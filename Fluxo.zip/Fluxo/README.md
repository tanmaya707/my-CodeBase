## Installation

```bash
$ yarn install

Rename `.env.example to .env`

Make sure you have the docker service running

To access graphql playground open 'localhost:4000/graphql'
```

## Running the app

```bash
# development
$ yarn run dev
```