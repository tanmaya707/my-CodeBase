import attributesList, { mapToAttributes } from './attributes'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

async function run(): Promise<void> {
  const attributes = mapToAttributes(attributesList)

  for (const attribute of attributes) {
    console.warn(attribute)
    try {
      await prisma.attribute.update({
        where: {
          name_type: {
            name: attribute.name,
            type: attribute.type,
          },
        },
        data: { iconUrl: attribute.iconUrl },
      })
    } catch (error) {
      console.error(error, 'ERROR')
    }
  }
}

void run()
