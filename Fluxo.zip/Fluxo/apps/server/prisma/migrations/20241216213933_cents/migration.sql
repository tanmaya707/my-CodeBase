-- Update dailyCost and hourlyCost in the day_passes table
UPDATE day_passes
SET daily_cost = daily_cost * 100;

-- Update dailyCost and hourlyCost in the spaces table
UPDATE spaces
SET hourly_cost = hourly_cost * 100,
    daily_cost = daily_cost * 100;