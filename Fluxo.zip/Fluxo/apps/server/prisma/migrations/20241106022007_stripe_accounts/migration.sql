/*
  Warnings:

  - You are about to drop the column `user_id` on the `stripe_business_accounts` table. All the data in the column will be lost.
  - A unique constraint covering the columns `[host_id]` on the table `stripe_business_accounts` will be added. If there are existing duplicate values, this will fail.
  - Added the required column `host_id` to the `stripe_business_accounts` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE "stripe_business_accounts" DROP CONSTRAINT "stripe_business_accounts_user_id_fkey";

-- DropIndex
DROP INDEX "stripe_business_accounts_user_id_key";

-- AlterTable
ALTER TABLE "stripe_business_accounts" DROP COLUMN "user_id",
ADD COLUMN     "host_id" TEXT NOT NULL;

-- CreateIndex
CREATE UNIQUE INDEX "stripe_business_accounts_host_id_key" ON "stripe_business_accounts"("host_id");

-- AddForeignKey
ALTER TABLE "stripe_business_accounts" ADD CONSTRAINT "stripe_business_accounts_host_id_fkey" FOREIGN KEY ("host_id") REFERENCES "hosts"("id") ON DELETE CASCADE ON UPDATE CASCADE;
