-- CreateEnum
CREATE TYPE "DayOfTheWeek" AS ENUM ('MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY', 'SUNDAY');

-- CreateTable
CREATE TABLE "availabilities" (
    "id" TEXT NOT NULL,
    "from" TEXT NOT NULL,
    "to" TEXT NOT NULL,
    "propertyId" TEXT NOT NULL,
    "dayPassId" TEXT NOT NULL,

    CONSTRAINT "availabilities_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "DayPass" (
    "id" TEXT NOT NULL,
    "description" VARCHAR(3000) NOT NULL,
    "quanity" INTEGER NOT NULL,
    "dailyCost" INTEGER NOT NULL,

    CONSTRAINT "DayPass_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "_PropertyToPropertyDetail" (
    "A" TEXT NOT NULL,
    "B" TEXT NOT NULL
);

-- CreateIndex
CREATE UNIQUE INDEX "_PropertyToPropertyDetail_AB_unique" ON "_PropertyToPropertyDetail"("A", "B");

-- CreateIndex
CREATE INDEX "_PropertyToPropertyDetail_B_index" ON "_PropertyToPropertyDetail"("B");

-- AddForeignKey
ALTER TABLE "availabilities" ADD CONSTRAINT "availabilities_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES "properties"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "availabilities" ADD CONSTRAINT "availabilities_dayPassId_fkey" FOREIGN KEY ("dayPassId") REFERENCES "DayPass"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_PropertyToPropertyDetail" ADD CONSTRAINT "_PropertyToPropertyDetail_A_fkey" FOREIGN KEY ("A") REFERENCES "properties"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_PropertyToPropertyDetail" ADD CONSTRAINT "_PropertyToPropertyDetail_B_fkey" FOREIGN KEY ("B") REFERENCES "property_details"("id") ON DELETE CASCADE ON UPDATE CASCADE;
