/*
  Warnings:

  - You are about to drop the column `seats` on the `BookingPassGroup` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "BookingPassGroup"
ADD COLUMN     "reviewScore" DOUBLE PRECISION NOT NULL DEFAULT 0;
