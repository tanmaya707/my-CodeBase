-- DropForeignKey
ALTER TABLE "availabilities" DROP CONSTRAINT "availabilities_dayPassId_fkey";

-- DropForeignKey
ALTER TABLE "availabilities" DROP CONSTRAINT "availabilities_propertyId_fkey";

-- AlterTable
ALTER TABLE "availabilities" ALTER COLUMN "propertyId" DROP NOT NULL,
ALTER COLUMN "dayPassId" DROP NOT NULL;

-- AddForeignKey
ALTER TABLE "availabilities" ADD CONSTRAINT "availabilities_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES "properties"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "availabilities" ADD CONSTRAINT "availabilities_dayPassId_fkey" FOREIGN KEY ("dayPassId") REFERENCES "DayPass"("id") ON DELETE SET NULL ON UPDATE CASCADE;
