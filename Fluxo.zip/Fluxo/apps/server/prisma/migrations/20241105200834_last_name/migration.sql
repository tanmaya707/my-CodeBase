-- AlterTable
ALTER TABLE "users" ADD COLUMN     "first_name" TEXT NOT NULL DEFAULT 'Unknown',
ADD COLUMN     "last_name" TEXT NOT NULL DEFAULT 'Unknown';
