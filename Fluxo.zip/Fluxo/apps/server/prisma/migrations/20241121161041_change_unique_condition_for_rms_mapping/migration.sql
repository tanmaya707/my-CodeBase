/*
  Warnings:

  - A unique constraint covering the columns `[rmsId,rmsEntityType]` on the table `rms_mapping` will be added. If there are existing duplicate values, this will fail.

*/
-- DropIndex
DROP INDEX "rms_mapping_rmsId_key";

-- CreateIndex
CREATE UNIQUE INDEX "rms_mapping_rmsId_rmsEntityType_key" ON "rms_mapping"("rmsId", "rmsEntityType");
