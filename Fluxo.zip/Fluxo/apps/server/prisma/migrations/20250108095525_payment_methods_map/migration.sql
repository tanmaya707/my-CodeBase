/*
  Warnings:

  - You are about to drop the column `isDefault` on the `stripe_customer_payment_methods` table. All the data in the column will be lost.
  - You are about to drop the column `isRemoved` on the `stripe_customer_payment_methods` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "stripe_customer_payment_methods" DROP COLUMN "isDefault",
DROP COLUMN "isRemoved",
ADD COLUMN     "is_default" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "is_removed" BOOLEAN NOT NULL DEFAULT false;
