/*
  Warnings:

  - You are about to drop the `stripe_customers` table. If the table is not empty, all the data it contains will be lost.

*/
-- DropForeignKey
ALTER TABLE "stripe_customers" DROP CONSTRAINT "stripe_customers_user_id_fkey";

-- DropTable
DROP TABLE "stripe_customers";

-- CreateTable
CREATE TABLE "stripe_business_accounts" (
    "id" TEXT NOT NULL,
    "user_id" TEXT NOT NULL,
    "stripe_id" TEXT NOT NULL,
    "is_verified" BOOLEAN NOT NULL DEFAULT false,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "stripe_business_accounts_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "stripe_business_accounts_user_id_key" ON "stripe_business_accounts"("user_id");

-- CreateIndex
CREATE UNIQUE INDEX "stripe_business_accounts_stripe_id_key" ON "stripe_business_accounts"("stripe_id");

-- AddForeignKey
ALTER TABLE "stripe_business_accounts" ADD CONSTRAINT "stripe_business_accounts_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "hosts"("id") ON DELETE CASCADE ON UPDATE CASCADE;
