/*
  Warnings:

  - You are about to drop the column `property_id` on the `BookingPass` table. All the data in the column will be lost.

*/
-- DropForeignKey
ALTER TABLE "BookingPass" DROP CONSTRAINT "BookingPass_property_id_fkey";

-- AlterTable
ALTER TABLE "BookingPass" DROP COLUMN "property_id",
ADD COLUMN     "propertyId" TEXT;

-- AddForeignKey
ALTER TABLE "BookingPass" ADD CONSTRAINT "BookingPass_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES "properties"("id") ON DELETE SET NULL ON UPDATE CASCADE;
