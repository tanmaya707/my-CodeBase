INSERT INTO locations (id, address, coordinates, host_id)
SELECT
    gen_random_uuid(), -- Generate a unique ID for the location
    'Central Park West, New York, NY, USA', -- Fixed address
    'SRID=4326;POINT(40.7811022 -73.9724322)', -- Fixed coordinates
    h.id -- Host ID
FROM
    hosts h
WHERE
    NOT EXISTS (
        SELECT 1
        FROM locations l
        WHERE l.host_id = h.id
    );