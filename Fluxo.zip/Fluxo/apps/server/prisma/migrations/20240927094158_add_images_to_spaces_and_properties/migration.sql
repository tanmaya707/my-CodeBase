/*
  Warnings:

  - Added the required column `hero_image` to the `properties` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "properties" ADD COLUMN     "hero_image" TEXT NOT NULL,
ADD COLUMN     "images" TEXT[];

-- AlterTable
ALTER TABLE "spaces" ADD COLUMN     "images" TEXT[];
