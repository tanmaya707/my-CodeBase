-- DropIndex
DROP INDEX "spaces_property_id_key";
