-- AlterTable
ALTER TABLE "Location" ALTER COLUMN "property_id" DROP NOT NULL,
ALTER COLUMN "guest_id" DROP NOT NULL;
