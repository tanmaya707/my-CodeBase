-- AlterTable
ALTER TABLE "BookingPass" ADD COLUMN     "rms_day_pass_id" TEXT;
