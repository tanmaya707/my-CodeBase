-- AlterTable
ALTER TABLE "users" ADD COLUMN     "tokens_expiry_threshold" TIMESTAMP(3);
