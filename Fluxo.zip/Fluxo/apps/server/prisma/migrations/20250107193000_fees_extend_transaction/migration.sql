-- AlterTable
ALTER TABLE "transactions_history" ADD COLUMN     "bookingFee" DOUBLE PRECISION,
ADD COLUMN     "transactionFee" DOUBLE PRECISION;
