/*
  Warnings:

  - You are about to drop the column `stripeCustomerId` on the `stripe_customers` table. All the data in the column will be lost.
  - A unique constraint covering the columns `[stripe_customer_id]` on the table `stripe_customers` will be added. If there are existing duplicate values, this will fail.
  - Added the required column `stripe_customer_id` to the `stripe_customers` table without a default value. This is not possible if the table is not empty.

*/
-- DropIndex
DROP INDEX "stripe_customers_stripeCustomerId_key";

-- AlterTable
ALTER TABLE "stripe_customers" DROP COLUMN "stripeCustomerId",
ADD COLUMN     "stripe_customer_id" TEXT NOT NULL;

-- CreateIndex
CREATE UNIQUE INDEX "stripe_customers_stripe_customer_id_key" ON "stripe_customers"("stripe_customer_id");
