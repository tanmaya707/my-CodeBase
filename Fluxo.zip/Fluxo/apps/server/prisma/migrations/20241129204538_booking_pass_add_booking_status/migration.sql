-- CreateEnum
CREATE TYPE "BookingStatus" AS ENUM ('PENCIL', 'ARRIVED', 'CONFIRMED', 'UNCONFIRMED', 'CANCELED');

-- AlterTable
ALTER TABLE "BookingPass" ADD COLUMN     "bookingStatus" "BookingStatus" NOT NULL DEFAULT 'PENCIL';
