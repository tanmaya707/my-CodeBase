/*
  Warnings:

  - A unique constraint covering the columns `[rmsId,rmsCategoryId,rmsEntityType]` on the table `rms_mapping` will be added. If there are existing duplicate values, this will fail.

*/
-- DropIndex
DROP INDEX "rms_mapping_rmsId_rmsCategoryId_key";

-- DropIndex
DROP INDEX "rms_mapping_rmsId_rmsEntityType_key";

-- CreateIndex
CREATE UNIQUE INDEX "rms_mapping_rmsId_rmsCategoryId_rmsEntityType_key" ON "rms_mapping"("rmsId", "rmsCategoryId", "rmsEntityType");
