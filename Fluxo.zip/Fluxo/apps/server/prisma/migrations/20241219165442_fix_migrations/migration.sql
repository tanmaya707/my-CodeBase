/*
  Warnings:

  - You are about to drop the column `seats` on the `BookingPassGroup` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "BookingPassGroup" DROP COLUMN "seats";
