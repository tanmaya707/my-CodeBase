/*
  Warnings:

  - The `rms_day_pass_id` column on the `BookingPass` table would be dropped and recreated. This will lead to data loss if there is data in the column.

*/
-- AlterTable
ALTER TABLE "BookingPass" DROP COLUMN "rms_day_pass_id",
ADD COLUMN     "rms_day_pass_id" INTEGER;
