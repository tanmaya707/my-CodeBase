/*
  Warnings:

  - You are about to drop the column `spaceId` on the `attributes` table. All the data in the column will be lost.
  - Made the column `property_id` on table `day_passes` required. This step will fail if there are existing NULL values in that column.
  - Made the column `property_id` on table `spaces` required. This step will fail if there are existing NULL values in that column.

*/
-- DropForeignKey
ALTER TABLE "attributes" DROP CONSTRAINT "attributes_spaceId_fkey";

-- AlterTable
ALTER TABLE "attributes" DROP COLUMN "spaceId";

-- AlterTable
ALTER TABLE "day_passes" ALTER COLUMN "property_id" SET NOT NULL;

-- AlterTable
ALTER TABLE "spaces" ALTER COLUMN "property_id" SET NOT NULL;

-- CreateTable
CREATE TABLE "_AttributeToSpace" (
    "A" TEXT NOT NULL,
    "B" TEXT NOT NULL
);

-- CreateIndex
CREATE UNIQUE INDEX "_AttributeToSpace_AB_unique" ON "_AttributeToSpace"("A", "B");

-- CreateIndex
CREATE INDEX "_AttributeToSpace_B_index" ON "_AttributeToSpace"("B");

-- AddForeignKey
ALTER TABLE "_AttributeToSpace" ADD CONSTRAINT "_AttributeToSpace_A_fkey" FOREIGN KEY ("A") REFERENCES "attributes"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_AttributeToSpace" ADD CONSTRAINT "_AttributeToSpace_B_fkey" FOREIGN KEY ("B") REFERENCES "spaces"("id") ON DELETE CASCADE ON UPDATE CASCADE;
