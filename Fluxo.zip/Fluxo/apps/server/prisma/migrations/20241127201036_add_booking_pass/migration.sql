-- CreateEnum
CREATE TYPE "BookingEntityType" AS ENUM ('SPACE', 'DAY_PASS');

-- CreateTable
CREATE TABLE "BookingPass" (
    "id" TEXT NOT NULL,
    "confirmation_number" TEXT NOT NULL,
    "expected_arrival_time" TIMESTAMP(3),
    "notes" TEXT,
    "booking_entity_type" "BookingEntityType" NOT NULL,
    "seats" INTEGER NOT NULL,
    "basePrice" INTEGER NOT NULL,
    "rms_mapping_id" TEXT NOT NULL,
    "property_id" TEXT NOT NULL,
    "guest_id" TEXT,
    "day_pass_id" TEXT,
    "space_id" TEXT,

    CONSTRAINT "BookingPass_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "BookingPass_rms_mapping_id_key" ON "BookingPass"("rms_mapping_id");

-- AddForeignKey
ALTER TABLE "BookingPass" ADD CONSTRAINT "BookingPass_rms_mapping_id_fkey" FOREIGN KEY ("rms_mapping_id") REFERENCES "rms_mapping"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "BookingPass" ADD CONSTRAINT "BookingPass_property_id_fkey" FOREIGN KEY ("property_id") REFERENCES "properties"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "BookingPass" ADD CONSTRAINT "BookingPass_guest_id_fkey" FOREIGN KEY ("guest_id") REFERENCES "guests"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "BookingPass" ADD CONSTRAINT "BookingPass_day_pass_id_fkey" FOREIGN KEY ("day_pass_id") REFERENCES "day_passes"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "BookingPass" ADD CONSTRAINT "BookingPass_space_id_fkey" FOREIGN KEY ("space_id") REFERENCES "spaces"("id") ON DELETE SET NULL ON UPDATE CASCADE;
