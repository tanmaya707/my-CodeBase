-- AlterEnum
ALTER TYPE "BookingStatus" ADD VALUE 'PENCIL_RTB';
