-- AlterTable
ALTER TABLE "guests" ALTER COLUMN "phone_number_country" SET DEFAULT 'US';

-- AlterTable
ALTER TABLE "hosts" ALTER COLUMN "business_phone_number_country" SET DEFAULT 'US';
