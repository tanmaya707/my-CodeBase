UPDATE users
SET first_name = SPLIT_PART(name, ' ', 1),
    last_name  = COALESCE(NULLIF(SPLIT_PART(name, ' ', 2), ''), 'Unknown');
