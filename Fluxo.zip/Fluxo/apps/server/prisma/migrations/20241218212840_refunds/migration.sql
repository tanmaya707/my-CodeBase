-- AlterTable
ALTER TABLE "BookingPassGroup" ADD COLUMN     "refunded_amount" DOUBLE PRECISION;
