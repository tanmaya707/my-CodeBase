-- CreateEnum
CREATE TYPE "PropertyDetailType" AS ENUM ('CATEGORY', 'FEATURES', 'VIBES');

-- CreateTable
CREATE TABLE "properties" (
    "id" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    "name" VARCHAR(300) NOT NULL,
    "address" TEXT NOT NULL,
    "logoUrl" TEXT NOT NULL,
    "description" VARCHAR(10000) NOT NULL,
    "wifiName" VARCHAR(100) NOT NULL,
    "wifiPassword" VARCHAR(100) NOT NULL,

    CONSTRAINT "properties_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "property_details" (
    "id" TEXT NOT NULL,
    "name" VARCHAR(80) NOT NULL,
    "type" "PropertyDetailType" NOT NULL,
    "iconUrl" TEXT NOT NULL DEFAULT '',
    "standard" BOOLEAN DEFAULT false,

    CONSTRAINT "property_details_pkey" PRIMARY KEY ("id")
);
