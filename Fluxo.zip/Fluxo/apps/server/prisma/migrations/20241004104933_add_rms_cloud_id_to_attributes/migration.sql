-- AlterTable
ALTER TABLE "attributes" ADD COLUMN     "rms_cloud_id" TEXT;
