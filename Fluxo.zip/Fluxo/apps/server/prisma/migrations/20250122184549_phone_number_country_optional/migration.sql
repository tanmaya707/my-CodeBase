-- AlterTable
ALTER TABLE "guests" ALTER COLUMN "phone_number_country" DROP NOT NULL;
