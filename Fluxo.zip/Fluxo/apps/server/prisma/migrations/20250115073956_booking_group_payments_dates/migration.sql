-- AlterTable
ALTER TABLE "BookingPassGroup" ADD COLUMN     "payment_captured_at" TIMESTAMP(3),
ADD COLUMN     "payment_created_at" TIMESTAMP(3);
