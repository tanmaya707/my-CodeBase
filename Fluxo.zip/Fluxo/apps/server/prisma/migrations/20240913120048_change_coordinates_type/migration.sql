/*
  Warnings:

  - Added the required column `coordinates` to the `properties` table without a default value. This is not possible if the table is not empty.

*/
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- AlterTable
ALTER TABLE "properties" ADD COLUMN "coordinates" geometry(Point, 4326) NOT NULL;
