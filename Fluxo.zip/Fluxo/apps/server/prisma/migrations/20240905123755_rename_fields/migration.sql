/*
  Warnings:

  - You are about to drop the column `dailyCost` on the `DayPass` table. All the data in the column will be lost.
  - You are about to drop the column `logoUrl` on the `properties` table. All the data in the column will be lost.
  - You are about to drop the column `wifiName` on the `properties` table. All the data in the column will be lost.
  - You are about to drop the column `wifiPassword` on the `properties` table. All the data in the column will be lost.
  - You are about to drop the column `iconUrl` on the `property_details` table. All the data in the column will be lost.
  - Added the required column `daily_cost` to the `DayPass` table without a default value. This is not possible if the table is not empty.
  - Added the required column `day_of_week` to the `availabilities` table without a default value. This is not possible if the table is not empty.
  - Added the required column `wifi_name` to the `properties` table without a default value. This is not possible if the table is not empty.
  - Added the required column `wifi_password` to the `properties` table without a default value. This is not possible if the table is not empty.

*/
-- CreateEnum
CREATE TYPE "DayOfWeek" AS ENUM ('MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY', 'SUNDAY');

-- AlterTable
ALTER TABLE "DayPass" DROP COLUMN "dailyCost",
ADD COLUMN     "daily_cost" INTEGER NOT NULL,
ALTER COLUMN "description" SET DEFAULT '';

-- AlterTable
ALTER TABLE "availabilities" ADD COLUMN     "day_of_week" "DayOfWeek" NOT NULL;

-- AlterTable
ALTER TABLE "properties" DROP COLUMN "logoUrl",
DROP COLUMN "wifiName",
DROP COLUMN "wifiPassword",
ADD COLUMN     "logo_url" TEXT NOT NULL DEFAULT '',
ADD COLUMN     "wifi_name" VARCHAR(100) NOT NULL,
ADD COLUMN     "wifi_password" VARCHAR(100) NOT NULL,
ALTER COLUMN "description" SET DEFAULT '';

-- AlterTable
ALTER TABLE "property_details" DROP COLUMN "iconUrl",
ADD COLUMN     "icon_url" TEXT NOT NULL DEFAULT '';

-- DropEnum
DROP TYPE "DayOfTheWeek";
