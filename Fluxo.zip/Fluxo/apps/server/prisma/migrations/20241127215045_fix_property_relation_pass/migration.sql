/*
  Warnings:

  - You are about to drop the column `propertyId` on the `BookingPass` table. All the data in the column will be lost.

*/
-- DropForeignKey
ALTER TABLE "BookingPass" DROP CONSTRAINT "BookingPass_propertyId_fkey";

-- AlterTable
ALTER TABLE "BookingPass" DROP COLUMN "propertyId";
