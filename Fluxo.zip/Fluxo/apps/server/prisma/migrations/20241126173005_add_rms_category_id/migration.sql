-- AlterTable
ALTER TABLE "rms_mapping" ADD COLUMN     "rmsCategoryId" INTEGER;
