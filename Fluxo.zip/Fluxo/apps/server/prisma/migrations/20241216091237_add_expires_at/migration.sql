-- AlterTable
ALTER TABLE "BookingPass" ADD COLUMN     "expires_at_date" TIMESTAMP(3);
