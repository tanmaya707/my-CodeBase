-- AlterTable
ALTER TABLE "attributes" ADD COLUMN     "spaceId" TEXT;

-- AlterTable
ALTER TABLE "availabilities" ADD COLUMN     "space_id" TEXT;

-- CreateTable
CREATE TABLE "spaces" (
    "id" TEXT NOT NULL,
    "name" VARCHAR(300) NOT NULL,
    "description" VARCHAR(300),
    "capacity" INTEGER NOT NULL DEFAULT 1,
    "hourly_cost" INTEGER NOT NULL,
    "manual_booking_approval" BOOLEAN NOT NULL DEFAULT false,
    "property_id" TEXT,

    CONSTRAINT "spaces_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "spaces_property_id_key" ON "spaces"("property_id");

-- AddForeignKey
ALTER TABLE "availabilities" ADD CONSTRAINT "availabilities_space_id_fkey" FOREIGN KEY ("space_id") REFERENCES "spaces"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "attributes" ADD CONSTRAINT "attributes_spaceId_fkey" FOREIGN KEY ("spaceId") REFERENCES "spaces"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "spaces" ADD CONSTRAINT "spaces_property_id_fkey" FOREIGN KEY ("property_id") REFERENCES "properties"("id") ON DELETE CASCADE ON UPDATE CASCADE;
