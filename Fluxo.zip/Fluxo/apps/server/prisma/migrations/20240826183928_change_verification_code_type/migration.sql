/*
  Warnings:

  - You are about to drop the column `emailVerificationCode` on the `users` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "users" DROP COLUMN "emailVerificationCode",
ADD COLUMN     "email_verification_code" TEXT;
