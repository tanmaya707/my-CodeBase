-- DropForeignKey
ALTER TABLE "stripe_business_accounts" DROP CONSTRAINT "stripe_business_accounts_host_id_fkey";

-- DropForeignKey
ALTER TABLE "stripe_customers" DROP CONSTRAINT "stripe_customers_guest_id_fkey";

-- AlterTable
ALTER TABLE "stripe_business_accounts" ALTER COLUMN "host_id" DROP NOT NULL;

-- AlterTable
ALTER TABLE "stripe_customers" ALTER COLUMN "guest_id" DROP NOT NULL;

-- AddForeignKey
ALTER TABLE "stripe_business_accounts" ADD CONSTRAINT "stripe_business_accounts_host_id_fkey" FOREIGN KEY ("host_id") REFERENCES "hosts"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "stripe_customers" ADD CONSTRAINT "stripe_customers_guest_id_fkey" FOREIGN KEY ("guest_id") REFERENCES "guests"("id") ON DELETE SET NULL ON UPDATE CASCADE;
