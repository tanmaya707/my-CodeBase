-- AlterEnum
ALTER TYPE "PaymentStatus" ADD VALUE 'REFUNDED';
