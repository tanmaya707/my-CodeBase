/*
  Warnings:

  - You are about to drop the column `quanity` on the `DayPass` table. All the data in the column will be lost.
  - Added the required column `quantity` to the `DayPass` table without a default value. This is not possible if the table is not empty.
  - Added the required column `neighborhood` to the `properties` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "DayPass" DROP COLUMN "quanity",
ADD COLUMN     "quantity" INTEGER NOT NULL;

-- AlterTable
ALTER TABLE "properties" ADD COLUMN     "dayPassId" TEXT,
ADD COLUMN     "neighborhood" VARCHAR(300) NOT NULL,
ADD COLUMN     "unlistedDays" TIMESTAMP(3)[];

-- AddForeignKey
ALTER TABLE "properties" ADD CONSTRAINT "properties_dayPassId_fkey" FOREIGN KEY ("dayPassId") REFERENCES "DayPass"("id") ON DELETE SET NULL ON UPDATE CASCADE;
