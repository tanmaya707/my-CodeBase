/*
  Warnings:

  - You are about to drop the column `order` on the `attributes` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "attributes" DROP COLUMN "order";
