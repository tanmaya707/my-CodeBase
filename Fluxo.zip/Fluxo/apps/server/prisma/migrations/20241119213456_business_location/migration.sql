/*
  Warnings:

  - You are about to drop the column `business_location` on the `hosts` table. All the data in the column will be lost.
  - A unique constraint covering the columns `[host_id]` on the table `locations` will be added. If there are existing duplicate values, this will fail.

*/
-- AlterTable
ALTER TABLE "hosts" DROP COLUMN "business_location";

-- AlterTable
ALTER TABLE "locations" ADD COLUMN     "host_id" TEXT;

-- CreateIndex
CREATE UNIQUE INDEX "locations_host_id_key" ON "locations"("host_id");

-- AddForeignKey
ALTER TABLE "locations" ADD CONSTRAINT "locations_host_id_fkey" FOREIGN KEY ("host_id") REFERENCES "hosts"("id") ON DELETE CASCADE ON UPDATE CASCADE;
