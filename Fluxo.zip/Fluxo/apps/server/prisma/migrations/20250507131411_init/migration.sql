-- CreateTable
CREATE TABLE "stripe_coupons" (
    "id" TEXT NOT NULL,
    "amount_off" INTEGER,
    "created_at" BIGINT NOT NULL,
    "currency" TEXT,
    "duration" TEXT NOT NULL,
    "duration_in_months" INTEGER,
    "livemode" BOOLEAN NOT NULL,
    "max_redemptions" INTEGER,
    "name" TEXT,
    "percent_off" INTEGER,
    "redeem_by" BIGINT,
    "times_redeemed" INTEGER NOT NULL,
    "valid" BOOLEAN NOT NULL,

    CONSTRAINT "stripe_coupons_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "stripe_coupons_id_key" ON "stripe_coupons"("id");
