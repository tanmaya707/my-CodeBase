/*
  Warnings:

  - You are about to drop the column `rms_cloud_id` on the `attributes` table. All the data in the column will be lost.
  - You are about to drop the column `rmsId` on the `users` table. All the data in the column will be lost.
  - A unique constraint covering the columns `[rms_mapping_id]` on the table `attributes` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[rms_mapping_id]` on the table `day_passes` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[rms_mapping_id]` on the table `properties` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[rms_mapping_id]` on the table `spaces` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[rms_mapping_id]` on the table `users` will be added. If there are existing duplicate values, this will fail.

*/
-- CreateEnum
CREATE TYPE "RmsEntityType" AS ENUM ('GUEST', 'RESERVATION', 'ATTRIBUTE', 'PROPERTY', 'AREA');

-- DropIndex
DROP INDEX "users_rmsId_key";

-- AlterTable
ALTER TABLE "attributes" DROP COLUMN "rms_cloud_id",
ADD COLUMN     "rms_mapping_id" TEXT;

-- AlterTable
ALTER TABLE "day_passes" ADD COLUMN     "rms_mapping_id" TEXT;

-- AlterTable
ALTER TABLE "properties" ADD COLUMN     "rms_mapping_id" TEXT;

-- AlterTable
ALTER TABLE "spaces" ADD COLUMN     "rms_mapping_id" TEXT;

-- AlterTable
ALTER TABLE "users" DROP COLUMN "rmsId",
ADD COLUMN     "rms_mapping_id" TEXT;

-- CreateTable
CREATE TABLE "rms_mapping" (
    "id" TEXT NOT NULL,
    "rmsId" TEXT NOT NULL,
    "rmsEntityType" "RmsEntityType" NOT NULL,

    CONSTRAINT "rms_mapping_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "rms_mapping_rmsId_key" ON "rms_mapping"("rmsId");

-- CreateIndex
CREATE UNIQUE INDEX "attributes_rms_mapping_id_key" ON "attributes"("rms_mapping_id");

-- CreateIndex
CREATE UNIQUE INDEX "day_passes_rms_mapping_id_key" ON "day_passes"("rms_mapping_id");

-- CreateIndex
CREATE UNIQUE INDEX "properties_rms_mapping_id_key" ON "properties"("rms_mapping_id");

-- CreateIndex
CREATE UNIQUE INDEX "spaces_rms_mapping_id_key" ON "spaces"("rms_mapping_id");

-- CreateIndex
CREATE UNIQUE INDEX "users_rms_mapping_id_key" ON "users"("rms_mapping_id");

-- AddForeignKey
ALTER TABLE "users" ADD CONSTRAINT "users_rms_mapping_id_fkey" FOREIGN KEY ("rms_mapping_id") REFERENCES "rms_mapping"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "properties" ADD CONSTRAINT "properties_rms_mapping_id_fkey" FOREIGN KEY ("rms_mapping_id") REFERENCES "rms_mapping"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "attributes" ADD CONSTRAINT "attributes_rms_mapping_id_fkey" FOREIGN KEY ("rms_mapping_id") REFERENCES "rms_mapping"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "day_passes" ADD CONSTRAINT "day_passes_rms_mapping_id_fkey" FOREIGN KEY ("rms_mapping_id") REFERENCES "rms_mapping"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "spaces" ADD CONSTRAINT "spaces_rms_mapping_id_fkey" FOREIGN KEY ("rms_mapping_id") REFERENCES "rms_mapping"("id") ON DELETE CASCADE ON UPDATE CASCADE;
