-- AlterTable
ALTER TABLE "stripe_customers" ADD COLUMN     "is_verified" BOOLEAN NOT NULL DEFAULT false;
