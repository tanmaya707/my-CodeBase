-- CreateTable
CREATE TABLE "payouts_history" (
    "id" TEXT NOT NULL,
    "payout_id" TEXT NOT NULL,
    "business_stripe_id" TEXT NOT NULL,
    "balance_transaction_id" TEXT NOT NULL,
    "statement_descriptor" TEXT NOT NULL,
    "failure_code" TEXT,
    "total" DOUBLE PRECISION NOT NULL,
    "status" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "payouts_history_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "payouts_history_payout_id_key" ON "payouts_history"("payout_id");

-- CreateIndex
CREATE UNIQUE INDEX "payouts_history_balance_transaction_id_key" ON "payouts_history"("balance_transaction_id");
