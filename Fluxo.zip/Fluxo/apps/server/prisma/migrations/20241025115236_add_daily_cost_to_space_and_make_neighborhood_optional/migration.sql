-- AlterTable
ALTER TABLE "properties" ALTER COLUMN "neighborhood" DROP NOT NULL;

-- AlterTable
ALTER TABLE "spaces" ADD COLUMN     "daily_cost" INTEGER;
