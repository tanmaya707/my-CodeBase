/*
  Warnings:

  - You are about to drop the column `description` on the `day_passes` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "day_passes" DROP COLUMN "description";
