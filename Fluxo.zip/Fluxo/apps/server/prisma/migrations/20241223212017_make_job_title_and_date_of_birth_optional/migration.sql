-- AlterTable
ALTER TABLE "guests" ALTER COLUMN "job_title" DROP NOT NULL,
ALTER COLUMN "date_of_birth" DROP NOT NULL;
