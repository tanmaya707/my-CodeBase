-- AlterTable
ALTER TABLE "BookingPassGroup" ADD COLUMN     "bookingFee" DOUBLE PRECISION,
ADD COLUMN     "transactionFee" DOUBLE PRECISION;
