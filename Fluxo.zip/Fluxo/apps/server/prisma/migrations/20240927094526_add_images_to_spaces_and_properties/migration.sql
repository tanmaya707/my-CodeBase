-- AlterTable
ALTER TABLE "properties" ALTER COLUMN "hero_image" SET DEFAULT '';
