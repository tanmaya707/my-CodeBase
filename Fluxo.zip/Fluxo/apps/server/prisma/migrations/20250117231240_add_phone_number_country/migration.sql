-- AlterTable
ALTER TABLE "guests" ADD COLUMN     "phone_number_country" TEXT NOT NULL DEFAULT 'USA';
