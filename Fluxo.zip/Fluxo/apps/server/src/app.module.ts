import { Module } from '@nestjs/common'
import { EventEmitterModule } from '@nestjs/event-emitter'
import { ScheduleModule } from '@nestjs/schedule'
import { SentryModule } from '@sentry/nestjs/setup'

import { ConfigModule } from '@/common/config/config.module'
import { GraphqlModule } from '@/common/services/graphql/graphql.module'
import { ExpoPushModule } from '@/common/services/integrations/expo-push/expo-push.module'
import { HubspotModule } from '@/common/services/integrations/hubspot/hubspot.module'
import { RmsCloudModule } from '@/common/services/integrations/rms-cloud/rms-cloud.module'
import { RmsCloudWebhooksModule } from '@/common/services/integrations/rms-cloud/webhooks/rms-cloud-webhooks.module'
import { StripeBusinessModule } from '@/common/services/integrations/stripe/business/stripe-business.module'
import { StripeCustomersModule } from '@/common/services/integrations/stripe/customers/stripe-customers.module'
import { JwtTokenModule } from '@/common/services/jwt-token/jwt-token.module'
import { PasswordModule } from '@/common/services/password/password.module'
import { PrismaModule } from '@/common/services/prisma/prisma.module'
import { ResourcesModule } from '@/resources/resources.module'
import { ReviewsModule } from '@/resources/reviews/reviews.module'
import { CouponService } from '@/common/services/integrations/stripe/coupon/coupon.service';
import { CouponController } from '@/common/services/integrations/stripe/coupon/coupon.controller';
import { CouponsModule } from './resources/coupons/coupons.module'

@Module({
  imports: [
    // Nest modules
    SentryModule.forRoot(),
    ScheduleModule.forRoot(),
    EventEmitterModule.forRoot({ verboseMemoryLeak: true }),

    // Resources module
    ResourcesModule,

    // Common modules
    ConfigModule,
    GraphqlModule,
    PrismaModule,
    PasswordModule,
    JwtTokenModule,

    // Integration modules
    HubspotModule,
    RmsCloudModule,
    RmsCloudWebhooksModule,
    ReviewsModule,
    StripeBusinessModule,
    StripeCustomersModule,
    ExpoPushModule,
    CouponsModule
  ],
  controllers: [CouponController],
  providers: [CouponService],
})
export class AppModule {}
