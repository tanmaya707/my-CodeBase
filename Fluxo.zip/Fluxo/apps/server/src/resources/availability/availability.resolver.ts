import { BadRequestException, UseGuards } from '@nestjs/common'
import { Args, Query, Resolver } from '@nestjs/graphql'
import { UserRole } from '@prisma/client'

import { ErrorGraphqlHandlingDecorator } from '@/common/decorators/error-graphql-handling.decorator'
import { Roles } from '@/common/decorators/roles.decorator'
import { JwtAuthGuard } from '@/common/guards/jwt-auth.guard'
import { RolesGuard } from '@/common/guards/roles.guard'
import { PrismaService } from '@/common/services/prisma/prisma.service'
import {
  AvailabilityService,
  PropertyForAvailabilityCheck,
} from '@/resources/availability/availability.service'
import { AvailableTimeSlotsInput } from '@/resources/availability/dto/time-slots-availability'
import { VenueAvailabilityInput } from '@/resources/availability/dto/venue-availability.input'
import { TimeSlotWithAvailabilityEntity } from '@/resources/availability/entities/time-slot.entity'
import { VenueAvailabilityEntity } from '@/resources/availability/entities/venue-availability.entity'

@Resolver()
export class AvailabilityResolver {
  constructor(
    private readonly availabilityService: AvailabilityService,
    private readonly prismaService: PrismaService,
  ) {}

  @Query(() => [TimeSlotWithAvailabilityEntity])
  @ErrorGraphqlHandlingDecorator(AvailabilityResolver.name)
  async timeSlotsAvailability(@Args('input') input: AvailableTimeSlotsInput) {
    return this.availabilityService.getTimeSlotsAvailability(input)
  }

  @Query(() => VenueAvailabilityEntity)
  @ErrorGraphqlHandlingDecorator(AvailabilityResolver.name)
  async venueAvailability(@Args('input') input: VenueAvailabilityInput) {
    const property: PropertyForAvailabilityCheck | null =
      await this.prismaService.property.findUnique({
        where: { id: input.propertyId },
        select: {
          id: true,
          dayPass: {
            select: {
              quantity: true,
              id: true,
              availability: { select: { from: true, to: true, dayOfWeek: true } },
            },
          },
          spaces: {
            select: {
              availability: { select: { from: true, to: true, dayOfWeek: true } },
              unlistedTime: true,
              id: true,
            },
          },
          unlistedDays: true,
        },
      })

    if (!property) {
      throw new BadRequestException("Can't find property in DB")
    }

    return this.availabilityService.getVenueAvailability({ date: input.date, property })
  }
}
