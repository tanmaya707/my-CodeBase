import { Field, InterfaceType } from '@nestjs/graphql'
import { IsISO8601 } from 'class-validator'

@InterfaceType()
export class TimeSlotInterface {
  @Field(() => Date)
  @IsISO8601()
  timeDateFrom: Date

  @Field(() => Date)
  @IsISO8601()
  timeDateTo: Date

  @Field(() => String)
  timeString: string
}
