import { Field, ID, InputType } from '@nestjs/graphql'
import { Type } from 'class-transformer'
import { IsNotEmpty, ValidateNested } from 'class-validator'

import { TimeSlotInput } from '@/resources/availability/dto/time-slot.input'

@InputType()
export class AvailableTimeSlotsInput {
  @IsNotEmpty()
  @Field(() => ID)
  spaceId: string

  @IsNotEmpty()
  @ValidateNested({ each: true })
  @Type(() => TimeSlotInput)
  @Field(() => [TimeSlotInput])
  timeSlots: TimeSlotInput[]
}
