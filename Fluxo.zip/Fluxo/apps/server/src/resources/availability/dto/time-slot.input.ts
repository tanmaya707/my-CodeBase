import { Field, InputType } from '@nestjs/graphql'
import { IsNotEmpty } from 'class-validator'

import { TimeSlotInterface } from '@/resources/availability/interfaces/time-slot.interface'

@InputType()
export class TimeSlotInput implements TimeSlotInterface {
  @IsNotEmpty()
  @Field(() => Date)
  timeDateFrom: Date

  @IsNotEmpty()
  @Field(() => Date)
  timeDateTo: Date

  @IsNotEmpty()
  @Field(() => String)
  timeString: string
}
