import { UTCDate } from '@date-fns/utc'
import { BadGatewayException, Injectable, Logger } from '@nestjs/common'
import { Availability, BookingEntityType, BookingStatus, UnlistedTime } from '@prisma/client'
import {
  differenceInHours,
  endOfDay,
  format,
  interval,
  isSameDay,
  isWithinInterval,
  max,
  min,
  parse,
  startOfDay,
} from 'date-fns'
import pLimit from 'p-limit'

import { RmsCloudService } from '@/common/services/integrations/rms-cloud/rms-cloud.service'
import {
  RMSCloudReservationBasic,
  RMSCloudReservationSearchListOfStatusEnum,
} from '@/common/services/integrations/rms-cloud/rms-cloud-types'
import { PrismaService } from '@/common/services/prisma/prisma.service'
import { blockingBookingStatuses } from '@/common/utils'
import { SearchAvailabilityInput } from '@/resources/availability/dto/search-availability.input'
import { AvailableTimeSlotsInput } from '@/resources/availability/dto/time-slots-availability'
import { VenueAvailabilityInput } from '@/resources/availability/dto/venue-availability.input'
import { TimeSlotWithAvailabilityEntity } from '@/resources/availability/entities/time-slot.entity'

// Tbd - think about better solution later
export interface PropertyForAvailabilityCheck {
  id: string
  dayPass: {
    id: string
    quantity: number
    availability: Pick<Availability, 'from' | 'to' | 'dayOfWeek'>[]
  } | null
  spaces: {
    id: string
    availability: Pick<Availability, 'from' | 'to' | 'dayOfWeek'>[]
    unlistedTime: UnlistedTime[]
  }[]
  unlistedDays: Date[]
}

@Injectable()
export class AvailabilityService {
  private readonly logger = new Logger(AvailabilityService.name)

  constructor(
    private readonly prismaService: PrismaService,
    private readonly rmsCloudService: RmsCloudService,
  ) {}

  public async getAvailableProperties(input: SearchAvailabilityInput) {
    const properties: PropertyForAvailabilityCheck[] = await this.prismaService.property.findMany({
      where: { id: { in: input.propertyIds } },
      select: {
        id: true,
        dayPass: {
          select: {
            quantity: true,
            id: true,
            availability: { select: { from: true, to: true, dayOfWeek: true } },
          },
        },
        spaces: {
          select: {
            availability: { select: { from: true, to: true, dayOfWeek: true } },
            unlistedTime: true,
            id: true,
          },
        },
        unlistedDays: true,
      },
    })
    const limit = pLimit(10)
    const propertiesAvailability = await Promise.all(
      properties.map((property) =>
        limit(async () => {
          const propertyAvailability = await this.getVenueAvailability({
            property,
            date: input.date,
          })

          return {
            id: property.id,
            availableDayPasses: propertyAvailability.availableDayPasses,
            availableSpaces: propertyAvailability.availableSpacesIds.length,
          }
        }),
      ),
    )

    return propertiesAvailability.filter(
      ({ availableSpaces, availableDayPasses }) => availableDayPasses > 0 || availableSpaces > 0,
    )
  }

  public async getVenueAvailability(
    input: Pick<VenueAvailabilityInput, 'date'> & { property: PropertyForAvailabilityCheck },
  ) {
    const { date, property } = input
    const utcDate = new UTCDate(date)
    const now = new UTCDate()
    const dayOfWeek = format(utcDate, 'EEEE').toUpperCase()
    const isSelectedDayUnlisted = property.unlistedDays.some((day) => isSameDay(day, utcDate))

    if (isSelectedDayUnlisted) {
      // If venue unlisted day is the selected date, the venue is unavailable
      return {
        availableDayPasses: 0,
        availableSpacesIds: [],
      }
    }

    const baseBookingPassWhere = {
      bookingStatus: { in: blockingBookingStatuses },
      guest: { isNot: null },
      AND: [
        {
          OR: [
            // If the booking is not in pencil status, do not apply the expiry check.
            { bookingStatus: { notIn: [BookingStatus.PENCIL, BookingStatus.PENCIL_RTB] } },
            {
              AND: [
                { bookingStatus: { in: [BookingStatus.PENCIL, BookingStatus.PENCIL_RTB] } },
                { expiresAt: { gt: now } },
              ],
            },
          ],
        },
      ],
    }

    // Calculate day pass availability
    const dayPassBookingsAmount = await this.prismaService.bookingPass.count({
      where: {
        ...baseBookingPassWhere,
        dayPassId: property.dayPass?.id,
        arrivalDate: { gte: startOfDay(utcDate), lt: endOfDay(utcDate) },
        departureDate: { gt: startOfDay(utcDate), lte: endOfDay(utcDate) },
        bookingEntityType: BookingEntityType.DAY_PASS,
      },
    })

    const totalAvailableDayPasses = property.dayPass?.quantity
      ? Math.max(0, property.dayPass.quantity - dayPassBookingsAmount)
      : 0

    const isSelectedDayAvailable = property.dayPass?.availability.some(
      (dailyAvailability) => dailyAvailability.dayOfWeek === dayOfWeek,
    )
    const isDayPassUnavailable = !isSelectedDayAvailable

    // Calculate spaces availability
    const availableSpacesIds: string[] = []

    for await (const space of property.spaces) {
      const selectedDayAvailability = space.availability.find(
        (dailyAvailability) => dailyAvailability.dayOfWeek === dayOfWeek,
      )
      if (!selectedDayAvailability?.from || !selectedDayAvailability.to) {
        continue // This space is not available on the selected day
      }

      const availabilityArrivalDate = parse(selectedDayAvailability.from, 'hh:mm a', utcDate)
      const availabilityDepartureDate = parse(selectedDayAvailability.to, 'hh:mm a', utcDate)
      const totalTimeSlots = Math.abs(
        differenceInHours(availabilityDepartureDate, availabilityArrivalDate),
      )

      const unlistedTimeForSelectedDay = space.unlistedTime.find((time) =>
        isSameDay(time.date, utcDate),
      )
      const totalUnlistedTimeSlots = unlistedTimeForSelectedDay
        ? Math.abs(
            differenceInHours(
              parse(
                unlistedTimeForSelectedDay.from,
                'hh:mm a',
                new UTCDate(unlistedTimeForSelectedDay.date),
              ),
              parse(
                unlistedTimeForSelectedDay.to,
                'hh:mm a',
                new UTCDate(unlistedTimeForSelectedDay.date),
              ),
            ),
          )
        : 0

      // Space is unavailable if all time slots are unlisted.
      if (totalUnlistedTimeSlots >= totalTimeSlots) {
        continue
      }

      // Find bookings for this space within the available time window
      const spaceBookings = await this.prismaService.bookingPass.findMany({
        where: {
          ...baseBookingPassWhere,
          spaceId: space.id,
          arrivalDate: { gte: availabilityArrivalDate, lt: availabilityDepartureDate },
          departureDate: { gt: availabilityArrivalDate, lte: availabilityDepartureDate },
          bookingEntityType: BookingEntityType.SPACE,
        },
        select: { arrivalDate: true, departureDate: true },
      })

      const totalBookedTimeSlots = spaceBookings.reduce(
        (total, booking) =>
          total + Math.abs(differenceInHours(booking.departureDate, booking.arrivalDate)),
        0,
      )
      const totalAvailableTimeSlots =
        totalTimeSlots - (totalBookedTimeSlots + totalUnlistedTimeSlots)

      if (totalAvailableTimeSlots > 0) {
        availableSpacesIds.push(space.id)
      }
    }

    return {
      availableDayPasses: isDayPassUnavailable ? 0 : totalAvailableDayPasses,
      availableSpacesIds,
    }
  }
}
