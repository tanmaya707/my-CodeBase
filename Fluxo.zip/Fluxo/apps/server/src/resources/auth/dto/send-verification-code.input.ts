import { InputType, PickType } from '@nestjs/graphql'

import { UserInterface } from '@/resources/users/interfaces/user.interface'

@InputType()
export class SendVerificationCodeInput extends PickType(UserInterface, ['email'], InputType) {}
