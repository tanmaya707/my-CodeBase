import { Field, InputType, registerEnumType } from '@nestjs/graphql'
import { AuthType, UserRole } from '@prisma/client'
import { IsEnum, IsNotEmpty, IsOptional, NotEquals } from 'class-validator'

registerEnumType(AuthType, { name: 'AuthType' })

@InputType()
export class SocialSignInInput {
  @IsNotEmpty({ message: 'Social sign-in type is required' })
  @IsEnum(AuthType, { message: 'Invalid social sign-in type' })
  @NotEquals(AuthType.FLUXO, {
    message:
      'Social sign-in for a fluxo auth type is disabled, you need to use the normal sign-in for it',
  })
  @Field(() => AuthType)
  authType: AuthType

  @IsOptional()
  @IsEnum(UserRole, { message: 'Invalid user role' })
  @Field(() => UserRole, { nullable: true })
  userRole?: UserRole | null

  @IsNotEmpty({ message: 'Token is required' })
  @Field()
  token: string

  @IsOptional()
  @Field(() => String, { nullable: true })
  displayName?: string | null
}
