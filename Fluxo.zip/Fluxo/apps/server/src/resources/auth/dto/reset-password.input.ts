import { Field, InputType } from '@nestjs/graphql'
import { IsNotEmpty, MaxLength, MinLength } from 'class-validator'

import { MessageGraphqlService } from '@/common/services/graphql/message-graphql.service'

const MessageService = new MessageGraphqlService()

@InputType()
export class ResetPasswordInput {
  @MinLength(8, { message: MessageService.error('password', 'Minimum 8 characters') })
  @MaxLength(40, { message: MessageService.error('password', 'Maximum 40 characters') })
  @IsNotEmpty()
  @Field()
  newPassword: string

  @IsNotEmpty()
  @Field()
  token: string
}
