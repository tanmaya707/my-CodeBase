import { Field, InputType, PickType } from '@nestjs/graphql'
import { IsNotEmpty, MaxLength, MinLength } from 'class-validator'

import { MessageGraphqlService } from '@/common/services/graphql/message-graphql.service'
import { UserInterface } from '@/resources/users/interfaces/user.interface'

const MessageService = new MessageGraphqlService()

@InputType()
export class SignUpInput extends PickType(
  UserInterface,
  ['email', 'firstName', 'lastName', 'role'],
  InputType,
) {
  @MinLength(8, { message: MessageService.error('password', 'Minimum 8 characters') })
  @MaxLength(40, { message: MessageService.error('password', 'Maximum 40 characters') })
  @IsNotEmpty()
  @Field()
  password: string
}
