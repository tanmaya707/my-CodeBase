import { Field, InputType } from '@nestjs/graphql'
import { IsNotEmpty, MaxLength, MinLength } from 'class-validator'

import { MessageGraphqlService } from '@/common/services/graphql/message-graphql.service'

const MessageService = new MessageGraphqlService()

@InputType()
export class ChangePasswordInput {
  @MinLength(8, { message: MessageService.error('currentPassword', 'Minimum 8 characters') })
  @MaxLength(40, { message: MessageService.error('currentPassword', 'Maximum 40 characters') })
  @IsNotEmpty()
  @Field()
  currentPassword: string

  @MinLength(8, { message: MessageService.error('newPassword', 'Minimum 8 characters') })
  @MaxLength(40, { message: MessageService.error('newPassword', 'Maximum 40 characters') })
  @IsNotEmpty()
  @Field()
  newPassword: string
}
