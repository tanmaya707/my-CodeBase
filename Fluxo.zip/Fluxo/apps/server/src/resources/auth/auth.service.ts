import {
  BadRequestException,
  ForbiddenException,
  Injectable,
  Logger,
  UnauthorizedException,
} from '@nestjs/common'
import { ConfigService } from '@nestjs/config'
import { EventEmitter2 } from '@nestjs/event-emitter'
import { AuthType, User, UserRole } from '@prisma/client'
import { omit } from 'es-toolkit'

import type { AppConfig } from '@/common/config/configuration'
import { AuthTokenInterface } from '@/common/interfaces/auth-token.interface'
import { EmailService } from '@/common/services/email/email.service'
import { ContextServer } from '@/common/services/graphql/graphql.module'
import { SocialAuthService } from '@/common/services/integrations/social-auth/social-auth.service'
import { StripeBusinessService } from '@/common/services/integrations/stripe/business/stripe-business.service'
import { StripeCustomersService } from '@/common/services/integrations/stripe/customers/stripe-customers.service'
import { JwtTokenPayload, JwtTokenService } from '@/common/services/jwt-token/jwt-token.service'
import { PasswordService } from '@/common/services/password/password.service'
import { ChangePasswordInput } from '@/resources/auth/dto/change-password.input'
import { ResetPasswordInput } from '@/resources/auth/dto/reset-password.input'
import { SignInInput } from '@/resources/auth/dto/sign-in.input'
import { SignUpInput } from '@/resources/auth/dto/sign-up.input'
import { SocialSignInInput } from '@/resources/auth/dto/social-sign-in.input'
import { VerifyCodeInput } from '@/resources/auth/dto/verify-code.input'
import { UsersService } from '@/resources/users/users.service'

@Injectable()
export class AuthService {
  private readonly logger = new Logger(AuthService.name)

  constructor(
    private readonly passwordService: PasswordService,
    private readonly jwtTokenService: JwtTokenService,
    private readonly configService: ConfigService<AppConfig>,
    private readonly usersService: UsersService,
    private readonly emailService: EmailService,
    private readonly socialAuthService: SocialAuthService,
    private readonly stripeBusinessService: StripeBusinessService,
    private readonly stripeCustomerService: StripeCustomersService,
    private readonly eventEmitter: EventEmitter2,
  ) {}

  public async validateUser(email: string, password: string): Promise<Omit<User, 'password'>> {
    const user = await this.usersService.findUnique(email)

    if (!user) throw new UnauthorizedException('Incorrect email or password')

    const passwordsMatch = this.passwordService.comparePassword(password, user.password)

    if (!passwordsMatch) throw new UnauthorizedException('Incorrect email or password')

    return omit(user, ['password'])
  }

  public async changePassword(
    input: ChangePasswordInput,
    userDetails: JwtTokenPayload,
  ): Promise<void> {
    const { currentPassword, newPassword } = input
    const user = await this.usersService.findUniqueById(userDetails.id, {
      password: true,
      id: true,
    })

    if (!user) {
      throw new UnauthorizedException('User not found')
    }

    const passwordsMatch = this.passwordService.comparePassword(currentPassword, user.password)

    if (!passwordsMatch) {
      throw new UnauthorizedException('The current password is incorrect')
    }

    await this.updateUserPassword(user.id, newPassword)
  }

  public async signIn(input: SignInInput, ctx: ContextServer): Promise<AuthTokenInterface> {
    const validatedUser = await this.validateUser(input.email, input.password)
    const tokenExpirationTime = this.configService.get('app.tokenExpirationTime', { infer: true })

    if (!validatedUser.emailVerified) throw new ForbiddenException('Email is not verified')

    const authToken = await this.jwtTokenService.createToken(
      {
        email: validatedUser.email,
        id: validatedUser.id,
        role: validatedUser.role,
        iat: new Date().getTime(),
      },
      input.remember ? tokenExpirationTime?.extended : tokenExpirationTime?.normal,
    )

    if (validatedUser.role === UserRole.HOST) {
      await this.stripeBusinessService.checkBusinessAccountCreated({ user: validatedUser })
    }

    if (validatedUser.role === UserRole.GUEST) {
      await this.stripeCustomerService.checkCustomerAccountCreated({ user: validatedUser })
    }

    this.jwtTokenService.setTokenToCookie(ctx.res, authToken)

    return { authToken }
  }

  public async socialSignIn(
    input: SocialSignInInput,
    ctx: ContextServer,
  ): Promise<AuthTokenInterface> {
    const socialAuthVariants = [
      {
        type: AuthType.GOOGLE,
        get: async () => {
          const response = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
            headers: {
              Authorization: `Bearer ${input.token}`,
            },
          })

          if (!response.ok) {
            throw new BadRequestException('Failed to fetch user info from Google API')
          }

          const userPayload: {
            picture: string
            email: string
            given_name: string | null | undefined
            name: string | null | undefined
            family_name: string | null | undefined
            sub: string
          } = await response.json()

          return {
            profileImage: userPayload.picture,
            email: userPayload.email,
            firstName: userPayload.given_name ?? userPayload.name ?? '',
            lastName: userPayload.family_name ?? '',
            password: userPayload.sub,
            authType: AuthType.GOOGLE,
          }
        },
      },
      {
        type: AuthType.APPLE,
        get: async () => {
          const user = await this.socialAuthService.verifyAppleIdToken(input.token)
          const userName = input.displayName?.trim().split(' ')

          return {
            email: user.email,
            firstName: userName?.[0] ?? user.firstname,
            lastName: userName?.[1] ?? user.lastname,
            password: user.sub,
            authType: AuthType.APPLE,
          }
        },
      },
    ]

    const socialUserData = await socialAuthVariants
      .find((item) => item.type === input.authType)
      ?.get()

    if (!socialUserData) {
      throw new BadRequestException(
        `Couldn't recieve the social user data for auth type ${input.authType}`,
      )
    }

    const socialUser: {
      email: string
      profileImage?: string
      firstName: string
      lastName: string
      password: string
      authType: AuthType
    } = socialUserData

    const fluxoUser = await this.usersService.findUnique(socialUser.email)

    if (!fluxoUser && !input.userRole) {
      throw new ForbiddenException('You are not registered. Please sign up to proceed.')
    }

    let token = ''

    // Create a new user if social user signs in for the first time
    if (!fluxoUser) {
      if (!input.userRole) {
        throw new BadRequestException('User role is required for sign up')
      }

      const newUser = await this.usersService.create({
        email: socialUser.email,
        password: socialUser.password,
        role: input.userRole,
        authType: input.authType,
        firstName: socialUser.firstName,
        lastName: socialUser.lastName,
      })

      token = await this.jwtTokenService.createToken(
        {
          id: newUser.id,
          email: newUser.email,
          role: newUser.role,
          remember: true,
        },
        this.configService.get('app.tokenExpirationTime.extended', { infer: true }),
      )
      // If user already exists, verify that it's the user that was created via the social login
    } else {
      const passwordsMatch = this.passwordService.comparePassword(
        socialUser.password,
        fluxoUser.password,
      )

      if (!passwordsMatch) {
        throw new BadRequestException(`A user with this email already exists in fluxo's system`)
      }

      token = await this.jwtTokenService.createToken(
        {
          id: fluxoUser.id,
          email: fluxoUser.email,
          role: fluxoUser.role,
          remember: true,
        },
        this.configService.get('app.tokenExpirationTime.extended', { infer: true }),
      )
    }

    if (fluxoUser && fluxoUser.role === UserRole.HOST) {
      await this.stripeBusinessService.checkBusinessAccountCreated({ user: fluxoUser })
    }
    if (fluxoUser && fluxoUser.role === UserRole.GUEST) {
      await this.stripeCustomerService.checkCustomerAccountCreated({ user: fluxoUser })
    }

    this.jwtTokenService.setTokenToCookie(ctx.res, token)

    return { authToken: token }
  }

  public async signUp(input: SignUpInput): Promise<void> {
    const userExists = await this.usersService.userExists(input.email)

    if (userExists) {
      throw new ForbiddenException('User with this email already exists')
    }

    const user = await this.usersService.create(input)

    await this.sendVerificationCode(user.email)
  }

  public async sendVerificationCode(email: string, isSignUp = true): Promise<void> {
    const userExists = await this.usersService.userExists(email)

    if (!userExists) {
      throw new UnauthorizedException("User with this email doesn't exist")
    }

    const emailVerificationCode = this.usersService.generateVerificationCode()

    // Send email verification code to the user's email > hash it and save in DB
    await this.emailService.sendVerificationCode(email, emailVerificationCode, isSignUp)
    await this.usersService.updateVerificationCode(email, emailVerificationCode)
  }

  public logout(ctx: ContextServer): void {
    this.jwtTokenService.clearTokenFromCookie(ctx.res)
  }

  public async resetPassword(input: ResetPasswordInput): Promise<void> {
    const verifiedToken = await this.jwtTokenService.verifyToken(input.token)
    const user = await this.usersService.findUnique(verifiedToken.email)

    if (!user) {
      throw new UnauthorizedException(`User is not found.`)
    }

    await this.updateUserPassword(user.id, input.newPassword)

    await this.clearActiveSessions(user.email)
  }

  public async verifyCode(input: VerifyCodeInput, ctx: ContextServer): Promise<AuthTokenInterface> {
    const user = await this.usersService.findUnique(input.email)

    if (!user) {
      throw new UnauthorizedException(`User with the email ${input.email} is not found.`)
    }

    const codesMatch = this.passwordService.comparePassword(
      input.verificationCode,
      user.verificationCode ?? '',
    )

    if (!codesMatch) {
      throw new UnauthorizedException('The verification code is not correct')
    }

    await this.usersService.update({
      where: { id: user.id },
      data: { emailVerified: true, verificationCode: null },
    })

    const authToken = await this.jwtTokenService.createToken({
      email: user.email,
      id: user.id,
      role: user.role,
      iat: new Date().getTime(),
    })

    if (!input.withCookieAuth) return { authToken }

    this.jwtTokenService.setTokenToCookie(ctx.res, authToken)

    return { authToken }
  }

  private async updateUserPassword(userId: string, newPassword: string): Promise<void> {
    await this.usersService.update({
      where: { id: userId },
      data: {
        password: this.passwordService.hashPassword(newPassword),
      },
    })
  }

  private async clearActiveSessions(email: string): Promise<void> {
    const user = await this.usersService.findUnique(email, { id: true })

    if (!user) {
      throw new UnauthorizedException(`User with the email ${email} is not found.`)
    }

    await this.usersService.update({
      where: { id: user.id },
      data: {
        tokenExpiryThreshold: new Date(),
      },
    })
  }
}
