import { UseGuards } from '@nestjs/common'
import { Args, Context, Mutation, Resolver } from '@nestjs/graphql'
import { UserRole } from '@prisma/client'

import { CurrentUserDetails } from '@/common/decorators/current-user-details.decorator'
import { ErrorGraphqlHandlingDecorator } from '@/common/decorators/error-graphql-handling.decorator'
import { Roles } from '@/common/decorators/roles.decorator'
import { JwtAuthGuard } from '@/common/guards/jwt-auth.guard'
import { RolesGuard } from '@/common/guards/roles.guard'
import { AuthTokenInterface } from '@/common/interfaces/auth-token.interface'
import { MessageInterfaceEntity } from '@/common/interfaces/message.interface'
import { ContextServer } from '@/common/services/graphql/graphql.module'
import { JwtTokenPayload } from '@/common/services/jwt-token/jwt-token.service'
import { AuthService } from '@/resources/auth/auth.service'
import { ChangePasswordInput } from '@/resources/auth/dto/change-password.input'
import { ResetPasswordInput } from '@/resources/auth/dto/reset-password.input'
import { SendVerificationCodeInput } from '@/resources/auth/dto/send-verification-code.input'
import { SignInInput } from '@/resources/auth/dto/sign-in.input'
import { SignUpInput } from '@/resources/auth/dto/sign-up.input'
import { SocialSignInInput } from '@/resources/auth/dto/social-sign-in.input'
import { VerifyCodeInput } from '@/resources/auth/dto/verify-code.input'

@Resolver(() => MessageInterfaceEntity)
export class AuthResolver {
  constructor(private readonly authService: AuthService) {}

  @Mutation(() => AuthTokenInterface)
  @ErrorGraphqlHandlingDecorator(AuthResolver.name)
  async signIn(
    @Args('input') input: SignInInput,
    @Context() ctx: ContextServer,
  ): Promise<AuthTokenInterface> {
    return await this.authService.signIn(input, ctx)
  }

  @Mutation(() => MessageInterfaceEntity)
  @ErrorGraphqlHandlingDecorator(AuthResolver.name)
  async signUp(@Args('input') input: SignUpInput): Promise<MessageInterfaceEntity> {
    await this.authService.signUp(input)

    return { message: 'Sign Up completed' }
  }

  @Roles(UserRole.GUEST, UserRole.HOST)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Mutation(() => MessageInterfaceEntity)
  @ErrorGraphqlHandlingDecorator(AuthResolver.name)
  async changePassword(
    @Args('input') input: ChangePasswordInput,
    @CurrentUserDetails() userDetails: JwtTokenPayload,
  ): Promise<MessageInterfaceEntity> {
    await this.authService.changePassword(input, userDetails)

    return { message: 'Password changed successfully' }
  }

  @Mutation(() => MessageInterfaceEntity)
  @ErrorGraphqlHandlingDecorator(AuthResolver.name)
  async sendForgotPassword(
    @Args('input') input: SendVerificationCodeInput,
  ): Promise<MessageInterfaceEntity> {
    await this.authService.sendVerificationCode(input.email, false)

    return { message: 'Email sent' }
  }

  @Mutation(() => MessageInterfaceEntity)
  @ErrorGraphqlHandlingDecorator(AuthResolver.name)
  async resetPassword(@Args('input') input: ResetPasswordInput): Promise<MessageInterfaceEntity> {
    await this.authService.resetPassword(input)

    return { message: 'Reset successful' }
  }

  @Mutation(() => AuthTokenInterface)
  @ErrorGraphqlHandlingDecorator(AuthResolver.name)
  socialSignIn(
    @Args('input') input: SocialSignInInput,
    @Context() ctx: ContextServer,
  ): Promise<AuthTokenInterface> {
    return this.authService.socialSignIn(input, ctx)
  }

  @Mutation(() => MessageInterfaceEntity)
  @ErrorGraphqlHandlingDecorator(AuthResolver.name)
  async sendVerificationCode(
    @Args('input') input: SendVerificationCodeInput,
  ): Promise<MessageInterfaceEntity> {
    await this.authService.sendVerificationCode(input.email)

    return { message: 'Verification code is sent' }
  }

  @Mutation(() => MessageInterfaceEntity)
  @ErrorGraphqlHandlingDecorator(AuthResolver.name)
  logout(@Context() ctx: ContextServer): MessageInterfaceEntity {
    this.authService.logout(ctx)

    return { message: 'Logout completed' }
  }

  @Mutation(() => AuthTokenInterface)
  @ErrorGraphqlHandlingDecorator(AuthResolver.name)
  async verifyCode(
    @Args('input') input: VerifyCodeInput,
    @Context() ctx: ContextServer,
  ): Promise<AuthTokenInterface> {
    return await this.authService.verifyCode(input, ctx)
  }
}
