import { Field, ObjectType } from '@nestjs/graphql'

@ObjectType()
export class PresignedUrlEntity {
  @Field()
  presignedUrl: string

  @Field()
  fileUrl: string
}
