import { UseGuards } from '@nestjs/common'
import { Args, Query, Resolver } from '@nestjs/graphql'

import { ErrorGraphqlHandlingDecorator } from '@/common/decorators/error-graphql-handling.decorator'
import { JwtAuthGuard } from '@/common/guards/jwt-auth.guard'
import { AWSService } from '@/common/services/integrations/aws/aws.service'
import { GetPresignedUrlInput } from '@/resources/images/dto/get-presigned-url.input'
import { PresignedUrlEntity } from '@/resources/images/entities/presigned-url.entity'

@UseGuards(JwtAuthGuard)
@Resolver(() => PresignedUrlEntity)
export class PresignedUrlResolver {
  constructor(private readonly awsService: AWSService) {}

  @Query(() => PresignedUrlEntity)
  @ErrorGraphqlHandlingDecorator(PresignedUrlResolver.name)
  async presignedUrl(@Args('input') input: GetPresignedUrlInput): Promise<PresignedUrlEntity> {
    return await this.awsService.generatePresignedUrl(input.key, input.type)
  }
}
