import { Field, InputType } from '@nestjs/graphql'
import { IsNotEmpty } from 'class-validator'

@InputType()
export class GetPresignedUrlInput {
  @IsNotEmpty()
  @Field()
  key: string

  @IsNotEmpty()
  @Field()
  type: string
}
