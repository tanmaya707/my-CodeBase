import { UseGuards } from '@nestjs/common'
import { Args, Mutation, Query, Resolver } from '@nestjs/graphql'
import { Prisma, UserRole } from '@prisma/client'

import { CurrentUserDetails } from '@/common/decorators/current-user-details.decorator'
import { ErrorGraphqlHandlingDecorator } from '@/common/decorators/error-graphql-handling.decorator'
import { RequestedFieldsDecorator } from '@/common/decorators/requested-fields.decorator'
import { Roles } from '@/common/decorators/roles.decorator'
import { JwtAuthGuard } from '@/common/guards/jwt-auth.guard'
import { RolesGuard } from '@/common/guards/roles.guard'
import { MessageInterfaceEntity } from '@/common/interfaces/message.interface'
import { TotalInterface } from '@/common/interfaces/total.interface'
import { PaginatedSelect } from '@/common/pagination-utils'
import { JwtTokenPayload } from '@/common/services/jwt-token/jwt-token.service'
import { NotificationEntity } from '@/resources/notifications/entities/notification.entity'
import { NotificationsEntity } from '@/resources/notifications/entities/notifications.entity'

import { MarkAsReadInput } from './dto/mark-as-read.input'
import { NotificationsInput } from './dto/notifications.input'
import { NotificationsService } from './notifications.service'

@Resolver(() => NotificationEntity)
export class NotificationsResolver {
  constructor(private readonly notificationsService: NotificationsService) {}

  @Roles(UserRole.GUEST, UserRole.HOST)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Mutation(() => MessageInterfaceEntity)
  @ErrorGraphqlHandlingDecorator(NotificationsResolver.name)
  markAsRead(
    @Args('input') input: MarkAsReadInput,
    @CurrentUserDetails() userDetails: JwtTokenPayload,
  ): Promise<MessageInterfaceEntity> {
    return this.notificationsService.markAsRead({ input, userDetails })
  }

  @Roles(UserRole.GUEST, UserRole.HOST)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Mutation(() => MessageInterfaceEntity)
  @ErrorGraphqlHandlingDecorator(NotificationsResolver.name)
  markAllAsRead(
    @CurrentUserDetails() userDetails: JwtTokenPayload,
  ): Promise<MessageInterfaceEntity> {
    return this.notificationsService.markAllAsRead({ userDetails })
  }

  @Roles(UserRole.GUEST, UserRole.HOST)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Query(() => NotificationsEntity)
  @ErrorGraphqlHandlingDecorator(NotificationsResolver.name)
  notifications(
    @Args('input') input: NotificationsInput,
    @CurrentUserDetails() userDetails: JwtTokenPayload,
    @RequestedFieldsDecorator() select: PaginatedSelect<Prisma.NotificationSelect>,
  ): Promise<NotificationsEntity> {
    return this.notificationsService.findMany(input, userDetails, select)
  }

  @Roles(UserRole.GUEST, UserRole.HOST)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Query(() => TotalInterface)
  @ErrorGraphqlHandlingDecorator(NotificationsResolver.name)
  unreadNotificationsCount(
    @CurrentUserDetails() userDetails: JwtTokenPayload,
  ): Promise<TotalInterface> {
    return this.notificationsService.findCount(userDetails)
  }
}
