export class HostBookingEvent {
  public userId: string
  public bookingPassId: string
  public bookingConfirmationNumber: string
  public groupId: string | null | undefined
  public guestId: string | null | undefined
  public guestLogo: string | null

  constructor(
    userId: string,
    bookingPassId: string,
    bookingConfirmationNumber: string,
    groupId: string | null | undefined,
    guestId?: string | null | undefined,
    guestLogo: string | null = null,
  ) {
    this.userId = userId
    this.bookingPassId = bookingPassId
    this.bookingConfirmationNumber = bookingConfirmationNumber
    this.groupId = groupId
    this.guestId = guestId
    this.guestLogo = guestLogo
  }
}
