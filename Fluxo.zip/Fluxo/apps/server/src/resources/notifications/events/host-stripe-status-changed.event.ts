export class HostStripeStatusChangedEvent {
  public userId: string
  public kycStatus: string

  constructor(userId: string, kycStatus: string) {
    this.userId = userId
    this.kycStatus = kycStatus
  }
}
