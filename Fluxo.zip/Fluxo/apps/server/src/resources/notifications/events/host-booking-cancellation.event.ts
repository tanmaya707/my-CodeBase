import { HostBookingEvent } from '@/resources/notifications/events/host-booking.event'

export class HostBookingCancellationEvent extends HostBookingEvent {}
