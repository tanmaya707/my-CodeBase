import { Field, ObjectType } from '@nestjs/graphql'
import { IsOptional } from 'class-validator'

import { GuestEntity } from '@/resources/guests/entities/guest.entity'
import { HostEntity } from '@/resources/hosts/entities/host.entity'
import { NotificationInterface } from '@/resources/notifications/interfaces/notification.interface'

@ObjectType({
  implements: () => [NotificationInterface],
})
export class NotificationEntity extends NotificationInterface {
  @IsOptional()
  @Field(() => HostEntity, { nullable: true })
  host?: HostEntity | null

  @IsOptional()
  @Field(() => GuestEntity, { nullable: true })
  guest?: GuestEntity | null
}
