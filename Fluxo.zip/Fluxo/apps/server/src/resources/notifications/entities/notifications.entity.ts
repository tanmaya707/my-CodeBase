import { Field, ObjectType } from '@nestjs/graphql'

import { PaginationInterfaceEntity } from '@/common/interfaces/pagination.inteface'

import { NotificationEntity } from './notification.entity'

@ObjectType()
class NotificationsPaginationEntity extends PaginationInterfaceEntity {}

@ObjectType()
export class NotificationsEntity {
  @Field(() => [NotificationEntity])
  readonly data: NotificationEntity[]

  @Field(() => NotificationsPaginationEntity)
  readonly pagination: NotificationsPaginationEntity
}
