import { Field, ID, InterfaceType, registerEnumType } from '@nestjs/graphql'
import { Notification, NotificationType, UserRole } from '@prisma/client'
import { JsonValue } from '@prisma/client/runtime/library'
import { IsNotEmpty, IsOptional } from 'class-validator'
import { GraphQLJSON } from 'graphql-type-json'

registerEnumType(NotificationType, {
  name: 'NotificationType',
})

@InterfaceType()
export abstract class NotificationInterface implements Notification {
  @IsNotEmpty()
  @Field(() => ID)
  id: string

  @IsNotEmpty()
  @Field(() => UserRole)
  recipientRole: UserRole

  @IsNotEmpty()
  @Field(() => NotificationType)
  type: NotificationType

  @IsNotEmpty()
  @Field()
  title: string

  @IsNotEmpty()
  @Field()
  message: string

  @IsNotEmpty()
  @Field()
  htmlMessage: string

  @IsNotEmpty()
  @Field()
  expoPushToken: string

  @IsOptional()
  @Field(() => GraphQLJSON, { nullable: true })
  metadata: JsonValue | null

  @IsNotEmpty()
  @Field()
  isRead: boolean

  @IsOptional()
  @Field(() => String, { nullable: true })
  guestId: string | null

  @IsOptional()
  @Field(() => String, { nullable: true })
  hostId: string | null

  @IsNotEmpty()
  @Field()
  createdAt: Date

  @IsNotEmpty()
  @Field()
  updatedAt: Date
}
