import { Logger } from '@nestjs/common'
import {
  MessageBody,
  OnGatewayConnection,
  SubscribeMessage,
  WebSocketGateway,
  WebSocketServer,
} from '@nestjs/websockets'
import { Server, Socket } from 'socket.io'

import { NotificationEntity } from '@/resources/notifications/entities/notification.entity'

@WebSocketGateway({
  cors: {
    origin: process.env.NEXT_PUBLIC_WEB_APP_URL,
  },
})
export class NotificationsGateway implements OnGatewayConnection {
  @WebSocketServer()
  server: Server
  private logger = new Logger()

  handleConnection(client: Socket): void {
    this.logger.log(`WS client connected: ${client.id}`)
  }

  handleDisconnect(client: Socket): void {
    this.logger.log(`WS client disconnected: ${client.id}`)
  }

  @SubscribeMessage('notifications')
  handleNotification(@MessageBody() data: any) {
    this.logger.log(`Notification received: ${data}`)
  }

  sendAsync(notification: NotificationEntity) {
    this.server.emit('notifications', notification)
  }
}
