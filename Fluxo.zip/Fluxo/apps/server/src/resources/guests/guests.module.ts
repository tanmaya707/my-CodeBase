import { forwardRef, Module } from '@nestjs/common'

// eslint-disable-next-line import/no-cycle -- fixed with forwardRef
import { StripeCustomersModule } from '@/common/services/integrations/stripe/customers/stripe-customers.module'
import { GuestsResolver } from '@/resources/guests/guests.resolver'
import { GuestsService } from '@/resources/guests/guests.service'
import { PropertiesModule } from '@/resources/properties/properties.module'
import { UsersModule } from '@/resources/users/users.module'

@Module({
  imports: [
    UsersModule,
    forwardRef(() => PropertiesModule),
    forwardRef(() => StripeCustomersModule),
  ],
  providers: [GuestsService, GuestsResolver],
  exports: [GuestsService],
})
export class GuestsModule {}
