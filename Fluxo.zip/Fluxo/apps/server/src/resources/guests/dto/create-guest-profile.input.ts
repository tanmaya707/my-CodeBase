import { Field, InputType, OmitType } from '@nestjs/graphql'
import { IsNotEmpty, IsOptional } from 'class-validator'

import { LocationInput } from '@/resources/properties/dto/location.input'

import { GuestEntity } from '../entities/guest.entity'

@InputType()
export class CreateGuestProfileInput extends OmitType(
  GuestEntity,
  ['id', 'userId', 'location'],
  InputType,
) {
  @IsNotEmpty()
  @Field()
  firstName: string

  @IsNotEmpty()
  @Field()
  lastName: string

  @IsOptional()
  @Field(() => LocationInput)
  location: LocationInput
}
