import { Field, ObjectType } from '@nestjs/graphql'
import { IsOptional } from 'class-validator'

import { GuestEntity } from '@/resources/guests/entities/guest.entity'
import { UserInterface } from '@/resources/users/interfaces/user.interface'

@ObjectType({
  implements: () => [UserInterface],
})
export class GuestUserEntity extends UserInterface {
  @IsOptional()
  @Field(() => GuestEntity, { nullable: true })
  guest?: GuestEntity | null
}
