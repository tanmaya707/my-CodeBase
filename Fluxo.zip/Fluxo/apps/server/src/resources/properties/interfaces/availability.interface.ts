import { Field, ID, InterfaceType, registerEnumType } from '@nestjs/graphql'
import { Availability, DayOfWeek } from '@prisma/client'
import { IsNotEmpty, IsOptional, Matches } from 'class-validator'

import { availabilityTimeFormatRegex } from '@/common/utils'

registerEnumType(DayOfWeek, {
  name: 'DayOfWeek',
})

@InterfaceType()
export abstract class AvailabilityInterface implements Availability {
  @IsNotEmpty()
  @Field(() => ID)
  id: string

  @IsOptional()
  @Matches(availabilityTimeFormatRegex, {
    message: 'Availability time must be in the format "HH:MM AM|PM"',
  })
  @Field(() => String, { nullable: true })
  from: string | null

  @IsOptional()
  @Matches(availabilityTimeFormatRegex, {
    message: 'Availability time must be in the format "HH:MM AM|PM"',
  })
  @Field(() => String, { nullable: true })
  to: string | null

  @IsNotEmpty()
  @Field(() => DayOfWeek)
  dayOfWeek: DayOfWeek

  @IsOptional()
  @Field(() => ID, { nullable: true })
  propertyId: string | null

  @IsOptional()
  @Field(() => ID, { nullable: true })
  dayPassId: string | null

  @IsOptional()
  @Field(() => ID, { nullable: true })
  spaceId: string | null
}
