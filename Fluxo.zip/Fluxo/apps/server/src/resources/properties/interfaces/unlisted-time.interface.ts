import { Field, ID, InterfaceType } from '@nestjs/graphql'
import { UnlistedTime } from '@prisma/client'
import { IsNotEmpty, IsOptional, Matches } from 'class-validator'

import { availabilityTimeFormatRegex } from '@/common/utils'

@InterfaceType()
export abstract class UnlistedTimeInterface implements UnlistedTime {
  @IsNotEmpty()
  @Field(() => ID)
  id: string

  @IsNotEmpty()
  @Matches(availabilityTimeFormatRegex, {
    message: 'Unlisted time must be in the format "HH:MM AM|PM"',
  })
  @Field(() => String)
  from: string

  @IsNotEmpty()
  @Matches(availabilityTimeFormatRegex, {
    message: 'Unlisted time must be in the format "HH:MM AM|PM"',
  })
  @Field(() => String)
  to: string

  @IsNotEmpty()
  @Field(() => Date)
  date: Date

  @IsOptional()
  @Field(() => ID, { nullable: true })
  spaceId: string | null
}
