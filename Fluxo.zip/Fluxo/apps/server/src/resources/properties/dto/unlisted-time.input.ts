import { InputType, PickType } from '@nestjs/graphql'

import { UnlistedTimeEntity } from '@/resources/properties/entities/unlisted-time.entity'

@InputType()
export class UnlistedTimeInput extends PickType(
  UnlistedTimeEntity,
  ['date', 'from', 'to'],
  InputType,
) {}
