import { Field, ID, InputType, PickType } from '@nestjs/graphql'
import { Type } from 'class-transformer'
import { IsNotEmpty, IsOptional, ValidateNested } from 'class-validator'

import { AvailabilityInput } from '@/resources/properties/dto/availability.input'
import { UnlistedTimeInput } from '@/resources/properties/dto/unlisted-time.input'
import { SpaceEntity } from '@/resources/properties/entities/space.entity'

@InputType()
export class SpacesInput extends PickType(
  SpaceEntity,
  ['capacity', 'name', 'description', 'hourlyCost', 'dailyCost', 'manualBookingApproval', 'images'],
  InputType,
) {
  @IsNotEmpty()
  @ValidateNested({ each: true })
  @Type(() => AvailabilityInput)
  @Field(() => [AvailabilityInput])
  availability: AvailabilityInput[]

  @IsNotEmpty()
  @ValidateNested({ each: true })
  @Type(() => UnlistedTimeInput)
  @Field(() => [UnlistedTimeInput])
  unlistedTime: UnlistedTimeInput[]

  @IsOptional()
  @Field(() => [ID], { nullable: true })
  attributeIds?: string[] | null
}
