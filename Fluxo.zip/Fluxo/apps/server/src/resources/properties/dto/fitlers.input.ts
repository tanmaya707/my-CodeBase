import { Field, ID, InputType, registerEnumType } from '@nestjs/graphql'
import { IsNotEmpty, IsOptional } from 'class-validator'

import { BookingType, PriceRange } from '@/common/enums'

registerEnumType(BookingType, {
  name: 'BookingType',
})

registerEnumType(PriceRange, {
  name: 'PriceRange',
})

@InputType()
export class FiltersInput {
  @IsNotEmpty()
  @Field(() => [BookingType], { nullable: true })
  bookingType: BookingType[]

  @IsNotEmpty()
  @Field({ defaultValue: 10 })
  distance: number

  @IsOptional()
  @Field(() => [ID], { nullable: true, defaultValue: [] })
  attributeIds?: string[]

  @IsOptional()
  @Field(() => [PriceRange], { nullable: true })
  priceRange: PriceRange[]

  @IsOptional()
  @Field({ nullable: true })
  name?: string

  @IsOptional()
  @Field({ nullable: true })
  date?: Date

  @IsOptional()
  @Field({ defaultValue: 1 })
  capacity?: number

  @IsOptional()
  @Field({ nullable: true })
  timeStart?: string
}
