import { Field, InputType, PickType } from '@nestjs/graphql'
import { Type } from 'class-transformer'
import { IsNotEmpty, ValidateNested } from 'class-validator'

import { AvailabilityInput } from '@/resources/properties/dto/availability.input'
import { DayPassEntity } from '@/resources/properties/entities/day-pass.entity'

@InputType()
export class DayPassInput extends PickType(DayPassEntity, ['dailyCost', 'quantity'], InputType) {
  @IsNotEmpty()
  @ValidateNested({ each: true })
  @Type(() => AvailabilityInput)
  @Field(() => [AvailabilityInput])
  availability: AvailabilityInput[]
}
