import { InputType, PickType } from '@nestjs/graphql'

import { LocationWithCoordinatesEntity } from '@/resources/properties/entities/location.entity'

@InputType()
export class GetLocationInput extends PickType(
  LocationWithCoordinatesEntity,
  ['guestId', 'hostId', 'propertyId'],
  InputType,
) {}
