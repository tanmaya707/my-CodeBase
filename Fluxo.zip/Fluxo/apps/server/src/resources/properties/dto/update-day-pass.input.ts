import { Field, ID, InputType, PartialType, PickType } from '@nestjs/graphql'
import { Type } from 'class-transformer'
import { IsNotEmpty, IsOptional, ValidateNested } from 'class-validator'

import { AvailabilityInput } from '@/resources/properties/dto/availability.input'
import { DayPassEntity } from '@/resources/properties/entities/day-pass.entity'

@InputType()
export class UpdateDayPassInput extends PartialType(
  PickType(DayPassEntity, ['quantity', 'dailyCost'], InputType),
) {
  @IsNotEmpty()
  @Field(() => ID)
  id: string

  @IsOptional()
  @ValidateNested({ each: true })
  @Type(() => AvailabilityInput)
  @Field(() => [AvailabilityInput], { nullable: true })
  availability?: AvailabilityInput[]
}
