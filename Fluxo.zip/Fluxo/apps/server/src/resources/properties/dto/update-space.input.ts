import { Field, ID, InputType, PartialType, PickType } from '@nestjs/graphql'
import { Type } from 'class-transformer'
import { IsNotEmpty, IsOptional, ValidateNested } from 'class-validator'

import { AvailabilityInput } from '@/resources/properties/dto/availability.input'
import { UnlistedTimeInput } from '@/resources/properties/dto/unlisted-time.input'
import { SpaceEntity } from '@/resources/properties/entities/space.entity'

@InputType()
export class UpdateSpaceInput extends PartialType(
  PickType(
    SpaceEntity,
    [
      'manualBookingApproval',
      'hourlyCost',
      'description',
      'name',
      'capacity',
      'dailyCost',
      'images',
    ],
    InputType,
  ),
) {
  @IsNotEmpty()
  @Field(() => ID)
  id: string

  @IsOptional()
  @ValidateNested({ each: true })
  @Type(() => AvailabilityInput)
  @Field(() => [AvailabilityInput], { nullable: true })
  availability?: AvailabilityInput[] | null

  @IsOptional()
  @ValidateNested({ each: true })
  @Type(() => UnlistedTimeInput)
  @Field(() => [UnlistedTimeInput], { nullable: true })
  unlistedTime?: UnlistedTimeInput[] | null

  @IsOptional()
  @Field(() => [ID], { nullable: true })
  attributeIds?: string[] | null
}
