import { Field, InputType, registerEnumType } from '@nestjs/graphql'
import { IsNotEmpty, IsOptional } from 'class-validator'

import { PropertiesSort } from '@/common/enums'
import { FiltersInput } from '@/resources/properties/dto/fitlers.input'

registerEnumType(PropertiesSort, {
  name: 'PropertiesSort',
})

@InputType()
export class SearchInput {
  @IsOptional()
  @Field({ nullable: true })
  coordinates: string

  @IsNotEmpty()
  @Field(() => FiltersInput)
  filters: FiltersInput

  @IsOptional()
  @Field(() => PropertiesSort, { defaultValue: PropertiesSort.DISTANCE })
  sort: PropertiesSort

  @IsOptional()
  @Field(() => Boolean, { nullable: true })
  topRated: boolean
}
