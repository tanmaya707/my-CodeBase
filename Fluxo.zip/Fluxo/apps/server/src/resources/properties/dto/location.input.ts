import { Field, InputType, PickType } from '@nestjs/graphql'
import { IsNotEmpty, IsOptional } from 'class-validator'

import { LocationEntity } from '@/resources/properties/entities/location.entity'

@InputType()
export class LocationInput extends PickType(LocationEntity, ['address'], InputType) {
  @IsNotEmpty()
  @Field()
  coordinates: string
}

@InputType()
export class LocationWithLatLngInput extends LocationInput {
  @IsOptional()
  @Field(() => Number, { nullable: true })
  latitude: number | null

  @IsOptional()
  @Field(() => Number, { nullable: true })
  longitude: number | null
}
