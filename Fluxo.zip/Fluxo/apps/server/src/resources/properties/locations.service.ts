import { Injectable } from '@nestjs/common'
import { Prisma, PrismaClient } from '@prisma/client'
import { ITXClientDenyList } from '@prisma/client/runtime/library'

import { PrismaService } from '@/common/services/prisma/prisma.service'
import { LocationInput } from '@/resources/properties/dto/location.input'
import { LocationWithCoordinatesEntity } from '@/resources/properties/entities/location.entity'

@Injectable()
export class LocationsService {
  constructor(private readonly prismaService: PrismaService) {}

  public create(
    locationInput: LocationInput,
    relation: { propertyId?: string; guestId?: string; hostId?: string },
    prisma: Omit<PrismaClient, ITXClientDenyList>,
  ): Promise<Location | null> {
    return prisma.$queryRaw(Prisma.sql`
            INSERT INTO "locations" ("id", "address", "coordinates", "property_id", "guest_id", "host_id")
            VALUES (uuid_generate_v4(), ${locationInput.address}, ST_GeomFromText(${locationInput.coordinates}, 4326), ${relation.propertyId}, ${relation.guestId}, ${relation.hostId});
        `)
  }

  public update(
    locationInput: LocationInput,
    relation: { propertyId?: string },
    prisma: Omit<PrismaClient, ITXClientDenyList>,
  ): Promise<Location | null> {
    return prisma.$queryRaw(Prisma.sql`
        UPDATE "locations"
        SET "address"     = ${locationInput.address},
            "coordinates" = ST_GeomFromText(${locationInput.coordinates}, 4326)
        WHERE "property_id" = ${relation.propertyId}
    `)
  }

  public async findUnique({
    propertyId = null,
    guestId = null,
    hostId = null,
  }: {
    propertyId?: string | null
    guestId?: string | null
    hostId?: string | null
  }): Promise<LocationWithCoordinatesEntity | null> {
    const result = await this.prismaService.$queryRaw<LocationWithCoordinatesEntity[]>(Prisma.sql`
            SELECT 
              "id",
              "address",
              ST_AsText("coordinates") AS "coordinates",
              "property_id" as "propertyId",
              "guest_id" as "guestId",
              "host_id" as "hostId"
            FROM "locations"
            WHERE ("property_id" = ${propertyId} OR "guest_id" = ${guestId} OR "host_id" = ${hostId})
            LIMIT 1
        `)

    return result[0]
  }
}
