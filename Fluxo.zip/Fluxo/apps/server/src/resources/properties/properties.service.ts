import { ForbiddenException, Injectable, UnauthorizedException } from '@nestjs/common'
import { EventEmitter2 } from '@nestjs/event-emitter'
import { Attribute, HostStatus, Prisma, PrismaClient, Space } from '@prisma/client'
import { ITXClientDenyList } from '@prisma/client/runtime/library'
import { format, startOfTomorrow } from 'date-fns'
import { merge } from 'es-toolkit'
import { omit } from 'es-toolkit/compat'

import { Events, PropertiesSort } from '@/common/enums'
import { StripeBusinessService } from '@/common/services/integrations/stripe/business/stripe-business.service'
import { JwtTokenPayload } from '@/common/services/jwt-token/jwt-token.service'
import { PrismaService } from '@/common/services/prisma/prisma.service'
import {
  isEmpty,
  isPropertyInactive,
  metersToMiles,
  milesToMeters,
  PriceRangeLimits,
} from '@/common/utils'
import { AvailabilityService } from '@/resources/availability/availability.service'
import { HostsService } from '@/resources/hosts/hosts.service'
import { CreatePropertyInput } from '@/resources/properties/dto/create-property.input'
import { DayPassInput } from '@/resources/properties/dto/day-pass.input'
import { DeleteDayPassInput } from '@/resources/properties/dto/delete-day-pass.input'
import { DeleteSpaceInput } from '@/resources/properties/dto/delete-space.input'
import { GetPropertyInput } from '@/resources/properties/dto/get-property.input'
import { SearchInput } from '@/resources/properties/dto/search.input'
import { SpacesInput } from '@/resources/properties/dto/spaces.input'
import { UpdateDayPassInput } from '@/resources/properties/dto/update-day-pass.input'
import { UpdatePropertyInput } from '@/resources/properties/dto/update-property.input'
import { UpdateSpaceInput } from '@/resources/properties/dto/update-space.input'
import { SpaceEntity } from '@/resources/properties/entities/space.entity'
import { DayPassUpdatedEvent } from '@/resources/properties/events/day-pass-updated.event'
import { PropertyCreatedEvent } from '@/resources/properties/events/property-created.event'
import { SpaceUpdatedEvent } from '@/resources/properties/events/space-updated.event'
import { LocationsService } from '@/resources/properties/locations.service'

const NEW_YORK_CITY_CENTER_COORDINATES = 'POINT(40.76525972362352 -73.97899564823628)'
const MAX_TOP_RATED_ITEMS = 12

@Injectable()
export class PropertiesService {
  constructor(
    private readonly prismaService: PrismaService,
    private readonly eventEmitter: EventEmitter2,
    private readonly hostsService: HostsService,
    private readonly locationsService: LocationsService,
    private readonly availabilityService: AvailabilityService,
    private readonly stripeBusinessService: StripeBusinessService,
  ) {}

  public async findManyAttributes(
    where: Prisma.AttributeWhereInput,
    select?: Prisma.AttributeSelect,
  ): Promise<Attribute[] | null> {
    const attributes = await this.prismaService.attribute.findMany({
      where,
      orderBy: [
        {
          name: 'asc',
        },
      ],
      select: isEmpty(select) ? null : select,
    })
    const attributesThatShouldBeAtTheEnd = attributes.filter((item) => item.name.startsWith('?'))
    const restAttributes = attributes.filter((item) => !item.name.startsWith('?'))

    return [...restAttributes, ...attributesThatShouldBeAtTheEnd]
  }

  public calculateLowestPrice(spaces?: Space[], dayPassDailyCost?: number): number {
    const spacesLowestPrice =
      spaces && spaces.length > 0 ? Math.min(...spaces.map((space) => space.hourlyCost)) : null

    if (dayPassDailyCost) {
      return dayPassDailyCost
    }

    if (spacesLowestPrice) {
      return spacesLowestPrice
    }

    return 0
  }

  private async createDayPass(
    propertyId: string,
    propertyName: string,
    dayPass: DayPassInput,
    prisma: Omit<PrismaClient, ITXClientDenyList>,
  ): Promise<void> {
    const { availability, ...rest } = dayPass

    const dayPassCreated = await prisma.dayPass.create({
      data: {
        property: { connect: { id: propertyId } },
        dailyCost: rest.dailyCost,
        quantity: rest.quantity,
        availability: { createMany: { data: availability } },
      },
    })

    await this.stripeBusinessService.createStripeProduct({
      propertyId,
      name: `${propertyName} - Day Pass`,
      price: dayPassCreated.dailyCost,
    })
  }

  private async createSpaces(
    propertyId: string,
    propertyName: string,
    spaces: SpacesInput[],
    prisma: Omit<PrismaClient, ITXClientDenyList>,
  ): Promise<void> {
    for (const space of spaces) {
      const { availability, attributeIds, unlistedTime, ...rest } = space

      const spaceCreated = await prisma.space.create({
        data: {
          ...rest,
          hourlyCost: rest.hourlyCost,
          dailyCost: rest.dailyCost ? rest.dailyCost : undefined,
          propertyId,
          availability: { createMany: { data: availability } },
          unlistedTime: { createMany: { data: unlistedTime } },
          attributes: {
            connect: attributeIds?.map((attributeId) => ({ id: attributeId })) ?? [],
          },
        },
      })

      await this.stripeBusinessService.createStripeProduct({
        propertyId,
        name: `${propertyName} - Space`,
        price: spaceCreated.dailyCost ?? 0,
        description: spaceCreated.description ?? '',
      })
    }
  }

  public async findUnique(
    input: GetPropertyInput,
    select: Prisma.PropertySelect,
    userDetails?: JwtTokenPayload,
    disableInactiveCheck = false,
  ) {
    const { distanceTo, ...otherFields } = select as Prisma.PropertySelect & { distanceTo: boolean }

    const property = await this.prismaService.property.findUnique({
      where: { id: input.id },
      select: merge({ host: { select: { userId: true, status: true } } }, otherFields),
    })
    const isUserOwnerOfProperty = disableInactiveCheck
      ? true
      : userDetails?.id === property?.host?.userId

    if (!property) {
      return null
    }

    if (!isUserOwnerOfProperty && isPropertyInactive(property.host)) {
      throw new ForbiddenException('Venue is paused or deactivated by host')
    }

    if (distanceTo && input.coordinates) {
      const properties = await this.prismaService.$queryRaw<
        { id: string; distance: string }[]
      >(Prisma.sql`
        SELECT 
          "properties"."id" AS id,
          ST_Distance("locations"."coordinates"::geography, ST_GeomFromText(${input.coordinates}, 4326)::geography) AS distance
        FROM "properties"
        JOIN "locations" ON "locations"."property_id" = "properties"."id"
        WHERE "properties"."id" = ${input.id}
        LIMIT 1
      `)

      const [propertyWithDistance] = properties

      return {
        ...property,
        distanceTo: propertyWithDistance.distance
          ? metersToMiles(parseInt(propertyWithDistance.distance, 10))
          : null,
      }
    }

    return property
  }

  public async create(input: CreatePropertyInput, select: Prisma.PropertySelect, userId: string) {
    const { availability, attributeIds, location, dayPass, spaces, ...rest } = input

    const createdProperty = await this.prismaService.$transaction(async (prisma) => {
      const property = await prisma.property.create({
        data: {
          ...rest,
          host: { connect: { userId } },
          availability: { createMany: { data: availability } },
          attributes: attributeIds
            ? { connect: attributeIds.map((attributeId) => ({ id: attributeId })) }
            : undefined,
        },
        // attributes and neighborhood are required for the event below
        include: { attributes: true },
      })

      if (location) {
        await this.locationsService.create(location, { propertyId: property.id }, prisma)
      }

      if (dayPass) {
        await this.createDayPass(property.id, property.name, dayPass, prisma)
      }

      if (spaces) {
        await this.createSpaces(property.id, property.name, spaces, prisma)
      }

      return property
    })

    const host = await this.hostsService.findUnique(
      { userId },
      { user: { select: { id: true, email: true, emailVerified: true } }, id: true },
    )

    if (host) {
      const businessAccountStatus = await this.stripeBusinessService.checkKYCVerified(userId)

      await this.prismaService.host.update({
        where: { id: host.id },
        data: { status: businessAccountStatus.isVerified ? HostStatus.ACTIVE : HostStatus.PAUSED },
      })

      if (businessAccountStatus.isVerified) {
        this.eventEmitter.emit(
          Events.PROPERTY_CREATED,
          new PropertyCreatedEvent(createdProperty, host.user.email),
        )
      }
    }

    // We are not using the 'create' result because it will not contain select values, and is used only for firing the event
    return this.prismaService.property.findUnique({ where: { id: createdProperty.id }, select })
  }

  public async updateSpace(
    input: UpdateSpaceInput,
    userDetails: JwtTokenPayload,
    select: Prisma.SpaceSelect,
  ) {
    const { availability, attributeIds, unlistedTime, id, ...rest } = input
    const host = await this.hostsService.findUnique(
      { userId: userDetails.id },
      {
        id: true,
      },
    )
    const space = await this.prismaService.space.findUnique({
      where: { id, property: { hostId: host?.id } },
      select: { id: true, attributes: { select: { id: true } } },
    })

    if (!space) {
      throw new UnauthorizedException(
        `Couldn't find the space, or the current user is not the owner of this space`,
      )
    }

    const previousAttributes = space.attributes.map((attr) => ({ id: attr.id }))

    return this.prismaService.space.update({
      where: { id },
      data: {
        ...rest,
        availability: availability
          ? {
              deleteMany: { spaceId: id },
              createMany: { data: availability },
            }
          : undefined,
        unlistedTime: unlistedTime
          ? {
              deleteMany: { spaceId: id },
              createMany: { data: unlistedTime },
            }
          : undefined,
        attributes: attributeIds
          ? {
              disconnect: previousAttributes,
              connect: attributeIds.map((attributeId) => ({ id: attributeId })),
            }
          : undefined,
      },
      select,
    })
  }

  public async deleteSpace(input: DeleteSpaceInput, userDetails: JwtTokenPayload): Promise<void> {
    const host = await this.hostsService.findUnique(
      { userId: userDetails.id },
      {
        id: true,
      },
    )
    const space = await this.prismaService.space.findUnique({
      where: { id: input.id, property: { hostId: host?.id } },
      select: { id: true },
    })

    if (!space) {
      throw new UnauthorizedException(
        `Couldn't find the space, or the current user is not the owner of this space`,
      )
    }

    this.eventEmitter.emit(Events.SPACE_DELETED, new SpaceUpdatedEvent(space.id))

    await this.prismaService.space.delete({ where: { id: input.id } })
  }

  public async addSpace(
    input: SpacesInput,
    userDetails: JwtTokenPayload,
    select: Prisma.SpaceSelect,
  ): Promise<SpaceEntity> {
    const { availability, attributeIds, unlistedTime, ...rest } = input
    const host = await this.hostsService.findUnique(
      { userId: userDetails.id },
      {
        id: true,
      },
    )
    const property = await this.prismaService.property.findUnique({
      where: { hostId: host?.id },
    })

    if (!property) {
      throw new UnauthorizedException(`You can't add space to the property you don't own`)
    }

    const newSpace = await this.prismaService.space.create({
      data: {
        ...rest,
        property: { connect: { id: property.id } },
        availability: { createMany: { data: availability } },
        unlistedTime: { createMany: { data: unlistedTime } },
        attributes: attributeIds
          ? { connect: attributeIds.map((attributeId) => ({ id: attributeId })) }
          : undefined,
      },
      select: merge({ id: true }, select),
    })

    this.eventEmitter.emit(Events.SPACE_ADDED, new SpaceUpdatedEvent(newSpace.id))

    return newSpace
  }

  public async updateDayPass(
    input: UpdateDayPassInput,
    userDetails: JwtTokenPayload,
    select: Prisma.DayPassSelect,
  ) {
    const { availability, id, ...rest } = input
    const host = await this.hostsService.findUnique(
      { userId: userDetails.id },
      {
        id: true,
      },
    )
    const dayPass = await this.prismaService.dayPass.findUnique({
      where: { id, property: { hostId: host?.id } },
      select: { id: true },
    })

    if (!dayPass) {
      throw new UnauthorizedException(
        `Couldn't find the day pass, or the current user is not the owner of this day pass`,
      )
    }

    const updatedDayPass = await this.prismaService.dayPass.update({
      where: { id },
      data: {
        ...rest,
        availability: availability
          ? {
              deleteMany: { dayPassId: id },
              createMany: { data: availability },
            }
          : undefined,
      },
      select,
    })

    this.eventEmitter.emit(Events.DAY_PASS_UPDATED, new DayPassUpdatedEvent(dayPass.id))

    return updatedDayPass
  }

  public async deleteDayPass(
    input: DeleteDayPassInput,
    userDetails: JwtTokenPayload,
  ): Promise<void> {
    const host = await this.hostsService.findUnique(
      { userId: userDetails.id },
      {
        id: true,
      },
    )
    const dayPass = await this.prismaService.dayPass.findUnique({
      where: { id: input.id, property: { hostId: host?.id } },
    })

    if (!dayPass) {
      throw new UnauthorizedException(
        `Couldn't find the day pass, or the current user is not the owner of this day pass`,
      )
    }

    await this.prismaService.dayPass.delete({ where: { id: input.id } })
  }

  public async update(
    input: UpdatePropertyInput,
    userDetails: JwtTokenPayload,
    select: Prisma.PropertySelect,
  ) {
    const { propertyId, availability, attributeIds, location, ...rest } = input
    const host = await this.hostsService.findUnique(
      { userId: userDetails.id },
      {
        user: { select: { email: true } },
        id: true,
      },
    )
    const property = await this.prismaService.property.findUnique({
      where: { id: propertyId, hostId: host?.id },
      select: { id: true, attributes: { select: { id: true } } },
    })

    if (!property) {
      throw new UnauthorizedException(
        `Couldn't find the property, or the current user is not the owner of this property`,
      )
    }

    return this.prismaService.$transaction(async (prisma) => {
      const previousAttributes = property.attributes.map((attr) => ({ id: attr.id }))
      const updatedProperty = await prisma.property.update({
        where: { id: propertyId },
        data: {
          ...rest,
          availability: availability
            ? {
                deleteMany: { propertyId },
                createMany: { data: availability },
              }
            : undefined,
          attributes: attributeIds
            ? {
                disconnect: previousAttributes,
                connect: attributeIds.map((attributeId) => ({ id: attributeId })),
              }
            : undefined,
        },
        select: merge({ id: true, location: false }, omit(select, ['location'])),
      })

      if (location) {
        await this.locationsService.update(location, { propertyId: updatedProperty.id }, prisma)
      }

      this.eventEmitter.emit(Events.PROPERTY_UPDATED, new DayPassUpdatedEvent(property.id))

      return updatedProperty
    })
  }

  public async search(
    input: SearchInput,
    select: Prisma.PropertySelect,
    userId: string | undefined,
  ) {
    let coordinates = input.topRated
      ? NEW_YORK_CITY_CENTER_COORDINATES
      : // eslint-disable-next-line @typescript-eslint/no-unnecessary-condition -- todo test without condition
        (input.coordinates ?? NEW_YORK_CITY_CENTER_COORDINATES)
    const { filters, sort } = input
    const attributeIds =
      filters.attributeIds && filters.attributeIds.length > 0 ? filters.attributeIds : null

    const distance = input.topRated ? 25 : Math.min(filters.distance, 25)

    if (!coordinates && userId) {
      const userCoordinates = await this.prismaService.$queryRaw<{ coordinates: string }[]>`
          SELECT ST_AsText(l.coordinates) AS "coordinates"
          FROM users u
                   LEFT JOIN guests g ON u.id = g.user_id
                   LEFT JOIN locations l ON g.id = l.guest_id
          WHERE u.id = ${userId};
      `

      if (userCoordinates.length > 0) {
        coordinates = userCoordinates[0].coordinates
      }
    }

    const sortCondition = {
      [PropertiesSort.DISTANCE]: Prisma.sql`ORDER BY distance ASC`,
      [PropertiesSort.PRICE]: Prisma.sql`ORDER BY "day_passes"."daily_cost" ASC`,
      [PropertiesSort.RATING]: Prisma.sql`ORDER BY "properties"."score" DESC NULLS LAST`,
    } as Record<PropertiesSort, Prisma.Sql>

    const dayOfWeekFilter = filters.date
      ? Prisma.sql`
        AND "availabilities"."day_of_week" = ${format(new Date(filters.date), 'EEEE').toUpperCase()}::"DayOfWeek"
        AND NOT EXISTS (
          SELECT 1
          FROM unnest("properties"."unlisted_days") AS unlisted_day
          WHERE DATE(unlisted_day) = DATE(${new Date(filters.date).toISOString()}::timestamp)
        )
      `
      : Prisma.empty

    const propertiesDetails = await this.prismaService.$queryRaw<
      { id: string; distance: string; longitude: number; latitude: number }[]
    >(Prisma.sql`
        SELECT DISTINCT 
            "properties"."id"                                             AS id,
            ST_Distance("locations"."coordinates"::geography,
                        ST_GeomFromText(${coordinates}, 4326)::geography) AS distance,
            ST_X("locations"."coordinates")                               AS latitude,
            ST_Y("locations"."coordinates")                               AS longitude,
            "spaces"."name"                                               AS "spaceName",
            "spaces"."hourly_cost"                                        AS "hourlyCost",
            "spaces"."capacity"                                           AS "capacity",
            "day_passes"."daily_cost"                                     AS "dailyCost",
            "day_passes"."quantity"                                       AS "quantity",
            "properties"."name"                                           AS "propertyName",
            "attributes"."name"                                           AS "attributeName",
            "attributes"."type"                                           AS "attributeType",
            "availabilities"."day_of_week"                                AS "dayWeek",
            "availabilities"."from"                                       AS "timeFrom",
            "availabilities"."to"                                         AS "timeTo",
            "properties"."score"                                          AS score
        FROM "locations"
            JOIN "properties" ON "locations"."property_id" = "properties"."id"
            JOIN "availabilities" ON "locations"."property_id" = "availabilities"."property_id"
            JOIN "hosts" ON "hosts"."id" = "properties"."host_id"
            LEFT JOIN "_AttributeToProperty" ON "properties"."id" = "_AttributeToProperty"."B"
            LEFT JOIN "attributes" ON "attributes"."id" = "_AttributeToProperty"."A"
            LEFT JOIN "spaces" ON "spaces"."property_id" = "properties"."id"
            LEFT JOIN "_AttributeToSpace" ON "spaces"."id" = "_AttributeToSpace"."B"
            LEFT JOIN "day_passes" ON "day_passes"."property_id" = "properties"."id"
        WHERE ST_DWithin(
                "locations"."coordinates"::geography,
                ST_GeomFromText(${coordinates}, 4326)::geography,
                ${milesToMeters(distance)}
              )
              ${
                attributeIds && attributeIds.length > 0
                  ? Prisma.sql`
                    AND (
                      (
                        SELECT COUNT(DISTINCT "_AttributeToProperty"."A")
                        FROM "_AttributeToProperty"
                        WHERE "_AttributeToProperty"."B" = "properties"."id"
                          AND "_AttributeToProperty"."A" IN (${Prisma.join(attributeIds)})
                      ) = ${attributeIds.length}
                      OR (
                        SELECT COUNT(DISTINCT "_AttributeToSpace"."A")
                        FROM "_AttributeToSpace"
                        WHERE "_AttributeToSpace"."B" = "spaces"."id"
                          AND "_AttributeToSpace"."A" IN (${Prisma.join(attributeIds)})
                      ) = ${attributeIds.length}
                    )
                  `
                  : Prisma.empty
              }
              ${
                filters.name
                  ? Prisma.sql`
                    AND (
                      ("properties"."name" ILIKE '%' || ${filters.name} || '%') 
                      OR (
                        "attributes"."name" ILIKE '%' || ${filters.name} || '%' 
                        AND ("attributes"."type" = 'PROPERTY_CATEGORY' OR "attributes"."type" = 'PROPERTY_FEATURE')
                      )
                    )
                  `
                  : Prisma.empty
              }
              ${
                filters.priceRange.length > 0
                  ? Prisma.sql`
                    AND (
                      ${Prisma.join(
                        filters.priceRange.map((range) => {
                          const rangeObj = PriceRangeLimits[range]
                          if (rangeObj.max !== null) {
                            return Prisma.sql`
                              (("spaces"."hourly_cost" >= ${rangeObj.min} AND "spaces"."hourly_cost" <= ${rangeObj.max})
                              OR ("day_passes"."daily_cost" >= ${rangeObj.min} AND "day_passes"."daily_cost" <= ${rangeObj.max}))`
                          }
                          return Prisma.sql`
                            ("spaces"."hourly_cost" >= ${rangeObj.min} OR "day_passes"."daily_cost" >= ${rangeObj.min})`
                        }),
                        ' OR ',
                      )}
                    )
                  `
                  : Prisma.empty
              }
              ${input.topRated ? Prisma.empty : dayOfWeekFilter}
              ${
                filters.timeStart && !input.topRated
                  ? Prisma.sql`
                    AND ${filters.timeStart}::time BETWEEN "availabilities"."from"::time AND "availabilities"."to"::time 
                    AND "availabilities"."from"::time <= ${filters.timeStart}::time
                  `
                  : Prisma.empty
              }
              ${
                filters.capacity
                  ? Prisma.sql`AND ("capacity" >= ${filters.capacity} OR "quantity" >= ${filters.capacity})`
                  : Prisma.empty
              }
              AND "properties"."host_id" IS NOT NULL
              AND "hosts"."status" != 'PAUSED'
              ${sortCondition[sort]}
      `)
    const propertyDetailsIds = propertiesDetails.map((el) => el.id)
    const availableProperties = await this.availabilityService.getAvailableProperties({
      propertyIds: propertyDetailsIds,
      date: input.topRated ? startOfTomorrow() : (filters.date ?? startOfTomorrow()),
    })
    const properties = await this.prismaService.property.findMany({
      where: {
        id: { in: input.topRated ? propertyDetailsIds : availableProperties.map(({ id }) => id) },
      },
      // Remove longitude and latitude from select because they don't exist in DB, also exclude lowestPrice and spotsAvailable for the same reason
      select: merge(
        omit(select, [
          'location.select.longitude',
          'location.select.latitude',
          'lowestPrice',
          'availableSpots',
          'distanceTo',
        ]),
        {
          location: { select: { id: true } },
          dayPass: { select: { dailyCost: true, quantity: true } },
          spaces: { select: { hourlyCost: true } },
          score: true,
          createdAt: true,
        },
      ),
      ...(sort === PropertiesSort.PRICE && { orderBy: { dayPass: { dailyCost: 'asc' } } }),
      ...(sort === PropertiesSort.RATING && {
        orderBy: [
          { score: 'desc' }, // Primary sorting by score
          { createdAt: 'desc' }, // Secondary sorting by most recently added
        ],
      }),
      ...(input.topRated && { take: MAX_TOP_RATED_ITEMS }),
    })

    if (sort === PropertiesSort.DISTANCE) {
      const orderMap = propertiesDetails.reduce<Record<string, number>>((acc, item, index) => {
        acc[item.id] = index
        return acc
      }, {})

      return properties
        .sort((a, b) => {
          return orderMap[a.id] - orderMap[b.id]
        })
        .map((property) => {
          const propertyDetails = propertiesDetails.find((el) => el.id === property.id)
          const availableSpots =
            availableProperties.find((availableProperty) => availableProperty.id === property.id)
              ?.availableDayPasses ?? 0

          return merge(property, {
            lowestPrice: this.calculateLowestPrice(property.spaces, property.dayPass?.dailyCost),
            availableSpots,
            distanceTo: propertyDetails?.distance
              ? metersToMiles(parseInt(propertyDetails.distance, 10))
              : null,
            location: {
              latitude: propertyDetails?.latitude ?? null,
              longitude: propertyDetails?.longitude ?? null,
            },
          })
        })
    }

    return properties.map((property) => {
      const propertyDetails = propertiesDetails.find((el) => el.id === property.id)

      return merge(property, {
        lowestPrice: this.calculateLowestPrice(property.spaces, property.dayPass?.dailyCost),
        distanceTo: propertyDetails?.distance
          ? metersToMiles(parseInt(propertyDetails.distance, 10))
          : null,
        location: {
          latitude: propertyDetails?.latitude ?? null,
          longitude: propertyDetails?.longitude ?? null,
        },
      })
    })
  }

  public async topRated(select: Prisma.PropertySelect) {
    const coordinates = NEW_YORK_CITY_CENTER_COORDINATES
    const propertiesDetails = await this.prismaService.$queryRaw<
      { id: string; distance: string; longitude: number; latitude: number }[]
    >(Prisma.sql`
        SELECT DISTINCT "properties"."id"                                             AS id,
                        "properties"."name"                                           AS "propertyName",
                        ST_Distance("locations"."coordinates"::geography,
                                    ST_GeomFromText(${coordinates}, 4326)::geography) AS distance,
                        ST_X("locations"."coordinates")                               AS latitude,
                        ST_Y("locations"."coordinates")                               AS longitude
        FROM "locations"
                 JOIN "properties" ON "locations"."property_id" = "properties"."id"
                 JOIN "hosts" ON "hosts"."id" = "properties"."host_id"
        WHERE "properties"."host_id" IS NOT NULL
        AND "hosts"."status" != 'PAUSED'
    `)
    const propertyDetailsIds = propertiesDetails.map((el) => el.id)
    const availableProperties = await this.availabilityService.getAvailableProperties({
      propertyIds: propertyDetailsIds,
      date: startOfTomorrow(),
    })
    const properties = await this.prismaService.property.findMany({
      where: { id: { in: propertyDetailsIds } },
      // Remove longitude and latitude from select because they don't exist in DB, also exclude lowestPrice for the same reason
      select: merge(
        omit(select, [
          'location.select.longitude',
          'location.select.latitude',
          'lowestPrice',
          'availableSpots',
          'distanceTo',
        ]),
        {
          location: { select: { id: true } },
          dayPass: { select: { dailyCost: true, quantity: true } },
          spaces: { select: { hourlyCost: true } },
          score: true,
          createdAt: true,
        },
      ),
      orderBy: [
        { score: 'desc' }, // Primary sorting by score
        { createdAt: 'desc' }, // Secondary sorting by most recently added
      ],
      take: MAX_TOP_RATED_ITEMS,
    })

    return properties.map((property) => {
      const propertyDetails = propertiesDetails.find((el) => el.id === property.id)
      const availableSpots =
        availableProperties.find((availableProperty) => availableProperty.id === property.id)
          ?.availableDayPasses ?? 0

      return merge(property, {
        lowestPrice: this.calculateLowestPrice(property.spaces, property.dayPass?.dailyCost),
        availableSpots,
        distanceTo: propertyDetails?.distance
          ? metersToMiles(parseInt(propertyDetails.distance, 10))
          : null,
        location: {
          latitude: propertyDetails?.latitude ?? null,
          longitude: propertyDetails?.longitude ?? null,
        },
      })
    })
  }
}
