import { Field, ObjectType } from '@nestjs/graphql'
import { IsOptional } from 'class-validator'

@ObjectType()
export class LowestPriceEntity {
  @IsOptional()
  @Field(() => Number, { nullable: true })
  lowestPrice: number | null
}
