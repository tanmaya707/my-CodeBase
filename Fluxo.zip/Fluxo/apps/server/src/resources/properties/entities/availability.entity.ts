import { ObjectType } from '@nestjs/graphql'

import { AvailabilityInterface } from '@/resources/properties/interfaces/availability.interface'

@ObjectType({
  implements: () => [AvailabilityInterface],
})
export class AvailabilityEntity extends AvailabilityInterface {}
