import { Field, ID, ObjectType, OmitType } from '@nestjs/graphql'
import { Type } from 'class-transformer'
import { IsNotEmpty, IsOptional, ValidateNested } from 'class-validator'

import { HostEntity } from '@/resources/hosts/entities/host.entity'
import { AttributeEntity } from '@/resources/properties/entities/attribute.entity'
import { AvailabilityEntity } from '@/resources/properties/entities/availability.entity'
import { DayPassEntity } from '@/resources/properties/entities/day-pass.entity'
import { LocationWithLatLongEntity } from '@/resources/properties/entities/location.entity'
import { SpaceEntity } from '@/resources/properties/entities/space.entity'
import { PropertyInterface } from '@/resources/properties/interfaces/property.interface'

@ObjectType({
  implements: () => [PropertyInterface],
})
export class PropertyEntity extends PropertyInterface {
  @IsOptional()
  @Field(() => [SpaceEntity], { nullable: true })
  spaces: SpaceEntity[] | null

  @IsOptional()
  @Field(() => DayPassEntity, { nullable: true })
  dayPass: DayPassEntity | null

  @IsOptional()
  @ValidateNested({ each: true })
  @Type(() => AvailabilityEntity)
  @Field(() => [AvailabilityEntity], { nullable: true })
  availability: AvailabilityEntity[] | null

  @IsOptional()
  @Field(() => [AttributeEntity], { nullable: true })
  attributes: AttributeEntity[] | null

  @IsOptional()
  @Field(() => LocationWithLatLongEntity, { nullable: true })
  location?: LocationWithLatLongEntity | null

  @IsOptional()
  @Field(() => Number, { nullable: true })
  distanceTo: number | null
}

@ObjectType()
export class PropertyWithHostEntity extends PropertyEntity {
  @IsOptional()
  @Field(() => HostEntity, { nullable: true })
  host: HostEntity | null
}

@ObjectType()
export class PropertyWithLowestPriceEntity extends PropertyEntity {
  @IsOptional()
  @Field(() => Number, { nullable: true })
  lowestPrice: number | null

  @IsOptional()
  @Field(() => Number, { nullable: true })
  availableSpots: number | null
}

@ObjectType()
export class PropertyWithIdEntity extends PropertyEntity {
  @IsNotEmpty()
  @Field(() => ID)
  id: string
}

@ObjectType({
  implements: () => [PropertyInterface],
})
export class PropertyWithoutLocationEntity extends OmitType(
  PropertyEntity,
  ['location'],
  ObjectType,
) {}
