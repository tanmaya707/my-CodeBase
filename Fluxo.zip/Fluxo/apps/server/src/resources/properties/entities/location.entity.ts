import { Field, ObjectType } from '@nestjs/graphql'
import { IsNotEmpty, IsOptional } from 'class-validator'

import { LocationInterface } from '@/resources/properties/interfaces/location.interface'

@ObjectType({
  implements: () => [LocationInterface],
})
export class LocationEntity extends LocationInterface {}

@ObjectType({
  implements: () => [LocationInterface],
})
export class LocationWithLatLongEntity extends LocationInterface {
  @IsOptional()
  @Field(() => Number, { nullable: true })
  latitude: number | null

  @IsOptional()
  @Field(() => Number, { nullable: true })
  longitude: number | null
}

@ObjectType({
  implements: () => [LocationInterface],
})
export class LocationWithCoordinatesEntity extends LocationInterface {
  @IsNotEmpty()
  @Field()
  coordinates: string
}
