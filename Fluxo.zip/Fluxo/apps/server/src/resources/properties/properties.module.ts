import { Module } from '@nestjs/common'

import { StripeBusinessModule } from '@/common/services/integrations/stripe/business/stripe-business.module'
import { AvailabilityModule } from '@/resources/availability/availability.module'
import { HostsModule } from '@/resources/hosts/hosts.module'
import { LocationsService } from '@/resources/properties/locations.service'
import { PropertiesResolver } from '@/resources/properties/properties.resolver'
import { PropertiesService } from '@/resources/properties/properties.service'
import { PropertyIntegrationsSyncController } from '@/resources/properties/property-integrations-sync.controller'

@Module({
  imports: [HostsModule, AvailabilityModule, StripeBusinessModule],
  providers: [PropertiesResolver, PropertiesService, LocationsService],
  controllers: [PropertyIntegrationsSyncController],
  exports: [PropertiesService, LocationsService],
})
export class PropertiesModule {}
