import { BadRequestException, UseGuards } from '@nestjs/common'
import { Args, Context, Mutation, Query, Resolver } from '@nestjs/graphql'
import { Prisma } from '@prisma/client'

import { CurrentUserDetails } from '@/common/decorators/current-user-details.decorator'
import { ErrorGraphqlHandlingDecorator } from '@/common/decorators/error-graphql-handling.decorator'
import { RequestedFieldsDecorator } from '@/common/decorators/requested-fields.decorator'
import { JwtAuthGuard } from '@/common/guards/jwt-auth.guard'
import { MessageInterfaceEntity } from '@/common/interfaces/message.interface'
import { ContextServer } from '@/common/services/graphql/graphql.module'
import { JwtTokenPayload, JwtTokenService } from '@/common/services/jwt-token/jwt-token.service'
import { AttributesInput } from '@/resources/properties/dto/attributes.input'
import { CreatePropertyInput } from '@/resources/properties/dto/create-property.input'
import { DeleteDayPassInput } from '@/resources/properties/dto/delete-day-pass.input'
import { DeleteSpaceInput } from '@/resources/properties/dto/delete-space.input'
import { GetLocationInput } from '@/resources/properties/dto/get-location.input'
import { GetPropertyInput } from '@/resources/properties/dto/get-property.input'
import { SearchInput } from '@/resources/properties/dto/search.input'
import { SpacesInput } from '@/resources/properties/dto/spaces.input'
import { UpdateDayPassInput } from '@/resources/properties/dto/update-day-pass.input'
import { UpdatePropertyInput } from '@/resources/properties/dto/update-property.input'
import { UpdateSpaceInput } from '@/resources/properties/dto/update-space.input'
import { AttributeEntity } from '@/resources/properties/entities/attribute.entity'
import { DayPassEntity } from '@/resources/properties/entities/day-pass.entity'
import { LocationWithCoordinatesEntity } from '@/resources/properties/entities/location.entity'
import { LowestPriceEntity } from '@/resources/properties/entities/lowest-price.entity'
import {
  PropertyWithHostEntity,
  PropertyWithIdEntity,
  PropertyWithLowestPriceEntity,
} from '@/resources/properties/entities/property.entity'
import { SpaceEntity } from '@/resources/properties/entities/space.entity'
import { LocationsService } from '@/resources/properties/locations.service'
import { PropertiesService } from '@/resources/properties/properties.service'

@Resolver()
export class PropertiesResolver {
  constructor(
    private readonly propertiesService: PropertiesService,
    private readonly jwtTokenService: JwtTokenService,
    private readonly locationsService: LocationsService,
  ) {}

  @Query(() => [AttributeEntity], {
    description: 'Returns a list of all attributes.',
  })
  @ErrorGraphqlHandlingDecorator(PropertiesResolver.name)
  attributes(
    @RequestedFieldsDecorator() select: Prisma.AttributeSelect,
    @Args('input') input?: AttributesInput,
  ): Promise<AttributeEntity[] | null> {
    return this.propertiesService.findManyAttributes(
      input?.type ? { type: { in: input.type } } : {},
      select,
    )
  }

  @Query(() => [PropertyWithLowestPriceEntity])
  @ErrorGraphqlHandlingDecorator(PropertiesResolver.name)
  async search(
    @CurrentUserDetails() userDetails: JwtTokenPayload | undefined,
    @Args('input') input: SearchInput,
    @RequestedFieldsDecorator() select: Prisma.PropertySelect,
  ) {
    return this.propertiesService.search(input, select, userDetails?.id)
  }

  @Query(() => [PropertyWithLowestPriceEntity])
  @ErrorGraphqlHandlingDecorator(PropertiesResolver.name)
  async topRated(@RequestedFieldsDecorator() select: Prisma.PropertySelect) {
    return this.propertiesService.topRated(select)
  }

  @Query(() => LowestPriceEntity)
  @ErrorGraphqlHandlingDecorator(PropertiesResolver.name)
  async propertyLowestPrice(
    @Args('input') input: GetPropertyInput,
    @CurrentUserDetails() userDetails: JwtTokenPayload,
  ): Promise<LowestPriceEntity> {
    const property = await this.propertiesService.findUnique(
      input,
      { spaces: true, dayPass: true },
      userDetails,
      true,
    )

    if (!property) {
      throw new BadRequestException("Can't find the property")
    }

    return {
      lowestPrice: this.propertiesService.calculateLowestPrice(
        property.spaces,
        property.dayPass?.dailyCost,
      ),
    }
  }

  @UseGuards(JwtAuthGuard)
  @Query(() => LocationWithCoordinatesEntity)
  @ErrorGraphqlHandlingDecorator(PropertiesResolver.name)
  async location(
    @Args('input') input: GetLocationInput,
  ): Promise<LocationWithCoordinatesEntity | null> {
    return this.locationsService.findUnique({
      propertyId: input.propertyId,
      guestId: input.guestId,
      hostId: input.hostId,
    })
  }

  @Query(() => PropertyWithHostEntity, { nullable: true })
  @ErrorGraphqlHandlingDecorator(PropertiesResolver.name)
  async property(
    @Args('input') input: GetPropertyInput,
    @RequestedFieldsDecorator() select: Prisma.PropertySelect,
    @Context() ctx: ContextServer,
  ) {
    let userDetails: JwtTokenPayload | undefined

    try {
      userDetails = await this.jwtTokenService.verifyToken(
        this.jwtTokenService.getTokenFromCookie(ctx.req) ?? '',
      )
    } catch {
      /* If token is not found it's fine  */
    }

    return await this.propertiesService.findUnique(input, select, userDetails)
  }

  @UseGuards(JwtAuthGuard)
  @Mutation(() => PropertyWithIdEntity)
  @ErrorGraphqlHandlingDecorator(PropertiesResolver.name)
  createProperty(
    @RequestedFieldsDecorator() select: Prisma.PropertySelect,
    @CurrentUserDetails() userDetails: JwtTokenPayload,
    @Args('input') input: CreatePropertyInput,
  ) {
    return this.propertiesService.create(input, select, userDetails.id)
  }

  @UseGuards(JwtAuthGuard)
  @Mutation(() => PropertyWithIdEntity)
  @ErrorGraphqlHandlingDecorator(PropertiesResolver.name)
  updateProperty(
    @RequestedFieldsDecorator() select: Prisma.PropertySelect,
    @CurrentUserDetails() userDetails: JwtTokenPayload,
    @Args('input') input: UpdatePropertyInput,
  ) {
    return this.propertiesService.update(input, userDetails, select)
  }

  @UseGuards(JwtAuthGuard)
  @Mutation(() => DayPassEntity)
  @ErrorGraphqlHandlingDecorator(PropertiesResolver.name)
  updateDayPass(
    @RequestedFieldsDecorator() select: Prisma.DayPassSelect,
    @CurrentUserDetails() userDetails: JwtTokenPayload,
    @Args('input') input: UpdateDayPassInput,
  ) {
    return this.propertiesService.updateDayPass(input, userDetails, select)
  }

  @UseGuards(JwtAuthGuard)
  @Mutation(() => MessageInterfaceEntity)
  @ErrorGraphqlHandlingDecorator(PropertiesResolver.name)
  async deleteDayPass(
    @CurrentUserDetails() userDetails: JwtTokenPayload,
    @Args('input') input: DeleteDayPassInput,
  ) {
    await this.propertiesService.deleteDayPass(input, userDetails)

    return { message: 'Day pass successfully deleted' }
  }

  @UseGuards(JwtAuthGuard)
  @Mutation(() => SpaceEntity)
  @ErrorGraphqlHandlingDecorator(PropertiesResolver.name)
  updateSpace(
    @RequestedFieldsDecorator() select: Prisma.SpaceSelect,
    @CurrentUserDetails() userDetails: JwtTokenPayload,
    @Args('input') input: UpdateSpaceInput,
  ) {
    return this.propertiesService.updateSpace(input, userDetails, select)
  }

  @UseGuards(JwtAuthGuard)
  @Mutation(() => SpaceEntity)
  @ErrorGraphqlHandlingDecorator(PropertiesResolver.name)
  addSpace(
    @RequestedFieldsDecorator() select: Prisma.SpaceSelect,
    @CurrentUserDetails() userDetails: JwtTokenPayload,
    @Args('input') input: SpacesInput,
  ) {
    return this.propertiesService.addSpace(input, userDetails, select)
  }

  @UseGuards(JwtAuthGuard)
  @Mutation(() => MessageInterfaceEntity)
  @ErrorGraphqlHandlingDecorator(PropertiesResolver.name)
  async deleteSpace(
    @CurrentUserDetails() userDetails: JwtTokenPayload,
    @Args('input') input: DeleteSpaceInput,
  ) {
    await this.propertiesService.deleteSpace(input, userDetails)

    return { message: 'Space successfully deleted' }
  }
}
