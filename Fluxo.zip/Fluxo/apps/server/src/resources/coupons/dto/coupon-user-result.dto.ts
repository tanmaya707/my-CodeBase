import { ObjectType, Field } from '@nestjs/graphql';

@ObjectType()
export class UserCouponsResult {
  @Field()
  valid: boolean;

  @Field()
  reason: string;

  @Field()
  userId: string;

  @Field()
  couponCode: string;
}
