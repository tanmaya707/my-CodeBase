import { Resolver, Query, Mutation, Args } from '@nestjs/graphql';
import { CouponService } from './coupons.service';
import { Coupon } from './entity/coupon.entity';
import { CouponValidationResult } from './dto/coupon-validation-result.dto';
import { UserCouponsResult } from './dto/coupon-user-result.dto';

@Resolver(() => Coupon)
export class CouponResolver {
  constructor(private readonly couponService: CouponService) {}

  @Query(() => [Coupon])
  async coupons(): Promise<Coupon[]> {
    return this.couponService.getAllCoupons();
  }

  @Query(() => Coupon, { nullable: true })
  async getCouponById(@Args('id') id: string) {
    return this.couponService.getCouponById(id);
  }

  @Mutation(() => CouponValidationResult)
  async validateCoupon(
    @Args('userId') userId: string,
    @Args('couponCode') couponCode: string,
    @Args('bookingAmount') bookingAmount: number
  ): Promise<CouponValidationResult> {
    return this.couponService.validateCoupon(userId, couponCode, bookingAmount);
  }

  @Mutation(() => UserCouponsResult)
  async userCoupon(
    @Args('userId') userId: string,
    @Args('couponCode') couponCode: string,
  ): Promise<UserCouponsResult> {
    return this.couponService.userCoupon(userId, couponCode);
  }

}
