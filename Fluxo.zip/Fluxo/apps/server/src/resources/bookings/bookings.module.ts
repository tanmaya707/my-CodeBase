import { forwardRef, Module } from '@nestjs/common'

import { RmsCloudModule } from '@/common/services/integrations/rms-cloud/rms-cloud.module'
// eslint-disable-next-line import/no-cycle -- fixed with forwardRef
import { StripeCustomersModule } from '@/common/services/integrations/stripe/customers/stripe-customers.module'
import { BookingsResolver } from '@/resources/bookings/bookings.resolver'
import { BookingsService } from '@/resources/bookings/bookings.service'
import { GuestsModule } from '@/resources/guests/guests.module'

@Module({
  imports: [GuestsModule, RmsCloudModule, forwardRef(() => StripeCustomersModule)],
  providers: [BookingsService, BookingsResolver],
  exports: [BookingsService],
})
export class BookingsModule {}
