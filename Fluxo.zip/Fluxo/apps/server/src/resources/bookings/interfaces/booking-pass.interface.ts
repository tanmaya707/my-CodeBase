import { Field, ID, Int, InterfaceType, registerEnumType } from '@nestjs/graphql'
import { BookingEntityType, BookingPass, BookingStatus } from '@prisma/client'
import { IsEnum, IsNotEmpty, IsOptional } from 'class-validator'

registerEnumType(BookingEntityType, {
  name: 'BookingEntityType',
})

registerEnumType(BookingStatus, {
  name: 'BookingStatus',
})

@InterfaceType()
export abstract class BookingPassInterface
  implements Omit<BookingPass, 'rmsMappingId' | 'createdAt' | 'updatedAt'>
{
  @IsNotEmpty()
  @Field(() => ID)
  id: string

  @IsNotEmpty()
  @Field()
  confirmationNumber: string

  @IsNotEmpty()
  @Field(() => Date)
  arrivalDate: Date

  @IsNotEmpty()
  @Field(() => Date)
  departureDate: Date

  @IsOptional()
  @Field(() => Date, { nullable: true })
  expiresAt: Date | null

  @IsOptional()
  @Field(() => String, { nullable: true })
  notes: string | null

  @IsNotEmpty()
  @IsEnum(BookingEntityType)
  @Field(() => BookingEntityType)
  bookingEntityType: BookingEntityType

  @IsNotEmpty()
  @IsEnum(BookingStatus)
  @Field(() => BookingStatus)
  bookingStatus: BookingStatus

  @IsOptional()
  @Field(() => String, { nullable: true })
  cancelationReason: string | null

  @IsNotEmpty()
  @Field()
  seats: number

  @IsNotEmpty()
  @Field()
  basePrice: number

  @IsOptional()
  @Field(() => ID, { nullable: true })
  guestId: string | null

  @IsOptional()
  @Field(() => ID, { nullable: true })
  dayPassId: string | null

  @IsOptional()
  @Field(() => Int, { nullable: true })
  rmsDayPassId: number | null

  @IsOptional()
  @Field(() => ID, { nullable: true })
  spaceId: string | null

  @IsOptional()
  @Field(() => ID, { nullable: true })
  groupId: string | null
}
