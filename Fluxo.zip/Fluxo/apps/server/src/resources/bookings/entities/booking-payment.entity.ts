import { Field, ID, ObjectType, OmitType } from '@nestjs/graphql'
import { IsNotEmpty, IsOptional } from 'class-validator'

import { BookingGroupEntity } from '@/resources/bookings/entities/booking-group.entity'
import { BookingPassEntity } from '@/resources/bookings/entities/booking-pass.entity'

@ObjectType()
class BookingPassForPayment extends OmitType(BookingPassEntity, ['group'], ObjectType) {}

@ObjectType()
export class BookingPaymentEntity extends BookingGroupEntity {
  @IsNotEmpty()
  @Field(() => ID)
  id: string

  @IsNotEmpty()
  @Field()
  createdAt: Date

  @IsOptional()
  @Field(() => [BookingPassForPayment], { nullable: true })
  bookingPasses: BookingPassForPayment[] | null
}
