import { Field, ObjectType } from '@nestjs/graphql'
import { IsOptional } from 'class-validator'

import { BookingGroupEntity } from '@/resources/bookings/entities/booking-group.entity'
import { BookingPassInterface } from '@/resources/bookings/interfaces/booking-pass.interface'
import { GuestEntityWithUser } from '@/resources/guests/entities/guest.entity'
import { DayPassEntityWithProperty } from '@/resources/properties/entities/day-pass.entity'
import { SpaceEntityWithProperty } from '@/resources/properties/entities/space.entity'

@ObjectType({
  implements: () => [BookingPassInterface],
})
export class BookingPassEntity extends BookingPassInterface {
  @IsOptional()
  @Field(() => SpaceEntityWithProperty, { nullable: true })
  space: SpaceEntityWithProperty | null

  @IsOptional()
  @Field(() => DayPassEntityWithProperty, { nullable: true })
  dayPass: DayPassEntityWithProperty | null

  @IsOptional()
  @Field(() => GuestEntityWithUser, { nullable: true })
  guest: GuestEntityWithUser | null

  @IsOptional()
  @Field(() => BookingGroupEntity, { nullable: true })
  group: BookingGroupEntity | null
}
