import { Field, ObjectType } from '@nestjs/graphql'
import { IsOptional } from 'class-validator'

import { PaginationInterfaceEntity } from '@/common/interfaces/pagination.inteface'
import { BookingPassEntity } from '@/resources/bookings/entities/booking-pass.entity'

@ObjectType()
class BookingPassesEntityPagination extends PaginationInterfaceEntity {}

@ObjectType()
class BookingPassWithReview extends BookingPassEntity {
  @IsOptional()
  @Field(() => Number, { nullable: true })
  readonly reviewScore: number | null
}

@ObjectType()
export class BookingPassesEntity {
  @Field(() => [BookingPassWithReview])
  readonly data: BookingPassWithReview[]

  @Field(() => BookingPassesEntityPagination)
  readonly pagination: BookingPassesEntityPagination
}
