import { Field, ObjectType } from '@nestjs/graphql'

import { PaginationInterfaceEntity } from '@/common/interfaces/pagination.inteface'
import { BookingPaymentEntity } from '@/resources/bookings/entities/booking-payment.entity'

@ObjectType()
class BookingPaymentsEntityPagination extends PaginationInterfaceEntity {}

@ObjectType()
export class BookingPaymentsEntity {
  @Field(() => [BookingPaymentEntity])
  readonly data: BookingPaymentEntity[]

  @Field(() => BookingPaymentsEntityPagination)
  readonly pagination: BookingPaymentsEntityPagination
}
