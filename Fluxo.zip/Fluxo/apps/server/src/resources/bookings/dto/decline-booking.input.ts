import { InputType, PickType } from '@nestjs/graphql'

import { BookingPassEntity } from '@/resources/bookings/entities/booking-pass.entity'

@InputType()
export class DeclineBookingInput extends PickType(BookingPassEntity, ['id'], InputType) {}
