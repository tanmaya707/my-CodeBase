import { Field, InputType, PickType } from '@nestjs/graphql'
import { IsOptional } from 'class-validator'

import { BookingTimeline } from '@/common/enums'
import { PaginationInterfaceInput } from '@/common/interfaces/pagination.inteface'

@InputType()
export class HostBookingsInput extends PickType(
  PaginationInterfaceInput,
  ['pagination', 'search'],
  InputType,
) {
  @IsOptional()
  @Field(() => BookingTimeline, { nullable: true })
  timeline: BookingTimeline | null

  @IsOptional()
  @Field(() => Date, { nullable: true })
  date: Date | null

  @IsOptional()
  @Field(() => Boolean, { nullable: true })
  includeRTBBookingsInUpcoming?: boolean | null
}
