import { InputType, PickType } from '@nestjs/graphql'

import { BookingPassEntity } from '@/resources/bookings/entities/booking-pass.entity'

@InputType()
export class CheckInBookingInput extends PickType(BookingPassEntity, ['id'], InputType) {}
