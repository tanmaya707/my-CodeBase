import { Field, ID, InputType, PickType } from '@nestjs/graphql'
import { IsNotEmpty } from 'class-validator'

import { AddressInput } from '@/common/services/integrations/stripe/customers/dto/checkout.input'
import { BookingPassEntity } from '@/resources/bookings/entities/booking-pass.entity'

@InputType()
export class CreateBookingInput extends PickType(
  BookingPassEntity,
  ['notes', 'bookingEntityType', 'basePrice'],
  InputType,
) {
  @IsNotEmpty()
  @Field(() => ID)
  fluxoAreaId: string

  @IsNotEmpty()
  @Field()
  seats: number

  @IsNotEmpty()
  @Field(() => Date)
  arrivalDate: Date

  @IsNotEmpty()
  @Field(() => Date)
  departureDate: Date

  @IsNotEmpty()
  @Field(() => String)
  paymentIntentId: string

  @IsNotEmpty()
  @Field(() => AddressInput)
  addressForTaxes: AddressInput
}
