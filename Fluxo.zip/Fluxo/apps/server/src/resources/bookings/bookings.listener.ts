import { Injectable } from '@nestjs/common'
import { OnEvent } from '@nestjs/event-emitter'
import { BookingStatus } from '@prisma/client'
import pLimit from 'p-limit'

import { Events } from '@/common/enums'
import { PrismaService } from '@/common/services/prisma/prisma.service'
import { blockingBookingStatuses } from '@/common/utils'
import { BookingsService } from '@/resources/bookings/bookings.service'
import { GuestAccountDeactivatedEvent } from '@/resources/guests/events/guest-account-deactivated.event'

@Injectable()
export class BookingsListener {
  constructor(
    private readonly prismaService: PrismaService,
    private readonly bookingsService: BookingsService,
  ) {}

  @OnEvent(Events.GUEST_ACCOUNT_DEACTIVATED)
  public async handleGuestAccountDeactivated({
    userId,
  }: GuestAccountDeactivatedEvent): Promise<void> {
    const guestBookings = await this.prismaService.bookingPass.findMany({
      where: {
        guest: { userId },
        bookingStatus: {
          in: blockingBookingStatuses,
        },
      },
    })

    const limit = pLimit(3)

    await Promise.all(
      guestBookings.map((booking) =>
        limit(async () =>
          this.bookingsService.updateStatus(
            booking.id,
            BookingStatus.CANCELED_BY_GUEST,
            'Account deactivation',
          ),
        ),
      ),
    )
  }
}
