import { RawBodyRequest, Req, UseGuards } from '@nestjs/common'
import { Args, Context, Mutation, Query, Resolver } from '@nestjs/graphql'
import { Prisma, UserRole } from '@prisma/client'
import { FastifyRequest } from 'fastify'

import { CurrentUserDetails } from '@/common/decorators/current-user-details.decorator'
import { ErrorGraphqlHandlingDecorator } from '@/common/decorators/error-graphql-handling.decorator'
import { RequestedFieldsDecorator } from '@/common/decorators/requested-fields.decorator'
import { Roles } from '@/common/decorators/roles.decorator'
import { JwtAuthGuard } from '@/common/guards/jwt-auth.guard'
import { RolesGuard } from '@/common/guards/roles.guard'
import { MessageInterfaceEntity } from '@/common/interfaces/message.interface'
import { PaginatedSelect } from '@/common/pagination-utils'
import { ContextServer } from '@/common/services/graphql/graphql.module'
import { JwtTokenPayload } from '@/common/services/jwt-token/jwt-token.service'
import { BookingsService } from '@/resources/bookings/bookings.service'
import { ApproveBookingInput } from '@/resources/bookings/dto/approve-booking.input'
import { BookingPassInput } from '@/resources/bookings/dto/booking-pass.input'
import { CancelBookingAsGuestInput } from '@/resources/bookings/dto/cancel-booking-as-guest.input'
import { CancelBookingAsHostInput } from '@/resources/bookings/dto/cancel-booking-as-host.input'
import { CheckInBookingInput } from '@/resources/bookings/dto/check-in-booking.input'
import { CreateBookingInput } from '@/resources/bookings/dto/create-booking.input'
import { DeclineBookingInput } from '@/resources/bookings/dto/decline-booking.input'
import { GuestBookingsInput } from '@/resources/bookings/dto/guest-bookings.input'
import { HostBookingsInput } from '@/resources/bookings/dto/host-bookings.input'
import { HostPaymentsInput } from '@/resources/bookings/dto/host-paymets.input'
import { SubmitCancelationReasonInput } from '@/resources/bookings/dto/submit-cancelation-reason.input'
import { BookingPassEntity } from '@/resources/bookings/entities/booking-pass.entity'
import { BookingPassesEntity } from '@/resources/bookings/entities/booking-passes.entity'
import { BookingPaymentsEntity } from '@/resources/bookings/entities/booking-payments.entity'
import { BookingsStatisticsEntity } from '@/resources/bookings/entities/bookings-statistics.entity'

@Resolver(() => BookingPassEntity)
export class BookingsResolver {
  constructor(private readonly bookingsService: BookingsService) {}

  @Roles(UserRole.GUEST)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Mutation(() => [BookingPassEntity])
  @ErrorGraphqlHandlingDecorator(BookingsResolver.name)
  async createBooking(
    @Args('input') input: CreateBookingInput,
    @CurrentUserDetails() userDetails: JwtTokenPayload,
    @RequestedFieldsDecorator() select: Prisma.BookingPassSelect,
  ) {
    return this.bookingsService.createBooking(input, userDetails, select)
  }

  @Roles(UserRole.GUEST)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Mutation(() => MessageInterfaceEntity)
  @ErrorGraphqlHandlingDecorator(BookingsResolver.name)
  async cancelBookingAsGuest(
    @Args('input') input: CancelBookingAsGuestInput,
    @CurrentUserDetails() userDetails: JwtTokenPayload,
  ) {
    await this.bookingsService.cancelBookingAsGuest(input, userDetails)

    return { message: 'Booking successfully canceled' }
  }

  @Roles(UserRole.GUEST)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Mutation(() => MessageInterfaceEntity)
  @ErrorGraphqlHandlingDecorator(BookingsResolver.name)
  async submitCancelationReason(
    @Args('input') input: SubmitCancelationReasonInput,
    @CurrentUserDetails() userDetails: JwtTokenPayload,
  ) {
    await this.bookingsService.submitCancelationReason(input, userDetails)

    return { message: 'Cancelation reason sent' }
  }

  @Roles(UserRole.HOST)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Mutation(() => MessageInterfaceEntity)
  @ErrorGraphqlHandlingDecorator(BookingsResolver.name)
  async cancelBookingAsHost(
    @Args('input') input: CancelBookingAsHostInput,
    @CurrentUserDetails() userDetails: JwtTokenPayload,
  ) {
    await this.bookingsService.cancelBookingAsHost(input, userDetails)

    return { message: 'Booking successfully canceled' }
  }

  @Roles(UserRole.HOST)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Mutation(() => MessageInterfaceEntity)
  @ErrorGraphqlHandlingDecorator(BookingsResolver.name)
  async checkInBooking(
    @Args('input') input: CheckInBookingInput,
    @CurrentUserDetails() userDetails: JwtTokenPayload,
  ) {
    await this.bookingsService.checkIn(input, userDetails)

    return { message: 'Checked in the booking' }
  }

  @Roles(UserRole.HOST)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Mutation(() => MessageInterfaceEntity)
  @ErrorGraphqlHandlingDecorator(BookingsResolver.name)
  async approveBooking(
    @Args('input') input: ApproveBookingInput,
    @CurrentUserDetails() userDetails: JwtTokenPayload,
  ) {
    await this.bookingsService.approve(input, userDetails)

    return { message: 'Approved the booking' }
  }

  @Roles(UserRole.HOST)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Mutation(() => MessageInterfaceEntity)
  @ErrorGraphqlHandlingDecorator(BookingsResolver.name)
  async declineBooking(
    @Args('input') input: DeclineBookingInput,
    @CurrentUserDetails() userDetails: JwtTokenPayload,
  ) {
    await this.bookingsService.decline(input, userDetails)

    return { message: 'Declined the booking' }
  }

  @Roles(UserRole.GUEST)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Query(() => BookingPassesEntity)
  @ErrorGraphqlHandlingDecorator(BookingsResolver.name)
  async guestBookings(
    @Args('input') input: GuestBookingsInput,
    @CurrentUserDetails() userDetails: JwtTokenPayload,
    @RequestedFieldsDecorator() select: PaginatedSelect<Prisma.BookingPassSelect>,
    @Context() ctx: ContextServer,
  ) {
    return this.bookingsService.findGuestBookings(input, select, userDetails)
  }

  @Roles(UserRole.HOST)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Query(() => BookingPassesEntity)
  @ErrorGraphqlHandlingDecorator(BookingsResolver.name)
  async hostBookings(
    @Args('input') input: HostBookingsInput,
    @CurrentUserDetails() userDetails: JwtTokenPayload,
    @RequestedFieldsDecorator() select: PaginatedSelect<Prisma.BookingPassSelect>,
    @Context() ctx: ContextServer,
  ) {
    return this.bookingsService.findHostBookings(input, select, userDetails)
  }

  @Roles(UserRole.HOST)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Query(() => BookingPaymentsEntity)
  @ErrorGraphqlHandlingDecorator(BookingsResolver.name)
  async hostPayments(
    @Args('input') input: HostPaymentsInput,
    @CurrentUserDetails() userDetails: JwtTokenPayload,
    @RequestedFieldsDecorator() select: PaginatedSelect<Prisma.BookingPassGroupSelect>,
    @Context() ctx: ContextServer,
  ) {
    return this.bookingsService.findHostPayments(input, select, userDetails)
  }

  @Query(() => [BookingPassEntity], { nullable: true })
  @ErrorGraphqlHandlingDecorator(BookingsResolver.name)
  async bookingPass(
    @Args('input') input: BookingPassInput,
    @RequestedFieldsDecorator() select: Prisma.BookingPassSelect,
  ) {
    return this.bookingsService.findMany({ where: { groupId: input.groupId }, select })
  }

  @Query(() => [BookingsStatisticsEntity])
  @ErrorGraphqlHandlingDecorator(BookingsResolver.name)
  async bookingsStatistics() {
    return this.bookingsService.bookingsStatistics()
  }
}
