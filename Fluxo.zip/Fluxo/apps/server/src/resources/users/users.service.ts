import { Injectable } from '@nestjs/common'
import { AuthType, Prisma, User } from '@prisma/client'
import { randomInt } from 'es-toolkit'

import { MessageInterfaceEntity } from '@/common/interfaces/message.interface'
import { JwtTokenPayload } from '@/common/services/jwt-token/jwt-token.service'
import { PasswordService } from '@/common/services/password/password.service'
import { PrismaService } from '@/common/services/prisma/prisma.service'
import { isEmpty } from '@/common/utils'
import { ReviewInput } from '@/resources/reviews/dto/review.input'
import { UpdateExpoPushTokenInput } from '@/resources/users/dto/update-expo-push-token.input'

@Injectable()
export class UsersService {
  constructor(
    private readonly prismaService: PrismaService,
    private readonly passwordService: PasswordService,
  ) {}

  public async findUnique(email: string, select?: Prisma.UserSelect): Promise<User | null> {
    return this.prismaService.user.findUnique({
      where: { email },
      select: isEmpty(select) ? null : select,
    })
  }

  public async findUniqueById(id: string, select?: Prisma.UserSelect) {
    return this.prismaService.user.findUnique({
      where: { id },
      select: isEmpty(select) ? null : select,
    })
  }

  public async userExists(email: string): Promise<boolean> {
    const usersCount = await this.prismaService.user.count({ where: { email } })

    return usersCount > 0
  }

  public create({
    email,
    password,
    firstName,
    lastName,
    role,
    authType = AuthType.FLUXO,
  }: Pick<User, 'email' | 'password' | 'firstName' | 'lastName' | 'role'> &
    Partial<Pick<User, 'authType'>>): Promise<User> {
    return this.prismaService.user.create({
      data: {
        email,
        firstName,
        lastName,
        password: this.passwordService.hashPassword(password),
        role,
        authType,
      },
    })
  }

  public async updateVerificationCode(email: string, code: string): Promise<void> {
    await this.update({
      where: { email },
      data: {
        verificationCode: this.passwordService.hashPassword(code),
      },
    })
  }

  public async updateExpoPushToken(
    input: UpdateExpoPushTokenInput,
    userDetails: JwtTokenPayload,
  ): Promise<MessageInterfaceEntity> {
    await this.update({
      where: { id: userDetails.id },
      data: {
        expoPushToken: input.expoPushToken,
      },
    })

    return { message: 'ok' }
  }

  public async update(args: Prisma.UserUpdateArgs): Promise<User> {
    return this.prismaService.user.update(args)
  }

  public generateVerificationCode(): string {
    return Array.from({ length: 6 }, () => randomInt(0, 10)).join('')
  }
}
