import { Field, InputType } from '@nestjs/graphql'
import { IsOptional } from 'class-validator'

@InputType()
export class UpdateExpoPushTokenInput {
  @IsOptional()
  @Field(() => String, { nullable: true })
  expoPushToken: string | null
}
