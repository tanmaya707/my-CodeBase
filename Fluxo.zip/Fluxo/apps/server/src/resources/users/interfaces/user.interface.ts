import { Field, ID, InterfaceType, registerEnumType } from '@nestjs/graphql'
import { AuthType, User, UserRole } from '@prisma/client'
import { Transform } from 'class-transformer'
import { IsEmail, IsNotEmpty, IsOptional } from 'class-validator'

import { MessageGraphqlService } from '@/common/services/graphql/message-graphql.service'

const MessageService = new MessageGraphqlService()

registerEnumType(UserRole, {
  name: 'UserRole',
})

@InterfaceType()
export class UserInterface
  implements
    Omit<
      User,
      | 'createdAt'
      | 'updatedAt'
      | 'password'
      | 'verificationCode'
      | 'tokenExpiryThreshold'
      | 'authType'
      | 'rmsMappingId'
    >
{
  @IsNotEmpty()
  @Field(() => ID)
  id: string

  @Transform((params: { value: string }) => params.value.toLowerCase().trim())
  @IsEmail({}, { message: MessageService.error('email', 'Incorrect email format') })
  @IsNotEmpty()
  @Field()
  email: string

  @IsNotEmpty()
  @Field()
  firstName: string

  @IsNotEmpty()
  @Field()
  lastName: string

  @Field()
  emailVerified: boolean

  @IsNotEmpty()
  @Field(() => UserRole)
  role: UserRole

  @IsNotEmpty()
  @Field(() => AuthType)
  authType: AuthType

  @IsOptional()
  @Field(() => String, { nullable: true })
  expoPushToken: string | null
}
