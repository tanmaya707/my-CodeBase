import { UseGuards } from '@nestjs/common'
import { Args, Mutation, Query, Resolver } from '@nestjs/graphql'
import { UserRole } from '@prisma/client'

import { CurrentUserDetails } from '@/common/decorators/current-user-details.decorator'
import { ErrorGraphqlHandlingDecorator } from '@/common/decorators/error-graphql-handling.decorator'
import { Roles } from '@/common/decorators/roles.decorator'
import { JwtAuthGuard } from '@/common/guards/jwt-auth.guard'
import { RolesGuard } from '@/common/guards/roles.guard'
import { MessageInterfaceEntity } from '@/common/interfaces/message.interface'
import { JwtTokenPayload } from '@/common/services/jwt-token/jwt-token.service'
import { UpdateExpoPushTokenInput } from '@/resources/users/dto/update-expo-push-token.input'
import { UserEntity } from '@/resources/users/entities/user.entity'
import { UserRoleEntity } from '@/resources/users/entities/user-role.entity'
import { UsersService } from '@/resources/users/users.service'

@UseGuards(JwtAuthGuard)
@Resolver(() => UserEntity)
export class UsersResolver {
  constructor(private readonly usersService: UsersService) {}

  @Query(() => UserRoleEntity, {
    description: 'Returns the user type of the currently authenticated user.',
  })
  @ErrorGraphqlHandlingDecorator(UsersResolver.name)
  userRole(@CurrentUserDetails() userDetails: JwtTokenPayload): Promise<UserRoleEntity | null> {
    return this.usersService.findUnique(userDetails.email, { role: true })
  }

  @Roles(UserRole.GUEST, UserRole.HOST)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Mutation(() => MessageInterfaceEntity)
  @ErrorGraphqlHandlingDecorator(UsersResolver.name)
  updateExpoPushToken(
    @CurrentUserDetails() userDetails: JwtTokenPayload,
    @Args('input') input: UpdateExpoPushTokenInput,
  ): Promise<MessageInterfaceEntity> {
    return this.usersService.updateExpoPushToken(input, userDetails)
  }
}
