import { HttpModule } from '@nestjs/axios'
import { Module } from '@nestjs/common'

import { ReviewsResolver } from './reviews.resolver'
import { ReviewsService } from './reviews.service'

@Module({
  imports: [HttpModule],
  providers: [ReviewsResolver, ReviewsService],
  exports: [ReviewsService],
})
export class ReviewsModule {}
