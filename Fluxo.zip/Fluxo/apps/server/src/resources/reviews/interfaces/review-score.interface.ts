interface BottomLineScore {
  domain_key: string
  product_score: number
  total_reviews: number
}

export interface ReviewScoreResponse {
  response?: {
    bottomlines?: BottomLineScore[]
    page: string
    per_page: string
  }
  status: {
    code: number
    message: string
  }
}
