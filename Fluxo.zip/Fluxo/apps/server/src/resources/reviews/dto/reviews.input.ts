import { Field, ID, InputType, PickType } from '@nestjs/graphql'
import { IsNotEmpty } from 'class-validator'

import { PaginationInterfaceInput } from '@/common/interfaces/pagination.inteface'

@InputType()
export class ReviewsInput extends PickType(PaginationInterfaceInput, ['pagination'], InputType) {
  @IsNotEmpty()
  @Field(() => ID)
  propertyId: string
}
