import { Field, ID, InputType } from '@nestjs/graphql'
import { IsInt, IsNotEmpty, IsOptional, Max, Min } from 'class-validator'

@InputType()
export class ReviewInput {
  @IsNotEmpty()
  @Field(() => ID)
  propertyId: string

  @IsNotEmpty()
  @Field(() => Number)
  @IsInt()
  @Min(1, { message: 'Score must be at least 1' })
  @Max(5, { message: 'Score must be at most 5' })
  score: number

  @IsNotEmpty()
  @Field(() => String)
  mainHighlight: string

  @IsOptional()
  @Field(() => String, { nullable: true })
  comments?: string
}
