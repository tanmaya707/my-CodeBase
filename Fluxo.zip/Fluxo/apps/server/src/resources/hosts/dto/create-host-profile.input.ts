import { Field, InputType, OmitType } from '@nestjs/graphql'
import { IsOptional } from 'class-validator'

import { HostEntity } from '@/resources/hosts/entities/host.entity'
import { LocationInput } from '@/resources/properties/dto/location.input'

@InputType()
export class CreateHostProfileInput extends OmitType(
  HostEntity,
  [
    'id',
    'userId',
    'property',
    'businessLocation',
    'stripeAccountDetails',
    'commissionRate',
    'status',
  ],
  InputType,
) {
  @IsOptional()
  @Field(() => LocationInput)
  businessLocation: LocationInput
}
