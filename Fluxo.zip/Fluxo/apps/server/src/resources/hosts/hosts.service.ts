import { BadRequestException, ForbiddenException, Injectable } from '@nestjs/common'
import { EventEmitter2 } from '@nestjs/event-emitter'
import { HostPauseSource, HostStatus, Prisma } from '@prisma/client'
import { merge } from 'es-toolkit'

import { BookingTimeline, Events } from '@/common/enums'
import { StripeBusinessService } from '@/common/services/integrations/stripe/business/stripe-business.service'
import { JwtTokenPayload } from '@/common/services/jwt-token/jwt-token.service'
import { PrismaService } from '@/common/services/prisma/prisma.service'
import { BookingsService } from '@/resources/bookings/bookings.service'
import { CreateHostProfileInput } from '@/resources/hosts/dto/create-host-profile.input'
import { UpdateHostProfileInput } from '@/resources/hosts/dto/update-host-profile.input'
import { HostUserEntity } from '@/resources/hosts/entities/host-user.entity'
import { HostAccountDeactivatedEvent } from '@/resources/hosts/events/host-account-deactivated.event'
import { HostAccountPausedEvent } from '@/resources/hosts/events/host-account-paused.event'
import { HostProfileChangedEvent } from '@/resources/hosts/events/host-profile-changed.event'
import { LocationInput } from '@/resources/properties/dto/location.input'
import { LocationsService } from '@/resources/properties/locations.service'

@Injectable()
export class HostsService {
  constructor(
    private readonly prismaService: PrismaService,
    private readonly eventEmitter: EventEmitter2,
    private readonly stripeBusinessService: StripeBusinessService,
    private readonly locationService: LocationsService,
    private readonly bookingsService: BookingsService,
  ) {}

  public async upsert(user: HostUserEntity, profileData: CreateHostProfileInput): Promise<void> {
    const isProfileCreated = !user.host
    const { businessLocation, ...hostData } = profileData
    const upsertResult = await this.prismaService.host.upsert({
      where: { userId: user.id },
      create: merge(
        { user: { connect: { id: user.id } } },
        { ...(hostData as Prisma.HostCreateInput) },
      ),
      update: hostData,
      include: {
        user: {
          include: {
            host: true,
            rmsMapping: true,
          },
        },
      },
    })

    await this.updateLocation(upsertResult.id, businessLocation)

    if (isProfileCreated) {
      await this.stripeBusinessService.createBusinessAccount({ user: upsertResult.user })

      this.eventEmitter.emit(Events.HOST_PROFILE_CREATED, new HostProfileChangedEvent(upsertResult))
    }
  }

  public async updateProfile(id: string, input: UpdateHostProfileInput): Promise<void> {
    const { businessLocation, ...hostData } = input

    const updatedProfile = await this.prismaService.host.update({
      where: { id },
      data: hostData,
      include: { user: { include: { rmsMapping: true } } },
    })
    await this.updateLocation(updatedProfile.id, businessLocation)

    this.eventEmitter.emit(Events.HOST_PROFILE_UPDATED, new HostProfileChangedEvent(updatedProfile))
  }

  public async findUnique(where: Prisma.HostWhereUniqueInput, select: Prisma.HostSelect) {
    return this.prismaService.host.findUnique({ where, select })
  }

  private async updateLocation(hostId: string, location?: LocationInput): Promise<void> {
    try {
      await this.prismaService.location.delete({ where: { hostId } })
    } catch {
      /*  If the location doesn't exist that's fine  */
    }

    if (location) await this.locationService.create(location, { hostId }, this.prismaService)
  }

  public async pauseAccount(
    userDetails: Pick<JwtTokenPayload, 'id' | 'email'>,
    pauseSource: HostPauseSource = HostPauseSource.FLUXO,
  ) {
    const host = await this.prismaService.host.findUniqueOrThrow({
      where: { userId: userDetails.id },
      select: { status: true },
    })

    if (host.status === 'PAUSED' && pauseSource === HostPauseSource.FLUXO) {
      throw new ForbiddenException(`You can't pause the already paused account.`)
    }

    // Update host status to "PAUSED"
    await this.prismaService.host.update({
      where: { userId: userDetails.id },
      data: {
        status: HostStatus.PAUSED,
        pauseSource,
      },
    })

    // Trigger Guest Notification -> Account Paused
    this.eventEmitter.emit(
      Events.HOST_ACCOUNT_PAUSED,
      new HostAccountPausedEvent(userDetails.id, userDetails.email),
    )
  }

  public async unpauseAccount(
    userDetails: Pick<JwtTokenPayload, 'id' | 'email'>,
    skipUnpauseCheck = false,
  ) {
    const host = await this.prismaService.host.findUniqueOrThrow({
      where: { userId: userDetails.id },
      select: { pauseSource: true },
    })

    if (!skipUnpauseCheck && host.pauseSource === HostPauseSource.RMS) {
      throw new ForbiddenException(
        `You are not allowed to unpause your account because it was paused by a Fluxo administrator. Please contact support.`,
      )
    }

    await this.prismaService.host.update({
      where: { userId: userDetails.id },
      data: {
        status: HostStatus.ACTIVE,
        pauseSource: null,
      },
    })

    this.eventEmitter.emit(
      Events.HOST_ACCOUNT_UNPAUSED,
      new HostAccountPausedEvent(userDetails.id, userDetails.email),
    )
  }

  public async deactivateAccount(userDetails: JwtTokenPayload): Promise<void> {
    const userCount = await this.prismaService.user.count({
      where: { id: userDetails.id },
    })

    if (userCount === 0) {
      throw new BadRequestException('User not found')
    }

    const upcomingBookings = await this.bookingsService.findHostBookings(
      {
        pagination: { take: 1, page: 0, sort: 'arrivalDate', order: 'asc' },
        timeline: BookingTimeline.UPCOMING,
        date: null,
      },
      { data: { select: { id: true } } },
      userDetails,
    )

    if (upcomingBookings.pagination.total > 0) {
      throw new ForbiddenException(`It's not possible to deactivate account with upcoming bookings`)
    }

    this.eventEmitter.emit(
      Events.HOST_ACCOUNT_DEACTIVATED,
      new HostAccountDeactivatedEvent(userDetails.id, userDetails.email),
    )

    await this.prismaService.user.delete({ where: { id: userDetails.id } })
  }
}
