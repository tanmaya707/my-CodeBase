import { Field, ObjectType } from '@nestjs/graphql'
import { IsOptional } from 'class-validator'

import { HostEntity } from '@/resources/hosts/entities/host.entity'
import { UserInterface } from '@/resources/users/interfaces/user.interface'

@ObjectType({
  implements: () => [UserInterface],
})
export class HostUserEntity extends UserInterface {
  @IsOptional()
  @Field(() => HostEntity, { nullable: true })
  host?: HostEntity | null
}
