import { Field, ID, InterfaceType, registerEnumType } from '@nestjs/graphql'
import { Host, HostPauseSource, HostStatus } from '@prisma/client'
import { IsNotEmpty, IsOptional } from 'class-validator'

registerEnumType(HostStatus, {
  name: 'HostStatus',
})

registerEnumType(HostPauseSource, {
  name: 'HostPauseSource',
})

@InterfaceType()
export class HostInterface implements Host {
  @IsNotEmpty()
  @Field(() => ID)
  id: string

  @IsNotEmpty()
  @Field(() => ID)
  userId: string

  @IsNotEmpty()
  @Field()
  businessContact: string

  @IsOptional()
  @Field(() => String, { nullable: true })
  businessPhoneNumber: string | null

  @IsOptional()
  @Field(() => String, { nullable: true })
  businessPhoneNumberCountry: string | null

  @IsNotEmpty()
  @Field()
  businessName: string

  @IsNotEmpty()
  @Field()
  commissionRate: number

  @IsNotEmpty()
  @Field(() => HostStatus)
  status: HostStatus

  @IsOptional()
  @Field(() => HostPauseSource, { nullable: true })
  pauseSource: HostPauseSource | null
}
