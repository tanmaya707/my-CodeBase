import * as Sentry from '@sentry/nestjs'
import { nodeProfilingIntegration } from '@sentry/profiling-node'

Sentry.init({
  dsn: 'https://45903c05850570c4581e7d35efb3ce4c@o4507812082548736.ingest.us.sentry.io/4508687542386688',
  integrations: [nodeProfilingIntegration()],
  enabled: process.env.IS_LOCAL !== 'true',
  environment: process.env.SENTRY_ENV ?? 'development',
  tracesSampleRate: 1.0,
  profilesSampleRate: 1.0,
})

Sentry.profiler.startProfiler()
