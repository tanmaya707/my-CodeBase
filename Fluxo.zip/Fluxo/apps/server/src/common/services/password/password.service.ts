import { Injectable } from '@nestjs/common'
import { compareSync, hashSync } from 'bcryptjs'

@Injectable()
export class PasswordService {
  public comparePassword(setPassword: string, savedPassword: string): boolean {
    return compareSync(setPassword, savedPassword)
  }

  public hashPassword(setPassword: string): string {
    return hashSync(setPassword, 12)
  }
}
