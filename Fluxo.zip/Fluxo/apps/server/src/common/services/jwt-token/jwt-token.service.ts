import { type CookieSerializeOptions } from '@fastify/cookie'
import { BadRequestException, Injectable } from '@nestjs/common'
import { ConfigService } from '@nestjs/config'
import { JwtService } from '@nestjs/jwt'
import { UserRole } from '@prisma/client'
import { type FastifyReply, type FastifyRequest } from 'fastify'

import { type AppConfig } from '@/common/config/configuration'

export interface JwtTokenPayload {
  id: string
  email: string
  role: UserRole
  remember?: boolean
  iat?: number
  exp?: number
}

@Injectable()
export class JwtTokenService {
  constructor(
    private jwt: JwtService,
    private configService: ConfigService<AppConfig>,
  ) {}

  private readonly cookieConfig: CookieSerializeOptions = {
    httpOnly: true,
    sameSite: true,
    secure: process.env.NODE_ENV === 'production',
    path: '/',
  }

  public createToken(payload: JwtTokenPayload, expiresIn?: string): Promise<string> {
    if (!process.env.TOKEN_SECRET) {
      throw new Error('Token secret is required')
    }

    return this.jwt.signAsync(payload, {
      secret: process.env.TOKEN_SECRET,
      expiresIn:
        expiresIn ?? this.configService.get('app.tokenExpirationTime.normal', { infer: true }),
    })
  }

  public async verifyToken(token: string): Promise<JwtTokenPayload> {
    try {
      return await this.jwt.verifyAsync(token, {
        secret: process.env.TOKEN_SECRET,
      })
    } catch (e) {
      throw new BadRequestException('Token is expired or not valid')
    }
  }

  getTokenFromCookie(req: FastifyRequest): string | null {
    return req.cookies.token ?? null
  }

  setTokenToCookie(res: FastifyReply, token: string): void {
    void res.setCookie('token', token, this.cookieConfig)
  }

  clearTokenFromCookie(res: FastifyReply): void {
    void res.setCookie('token', '', this.cookieConfig)
  }
}
