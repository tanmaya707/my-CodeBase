import { Module } from '@nestjs/common'

import { EmailService } from '@/common/services/email/email.service'
import { EMAIL_INTEGRATION_SERVICE } from '@/common/services/integrations/email-service-integration.interface'
import { ResendService } from '@/common/services/integrations/resend/resend.service'

@Module({
  imports: [],
  providers: [
    EmailService,
    {
      provide: EMAIL_INTEGRATION_SERVICE,
      useClass: ResendService,
    },
  ],
  exports: [EmailService],
})
export class EmailModule {}
