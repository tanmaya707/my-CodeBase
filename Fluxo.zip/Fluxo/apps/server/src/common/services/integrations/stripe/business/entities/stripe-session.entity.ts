import { Field, ObjectType } from '@nestjs/graphql'
import { IsNotEmpty } from 'class-validator'

@ObjectType()
export class StripeSessionEntity {
  @IsNotEmpty()
  @Field(() => String)
  clientSecret: string
}
