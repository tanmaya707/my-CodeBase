import { Injectable, OnModuleInit, Logger } from '@nestjs/common';
import Stripe from 'stripe';
import { ConfigService } from '@nestjs/config';
import { AppConfig } from '@/common/config/configuration';
import { PrismaService } from '@/common/services/prisma/prisma.service'
import { Cron, CronExpression } from '@nestjs/schedule';

@Injectable()
export class CouponService {
    private readonly stripeClient: Stripe;
    private readonly logger = new Logger(CouponService.name);

    constructor(
        private configService: ConfigService<AppConfig>,
        private readonly prismaService: PrismaService,
    ) {
        const apiKey = this.configService.get('stripe.apiKey', { infer: true });
        this.stripeClient = new Stripe(apiKey ?? '');
    }

    // @Cron(CronExpression.EVERY_DAY_AT_MIDNIGHT) // Runs at midnight daily
    // async scheduledCouponFetch() {
    //     this.logger.log('Running scheduled coupon fetch...');
    //     await this.fetchAndStoreCoupons();
    // }

    @Cron(CronExpression.EVERY_MINUTE) // Runs every minute
    async scheduledCouponFetch() {
        this.logger.log('Running scheduled coupon fetch every minute...');
        await this.fetchAndStoreCoupons();
    }


    async fetchAndStoreCoupons() {
        const coupons = await this.stripeClient.coupons.list();

        for (const coupon of coupons.data) {

            console.log('Fetched coupon:', coupon); // Log the fetched coupon for debugging
           
            await this.prismaService.stripeCoupons.upsert({
                where: { id: coupon.id },
                update: {
                    amount_off: coupon.amount_off ?? null,
                    created_at: coupon.created,
                    currency: coupon.currency ?? null,
                    duration: coupon.duration,
                    duration_in_months: coupon.duration_in_months ?? null,
                    livemode: coupon.livemode,
                    max_redemptions: coupon.max_redemptions ?? null,
                    name: coupon.name ?? null,
                    percent_off: coupon.percent_off ?? null,
                    redeem_by: coupon.redeem_by ?? null,
                    times_redeemed: coupon.times_redeemed,
                    valid: coupon.valid,
                },
                create: {
                    id: coupon.id,
                    amount_off: coupon.amount_off ?? null,
                    created_at: coupon.created,
                    currency: coupon.currency ?? null,
                    duration: coupon.duration,
                    duration_in_months: coupon.duration_in_months ?? null,
                    livemode: coupon.livemode,
                    max_redemptions: coupon.max_redemptions ?? null,
                    name: coupon.name ?? null,
                    percent_off: coupon.percent_off ?? null,
                    redeem_by: coupon.redeem_by ?? null,
                    times_redeemed: coupon.times_redeemed,
                    valid: coupon.valid,
                },
            });
        }

        this.logger.log(`Stored ${coupons.data.length} coupons in the database`);
    }
}