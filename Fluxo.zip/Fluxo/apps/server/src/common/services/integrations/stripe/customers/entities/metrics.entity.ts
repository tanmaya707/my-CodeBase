import { Field, ObjectType } from '@nestjs/graphql'
import { IsNotEmpty } from 'class-validator'

@ObjectType()
export class DashboardMetricsEntity {
  @IsNotEmpty()
  @Field(() => Number)
  totalRevenue: number

  @IsNotEmpty()
  @Field(() => Number)
  totalThisMonth: number

  @IsNotEmpty()
  @Field(() => Number)
  averageMonthlyRevenue: number

  @IsNotEmpty()
  @Field(() => Number)
  monthlyEarnings: number

  @IsNotEmpty()
  @Field(() => Number)
  lastMonthEarnings: number

  @IsNotEmpty()
  @Field(() => Number)
  nextPayoutAmount: number

  @IsNotEmpty()
  @Field(() => Number)
  percentageChange: number
}
