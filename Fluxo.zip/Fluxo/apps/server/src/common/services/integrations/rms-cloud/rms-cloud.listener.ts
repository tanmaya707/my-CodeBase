import {
  BadGatewayException,
  BadRequestException,
  Injectable,
  InternalServerErrorException,
  Logger,
} from '@nestjs/common'
import { OnEvent } from '@nestjs/event-emitter'
import { RmsEntityType } from '@prisma/client'
import { AxiosError } from 'axios'
import { take } from 'es-toolkit'

import { Events } from '@/common/enums'
import { RmsCloudService } from '@/common/services/integrations/rms-cloud/rms-cloud.service'
import {
  RMSCloudAreaFull,
  RMSCloudCategoryFull,
  RMSCloudGuestBasic,
  RMSCloudPropertiesBasic,
  RMSCloudRateTable,
} from '@/common/services/integrations/rms-cloud/rms-cloud-types'
import { PrismaService } from '@/common/services/prisma/prisma.service'
import { convertCentsToUnits, extractLatitudeAndLongitude } from '@/common/utils'
import { GuestProfileChangedEvent } from '@/resources/guests/events/guest-profile-changed.event'
import { HostProfileChangedEvent } from '@/resources/hosts/events/host-profile-changed.event'
import { DayPassUpdatedEvent } from '@/resources/properties/events/day-pass-updated.event'
import { PropertyCreatedEvent } from '@/resources/properties/events/property-created.event'
import { PropertyUpdatedEvent } from '@/resources/properties/events/property-updated.event'
import { SpaceUpdatedEvent } from '@/resources/properties/events/space-updated.event'
import { LocationsService } from '@/resources/properties/locations.service'

@Injectable()
export class RmsCloudListener {
  private readonly logger = new Logger(RmsCloudListener.name)

  constructor(
    private readonly locationsService: LocationsService,
    private readonly prismaService: PrismaService,
    private readonly rmsCloudService: RmsCloudService,
  ) {}

  @OnEvent(Events.GUEST_PROFILE_CREATED)
  public async handleGuestProfileCreatedEvent({ guest }: GuestProfileChangedEvent): Promise<void> {
    const guestLocation = await this.locationsService.findUnique({ guestId: guest.id })

    const rmsGuest = await this.rmsCloudService.request<RMSCloudGuestBasic>('/guests', {
      method: 'POST',
      data: {
        id: this.rmsCloudService.DEFAULT_POST_ID,
        addressLine1: guestLocation?.address,
        email: guest.user.email,
        guestGiven: guest.user.firstName,
        guestSurname: guest.user.lastName || guest.user.firstName.split(' '),
        birth: guest.dateOfBirth ? guest.dateOfBirth.toISOString() : '',
        title: guest.user.role,
        mobile: guest.phoneNumber,
      } as RMSCloudGuestBasic,
    })

    if (!rmsGuest.id) {
      throw new BadGatewayException("Can't create guest user in RMS")
    }

    await this.prismaService.rmsMapping.create({
      data: {
        user: { connect: { id: guest.userId } },
        rmsId: rmsGuest.id,
        rmsEntityType: RmsEntityType.GUEST,
      },
    })

    this.logger.debug(`RMS Cloud guest user is created. ID: ${rmsGuest.id}`)
  }

  @OnEvent(Events.GUEST_PROFILE_UPDATED)
  public async handleGuestProfileUpdatedEvent({ guest }: GuestProfileChangedEvent): Promise<void> {
    if (!guest.user.rmsMapping?.rmsId) {
      throw new BadRequestException(
        `Can't find the guest profile in RMS system, or it's not linked in fluxo DB`,
      )
    }

    const guestLocation = await this.locationsService.findUnique({ guestId: guest.id })
    const rmsGuest = await this.rmsCloudService.request<RMSCloudGuestBasic>('/guests', {
      method: 'PUT',
      data: {
        id: guest.user.rmsMapping.rmsId,
        addressLine1: guestLocation?.address,
        email: guest.user.email,
        guestGiven: guest.user.firstName,
        guestSurname: guest.user.lastName || guest.user.firstName.split(' '),
        birth: guest.dateOfBirth ? guest.dateOfBirth.toISOString() : '',
        title: guest.user.role,
        mobile: guest.phoneNumber,
      } as RMSCloudGuestBasic,
    })

    if (!rmsGuest.id) {
      throw new BadGatewayException("Can't update guest user in RMS")
    }

    this.logger.debug(`RMS Cloud guest user is updated. ID: ${rmsGuest.id}`)
  }

  @OnEvent(Events.HOST_PROFILE_CREATED)
  public async handleHostProfileCreatedEvent({ host }: HostProfileChangedEvent): Promise<void> {
    const location = await this.locationsService.findUnique({ hostId: host.id })
    const rmsHost = await this.rmsCloudService.request<RMSCloudGuestBasic>('/guests', {
      method: 'POST',
      data: {
        id: this.rmsCloudService.DEFAULT_POST_ID,
        addressLine1: location?.address ?? '',
        email: host.user.email,
        guestGiven: host.user.firstName,
        guestSurname: host.user.lastName || host.user.firstName.split(' '),
        title: host.user.role,
        mobile: host.businessPhoneNumber,
      } as RMSCloudGuestBasic,
    })

    if (!rmsHost.id) {
      throw new BadGatewayException("Can't create host user in RMS")
    }

    await this.prismaService.rmsMapping.create({
      data: {
        user: { connect: { id: host.userId } },
        rmsId: rmsHost.id,
        rmsEntityType: RmsEntityType.GUEST,
      },
    })

    this.logger.debug(`RMS Cloud host user is created. ID: ${rmsHost.id}`)
  }

  @OnEvent(Events.HOST_PROFILE_UPDATED)
  public async handleHostProfileUpdatedEvent({ host }: HostProfileChangedEvent): Promise<void> {
    if (!host.user.rmsMapping?.rmsId) {
      throw new BadRequestException(
        `Can't find the host profile in RMS system, or it's not linked in fluxo DB`,
      )
    }

    const location = await this.locationsService.findUnique({ hostId: host.id })
    const rmsHost = await this.rmsCloudService.request<RMSCloudGuestBasic>('/guests', {
      method: 'PUT',
      data: {
        id: host.user.rmsMapping.rmsId,
        addressLine1: location?.address ?? '',
        email: host.user.email,
        guestGiven: host.user.firstName,
        guestSurname: host.user.lastName || host.user.firstName.split(' '),
        title: host.user.role,
        mobile: host.businessPhoneNumber,
      } as RMSCloudGuestBasic,
    })

    if (!rmsHost.id) {
      throw new BadGatewayException("Can't update host user in RMS")
    }

    this.logger.debug(`RMS Cloud host user is updated. ID: ${rmsHost.id}`)
  }

  @OnEvent(Events.PROPERTY_CREATED)
  public async handlePropertyCreatedEvent({ property }: PropertyCreatedEvent): Promise<void> {
    try {
      const location = await this.locationsService.findUnique({ propertyId: property.id })
      const propertyFull = await this.prismaService.property.findUnique({
        where: {
          id: property.id,
        },
        select: {
          name: true,
          id: true,
          host: { select: { user: true } },
          spaces: { include: { attributes: true } },
          dayPass: true,
          attributes: { select: { rmsMapping: true } },
        },
      })

      if (!propertyFull) {
        throw new BadRequestException("Can't find property")
      }

      const { latitude, longitude } = extractLatitudeAndLongitude(location?.coordinates)
      const rmsProperty = await this.rmsCloudService.request<RMSCloudPropertiesBasic | null>(
        '/letting/properties',
        {
          method: 'POST',
          data: {
            addressLine1: location?.address,
            countryId: 13,
            latitude,
            longitude,
            name: `${propertyFull.name}-${propertyFull.id}`,
            timeZone: 'Eastern Standard Time',
            email: propertyFull.host?.user.email,
          } as RMSCloudPropertiesBasic,
        },
      )

      // Update auth token after property creation (required step to make the new property visible)
      await this.rmsCloudService.updateAuthToken()

      if (!rmsProperty?.id) {
        throw new BadRequestException("Couldn't create RMS property")
      }

      await this.prismaService.rmsMapping.create({
        data: {
          property: { connect: { id: propertyFull.id } },
          rmsId: rmsProperty.id,
          rmsEntityType: RmsEntityType.PROPERTY,
        },
      })

      const dayPass = propertyFull.dayPass

      if (dayPass) {
        const dayPassGlAccountCode = await this.rmsCloudService.request<{ id: number } | null>(
          '/glAccountCodes',
          {
            method: 'POST',
            data: {
              id: this.rmsCloudService.DEFAULT_POST_ID,
              name: 'DAY_PASS',
              glCode: `${crypto.randomUUID()}--${propertyFull.id}`,
              groupingId: this.rmsCloudService.DEFAULT_POST_ID,
              'includeInAccommodationRevenue"': false,
            },
          },
        )

        if (!dayPassGlAccountCode) {
          throw new BadRequestException("Couldn't create RMS GlAccountCode")
        }

        const rmsDayPassCategory = await this.rmsCloudService.request<RMSCloudCategoryFull | null>(
          `/letting/properties/${rmsProperty.id}/categories`,
          {
            method: 'POST',
            data: {
              name: `DAY_PASS-${crypto.randomUUID()}--${propertyFull.id}`,
              guestDescription: `fluxo guest description ${crypto.randomUUID()}--${propertyFull.id}`,
              categoryClass: 'Accomm',
              glCodeId: dayPassGlAccountCode.id,
            },
          },
        )

        for (const index of Array.from({ length: dayPass.quantity }).map((_, i) => i + 1)) {
          const dayPassArea = await this.rmsCloudService.request<RMSCloudAreaFull | null>(
            `/letting/categories/${rmsDayPassCategory?.id}/areas`,
            {
              method: 'POST',
              data: {
                name: `${dayPass.id}--${crypto.randomUUID()}`,
              },
            },
          )

          if (!dayPassArea?.id) {
            this.logger.debug(`Can't create RMS area for day pass id - ${dayPass.id}`)

            return
          }

          await this.prismaService.rmsMapping.create({
            data: {
              dayPass: { connect: { id: dayPass.id } },
              rmsId: dayPassArea.id,
              rmsCategoryId: dayPassArea.categoryId,
              rmsEntityType: RmsEntityType.AREA,
            },
          })
          const cost = convertCentsToUnits(dayPass.dailyCost)
          const rateTable = await this.rmsCloudService.request<RMSCloudAreaFull | null>(
            `/letting/rates/tables`,
            {
              method: 'POST',
              data: {
                description: `Day pass rate table--${crypto.randomUUID()}--${propertyFull.id}`,
                personBase: 1,
                mondayRate: cost,
                tuesdayRate: cost,
                wednesdayRate: cost,
                thursdayRate: cost,
                fridayRate: cost,
                saturdayRate: cost,
                sundayRate: cost,
              },
            },
          )

          if (!rateTable) return

          await this.rmsCloudService.request<RMSCloudRateTable | null>(`/letting/rates/lookups`, {
            method: 'POST',
            data: {
              rateId: this.rmsCloudService.DEFAULT_RATE_TYPE_ID,
              categoryId: rmsDayPassCategory?.id,
              areaId: dayPassArea.id,
              tableId: rateTable.id,
            },
          })
        }
      }

      if (propertyFull.spaces.length > 0) {
        const spacesGlAccountCode = await this.rmsCloudService.request<{ id: number } | null>(
          '/glAccountCodes',
          {
            method: 'POST',
            data: {
              id: this.rmsCloudService.DEFAULT_POST_ID,
              name: 'SPACES',
              glCode: `${crypto.randomUUID()}--${propertyFull.id}`,
              groupingId: this.rmsCloudService.DEFAULT_POST_ID,
              'includeInAccommodationRevenue"': false,
            },
          },
        )

        if (!spacesGlAccountCode) {
          throw new BadRequestException("Couldn't create RMS GlAccountCode")
        }

        const rmsSpacesCategory = await this.rmsCloudService.request<RMSCloudCategoryFull | null>(
          `/letting/properties/${rmsProperty.id}/categories`,
          {
            method: 'POST',
            data: {
              name: `SPACES-${crypto.randomUUID()}`,
              guestDescription: `fluxo guest description--${crypto.randomUUID()}--${propertyFull.id}`,
              categoryClass: 'Accomm',
              glCodeId: spacesGlAccountCode.id,
            },
          },
        )

        for (const space of propertyFull.spaces) {
          const area = await this.rmsCloudService.request<RMSCloudAreaFull | null>(
            `/letting/categories/${rmsSpacesCategory?.id}/areas`,
            {
              method: 'POST',
              data: {
                name: `${space.name}--${crypto.randomUUID()}--${propertyFull.id}`,
              },
            },
          )

          if (!area?.id) {
            this.logger.debug(`Can't create RMS area for space id - ${space.id}`)

            return
          }

          await this.prismaService.rmsMapping.create({
            data: {
              space: { connect: { id: space.id } },
              rmsId: area.id,
              rmsCategoryId: area.categoryId,
              rmsEntityType: RmsEntityType.AREA,
            },
          })

          const cost = convertCentsToUnits(space.hourlyCost)
          const rateTable = await this.rmsCloudService.request<RMSCloudAreaFull | null>(
            `/letting/rates/tables`,
            {
              method: 'POST',
              data: {
                description: `Space rate table--${crypto.randomUUID()}--${propertyFull.id}`,
                personBase: space.capacity,
                mondayRate: cost,
                tuesdayRate: cost,
                wednesdayRate: cost,
                thursdayRate: cost,
                fridayRate: cost,
                saturdayRate: cost,
                sundayRate: cost,
              },
            },
          )

          if (!rateTable) return

          await this.rmsCloudService.request<RMSCloudRateTable | null>(`/letting/rates/lookups`, {
            method: 'POST',
            data: {
              rateId: this.rmsCloudService.DEFAULT_RATE_TYPE_ID,
              categoryId: rmsSpacesCategory?.id,
              areaId: area.id,
              tableId: rateTable.id,
            },
          })
        }
      }

      this.logger.debug(`RMS Cloud property is created. ID: ${rmsProperty.id}`)
    } catch (error) {
      if (error instanceof AxiosError) {
        this.logger.error(`RMS Cloud property creation error. Error: ${error.message}`)
        return
      }

      this.logger.error(
        `RMS Cloud property creation error. Error: ${JSON.stringify(error, null, 2)}`,
      )
    }
  }

  @OnEvent(Events.PROPERTY_UPDATED)
  public async handlePropertyUpdatedEvent(payload: PropertyUpdatedEvent): Promise<void> {
    const property = await this.prismaService.property.findUniqueOrThrow({
      where: { id: payload.id },
      select: {
        id: true,
        name: true,
        description: true,
        location: true,
        host: { select: { user: true } },
        rmsMapping: { select: { rmsId: true } },
      },
    })
    const location = await this.locationsService.findUnique({ propertyId: property.id })

    if (!property.rmsMapping?.rmsId) {
      throw new BadRequestException('RMS id not found for property')
    }

    const { latitude, longitude } = extractLatitudeAndLongitude(location?.coordinates)

    await this.rmsCloudService.request<RMSCloudPropertiesBasic | null>(
      `/letting/properties/${property.rmsMapping.rmsId}`,
      {
        method: 'PATCH',
        data: {
          addressLine1: property.location?.address ?? '',
          countryId: 13,
          latitude,
          longitude,
          name: `${property.name}-${property.id}`,
          timeZone: 'Eastern Standard Time',
          email: property.host?.user.email,
        } as RMSCloudPropertiesBasic,
      },
    )
  }

  @OnEvent(Events.SPACE_DELETED)
  public async handleSpaceDeletedEvent(payload: SpaceUpdatedEvent): Promise<void> {
    const space = await this.prismaService.space.findFirstOrThrow({
      where: { id: payload.id },
      select: {
        name: true,
        id: true,
        rmsMapping: { select: { rmsId: true, rmsCategoryId: true } },
      },
    })

    if (!space.rmsMapping?.rmsCategoryId) {
      throw new BadRequestException('Category not found for a new space')
    }

    await this.rmsCloudService.request<RMSCloudAreaFull | null>(
      `/letting/categories/${space.rmsMapping.rmsCategoryId}/areas/${space.rmsMapping.rmsId}`,
      {
        method: 'PATCH',
        data: {
          name: `${this.rmsCloudService.DELETED_AREA_MARKER}--${space.id}-${crypto.randomUUID()}`,
        },
      },
    )
  }

  @OnEvent(Events.SPACE_ADDED)
  public async handleSpaceUpdatedEvent(payload: SpaceUpdatedEvent): Promise<void> {
    const newSpace = await this.prismaService.space.findFirstOrThrow({
      where: { id: payload.id },
      select: {
        name: true,
        id: true,
        property: {
          select: {
            id: true,
            name: true,
            rmsMapping: { select: { rmsId: true } },
            spaces: { select: { rmsMapping: { select: { rmsCategoryId: true } } } },
          },
        },
      },
    })
    let spacesCategoryId = newSpace.property.spaces.find((space) => space.rmsMapping?.rmsCategoryId)
      ?.rmsMapping?.rmsCategoryId

    if (!newSpace.property.rmsMapping) {
      throw new InternalServerErrorException(
        `RMS mapping not found for property ${newSpace.property.id}`,
      )
    }

    if (!spacesCategoryId) {
      const spacesGlAccountCode = await this.rmsCloudService.request<{ id: number } | null>(
        '/glAccountCodes',
        {
          method: 'POST',
          data: {
            id: this.rmsCloudService.DEFAULT_POST_ID,
            name: 'SPACES',
            glCode: `${crypto.randomUUID()}--${newSpace.property.id}`,
            groupingId: this.rmsCloudService.DEFAULT_POST_ID,
            'includeInAccommodationRevenue"': false,
          },
        },
      )

      if (!spacesGlAccountCode) {
        throw new BadRequestException('Failed to create RMS GlAccountCode')
      }

      const rmsSpacesCategory = await this.rmsCloudService.request<RMSCloudCategoryFull | null>(
        `/letting/properties/${newSpace.property.rmsMapping.rmsId}/categories`,
        {
          method: 'POST',
          data: {
            name: `SPACES-${crypto.randomUUID()}`,
            guestDescription: `fluxo guest description--${crypto.randomUUID()}--${newSpace.property.id}`,
            categoryClass: 'Accomm',
            glCodeId: spacesGlAccountCode.id,
          },
        },
      )

      spacesCategoryId = rmsSpacesCategory?.id
    }

    if (!spacesCategoryId) {
      throw new InternalServerErrorException(
        `Failed to create the spaces category. Property ID: ${newSpace.property.id}`,
      )
    }

    const rmsSpace = await this.rmsCloudService.request<RMSCloudAreaFull | null>(
      `/letting/categories/${spacesCategoryId}/areas`,
      {
        method: 'POST',
        data: {
          name: `${newSpace.name}--${crypto.randomUUID()}--${newSpace.property.name}`,
        },
      },
    )

    if (!rmsSpace?.id) {
      this.logger.debug(`Failed to create RMS area for space id - ${newSpace.id}`)

      return
    }

    await this.prismaService.rmsMapping.create({
      data: {
        space: { connect: { id: newSpace.id } },
        rmsId: rmsSpace.id,
        rmsCategoryId: rmsSpace.categoryId,
        rmsEntityType: RmsEntityType.AREA,
      },
    })
  }

  @OnEvent(Events.DAY_PASS_UPDATED)
  public async handleDayPassUpdatedEvent(payload: DayPassUpdatedEvent): Promise<void> {
    const dayPass = await this.prismaService.dayPass.findUniqueOrThrow({
      where: { id: payload.id },
      select: {
        id: true,
        propertyId: true,
        dailyCost: true,
        rmsMappings: { select: { rmsId: true, rmsCategoryId: true, id: true } },
        quantity: true,
      },
    })
    const isQuantityChanged = dayPass.quantity !== dayPass.rmsMappings.length

    if (!isQuantityChanged) {
      return
    }

    const quantityDifference = dayPass.quantity - dayPass.rmsMappings.length
    const dayPassCategoryId = dayPass.rmsMappings.find(
      (rmsMapping) => rmsMapping.rmsCategoryId,
    )?.rmsCategoryId

    // Quantity increased, we need to add more day pass areas to venue
    if (quantityDifference > 0) {
      for (const index of Array.from({ length: quantityDifference }).map((_, i) => i + 1)) {
        // TODO remove duplication
        const dayPassArea = await this.rmsCloudService.request<RMSCloudAreaFull | null>(
          `/letting/categories/${dayPassCategoryId}/areas`,
          {
            method: 'POST',
            data: {
              name: `${dayPass.id}--${crypto.randomUUID()}`,
            },
          },
        )

        if (!dayPassArea?.id) {
          this.logger.debug(`Can't create RMS area for day pass id - ${dayPass.id}`)

          return
        }

        await this.prismaService.rmsMapping.create({
          data: {
            dayPass: { connect: { id: dayPass.id } },
            rmsId: dayPassArea.id,
            rmsCategoryId: dayPassArea.categoryId,
            rmsEntityType: RmsEntityType.AREA,
          },
        })
        const cost = convertCentsToUnits(dayPass.dailyCost)
        const rateTable = await this.rmsCloudService.request<RMSCloudAreaFull | null>(
          `/letting/rates/tables`,
          {
            method: 'POST',
            data: {
              description: `Day pass rate table--${crypto.randomUUID()}--${dayPass.propertyId}`,
              personBase: 1,
              mondayRate: cost,
              tuesdayRate: cost,
              wednesdayRate: cost,
              thursdayRate: cost,
              fridayRate: cost,
              saturdayRate: cost,
              sundayRate: cost,
            },
          },
        )

        if (!rateTable) return

        await this.rmsCloudService.request<RMSCloudRateTable | null>(`/letting/rates/lookups`, {
          method: 'POST',
          data: {
            rateId: this.rmsCloudService.DEFAULT_RATE_TYPE_ID,
            categoryId: dayPassCategoryId,
            areaId: dayPassArea.id,
            tableId: rateTable.id,
          },
        })
      }
      // Quantity decreased, we need to disable day passes in RMS and remove their mappings
    } else {
      const totalDayPassesToRemove = Math.abs(quantityDifference)
      const selectedDayPassMappingsForRemoval = take(dayPass.rmsMappings, totalDayPassesToRemove)

      for (const dayPassToRemove of selectedDayPassMappingsForRemoval) {
        await this.rmsCloudService.request<RMSCloudAreaFull | null>(
          `/letting/categories/${dayPassToRemove.rmsCategoryId}/areas/${dayPassToRemove.rmsId}`,
          {
            method: 'PATCH',
            data: {
              name: `${this.rmsCloudService.DELETED_AREA_MARKER}--${dayPass.id}-${crypto.randomUUID()}`,
            },
          },
        )

        await this.prismaService.rmsMapping.delete({ where: { id: dayPassToRemove.id } })
      }
    }
  }
}
