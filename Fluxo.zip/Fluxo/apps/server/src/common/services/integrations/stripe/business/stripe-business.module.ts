import { Module } from '@nestjs/common'

import { StripeBusinessGateway } from '@/common/services/integrations/stripe/business/stripe-business.gateway'
import { StripeBusinessResolver } from '@/common/services/integrations/stripe/business/stripe-business.resolver'
import { StripeBusinessService } from '@/common/services/integrations/stripe/business/stripe-business.service'
import { StripeBusinessWebhookController } from '@/common/services/integrations/stripe/business/stripe-business-webhook.controller'

@Module({
  controllers: [StripeBusinessWebhookController],
  providers: [StripeBusinessService, StripeBusinessResolver, StripeBusinessGateway],
  exports: [StripeBusinessService],
})
export class StripeBusinessModule {}
