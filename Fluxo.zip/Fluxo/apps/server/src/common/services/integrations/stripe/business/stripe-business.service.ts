import { Injectable, Logger, NotFoundException } from '@nestjs/common'
import { ConfigService } from '@nestjs/config'
import { EventEmitter2 } from '@nestjs/event-emitter'
import { BookingStatus, Host, HostPauseSource, HostStatus } from '@prisma/client'
import {
  addDays,
  endOfDay,
  endOfMonth,
  format,
  startOfDay,
  startOfMonth,
  subMonths,
} from 'date-fns'
import Stripe from 'stripe'

import { AppConfig } from '@/common/config/configuration'
import { Events, StripeConnectAccountStatus } from '@/common/enums'
import { GetAccountLinkInput } from '@/common/services/integrations/stripe/business/dto/get-account-link.input'
import { StripeAccountEntity } from '@/common/services/integrations/stripe/business/entities/stripe-account.entity'
import {
  StripeAccountErrorsEntity,
  StripeBusinessAccountEntity,
  StripePublicAccountEntity,
} from '@/common/services/integrations/stripe/business/entities/stripe-business-account.entity'
import { StripeSessionEntity } from '@/common/services/integrations/stripe/business/entities/stripe-session.entity'
import { JwtTokenPayload } from '@/common/services/jwt-token/jwt-token.service'
import { PrismaService } from '@/common/services/prisma/prisma.service'
import { HostAccountPausedEvent } from '@/resources/hosts/events/host-account-paused.event'
import { PropertyCreatedEvent } from '@/resources/properties/events/property-created.event'
import { UserEntity } from '@/resources/users/entities/user.entity'

@Injectable()
export class StripeBusinessService {
  private readonly stripeClient: Stripe
  private readonly logger = new Logger(StripeBusinessService.name)
  private MAX_DESCRIPTOR_LENGTH = 12

  constructor(
    private configService: ConfigService<AppConfig>,
    private readonly prismaService: PrismaService,
    private readonly eventEmitter: EventEmitter2,
  ) {
    const apiKey = this.configService.get('stripe.apiKey', { infer: true })
    this.stripeClient = new Stripe(apiKey ?? '')
  }

  // TODO: account exists flow
  async createBusinessAccount({
    user,
  }: {
    user: UserEntity & { host: Host | null }
  }): Promise<StripeBusinessAccountEntity> {
    const ACCOUNT_TYPE = 'express'

    try {
      const { id: userId, email, host } = user

      if (!host) {
        this.logger.error(`Host with user ID ${userId} not found`)
        throw new NotFoundException('Host not found')
      }

      let businessName = host.businessName
        .substring(0, this.MAX_DESCRIPTOR_LENGTH)
        .normalize('NFD') // Normalize Unicode
        .replace(/[^A-Za-z0-9\s&-]/g, '') // Allow only Latin characters, numbers, spaces, &, and -
        .trim()

      if (businessName.length < 5) {
        businessName = 'FLUXO' // Fallback if too short
      }

      const account = await this.stripeClient.accounts.create({
        type: ACCOUNT_TYPE,
        email,
        capabilities: {
          transfers: { requested: true },
          bank_transfer_payments: { requested: true },
          card_payments: { requested: true },
        },
        business_profile: {
          name: host.businessName,
        },
        settings: {
          card_payments: {
            statement_descriptor_prefix: 'FLUXO',
          },
          payments: {
            statement_descriptor: `${businessName} Via Fluxo`,
          },
          payouts: {
            statement_descriptor: `${businessName} Via Fluxo`,
            schedule: {
              interval: 'weekly',
              weekly_anchor: 'wednesday',
            },
          },
        },
        // country: 'US', // TODO: temp
      })

      const businessAccount = await this.prismaService.stripeBusinessAccount.create({
        data: {
          stripeId: account.id,
          host: { connect: { id: host.id } },
        },
      })

      this.logger.log('Successfully created Stripe business account')
      return businessAccount
    } catch (error: unknown) {
      // Handle Stripe-related errors
      // eslint-disable-next-line @typescript-eslint/no-unnecessary-condition -- known
      if (error instanceof Error && 'type' in error && (error as Stripe.StripeRawError).type) {
        this.logger.error('Stripe API error', error)
        throw new Error('There was an issue creating the Stripe account, please try again later.')
      }

      if (error instanceof NotFoundException) {
        this.logger.error('Host not found error', error)
        throw error
      }

      // Handle any other unexpected errors
      this.logger.error('Failed to create Stripe account', error)
      throw new Error('An unknown error occurred, please try again later.')
    }
  }

  async checkBusinessAccountCreated({ user }: { user: UserEntity }): Promise<void> {
    const host = await this.prismaService.host.findUnique({ where: { userId: user.id } })

    if (!host) {
      this.logger.error(`Stripe business account: Host with user ID ${user.id} not found`)
      return // no exception, proceed any flow
    }

    const businessAccount = await this.prismaService.stripeBusinessAccount.findUnique({
      where: { hostId: host.id },
      select: { id: true, stripeId: true, isVerified: true },
    })

    if (!businessAccount) {
      // if we don't have stripe connected account in our db and have within stripe -
      // it will create row in db with existing stripe account
      await this.createBusinessAccount({ user: { ...user, host } })
    }
  }

  async checkKYCVerified(userId: string): Promise<StripePublicAccountEntity> {
    try {
      const host = await this.prismaService.host.findUnique({ where: { userId } })

      if (!host) {
        this.logger.error(`Stripe business account: Host with user ID ${userId} not found`)
        throw new NotFoundException('Host not found')
      }

      const businessAccount = await this.prismaService.stripeBusinessAccount.findUnique({
        where: { hostId: host.id },
        select: { id: true, stripeId: true, isVerified: true },
      })

      if (!businessAccount) {
        throw new Error(
          'Stripe business account not found. Please try again later. If this problem persists, please contact support.',
        )
      }

      const account = await this.stripeClient.accounts.retrieve(businessAccount.stripeId)

      if (account.requirements?.currently_due?.length) {
        return {
          isVerified: false,
          status: StripeConnectAccountStatus.PENDING,
          errors: this.getAccountErrors(account),
        }
      }

      if (account.requirements?.disabled_reason) {
        return {
          isVerified: false,
          status: StripeConnectAccountStatus.DISABLED,
          errors: this.getAccountErrors(account),
        }
      }

      if (
        account.requirements?.currently_due?.length === 0 &&
        account.requirements.past_due?.length === 0 &&
        account.requirements.errors?.length === 0
      ) {
        return {
          isVerified: true,
          status: StripeConnectAccountStatus.VERIFIED,
          errors: this.getAccountErrors(account),
        }
      }

      return {
        isVerified: false,
        status: StripeConnectAccountStatus.PENDING,
        errors: this.getAccountErrors(account),
      }
    } catch (error) {
      this.logger.error('Error retrieving account:', error)
      throw new Error('Failed to retrieve account status')
    }
  }

  async updateBusinessAccountStatus(
    accountId: string,
    status: StripeConnectAccountStatus,
  ): Promise<void> {
    const businessAccount = await this.prismaService.stripeBusinessAccount.findUnique({
      where: { stripeId: accountId },
      select: { beenAlreadyVerified: true },
    })
    if (businessAccount && accountId) {
      await this.prismaService.stripeBusinessAccount.update({
        where: { stripeId: accountId },
        data: {
          isVerified: status === StripeConnectAccountStatus.VERIFIED,
        },
      })
    }
  }

  async createBusinessAccountLink(
    userDetails: JwtTokenPayload,
    input: GetAccountLinkInput,
  ): Promise<StripeAccountEntity> {
    try {
      const REFRESH_URL = input.refreshUrl
      const RETURN_URL = input.returnUrl
      const ACCOUNT_LINK_TYPE = 'account_onboarding'

      const host = await this.prismaService.host.findUnique({ where: { userId: userDetails.id } })

      if (!host) {
        this.logger.error(`Host with user ID ${userDetails.id} not found`)
        throw new NotFoundException('Host not found')
      }

      const businessAccount = await this.prismaService.stripeBusinessAccount.findUnique({
        where: { hostId: host.id },
      })

      if (!businessAccount) {
        throw new Error(
          'Stripe business account not found. Please try again later. If this problem persists, please contact support.',
        )
      }

      const accountLink = await this.stripeClient.accountLinks.create({
        account: businessAccount.stripeId,
        refresh_url: REFRESH_URL,
        return_url: RETURN_URL,
        type: ACCOUNT_LINK_TYPE,
      })
      return { url: accountLink.url }
    } catch (error: unknown) {
      this.logger.error('Failed to create stripe account link')
      throw error
    }
  }

  async createBusinessAccountSession(userDetails: JwtTokenPayload): Promise<StripeSessionEntity> {
    try {
      const businessAccount = await this.getBusinessAccount({ userId: userDetails.id })
      const accountSession = await this.stripeClient.accountSessions.create({
        account: businessAccount.stripeId,
        components: {
          account_onboarding: {
            enabled: true,
            features: {
              external_account_collection: true,
            },
          },
        },
      })
      return { clientSecret: accountSession.client_secret }
    } catch (error: unknown) {
      this.logger.error('Failed to create stripe account session')
      throw error
    }
  }

  async createStripeProduct({
    propertyId,
    name,
    price,
    description,
  }: {
    propertyId: string
    name: string
    price: number
    description?: string
  }) {
    try {
      await this.stripeClient.products.create({
        name,
        ...(description && { description }),
        default_price_data: {
          currency: 'usd',
          unit_amount: price,
        },
        metadata: {
          propertyId,
        },
      })
    } catch (error) {
      this.logger.error('Error on stripe product creation')
    }
  }

  async getBusinessAccount({ userId }: { userId: string }): Promise<StripeBusinessAccountEntity> {
    const host = await this.prismaService.host.findUnique({ where: { userId } })

    if (!host) {
      this.logger.error(`Host with user ID ${userId} not found`)
      throw new NotFoundException('Host not found')
    }

    const businessAccount = await this.prismaService.stripeBusinessAccount.findUnique({
      where: { hostId: host.id },
    })

    if (!businessAccount) {
      throw new Error(
        'Stripe business account not found. Please try again later. If this problem persists, please contact support.',
      )
    }

    return businessAccount
  }

  getKYCStatus(
    account: Stripe.Response<Stripe.Account> | Stripe.Account,
  ): StripeConnectAccountStatus {
    if (account.requirements?.currently_due?.length) {
      return StripeConnectAccountStatus.PENDING
    }

    if (
      account.requirements?.currently_due?.length === 0 &&
      account.requirements.past_due?.length === 0 &&
      account.requirements.errors?.length === 0
    ) {
      return StripeConnectAccountStatus.VERIFIED // KYC passed
    }

    if (account.requirements?.disabled_reason) {
      return StripeConnectAccountStatus.DISABLED // KYC failed
    }

    return StripeConnectAccountStatus.PENDING // KYC is in progress
  }

  getAccountErrors(
    account: Stripe.Response<Stripe.Account> | Stripe.Account,
  ): StripeAccountErrorsEntity {
    return {
      disabled_reason: account.requirements?.disabled_reason ?? '',
      currently_due: account.requirements?.currently_due ?? [],
      past_due: account.requirements?.past_due ?? [],
      eventually_due: account.requirements?.eventually_due ?? [],
      errors: account.requirements?.errors?.map((e) => e.reason) ?? [],
    }
  }

  public async getUserByStripeId(stripeId: string): Promise<{ id: string; email: string }> {
    const stripeBusinessAccount = await this.prismaService.stripeBusinessAccount.findUnique({
      where: { stripeId },
      select: {
        id: true,
        host: {
          select: {
            id: true,
            user: {
              select: {
                id: true,
                email: true,
              },
            },
          },
        },
      },
    })

    if (!stripeBusinessAccount) {
      this.logger.error(`Stripe Business Account with ID ${stripeId} not found`)

      return { id: '', email: '' }
    }

    return {
      id: stripeBusinessAccount.host?.user.id ?? '',
      email: stripeBusinessAccount.host?.user.email ?? '',
    }
  }

  async calculateDashboardMetrics(userDetails: JwtTokenPayload) {
    const now = new Date()

    const startOfCurrentMonth = Math.floor(startOfMonth(now).getTime() / 1000)
    const endOfCurrentMonth = Math.floor(endOfDay(now).getTime() / 1000)

    const lastMonth = subMonths(now, 1)
    const startOfLastMonth = Math.floor(startOfMonth(lastMonth).getTime() / 1000)
    const endOfLastMonth = Math.floor(endOfMonth(lastMonth).getTime() / 1000)

    const businessAccount = await this.getBusinessAccount({ userId: userDetails.id })
    const connectedAccountId = businessAccount.stripeId

    const transactions = await this.stripeClient.balanceTransactions.list(
      {
        created: { gte: startOfCurrentMonth, lte: endOfCurrentMonth },
        type: 'payment',
      },
      {
        stripeAccount: businessAccount.stripeId,
      },
    )
    const balanceTransactionsLastMonth = await this.stripeClient.balanceTransactions.list({
      created: { gte: startOfLastMonth, lte: endOfLastMonth },
      type: 'payment',
    })

    const allTransactions = await this.getAllTransactions(connectedAccountId)

    const totalRevenue = allTransactions.reduce((sum, transaction) => sum + transaction.amount, 0)
    const totalThisMonth = transactions.data.reduce(
      (sum, transaction) => sum + transaction.amount,
      0,
    )

    const averageMonthlyRevenue = await this.calculateAverageMonthlyRevenue(connectedAccountId)

    const nextPayoutAmount = await this.getNextPayoutAmount(connectedAccountId)
    const monthlyEarnings = transactions.data.reduce((total, transaction) => {
      return total + transaction.amount
    }, 0)

    const lastMonthEarnings = balanceTransactionsLastMonth.data.reduce((total, transaction) => {
      return total + transaction.amount
    }, 0)
    const percentageChange =
      lastMonthEarnings === 0
        ? 100
        : ((monthlyEarnings - lastMonthEarnings) / lastMonthEarnings) * 100

    return {
      totalRevenue,
      totalThisMonth,
      averageMonthlyRevenue,
      monthlyEarnings,
      lastMonthEarnings,
      nextPayoutAmount,
      percentageChange,
    }
  }

  async calculateAverageMonthlyRevenue(connectedAccountId: string) {
    const allTransactions = await this.getAllTransactions(connectedAccountId)
    if (allTransactions.length === 0) {
      this.logger.error('No transactions found.')
      return 0
    }

    // Group transactions by month
    const monthlyRevenue: Record<string, number> = allTransactions.reduce(
      (acc: Record<string, number>, transaction: Stripe.BalanceTransaction) => {
        const month: string = new Date(transaction.created * 1000).toISOString().slice(0, 7) // Format "YYYY-MM"
        acc[month] = (acc[month] || 0) + transaction.amount
        return acc
      },
      {},
    )

    const totalRevenue: number = Object.values(monthlyRevenue).reduce(
      (sum: number, monthlyTotal: number) => sum + monthlyTotal,
      0,
    )
    const numberOfMonths: number = Object.keys(monthlyRevenue).length
    return totalRevenue / numberOfMonths
  }

  async getAllTransactions(connectedAccountId: string) {
    const allTransactions = []
    let hasMore = true
    let startingAfter = null

    while (hasMore) {
      const response: Stripe.ApiList<Stripe.BalanceTransaction> =
        await this.stripeClient.balanceTransactions.list(
          {
            limit: 100,
            starting_after: startingAfter ?? undefined,
            type: 'payment',
          },
          {
            stripeAccount: connectedAccountId,
          },
        )

      allTransactions.push(...response.data)
      hasMore = response.has_more
      if (response.data.length > 0) {
        startingAfter = response.data[response.data.length - 1].id
      }
    }
    return allTransactions
  }

  async getNextPayoutAmount(connectedAccountId: string) {
    const nextPayout = await this.stripeClient.payouts.list(
      {
        limit: 1,
        status: 'pending',
      },
      {
        stripeAccount: connectedAccountId,
      },
    )
    return nextPayout.data.length > 0 ? nextPayout.data[0].amount : 0
  }

  async historicalRevenue(userDetails: JwtTokenPayload) {
    const businessAccount = await this.getBusinessAccount({ userId: userDetails.id })
    const connectedAccountId = businessAccount.stripeId
    const now = new Date()
    const results = []

    for (let i = 0; i < 12; i++) {
      const currentMonth = subMonths(now, i)
      const startOfCurrentMonth = Math.floor(startOfMonth(currentMonth).getTime() / 1000)
      const endOfCurrentMonth = Math.floor(endOfMonth(currentMonth).getTime() / 1000)

      const transactions = await this.stripeClient.balanceTransactions.list(
        {
          created: { gte: startOfCurrentMonth, lte: endOfCurrentMonth },
          type: 'payment',
        },
        connectedAccountId ? { stripeAccount: connectedAccountId } : undefined,
      )

      const monthlyRevenue = transactions.data.reduce((total, transaction) => {
        return total + transaction.amount
      }, 0)

      results.push({
        month: format(currentMonth, 'yyyy-MM'),
        revenue: monthlyRevenue,
      })
    }

    return results.reverse()
  }

  async upcomingBookingsStatistics(userDetails: JwtTokenPayload) {
    const host = await this.prismaService.host.findUnique({
      where: { userId: userDetails.id },
      include: {
        property: {
          include: {
            spaces: true,
            dayPass: true,
          },
        },
      },
    })

    if (!host || !host.property) {
      throw new Error('Host property not found')
    }

    const now = new Date()
    const totalDays = 7

    const totalCapacity =
      (host.property.dayPass?.quantity ?? 0) +
      host.property.spaces.reduce((sum, space) => sum + space.capacity, 0)

    return await Promise.all(
      Array.from({ length: totalDays }, async (_, i) => {
        const targetDate = addDays(now, i)
        const startOfTargetDate = startOfDay(targetDate)
        const endOfTargetDate = endOfDay(targetDate)

        const bookingCount = await this.prismaService.bookingPass.count({
          where: {
            bookingStatus: {
              notIn: [
                BookingStatus.CANCELED_BY_SYSTEM,
                BookingStatus.CANCELED_BY_GUEST,
                BookingStatus.CANCELED_BY_HOST,
              ],
            },
            arrivalDate: { gte: startOfTargetDate, lte: endOfTargetDate },
            OR: [
              { space: { property: { hostId: host.id } } },
              { dayPass: { property: { hostId: host.id } } },
            ],
          },
        })

        return {
          date: format(targetDate, 'yyyy-MM-dd'),
          bookings: bookingCount,
          capacity: totalCapacity,
        }
      }),
    )
  }

  async unpauseHostAccount({ userId, email }: { userId: string; email?: string }) {
    const host = await this.prismaService.host.findUnique({
      where: { userId },
      select: { id: true, pauseSource: true, user: true },
    })

    if (host) {
      if (host.pauseSource !== HostPauseSource.RMS) {
        await this.prismaService.host.update({
          where: { id: host.id },
          data: { status: HostStatus.ACTIVE, pauseSource: null },
        })

        if (email) {
          this.eventEmitter.emit(
            Events.HOST_ACCOUNT_UNPAUSED,
            new HostAccountPausedEvent(userId, email),
          )
        }
      }

      await this.triggerPropertyCreatedEvent({ hostId: host.id, email: host.user.email })
    }
  }

  async pauseHostAccount(userId: string, email?: string) {
    const host = await this.prismaService.host.findUnique({
      where: { userId },
      select: { pauseSource: true },
    })

    if (host && host.pauseSource !== HostPauseSource.RMS) {
      // Update host status to "PAUSED"
      await this.prismaService.host.update({
        where: { userId },
        data: {
          status: HostStatus.PAUSED,
          pauseSource: HostPauseSource.FLUXO,
        },
      })

      // Trigger Guest Notification -> Account Paused
      if (email) {
        this.eventEmitter.emit(
          Events.HOST_ACCOUNT_PAUSED,
          new HostAccountPausedEvent(userId, email),
        )
      }
    }
  }

  async triggerPropertyCreatedEvent({ hostId, email }: { hostId: string; email: string }) {
    const property = await this.prismaService.property.findUnique({
      where: { hostId },
      include: { attributes: true, rmsMapping: true },
    })

    if (property && !property.rmsMapping?.rmsId) {
      this.eventEmitter.emit(Events.PROPERTY_CREATED, new PropertyCreatedEvent(property, email))
    }
  }
}
