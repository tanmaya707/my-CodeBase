import { BadGatewayException, Injectable, Logger } from '@nestjs/common'
import { ConfigService } from '@nestjs/config'
import { Resend } from 'resend'

import type { AppConfig } from '@/common/config/configuration'
import {
  EmailIntegrationService,
  SendOptions,
} from '@/common/services/integrations/email-service-integration.interface'

@Injectable()
export class ResendService implements EmailIntegrationService {
  private readonly logger = new Logger(ResendService.name)
  private readonly client: Resend

  constructor(private readonly configService: ConfigService<AppConfig>) {
    this.client = new Resend(this.configService.get('resend.apiKey', { infer: true }))
  }

  public async send(opts: SendOptions): Promise<void> {
    try {
      const { error } = await this.client.emails.send(opts)

      if (error) {
        throw new BadGatewayException(error, "Can't send the email")
      }
    } catch (e) {
      this.logger.error('Resend error:', JSON.stringify(e, null, 2))
      throw e
    }
  }
}
