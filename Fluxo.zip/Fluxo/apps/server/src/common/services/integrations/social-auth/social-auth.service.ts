import { HttpService } from '@nestjs/axios'
import { BadRequestException, Injectable } from '@nestjs/common'
import { ConfigService } from '@nestjs/config'
import { OAuth2Client } from 'google-auth-library'
import * as jwt from 'jsonwebtoken'
import { JwtPayload } from 'jsonwebtoken'
import jwkToPem, { JWK } from 'jwk-to-pem'

import type { AppConfig } from '@/common/config/configuration'

@Injectable()
export class SocialAuthService {
  private client: OAuth2Client

  constructor(
    private readonly configService: ConfigService<AppConfig>,
    private readonly httpService: HttpService,
  ) {
    this.client = new OAuth2Client(this.configService.get('google.clientId', { infer: true }))
  }

  public async verifyGoogleIdToken(token: string) {
    try {
      return await this.client.verifyIdToken({
        idToken: token,
        // audience: this.configService.get('google.clientId', { infer: true }),
      })
    } catch (error) {
      throw new BadRequestException(error)
    }
  }

  private readonly getApplePublicKey = async (kid: string): Promise<string> => {
    const appleKeysResponse = await this.httpService.axiosRef.get<{ keys: { kid: string }[] }>(
      'https://appleid.apple.com/auth/keys',
    )
    const requiredKey = appleKeysResponse.data.keys.find((key: { kid: string }) => key.kid === kid)

    if (!requiredKey) {
      throw new Error('Apple public key not found')
    }

    return jwkToPem(requiredKey as unknown as JWK)
  }

  async verifyAppleIdToken(token: string): Promise<{
    sub: string
    email: string
    firstname: string
    lastname: string
  }> {
    try {
      const decodedToken = jwt.decode(token, { complete: true })

      if (!decodedToken?.header.kid) {
        throw new BadRequestException('Invalid apple token')
      }

      const applePublicKey = await this.getApplePublicKey(decodedToken.header.kid)
      let verifiedToken: (JwtPayload & { email?: string }) | string

      try {
        // iOS app
        verifiedToken = jwt.verify(token, applePublicKey, {
          algorithms: ['RS256'],
          audience: this.configService.get('apple.bundleId', { infer: true }),
        })
      } catch {
        try {
          // Android app
          verifiedToken = jwt.verify(token, applePublicKey, {
            algorithms: ['RS256'],
            audience: `${this.configService.get('apple.bundleId', { infer: true })}.client-android`,
          })
        } catch {
          // Web app
          verifiedToken = jwt.verify(token, applePublicKey, {
            algorithms: ['RS256'],
            audience: `com.materializelabs.fluxo.si`,
          })
        }
      }

      if (typeof verifiedToken === 'string' || !verifiedToken.email) {
        throw new BadRequestException('Apple account email is required')
      }

      return {
        sub: verifiedToken.sub ?? '',
        email: verifiedToken.email,
        firstname: verifiedToken.email.split('@').at(0) ?? '',
        lastname: verifiedToken.email.split('@').at(-1) ?? '',
      }
    } catch (error) {
      throw new BadRequestException(error)
    }
  }
}
