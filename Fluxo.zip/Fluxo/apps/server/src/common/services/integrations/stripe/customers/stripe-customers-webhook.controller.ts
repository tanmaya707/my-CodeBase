import { Controller, HttpStatus, Logger, Post, RawBodyRequest, Req, Res } from '@nestjs/common'
import { ConfigService } from '@nestjs/config'
import { EventEmitter2 } from '@nestjs/event-emitter'
import { BookingEntityType } from '@prisma/client'
import { FastifyReply, FastifyRequest } from 'fastify'
import Stripe from 'stripe'

import { AppConfig } from '@/common/config/configuration'
import { StripeCustomersService } from '@/common/services/integrations/stripe/customers/stripe-customers.service'
import { PrismaService } from '@/common/services/prisma/prisma.service'
import { BookingsService } from '@/resources/bookings/bookings.service'

@Controller('webhooks')
export class StripeCustomersWebhookController {
  private readonly stripeClient: Stripe
  private readonly logger = new Logger(StripeCustomersWebhookController.name)

  constructor(
    private configService: ConfigService<AppConfig>,
    private readonly prismaService: PrismaService,
    private bookingService: BookingsService,
    private stripeCustomersService: StripeCustomersService,
    private readonly eventEmitter: EventEmitter2,
  ) {
    const apiKey = this.configService.get('stripe.apiKey', { infer: true })
    this.stripeClient = new Stripe(apiKey ?? '')
  }


  @Post('payments')
  async handleWebhook(
    @Req() req: RawBodyRequest<FastifyRequest>,
    @Res() res: FastifyReply,
  ): Promise<void> {
    const sig = req.headers['stripe-signature'] as string
    const endpointSecret = this.configService.get('stripe.whCustomersSecret', { infer: true })

    let event: Stripe.Event

    try {
      // Validate the webhook signature
      event = this.stripeClient.webhooks.constructEvent(
        req.rawBody ?? Buffer.from(''),
        sig,
        endpointSecret ?? '',
      )
    } catch (err) {
      this.logger.error('Webhook signature verification failed:', err)
      await res.status(HttpStatus.BAD_REQUEST).send(`Webhook Error: ${err}`)
      return
    }


    if (event.type === 'charge.captured') {
      const charge = event.data.object
      if (charge.payment_intent) {
        const paymentIntent = await this.stripeClient.paymentIntents.retrieve(
          charge.payment_intent as string,
        )

        const balanceTransaction = await this.stripeClient.balanceTransactions.retrieve(
          charge.balance_transaction as string,
        )
        const bookingFee = this.stripeCustomersService.calculateBookingFee(
          Number(paymentIntent.metadata.basePrice),
        )
        const fees = balanceTransaction.fee + bookingFee

        await this.prismaService.bookingPassGroup.update({
          where: { id: paymentIntent.metadata.bookingGroupId },
          data: {
            confirmationNumbers: paymentIntent.metadata.confirmationNumbers,
            totalPrice: charge.amount,
            transferAmount: charge.transfer_data?.amount ?? null,
            fees,
            bookingFee,
            transactionFee: balanceTransaction.fee,
            taxes: Number(paymentIntent.metadata.taxes),
            paymentCapturedAt: new Date(),
          },
        })

        // TODO: error handler, move after booking confirmation
        await this.prismaService.transactionsHistory.create({
          data: {
            bookingGroupId: paymentIntent.metadata.bookingGroupId,
            basePrice: Number(paymentIntent.metadata.basePrice),
            fees,
            bookingFee,
            transactionFee: balanceTransaction.fee,
            taxes: Number(paymentIntent.metadata.taxes),
            transferAmount: charge.transfer_data?.amount ?? 0,
            chargeId: charge.id,
            userId: paymentIntent.metadata.userId,
            customerStripeId: charge.customer as string,
            captured: charge.captured,
            status: paymentIntent.status,
            total: charge.amount, // in cents
            balanceTransactionId: charge.balance_transaction as string,
            paymentIntentId: charge.payment_intent as string,
            // @ts-expect-error wrong types within stripe lib
            businessStripeId: charge.destination as string,
            transferId: charge.transfer as string,
          },
        })

        await this.bookingService.confirmPencilBooking(
          paymentIntent.metadata.bookingGroupId,
          paymentIntent.metadata.bookingEntityType as BookingEntityType,
        )
      }

      await res.status(HttpStatus.OK).send()
    }
  }
}
