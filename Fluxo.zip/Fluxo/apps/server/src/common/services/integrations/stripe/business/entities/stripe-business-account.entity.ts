import { Field, ID, InterfaceType, ObjectType, registerEnumType } from '@nestjs/graphql'
import { StripeBusinessAccount } from '@prisma/client'
import { IsNotEmpty, IsOptional } from 'class-validator'

import { StripeConnectAccountStatus } from '@/common/enums'

registerEnumType(StripeConnectAccountStatus, {
  name: 'StripeConnectAccountStatus',
})

@ObjectType()
export class StripeAccountErrorsEntity {
  @Field(() => String)
  disabled_reason: string

  @Field(() => [String])
  currently_due: string[]

  @Field(() => [String])
  past_due: string[]

  @Field(() => [String])
  eventually_due: string[]

  @Field(() => [String])
  errors: string[]
}

@ObjectType()
export class StripePublicAccountEntity {
  @IsNotEmpty()
  @Field(() => Boolean)
  isVerified: boolean

  @IsNotEmpty()
  @Field(() => StripeConnectAccountStatus)
  status: StripeConnectAccountStatus

  @IsOptional()
  @Field(() => StripeAccountErrorsEntity, { nullable: true })
  errors: StripeAccountErrorsEntity
}

@InterfaceType()
export class StripeBusinessAccountEntity
  implements Omit<StripeBusinessAccount, 'hostId' | 'createdAt' | 'updatedAt'>
{
  @IsNotEmpty()
  @Field(() => ID)
  id: string

  @IsNotEmpty()
  @Field(() => ID)
  stripeId: string

  @IsNotEmpty()
  @Field(() => Boolean)
  isVerified: boolean

  @IsNotEmpty()
  @Field(() => Boolean)
  beenAlreadyVerified: boolean
}
