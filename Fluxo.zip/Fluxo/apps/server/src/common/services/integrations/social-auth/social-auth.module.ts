import { HttpModule } from '@nestjs/axios'
import { Module } from '@nestjs/common'

import { SocialAuthService } from '@/common/services/integrations/social-auth/social-auth.service'

@Module({
  imports: [HttpModule],
  providers: [SocialAuthService],
  exports: [SocialAuthService],
})
export class SocialAuthModule {}
