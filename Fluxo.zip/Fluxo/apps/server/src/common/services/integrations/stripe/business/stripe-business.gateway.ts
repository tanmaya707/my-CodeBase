import { Logger } from '@nestjs/common'
import {
  MessageBody,
  OnGatewayConnection,
  WebSocketGateway,
  WebSocketServer,
} from '@nestjs/websockets'
import { Server, Socket } from 'socket.io'

import { StripeConnectAccountStatus } from '@/common/enums'
import { StripeAccountErrorsEntity } from '@/common/services/integrations/stripe/business/entities/stripe-business-account.entity'

@WebSocketGateway({
  cors: {
    origin: process.env.NEXT_PUBLIC_WEB_APP_URL,
    methods: ['GET', 'POST'],
  },
})
export class StripeBusinessGateway implements OnGatewayConnection {
  @WebSocketServer()
  server: Server
  private logger = new Logger()

  handleConnection(client: Socket): void {
    this.logger.log(`Stripe WS client connected: ${client.id}`)
  }

  handleDisconnect(client: Socket): void {
    this.logger.log(`Stripe WS client disconnected: ${client.id}`)
  }

  handleKycUpdate(
    @MessageBody() data: { status: StripeConnectAccountStatus; errors: StripeAccountErrorsEntity },
  ): void {
    this.server.emit('verificationStatus', data)
  }
}
