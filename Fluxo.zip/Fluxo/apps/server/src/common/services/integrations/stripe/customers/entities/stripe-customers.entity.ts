import { Field, ID, InterfaceType, ObjectType } from '@nestjs/graphql'
import { StripeCustomer } from '@prisma/client'
import { IsNotEmpty } from 'class-validator'

@InterfaceType()
export class StripeCustomersEntity
  implements Omit<StripeCustomer, 'guestId' | 'createdAt' | 'updatedAt'>
{
  @IsNotEmpty()
  @Field(() => ID)
  id: string

  @IsNotEmpty()
  @Field(() => ID)
  stripeId: string
}

@ObjectType()
export class StripePaymentIntentEntity {
  @IsNotEmpty()
  @Field(() => String)
  clientSecret: string

  @IsNotEmpty()
  @Field(() => String)
  paymentIntentId: string

  @IsNotEmpty()
  @Field(() => String)
  customerSessionClientSecret: string

  @IsNotEmpty()
  @Field(() => String)
  ephemeralKey: string

  @IsNotEmpty()
  @Field(() => String)
  customerId: string
}

@ObjectType()
export class StripePublicKeyEntity {
  @IsNotEmpty()
  @Field(() => String)
  publishableKey: string
}

@ObjectType()
export class CheckoutTotalsEntity {
  @IsNotEmpty()
  @Field(() => Number)
  taxes: number

  @IsNotEmpty()
  @Field(() => Number)
  fees: number

  @IsNotEmpty()
  @Field(() => Number)
  bookingFee: number

  @IsNotEmpty()
  @Field(() => Number)
  transactionFee: number

  @IsNotEmpty()
  @Field(() => Number)
  total: number
}

@ObjectType()
export class StripeSetupIntentEntity {
  @IsNotEmpty()
  @Field(() => String)
  clientSecret: string
}
