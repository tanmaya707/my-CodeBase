import { UseGuards } from '@nestjs/common'
import { Args, Mutation, Query, Resolver } from '@nestjs/graphql'
import { UserRole } from '@prisma/client'

import { CurrentUserDetails } from '@/common/decorators/current-user-details.decorator'
import { ErrorGraphqlHandlingDecorator } from '@/common/decorators/error-graphql-handling.decorator'
import { Roles } from '@/common/decorators/roles.decorator'
import { JwtAuthGuard } from '@/common/guards/jwt-auth.guard'
import { RolesGuard } from '@/common/guards/roles.guard'
import { MessageInterfaceEntity } from '@/common/interfaces/message.interface'
import { CheckoutTotalsInput } from '@/common/services/integrations/stripe/customers/dto/checkout.input'
import { CreatePaymentIntentInput } from '@/common/services/integrations/stripe/customers/dto/create-payment-intent.input'
import { SavePaymentMethodInput } from '@/common/services/integrations/stripe/customers/dto/save-payment-method.input'
import {
  CheckoutTotalsEntity,
  StripePaymentIntentEntity,
  StripePublicKeyEntity,
  StripeSetupIntentEntity,
} from '@/common/services/integrations/stripe/customers/entities/stripe-customers.entity'
import { StripePaymentMethodEntity } from '@/common/services/integrations/stripe/customers/entities/stripe-payment-methods.entity'
import { StripeCustomersService } from '@/common/services/integrations/stripe/customers/stripe-customers.service'
import { JwtTokenPayload } from '@/common/services/jwt-token/jwt-token.service'

@Resolver(() => MessageInterfaceEntity)
export class StripeCustomersResolver {
  constructor(private readonly stripeCustomersService: StripeCustomersService) {}

  @Roles(UserRole.GUEST)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Query(() => StripePaymentIntentEntity)
  @ErrorGraphqlHandlingDecorator(StripeCustomersResolver.name)
  paymentIntent(
    @CurrentUserDetails() userDetails: JwtTokenPayload,
    @Args('input') input: CreatePaymentIntentInput,
  ) {
    return this.stripeCustomersService.createPaymentIntent({
      userDetails,
      input,
    })
  }

  @UseGuards(JwtAuthGuard)
  @Query(() => CheckoutTotalsEntity)
  @ErrorGraphqlHandlingDecorator(StripeCustomersResolver.name)
  checkoutTotals(@Args('input') input: CheckoutTotalsInput) {
    return this.stripeCustomersService.getCheckoutTotals({ input })
  }

  @Roles(UserRole.GUEST)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Query(() => StripePublicKeyEntity)
  @ErrorGraphqlHandlingDecorator(StripeCustomersResolver.name)
  stripePublicKey() {
    return { publishableKey: this.stripeCustomersService.getPublicKey() }
  }

  @Roles(UserRole.GUEST)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Query(() => [StripePaymentMethodEntity])
  @ErrorGraphqlHandlingDecorator(StripeCustomersResolver.name)
  stripePaymentMethods(@CurrentUserDetails() userDetails: JwtTokenPayload) {
    return this.stripeCustomersService.getPaymentMethods(userDetails)
  }

  @Roles(UserRole.GUEST)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Query(() => StripeSetupIntentEntity)
  @ErrorGraphqlHandlingDecorator(StripeCustomersResolver.name)
  createSetupIntent(@CurrentUserDetails() userDetails: JwtTokenPayload) {
    return this.stripeCustomersService.createSetupIntent(userDetails)
  }

  @Roles(UserRole.GUEST)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Mutation(() => MessageInterfaceEntity)
  @ErrorGraphqlHandlingDecorator(StripeCustomersResolver.name)
  async savePaymentMethod(
    @Args('input') input: SavePaymentMethodInput,
    @CurrentUserDetails() userDetails: JwtTokenPayload,
  ): Promise<MessageInterfaceEntity> {
    await this.stripeCustomersService.savePaymentMethod(userDetails, input.paymentMethodId)
    return { message: 'Payment method saved!' }
  }
}
