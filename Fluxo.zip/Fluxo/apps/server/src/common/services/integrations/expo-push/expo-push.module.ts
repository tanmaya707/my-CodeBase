import { Module } from '@nestjs/common'

import { ExpoPushService } from '@/common/services/integrations/expo-push/expo-push.service'

@Module({
  providers: [ExpoPushService],
  exports: [ExpoPushService],
})
export class ExpoPushModule {}
