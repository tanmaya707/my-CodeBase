import { Field, InputType } from '@nestjs/graphql'
import { IsOptional } from 'class-validator'

@InputType()
export class GetAccountLinkInput {
  @IsOptional()
  @Field(() => String, { nullable: true })
  refreshUrl?: string

  @IsOptional()
  @Field(() => String, { nullable: true })
  returnUrl?: string
}
