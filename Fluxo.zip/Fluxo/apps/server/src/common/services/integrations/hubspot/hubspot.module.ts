import { Module } from '@nestjs/common'

import { HubspotListener } from '@/common/services/integrations/hubspot/hubspot.listener'
import { PropertiesModule } from '@/resources/properties/properties.module'

@Module({
  imports: [PropertiesModule],
  providers: [HubspotListener],
  exports: [],
})
export class HubspotModule {}
