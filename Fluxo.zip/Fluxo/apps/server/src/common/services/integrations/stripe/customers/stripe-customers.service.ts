import { BadRequestException, Injectable, Logger, NotFoundException } from '@nestjs/common'
import { ConfigService } from '@nestjs/config'
import { BookingEntityType, BookingPassGroup, Guest, PaymentStatus } from '@prisma/client'
import Stripe from 'stripe'

import { AppConfig } from '@/common/config/configuration'
import {
  DEFAULT_HOST_COMMISSION_PERCENTAGE,
  FLUXO_FEE_FIXED,
  FLUXO_FEE_PERCENTAGE,
  STRIPE_CHECKOUT_TRANSACTION_FEE_FIXED,
  STRIPE_CHECKOUT_TRANSACTION_FEE_PERCENTAGE,
} from '@/common/services/integrations/stripe/config'
import {
  AddressInput,
  CheckoutTotalsInput,
} from '@/common/services/integrations/stripe/customers/dto/checkout.input'
import { CreatePaymentIntentInput } from '@/common/services/integrations/stripe/customers/dto/create-payment-intent.input'
import {
  CheckoutTotalsEntity,
  StripeCustomersEntity,
} from '@/common/services/integrations/stripe/customers/entities/stripe-customers.entity'
import { JwtTokenPayload } from '@/common/services/jwt-token/jwt-token.service'
import { PrismaService } from '@/common/services/prisma/prisma.service'
import { UserEntity } from '@/resources/users/entities/user.entity'

@Injectable()
export class StripeCustomersService {
  private readonly stripeClient: Stripe
  private readonly logger = new Logger(StripeCustomersService.name)

  constructor(
    private configService: ConfigService<AppConfig>,
    private readonly prismaService: PrismaService,
  ) {
    const apiKey = this.configService.get('stripe.apiKey', { infer: true })
    this.stripeClient = new Stripe(apiKey ?? '')
  }

  async createCustomerAccount({
    user,
  }: {
    user: UserEntity & { guest: Guest | null }
  }): Promise<StripeCustomersEntity> {
    try {
      const { id: userId, email, firstName, lastName, guest } = user

      if (!guest) {
        this.logger.error(`Guest with user ID ${userId} not found`)
        throw new NotFoundException('Guest not found')
      }

      const account = await this.stripeClient.customers.create({
        email,
        name: `${firstName} ${lastName}`,
        ...(guest.phoneNumber && { phone: guest.phoneNumber }),
      })

      const customerAccount = await this.prismaService.stripeCustomer.create({
        data: {
          stripeId: account.id,
          guest: { connect: { id: guest.id } },
        },
      })

      this.logger.log('Successfully created Stripe customer account')
      return customerAccount
    } catch (error: unknown) {
      // Handle Stripe-related errors
      // eslint-disable-next-line @typescript-eslint/no-unnecessary-condition -- known
      if (error instanceof Error && 'type' in error && (error as Stripe.StripeRawError).type) {
        this.logger.error('Stripe API error', error)
        throw new Error('There was an issue creating the Stripe account, please try again later.')
      }

      if (error instanceof NotFoundException) {
        this.logger.error('Guest not found error', error)
        throw error
      }

      // Handle any other unexpected errors
      this.logger.error('Failed to create Stripe account', error)
      throw new Error('An unknown error occurred, please try again later.')
    }
  }

  async checkCustomerAccountCreated({ user }: { user: UserEntity }): Promise<void> {
    const guest = await this.prismaService.guest.findUnique({ where: { userId: user.id } })

    if (!guest) {
      this.logger.error(`Stripe customer account: Guest with user ID ${user.id} not found`)
      return // no exception, proceed any flow
    }

    const customerAccount = await this.prismaService.stripeCustomer.findUnique({
      where: { guestId: guest.id },
      select: { id: true, stripeId: true },
    })

    if (!customerAccount) {
      await this.createCustomerAccount({ user: { ...user, guest } })
    }
  }

  private async getCustomerAccount({ userId }: { userId: string }): Promise<StripeCustomersEntity> {
    const guest = await this.prismaService.guest.findUnique({ where: { userId } })

    if (!guest) {
      this.logger.error(`Guest with user ID ${userId} not found`)
      throw new NotFoundException('Guest not found')
    }

    const customerAccount = await this.prismaService.stripeCustomer.findUnique({
      where: { guestId: guest.id },
    })

    if (!customerAccount) {
      throw new Error(
        'Stripe customer account not found. Please try again later. If this problem persists, please contact support.',
      )
    }

    return customerAccount
  }

  async getCheckoutTotals({
    input,
  }: {
    input: CheckoutTotalsInput
  }): Promise<CheckoutTotalsEntity> {
    const basePrice = input.price

    const bookingFee = this.calculateBookingFee(basePrice)
    const priceForTaxes = basePrice + bookingFee
    const taxes = await this.calculateTaxes({
      price: priceForTaxes,
      address: input.propertyAddress,
    })
    const transactionFee = this.calculateStripeCheckoutTransactionFee({
      basePrice,
      bookingFee,
      salesTax: taxes,
    })

    const fees = transactionFee + bookingFee
    const total = basePrice + fees + taxes

    return { total, fees, taxes, transactionFee, bookingFee }
  }

  calculateBookingFee(price: number) {
    let bookingFee
    if (price * (FLUXO_FEE_PERCENTAGE / 100) < FLUXO_FEE_FIXED) {
      bookingFee = FLUXO_FEE_FIXED
    } else {
      bookingFee = (price / 100) * FLUXO_FEE_PERCENTAGE
    }
    return bookingFee
  }

  calculateStripeCheckoutTransactionFee({
    basePrice,
    bookingFee,
    salesTax,
  }: {
    basePrice: number
    bookingFee: number
    salesTax: number
  }) {
    const price = basePrice + bookingFee + salesTax
    // (Pgoal + Ffixed) / (1 - Fpercent)
    return Math.ceil(
      (price + STRIPE_CHECKOUT_TRANSACTION_FEE_FIXED) /
        (1 - STRIPE_CHECKOUT_TRANSACTION_FEE_PERCENTAGE / 100) -
        price,
    )
  }

  async createPaymentIntent({
    userDetails,
    input,
  }: {
    userDetails: JwtTokenPayload
    input: CreatePaymentIntentInput
  }) {
    const customer = await this.getCustomerAccount({ userId: userDetails.id })
    const businessAccount = await this.prismaService.stripeBusinessAccount.findUnique({
      where: { hostId: input.hostId },
    })

    if (!businessAccount) {
      throw new Error('Stripe business account not found.')
    }

    const host = await this.prismaService.host.findUnique({ where: { id: input.hostId } })
    if (!host) {
      throw new Error('Host account account not found.')
    }

    const ephemeralKey = await this.stripeClient.ephemeralKeys.create(
      { customer: customer.stripeId },
      { apiVersion: '2024-11-20.acacia' },
    )

    const paymentIntent = await this.stripeClient.paymentIntents.create({
      amount: Math.ceil(input.total),
      currency: 'usd',
      customer: customer.stripeId,
      capture_method: 'manual',
      automatic_payment_methods: {
        enabled: true,
      },
      // application_fee_amount: Math.round(
      //   input.basePrice * (host.commissionRate || DEFAULT_HOST_COMMISSION_PERCENTAGE),
      // ),
      transfer_data: {
        amount:
          input.basePrice -
          input.basePrice * (host.commissionRate || DEFAULT_HOST_COMMISSION_PERCENTAGE),
        destination: businessAccount.stripeId,
      },
      metadata: {
        venueName: input.venueName,
        hostId: input.hostId,
      },
    })

    const customerSession = await this.stripeClient.customerSessions.create({
      customer: customer.stripeId,
      components: {
        payment_element: {
          enabled: true,
          features: {
            payment_method_redisplay: 'enabled',
            payment_method_save: 'enabled',
            payment_method_save_usage: 'on_session',
            payment_method_remove: 'enabled',
          },
        },
      },
    })

    return {
      clientSecret: paymentIntent.client_secret,
      paymentIntentId: paymentIntent.id,
      customerSessionClientSecret: customerSession.client_secret,
      ephemeralKey: ephemeralKey.secret,
      customerId: customer.stripeId,
    }
  }

  async calculateTaxes({ price, address }: { price: number; address: AddressInput }) {
    const calculation = await this.stripeClient.tax.calculations.create({
      currency: 'usd',
      line_items: [
        {
          amount: price,
          reference: 'L1',
        },
      ],
      customer_details: {
        address,
        address_source: 'billing',
      },
      expand: ['line_items'],
    })
    return calculation.tax_amount_exclusive
  }

  async submitBookingPayment({
    paymentIntentId,
    confirmationNumbers,
    bookingEntityType,
    bookingGroupId,
    userId,
    basePrice,
    totalBasePrice,
    addressForTaxes,
    onPaymentFailure,
  }: {
    paymentIntentId: string
    confirmationNumbers: string
    bookingEntityType: BookingEntityType
    bookingGroupId: string
    userId: string
    basePrice: number
    totalBasePrice: number
    addressForTaxes: AddressInput
    onPaymentFailure?: () => Promise<void>
  }) {
    try {
      const bookingFee = this.calculateBookingFee(totalBasePrice)
      const priceForTaxes = totalBasePrice + bookingFee
      // TODO: addressForTaxes remove from input and create address object on venue creation (remove geocoding on FE accordingly)
      const taxes = await this.calculateTaxes({ price: priceForTaxes, address: addressForTaxes })

      const capture = await this.stripeClient.paymentIntents.capture(paymentIntentId, {
        metadata: {
          confirmationNumbers,
          bookingEntityType,
          bookingGroupId,
          userId,
          basePrice,
          taxes,
        },
      })

      await this.prismaService.bookingPassGroup.update({
        where: { id: bookingGroupId },
        data: {
          paymentCreatedAt: new Date(),
          paymentCapturedAt: capture.status.toUpperCase() === 'SUCCEEDED' ? new Date() : null,
          paymentStatus: capture.status.toUpperCase() as PaymentStatus,
        },
      })
    } catch (error: unknown) {
      if (onPaymentFailure) await onPaymentFailure()
      this.logger.error('Failed capturing payment')
      throw error
    }
  }

  async refund(bookingGroup: BookingPassGroup) {
    if (!bookingGroup.paymentIntentId) {
      throw new BadRequestException("Can't find payment intent id for refund")
    }
    if (!bookingGroup.baseTotalPrice) {
      throw new BadRequestException('No price saved for refund')
    }
    try {
      const paymentIntent = await this.stripeClient.paymentIntents.retrieve(
        bookingGroup.paymentIntentId,
      )
      const chargeId = paymentIntent.latest_charge as string

      const refund = await this.stripeClient.refunds.create({
        charge: chargeId,
        amount: bookingGroup.baseTotalPrice + (bookingGroup.taxes ?? 0),
        reason: 'requested_by_customer',
        reverse_transfer: true,
      })

      await this.prismaService.bookingPassGroup.update({
        where: { id: bookingGroup.id },
        data: {
          refunded: refund.status === 'succeeded',
          refundedAmount: refund.amount,
        },
      })
    } catch (error: unknown) {
      this.logger.error('Failed to make refund')
      throw error
    }
  }

  async createSetupIntent(userDetails: JwtTokenPayload) {
    const customer = await this.getCustomerAccount({ userId: userDetails.id })

    const setupIntent = await this.stripeClient.setupIntents.create({
      customer: customer.stripeId,
      automatic_payment_methods: {
        enabled: true,
      },
    })
    return { clientSecret: setupIntent.client_secret }
  }

  async savePaymentMethod(userDetails: JwtTokenPayload, paymentMethodId: string) {
    const customer = await this.getCustomerAccount({ userId: userDetails.id })
    await this.prismaService.stripeCustomerPaymentMethods.create({
      data: {
        paymentMethodId,
        customerId: customer.id,
      },
    })
  }

  async getPaymentMethods(userDetails: JwtTokenPayload) {
    try {
      const customer = await this.getCustomerAccount({ userId: userDetails.id })
      const customerPaymentMethods = await this.prismaService.stripeCustomerPaymentMethods.findMany(
        {
          where: {
            customerId: customer.id,
          },
        },
      )
      const savedPaymentMethodIds = customerPaymentMethods.map((method) => method.paymentMethodId)

      const stripePaymentMethods = await this.stripeClient.paymentMethods.list({
        customer: customer.stripeId,
      })

      // Only include methods saved in the database
      return stripePaymentMethods.data
        .filter((pm) => savedPaymentMethodIds.includes(pm.id))
        .map((pm) => ({
          id: pm.id,
          brand: pm.card?.brand,
          last4: pm.card?.last4,
          exp_month: pm.card?.exp_month,
          exp_year: pm.card?.exp_year,
          type: pm.type,
        }))
    } catch (error) {
      this.logger.error(`Failed to make refund - ${error}`)
      throw error
    }
  }

  getPublicKey() {
    return this.configService.get('stripe.publicApiKey', { infer: true })
  }

  public async getUserIdByStripeId(stripeId: string) {
    const stripeCustomerAccount = await this.prismaService.stripeCustomer.findUnique({
      where: { stripeId },
      select: {
        id: true,
        guest: {
          select: {
            id: true,
            user: {
              select: {
                id: true,
              },
            },
          },
        },
      },
    })

    if (!stripeCustomerAccount) {
      this.logger.error(`Stripe Customer Account with ID ${stripeId} not found`)

      return ''
    }

    return stripeCustomerAccount.guest?.user.id ?? ''
  }
}
