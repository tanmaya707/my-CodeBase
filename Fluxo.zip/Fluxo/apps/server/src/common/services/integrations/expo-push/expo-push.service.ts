import { Injectable, Logger } from '@nestjs/common'
import { ConfigService } from '@nestjs/config'
import { Expo, ExpoPushMessage } from 'expo-server-sdk'

import type { AppConfig } from '@/common/config/configuration'
import { PrismaService } from '@/common/services/prisma/prisma.service'

@Injectable()
export class ExpoPushService {
  private readonly logger = new Logger(ExpoPushService.name)
  private readonly expo: Expo

  constructor(
    private readonly configService: ConfigService<AppConfig>,
    private readonly prismaService: PrismaService,
  ) {
    this.expo = new Expo({
      accessToken: this.configService.get('expoPush.accessToken', { infer: true }),
    })
    this.prismaService = prismaService
  }

  public async sendAsync(pushToken: string, message: string, data: string, title: string) {
    if (!Expo.isExpoPushToken(pushToken)) {
      this.logger.warn(`Expo Push token ${pushToken} is not valid!`)
      return
    }

    const pushMessage: ExpoPushMessage = {
      to: pushToken,
      sound: 'default',
      body: message,
      data: JSON.parse(data),
      title,
    }

    try {
      const tickets = await this.expo.sendPushNotificationsAsync([pushMessage])

      for (const ticket of tickets) {
        if (ticket.status === 'error' && ticket.details?.error === 'DeviceNotRegistered') {
          await this.prismaService.user.updateMany({
            where: { expoPushToken: pushToken },
            data: { expoPushToken: null },
          })
          this.logger.log('Removed Expo Push Token for users with Push Token: ', pushToken)
        }
      }

      this.logger.log('Expo Push notification sent:', tickets)
    } catch (error) {
      this.logger.error('Error sending push notification:', error)
    }
  }
}
