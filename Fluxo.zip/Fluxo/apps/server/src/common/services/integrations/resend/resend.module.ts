import { Module } from '@nestjs/common'

import { ResendService } from '@/common/services/integrations/resend/resend.service'

@Module({
  providers: [ResendService],
  exports: [ResendService],
})
export class ResendModule {}
