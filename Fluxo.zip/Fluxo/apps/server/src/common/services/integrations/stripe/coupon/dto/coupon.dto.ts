import { IsString, IsNumber, IsOptional, IsBoolean } from 'class-validator';

export class CreateCouponDto {
    @IsString()
    id: string;

    @IsOptional()
    @IsString()
    name?: string;

    @IsNumber()
    percent_off: number;

    @IsBoolean()
    @IsOptional()
    valid?: boolean;
}
