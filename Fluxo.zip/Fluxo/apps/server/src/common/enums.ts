export enum Events {
  HOST_PROFILE_CREATED = 'host.profile.created',
  HOST_PROFILE_UPDATED = 'host.profile.updated',
  HOST_ACCOUNT_DEACTIVATED = 'host.account.deactivated',
  HOST_ACCOUNT_PAUSED = 'host.account.paused',
  HOST_ACCOUNT_UNPAUSED = 'host.account.unpaused',
  HOST_BOOKING_CONFIRMED = 'host.booking.confirmed',
  HOST_BOOKING_REQUEST = 'host.booking.request',
  HOST_BOOKING_CANCELED = 'host.booking.canceled',
  HOST_PAYOUT_COMPLETED = 'host.payout.completed',
  HOST_STRIPE_STATUS_CHANGED = 'host.stripe.status.changed',
  GUEST_PROFILE_CREATED = 'guest.profile.created',
  GUEST_PROFILE_UPDATED = 'guest.profile.updated',
  GUEST_ACCOUNT_DEACTIVATED = 'guest.account.deactivated',
  GUEST_BOOKING_CONFIRMED = 'guest.booking.confirmed',
  GUEST_BOOKING_CANCELED = 'guest.booking.canceled',
  GUEST_BOOKING_REQUEST_APPROVED = 'guest.booking.request.approved',
  GUEST_BOOKING_REQUEST_DECLINED = 'guest.booking.request.declined',
  GUEST_CHECKED_IN = 'guest.checked.in',
  GUEST_CHECKED_OUT = 'guest.checked.out',
  PROPERTY_CREATED = 'property.created',
  PROPERTY_UPDATED = 'property.updated',
  SPACE_ADDED = 'space.added',
  SPACE_DELETED = 'space.deleted',
  DAY_PASS_UPDATED = 'day_pass.updated',
  NOTIFICATION_CREATED = 'notification.created',
}

export enum BookingType {
  DAY_PASS,
  SPACES,
}

export enum BookingTimeline {
  PAST,
  UPCOMING,
  PENDING,
}

export enum PropertiesSort {
  RATING,
  PRICE,
  DISTANCE,
}

export enum PriceRange {
  ONE_DOLLAR,
  TWO_DOLLARS,
  THREE_DOLLARS,
  FOUR_DOLLARS,
}

export enum StripeConnectAccountStatus {
  VERIFIED = 'verified',
  PENDING = 'pending',
  DISABLED = 'disabled',
}
