import { Field, ObjectType } from '@nestjs/graphql'

@ObjectType()
export class TotalInterface {
  @Field()
  total: number
}
