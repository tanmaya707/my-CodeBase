import { BookingStatus, type Host, HostStatus } from '@prisma/client'

import { PriceRange } from '@/common/enums'

export function isEmpty(value: unknown): boolean {
  return Boolean(value && Object.keys(value).length === 0)
}

export function milesToMeters(miles: number) {
  const METERS_IN_ONE_MILE = 1609.344

  return miles * METERS_IN_ONE_MILE
}

export function metersToMiles(meters: number): number {
  const MILES_IN_ONE_METER = 1 / 1609.344

  return Math.round(meters * MILES_IN_ONE_METER * 100) / 100
}

export function isPropertyInactive(host?: Pick<Host, 'status'> | null) {
  return isEmpty(host) || host?.status === HostStatus.PAUSED
}

export const availabilityTimeFormatRegex =
  /^(?<hours>0[1-9]|1[0-2]):(?<minutes>[0-5][0-9])\s?(?<period>AM|PM)$/i

export function extractLatitudeAndLongitude(point?: string): {
  latitude: string
  longitude: string
} {
  if (!point) {
    return { latitude: '', longitude: '' }
  }

  const regex = /POINT\((?<latitude>[-\d.]+) (?<longitude>[-\d.]+)\)/
  const match = regex.exec(point)

  return { latitude: match?.[1] ?? '', longitude: match?.[2] ?? '' }
}

export function convertCentsToUnits(cents: number) {
  return cents / 100
}

export const PriceRangeLimits = {
  [PriceRange.ONE_DOLLAR]: { min: 0, max: 2500 },
  [PriceRange.TWO_DOLLARS]: { min: 2501, max: 5000 },
  [PriceRange.THREE_DOLLARS]: { min: 5001, max: 10000 },
  [PriceRange.FOUR_DOLLARS]: { min: 10001, max: null },
}

export const bookingStatusTransitions: Record<BookingStatus, BookingStatus[]> = {
  [BookingStatus.PENCIL]: [
    BookingStatus.CONFIRMED,
    BookingStatus.CANCELED_BY_HOST,
    BookingStatus.CANCELED_BY_SYSTEM,
  ],
  [BookingStatus.PENCIL_RTB]: [
    BookingStatus.CONFIRMED,
    BookingStatus.CANCELED_BY_HOST,
    BookingStatus.CANCELED_BY_GUEST,
    BookingStatus.CANCELED_BY_SYSTEM,
  ],
  [BookingStatus.ARRIVED]: [BookingStatus.DEPARTED],
  [BookingStatus.CONFIRMED]: [
    BookingStatus.ARRIVED,
    BookingStatus.CANCELED_BY_GUEST,
    BookingStatus.CANCELED_BY_HOST,
    BookingStatus.CANCELED_BY_SYSTEM,
    BookingStatus.NO_SHOW,
  ],
  [BookingStatus.CANCELED_BY_GUEST]: [],
  [BookingStatus.CANCELED_BY_HOST]: [],
  [BookingStatus.CANCELED_BY_SYSTEM]: [],
  [BookingStatus.NO_SHOW]: [],
  [BookingStatus.DEPARTED]: [],
}

export const blockingBookingStatuses = [
  BookingStatus.CONFIRMED,
  BookingStatus.ARRIVED,
  BookingStatus.PENCIL,
  BookingStatus.PENCIL_RTB,
]
