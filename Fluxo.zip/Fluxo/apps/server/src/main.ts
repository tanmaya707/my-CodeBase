import './instrument'

import compression from '@fastify/compress'
import cookieFastify from '@fastify/cookie'
import { Catch, ValidationPipe } from '@nestjs/common'
import { ConfigService } from '@nestjs/config'
import { BaseExceptionFilter, NestFactory } from '@nestjs/core'
import { FastifyAdapter, type NestFastifyApplication } from '@nestjs/platform-fastify'
import * as Sentry from '@sentry/node'

import { AppModule } from '@/app.module'
import { type AppConfig } from '@/common/config/configuration'

@Catch()
export class SentryExceptionFilter extends BaseExceptionFilter {
  catch(exception: unknown) {
    Sentry.captureException(exception)
  }
}

async function bootstrap(): Promise<void> {
  const app = await NestFactory.create<NestFastifyApplication>(AppModule, new FastifyAdapter(), {
    rawBody: true,
  })
  const configService = app.get(ConfigService<AppConfig>)

  const cookieSecret = configService.get('secrets.cookie', { infer: true })

  app.enableCors(configService.get('app.corsConfig', { infer: true }))

  await app.register(cookieFastify, { secret: cookieSecret })
  await app.register(compression, { encodings: ['gzip', 'deflate'] })

  app.useGlobalFilters(new SentryExceptionFilter(app.getHttpAdapter()))

  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      stopAtFirstError: true,
      transform: true,
    }),
  )
  await app.listen(4000, '0.0.0.0')
}

void bootstrap().catch((error: unknown) => {
  // eslint-disable-next-line no-console -- bootstrap failure error
  console.error('--- server error: ', error)
})
