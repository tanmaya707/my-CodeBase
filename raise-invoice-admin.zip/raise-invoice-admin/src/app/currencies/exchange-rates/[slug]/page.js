"use client";

import { Breadcrumb } from "react-bootstrap";
import ExchangeRatesTable from "@/components/Currency/ExchangeRatesTable";

export default function Page() {
  return (
    <>
      <div className="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-4">
        <h3 className="mb-0">Exchange Rates</h3>

        <Breadcrumb className="breadcrumb-page-list align-items-center mb-0 lh-1">
          <Breadcrumb.Item href="/dashboard/">
            <div className="d-flex text-decoration-none">
              <i className="ri-home-4-line fs-18 text-primary me-1"></i>
              <span className="text-secondary fw-medium hover">Dashboard</span>
            </div>
          </Breadcrumb.Item>
          <Breadcrumb.Item href="/currencies/list/" aria-label="Currency List">
            <span className="text-secondary fw-medium hover">Currency List</span>
          </Breadcrumb.Item>
          <Breadcrumb.Item active>
            <span className="fw-medium">Exchange Rates</span>
          </Breadcrumb.Item>
        </Breadcrumb>
      </div>

      <ExchangeRatesTable />
    </>
  );
}
