import SignUpForm from "@/components/Authentication/SignUpForm";

export default function Page() {
  return (
    <>
      <SignUpForm />
    </>
  );
}
