"use client";

import { Breadcrumb } from "react-bootstrap";
import ViewJobCategory from "@/components/Jobs/ViewJobCategory";
import { useParams } from 'next/navigation';

export default function Page() {
  const { uuid } = useParams();
  return (
    <>
      <div className="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-4">
        <h3 className="mb-0">View Job Category</h3>
 
        <Breadcrumb className="breadcrumb-page-list align-items-center mb-0 lh-1">
          <Breadcrumb.Item href="/dashboard/">
            <div className="d-flex text-decoration-none">
              <i className="ri-home-4-line fs-18 text-primary me-1"></i>
              <span className="text-secondary fw-medium hover">Dashboard</span>
            </div>
          </Breadcrumb.Item>

          <Breadcrumb.Item href="/jobs/job-categories/">
            <span className="text-secondary fw-medium hover">Job Categories</span>
          </Breadcrumb.Item>

          <Breadcrumb.Item active>
            <span className="fw-medium">View Job Category</span>
          </Breadcrumb.Item>
        </Breadcrumb>
      </div> 

      <ViewJobCategory uuid={uuid} />
    </>
  );
}
