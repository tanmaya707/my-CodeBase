"use client";

import { Row, Col, Card, Form } from "react-bootstrap";
import React, {useState, useEffect} from 'react';
import apiConnection from "../../../utils/apiConnection";

const ViewContact = ({uuid}) => {
  var [state, setState] = useState({
    name: '',
    email: '',
    // phone: '',
    location: '',
    company: '',
    message: '',
  });
  var { name, email, location, company, message } = state;

  const getEnquiryDetails = async () => {
    try {
        const enquiryResponse = await apiConnection.post('get-enquiry-details', {uuid: uuid})
        if(enquiryResponse?.data?.status){
          let enquiryData = enquiryResponse?.data?.data;
          setState(prevState => ({
            ...prevState,
            name: enquiryData?.name,
            email: enquiryData?.email,
            // phone: enquiryData?.phone,
            location: enquiryData?.country?.name,
            company: enquiryData?.companyName,
            message: enquiryData?.message
          }));
          await apiConnection.post('mark-enquiry-read', { enquiryIds: [enquiryData?.id] })
        }
    } catch (error) {
        console.log('error', error);
    }
  };
  useEffect(() => {
    getEnquiryDetails()    
  }, 
  [])

  return (
    <>
      <Row>
        <Col lg={8}>
          <Card className="bg-white border-0 rounded-3 mb-4">
            <Card.Body className="p-4">
              <Row>
                <Col sm={12} lg={12}>
                  <Form.Group className="mb-4">
                    <label className="label text-secondary">Title</label>
                    <h3>{name}</h3>
                  </Form.Group>
                </Col>
                <Col sm={12} lg={12}>
                  <Form.Group className="mb-4">
                    <label className="label text-secondary">
                      Message
                    </label>
                    <p>{message}</p>
                  </Form.Group>
                </Col>
                
              </Row>
            </Card.Body>
          </Card>
        </Col>
        
        <Col lg={4}>
          <Card className="bg-white border-0 rounded-3 mb-4">
            <Card.Body className="p-4">
              <h3 className="mb-4">Contact Info</h3>
              <Row>
                <Col sm={5} lg={5}>
                  <label className="label text-secondary">Email</label>
                </Col>
                <Col sm={7} lg={7}>
                  <p><a href={`mailto:${email}`}>{email}</a></p>
                </Col>
                {/* <Col sm={5} lg={5}>
                  <label className="label text-secondary">Phone</label>
                </Col>
                <Col sm={7} lg={7}>
                  <p><a href={`tel:${phone}`}>{phone}</a></p>
                </Col> */}
                <Col sm={5} lg={5}>
                  <label className="label text-secondary">Company Name</label>
                </Col>
                <Col sm={7} lg={7}>
                  <p>{company}</p>
                </Col>
                <Col sm={5} lg={5}>
                  <label className="label text-secondary">Location</label>
                </Col>
                <Col sm={7} lg={7}>
                  <p>{location}</p>
                </Col>
              </Row>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </>
  );
};

export default ViewContact;
