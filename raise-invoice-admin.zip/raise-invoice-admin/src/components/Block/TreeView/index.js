import React, { useState, useEffect } from 'react';
// import { DragDropContext, Droppable, Draggable } from 'react-beautiful-dnd';
import '../../../../styles/TreeView.css';
import { useParams } from 'next/navigation';
import apiConnection from "../../../utils/apiConnection";
import { confirmAlert } from 'react-confirm-alert';
import 'react-confirm-alert/src/react-confirm-alert.css';
import { ToastContainer, toast } from "react-toastify";

import dynamic from 'next/dynamic';

const DragDropContext = dynamic(
    async () => {
        const mod = await import('react-beautiful-dnd');
        return mod.DragDropContext;
    },
    { ssr: false },
);
const Droppable = dynamic(
    async () => {
        const mod = await import('react-beautiful-dnd');
        return mod.Droppable;
    },
    { ssr: false },
);
const Draggable = dynamic(
    async () => {
        const mod = await import('react-beautiful-dnd');
        return mod.Draggable;
    },
    { ssr: false },
);

const TreeNode = ({ node, index }) => {
    const [isOpen, setIsOpen] = useState(false);

    const toggleOpen = () => {
        setIsOpen(!isOpen);
    };

    return (
        <Draggable draggableId={node.id} index={index}>
            {(provided) => (
                <div
                    ref={provided.innerRef}
                    {...provided.draggableProps}
                    {...provided.dragHandleProps}
                    className="tree-node"
                >
                    <div onClick={toggleOpen} className="tree-node-icon">
                        {node?.children?.length > 0 && (isOpen ? '[-]' : '[+]')}
                    </div>
                    <div className="tree-node-name">{node.order_number}. {node.title}</div>
                    {isOpen && node?.children?.length > 0 && (
                        <div>
                            {node?.children.map((child, idx) => (
                                <TreeNode key={child.id} node={child} index={idx} />
                            ))}
                        </div>
                    )}
                </div>
            )}
        </Draggable>
    );
};

const TreeView = () => {
    const [folderData, setFolderData] = useState([]);
    const { uuid } = useParams();

    const getBlockList = async () => {
        try {
            const response = await apiConnection.post('get-block-list', { page_id: uuid });
            // Assuming the API returns a structure compatible with the TreeNode
            setFolderData(response.data.data || []);
        } catch (error) {
            console.error('Error fetching block list:', error);
        }
    };

    const handleDelete = async (e, uuid) => {
        confirmAlert({
            title: 'Confirm to delete',
            message: 'Are you sure to do this.',
            buttons: [
                {
                    label: 'Yes',
                    onClick: async () => {
                        try {
                            const response = await apiConnection.post('delete-block', { uuid: uuid });
                            if (response?.data?.status) {
                                toast.success("Block deleted successfully");
                                // Refresh the block list after deletion
                                getBlockList();
                            }
                        } catch (error) {
                            console.error('Error deleting block data:', error);
                        }
                    }
                },
                {
                    label: 'No'
                }
            ]
        });
    };

    useEffect(() => {
        getBlockList();
    }, [uuid]);

    const onDragEnd = (result) => {
        if (!result.destination) return;

        const items = Array.from(folderData);
        const [reorderedItem] = items.splice(result.source.index, 1);
        items.splice(result.destination.index, 0, reorderedItem);

        setFolderData(items);

        // Accessing the ID of the dragged item
        const draggedItemId = result.draggableId;
        console.log(`Dragged item ID: ${draggedItemId}`);
        console.log(`Moved from index: ${result.source.index} to index: ${result.destination.index}`);
    };
    console.log(folderData);

    return (
        <DragDropContext onDragEnd={onDragEnd}>
            <Droppable droppableId="droppable">
                {(provided) => (
                    <div
                        ref={provided.innerRef}
                        {...provided.droppableProps}
                        className="tree-view"
                    >
                        {folderData.map((folder, index) => (
                            <TreeNode key={folder.id} node={folder} index={index} />
                        ))}
                        {provided.placeholder}
                    </div>
                )}
            </Droppable>
        </DragDropContext>
    );
};

export default TreeView;