const sharp = require('sharp');

async function computeImageSignature(buffer) {
  try {
    const rotations = [0, 90, 180, 270];
    const dhashes = [];

    for (const angle of rotations) {
      const { data } = await sharp(buffer)
        .rotate(angle)
        .grayscale()
        .resize(9, 8, { fit: 'fill' })
        .raw()
        .toBuffer({ resolveWithObject: true });

      let h = '';
      for (let r = 0; r < 8; r++) {
        for (let c = 0; c < 8; c++) {
          h += data[r * 9 + c] < data[r * 9 + c + 1] ? '1' : '0';
        }
      }
      dhashes.push({ angle, hash: h });
    }

    const { data: rgbData } = await sharp(buffer)
      .resize(64, 64, { fit: 'fill' })
      .raw()
      .toBuffer({ resolveWithObject: true });

    const colorHist = new Float32Array(64);
    const bgHist = new Float32Array(64);
    const centerHist = new Float32Array(64);
    let bgCount = 0;
    let centerCount = 0;
    const borderThickness = 12;

    for (let y = 0; y < 64; y++) {
      for (let x = 0; x < 64; x++) {
        const idx = (y * 64 + x) * 3;
        const r = Math.min(3, Math.floor(rgbData[idx] / 64));
        const g = Math.min(3, Math.floor(rgbData[idx + 1] / 64));
        const b = Math.min(3, Math.floor(rgbData[idx + 2] / 64));
        const binIdx = (r * 16) + (g * 4) + b;
        colorHist[binIdx]++;

        const isBorder = (y < borderThickness || y >= 64 - borderThickness || x < borderThickness || x >= 64 - borderThickness);
        if (isBorder) {
          bgHist[binIdx]++;
          bgCount++;
        }

        const isCenter = (y >= 16 && y < 48 && x >= 16 && x < 48);
        if (isCenter) {
          centerHist[binIdx]++;
          centerCount++;
        }
      }
    }

    for (let i = 0; i < 64; i++) {
      colorHist[i] /= 4096;
      bgHist[i] /= (bgCount || 1);
      centerHist[i] /= (centerCount || 1);
    }

    return {
      dhashes,
      primaryDHash: dhashes[0].hash,
      colorHist: Array.from(colorHist),
      bgHist: Array.from(bgHist),
      centerHist: Array.from(centerHist),
    };
  } catch (err) {
    console.error('Error computing image signature:', err.message);
    return null;
  }
}

function cosineSimilarity(a, b) {
  if (!a || !b || a.length !== b.length) return 0;
  let dot = 0, nA = 0, nB = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    nA += a[i] * a[i];
    nB += b[i] * b[i];
  }
  const denom = Math.sqrt(nA) * Math.sqrt(nB);
  return denom === 0 ? 0 : dot / denom;
}

function hammingDistance(a, b) {
  if (!a || !b) return 64;
  let dist = 0;
  for (let i = 0; i < a.length; i++) {
    if (a[i] !== b[i]) dist++;
  }
  return dist;
}

function evaluateSimilarity(sig1, sig2) {
  if (!sig1 || !sig2) {
    return { isDuplicate: false, matchType: null, confidencePct: 0, reason: '' };
  }

  let minDistance = Infinity;
  let bestAngle = 0;
  for (const r1 of (sig1.dhashes || [])) {
    for (const r2 of (sig2.dhashes || [])) {
      const dist = hammingDistance(r1.hash, r2.hash);
      if (dist < minDistance) {
        minDistance = dist;
        bestAngle = (r2.angle - r1.angle + 360) % 360;
      }
    }
  }

  const colorSim = cosineSimilarity(sig1.colorHist, sig2.colorHist);
  const bgSim = cosineSimilarity(sig1.bgHist, sig2.bgHist);
  const centerSim = cosineSimilarity(sig1.centerHist, sig2.centerHist);

  const isDirectStructuralMatch = minDistance <= 10;
  const isRotatedStructuralMatch = minDistance <= 15 && colorSim >= 0.70;
  const isSameBackgroundAndSubject = bgSim >= 0.80 && colorSim >= 0.80 && centerSim >= 0.80;

  let isDuplicate = false;
  let matchType = null;
  let confidencePct = 0;
  let reason = '';

  if (isDirectStructuralMatch) {
    isDuplicate = true;
    matchType = 'similar';
    confidencePct = Math.round(((64 - minDistance) / 64) * 100);
    reason = `Visual Structure Match (${confidencePct}%)`;
  } else if (isRotatedStructuralMatch) {
    isDuplicate = true;
    matchType = 'similar';
    confidencePct = Math.round((((64 - minDistance) / 64) * 0.5 + colorSim * 0.5) * 100);
    reason = `Rotated (${bestAngle}°) Match (${confidencePct}%)`;
  } else if (isSameBackgroundAndSubject) {
    isDuplicate = true;
    matchType = 'similar';
    confidencePct = Math.round((bgSim * 0.4 + centerSim * 0.35 + colorSim * 0.25) * 100);
    reason = `Same Background & Subject (${Math.round(bgSim * 100)}% background match)`;
  }

  return {
    isDuplicate,
    matchType,
    confidencePct,
    reason,
    minDistance: minDistance === Infinity ? 64 : minDistance,
    bestAngle,
    colorSim: Math.round(colorSim * 100),
    bgSim: Math.round(bgSim * 100),
    centerSim: Math.round(centerSim * 100),
  };
}

module.exports = {
  computeImageSignature,
  evaluateSimilarity,
  cosineSimilarity,
  hammingDistance,
};
