const Datastore = require('nedb-promises');
const path = require('path');

const imagesDb = Datastore.create({
  filename: path.join(__dirname, 'data', 'images.db'),
  autoload: true,
});

const duplicatesDb = Datastore.create({
  filename: path.join(__dirname, 'data', 'duplicates.db'),
  autoload: true,
});

module.exports = imagesDb;
module.exports.imagesDb = imagesDb;
module.exports.duplicatesDb = duplicatesDb;

