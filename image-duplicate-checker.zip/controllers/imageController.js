const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const { imagesDb, duplicatesDb } = require('../db');
const { computeImageSignature, evaluateSimilarity } = require('../phash');

const UPLOAD_DIR = path.join(__dirname, '..', 'public', 'uploads');

async function ensureDocSignature(doc) {
  if (doc.sig && doc.sig.colorHist && doc.sig.bgHist && doc.sig.centerHist) return doc.sig;
  if (!doc.filename) return null;
  const filePath = path.join(UPLOAD_DIR, doc.filename);
  if (!fs.existsSync(filePath)) return null;
  try {
    const buf = fs.readFileSync(filePath);
    const sha256 = crypto.createHash('sha256').update(buf).digest('hex');
    const md5 = crypto.createHash('md5').update(buf).digest('hex');
    const sig = await computeImageSignature(buf);
    if (sig) {
      await imagesDb.update(
        { _id: doc._id },
        { $set: { sha256, md5, sig, dhash: sig.primaryDHash } }
      );
      doc.sha256 = sha256;
      doc.md5 = md5;
      doc.sig = sig;
      doc.dhash = sig.primaryDHash;
    }
    return sig;
  } catch (e) {
    return null;
  }
}

async function renderHome(req, res) {
  try {
    const totalUnique = await imagesDb.count({});
    const totalDuplicates = await duplicatesDb.count({});
    const recentUnique = await imagesDb.find({}).sort({ uploadedAt: -1 }).limit(12);

    res.render('index', {
      unique: recentUnique,
      duplicates: [],
      justUploaded: false,
      batchStats: null,
      stats: {
        totalUnique,
        totalDuplicates,
        totalProcessed: totalUnique + totalDuplicates,
      },
    });
  } catch (err) {
    console.error('Error loading home page:', err);
    res.status(500).send('Internal server error');
  }
}

async function handleUpload(req, res) {
  try {
    const files = req.files || [];
    const batchDuplicates = [];
    const batchUnique = [];
    const existingDocs = await imagesDb.find({});

    for (const doc of existingDocs) {
      await ensureDocSignature(doc);
    }

    for (const file of files) {
      const ext = path.extname(file.originalname) || '.jpg';
      const md5 = crypto.createHash('md5').update(file.buffer).digest('hex');
      const sha256 = crypto.createHash('sha256').update(file.buffer).digest('hex');
      const filename = `${md5}${ext}`;
      const filePath = path.join(UPLOAD_DIR, filename);

      if (!fs.existsSync(filePath)) {
        fs.writeFileSync(filePath, file.buffer);
      }
      const ownUrl = `/uploads/${filename}`;

      const exactMatch = existingDocs.find(
        (doc) => (doc.sha256 && doc.sha256 === sha256) || (doc.md5 && doc.md5 === md5)
      );

      if (exactMatch) {
        const dupRecord = {
          originalName: file.originalname,
          filename,
          matchedWith: exactMatch.originalName,
          matchedFilename: exactMatch.filename,
          url: ownUrl,
          matchedUrl: exactMatch.url,
          type: 'exact',
          reason: 'Exact Match',
          distance: 0,
          similarityPct: 100,
          sha256,
          md5,
          size: file.size,
          uploadedAt: new Date(),
          isDuplicate: true,
        };
        const insertedDup = await duplicatesDb.insert(dupRecord);
        batchDuplicates.push(insertedDup);
        continue;
      }

      const sig = await computeImageSignature(file.buffer);
      let bestMatch = null;
      let bestEvaluation = null;

      if (sig) {
        for (const doc of existingDocs) {
          if (!doc.sig) continue;
          const evaluation = evaluateSimilarity(sig, doc.sig);
          if (evaluation.isDuplicate) {
            if (!bestEvaluation || evaluation.confidencePct > bestEvaluation.confidencePct) {
              bestEvaluation = evaluation;
              bestMatch = doc;
            }
          }
        }
      }

      if (bestMatch && bestEvaluation && bestEvaluation.isDuplicate) {
        const dupRecord = {
          originalName: file.originalname,
          filename,
          matchedWith: bestMatch.originalName,
          matchedFilename: bestMatch.filename,
          url: ownUrl,
          matchedUrl: bestMatch.url,
          type: 'similar',
          reason: bestEvaluation.reason,
          distance: bestEvaluation.minDistance,
          similarityPct: bestEvaluation.confidencePct,
          bgSim: bestEvaluation.bgSim,
          colorSim: bestEvaluation.colorSim,
          centerSim: bestEvaluation.centerSim,
          bestAngle: bestEvaluation.bestAngle,
          sha256,
          md5,
          dhash: sig ? sig.primaryDHash : '',
          size: file.size,
          uploadedAt: new Date(),
          isDuplicate: true,
        };
        const insertedDup = await duplicatesDb.insert(dupRecord);
        batchDuplicates.push(insertedDup);
        continue;
      }

      const record = {
        originalName: file.originalname,
        filename,
        sha256,
        md5,
        dhash: sig ? sig.primaryDHash : '',
        sig,
        url: ownUrl,
        size: file.size,
        uploadedAt: new Date(),
        isDuplicate: false,
      };

      const inserted = await imagesDb.insert(record);
      existingDocs.push(inserted);
      batchUnique.push(inserted);
    }

    const totalUnique = await imagesDb.count({});
    const totalDuplicates = await duplicatesDb.count({});

    res.render('index', {
      unique: batchUnique,
      duplicates: batchDuplicates,
      justUploaded: true,
      batchStats: {
        batchCount: files.length,
        batchUniqueCount: batchUnique.length,
        batchDuplicateCount: batchDuplicates.length,
      },
      stats: {
        totalUnique,
        totalDuplicates,
        totalProcessed: totalUnique + totalDuplicates,
      },
    });
  } catch (err) {
    console.error('Error processing upload:', err);
    res.status(500).send('Upload processing failed: ' + err.message);
  }
}

async function renderGallery(req, res) {
  try {
    const totalUnique = await imagesDb.count({});
    const totalDuplicates = await duplicatesDb.count({});
    const totalExact = await duplicatesDb.count({ type: 'exact' });
    const totalSimilar = await duplicatesDb.count({ type: 'similar' });

    const initialTab = req.query.tab || 'all';

    res.render('gallery', {
      initialTab,
      stats: {
        totalAll: totalUnique + totalDuplicates,
        totalUnique,
        totalDuplicates,
        totalExact,
        totalSimilar,
      },
    });
  } catch (err) {
    console.error('Error loading gallery page:', err);
    res.status(500).send('Internal server error');
  }
}

async function getImagesApi(req, res) {
  try {
    const tab = req.query.tab || 'all';
    const search = (req.query.search || '').trim().toLowerCase();
    const typeFilter = req.query.type || 'all';
    const sort = req.query.sort || 'newest';
    const page = Math.max(1, parseInt(req.query.page, 10) || 1);
    const limit = Math.min(200, Math.max(1, parseInt(req.query.limit, 10) || 24));

    let items = [];

    if (tab === 'unique') {
      const docs = await imagesDb.find({});
      items = docs.map((d) => ({ ...d, kind: 'unique' }));
    } else if (tab === 'duplicates') {
      const query = {};
      if (typeFilter === 'exact') query.type = 'exact';
      if (typeFilter === 'similar') query.type = 'similar';
      const docs = await duplicatesDb.find(query);
      items = docs.map((d) => ({ ...d, kind: 'duplicate' }));
    } else {
      if (typeFilter === 'exact') {
        const dDocs = await duplicatesDb.find({ type: 'exact' });
        items = dDocs.map((d) => ({ ...d, kind: 'duplicate' }));
      } else if (typeFilter === 'similar') {
        const dDocs = await duplicatesDb.find({ type: 'similar' });
        items = dDocs.map((d) => ({ ...d, kind: 'duplicate' }));
      } else {
        const [uDocs, dDocs] = await Promise.all([
          imagesDb.find({}),
          duplicatesDb.find({}),
        ]);
        items = [
          ...uDocs.map((d) => ({ ...d, kind: 'unique' })),
          ...dDocs.map((d) => ({ ...d, kind: 'duplicate' })),
        ];
      }
    }

    if (search) {
      items = items.filter((item) => {
        const nameMatch = (item.originalName || '').toLowerCase().includes(search);
        const matchWithMatch = (item.matchedWith || '').toLowerCase().includes(search);
        const md5Match = (item.md5 || '').toLowerCase().includes(search);
        const shaMatch = (item.sha256 || '').toLowerCase().includes(search);
        const reasonMatch = (item.reason || '').toLowerCase().includes(search);
        return nameMatch || matchWithMatch || md5Match || shaMatch || reasonMatch;
      });
    }

    items.sort((a, b) => {
      const dateA = new Date(a.uploadedAt || 0).getTime();
      const dateB = new Date(b.uploadedAt || 0).getTime();
      const nameA = (a.originalName || '').toLowerCase();
      const nameB = (b.originalName || '').toLowerCase();

      switch (sort) {
        case 'oldest':
          return dateA - dateB;
        case 'name_asc':
          return nameA.localeCompare(nameB);
        case 'name_desc':
          return nameB.localeCompare(nameA);
        case 'similarity':
          return (b.similarityPct || 0) - (a.similarityPct || 0);
        case 'newest':
        default:
          return dateB - dateA;
      }
    });

    const total = items.length;
    const totalPages = Math.ceil(total / limit) || 1;
    const startIndex = (page - 1) * limit;
    const paginatedItems = items.slice(startIndex, startIndex + limit);

    const [totalUnique, totalDuplicates, totalExact, totalSimilar] = await Promise.all([
      imagesDb.count({}),
      duplicatesDb.count({}),
      duplicatesDb.count({ type: 'exact' }),
      duplicatesDb.count({ type: 'similar' }),
    ]);

    res.json({
      success: true,
      items: paginatedItems,
      total,
      page,
      limit,
      totalPages,
      startIndex: total === 0 ? 0 : startIndex + 1,
      endIndex: Math.min(startIndex + limit, total),
      counts: {
        totalAll: totalUnique + totalDuplicates,
        unique: totalUnique,
        duplicates: totalDuplicates,
        exact: totalExact,
        similar: totalSimilar,
      },
    });
  } catch (err) {
    console.error('API /api/images error:', err);
    res.status(500).json({ success: false, error: err.message });
  }
}

async function rescanLibraryApi(req, res) {
  try {
    const allUnique = await imagesDb.find({}).sort({ uploadedAt: 1 });
    let movedDuplicatesCount = 0;

    for (const doc of allUnique) {
      await ensureDocSignature(doc);
    }

    const uniquePool = [];
    for (const doc of allUnique) {
      if (!doc.sig) {
        uniquePool.push(doc);
        continue;
      }

      let matchedWithDoc = null;
      let matchEval = null;

      for (const poolDoc of uniquePool) {
        if ((doc.sha256 && poolDoc.sha256 && doc.sha256 === poolDoc.sha256) ||
          (doc.md5 && poolDoc.md5 && doc.md5 === poolDoc.md5)) {
          matchedWithDoc = poolDoc;
          matchEval = {
            isDuplicate: true,
            matchType: 'exact',
            reason: 'Exact Match',
            confidencePct: 100,
            minDistance: 0,
            bgSim: 100,
            colorSim: 100,
            centerSim: 100,
          };
          break;
        }

        if (poolDoc.sig) {
          const evalRes = evaluateSimilarity(doc.sig, poolDoc.sig);
          if (evalRes.isDuplicate) {
            matchedWithDoc = poolDoc;
            matchEval = evalRes;
            break;
          }
        }
      }

      if (matchedWithDoc && matchEval) {
        await imagesDb.remove({ _id: doc._id }, {});
        const dupRecord = {
          originalName: doc.originalName,
          filename: doc.filename,
          matchedWith: matchedWithDoc.originalName,
          matchedFilename: matchedWithDoc.filename,
          url: doc.url || `/uploads/${doc.filename}`,
          matchedUrl: matchedWithDoc.url || `/uploads/${matchedWithDoc.filename}`,
          type: matchEval.matchType,
          reason: matchEval.reason,
          distance: matchEval.minDistance || 0,
          similarityPct: matchEval.confidencePct || 90,
          bgSim: matchEval.bgSim || 0,
          colorSim: matchEval.colorSim || 0,
          centerSim: matchEval.centerSim || 0,
          bestAngle: matchEval.bestAngle || 0,
          sha256: doc.sha256,
          md5: doc.md5,
          dhash: doc.dhash,
          size: doc.size,
          uploadedAt: doc.uploadedAt || new Date(),
          isDuplicate: true,
        };
        await duplicatesDb.insert(dupRecord);
        movedDuplicatesCount++;
      } else {
        uniquePool.push(doc);
      }
    }

    const totalUnique = await imagesDb.count({});
    const totalDuplicates = await duplicatesDb.count({});

    res.json({
      success: true,
      movedDuplicatesCount,
      totalUnique,
      totalDuplicates,
    });
  } catch (err) {
    console.error('Error during rescan:', err);
    res.status(500).json({ success: false, error: err.message });
  }
}

async function deleteImageApi(req, res) {
  try {
    const { type, id } = req.params;
    if (type === 'unique') {
      const doc = await imagesDb.findOne({ _id: id });
      if (doc) {
        await imagesDb.remove({ _id: id }, {});
        const others = await imagesDb.count({ filename: doc.filename });
        const dupOthers = await duplicatesDb.count({ filename: doc.filename });
        if (others === 0 && dupOthers === 0 && doc.filename) {
          const filePath = path.join(UPLOAD_DIR, doc.filename);
          if (fs.existsSync(filePath)) {
            try {
              fs.unlinkSync(filePath);
            } catch (e) { }
          }
        }
      }
    } else if (type === 'duplicate') {
      const dup = await duplicatesDb.findOne({ _id: id });
      await duplicatesDb.remove({ _id: id }, {});
      if (dup && dup.filename) {
        const others = await imagesDb.count({ filename: dup.filename });
        const dupOthers = await duplicatesDb.count({ filename: dup.filename });
        if (others === 0 && dupOthers === 0) {
          const filePath = path.join(UPLOAD_DIR, dup.filename);
          if (fs.existsSync(filePath)) {
            try {
              fs.unlinkSync(filePath);
            } catch (e) { }
          }
        }
      }
    }
    res.json({ success: true });
  } catch (err) {
    console.error('Delete error:', err);
    res.status(500).json({ success: false, error: err.message });
  }
}

async function clearImagesApi(req, res) {
  try {
    const { target } = req.body;
    if (target === 'duplicates') {
      await duplicatesDb.remove({}, { multi: true });
    } else if (target === 'all') {
      await duplicatesDb.remove({}, { multi: true });
      await imagesDb.remove({}, { multi: true });
      if (fs.existsSync(UPLOAD_DIR)) {
        const files = fs.readdirSync(UPLOAD_DIR);
        for (const file of files) {
          try {
            fs.unlinkSync(path.join(UPLOAD_DIR, file));
          } catch (e) { }
        }
      }
    }
    res.json({ success: true });
  } catch (err) {
    console.error('Clear error:', err);
    res.status(500).json({ success: false, error: err.message });
  }
}

module.exports = {
  renderHome,
  handleUpload,
  renderGallery,
  getImagesApi,
  rescanLibraryApi,
  deleteImageApi,
  clearImagesApi,
};
