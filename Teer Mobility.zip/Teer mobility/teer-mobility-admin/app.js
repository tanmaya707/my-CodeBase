const express = require('express');
const app = express();
const axios = require('axios');
const morgan = require("morgan");
const cors = require("cors");
const session = require('express-session');
const errorMiddleware = require('./src/middleware/error');
const cookieParser = require('cookie-parser');
const expressFileUpload = require("express-fileupload");
const path          = require('path');
const { API_URL, APPURL } = require('./src/config/index');
const oneDay = 1000 * 60 * 60 * 24;
const MongoDBStore = require('connect-mongodb-session')(session);
// const mongoConfig = require("./index").Mongo;
const mongoConfig = require('./src/config/index').Mongo;
// let dburl =
//   process.env.APP_ENV == "development"
//     ? `mongodb://` + mongoConfig.path + "/" + mongoConfig.dbName
//     : "mongodb://" +
//       mongoConfig.user +
//       ":" +
//       mongoConfig.pwd +
//       "@" +
//       mongoConfig.path +
//       "/" +
//       mongoConfig.dbName +
//       "?retryWrites=true&w=majority";

// console.log(dburl)

// const store = new MongoDBStore({
//     uri: dburl,
//     collection: 'sessions'
// });


// CORS configuration
// const corsOptions = {
//     origin: "*", // Allow all origins
//     methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"], // Allowed methods
//     allowedHeaders: ["Content-Type", "Authorization", "X-Requested-With"], // Allowed headers
// };
// // Use the CORS middleware with options
// app.use(cors(corsOptions));
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ limit: "50mb", extended: true }));

app.use(cookieParser());

app.use(expressFileUpload({ parseNested: true }));
app.use(cors());
app.use(session({
    secret: "53536311secrctekeyfhgfgrfrty0687564rw3234e5659884fwir764",
    saveUninitialized:true,
    // store: store,
    cookie: { maxAge: oneDay },
    resave: false
}));
// Cache Control: 'no-store'; Prevents the browser from caching the login page. So if logged in and user presses browser back button, browser won't reload static DOM, rather hit the URL for the page
app.use((req, res, next) => {
    res.set('Cache-Control', 'no-store');
    next();
});

app.use (async (req, res, next) => {
    res.locals.currentDate = new Date().toISOString().split('T')[0];
    res.locals.currentUrl = req.url.split('/')[1].split('?')[0]
    res.locals.host = req.get('host')
    res.locals.protocol = req.protocol
    res.locals.apiUrl = API_URL
    res.locals.appUrl = APPURL
    res.locals.token = (req.session && req.session.token)?req.session.token:''
    res.locals.userId = (req.session && req.session.userId)?req.session.userId:''
    if(req.session.superId != null){
        res.locals.superId = req.session.superId
    } else {
        res.locals.superId = null
    }
    res.locals.email = (req.session && req.session.email)?req.session.email:''
    res.locals.userName = (req.session && req.session.name)?req.session.name:''
    res.locals.userRole = (req.session && req.session.role)?req.session.role:''
    res.locals.roleList = []
    await axios({
        method: 'get',
        url: API_URL + "role-list",
        // headers: {
        //     'Content-Type': 'application/json',
        //     'token': req.session.token,
        // },
    }).then(roles => {
        res.locals.roleList = roles.data.data.data
    }).catch(error=>{
        console.log(error);
    });
    // ------ module-checker ------
    res.locals.moduleChecker = []
    res.locals.permissionModuleChecker = []
    await axios({
        method: 'get',
        url: API_URL + 'perssion-module-list',
    }).then(moduleChecker => {
        res.locals.moduleChecker = moduleChecker.data.data
    }).catch(error=>{
        console.log(error);
    });
    await axios({
        method: 'get',
        url: API_URL + 'all-perssion-module-list',
    }).then(permissionModuleChecker => {
        res.locals.permissionModuleChecker = permissionModuleChecker.data.data
    }).catch(error=>{
        console.log(error);
    });
    // ------ role-permission-checker ------
    res.locals.rolePermissionChecker = []
    if((req.session && req.session.token)){
        await axios({
            method: 'post',
            url: API_URL + 'user-permission-checker',
            headers: {
                'Content-Type': 'application/json',
                'token': req.session.token,
            },
            data: {'roleId' : req.session.roleId}
        }).then((permission)=>{
            if(permission?.data?.data.length > 0){
                // has permission ===== let the user pass-through =====
                res.locals.rolePermissionChecker = permission.data.data
                
            } else {
                // does not have permission ==== force logout ====
                return res.status(401).json({
                    status: true,
                    redirect: "/logout"
                });
            }
        }).catch(error=>{
            res.redirect('/logout');

            // return res.status(401).json({
            //     status: false,
            //     message: "Oops..!! Looks like you don't have any permissions set for your profile yet. Please contact the admin.",
            //     data: {},
            //     redirect: "/logout",
            // });
        });
    }
    // ------ role-permission-checker ------
    next()
});

app.set('views', path.join(__dirname, 'src/views'));
app.use('src/public/uploads', express.static('uploads'));
app.set('view engine', 'ejs');

app.use('/',require('./src/routes/authenticationRoute'));
app.use('/',require('./src/routes/userRoute'));
app.use('/',require('./src/routes/vehicleRoute'));
app.use('/',require('./src/routes/assetRoute'));
app.use('/',require('./src/routes/moduleRoute'));
app.use('/',require('./src/routes/rolePermissionRoute'));
app.use('/',require('./src/routes/corporateRoute'));
app.use('/',require('./src/routes/taggingRoute'));
app.use('/',require('./src/routes/tripStopRoute'));
app.use('/',require('./src/routes/routeMapRoute'));
app.use('/',require('./src/routes/couponRoute'));
app.use('/',require('./src/routes/termsAndConditionsRoute'));
app.use('/',require('./src/routes/privacyPolicyRoute'));
app.use('/',require('./src/routes/contentManagementRoute'));
app.use('/',require('./src/routes/tripPlanRoute'));
app.use('/',require('./src/routes/tripRoute'));
app.use('/',require('./src/routes/countriesRoute'));
app.use('/',require('./src/routes/geoCalculationsRoute'));
app.use('/',require('./src/routes/fareChartRoute'));
app.use('/',require('./src/routes/supportRoute'));
app.use('/',require('./src/routes/transactionHistoryRoute'));
/*************** Morgan Log Configuration ****************/

app.use('/uploads', express.static('src/public/uploads'));
app.use('/assets', express.static('src/public/assets'));


app.use(errorMiddleware);


module.exports = app;