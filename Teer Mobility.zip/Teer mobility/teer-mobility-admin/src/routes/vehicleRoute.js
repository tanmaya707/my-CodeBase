const express = require('express');
const router = express.Router();
const vehicleController = require('../controllers/vehicleController')
const {
    isLoggedIn,
    userHasPermission,
} = require('../middleware/auth');

router.route('/vehicle-category').get(isLoggedIn, userHasPermission, vehicleController.index);
router.route('/vehicle-models').get(isLoggedIn, userHasPermission, vehicleController.vehicleModels);
router.route('/vehicles').get(isLoggedIn, userHasPermission, vehicleController.vehicles);

module.exports = router;