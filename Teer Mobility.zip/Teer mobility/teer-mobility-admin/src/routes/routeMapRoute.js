const express = require('express');
const router = express.Router();
const routeMapController = require('../controllers/routeMapController')
const {
    isLoggedIn,
    userHasPermission,
} = require('../middleware/auth');

router.route('/route-maps').get(isLoggedIn, userHasPermission, routeMapController.index);
module.exports = router;