const express = require('express');
const router = express.Router();

const countriesController = require('../controllers/countriesController');
const {
    isLoggedIn,
    userHasPermission,
} = require('../middleware/auth');

router.route('/countries').get(isLoggedIn, userHasPermission, countriesController.index);

module.exports = router;