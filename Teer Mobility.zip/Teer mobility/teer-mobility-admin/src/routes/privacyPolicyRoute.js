const express = require('express');
const router = express.Router();

const privacyPolicyController = require('../controllers/privacyPolicyController');
const {
    isLoggedIn,
    userHasPermission,
} = require('../middleware/auth');

router.route('/privacy-policies').get(isLoggedIn, userHasPermission, privacyPolicyController.index);

module.exports = router;