const express = require('express');
const router = express.Router();

const rolePermissionController = require('../controllers/rolePermissionController');
const {
    isLoggedIn,
    userHasPermission,
} = require('../middleware/auth');

router.route('/permissions').get(isLoggedIn, userHasPermission, rolePermissionController.index);

module.exports = router;