const express = require('express');
const router = express.Router();

const contentManagementController = require('../controllers/contentManagementController');
const {
    isLoggedIn,
    userHasPermission,
} = require('../middleware/auth');

router.route('/content-management').get(isLoggedIn, userHasPermission, contentManagementController.index);

module.exports = router;