const express = require('express');
const router = express.Router();
const authenticationController = require('../controllers/AuthenticationController')

const {
    isLoggedIn,
    isTokenAvailable,
    userHasPermission,
} = require('../middleware/auth');

// ------ the forbidden forest ------
router.route('/unauthosized-access').get(isLoggedIn, authenticationController.unauthorizedAccess);
// ------ the forbidden forest ------

// ------ login page ------
router.route('/').get(isTokenAvailable, authenticationController.index);
// ------ login page ------

// ------ everybody has default permission to visit the dashboard ------
router.route('/dashboard').get(isLoggedIn, userHasPermission, authenticationController.dashboard);
// ------ everybody has default permission to visit the dashboard ------

router.route('/store-session').post(authenticationController.storeSession)
router.route('/logout').get(authenticationController.logout);

router.route('/forget-password').get(isTokenAvailable, authenticationController.forgetPassword);
router.route('/change-password').get(isLoggedIn, authenticationController.changePassword);
router.route('/my-account').get(isLoggedIn, authenticationController.myAccount);

module.exports = router;