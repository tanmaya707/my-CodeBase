const express = require('express');
const router = express.Router();

const transactionHistoryController = require('../controllers/transactionHistoryController');
const {
    isLoggedIn,
    userHasPermission,
} = require('../middleware/auth');

router.route('/transaction-history').get(isLoggedIn, userHasPermission, transactionHistoryController.index);
router.route('/transaction-history-trip-wise').get(isLoggedIn, userHasPermission, transactionHistoryController.transactionHistoryTripWise);

module.exports = router;