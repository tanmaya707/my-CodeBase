const express = require('express');
const router = express.Router();
const corporateController = require('../controllers/corporateController')
const {
    isLoggedIn,
    userHasPermission,
} = require('../middleware/auth');

router.route('/corporates').get(isLoggedIn, userHasPermission, corporateController.index);
router.route('/vendors').get(isLoggedIn, userHasPermission, corporateController.index);
router.route('/schools').get(isLoggedIn, userHasPermission, corporateController.index);

module.exports = router;