const express = require('express');
const router = express.Router();
const tripController = require('../controllers/tripController')
const {
    isLoggedIn,
    userHasPermission,
} = require('../middleware/auth');

router.route('/trips').get(isLoggedIn, userHasPermission, tripController.index);

router.route('/trip-tabular-view').get(isLoggedIn, userHasPermission, tripController.tripTabularView);

module.exports = router;