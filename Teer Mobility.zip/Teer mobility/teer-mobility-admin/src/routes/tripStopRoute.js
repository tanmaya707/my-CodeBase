const express = require('express');
const router = express.Router();
const tripStopController = require('../controllers/tripStopController')
const {
    isLoggedIn,
    userHasPermission,
} = require('../middleware/auth');

router.route('/trip-stops').get(isLoggedIn, userHasPermission, tripStopController.index);

module.exports = router;