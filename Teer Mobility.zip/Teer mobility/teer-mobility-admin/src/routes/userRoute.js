const express = require('express');
const router = express.Router();
const userController = require('../controllers/UserController')
const {
    isLoggedIn,
    userHasPermission,
} = require('../middleware/auth');

router.route('/users').get(isLoggedIn, userHasPermission, userController.userList);

router.route('/drivers').get(isLoggedIn, userHasPermission, userController.driverList);

router.route('/employees').get(isLoggedIn, userHasPermission, userController.employeeList);

router.route('/students').get(isLoggedIn, userHasPermission, userController.studentList);

router.route('/corporate-users').get(isLoggedIn, userHasPermission, userController.corporateUserList);


module.exports = router;