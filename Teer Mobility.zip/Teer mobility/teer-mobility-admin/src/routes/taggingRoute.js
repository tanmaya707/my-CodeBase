const express = require('express');
const router = express.Router();
const TaggingController = require('../controllers/TaggingController')
const {
    isLoggedIn,
    userHasPermission,
} = require('../middleware/auth');

router.route('/vendor-driver-tagging').get(isLoggedIn, userHasPermission, TaggingController.vendorDriverTag);
router.route('/vendor-corporate-tagging').get(isLoggedIn, userHasPermission, TaggingController.vendorCorporateTag);
router.route('/vendor-vehicle-tagging').get(isLoggedIn, userHasPermission, TaggingController.vendorVehicleTag);
router.route('/route-vehicle-tagging').get(isLoggedIn, userHasPermission, TaggingController.routeVehicleTag);

module.exports = router;