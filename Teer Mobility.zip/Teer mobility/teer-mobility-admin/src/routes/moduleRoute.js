const express = require('express');
const router = express.Router();

const moduleController = require('../controllers/moduleController');
const {
    isLoggedIn,
    userHasPermission,
} = require('../middleware/auth');

router.route('/modules').get(isLoggedIn, userHasPermission, moduleController.index);
router.route('/reorder-module').get(isLoggedIn, moduleController.reorderModule);

module.exports = router;