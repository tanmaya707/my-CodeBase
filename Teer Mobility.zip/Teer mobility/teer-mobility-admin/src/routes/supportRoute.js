const express = require('express');
const router = express.Router();

const supportController = require('../controllers/supportController');

const {
    isLoggedIn,
    userHasPermission,
} = require('../middleware/auth');

router.route('/support').get(isLoggedIn, userHasPermission, supportController.index);

module.exports = router;