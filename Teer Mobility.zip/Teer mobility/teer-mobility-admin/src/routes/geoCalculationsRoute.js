const express = require('express');
const router = express.Router();

const geoCalculationsController = require('../controllers/geoCalculationsController');
const {
    isLoggedIn,
} = require('../middleware/auth');

router.route('/getPreciseDistance').post(isLoggedIn, geoCalculationsController.getPreciseDistance);
router.route('/getAutoCalculatedEndTime').post(isLoggedIn, geoCalculationsController.getAutoCalculatedEndTime);

module.exports = router;