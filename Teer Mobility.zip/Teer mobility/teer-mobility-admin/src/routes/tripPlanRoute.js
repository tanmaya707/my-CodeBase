const express = require('express');
const router = express.Router();
const tripPlanController = require('../controllers/tripPlanController')
const {
    isLoggedIn,
    userHasPermission,
} = require('../middleware/auth');

router.route('/trip-plans').get(isLoggedIn, userHasPermission, tripPlanController.index);
module.exports = router;