const express = require('express');
const router = express.Router();

const termsAndConditionsController = require('../controllers/termsAndConditionsController');
const {
    isLoggedIn,
    userHasPermission,
} = require('../middleware/auth');

router.route('/terms-and-conditions').get(isLoggedIn, userHasPermission, termsAndConditionsController.index);

module.exports = router;