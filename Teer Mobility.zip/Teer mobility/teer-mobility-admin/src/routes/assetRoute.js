const express = require('express');
const router = express.Router();

const assetController = require('../controllers/assetController');
const {
    isLoggedIn
} = require('../middleware/auth');

router.route('/assets').get(isLoggedIn, assetController.index);

module.exports = router;