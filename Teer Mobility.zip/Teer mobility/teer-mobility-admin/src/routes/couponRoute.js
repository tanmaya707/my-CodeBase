const express = require('express');
const router = express.Router();

const couponController = require('../controllers/couponController');
const {
    isLoggedIn,
    userHasPermission,
} = require('../middleware/auth');

router.route('/coupons').get(isLoggedIn, userHasPermission, couponController.index);

module.exports = router;