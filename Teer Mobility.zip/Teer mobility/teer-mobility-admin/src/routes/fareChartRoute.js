const express = require('express');
const router = express.Router();

const fareChartController = require('../controllers/fareChartController');
const {
    isLoggedIn
} = require('../middleware/auth');

router.route('/fare-chart').get(isLoggedIn, fareChartController.index);

module.exports = router;