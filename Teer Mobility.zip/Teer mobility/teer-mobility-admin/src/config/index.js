// require("dotenv").config();

const HTTP = {
    port: process.env.APP_ENV == "production" ? process.env.PORT : 4200,
};
const APPNAME = {
    port:
        process.env.APP_ENV == "production"
            ? process.env.APP_NAME
            : "teer_mobility",
};
const APPURL =
    process.env.APP_ENV == "production"
        ? process.env.APP_URL
        : "http://localhost:4200";
const API_URL =
process.env.APP_ENV == "production"
    ? process.env.API_URL
    : "http://localhost:4100/";

const Mongo = {
    path: process.env.APP_ENV == "production" ? process.env.DB_HOST : "0.0.0.0",
    user: process.env.APP_ENV == "production" ? process.env.DB_USER : "",
    pwd: process.env.APP_ENV == "production" ? process.env.DB_PASSWORD : "",
    port: process.env.APP_ENV == "production" ? process.env.DB_PORT : 27017,
    dbName: process.env.APP_ENV == "production" ? process.env.DB_NAME : "teer_mobility",
};

let JWT = {
    secret:
        process.env.APP_ENV == "production"
            ? process.env.JWT_SECRET
            : "some-silly-secret-access-token-shit",
    options: {
        expiresIn: 60 * 60 * 24 * 365,
    },
    refresh: {
        secret:
            process.env.APP_ENV == "production"
                ? process.env.JWT_REFRESH_SECRET
                : "some-silly-secret-refresh-token-shit",
        options: {
            expiresIn: 60 * 60 * 24 * 365,
        },
    },
};

const Timezone = process.env.APP_ENV == "production" ? process.env.TIMEZONE : "Asia/Calcutta";

module.exports = {
    HTTP,
    APPNAME,
    APPURL,
    Mongo,
    JWT,
    Timezone,
    API_URL,
};