const loaderHTML = `
<div id="loader" style="display: none;">
    <div class="spinner-wrapper">
    <div class="spinner"></div>
    <p class="loading-text">Loading...</p> 
    </div>
</div>
`;

$('body').append(loaderHTML);

$(document).ready(function(){
    let dates = dateCalculation('', '')
    $("[name=toDate]").val(dates.endDate)
    $("[name=fromDate]").val(dates.startDate)
    calendarFormat()
})
$(document).on("change", "[name=routeId]", function(){
    calendarFormat()
})
$(document).on("change", "[name=isOnDemand]", function(){
    calendarFormat()
})
$(document).on("change", "[name=toDate]", function(){
    calendarFormat()
})
$(document).on("change", "[name=fromDate]", function(){
    calendarFormat()
})
$(document).on("click", ".prev_date", function(){
    let fromDate = new Date($("[name=fromDate]").val())
    let toDate = new Date($("[name=fromDate]").val())
    fromDate.setDate(fromDate.getDate() - 7)
    toDate.setDate(toDate.getDate() - 1)
    let dates = dateCalculation(fromDate, toDate)
    $("[name=toDate]").val(dates.endDate)
    $("[name=fromDate]").val(dates.startDate)
    calendarFormat()
})
$(document).on("click", ".next_date", function(){
    let fromDate = new Date($("[name=toDate]").val())
    let toDate = new Date($("[name=toDate]").val())
    fromDate.setDate(fromDate.getDate() + 1)
    toDate.setDate(toDate.getDate() + 7)
    let dates = dateCalculation(fromDate, toDate)
    $("[name=toDate]").val(dates.endDate)
    $("[name=fromDate]").val(dates.startDate)
    calendarFormat()
})
$(document).on("click", ".today_date", function(){
    let dates = dateCalculation('', '')
    $("[name=toDate]").val(dates.endDate)
    $("[name=fromDate]").val(dates.startDate)
    calendarFormat()
})
$(document).on("click", ".rut-link", function(){
    $(".rut-link").not($(this)).closest(".rost_coname").find(".stops-list").hide()
    $(this).closest(".rost_coname").find(".stops-list").toggle()
})
function dateCalculation(startDate, endDate){
    if((startDate != '') && (endDate == '')){
        endDate = new Date(startDate)
        endDate.setDate(endDate.getDate() + 6)
    }else if((startDate == '') && (endDate != '')){
        startDate = new Date(endDate)
        startDate.setDate(startDate.getDate() - 6)
    }else if((startDate == '') && (endDate == '')){
        startDate = new Date().getTime()
        endDate = new Date()
        endDate.setDate(endDate.getDate() + 6)
    }
    return {
        "startDate" : dateFormat(startDate),
        "endDate" :  dateFormat(endDate)
    }
}

function calendarFormat(){
	let routeId = $("[name=routeId]").val()
    let isOnDemand = $("[name=isOnDemand]").val()
	let toDate = $("[name=toDate]").val()
	let fromDate = $("[name=fromDate]").val()

	let superId = $("[name=superId]").val();
	// console.log("superId ===> ");
	// console.log(superId);
	let content = ''
	let date = fromDate

	$.ajax({
		type: 'POST',
		headers: requestHeader,
		url: apiUrl + "trip-list",
		data: {
			'routeId' : routeId,
            'isOnDemand' : isOnDemand,
			'fromDate' : fromDate,
			'toDate': toDate,
			'superId': superId,
		},
		dataType: "JSON",
        beforeSend: function() {
            $('#loader').show();
        },
		success: function (response) {
			if (response.status == false) {
				swal.fire({
					icon: 'error',
					title: 'Error',
					text: response.message,
				})
			} else {
				// console.log("response.data.data =======> ");
				// console.log(response.data.data);

				// ================== prepare roster content =========================
				response.data.data.forEach((trip)=>{
					content += `
					<div class="accroster_box">
						<div class="date-box">
							<h6>${new Date(trip.date).toLocaleString('default', { month: 'short' })+" "+new Date(trip.date).getDate()}</h6>
						</div>`;
						trip.trips.forEach(elem => {
							let bookings = elem.bookings.length;
							let accessibility = elem?.tripPlanId?.accessibility;
							let availability = Number(accessibility) - Number(bookings);
							let stopNamesHtml = ``;
							var status = "blue";
							var endStatus = false;
							var startTime = new Date(dateFormat(elem.tripDate)+" "+elem.tripStartTime);
							var endTime = new Date(dateFormat(elem.tripDate)+" "+elem.tripEndTime);
							var currentTime = new Date();

							if(endTime < currentTime){
								status = 'grey';
								endStatus = true;
							} else if(startTime > currentTime){
								status = 'yellow';
							}

							stopNamesHtml += `<div class="stops-list"><ul>`;
							elem?.tripPlanId?.routeId?.routeStops.forEach((stop)=>{
								stopNamesHtml += `<li><div class="time">${stop?.stopId?.stopName}</div><p></p></li>`;
							})
							stopNamesHtml += `</ul></div>`;
							content += `
								<div class="rost_lsingle rost_lsin${status}" data-id="${elem?._id}">
									<div class="rost_lshead">
										<h5 data-title="${elem?.tripPlanId?.tripName}">Details</h6>
									</div>
									<div class="rost_lscon">
										<div class="rost_coname">
											<p class="grn-p">${elem?.tripStartTime} - ${elem?.tripEndTime}</p>
											<p>Driver assigned - ${(elem.driverId == null)? "No":"Yes"}</p>

											<p><b>Vendor</b> - ${(elem?.tripPlanId?.vendorId)? elem?.tripPlanId?.vendorId?.userId.firstName : "Not Assigned"}</p>
											
											<div class="tripActionButtons">
												<a href="javascript:void(0)" class="rut-link"><i class="fa-solid fa-route" title="View Route"></i></a>
												${stopNamesHtml}

												${(!endStatus)? `<a href="javascript:void(0)" class="viewTrip"><i class="fa-solid fa-taxi" title="Vendor/Driver/Vehicle Assign"></i></a>` : ``}
											
							`;
							if(!endStatus){
								if(availability > 0){
									content += `
										<a href="javascript:void(0)" class="addPassenger"><i class="fa-solid fa-users" title="Add Passenger"></i> (${availability} left)</a><br>
									`;
								}
							}
							content += `
												<a href="javascript:void(0)" class="viewBookings ${(endStatus)?'closed':'' }"><i class="fa-solid fa-clipboard-list" title="View Bookings"></i></a>
											</div>
										</div>
									</div>
								</div>
							`;
						})
	
					content += `</div>`;
				})
				// ================== prepare roster content =========================

				$("#accorRoster").html(content);
                $('#loader').hide();
			}
		},
		error: function (res) {
			swal.fire({
				icon: 'error',
				title: 'Error',
				text: "Something Went Wrong",
			})
		},
        complete: function() {
            $('#loader').hide();
        }
	})

}

function dateFormat(date){
    return new Date(date).getFullYear()+'-'+(new Date(date).getMonth() + 1).toString().padStart(2,'0')+'-'+new Date(date).getDate().toString().padStart(2,'0')
}
$(document).on("click", ".viewTrip", function () {
    let id = $(this).closest(".rost_lsingle").attr("data-id")
    $.ajax({
        type: 'POST',
        headers: requestHeader,
        url: apiUrl + "trip-assignment",
        data: {
            'tripId' : id
        },
        dataType: "JSON",
        beforeSend: function() {
            $('#loader').show();
        },
        success: function (response) {
            if (response.type != 'success') {
                swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: response.message,
                })
            } else {
                $("#exampleModal").find("[name=_id]").val(id)
                $("#exampleModal .tripName").text(response.data.data.tripPlanId.tripName)
                $("#exampleModal .tripDate").text(dateFormat(response.data.data.tripDate))
                $("#exampleModal .routeName").text(response.data.data.tripPlanId.routeId.routeName)
                
                if(response.data.data.vehicleId && response.data.data.vehicleId != null)
                {
                    $("#exampleModal").find("[name=vehicleId]").val(response.data.data.vehicleId)
                }else{
                    $("#exampleModal").find("[name=vehicleId]").val('')
                }
                if(response.data.data.driverId && response.data.data.driverId != null)
                {
                    $("#exampleModal").find("[name=driverId]").val(response.data.data.driverId)
                }else{
                    $("#exampleModal").find("[name=driverId]").val('')
                }
                if(response.data.data.vendorId && response.data.data.vendorId != null)
                {
                    $("#exampleModal").find("[name=vendorId]").val(response.data.data.vendorId)
                }else{
                    $("#exampleModal").find("[name=vendorId]").val('')
                }
                $("#exampleModal").find("[name=vendorId]").trigger('change')
                
	            $("#exampleModal").modal('show');
            }
        },
        error: function (res) {
            swal.fire({
                icon: 'error',
                title: 'Error',
                text: "Something Went Wrong",
            })
        },
        complete: function() {
            $('#loader').hide();
        }
    })
    
 })

$(document).on("click", ".addPassenger", function(){
    let id = $(this).closest(".rost_lsingle").attr("data-id")
    passengerAddModalCreate(id)
})

$(document).on("click", ".viewBookings", function(){
    let id = $(this).closest(".rost_lsingle").attr("data-id")
    let thisElem = $(this)
    $.ajax({
        type: 'POST',
        headers: requestHeader,
        url: apiUrl + "trip-bookings",
        data: {
            'tripId' : id
        },
        dataType: "JSON",
        beforeSend: function() {
            $('#loader').show();
        },
        success: function (response) {
            if (response.type != 'success') {
                swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: response.message,
                })
            } else {
                $("#bookingModal table").attr("data-id", id)
                let content = ''
                response.data.data.forEach(elem => {
                    content += `<tr data-id="${elem._id}">
                                    <td>${elem.userId.firstName+" "+elem.userId.lastName}</td>
                                    <td>${elem.userId.phone}</td>
                                    <td>${elem.pickupStop}</td>
                                    <td>${elem.dropStop}</td>`
                                    if(!thisElem.hasClass('closed')){
                                        content += `<td>
                                            <button class="btn btn-success edit_booking"><i class="fa fa-pen"></i></button>
                                            <button class="btn btn-danger delete"><i class="fa fa-trash"></i></button>
                                        </td>`
                                    }
                                content += `</tr>`
                })
                if(response.data.data.length == 0){
                    content += `<tr><td colspan="5">No Data Found</td></tr>`
                }
                if(thisElem.hasClass('closed')){
                    $("#bookingModal table tr th.action").hide()
                }else{
                    $("#bookingModal table tr th.action").show()
                }
                $("#bookingModal table tbody").html(content)
                $("#bookingModal").modal('show');
            }
        },
        error: function (res) {
            swal.fire({
                icon: 'error',
                title: 'Error',
                text: "Something Went Wrong",
            })
        },
        complete: function() {
            $('#loader').hide();
        }
    })
})

$(document).on("change", "[name=pickupStopId]", function(){
    if(Number($("[name=dropStopId] option:selected").attr("data-order")) <= Number($("[name=pickupStopId] option:selected").attr("data-order"))){
        $("[name=dropStopId] option[data-order="+(Number($("[name=pickupStopId] option:selected").attr("data-order")) + 1)+"]").prop("selected", true)
    }
})
$(document).on("change", "[name=dropStopId]", function(){
    if(Number($("[name=pickupStopId] option:selected").attr("data-order")) >= Number($("[name=dropStopId] option:selected").attr("data-order"))){
        $("[name=pickupStopId] option[data-order="+(Number($("[name=dropStopId] option:selected").attr("data-order")) - 1)+"]").prop("selected", true)
    }
})
function passengerAddModalCreate(id){
    $.ajax({
        type: 'POST',
        headers: requestHeader,
        url: apiUrl + "trip-requirements",
        data: {
            'id' : id
        },
        dataType: "JSON",
        beforeSend: function() {
            $('#loader').show();
        },
        success: function (response) {
            if (response.type != 'success') {
                swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: response.message,
                })
            } else {
                let userContent = ''
                // console.log("response.data.data.tripFor ============>");
                // console.log(response.data.data.tripFor);
                if(response.data.data.tripFor == "School"){
                    response.data.data.eligibleStudentsOfTrip.forEach(elem => {
                        userContent += `<option value="${elem?._id}">${elem?.firstName+" "+elem?.lastName}</option>`;
                    });
                } else {
                    response.data.data.employees.forEach(elem => {
                        userContent += `<option value="${elem?.userId?._id}">${elem?.userId?.firstName+" "+elem?.userId?.lastName}</option>`;
                    });
                }
                let pickupRouteContent = ''
                let dropRouteContent = ''
                response.data.data.stops.forEach((elem, index) => {
                    if(elem.order == 1){
                        pickupRouteContent += `<option value="${elem?.stop?._id}" data-order="${elem?.order}" selected>${elem?.stop?.stopName}</option>`
                    }else if(elem?.order == response?.data?.data?.stops.length){
                        dropRouteContent += `<option value="${elem?.stop?._id}" data-order="${elem?.order}" selected>${elem?.stop?.stopName}</option>`
                    }else{
                        pickupRouteContent += `<option value="${elem?.stop?._id}" data-order="${elem?.order}">${elem?.stop?.stopName}</option>`
                        dropRouteContent += `<option value="${elem?.stop?._id}" data-order="${elem?.order}">${elem?.stop?.stopName}</option>`
                    }
                });
                
                $("#passengerModal").find("[name=tripId]").val(id);
                $("#passengerModal .tripName").text(response?.data?.data?.trip?.tripPlanId?.tripName);
                $("#passengerModal .tripDate").text(dateFormat(response?.data?.data?.trip?.tripDate));
                $("#passengerModal [name=userId]").html(userContent);
                if(response.data.data.tripFor == "School"){
                    // append serviceId of user being added =======
                    // console.log(response.data.data.eligibleStudentsOfTrip[0].roleId);
                    $("#passengerModal [name=serviceId]").val(response?.data?.data?.eligibleStudentsOfTrip[0]?.roleId);
                } else{
                    // append serviceId of user being added =======
                    // console.log(response.data.data.employees[0].userId.roleId);
                    $("#passengerModal [name=serviceId]").val(response?.data?.data?.employees[0]?.userId?.roleId);
                }
                $("#passengerModal [name=pickupStopId]").html(pickupRouteContent);
                $("#passengerModal [name=dropStopId]").html(dropRouteContent);
                $("#passengerModal").modal('show');
            }
        },
        error: function (res) {
            swal.fire({
                icon: 'error',
                title: 'Error',
                text: "Something Went Wrong",
            })
        },
        complete: function() {
            $('#loader').hide();
        }
    })
}