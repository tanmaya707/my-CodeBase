// var geolib = require('geolib');

$(document).ready(function(){
    if($("[name=roleId]").length){
        let roleOfUserType = $("#roleOfUserType").val();
        $.ajax({
            type: 'GET',
            headers: requestHeader,
            url: apiUrl + "role-list",
            dataType: "JSON",
            beforeSend: function() {
                $('#loader').show();
            },
            success: function (response) {
                if (response.status == false) {
                    swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: response.message,
                    })
                } else {
                    // console.log("currentUrl ===>");
                    // console.log(currentUrl);
                    
                    let content = '<option value="" selected>Select Role</option>'
                    let filteredRoles = []
                    if(roleOfUserType != undefined){
                        filteredRoles = response.data.data.filter((role)=>{
                            if (role._id.toString() === roleOfUserType) {
                                return role;
                            }
                        });
                    } else {
                        filteredRoles = response.data.data
                    }
                    filteredRoles.forEach((element, key) => {
                        // if(currentUrl != "users"){
                        //     content += '<option value="'+element._id.toString()+'">'+element.name+'</option>'
                        // } else{
                        //     if(
                        //         (element.name == "Corporate")
                        //         || (element.name == "Company")
                        //         || (element.name == "Vendor")
                        //         || (element.name == "School")
                        //         || (element.name == "Employee")
                        //         || (element.name == "Student")
                        //         || (element.name == "Driver")
                        //     ){

                        //     } else {
                        //         content += '<option value="'+element._id.toString()+'">'+element.name+'</option>'
                        //     }

                        // }

                        content += '<option selected="'+element._id.toString()+'">'+element.name+'</option>'
                    });

                    $("[name=roleId]").html(content)
                    $("select[name=roleId]").select2();
                    $("select[name=roleId]").prop('disabled', true).select2();
                    $("[name=roleId]").trigger('change')
                }
            },
            error: function (res) {
                swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: "Something Went Wrong",
                })
            },
            complete: function() {
                $('#loader').hide();
            }
        })
    }
    if($("[name=userId]").length){
        let roleOfUserType = $("#roleOfUserType").val();
        $.ajax({
            type: 'GET',
            headers: requestHeader,
            url: apiUrl + "user-list",
            dataType: "JSON",
            beforeSend: function() {
                $('#loader').show();
            },
            success: function (response) {
                if (response.status == false) {
                    swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: response.message,
                    })
                } else {
                    let content = '<option value="" selected>Select User</option>'
                    let filteredRoles = []
                    if(roleOfUserType != undefined){
                        filteredRoles = response.data.data.filter((user)=>{
                            if (user.roleId.toString() === roleOfUserType) {
                                return user;
                            }
                        });
                    } else {
                        filteredRoles = response.data.data
                    }
                    filteredRoles.forEach((element, key) => {
                        content += `<option value="${element._id.toString()}">${element.firstName} ${element.lastName}</option>`
                    });
                    $("[name=userId]").html(content)
                    $("[name=userId]").trigger('change')
                }
            },
            error: function (res) {
                swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: "Something Went Wrong",
                })
            },
            complete: function() {
                $('#loader').hide();
            }
        })
    }
    if($("[name=moduleId]").length){
        $.ajax({
            type: 'GET',
            headers: requestHeader,
            url: apiUrl + "module-list",
            dataType: "JSON",
            beforeSend: function() {
                $('#loader').show();
            },
            success: function (response) {
                if (response.status == false) {
                    swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: response.message,
                    })
                } else {
                    let content = '<option value="">Select Modules</option>'
                    response.data.data.forEach((element, key) => {
                        content += '<option value="'+element._id.toString()+'">'+element.moduleName+'</option>'
                    });
                    $("[name=moduleId]").html(content)
                    $("[name=moduleId]").trigger('change')
                }
            },
            error: function (res) {
                swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: "Something Went Wrong",
                })
            },
            complete: function() {
                $('#loader').hide();
            }
        })
    }
    if ($("[name=countryCode]").length) {
        $.ajax({
            type: 'GET',
            headers: requestHeader,
            url: apiUrl + "country-list",
            dataType: "JSON",
            beforeSend: function () {
                $('#loader').show();
            },
            success: function (response) {
                if (response.status == false) {
                    swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: response.message,
                    });
                } else {
                    let content = '<option value="">Select Country</option>';
                    response.data.data.forEach((element, key) => {
                        content += '<option value="'+element._id.toString()+'">'+element.name+'</option>';
                    });
                    $("[name=countryCode]").html(content);
                    $("[name=countryCode]").trigger('change');
                }
            },
            error: function (res) {
                swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: "Something Went Wrong",
                });
            },
            complete: function () {
                $('#loader').hide();
            }
        });
    }  
    if($("[name=type]").length){
        $.ajax({
            type: 'GET',
            headers: requestHeader,
            url: apiUrl + "vehicleCategory-list",
            dataType: "JSON",
            beforeSend: function() {
                $('#loader').show();
            },
            success: function (response) {
                if (response.status == false) {
                    swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: response.message,
                    })
                } else {
                    let content = '<option value="" selected>Select Vehicle Category</option>'
                    response.data.data.forEach((element, key) => {
                        let count = 0;
                        response.data.vehicles.forEach((vehicle, key) => {
                            if(vehicle?.modelId?.type?.type == element?.type){
                                count++;
                            }
                        });
                        content += `<option value="${element._id.toString()}">${element?.type} (${count} Cars)</option>`
                    });
                    $("[name=type]").html(content)
                    $("[name=type]").trigger('change')
                }
            },
            error: function (res) {
                swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: "Something Went Wrong",
                })
            },
            complete: function() {
                $('#loader').hide();
            }
        })
    }
    if($("[name=modelId]").length){
        $.ajax({
            type: 'GET',
            headers: requestHeader,
            url: apiUrl + "vehicleModel-list",
            dataType: "JSON",
            beforeSend: function() {
                $('#loader').show();
            },
            success: function (response) {
                if (response.status == false) {
                    swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: response.message,
                    })
                } else {
                    let content = '<option value="" selected>Select Vehicle Model</option>'
                    response.data.data.forEach((element, key) => {
                        content += '<option value="'+element._id.toString()+'">'+element.model+'</option>'
                    });
                    $("[name=modelId]").html(content)
                    $("[name=modelId]").trigger('change')
                }
            },
            error: function (res) {
                swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: "Something Went Wrong",
                })
            },
            complete: function() {
                $('#loader').hide();
            }
        })
    }
    if($("[name=assets]").length){
        $.ajax({
            type: 'GET',
            headers: requestHeader,
            url: apiUrl + "asset-list",
            dataType: "JSON",
            beforeSend: function() {
                $('#loader').show();
            },
            success: function (response) {
                if (response.status == false) {
                    swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: response.message,
                    })
                } else {
                    let content = '<option value="" disabled>Select Assets</option>'
                    response.data.data.forEach((element, key) => {
                        content += '<option value="'+element._id.toString()+'">'+element.assetType+'</option>'
                    });
                    $("[name=assets]").html(content)
                    $("[name=assets]").trigger('change')
                }
            },
            error: function (res) {
                swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: "Something Went Wrong",
                })
            },
            complete: function() {
                $('#loader').hide();
            }
        })
    }
    if($("[name=parentModuleId]").length){
        $.ajax({
            type: 'GET',
            headers: requestHeader,
            url: apiUrl + "module-list",
            dataType: "JSON",
            beforeSend: function() {
                $('#loader').show();
            },
            success: function (response) {
                if (response.status == false) {
                    swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: response.message,
                    })
                } else {
                    let content = '<option value="">Select Parent Module</option>'
                    response.data.data.forEach((element, key) => {
                        content += '<option value="'+element._id.toString()+'">'+element.moduleName+'</option>'
                    });
                    $("[name=parentModuleId]").html(content)
                    $("[name=parentModuleId]").trigger('change')
                }
            },
            error: function (res) {
                swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: "Something Went Wrong",
                })
            },
            complete: function() {
                $('#loader').hide();
            }
        })
    }
    if($("[name=parentCorporateId]").length){
        let roleOfCorporateType = $("#roleOfCorporateType").val();
        $.ajax({
            type: 'GET',
            headers: requestHeader,
            // url: apiUrl + "corporate-list/?type=" + roleOfCorporateType,
            url: apiUrl + "corporate-list",
            dataType: "JSON",
            beforeSend: function() {
                $('#loader').show();
            },
            success: function (response) {
                if (response.status == false) {
                    swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: response.message,
                    })
                } else {
                    let content = '<option value="">Select Parent Organization</option>'
                    // let filteredCorporates = response.data.data.filter((corporate)=>{
                    //     if (corporate.userId.roleId._id.toString() === roleOfCorporateType) {
                    //         return corporate;
                    //     }
                    // });
                    // filteredCorporates.forEach((element, key) => {
                    //     content += '<option value="'+element._id.toString()+'">'+element.name+'</option>'
                    // });
                    response.data.data.forEach((element, key) => {
                        content += '<option value="'+element._id.toString()+'">'+element.name+'</option>'
                    });


                    $("[name=parentCorporateId]").html(content)
                    $("[name=parentCorporateId]").trigger('change')
                }
            },
            error: function (res) {
                swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: "Something Went Wrong",
                })
            },
            complete: function() {
                $('#loader').hide();
            }
        })
    }
    if($("[name=corporateId]").length){
        let corporateTypeRoleArr = $("#corporateTypeRoleArr").val();
        corporateTypeRoleArr = corporateTypeRoleArr.split(",")

        $.ajax({
            type: 'GET',
            headers: requestHeader,
            url: apiUrl + "corporate-list",
            dataType: "JSON",
            beforeSend: function() {
                $('#loader').show();
            },
            success: function (response) {
                if (response.status == false) {
                    swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: response.message,
                    })
                } else {
                    let content = '<option value="">Select Organization</option>'
                    let filteredCorporates = response.data.data.filter((corporate)=>{
                        if (
                            // corporate.userId.roleId._id.toString() === roleOfCorporateType
                            corporateTypeRoleArr.includes(corporate.userId.roleId._id.toString())
                        ) {
                            return corporate;
                        }
                    });
                    // console.log("superId =====> ");
                    // console.log(superId);

                    let filteredCorporatesUserwise = filteredCorporates.filter((corporate)=>{
                        if(corporate.userId._id.toString() == userId){
                            return corporate;
                        }
                    });
                    if(superId != userId){
                        filteredCorporates = filteredCorporatesUserwise
                    } 
                    filteredCorporates.forEach((element, key) => {
                        content += '<option value="'+element._id.toString()+'">'+element.name+'</option>'
                    });

                    $("[name=corporateId]").html(content)
                    // $("[name=corporateId]").trigger('change')
                }
            },
            error: function (res) {
                swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: "Something Went Wrong",
                })
            },
            complete: function() {
                $('#loader').hide();
            }
        })
    }
    if($("[name=vendorId]").length){
        let vendorRole = $("#vendorRole").val();
        $.ajax({
            type: 'GET',
            headers: requestHeader,
            url: apiUrl + "corporate-list",
            dataType: "JSON",
            beforeSend: function() {
                $('#loader').show();
            },
            success: function (response) {
                if (response.status == false) {
                    swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: response.message,
                    })
                } else {
                    let content = '<option value="">Select Vendor</option>'
                    let filteredCorporates = response.data.data.filter((corporate)=>{
                        if (corporate.userId.roleId._id.toString() === vendorRole) {
                            return corporate;
                        }
                    });
                    filteredCorporates.forEach((element, key) => {
                        content += '<option value="'+element._id.toString()+'">'+element.name+'</option>'
                    });
                    // response.data.data.forEach((element, key) => {
                    //     content += '<option value="'+element._id.toString()+'">'+element.name+'</option>'
                    // });


                    $("[name=vendorId]").html(content)
                    $("[name=vendorId]").trigger('change')
                }
            },
            error: function (res) {
                swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: "Something Went Wrong",
                })
            },
            complete: function() {
                $('#loader').hide();
            }
        })
    }
    if($("[name=driverId]").length){
        // let driverRole = $("#driverRole").val();
        $.ajax({
            type: 'GET',
            headers: requestHeader,
            url: apiUrl + "driver-list",
            dataType: "JSON",
            beforeSend: function() {
                $('#loader').show();
            },
            success: function (response) {
                if (response.status == false) {
                    swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: response.message,
                    })
                } else {
                    let content = `<option value="">Select Driver</option>`
                    // let filteredCorporates = response.data.data.filter((corporate)=>{
                    //     if (corporate.userId.roleId._id.toString() === driverRole) {
                    //         return corporate;
                    //     }
                    // });
                    
                    response.data.data.forEach((element, key) => {
                        content += `<option value="${element._id.toString()}">${(element?.userId?.firstName)? element?.userId?.firstName : "N/A"} ${(element?.userId?.lastName)? element?.userId?.lastName : "N/A"} (${(element?.userId?.email)? element?.userId?.email : "N/A"})(${(element?.userId?.phone)? element?.userId?.phone : "N/A"})</option>`
                    });


                    $("[name=driverId]").html(content)
                    $("[name=driverId]").trigger('change')
                }
            },
            error: function (res) {
                swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: "Something Went Wrong",
                })
            },
            complete: function() {
                $('#loader').hide();
            }
        })
    }
    if($("[name=vehicleId]").length){
        $.ajax({
            type: 'GET',
            headers: requestHeader,
            url: apiUrl + "vehicle-list",
            dataType: "JSON",
            beforeSend: function() {
                $('#loader').show();
            },
            success: function (response) {
                if (response.status == false) {
                    swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: response.message,
                    })
                } else {
                    let content = `<option value="">Select Vehicle</option>`
                    response.data.data.forEach((element, key) => {
                        content += `<option value="${element._id.toString()}">${element.model} (Reg. No.: ${element.registrationNumber}) (Chassis. No.: ${element.chassisNumber}) (${element.capacity} Seater)</option>`
                    });

                    $("[name=vehicleId]").html(content)
                    $("[name=vehicleId]").trigger('change')
                }
            },
            error: function (res) {
                swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: "Something Went Wrong",
                })
            },
            complete: function() {
                $('#loader').hide();
            }
        })
    }
    if($("[name=accessibility]").length){
        $.ajax({
            type: 'GET',
            headers: requestHeader,
            url: apiUrl + "vehicle-list",
            dataType: "JSON",
            beforeSend: function() {
                $('#loader').show();
            },
            success: function (response) {
                if (response.status == false) {
                    swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: response.message,
                    })
                } else {
                    let content = `<option value="">Select Accessibility</option>`
                    let vehicleCapacitiesArr = [];
                    response.data.data.forEach((element, key) => {
                        vehicleCapacitiesArr.push(element.capacity)
                    })
                    // =================================================================
                    // uniq = [...new Set(array)]; 
                    // Note: "var uniq" will be an array. "new Set()" turns it into a set, but "[... ]" turns it back into an array again ==========
                    let uniqueCapacitiesArr = [...new Set(vehicleCapacitiesArr)];
                    // =================================================================
                    uniqueCapacitiesArr.forEach((element, key) => {
                        let count = 0;
                        response.data.data.forEach((vehicle, key) => {
                            if(vehicle.capacity == element){
                                count++;
                            }
                        });

                        if(currentUrl == "trip-tabular-view"){
                            content += `<option value="${element}">${element} Seater (${count} Cars)</option>`
                        } else {
                            content += `<option value="${element}">${element} Seater</option>`
                        }
                    });

                    $("[name=accessibility]").html(content)
                    $("[name=accessibility]").trigger('change')
                }
            },
            error: function (res) {
                swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: "Something Went Wrong",
                })
            },
            complete: function() {
                $('#loader').hide();
            }
        })
    }
    if($("[name=stopId]").length){
        $.ajax({
            type: 'GET',
            headers: requestHeader,
            url: apiUrl + "tripStop-list",
            dataType: "JSON",
            beforeSend: function() {
                $('#loader').show();
            },
            success: function (response) {
                if (response.status == false) {
                    swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: response.message,
                    })
                } else {
                    let content = `<option value="">Select Stop</option>`
                    response.data.data.forEach((element, key) => {
                        content += `<option value="${element._id.toString()}">${element}</option>`
                    });

                    $("[name=stopId]").html(content)
                    $("[name=stopId]").trigger('change')
                }
            },
            error: function (res) {
                swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: "Something Went Wrong",
                })
            },
            complete: function() {
                $('#loader').hide();
            }
        })
    }
    if ($("[name=routeId]").length) {
      $.ajax({
        type: "GET",
        headers: requestHeader,
        url: apiUrl + "routeMap-list",
        dataType: "JSON",
        beforeSend: function() {
            $('#loader').show();
        },
        success: function (response) {
          if (response.status == false) {
            swal.fire({
              icon: "error",
              title: "Error",
              text: response.message,
            });
          } else {
            let content = `<option value="">Select Route</option>`;

            response.data.data.forEach((element, key) => {
              content += `<option data-time="${element.routeTime}" value="${element._id.toString()}">${element.routeDetail}</option>`;
            });

            $("[name=routeId]").html(content);
            $("[name=routeId]").trigger("change");
          }
        },
        error: function (res) {
          swal.fire({
            icon: "error",
            title: "Error",
            text: "Something Went Wrong",
          });
        },
        complete: function() {
            $('#loader').hide();
        }
      });
    }
		if($("[name=timeRanges]").length){
			$.ajax({
        type: "POST",
        headers: requestHeader,
        url: apiUrl + "time-ranges",
        dataType: "JSON",
        beforeSend: function() {
            $('#loader').show();
        },
        success: function (response) {
          if (response.status == false) {
            swal.fire({
              icon: "error",
              title: "Error",
              text: response.message,
            });
          } else {
            let content = `<option value="">Select Time Range</option>`;
						
            response.data.forEach((element, key) => {
              content += `<option value="${element?.tripStartTime}-${element?.tripEndTime}">${element?.tripStartTime}-${element?.tripEndTime} (${element?.count})</option>`;
            });

            $("[name=timeRanges]").html(content);
            $("[name=timeRanges]").trigger("change");
          }
        },
        error: function (res) {
          swal.fire({
            icon: "error",
            title: "Error",
            text: "Something Went Wrong",
          });
        },
        complete: function() {
            $('#loader').hide();
        }
      });
		}

		if($(".fill_table").length){
			let url = $(".fill_table").attr("data-url")
				searchList(url, $(".fill_table"))
		}
})

$(document).on("change", ".searchable", function(){
    if($(".fill_table").length){
        let url = $(".fill_table").attr("data-url")
        searchList(url, $(".fill_table"))
    }
})
$(document).on("keyup", ".searchable", function(){
    if($(".fill_table").length){
        let url = $(".fill_table").attr("data-url")
        searchList(url, $(".fill_table"))
    }
})
$(document).on("click", ".pageNo", function(){
    let pageNo = 1;
    if($(".fill_table").length){
        let url = $(".fill_table").attr("data-url");
        if($(".pagination_box").length){
            pageNo = $(this).attr("data-pageno");
        }

        searchList(url, $(".fill_table"), pageNo)
    }
})
$(document).on("click", ".pageNavBtn", function(){
    let pageNo = $(".pageNavBtn").attr("data-pageno");
    if($(".fill_table").length){
        let url = $(".fill_table").attr("data-url");
        if($(".pagination_box").length){
            pageNo = $(this).attr("data-pageno");
        }

        searchList(url, $(".fill_table"), pageNo)
    }
})

$(document).on("change", "[name=roleId]", function(){
    let role = $(this).val()
    if($(".role_permission_sec").length){
        if($("[name=_id]").val() == ''){
            $(".role_permission_sec").find("input").prop("checked", false)
            if((role != '') && (role != null)){
                $.ajax({
                    type: 'POST',
                    headers: requestHeader,
                    url: apiUrl + "role-permission-checker",
                    data: {
                        'roleId' : role
                    },
                    dataType: "JSON",
                    beforeSend: function() {
                        $('#loader').show();
                    },
                    success: function (response) {
                        if (response.status == false) {
                            swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: response.message,
                            })
                        } else {
                            $(".role_permission_sec").find("input").each(function(){
                                if(response.data.includes($(this).val())){
                                    $(this).prop("checked", true)
                                }
                            })
                        }
                    },
                    error: function (res) {
                        swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: "Something Went Wrong",
                        })
                    },
                    complete: function() {
                        $('#loader').hide();
                    }
                })
            }
        }
    }
})

$(document).on("click", ".role_permission_sec input", function(){
    if($(this).hasClass("parentPermission")){
        if($(this).is(":checked")){
            $(this).closest("li").find("ul").find("input").prop("checked", true)
        }else{
            $(this).closest("li").find("ul").find("input").prop("checked", false)
        }
    }else{
        if($(this).is(":checked")){
            $(this).closest("ul").closest("li").find(".parentPermission").prop("checked", true)
        }
    }
})

$(document).on("change", "[name=vendorId]", function(){
    if(
			// ===== driver dropdown doesnot need to be changed for "vendor-driver-tagging" module ====
			(currentUrl != "vendor-driver-tagging") &&
			// ===== driver dropdown doesnot need to be changed for "vendor-driver-tagging" module ====
			$("[name=driverId]").length
		){
        let vendor = $(this).val()
        let driver = $("[name=driverId]").val()
        let vehicle = $("[name=vehicleId]").val()
        let tripId = ''
        if(
					$("#exampleModal").length
					&&
					currentUrl == "trips"
				){
            tripId = $("#exampleModal").find("[name=_id]").val()
        }
        if((vendor != '') && (vendor != null)){
            $.ajax({
                type: 'POST',
                headers: requestHeader,
                url: apiUrl + "vendorDriverMap-list",
                data: {
                    'vendorId' : $("[name=vendorId]").val(),
                    'tripId'   : tripId
                },
                dataType: "JSON",
                beforeSend: function() {
                    $('#loader').show();
                },
                success: function (response) {
                    if (response.status == false) {
                        swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: response.message,
                        })
                    } else {
						let driverIdVal = $("[name=driverId]").val();
                        let content = `<option value="">Select Driver</option>`
                        // let filteredCorporates = response.data.data.filter((corporate)=>{
                        //     if (corporate.userId.roleId._id.toString() === driverRole) {
                        //         return corporate;
                        //     }
                        // });
                        response.data.data.forEach((element, key) => {
                            if(currentUrl == 'vendor-driver-tagging'){
                                content += `<option value="${element._id.toString()}">${element.driverId.userId.firstName} ${element.driverId.userId.lastName} (${element.driverId.userId.email})(${element.driverId.userId.phone})</option>`
                            }else{
                                let selected = (driverIdVal != '')?(driverIdVal == element?.driverId?._id?.toString())?'selected':((driver != '') && (element.driverId._id.toString() == driver.toString()))?'selected':'':''
																
                                content += `<option value="${element.driverId._id.toString()}" ${selected}>${element.driverId.userId.firstName} ${element.driverId.userId.lastName} (${element.driverId.userId.email})(${element.driverId.userId.phone})</option>`
                            }
                        });
    
                        $("[name=driverId]").html(content)
                        $("[name=driverId]").trigger('change')
                        if(
													(currentUrl == 'trips')
													|| (currentUrl == 'trip-plans')
												){
                            $.ajax({
                                type: 'POST',
                                headers: requestHeader,
                                url: apiUrl + "vendorVehicleMap-list",
                                data: {
                                    'vendorId' : $("[name=vendorId]").val(),
                                    'tripId'   : tripId
                                },
                                dataType: "JSON",
                                beforeSend: function() {
                                    $('#loader').show();
                                },
                                success: function (response) {
                                    if (response.status == false) {
                                        swal.fire({
                                            icon: 'error',
                                            title: 'Error',
                                            text: response.message,
                                        })
                                    } else {
																				let vehicleIdVal = $("[name=vehicleId]").val();
                                        let content = `<option value="">Select Vehicle</option>`
                                        response.data.data.forEach((element, key) => {
                                            let selected = (vehicleIdVal != '')?(vehicleIdVal == element?.vehicleId?._id?.toString())?'selected':((vehicle != '') && (element.vehicleId._id.toString() == vehicle.toString()))?'selected':'':''
                                            content += `<option value="${element.vehicleId._id.toString()}" ${selected}>${element.vehicleName}</option>`
                                        });
                    
                                        $("[name=vehicleId]").html(content)
                                        $("[name=vehicleId]").trigger('change')
                                    }
                                },
                                error: function (res) {
                                    swal.fire({
                                        icon: 'error',
                                        title: 'Error',
                                        text: "Something Went Wrong",
                                    })
                                },
                                complete: function() {
                                    $('#loader').hide();
                                }
                            })
                        }
                    }
                },
                error: function (res) {
                    swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: "Something Went Wrong",
                    })
                },
                complete: function() {
                    $('#loader').hide();
                }
            })
        }
    }
})

$(document).on("change", "[name=stopId]", function(){
    let thisElem = $(this); 

    if($(this).attr("data-order") == 1){
        thisElem.closest(".appendedStopRow").find("[name=distance]").val(0);
        distanceCalculation()
        thisElem.closest(".appendedStopRow").find("[name=distance]").attr("readonly", "readonly")
        // thisElem.closest("#form").find("[name=routeDistance]").val()

    } else if($(this).attr("data-order") > 1){
        let start = {}
        let end = {}

        let destinationPoints = $(this).find("option:selected").attr("data-coordinate");
        end.latitude = destinationPoints.split(",")[0]
        end.longitude = destinationPoints.split(",")[1]
        
        let fromPoints = $(this).closest(".appendedStopRow").prev(".appendedStopRow").find("[name=stopId] option:selected").attr("data-coordinate");
        start.latitude = fromPoints.split(",")[0]
        start.longitude = fromPoints.split(",")[1]

        $.ajax({
            type: 'POST',
            headers: requestHeader,
            url: "/getPreciseDistance",
            data: {
                start: start,
                end: end,
            },
            dataType: "JSON",
            beforeSend: function() {
                $('#loader').show();
            },
            success: function (response) {
                if (response.status == false) {
                    swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: response.message,
                    })
                    thisElem.closest(".appendedStopRow").find("[name=stopId]").val('')
                } else {
                    thisElem.closest(".appendedStopRow").find("[name=distance]").val(response.data);
                    distanceCalculation()
                }
            },
            error: function (res) {
                swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: (res.responseJSON)?res.responseJSON.message:"Something Went Wrong",
                })
            },
            complete: function() {
                $('#loader').hide();
            }
        })
    }
});

$(document).on("change", "[name=parentPhone]", function(){
	$.ajax({
		type: "POST",
		headers: requestHeader,
		url: apiUrl + "parent-exist-check",
		data: {
			parentPhone: $("[name=parentPhone]").val(),
		},
		dataType: "JSON",
        beforeSend: function() {
            $('#loader').show();
        },
		success: function (response) {
			if (response.status == false) {
				swal.fire({
					icon: "error",
					title: "Error",
					text: response.message,
				});
				$("[name=parentPhone]").val("");
			} else {
				swal.fire({
					icon: "success",
					title: "Success",
					text: `Parent Name: ${response.data.parentExist.firstName} ${response.data.parentExist.lastName}, Email: ${response.data.parentExist.email}`,
				});
                $("[name=email]").val(response.data.autogeneratedStudentEmail);
                $("[name=email]").trigger("change");
			}
		},
		error: function (res) {
			swal.fire({
				icon: "error",
				title: "Error",
				text: "Something Went Wrong. Please provide a valid phone number.",
			});
		},
        complete: function() {
            $('#loader').hide();
        }
	});
});

$(document).on("change", ".customerPhone", function(){
	$.ajax({
		type: "POST",
		headers: requestHeader,
		url: apiUrl + "customer-exist-check",
		data: {
			customerPhone: $(".customerPhone").val(),
		},
		dataType: "JSON",
        beforeSend: function() {
            $('#loader').show();
        },
		success: function (response) {
			if (response.status == false) {
				swal.fire({
					icon: "error",
					title: "Error",
					text: response.message,
				});
				$("[name=phone]").val("");
			} else {
                swal.fire({
                    icon: "success",
					title: "Success",
					text: `Customer Name: ${response.data.firstName} ${response.data.lastName}, Email: ${response.data.email}`,
				});
                // console.log(response.data);
                $("[name=firstName]").val(response.data.firstName);
                $("[name=lastName]").val(response.data.lastName);
                $("[name=email]").val(response.data.email);
                $("[name=phone]").val(response.data.phone);
                // $("[name=address]").val(response.data.address);
                // $("[name=state]").val(response.data.state);
			}
		},
		error: function (res) {
			swal.fire({
				icon: "error",
				title: "Error",
				text: "Something Went Wrong",
			});
		},
        complete: function() {
            $('#loader').hide();
        }
	});
});

$(document).on("input", ".stopDistances", function(){
    distanceCalculation()
});

function searchList(url, element, pageNo = false, documentPerPage = false){
    let datas = {}
    if($(".pagination_box").length){
        datas['pageNo'] = pageNo? pageNo : 1;
        datas['documentPerPage'] = 10;
    }
    $(".searchable").each(function(){
        datas[$(this).attr('name')] = $(this).val();
    })
    $.ajax({
        type: 'POST',
        headers: requestHeader,
        url: apiUrl + url,
        data: datas,
        dataType: "JSON",
        beforeSend: function() {
            $('#loader').show();
        },
        success: function (response) {
            if (response.status == false) {
                swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: response.message,
                })
            } else {
                content = '';
                if(response.data.data.length > 0){
                    let currentPage = (response?.data?.pagination?.currentPage)? (response.data.pagination.currentPage) : 1;
                    let rowPerPage = (response?.data?.pagination?.rowsPerPage)? (response.data.pagination.rowsPerPage) : 10;
                    
                    response.data.data.forEach((value, key) => {
                        content += `<tr data-id="${value._id}">`;
                        element.find("thead tr th").each(function(){
                            if($(this).attr('data-name') == 'id'){
                                content += `<td>${(currentPage - 1) * rowPerPage + (key + 1)}</td>`
                            } else if($(this).attr('data-name') == 'action'){
                                content += `
                                <td>
                                <div class="btn-group dropup">
    
                                    <div class="dropdown btn_action ">
                                        <button class="dropdown-toggle" type="button" id="dropdownMenuButton1"
                                            data-bs-toggle="dropdown" aria-expanded="false" >
                                            <i class="fa-solid fa-ellipsis" style="color: #3b02e3;" aria-hidden="true"></i>
                                        </button>
                                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1"
                                            style="" >
                                            <li>
                                                <a class="dropdown-item waves-effect edit ${
                                                        (   
                                                            (currentUrl == "permissions")
                                                            && (
                                                                (value.roleName == "Student") 
                                                                || (value.roleName == "Employee") 
                                                                || (value.roleName == "Driver") 
                                                                || (value.roleName == "Customer")
                                                            )
                                                        )
                                                        ? "disabled"
                                                        : ""
                                                    }" 
                                                    href="javascript:void(0)" 
                                                    ${
                                                        (
                                                            (currentUrl == "permissions")
                                                            && (
                                                                (value.roleName == "Student") 
                                                                || (value.roleName == "Employee") 
                                                                || (value.roleName == "Driver") 
                                                                || (value.roleName == "Customer")
                                                            )
                                                        )
                                                        ? `tabindex="-1" aria-disabled="true"`
                                                        : ""
                                                    }
                                                ><span><i
                                                            class="fa-solid fa-pen-to-square"></i></span>Edit</a>
                                            </li>
                                            <li>
                                            <a class="dropdown-item waves-effect delete ${
                                                    (   
                                                        (currentUrl == "users")
                                                        && (
                                                            (value.roleName == "Corporate") 
                                                            || (value.roleName == "School") 
                                                            || (value.roleName == "Vendor") 
                                                            || (value.roleName == "Company")

                                                            || (value.role == "Corporate")
                                                            || (value.role == "School")
                                                            || (value.role == "Vendor")
                                                            || (value.role == "Company")
                                                        )
                                                    )
                                                    ? "disabled"
                                                    : ""
                                                }" 
                                                href="javascript:void(0)"
                                                ${
                                                    (   
                                                        (currentUrl == "users")
                                                        && (
                                                            (value.roleName == "Corporate") 
                                                            || (value.roleName == "School") 
                                                            || (value.roleName == "Vendor") 
                                                            || (value.roleName == "Company")

                                                            || (value.role == "Corporate")
                                                            || (value.role == "School")
                                                            || (value.role == "Vendor")
                                                            || (value.role == "Company")
                                                        )
                                                    )
                                                    ? `tabindex="-1" aria-disabled="true"`
                                                    : ""
                                                }><span><i
                                                            class="fa-solid fa-trash"></i></span>Delete</a>
                                            </li>
                                        </ul>
                                    </div>
                                    </div>
                                </td>`
                            } else if($(this).attr('data-name') == 'reply'){
                                content += `
                                <td>
                                <div class="btn-group dropup">
    
                                    <div class="dropdown btn_action ">
                                        <button class="dropdown-toggle" type="button" id="dropdownMenuButton1"
                                            data-bs-toggle="dropdown" aria-expanded="false" >
                                            <i class="fa-solid fa-ellipsis" style="color: #3b02e3;" aria-hidden="true"></i>
                                        </button>
                                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1"
                                            style="" >
                                            <li>
                                                <a class="dropdown-item waves-effect replyToSupportRequest" 
                                                    href="javascript:void(0)" 
                                                    ><span><i
                                                            class="fa-solid fa-pen-to-square"></i></span>Reply</a>
                                            </li>
                                        </ul>
                                    </div>
                                    </div>
                                </td>`
                            } else if($(this).attr('data-name') == 'refund'){
                                let refundBtnHtml = `
                                    <div class="btn-group dropup">
                                        <div class="dropdown btn_action ">
                                                <button class="dropdown-toggle" type="button" id="dropdownMenuButton1"
                                                        data-bs-toggle="dropdown" aria-expanded="false" >
                                                        <i class="fa-solid fa-ellipsis" style="color: #3b02e3;" aria-hidden="true"></i>
                                                </button>
                                                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1"
                                                        style="" >
                                                        <li>
                                                                <a class="dropdown-item waves-effect refundMoneyBtn" 
                                                                        href="javascript:void(0)" 
                                                                        data-gateway="${value?.gatewayName}"
                                                                        ><span><i
                                                                                        class="fa-solid fa-pen-to-square"></i></span>${(value?.refundStatus == "Refunded")? "Refunded" : "Refund"}</a>
                                                        </li>
                                                </ul>
                                        </div>
                                    </div>
                                `;
                                content += `
                                <td>
								${((value?.type == "refund") || (value?.refundStatus == "Refunded"))? "-" : refundBtnHtml}
                                </td>`
							}
                            else if($(this).attr('data-name') == 'parentModule'){
                                content += `<td>${value?.parentModuleId?.moduleName ?? 'N/A'}</td>`
                            }
                            else{
                                if($.isArray(value[$(this).attr('data-name')])){
                                    // if value is an array, prints the array in listed format ========
                                    content += `<td>
                                                    <ul>`
                                    value[$(this).attr('data-name')].forEach(val => {
                                        content += `<li>${val}</li>`
                                    })
                                    content += `    </ul>
                                                </td>`
                                    
                                }else{
                                    if(!$(this).attr('data-name').includes("Image")){
                                        content += `<td>${
                                            (value[$(this).attr('data-name')])
                                                ? value[$(this).attr('data-name')] 
                                                : "N/A"
                                        }</td>`
    
                                    } else if($(this).attr('data-name').includes("contentImage")){
                                        content += `<td>
                                            <img crossorigin='anonymous' src="${value[$(this).attr('data-name')]}" width="200" height="100">
                                        </td>`
                                    }
                                }
                            }
                        })
                        content += `</tr>`
                    })
                } else {
                    content += `<tr><td colspan="20" style="text-align: center;">No data found.</td></tr>`
                }
                element.find("tbody").html(content);

                if(response.data.pagination){
                    const totalPages = response.data.pagination.totalPages; // Total pages available
                    let currentPage = response.data.pagination.currentPage; // Current active page
                    let startPage = (totalPages > 5)?Math.max(1, currentPage - 2):1;
                    let endPage = (totalPages > 5)?Math.min(totalPages, startPage + 4):5;
                    paginationContent = `<nav aria-label="Page navigation example"><ul class="pagination">`
                    if(totalPages > 5){
                        if (currentPage > 1) {
                            paginationContent += `<li class="page-item">
                                <a class="page-link pageNo" href="javascript:void(0);" data-pageno="${response.data.pagination.currentPage -1}" aria-label="Previous">
                                    <span aria-hidden="true">«</span>
                                </a>
                            </li>`;
                        }
                    }
                    for (let i = startPage; i <= endPage; i++) {
                        paginationContent += `<li class="page-item ${i === currentPage ? 'active' : ''}">
                            <span class="page-link pageNo" data-pageno="${i}">${i}</span>
                        </li>`;
                    }
                    if(totalPages > 5){
                        if (currentPage < totalPages) {
                            paginationContent += `<li class="page-item">
                                <a class="page-link pageNo" href="javascript:void(0);" data-pageno="${response.data.pagination.currentPage + 1}" aria-label="Next">
                                    <span aria-hidden="true">»</span>
                                </a>
                            </li>`;
                        }
                    }
                    paginationContent += `</ul></nav>`


                    // paginationContent = `<nav aria-label="Page navigation example">
                    //     <ul class="pagination">
                    //         <li class="page-item ${(!response.data.pagination.hasPrevPage)? "diabl":""}">
                    //             <a class="page-link pageNavBtn previousPageNavBtn ${(!response.data.pagination.hasPrevPage)? "pointerEventNone":""}" href="javascript:void(0);" aria-label="Previous" data-pageno="${response.data.pagination.currentPage -1}">
                    //             <span aria-hidden="true">&laquo;</span>
                    //             </a>
                    //         </li>`;

                    // for(let i = 1; i <= response.data.pagination.totalPages; i++){
                    //     paginationContent += `<li class="page-item pageNo " data-pageno="${i}"><span class="page-link ${(response.data.pagination.currentPage == i)? "activePage":""}">${i}</span></li>`
                    // }

                    // paginationContent += `<li class="page-item ${(!response.data.pagination.hasNextPage)? "diabl":""}">
                    //             <a class="page-link pageNavBtn nextPageNavBtn ${(!response.data.pagination.hasNextPage)? "pointerEventNone":""}" href="javascript:void(0);" aria-label="Next" data-pageno="${response.data.pagination.currentPage + 1}">
                    //             <span aria-hidden="true">&raquo;</span>
                    //             </a>
                    //         </li>
                    //     </ul>
                    // </nav>`;

                    $(".pagination_box").html(paginationContent);
                }
            }
        },
        error: function (res) {
            swal.fire({
                icon: 'error',
                title: 'Error',
                text: "Something Went Wrong",
            })
        },
        complete: function() {
            $('#loader').hide();
        }
    })
}
function distanceCalculation(){
    let distance = 0
    $(".stopDistances").each(function () { 
        let val = ($(this).val() != '')?$(this).val():0
        distance = (parseFloat(distance) + parseFloat(val)).toFixed(3)
     })
     $("[name=routeDistance]").val(distance)
}
