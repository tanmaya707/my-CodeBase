const loaderHTML = `
<div id="loader" style="display: none;">
    <div class="spinner-wrapper">
    <div class="spinner"></div>
    <p class="loading-text">Loading...</p> 
    </div>
</div>
`;

$('body').append(loaderHTML);

$(document).on("submit", "#form", function(e){
    e.preventDefault()
})
$(document).ready(function(){
    $.validator.addMethod(
        "passRegex",
        function(value, element) {
            var re = /^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*[!@#$%&*])[a-zA-Z0-9!@#$%&*]+$/;
            return this.optional(element) || re.test(value);
        }, "Password must contain atleast 1 upppercase, 1 lowercase and 1 special character"
    );
    $.validator.addMethod(
        "phoneRegex",
        function(value, element) {
            var re = /^[0-9]{10}$/;
            return this.optional(element) || re.test(value);
        }, "Enter a valid phone number"
    );
    $.validator.addMethod(
        "imageRequired",
        function(value, element) {
            if($("[name=_id]").val() != ''){
                return true
            }else{
                if(value == ''){
                    return false
                }else{
                    return true
                }
            }
        }, "This is a required field"
    );
    
    let rules = {}
    let rules2 = {}
    $("#form .form-submit-data").each(function(){
        let obj = {}
        if($(this).attr("data-valid")) {
            $(this).attr("data-valid").split(',').forEach(element => {
                element.replaceAll(" ", "")
                obj[element] = true
            })
        }
        rules[$(this).attr("name")] = obj
        
    })
    $("#form2 .form-submit-data").each(function(){
        let obj = {}
        if($(this).attr("data-valid")) {
            $(this).attr("data-valid").split(',').forEach(element => {
                element.replaceAll(" ", "")
                obj[element] = true
            })
        }
        rules2[$(this).attr("name")] = obj
        
    })
    
    $("#form").validate({    
        ignore: ".d-none, .avoidable",
        errorClass: 'invalid-feedback',
        errorElement: 'span',          
        rules: rules,
        // messages: {},
        errorPlacement: function (error, element) {
            error.insertAfter(element);
            return false;
        },
        highlight: function (element, errorClass, validClass) {
            $(element).closest("input")
            .addClass("error");
        },
        unhighlight: function (element, errorClass, validClass) {
            $(element).closest("input")
            .removeClass("error");
        },
        submitHandler: function (form) {
            var datas = new FormData($("#form")[0])
            
            if(localStorage.getItem("dangerCoOrdinates")){
                datas.append("dangerCoOrdinates", localStorage.getItem("dangerCoOrdinates"));
            }
            $.ajax({
                type: 'POST',
                headers: requestHeader,
                url: apiUrl + $("#form").attr("data-url"),
                data: datas,
                processData: false,
                contentType: false,
                dataType: "JSON",
                beforeSend: function() {
                    $('#loader').show();
                  }, 
                success: function (response) {
                    // console.log(response);
                    // return
                    if (response.status == false) {
                        swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: response.message,
                        })
                    } else {
                        
                        if($("#form").attr("action").length){
                            if($("#form").attr("data-url") == 'login'){
                                $.ajax({
                                    type: 'POST',
                                    url: '/store-session',
                                    data: {
                                        'data': response.data
                                    },
                                    dataType : "JSON",
                                    beforeSend: function() {
                                        $('#loader').show();
                                      }, 
                                    success: function (response) {
                                        if(response.status == false) {
                                            swal.fire({
                                                icon: 'error',
                                                title: 'Error',
                                                text: "Something Went Wrong",
                                            })
                                        } else {
                                            window.location.href = $("#form").attr("action")
                                        }
                                    },
                                    error: function (response) {
                                        swal.fire({
                                            icon: 'error',
                                            title: 'Error',
                                            text: "Something Went Wrong",
                                        })
                                    },
                                    complete: function() {
                                        $('#loader').hide();
                                    }
                                })
                            } else if($("#form").attr("data-url") == 'logout'){
                                $.ajax({
                                    type: 'POST',
                                    url: '/logout',
                                    data: {
                                        'data': response.data
                                    },
                                    dataType : "JSON",
                                    beforeSend: function() {
                                        $('#loader').show();
                                      }, 
                                    success: function (response) {
                                        if(response.status == false) {
                                            swal.fire({
                                                icon: 'error',
                                                title: 'Error',
                                                text: "Something Went Wrong",
                                            })
                                        } else {
                                            window.location.href = $("#form").attr("action")
                                        }
                                    },
                                    error: function (response) {
                                        swal.fire({
                                            icon: 'error',
                                            title: 'Error',
                                            text: "Something Went Wrong",
                                        })
                                    },
                                    complete: function() {
                                        $('#loader').hide();
                                    }
                                })
                            }else if($("#form").attr("data-url") == 'forget-password'){
                                if($(".otp_sect").hasClass("d-none")){
                                    $(".otp_sect").removeClass("d-none")
                                }
                                else if($(".pass_sect").hasClass("d-none")){
                                    $(".pass_sect").removeClass("d-none")
                                    $("[name=otp]").val('')
                                    $(".otp_sect").hide()
                                    $("[name=otp]").addClass("avoidable")
                                }
                                else{
                                    window.location.href = $("#form").attr("action")
                                }
                            }
                            else{
                                window.location.href = $("#form").attr("action")
                            }
                        }else{
                            location.reload()
                        }
                    }
                },
                error: function (res) {
                    swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: (res.responseJSON)?(res.responseJSON.errors)?res.responseJSON.errors[0].msg:res.responseJSON.message:"Something went Wrong",
                    })
                },
                complete: function() {
                    $('#loader').hide();
                }
            })
        }
    })
    $("#form2").validate({    
        ignore: ".d-none, .avoidable",
        errorClass: 'invalid-feedback',
        errorElement: 'span',          
        rules: rules2,
        // messages: {},
        errorPlacement: function (error, element) {
            error.insertAfter(element);
            return false;
        },
        highlight: function (element, errorClass, validClass) {
            $(element).closest("input")
            .addClass("error");
        },
        unhighlight: function (element, errorClass, validClass) {
            $(element).closest("input")
            .removeClass("error");
        },
        submitHandler: function (form) {
            var datas = new FormData($("#form2")[0])
            $.ajax({
                type: 'POST',
                headers: requestHeader,
                url: apiUrl + $("#form2").attr("data-url"),
                data: datas,
                processData: false,
                contentType: false,
                dataType: "JSON",
                beforeSend: function() {
                    $('#loader').show();
                  }, 
                success: function (response) {
                    if (response.status == false) {
                        swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: response.message,
                        })
                    } else {
                        
                        if($("#form2").attr("action").length){
                            if($("#form2").attr("data-url") == 'trip-passenger-update'){
                                calendarFormat()
                                $("#passengerModal").modal('hide');
                            }
                            else{
                                window.location.href = $("#form2").attr("action")
                            }
                        }else{
                            location.reload()
                        }
                    }
                },
                error: function (res) {
                    swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: (res.responseJSON)?(res.responseJSON.errors)?res.responseJSON.errors[0].msg:res.responseJSON.message:"Something went Wrong",
                    })
                },
                complete: function() {
                    $('#loader').hide();
                }
            })
        }
    })

})

$(document).on("click", "#getOtpButton", function(){
    $("[name=otp]").val("")
    $("[name=password]").val("")
    $("[name=otp]").addClass("d-none")
    $("[name=password]").addClass("d-none")
    $(".otp_sect").attr("style", "")
    $(".otp_sect").addClass("d-none")
    $(".pass_sect").addClass("d-none")
    $("[name=otp]").removeClass("avoidable")
    $("#form").submit()
})
$(document).on("click", "#updatepass_btn", function(){
    $("#form").submit()
})

