$(document).ready(function () {
  $('.toggle-children').click(function() {
    $(this).siblings('ul').toggle();
    $(this).text($(this).text() === '+' ? '-' : '+');
  });
  if($("#menu-tree").length){
    $("#menu-tree").sortable({
        items: "li",
        placeholder: "ui-state-highlight", // Placeholder for the dragged item
        update: function(event, ui) {
            let order = $(this).sortable('toArray', { attribute: 'data-id' });
            // Save the new order
            $.ajax({
                method: 'POST',
                headers: requestHeader,
                url: apiUrl + 'reorder-module',
                data: {
                  order: order
                },
                dataType: "JSON",
                beforeSend: function() {
                  $('#loader').show();
                },
                success: function(response) {
                    if (response.success) {
                        Swal.fire({
                            title: "Menu order saved successfully!",
                            icon: "success",
                            timer: 2000,
                            showConfirmButton: false,
                        }).then(function() {
                            window.location.reload();
                        });
                    }
                },
                complete: function() {
                  $('#loader').hide();
                }
            });
        }
    });
  }
  if($(".addRouteStop").length){
    $(".addRouteStop").trigger("click");
  }
  // Select all elements with data-valid attribute
  $("[data-valid='required']").each(function () {
    // Check if the element has a label
    let label = $(this).closest('label');
    
    if (label.length) {
        // Append the red asterisk to the label
        label.append(`<span class="redStar" style="color: red;">*</span>`);
    } else {
        // If no label, append next to the input/select
        $(this).before(`<span class="redStar" style="color: red;">*</span>`);
    }
  });
  if ($("[name=phone]").length) {
    var inputr = document.querySelector("[name=phone]");
    var itir = window.intlTelInput(inputr, {
      allowDropdown: true,
      autoHideDialCode: false,
      autoPlaceholder: "off",
      dropdownContainer: document.body,
      // excludeCountries: ["us"],
      formatOnDisplay: false,
      initialCountry: countryCodeCheck($("[name=dialcode]").val()),
      // hiddenInput: "full_number",
      placeholderNumberType: "MOBILE",
      onlyCountries: ["US", "GB", "CH", "IN", "NP", "BD", "AU", "AT", "AZ"],
      preferredCountries: ["AU"],
      separateDialCode: true,
      utilsScript: "/assets/intel-tel-info/build/js/utils.js",
    });
    inputr.addEventListener("countrychange", function () {
      $(this)
        .closest(".phoneInput")
        .find("[name=dialcode]")
        .val("+" + itir.getSelectedCountryData().dialCode);
    });
    // $(document).on("blur", "[name=phone]", function () {
    //     console.log(itir.getSelectedCountryData().dialCode, $(this).closest(".phoneInput")
    //     .find("[name=dialcode]").val())

    // });
  }
  if($(".select2").length){
    $(".select2").select2();
  }
  // if($(".select2").length){
  //   $(".select2").each(function(){
  //     $(this).select2();
  //   });
  // }

  if($(".myAccountPage").length){
    const url = "get-" + $(".myAccountPage").attr("data-name");
    const data = {
      id: $(".myAccountPage").attr("data-id"),
    };
    const form = "form";
    $.ajax({
      type: "POST",
      headers: requestHeader,
      url: apiUrl + url,
      data: data,
      dataType: "JSON",
      beforeSend: function() {
        $('#loader').show();
      },
      success: function (response) {
        if (response.status == false) {
          // response.status == false this should be response.type == false; there is nothing like status in the response ========
          swal.fire({
            icon: "error",
            title: "Error",
            text: response.message,
          });
        } else {
          if(superId){
            $("#form").find(".request-button").find("[name=_id]").remove();
            $("#form").find(".request-button").find(".submitButton[type=submit]").remove();

            $("#form").find(".request-button").css("float", "none");
            $("#form").find(".request-button").css("display", "block");

            $("#form").find(".request-button").html(`
              <div class="alert alert-info">
                <p>Profile update is not allowed for Super Admin..!! Please contact higher authority..!!</p>
              </div>
            `);

            $( "#" + form + " input" ).attr("readonly", "readonly"); 
            $( "#" + form + " select" ).attr("disabled", "true"); 
          }
          const data = response.data;
          $(
            "#" +
              form +
              " input:not(':input[type=radio], :input[type=button], :input[type=submit], :input[type=file]')"
          ).each(function () {
            var label = $(this).attr("name");
            $(this).val(data.data[label]);

            if(data.data["lastName"] == " "){
              $("[name=lastName]").closest(".lastNameDiv").remove();
              $("[name=firstName]").closest(".firstNameDiv").find("label").html("Organization Name");
            }
          });
          $("#" + form + " input[type=radio]").prop("checked", false);
          $("#" + form + " input[type=radio]").each(function () {
            var label = $(this).attr("name");
            $("#" + form)
              .find("[name=" + label + "][value=" + data.data[label] + "]")
              .prop("checked", true);
            $("#" + form)
              .find("[name=" + label + "][value=" + data.data[label] + "]")
              .trigger("click");
          });
          $("#" + form + " input[type=file]").each(function () {
            var label = $(this).attr("name");
            var fileExtension = ["jpeg", "jpg", "png"];
            var fileExtensionimage = ["jpeg", "jpg", "png"];
            
            if (data.data[label] && ($.inArray(data.data[label].split(/[#?]/)[0].split('.').pop().trim().toLowerCase(), fileExtension) != false)) {
              if (
                $.inArray(
                  data.data[label].split(/[#?]/)[0].split('.').pop().trim().toLowerCase(),
                  fileExtensionimage
                ) !== -1
              ) {
                $("[name=" + label + "]").closest(".form-group").find(".clientphoto").html(`<a href="${data.data[label]}" target="_blank"></a>`)
                $($.parseHTML("<img class='pre-img' crossorigin='anonymous'>"))
                  .attr("src", data.data[label])
                  .appendTo(
                    $("[name=" + label + "]")
                      .closest(".form-group")
                      .find(".clientphoto a")
                  );
              } else {
                $("[name=" + label + "]").closest(".form-group").find(".clientphoto").html(`<a href="${data.data[label]}" target="_blank"></a>`)
                $($.parseHTML("<img class='pre-img'>"))
                .attr("src", "../../assets/images/google-docs.png")
                .appendTo(
                  $("[name=" + label + "]")
                    .closest(".form-group")
                    .find(".clientphoto a")
                );
  
              }
            }
          });

          $("#" + form + " textarea").each(function () {
            var label = $(this).attr("name");
            if ($("#" + label).length && label == "description") {
              CKEDITOR.replace("description", {
                allowedContent: true,
              });
              CKEDITOR.instances["description"].setData(data.data.description);
            }
            $(this).val(data.data[label]);
          });
          $("#" + form + " select:not([multiple])").each(function () {
            var label = $(this).attr("name");
            $(this)
              .find("option[value='" + data.data[label] + "']")
              .prop("selected", true);
            
            $(this).select2();
          });
          $("#" + form + " select[multiple]").each(function () {
            var label = $(this).attr("name");
            data.data[label].forEach((item) => {
              $(this)
                .find("option[value='" + item + "']")
                .prop("selected", true);
            });

            $(this).select2();
          });
          $("#" + form)
            .find("[name=password]")
            .closest("div")
            .remove();
          
          if ($("#address").length) {
            $("#address").focus(function () {
              selected = false;
              autocomplete = new google.maps.places.SearchBox(
                document.getElementById("address")
              );

              postcode = "";
              autocomplete.addListener("places_changed", function () {
                selected = true;
                let place = autocomplete.getPlaces();
                const addressName = place[0].name;
                latitude = place[0].geometry.location.lat();
                longitude = place[0].geometry.location.lng();
                for (const component of place[0].address_components) {
                  // @ts-ignore remove once typings fixed
                  const componentType = component.types[0];
                  switch (componentType) {
                    case "subpremise": {
                      address1 = `${component.long_name} ${address1}`;
                      break;
                    }
                    case "premise": {
                      address1 += component.short_name;
                      break;
                    }
                    case "postal_code": {
                      postcode = `${component.long_name}${postcode}`;
                      break;
                    }
                    // case "postal_code_suffix": {
                    //     postcode = `${postcode}-${component.long_name}`;
                    //     break;
                    // }
                    case "locality": {
                      locality = component.long_name;
                      break;
                    }
                    case "administrative_area_level_1": {
                      state = component.long_name;
                      break;
                    }
                    case "country":
                      country = component.long_name;
                      break;
                    case "sublocality_level_3":
                      landmark = component.long_name;
                      break;
                  }
                }
                //   console.log(
                //     `address : ${address1}
                //         postcode : ${postcode}
                //         locality : ${locality}
                //         state : ${state}
                //         country : ${country}
                //         landmark : ${landmark}
                //         lat : ${lat}
                //         lng : ${lng}`
                //   );

                $("[name=city]").val(locality);
                $("[name=state]").val(state);
                $("[name=zipcode]").val(postcode);
                $("[name=country]").val(country);
                $("[name=latitude]").val(latitude);
                $("[name=longitude]").val(longitude);
              });
            });
          }
          if ($("#dangerAddress").length) {
            $("#dangerAddress").focus(function () {
              selected = false;
              autocomplete = new google.maps.places.SearchBox(
                document.getElementById("dangerAddress")
              );

              postcode = "";
              autocomplete.addListener("places_changed", function () {
                selected = true;
                let place = autocomplete.getPlaces();
                const addressName = place[0].name;
                latitude = place[0].geometry.location.lat();
                longitude = place[0].geometry.location.lng();
                for (const component of place[0].address_components) {
                  // @ts-ignore remove once typings fixed
                  const componentType = component.types[0];
                  switch (componentType) {
                    case "subpremise": {
                      address1 = `${component.long_name} ${address1}`;
                      break;
                    }
                    case "premise": {
                      address1 += component.short_name;
                      break;
                    }
                    case "postal_code": {
                      postcode = `${component.long_name}${postcode}`;
                      break;
                    }
                    // case "postal_code_suffix": {
                    //     postcode = `${postcode}-${component.long_name}`;
                    //     break;
                    // }
                    case "locality": {
                      locality = component.long_name;
                      break;
                    }
                    case "administrative_area_level_1": {
                      state = component.long_name;
                      break;
                    }
                    case "country":
                      country = component.long_name;
                      break;
                    case "sublocality_level_3":
                      landmark = component.long_name;
                      break;
                  }
                }
                //   console.log(
                //     `address : ${address1}
                //             postcode : ${postcode}
                //             locality : ${locality}
                //             state : ${state}
                //             country : ${country}
                //             landmark : ${landmark}
                //             lat : ${lat}
                //             lng : ${lng}`
                //   );

                //   $("[name=city]").val(locality);
                //   $("[name=state]").val(state);
                //   $("[name=zipcode]").val(postcode);
                //   $("[name=country]").val(country);
                $("[name=dangerLatitude]").val(latitude);
                $("[name=dangerLongitude]").val(longitude);
              });
            });
          }
          if ($("#branches").length) {
            response.data.data.organizations.forEach((org) => {
              $("#branches").find("label").append(`
                  <div class="col-lg-12 col-12">
                      <input type="text" name="orgBranch" class="form-control mt-2" placeholder="Enter Branch Name 1" value="${org.orgBranch}" data-valid="required">
              
                      <input type="text" class="form-control form-submit-data address mt-2" id="address1" placeholder="Enter Address for Branch 1" name="orgAddress" value="${org.orgAddress}" data-valid="required">
              
                      <input type="hidden" name="orgLatitude" data-valid="required" value="${org.orgLatitude}">
                      <input type="hidden" name="orgLongitude" data-valid="required" value="${org.orgLongitude}">
              
                      <hr>
                  </div>
                  `);
            });
          }
          if ($("#holidays").length) {
            response.data.data.holidaysArr.forEach((holiday, index) => {
              $("#holidays").find(".row")
                .append(`<div class="col-lg-6">                                        
                      ${
                        index + 1
                      }. <input type="date" name="holidays" class="form-control mb-2" value="${holiday}">
                      </div>`);
            });
          }
          let routeStops = response.data.data.routeStops;
          let stopsArr = [];
          if ($("#stops").length) {
            if ($("[name=routeType]").length) {
              if (stopsArr.length == 0) {
                $.ajax({
                  type: "GET",
                  headers: requestHeader,
                  url: apiUrl + "tripStop-list",
                  dataType: "JSON",
                  beforeSend: function() {
                    $('#loader').show();
                  }, 
                  success: function (response) {
                    if (response.status == false) {
                      swal.fire({
                        icon: "error",
                        title: "Error",
                        text: response.message,
                      });
                    } else {
                      stopsArr = response.data.data;

                      if (stopsArr.length > 0) {
                        routeStops.forEach((item, index) => {
                          let html = ``;
                          stopsArr.forEach((stop) => {
                            html += `
                              <option value="${stop._id.toString()}" data-coordinate="${
                              stop.location.coordinates
                            }" ${
                              stop._id.toString() == item.stopId.toString()
                                ? "selected"
                                : ""
                            }>${stop.stopName} (${stop.stopType}) ${
                              stop.isDanger == "Yes" ? "(Danger)" : ""
                            }</option>
                            `;
                          });
                          $("#stops").append(`
                            <div class="col-lg-6 col-12 mb-3">
                                <div class="dashmhri_select">
                                    <label for="">Stop ${index + 1}</label>
                                    <select class="form-select form-submit-data user mt-2 mb-3 select2" name="stopId" aria-label="Default select example" data-valid="required">
                                        <option value="">Select Stop</option>
                                        ${html}
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-2 col-12 mb-3">
                                <label for="" class="form-label">Order</label>
                                <input type="text" name="order" placeholder="Enter Route Order" class="form-control form-submit-data user" data-valid="required" value="${
                                  index + 1
                                }" readonly>
                            </div>
                            <div class="col-lg-4 col-12 mb-3">
                              <label for="" class="form-label">Distance</label>
                              <input type="text" name="distance" placeholder="Enter Distance" class="form-control form-submit-data user" value="${
                                item.distance
                              }" data-valid="required" >
                            </div>
                          `);
                        });
                      }
                    }
                  },
                  error: function (res) {
                    swal.fire({
                      icon: "error",
                      title: "Error",
                      text: "Something Went Wrong",
                    });
                  },
                  complete: function() {
                    $('#loader').hide();
                  }
                });
              }
            }
          }

          if ($(".schedule").length) {
            if (data.data.schedule.length > 1) {
              // means customized ===================
              data.data.schedule.forEach((val) => {
                $("[name=dayName][value=" + val.dayName + "]").prop(
                  "checked",
                  true
                );
                $("[name=dayName][value=" + val.dayName + "]")
                  .closest(".day_sec")
                  .find("[name=startTime]")
                  .val(val.startTime);
                $("[name=dayName][value=" + val.dayName + "]")
                  .closest(".day_sec")
                  .find("[name=endTime]")
                  .val(val.endTime);
              });
            } else {
              // means daily ===================
              $(".day_sec")
                .find("[name=startTime]")
                .val(data.data.schedule[0].startTime);
              $(".day_sec")
                .find("[name=endTime]")
                .val(data.data.schedule[0].endTime);
            }
          }

          $("#" + form)
            .closest(".modal")
            .modal("show");

          
        }
      },
      error: function (res) {
        swal.fire({
          icon: "error",
          title: "Error",
          text: "Something Went Wrong",
        });
      },
      complete: function() {
        $('#loader').hide();
      }

    });
  }

  if($(".supportPage").length){
    const url = "get-" + $(".supportPage").attr("data-name");
    const data = {
      userId: $(".supportPage").attr("data-id"),
    };
    const form = "form";
    
    $.ajax({
      type: "POST",
      headers: requestHeader,
      url: apiUrl + url,
      data: data,
      dataType: "JSON",
      beforeSend: function() {
        $('#loader').show();
      }, 
      success: function (response) {
        
        if (response.status == false) {
          // response.status == false this should be response.type == false; there is nothing like status in the response ========
          swal.fire({
            icon: "error",
            title: "Error",
            text: response.message,
          });
        } else {
          // if(superId){
          //   $("#form").find(".request-button").find("[name=_id]").remove();
          //   $("#form").find(".request-button").find(".submitButton[type=submit]").remove();

          //   $("#form").find(".request-button").css("float", "none");
          //   $("#form").find(".request-button").css("display", "block");

          //   $("#form").find(".request-button").html(`
          //     <div class="alert alert-info">
          //       <p>Profile update is not allowed for Super Admin..!! Please contact higher authority..!!</p>
          //     </div>
          //   `);

          //   $( "#" + form + " input" ).attr("readonly", "readonly"); 
          //   $( "#" + form + " select" ).attr("disabled", "true"); 
          // }
          const data = response;
          $(
            "#" +
              form +
              " input:not(':input[type=radio], :input[type=button], :input[type=submit], :input[type=file]')"
          ).each(function () {
            var label = $(this).attr("name");
            $(this).val(data.data[label]);

            if(data.data["lastName"] == " "){
              $("[name=lastName]").closest(".lastNameDiv").remove();
              $("[name=firstName]").closest(".firstNameDiv").find("label").html("Organization Name");
            }
          });
          $("#" + form + " input[type=radio]").prop("checked", false);
          $("#" + form + " input[type=radio]").each(function () {
            var label = $(this).attr("name");
            $("#" + form)
              .find("[name=" + label + "][value=" + data.data[label] + "]")
              .prop("checked", true);
            $("#" + form)
              .find("[name=" + label + "][value=" + data.data[label] + "]")
              .trigger("click");
          });
          $("#" + form + " input[type=file]").each(function () {
            var label = $(this).attr("name");
            var fileExtension = ["jpeg", "jpg", "png"];
            var fileExtensionimage = ["jpeg", "jpg", "png"];
            
            if (data.data[label] && ($.inArray(data.data[label].split(/[#?]/)[0].split('.').pop().trim().toLowerCase(), fileExtension) != false)) {
              if (
                $.inArray(
                  data.data[label].split(/[#?]/)[0].split('.').pop().trim().toLowerCase(),
                  fileExtensionimage
                ) !== -1
              ) {
                $("[name=" + label + "]").closest(".form-group").find(".clientphoto").html(`<a href="${data.data[label]}" target="_blank"></a>`)
                $($.parseHTML("<img class='pre-img' crossorigin='anonymous'>"))
                  .attr("src", data.data[label])
                  .appendTo(
                    $("[name=" + label + "]")
                      .closest(".form-group")
                      .find(".clientphoto a")
                  );
              } else {
                $("[name=" + label + "]").closest(".form-group").find(".clientphoto").html(`<a href="${data.data[label]}" target="_blank"></a>`)
                $($.parseHTML("<img class='pre-img'>"))
                .attr("src", "../../assets/images/google-docs.png")
                .appendTo(
                  $("[name=" + label + "]")
                    .closest(".form-group")
                    .find(".clientphoto a")
                );
  
              }
            }
          });

          $("#" + form + " textarea").each(function () {
            var label = $(this).attr("name");
            if ($("#" + label).length && label == "description") {
              CKEDITOR.replace("description", {
                allowedContent: true,
              });
              CKEDITOR.instances["description"].setData(data.data.description);
            }
            $(this).val(data.data[label]);
          });
          $("#" + form + " select:not([multiple])").each(function () {
            var label = $(this).attr("name");
            $(this)
              .find("option[value='" + data.data[label] + "']")
              .prop("selected", true);
            
            $(this).select2();
          });
          $("#" + form + " select[multiple]").each(function () {
            var label = $(this).attr("name");
            data.data[label].forEach((item) => {
              $(this)
                .find("option[value='" + item + "']")
                .prop("selected", true);
            });

            $(this).select2();
          });
          $("#" + form)
            .find("[name=password]")
            .closest("div")
            .remove();
          
          if ($("#address").length) {
            $("#address").focus(function () {
              selected = false;
              autocomplete = new google.maps.places.SearchBox(
                document.getElementById("address")
              );

              postcode = "";
              autocomplete.addListener("places_changed", function () {
                selected = true;
                let place = autocomplete.getPlaces();
                const addressName = place[0].name;
                latitude = place[0].geometry.location.lat();
                longitude = place[0].geometry.location.lng();
                for (const component of place[0].address_components) {
                  // @ts-ignore remove once typings fixed
                  const componentType = component.types[0];
                  switch (componentType) {
                    case "subpremise": {
                      address1 = `${component.long_name} ${address1}`;
                      break;
                    }
                    case "premise": {
                      address1 += component.short_name;
                      break;
                    }
                    case "postal_code": {
                      postcode = `${component.long_name}${postcode}`;
                      break;
                    }
                    // case "postal_code_suffix": {
                    //     postcode = `${postcode}-${component.long_name}`;
                    //     break;
                    // }
                    case "locality": {
                      locality = component.long_name;
                      break;
                    }
                    case "administrative_area_level_1": {
                      state = component.long_name;
                      break;
                    }
                    case "country":
                      country = component.long_name;
                      break;
                    case "sublocality_level_3":
                      landmark = component.long_name;
                      break;
                  }
                }
                //   console.log(
                //     `address : ${address1}
                //         postcode : ${postcode}
                //         locality : ${locality}
                //         state : ${state}
                //         country : ${country}
                //         landmark : ${landmark}
                //         lat : ${lat}
                //         lng : ${lng}`
                //   );

                $("[name=city]").val(locality);
                $("[name=state]").val(state);
                $("[name=zipcode]").val(postcode);
                $("[name=country]").val(country);
                $("[name=latitude]").val(latitude);
                $("[name=longitude]").val(longitude);
              });
            });
          }
          if ($("#dangerAddress").length) {
            $("#dangerAddress").focus(function () {
              selected = false;
              autocomplete = new google.maps.places.SearchBox(
                document.getElementById("dangerAddress")
              );

              postcode = "";
              autocomplete.addListener("places_changed", function () {
                selected = true;
                let place = autocomplete.getPlaces();
                const addressName = place[0].name;
                latitude = place[0].geometry.location.lat();
                longitude = place[0].geometry.location.lng();
                for (const component of place[0].address_components) {
                  // @ts-ignore remove once typings fixed
                  const componentType = component.types[0];
                  switch (componentType) {
                    case "subpremise": {
                      address1 = `${component.long_name} ${address1}`;
                      break;
                    }
                    case "premise": {
                      address1 += component.short_name;
                      break;
                    }
                    case "postal_code": {
                      postcode = `${component.long_name}${postcode}`;
                      break;
                    }
                    // case "postal_code_suffix": {
                    //     postcode = `${postcode}-${component.long_name}`;
                    //     break;
                    // }
                    case "locality": {
                      locality = component.long_name;
                      break;
                    }
                    case "administrative_area_level_1": {
                      state = component.long_name;
                      break;
                    }
                    case "country":
                      country = component.long_name;
                      break;
                    case "sublocality_level_3":
                      landmark = component.long_name;
                      break;
                  }
                }
                //   console.log(
                //     `address : ${address1}
                //             postcode : ${postcode}
                //             locality : ${locality}
                //             state : ${state}
                //             country : ${country}
                //             landmark : ${landmark}
                //             lat : ${lat}
                //             lng : ${lng}`
                //   );

                //   $("[name=city]").val(locality);
                //   $("[name=state]").val(state);
                //   $("[name=zipcode]").val(postcode);
                //   $("[name=country]").val(country);
                $("[name=dangerLatitude]").val(latitude);
                $("[name=dangerLongitude]").val(longitude);
              });
            });
          }
          if ($("#branches").length) {
            response.data.data.organizations.forEach((org) => {
              $("#branches").find("label").append(`
                  <div class="col-lg-12 col-12">
                      <input type="text" name="orgBranch" class="form-control mt-2" placeholder="Enter Branch Name 1" value="${org.orgBranch}" data-valid="required">
              
                      <input type="text" class="form-control form-submit-data address mt-2" id="address1" placeholder="Enter Address for Branch 1" name="orgAddress" value="${org.orgAddress}" data-valid="required">
              
                      <input type="hidden" name="orgLatitude" data-valid="required" value="${org.orgLatitude}">
                      <input type="hidden" name="orgLongitude" data-valid="required" value="${org.orgLongitude}">
              
                      <hr>
                  </div>
                  `);
            });
          }
          if ($("#holidays").length) {
            response.data.data.holidaysArr.forEach((holiday, index) => {
              $("#holidays").find(".row")
                .append(`<div class="col-lg-6">                                        
                      ${
                        index + 1
                      }. <input type="date" name="holidays" class="form-control mb-2" value="${holiday}">
                      </div>`);
            });
          }
          if ($("#stops").length) {
            let routeStops = response.data.data.routeStops;
            let stopsArr = [];
            if ($("[name=routeType]").length) {
              if (stopsArr.length == 0) {
                $.ajax({
                  type: "GET",
                  headers: requestHeader,
                  url: apiUrl + "tripStop-list",
                  dataType: "JSON",
                  beforeSend: function() {
                    $('#loader').show();
                  }, 
                  success: function (response) {
                    if (response.status == false) {
                      swal.fire({
                        icon: "error",
                        title: "Error",
                        text: response.message,
                      });
                    } else {
                      stopsArr = response.data.data;

                      if (stopsArr.length > 0) {
                        routeStops.forEach((item, index) => {
                          let html = ``;
                          stopsArr.forEach((stop) => {
                            html += `
                              <option value="${stop._id.toString()}" data-coordinate="${
                              stop.location.coordinates
                            }" ${
                              stop._id.toString() == item.stopId.toString()
                                ? "selected"
                                : ""
                            }>${stop.stopName} (${stop.stopType}) ${
                              stop.isDanger == "Yes" ? "(Danger)" : ""
                            }</option>
                            `;
                          });
                          $("#stops").append(`
                            <div class="col-lg-6 col-12 mb-3">
                                <div class="dashmhri_select">
                                    <label for="">Stop ${index + 1}</label>
                                    <select class="form-select form-submit-data user mt-2 mb-3 select2" name="stopId" aria-label="Default select example" data-valid="required">
                                        <option value="">Select Stop</option>
                                        ${html}
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-2 col-12 mb-3">
                                <label for="" class="form-label">Order</label>
                                <input type="text" name="order" placeholder="Enter Route Order" class="form-control form-submit-data user" data-valid="required" value="${
                                  index + 1
                                }" readonly>
                            </div>
                            <div class="col-lg-4 col-12 mb-3">
                              <label for="" class="form-label">Distance</label>
                              <input type="text" name="distance" placeholder="Enter Distance" class="form-control form-submit-data user" value="${
                                item.distance
                              }" data-valid="required" >
                            </div>
                          `);
                        });
                      }
                    }
                  },
                  error: function (res) {
                    swal.fire({
                      icon: "error",
                      title: "Error",
                      text: "Something Went Wrong",
                    });
                  },
                  complete: function() {
                    $('#loader').hide();
                  }
                });
              }
            }
          }

          if ($(".schedule").length) {
            if (data.data.schedule.length > 1) {
              // means customized ===================
              data.data.schedule.forEach((val) => {
                $("[name=dayName][value=" + val.dayName + "]").prop(
                  "checked",
                  true
                );
                $("[name=dayName][value=" + val.dayName + "]")
                  .closest(".day_sec")
                  .find("[name=startTime]")
                  .val(val.startTime);
                $("[name=dayName][value=" + val.dayName + "]")
                  .closest(".day_sec")
                  .find("[name=endTime]")
                  .val(val.endTime);
              });
            } else {
              // means daily ===================
              $(".day_sec")
                .find("[name=startTime]")
                .val(data.data.schedule[0].startTime);
              $(".day_sec")
                .find("[name=endTime]")
                .val(data.data.schedule[0].endTime);
            }
          }

          // $("#" + form)
          //   .closest(".modal")
          //   .modal("show");

          
        }
      },
      error: function (res) {
        swal.fire({
          icon: "error",
          title: "Error",
          text: "Something Went Wrong",
        });
      },
      complete: function() {
        $('#loader').hide();
      }
    });
  }

  if($("#videoElement").length){
    const video = document.getElementById("videoElement");
    const captureButton = document.getElementById("captureButton");
  
    navigator.mediaDevices.getUserMedia({ video: true }).then(function (stream) {
      video.srcObject = stream;
    })
    .catch(function (error) {
      console.error("Error accessing the camera: ", error);
    });
  
    captureButton.addEventListener("click", function () {
      const canvas = document.createElement("canvas");
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const context = canvas.getContext("2d");
      context.drawImage(video, 0, 0, canvas.width, canvas.height);
      const imageData = canvas.toDataURL("image/jpeg");
      
      if($("[name=frsImage]").length){
        // $("[name=frsImage]").val(JSON.stringify({ image: imageData }));
        $("[name=frsImage]").val(JSON.stringify(imageData));
      }
    });

  }
  
});

let i = 1;
$(document).on("click", ".addOrganization", function(){
    $("#branches").append(`
    <div class="col-lg-12 col-12 appendedBranch">
        <button type="button" class="btn btn-sm btn-danger pull-right mb-1 deleteAppendedBranch">-</button>
        <input type="text" name="orgBranch" class="form-control mt-2" placeholder="Enter Branch Name" data-valid="required" >

        <input type="text" class="form-control form-submit-data address mt-2" id="address${i}" placeholder="Enter Address for Branch" name="orgAddress" data-valid="required" >

        <input type="hidden" name="orgLatitude" data-valid="required" >
        <input type="hidden" name="orgLongitude" data-valid="required" >

        <hr>
    </div>
    `);
    // for multiple branches =============
    $(".address").each(function () {
      let element = $(this);
      $(this).focus(function () {
        autocomplete = new google.maps.places.SearchBox(
          document.getElementById($(this).attr("id"))
        );
        postcode = "";
        autocomplete.addListener("places_changed", function () {
          let place = autocomplete.getPlaces();
          let addressName = place[0].name;
          let latitude = place[0].geometry.location.lat();
          let longitude = place[0].geometry.location.lng();
          for (const component of place[0].address_components) {
            // @ts-ignore remove once typings fixed
            const componentType = component.types[0];
            switch (componentType) {
              case "subpremise": {
                address1 = `${component.long_name} ${address1}`;
                break;
              }
              case "premise": {
                address1 += component.short_name;
                break;
              }
              case "postal_code": {
                postcode = `${component.long_name}${postcode}`;
                break;
              }
              // case "postal_code_suffix": {
              //     postcode = `${postcode}-${component.long_name}`;
              //     break;
              // }
              case "locality": {
                locality = component.long_name;
                break;
              }
              case "administrative_area_level_1": {
                state = component.long_name;
                break;
              }
              case "country":
                country = component.long_name;
                break;
              case "sublocality_level_3":
                landmark = component.long_name;
                break;
            }
          }
          //   $("[name=city]").val(locality);
          //   $("[name=state]").val(state);
          //   $("[name=zipcode]").val(postcode);
          //   $("[name=country]").val(country);
          element.closest("div").find(`[name=orgLatitude]`).val(latitude);
          element.closest("div").find(`[name=orgLongitude]`).val(longitude);
        });
      });
    });
    // for multiple branches =============
    $("#form").closest(".modal").modal("show");
    // increment =====
    i++
    // increment =====
});

// $(document).on("click", ".deleteAppendedBranch", function(){
//   $(this).closest(".appendedBranch").remove();
//   i--;
// });

$(document).on("click", ".deleteAppendedBranch", function() {
  $(this).closest(".appendedBranch")
    .fadeOut(300)
    .queue(function(next) {
      $(this).remove(); // Remove after fading out
      i--; // Decrement the counter
      next(); // Move to the next item in the queue
    });
});

let j = 1;
$(document).on("click", ".addHoliday", function(){
    $(this).closest("div").find('.row').append(`
        <div class="col-lg-6 appendedHoliday">
            <button type="button" class="btn btn-sm btn-danger pull-right mb-1 deleteAppendedHoliday">-</button>
            <input type="date" name="holidays" class="form-control mb-2">
        </div>
    `);
    // increment =====
    j++
    // increment =====
});

$(document).on("click", ".deleteAppendedHoliday", function() {
  $(this).closest(".appendedHoliday")
    .fadeOut(300)
    .queue(function(next) {
      $(this).remove(); // Remove after fading out
      j--; // Decrement the counter
      next(); // Move to the next item in the queue
    });
});

$(document).on("click", "[name=tripType]", function(){
  let days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  if($("[name=tripType]:checked").val() == "Daily"){

    $(".schedule").html(`
    <fieldset >
      <legend>Daily Timing</legend>
      <div class="row day_sec">
        <div class="col-lg-6 col-6 mb-3 ">
          <input type="time" name="startTime" class="form-control form-submit-data" data-valid="required">
        </div>
        <div class="col-lg-6 col-6 mb-3 ">
          <input type="time" name="endTime" class="form-control form-submit-data" data-valid="required">
        </div>
      </div>
    </fieldset>
    `);
  } 
  else if($("[name=tripType]:checked").val() == "Customized"){
    
    let html = ``;
    html += `
    <fieldset>
      <legend>Customized Timing</legend>
    `;
    days.forEach((day)=>{
      html += `
        <div class="row col-lg-12 col-6 mb-2 day_sec">
          <div class="col-lg-4 col-6 mb-2">
            <label>
              <input type="checkbox" name="dayName" class=" dayName" value="${day}"> 
              ${day}
            </label>
          </div>
          <div class="col-lg-4 col-6 mb-3">
            <input type="time" name="startTime" class=" form-control" >
          </div>
          <div class="col-lg-4 col-6 mb-3">
            <input type="time" name="endTime" class=" form-control" >
          </div>
        </div>
      `;
    });

    html += `</fieldset>`;

    $(".schedule").html(html);
    
  }
  else if($("[name=tripType]:checked").val() == "OneTime"){
    
    let html = ``;
    html += `
    <fieldset>
      <legend>One Time Trip Timing</legend>
      <div class="row day_sec">
        <div class="col-md-6 col-6 mb-3">
          <label>Choose Date</label>
          <input type="date" name="oneTimeDate" class="form-control form-submit-data oneTimeDate" >
        </div>
        <div class="row col-md-6 col-6">
          <div class="col-lg-12 col-6 mb-3">
            <label>Start Time</label>
            <input type="time" name="startTime" class=" form-control" >
          </div>
          <div class="col-lg-12 col-6 mb-3">
            <label>End Time</label>
            <input type="time" name="endTime" class=" form-control" >
          </div>
        </div>
      </div>
    </fieldset>
    `;

    $(".schedule").html(html);
    
  }
});

$(document).on("change", "[name=routeId]", function(){
  if(currentUrl != "trip-tabular-view"){
    if(
      ($("[name=routeId]").val())
      && ($(this).hasClass("populateStopList"))
    ){
      $.ajax({
        type: 'POST',
        headers: requestHeader,
        url: apiUrl + "stops-list",
        data: {
          routeId: $("[name=routeId]").val(),
        },
        dataType: "JSON",
        beforeSend: function() {
          $('#loader').show();
        }, 
        success: function (response) {
            if (response.status == false) {
                swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: response.message,
                })
            } else {
              // console.log(response.data.routeStops); return;
              let timeToReach = 0;
  
              let stopNamesHtml = ``;
              stopNamesHtml += `<div class="stops-list disp-block"><ul>`;
              response.data.routeStops.forEach((stop)=>{
                stopNamesHtml += `<li class="individualStop">
                  <div class="time row ">
                    <div class="col-md-4 col-6">
                      <input type="text" class="form-submit-data" name="tripStopId" data-order="${stop.order}" data-coordinates="${stop.stopId.location.coordinates}" value="${stop.stopId._id}" data-valid="required" hidden> ${stop.stopId.stopName}
                    </div>
                    <div class="col-md-4 col-6">
                      <input type="text" class="form-control form-submit-data user mb-3" name="distance" placeholder="Distance" data-valid="required" value="${stop.distance}" readonly> Km.
                    </div>
                    <div class="col-md-4 col-6">
                      <input type="number" class="form-control form-submit-data user mb-3" name="time" placeholder="Time" min="0" data-valid="required"> Hr
                    </div>
                  </div>
                </li>`;
              })
              stopNamesHtml += `</ul></div>`;
    
              $("#stopDetails").html(stopNamesHtml)
  
              // ========= auto-calculate time ============
              $("#stopDetails").find(".individualStop").each(function(){
  
                if($(this).find("[name=tripStopId]").attr("data-order") == 1){
                  $(this).find("[name=time]").val(0);
  
                } else if($(this).find("[name=tripStopId]").attr("data-order") > 1){
                  let averageSpeedInKmph = parseFloat(40);
                  let thisStopDistance = parseFloat($(this).find("[name=distance]").val());
  
                  let timeNeededInHour = (thisStopDistance) / averageSpeedInKmph;
  
                  let roundedOff = parseFloat(timeNeededInHour.toFixed(2));
  
                  $(this).find("[name=time]").val(roundedOff);
                }
              });
              // ========= auto-calculate time ============
  
              if($("[name=accessibility]").length){
                let accsContent = ''
                response.data.capacity.forEach(elem => {
                  accsContent += `<option value="${elem}">${elem}</option>`
                })
                $("[name=accessibility]").html(accsContent)
              }
  
              // ======== auto-calculate END TIME of TRIP based on the total time of trip ==========
              if($("[name=startTime]").length){
                $("[name=startTime]").trigger("change");
              }
              // ======== auto-calculate END TIME of TRIP based on the total time of trip ==========
            }
        },
        error: function (res) {
            swal.fire({
                icon: 'error',
                title: 'Error',
                text: "Something Went Wrong",
            })
        },
        complete: function() {
          $('#loader').hide();
        }
      });
    }
  }
});

$(document).on("change", ".fetch-corporate-detail", function(){
  if(currentUrl == "trip-plans"){
    if($(".fetch-corporate-detail").val() != ""){
      $.ajax({
        type: 'POST',
        headers: requestHeader,
        url: apiUrl + "get-corporate",
        data: {
          id: $(".fetch-corporate-detail").val(),
        },
        dataType: "JSON",
        beforeSend: function() {
          $('#loader').show();
        }, 
        success: function (response) {
            if (response.status == false) {
                swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: response.message,
                })
            } else {
              if(response?.data?.data?.isOnDemand == false){
                $(document).find("[name=isOnDemand]").prop("checked", false);
              }
              $(document).find("[name=isOnDemand2]").prop("checked", false);

              let onDemand = $(".hiddenIsOnDemand").val();
              
              // $(".onDemandCheckbox").html(``);
  
              if(response?.data?.data?.isOnDemand == true){
                $(".onDemandCheckbox").html(`
                  <input type="checkbox" name="isOnDemand2" class="form-submit-data user"> <label for="" class="form-label">On Demand</label>
                `);
                if(onDemand == "true"){
                  $(document).find("[name=isOnDemand2]").prop("checked", true);
                }
              } else {
                $(".onDemandCheckbox").html(``);
                // $(document).find("[name=isOnDemand]").prop("checked", false);
              }
            }
        },
        error: function (res) {
            swal.fire({
                icon: 'error',
                title: 'Error',
                text: "Something Went Wrong",
            })
        },
        complete: function() {
          $('#loader').hide();
        }
      });
    } else {
      $(".onDemandCheckbox").html(``);
    }
  }
});

$(document).on("keyup", "[name=amount]", function(){
  if($(this).val() < 0){
    $(this).val(0);
  }
});
$(document).on("keyup", "[name=phoneSearch]", function(){
  if($(this).val() < 0){
    $(this).val(0);
  }
});

$(document).on("change", "[name=startTime]", function(){
  let thisElem = $(this); 
  let startTimeValue = $(this).closest(".day_sec").find("[name=startTime]").val();
  let routeTime = $(this).closest("#form").find("[name=routeId] option:selected").attr("data-time");

  $.ajax({
    type: 'POST',
    headers: requestHeader,
    url: "/getAutoCalculatedEndTime",
    data: {
        startTimeValue: startTimeValue,
        routeTime: routeTime,
    },
    dataType: "JSON",
    beforeSend: function() {
      $('#loader').show();
    }, 
    success: function (response) {
        if (response.status == false) {
            swal.fire({
                icon: 'error',
                title: 'Error',
                text: response.message,
            })
            thisElem.closest(".appendedStopRow").find("[name=stopId]").val('')
        } else {
          // ======================= set value of endTime =======================
          thisElem.closest(".day_sec").find("[name=endTime]").val(response.data);
          // ======================= set value of endTime =======================
        }
    },
    error: function (res) {
        swal.fire({
            icon: 'error',
            title: 'Error',
            text: (res.responseJSON)?res.responseJSON.message:"Something Went Wrong",
        })
    },
    complete: function() {
      $('#loader').hide();
    }
  });
});

$(document).on("click", ".dayName", function(){
  $("[name=dayName]:checked").each(function(){
    $(this).closest(".row").find($("[name=startTime]")).attr("data-valid", "required")
    $(this).closest(".row").find($("[name=endTime]")).attr("data-valid", "required")
    
    $(this).closest(".row").find($("[name=dayName]:checked")).classList().add("form-submit-data")
    $(this).closest(".row").find($("[name=startTime]")).classList().add("form-submit-data")
    $(this).closest(".row").find($("[name=endTime]")).classList().add("form-submit-data")
  });
});

$(document).on("click", ".generateUniquePhone", async function() {
  const checkPhoneNumberExists = (phoneNumber) => {
    return new Promise((resolve, reject) => {
      $.ajax({
        type: 'POST',
        headers: requestHeader,
        url: apiUrl + "phone-exist-check",
        data: {
          phoneNumber: phoneNumber,
        },
        dataType: "JSON",
        beforeSend: function() {
          $('#loader').show();
        }, 
        success: function(response) {
          resolve(response.status);
        },
        error: function(res) {
          reject(res.responseJSON ? res.responseJSON.message : "Something Went Wrong");
        },
        complete: function() {
          $('#loader').hide();
        }
      });
    });
  };

  let terminationFlag = false;

  while (!terminationFlag) {
    // Generate a random 8-digit number
    const randomPart = Math.floor(Math.random() * 100000000).toString().padStart(8, '0');
    const phoneNumber = `11${randomPart}`; // Note: No need to parseInt here

    const status = await checkPhoneNumberExists(phoneNumber);
    if (!status) {
      // phone number is not unique, continue loop
      console.log("Duplicate number, generating a new one.");
    } else {
      // phone number is unique
      $(this).closest(".phoneInput").find("[name=phone]").val(phoneNumber);
      terminationFlag = true;
      console.log("Unique phone number found.");
    }
  }
});

$(document).on("click", ".generateUniqueEmail", async function(){
  const checkEmailExists = (email) => {
    return new Promise((resolve, reject) => {
      $.ajax({
        type: 'POST',
        headers: requestHeader,
        url: apiUrl + "email-exist-check",
        data: {
          email: email,
        },
        dataType: "JSON",
        beforeSend: function() {
          $('#loader').show();
        }, 
        success: function(response) {
          resolve(response.status);
        },
        error: function(res) {
          reject(res.responseJSON ? res.responseJSON.message : "Something Went Wrong");
        },
        complete: function() {
          $('#loader').hide();
        }
      });
    });
  };

  let terminationFlag = false;

  while (!terminationFlag) {
    // Generate a random 8-digit number
    const randomPart = Math.floor(Math.random() * 100000000).toString().padStart(8, '0');
    const email = `11${randomPart}@gmail.com`; // Note: No need to parseInt here

    const status = await checkEmailExists(email);
    if (!status) {
      // email is not unique, continue loop
      console.log("Duplicate email, generating a new one.");
    } else {
      // email is unique
      $(this).closest(".emailInput").find("[name=email]").val(email);
      terminationFlag = true;
      console.log("Unique email found.");
    }
  }
});

let k = 1;
let stopsArr = []
$(document).on("click", ".addRouteStop", function () {
	if($("[name=routeType]").length){
    $.ajax({
      type: "GET",
      headers: requestHeader,
      url: apiUrl + "tripStop-list",
      dataType: "JSON",
      beforeSend: function() {
        $('#loader').show();
      }, 
      success: function (response) {
        if (response.status == false) {
          swal.fire({
            icon: "error",
            title: "Error",
            text: response.message,
          });
        } else {
          stopsArr = response.data.data;
        }
      },
      error: function (res) {
        swal.fire({
          icon: "error",
          title: "Error",
          text: "Something Went Wrong",
        });
      },
      complete: function() {
        $('#loader').hide();
      }
    });
		// if(stopsArr.length == 0){
		// }
	}
	if(stopsArr.length > 0){
		let html = ``;
		stopsArr.forEach((stop) => {
			html += `<option value="${stop._id.toString()}" data-coordinate="${stop.location.coordinates}" >${stop.stopName} (${stop.stopType}) ${stop.isDanger == "Yes" ? "(Danger)" : ""}</option>`;
		})
		$(this).closest("div").append(`
      <div class="row col-md-12 col-12 ml-3 appendedStopRow">
        <div class="col-lg-6 col-12 mb-3">
          <div class="dashmhri_select">
            <label for="">Stop</label>
            <button type="button" class="btn btn-sm btn-danger pull-right mb-1 deleteAppendedStopRow">-</button>
            <select class="form-select form-submit-data user mt-2 mb-3 select2" name="stopId" data-order="${k}" aria-label="Default select example" data-valid="required">
              <option value="">Select Stop</option>
              ${html}
            </select>
          </div>
        </div>
        <div class="col-lg-2 col-12 mb-3" hidden>
          <label for="" class="form-label">Order</label>
          <input type="text" name="order" placeholder="Enter Stop Order" class="form-control form-submit-data user" data-valid="required" value="${k}" readonly>
        </div>
        <div class="col-lg-6 col-12 mb-3">
          <label for="" class="form-label">Distance (Km.)</label>
          <input type="number" name="distance" min="0" placeholder="Enter Distance" class="form-control form-submit-data user stopDistances" data-valid="required">
        </div>
      </div>
		`);
		// increment =====
		k++;
		// increment =====
    if($(".select2").length){
      $(".select2").each(function(){
        $(this).select2();
      });
    }
	}
});

$(document).on("click", ".deleteAppendedStopRow", function() {
  $(this).closest(".appendedStopRow")
    .fadeOut(300)
    .queue(function(next) {
      $(this).remove(); // Remove after fading out
      k--; // Decrement the counter
      next(); // Move to the next item in the queue
    });
});

$(document).on("click", ".add", function () {
  i = 1;
  j = 1;
  k = 1;
  $("#form").trigger('reset');
  
  $(".invalid-feedback").remove();

  if($("#branches").length > 0){
    $("#branches").find(".appendedBranch").remove()
  }
  if($(".appendedHoliday").length > 0){
    $(".appendedHoliday").remove()
  }
  if($("#stopDetails").length > 0){
    $("#stopDetails").html('');
  }
  if($("[name=vehicleId")){
    $("[name=vehicleId").val('');
  }
  if($("[name=driverId")){
    $("[name=driverId").val('');
  }

  if($(".role_permission_sec").length){
    $(".role_permission_sec").find("input[type=checkbox]").each(function(){
          
      // $(this).attr("readonly", true);
      $(this).prop("disabled", false);
    });
  }

  $("#form").find("input .form-submit-data").val("");
  if ($("#address").length) {
    $("#address").focus(function () {
      selected = false;
      autocomplete = new google.maps.places.SearchBox(
        document.getElementById("address")
      );

      postcode = "";
      autocomplete.addListener("places_changed", function () {
        selected = true;
        let place = autocomplete.getPlaces();
        const addressName = place[0].name;
        latitude = place[0].geometry.location.lat();
        longitude = place[0].geometry.location.lng();
        for (const component of place[0].address_components) {
          // @ts-ignore remove once typings fixed
          const componentType = component.types[0];
          switch (componentType) {
            case "subpremise": {
              address1 = `${component.long_name} ${address1}`;
              break;
            }
            case "premise": {
              address1 += component.short_name;
              break;
            }
            case "postal_code": {
              postcode = `${component.long_name}${postcode}`;
              break;
            }
            // case "postal_code_suffix": {
            //     postcode = `${postcode}-${component.long_name}`;
            //     break;
            // }
            case "locality": {
              locality = component.long_name;
              break;
            }
            case "administrative_area_level_1": {
              state = component.long_name;
              break;
            }
            case "country":
              country = component.long_name;
              break;
            case "sublocality_level_3":
              landmark = component.long_name;
              break;
          }
        }

        $("[name=city]").val(locality);
        $("[name=state]").val(state);
        $("[name=zipcode]").val(postcode);
        $("[name=country]").val(country);
        $("[name=latitude]").val(latitude);
        $("[name=longitude]").val(longitude);
      });
    });
  }
  if ($("#dangerAddress").length) {
    $("#dangerAddress").focus(function () {
      selected = false;
      autocomplete = new google.maps.places.SearchBox(
        document.getElementById("dangerAddress")
      );

      postcode = "";
      autocomplete.addListener("places_changed", function () {
        selected = true;
        let place = autocomplete.getPlaces();
        const addressName = place[0].name;
        latitude = place[0].geometry.location.lat();
        longitude = place[0].geometry.location.lng();
        for (const component of place[0].address_components) {
          // @ts-ignore remove once typings fixed
          const componentType = component.types[0];
          switch (componentType) {
            case "subpremise": {
              address1 = `${component.long_name} ${address1}`;
              break;
            }
            case "premise": {
              address1 += component.short_name;
              break;
            }
            case "postal_code": {
              postcode = `${component.long_name}${postcode}`;
              break;
            }
            // case "postal_code_suffix": {
            //     postcode = `${postcode}-${component.long_name}`;
            //     break;
            // }
            case "locality": {
              locality = component.long_name;
              break;
            }
            case "administrative_area_level_1": {
              state = component.long_name;
              break;
            }
            case "country":
              country = component.long_name;
              break;
            case "sublocality_level_3":
              landmark = component.long_name;
              break;
          }
        }
        //   console.log(
        //     `address : ${address1}
        //             postcode : ${postcode}
        //             locality : ${locality}
        //             state : ${state}
        //             country : ${country}
        //             landmark : ${landmark}
        //             lat : ${lat}
        //             lng : ${lng}`
        //   );

        //   $("[name=city]").val(locality);
        //   $("[name=state]").val(state);
        //   $("[name=zipcode]").val(postcode);
        //   $("[name=country]").val(country);
        $("[name=dangerLatitude]").val(latitude);
        $("[name=dangerLongitude]").val(longitude);

        $("#dangerLatitude").trigger("change");
        $("#dangerLongitude").trigger("change");
      });
    });
  }

  if($(".clientphoto").length){
    $("#form").find(".clientphoto").find("a").remove();
  }

  if($(".appendedStopRow").length){
    $(".appendedStopRow").remove();
  }
  
  $("#form").closest(".modal").modal("show");

  if($(".select2").length){
    $(".select2").each(function(){
      $(this).select2();
    });
  }

});
$(document).on("click", ".edit", function () {
  // ===== form resetting =====
  $("#form").trigger('reset');
  $(".invalid-feedback").remove();

  if($(".appendedStopRow").length){
    $(".appendedStopRow").remove();
  }
  if($(".appendedBranch").length){
    $(".appendedBranch").remove();
  }
  if($(".appendedHoliday").length){
    $(".appendedHoliday").remove();
  }
  // if($("#branches").length > 0){
  //   $("#branches").find(".appendedBranch").remove()
  // }
  // $("#form").find("input .form-submit-data").val("");

  // if($(".clientphoto").length){
  //   $("#form").find(".clientphoto").find("a").remove();
  // }
  // ===== form resetting =====

  const url = "get-" + $(this).closest("tbody").attr("data-name");
  const data = {
    id: $(this).closest("tr").attr("data-id"),
  };
  if($("[name=parentCorporateId]").length){
    $("[name=parentCorporateId] option[value="+$(this).closest("tr").attr("data-id")+"]").remove()
  }

  const form = "form";
  $.ajax({
    type: "POST",
    headers: requestHeader,
    url: apiUrl + url,
    data: data,
    dataType: "JSON",
    beforeSend: function() {
      $('#loader').show();
    }, 
    success: function (response) {
      if (response.status == false) {
        // response.status == false this should be response.type == false; there is nothing like status in the response ========
        swal.fire({
          icon: "error",
          title: "Error",
          text: response.message,
        });
      } else {
        const data = response.data;
        $(
          "#" +
            form +
            " input:not(':input[type=radio], :input[type=checkbox], :input[type=button], :input[type=submit], :input[type=file]')"
        ).each(function () {
          if(
            ($(this).attr("name") != 'roleOfCorporateType')
            && ($(this).attr("name") != 'userType')
          ){
            var label = $(this).attr("name");
            $(this).val(data.data[label]);
          }
        });
        $("#" + form + " input[type=radio]").prop("checked", false);
        $("#" + form + " input[type=radio]").each(function () {
          var label = $(this).attr("name");
          $("#" + form)
            .find("[name=" + label + "][value=" + data.data[label] + "]")
            .prop("checked", true);
            $("#" + form)
            .find("[name=" + label + "][value=" + data.data[label] + "]").trigger("click")
        });
        $("#" + form + " input[type=checkbox]").prop("checked", false);
        $("#" + form + " input[type=checkbox]").each(function () {
          var label = $(this).attr("name");
          if(data.data[label] == true){
            $("#" + form).find("[name=" + label + "]").trigger("click")
          } 
        });
        if($(".role_permission_sec").length){
          $(".role_permission_sec").find("input[type=checkbox]").prop("disabled", false)
          
          if(data.data["moduleId"].length > 0){
            data?.data["moduleId"].forEach((item)=>{
              $(".role_permission_sec [name=moduleId][value="+item.toString()+"]").prop('checked', true)
              
            });
          }
        }
        $("#" + form + " input[type=file]").each(function () {
          var label = $(this).attr("name");
          var fileExtension = ["jpeg", "jpg", "png"];
          var fileExtensionimage = ["jpeg", "jpg", "png"];
          
          if (data.data[label] && ($.inArray(data.data[label].split(/[#?]/)[0].split('.').pop().trim().toLowerCase(), fileExtension) != false)) {
            if (
              $.inArray(
                data.data[label].split(/[#?]/)[0].split('.').pop().trim().toLowerCase(),
                fileExtensionimage
              ) !== -1
            ) {
              $("[name=" + label + "]").closest(".form-group").find(".clientphoto").html(`<a href="${data.data[label]}" target="_blank"></a>`)
              $($.parseHTML("<img class='pre-img' crossorigin='anonymous'>"))
                .attr("src", data.data[label])
                .appendTo(
                  $("[name=" + label + "]")
                    .closest(".form-group")
                    .find(".clientphoto a")
                );
            } else {
              $("[name=" + label + "]").closest(".form-group").find(".clientphoto").html(`<a href="${data.data[label]}" target="_blank"></a>`)
              $($.parseHTML("<img class='pre-img'>"))
              .attr("src", "../../assets/images/google-docs.png")
              .appendTo(
                $("[name=" + label + "]")
                  .closest(".form-group")
                  .find(".clientphoto a")
              );

            }
          }
        });

        $("#" + form + " textarea").each(function () {
          var label = $(this).attr("name");
          if ($("#" + label).length && label == "description") {
            CKEDITOR.replace("description", {
              allowedContent: true,
            });
            CKEDITOR.instances["description"].setData(data.data.description);
          }
          $(this).val(data.data[label]);
        });
        $("#" + form + " select:not([multiple])").each(function () {
          var label = $(this).attr("name");
          $(this)
            .find("option[value='" + data.data[label] + "']")
            .prop("selected", true);

          $(this).select2();
          $(this).trigger("change");
        });
        $("#" + form + " select[multiple]").each(function () {
          var label = $(this).attr("name");
          data.data[label].forEach((item)=>{
              $(this)
              .find("option[value='" + item + "']")
              .prop("selected", true);
          });
          $(this).select2();
          $(this).trigger("change");
        });

        // ==== can not change role ====
        $("#" + form + " select[name=roleId]").next(".select2-container").css("pointer-events", "none");
        // ==== can not change role ====

        $("#" + form)
          .find("[name=password]")
          .closest("div")
          .remove();
        // if ($("[name=phone]").length) {
        //     var inputr = document.querySelector("[name=phone]");
        //     var itir = window.intlTelInput(inputr, {
        //       allowDropdown: true,
        //       autoHideDialCode: false,
        //       autoPlaceholder: "off",
        //       dropdownContainer: document.body,
        //       // excludeCountries: ["us"],
        //       formatOnDisplay: false,
        //       initialCountry: countryCodeCheck($("[name=phone]").val()),
        //       // hiddenInput: "full_number",
        //       placeholderNumberType: "MOBILE",
        //       onlyCountries: ["US", "GB", "CH", "IN", "NP", "BD", "AU", "AT", "AZ"],
        //       preferredCountries: ["AU"],
        //       separateDialCode: true,
        //       utilsScript: "/assets/intel-tel-info/build/js/utils.js",
        //     });

        //     $(document).on("blur", "[name=phone]", function () {
        //         console.log(itir.getSelectedCountryData().dialCode, $(this).closest(".phoneInput")
        //         .find("[name=dialcode]").val())
        //         $(this).closest(".phoneInput")
        //         .find("[name=dialcode]")
        //         .val("+" + itir.getSelectedCountryData().dialCode);

        //     });
        //   }
        if ($("#address").length) {
          $("#address").focus(function () {
            selected = false;
            autocomplete = new google.maps.places.SearchBox(
              document.getElementById("address")
            );

            postcode = "";
            autocomplete.addListener("places_changed", function () {
              selected = true;
              let place = autocomplete.getPlaces();
              const addressName = place[0].name;
              latitude = place[0].geometry.location.lat();
              longitude = place[0].geometry.location.lng();
              for (const component of place[0].address_components) {
                // @ts-ignore remove once typings fixed
                const componentType = component.types[0];
                switch (componentType) {
                  case "subpremise": {
                    address1 = `${component.long_name} ${address1}`;
                    break;
                  }
                  case "premise": {
                    address1 += component.short_name;
                    break;
                  }
                  case "postal_code": {
                    postcode = `${component.long_name}${postcode}`;
                    break;
                  }
                  // case "postal_code_suffix": {
                  //     postcode = `${postcode}-${component.long_name}`;
                  //     break;
                  // }
                  case "locality": {
                    locality = component.long_name;
                    break;
                  }
                  case "administrative_area_level_1": {
                    state = component.long_name;
                    break;
                  }
                  case "country":
                    country = component.long_name;
                    break;
                  case "sublocality_level_3":
                    landmark = component.long_name;
                    break;
                }
              }
            //   console.log(
            //     `address : ${address1}
            //         postcode : ${postcode}
            //         locality : ${locality}
            //         state : ${state}
            //         country : ${country}
            //         landmark : ${landmark}
            //         lat : ${lat}
            //         lng : ${lng}`
            //   );

              $("[name=city]").val(locality);
              $("[name=state]").val(state);
              $("[name=zipcode]").val(postcode);
              $("[name=country]").val(country);
              $("[name=latitude]").val(latitude);
              $("[name=longitude]").val(longitude);
            });
          });
        }
        if ($("#dangerAddress").length) {
          $("#dangerAddress").focus(function () {
            selected = false;
            autocomplete = new google.maps.places.SearchBox(
              document.getElementById("dangerAddress")
            );

            postcode = "";
            autocomplete.addListener("places_changed", function () {
              selected = true;
              let place = autocomplete.getPlaces();
              const addressName = place[0].name;
              latitude = place[0].geometry.location.lat();
              longitude = place[0].geometry.location.lng();
              for (const component of place[0].address_components) {
                // @ts-ignore remove once typings fixed
                const componentType = component.types[0];
                switch (componentType) {
                  case "subpremise": {
                    address1 = `${component.long_name} ${address1}`;
                    break;
                  }
                  case "premise": {
                    address1 += component.short_name;
                    break;
                  }
                  case "postal_code": {
                    postcode = `${component.long_name}${postcode}`;
                    break;
                  }
                  // case "postal_code_suffix": {
                  //     postcode = `${postcode}-${component.long_name}`;
                  //     break;
                  // }
                  case "locality": {
                    locality = component.long_name;
                    break;
                  }
                  case "administrative_area_level_1": {
                    state = component.long_name;
                    break;
                  }
                  case "country":
                    country = component.long_name;
                    break;
                  case "sublocality_level_3":
                    landmark = component.long_name;
                    break;
                }
              }
              //   console.log(
              //     `address : ${address1}
              //             postcode : ${postcode}
              //             locality : ${locality}
              //             state : ${state}
              //             country : ${country}
              //             landmark : ${landmark}
              //             lat : ${lat}
              //             lng : ${lng}`
              //   );

              //   $("[name=city]").val(locality);
              //   $("[name=state]").val(state);
              //   $("[name=zipcode]").val(postcode);
              //   $("[name=country]").val(country);
              $("[name=dangerLatitude]").val(latitude);
              $("[name=dangerLongitude]").val(longitude);

              // $("#dangerAddress").focus();
              // $("#dangerLatitude").trigger("change");
            });
          });
        }
        if($("#branches").length){
            response.data.data.organizations.forEach((org, index)=>{
              $("#branches").append(`
              <div class="col-lg-12 col-12 appendedBranch">
                  <button type="button" class="btn btn-sm btn-danger pull-right mb-1 deleteAppendedBranch">-</button>
                  <input type="text" name="orgBranch" class="form-control mt-2" placeholder="Enter Branch Name" value="${org.orgBranch}" data-valid="required">
          
                  <input type="text" class="form-control form-submit-data address mt-2" id="address${index + 1}" placeholder="Enter Address for Branch" name="orgAddress" value="${org.orgAddress}" data-valid="required">
          
                  <input type="hidden" name="orgLatitude" data-valid="required" value="${org.orgLatitude}">
                  <input type="hidden" name="orgLongitude" data-valid="required" value="${org.orgLongitude}">
          
                  <hr>
              </div>
              `);
              i = index + 2;
            });
        }
        if($("#holidays").length){
            response.data.data.holidaysArr.forEach((holiday, index)=>{
              $("#holidays").find(".row").append(`
              <div class="col-lg-6 appendedHoliday">
                <button type="button" class="btn btn-sm btn-danger pull-right mb-1 deleteAppendedHoliday">-</button>
                <input type="date" name="holidays" class="form-control mb-2" value="${holiday}">
              </div>`);
              
              j = index + 2;
            });
        }
				let routeStops = response.data.data.routeStops
				let stopsArr = []
        if($("#stops").length){
					if($("[name=routeType]").length){
						if(stopsArr.length == 0){
							$.ajax({
								type: "GET",
								headers: requestHeader,
								url: apiUrl + "tripStop-list",
								dataType: "JSON",
                beforeSend: function() {
                  $('#loader').show();
                }, 
								success: function (response) {
									if (response.status == false) {
										swal.fire({
											icon: "error",
											title: "Error",
											text: response.message,
										});
									} else {
										stopsArr = response.data.data;

										if(stopsArr.length > 0){
											routeStops.forEach((item, index)=>{
												let html = ``;
												stopsArr.forEach((stop) => {
													html += `
														<option value="${stop._id.toString()}" data-coordinate="${stop.location.coordinates}" ${(stop._id.toString() == item.stopId.toString())? "selected":""}>${stop.stopName} (${
															stop.stopType
														}) ${stop.isDanger == "Yes" ? "(Danger)" : ""}</option>
													`;
													
												})
												$("#stops").append(`
                          <div class="row col-md-12 col-12 ml-3 appendedStopRow">
                            <div class="col-lg-6 col-12 mb-3">
                                <div class="dashmhri_select">
                                    <label for="">Stop</label>
                                    <button type="button" class="btn btn-sm btn-danger pull-right mb-1 deleteAppendedStopRow">-</button>
                                    <select class="form-select form-submit-data user mt-2 mb-3 select2" name="stopId" data-order="${index}" aria-label="Default select example" data-valid="required">
                                        <option value="">Select Stop</option>
                                        ${html}
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-2 col-12 mb-3" hidden>
                                <label for="" class="form-label">Order</label>
                                <input type="text" name="order" placeholder="Enter Route Order" class="form-control form-submit-data user" data-valid="required" value="${index + 1}" readonly>
                            </div>
                            <div class="col-lg-6 col-12 mb-3">
                              <label for="" class="form-label">Distance</label>
                              <input type="text" name="distance" min="0" placeholder="Enter Distance" class="form-control form-submit-data user" value="${item.distance}" data-valid="required" >
                            </div>
                          </div>
												`)
											});
										}
									}
								},
								error: function (res) {
									swal.fire({
										icon: "error",
										title: "Error",
										text: "Something Went Wrong",
									});
								},
                complete: function() {
                  $('#loader').hide();
                }
							});
						}
					}
					
        }
        
        if($(".schedule").length){
          if(data.data.schedule.length > 1){
            // means customized ===================
            data.data.schedule.forEach(val => {
              $("[name=dayName][value="+val.dayName+"]").prop("checked", true)
              $("[name=dayName][value="+val.dayName+"]").closest(".day_sec").find("[name=startTime]").val(val.startTime)
              $("[name=dayName][value="+val.dayName+"]").closest(".day_sec").find("[name=endTime]").val(val.endTime)
            })
          } else {
            // means daily ===================
            $(".day_sec").find("[name=startTime]").val(data.data.schedule[0].startTime)
            $(".day_sec").find("[name=endTime]").val(data.data.schedule[0].endTime)
          }
        }

        $("#" + form)
          .closest(".modal")
          .modal("show");

        // if($(".select2").length){
        //   $(".select2").each(function(){
        //     $(this).select2({
        //       dropdownParent: $("#" + form)
        //     });
        //   });
        // }

        var polygonCoordinates = "";
        if($("#dangerLatitude").length){
          $("#dangerLatitude").trigger("change");
  
          polygonCoordinates = data.data["dangerZone"].dangerLocation.coordinates;
          // console.log("polygonCoordinates ========>");
          // console.log(polygonCoordinates);

          // Draw polygon on the map ========
          var polygon = L.polygon(polygonCoordinates).addTo(map);
        }
        

      }
    },
    error: function (res) {
      swal.fire({
        icon: "error",
        title: "Error",
        text: "Something Went Wrong",
      });
    },
    complete: function() {
      $('#loader').hide();
    }
  });
});
$(document).on("click", ".replyToSupportRequest", function () {
  let userId = $(this).closest("tr").attr("data-id");

  $("#exampleModal").find("[name='_id']").val(userId);;

  $("#exampleModal").modal("show");
});
$(document).on("click", ".refundMoneyBtn", function () {
  if(
    ($(this).attr("data-gateway").toLowerCase() != "stripe") 
    && ($(this).attr("data-gateway").toLowerCase() != "razorpay") 
  ){
    // refund-money-via-wallet
    swal.fire({
      icon: 'error',
      title: 'Error',
      text: "Sorry..!! Refund is not allowed for this payment method.",
    })
  }
  const refundUrl = "refund-money-via-" + $(this).attr("data-gateway").toLowerCase();
  // refund-money-via-stripe
  // refund-money-via-razorpay
  
  const data = {
    _id: $(this).closest("tr").attr("data-id"),
  };

  $.ajax({
    type: 'POST',
    headers: requestHeader,
    url: apiUrl + refundUrl,
    data: data,
    dataType: "JSON",
    beforeSend: function() {
      $('#loader').show();
    },
    success: function(response) {
      if (response.status == false) {
        swal.fire({
          icon: 'error',
          title: 'Error',
          text: response.message,
        })
      } else {
        location.reload()
      }
    },
    error: function(res) {
      // reject(res.responseJSON ? res.responseJSON.message : "Something Went Wrong");
      // console.log("==========>", res.responseJSON ? res.responseJSON.message : "Something Went Wrong");
      swal.fire({
        icon: 'error',
        title: 'Error',
        text: res.message,
      })
    },
    complete: function() {
      $('#loader').hide();
    }
  });
});

// let editor;
// // Initialize CKEditor when the modal is opened
// $('#replyModal').on('shown.bs.modal', function () {
//   ClassicEditor
//     .create(document.querySelector('#editor'))
//     .then(newEditor => {
//       editor = newEditor;
//     })
//     .catch(error => {
//       console.error(error);
//     });
// });

// // Optional: Destroy CKEditor instance when the modal is hidden to clean up resources
// $('#replyModal').on('hidden.bs.modal', function () {
//   if (editor) {
//     editor.destroy()
//       .then(() => {
//         editor = null;
//       })
//       .catch(error => {
//         console.error(error);
//       });
//   }
// });

$(document).on("click", ".delete", function () {
  const url = "delete-" + $(this).closest("tbody").attr("data-name");
  const data = {
    id: $(this).closest("tr").attr("data-id"),
  };
  let trelement = $(this).closest("tr")
  const form = "form";
  Swal.fire({
    title: "Are you sure?",
    text: "Do you want to delete this?",
    type: "warning",
    showCancelButton: true,
    confirmButtonColor: "#DD6B55",
    confirmButtonText: "Yes",
    closeOnConfirm: false
  }).then(function (isConfirm) {
    if (!isConfirm.isConfirmed) return;
    $.ajax({
      type: "POST",
      headers: requestHeader,
      url: apiUrl + url,
      data: data,
      dataType: "JSON",
      beforeSend: function() {
        $('#loader').show();
      }, 
      success: function (response) {
        if (response.status == false) {
          swal.fire({
            icon: "error",
            title: "Error",
            text: response.message,
          });
        } else {
          if(response.data.specific){
            let tableelement = trelement.closest("table")
            trelement.remove()
            if(tableelement.find("tbody").find("tr").length == 0){
              let colspan = tableelement.find("thead tr").find("th").length
              tableelement.find("tbody").html(`<tr><td colspan="${colspan}">No Data Found</td></tr>`)
            }
            calendarFormat()
          }else{
            location.reload();
          }
        }
      },
      error: function (response) {
        swal.fire({
          icon: "error",
          title: (response?.responseJSON?.statusText)? (response?.responseJSON?.statusText) : "Error",
          text: (response?.responseJSON?.message)? (response?.responseJSON?.message) : "Something went wrong ====>.",
        });
      },
      complete: function() {
        $('#loader').hide();
      }
    });
  })
});

$(document).on("change", '[type="file"]', function () {
  var fileExtension = ["jpeg", "jpg", "png"];
  if (
    $.inArray($(this).val().split(".").pop().toLowerCase(), fileExtension) == -1
  ) {
    var msg = "Only " + fileExtension.join(", ") + " formats are allowed";
    $(this).val("");

    swal.fire({
      icon: "error",
      title: ucWords("Oops..."),
      text: ucWords(msg),
      timer: 1000,
    });
  } else {
    var file = this.files[0],
      img;
    if (Math.round(file.size / (1024 * 1024)) > 3) {
      $(this).val("");

      swal.fire({
        icon: "error",
        title: ucWords("Oops..."),
        text: ucWords("Maximum size should be 3MB"),
        timer: 1000,
      });
    } else {
      if ($(this).closest(".form-group").find(".clientphoto").length) {
        $(this).closest(".form-group").find(".clientphoto").html("");
        var fileExtensionimage = ["jpeg", "jpg", "png"];
        if (
          $.inArray(
            $(this).val().split(".").pop().toLowerCase(),
            fileExtensionimage
          ) !== -1
        ) {
          imagesPreview(this, $(this).attr("name"));
        } else {
          documentsPreview(this, $(this).attr("name"));
        }
      }
    }
  }
});

$(document).on("click", ".edit_booking", function () {
  const url = "get-" + $(this).closest("tbody").attr("data-name");
  let id = $(this).closest("table").attr("data-id")
  const data = {
    id: $(this).closest("tr").attr("data-id"),
  };
  let form = "form2"
  $.ajax({
    type: 'POST',
    headers: requestHeader,
    url: apiUrl + "trip-requirements",
    data: {
        'id' : $(this).closest("table").attr("data-id")
    },
    dataType: "JSON",
    beforeSend: function() {
      $('#loader').show();
    }, 
    success: function (response) {
        if (response.type != 'success') {
            swal.fire({
                icon: 'error',
                title: 'Error',
                text: response.message,
            })
        } else {
            let userContent = ''
            // console.log("response.data.data ============>");
            // console.log(response.data.data);
            if(response.data.data.tripFor == "School"){
              response.data.data.eligibleStudentsOfTrip.forEach(elem => {
                userContent += `<option value="${elem._id}">${elem.firstName+" "+elem.lastName}</option>`;
              });
            } else {
              response.data.data.employees.forEach(elem => {
                userContent += `<option value="${elem.userId._id}">${elem.userId.firstName+" "+elem.userId.lastName}</option>`;
              });
            }
            let pickupRouteContent = ''
            let dropRouteContent = ''
            response.data.data.stops.forEach((elem, index) => {
              if(elem.order == 1){
                pickupRouteContent += `<option value="${elem.stop._id}" data-order="${elem.order}" selected>${elem.stop.stopName}</option>`
              } else if(elem.order == response.data.data.stops.length){
                dropRouteContent += `<option value="${elem.stop._id}" data-order="${elem.order}" selected>${elem.stop.stopName}</option>`
              } else{
                pickupRouteContent += `<option value="${elem.stop._id}" data-order="${elem.order}">${elem.stop.stopName}</option>`
                dropRouteContent += `<option value="${elem.stop._id}" data-order="${elem.order}">${elem.stop.stopName}</option>`
              }
            });

            $("#passengerModal").find("[name=tripId]").val(id);
            $("#passengerModal .tripName").text(response.data.data.trip.tripPlanId.tripName);
            $("#passengerModal .tripDate").text(dateFormat(response.data.data.trip.tripDate));
            $("#passengerModal [name=userId]").html(userContent);
            if(response.data.data.tripFor == "School"){
              // append serviceId of user being added =======
              // console.log(response.data.data.eligibleStudentsOfTrip[0].roleId);
              $("#passengerModal [name=serviceId]").val(response.data.data.eligibleStudentsOfTrip[0].roleId);
            } else{
              // append serviceId of user being added =======
              // console.log(response.data.data.employees[0].userId.roleId);
              $("#passengerModal [name=serviceId]").val(response.data.data.employees[0].userId.roleId);
            }
            $("#passengerModal [name=pickupStopId]").html(pickupRouteContent);
            $("#passengerModal [name=dropStopId]").html(dropRouteContent);
            $.ajax({
              type: "POST",
              headers: requestHeader,
              url: apiUrl + url,
              data: data,
              dataType: "JSON",
              beforeSend: function() {
                $('#loader').show();
              }, 
              success: function (response) {
                if (response.status == false) {
                  // response.status == false this should be response.type == false; there is nothing like status in the response ========
                  swal.fire({
                    icon: "error",
                    title: "Error",
                    text: response.message,
                  });
                } else {
                  const data = response.data;
                  $(
                    "#" +
                      form +
                      " input:not(':input[type=radio], :input[type=button], :input[type=submit], :input[type=file]')"
                  ).each(function () {
                    var label = $(this).attr("name");
                    $(this).val(data.data[label]);
                  });
                  $("#" + form + " select:not([multiple])").each(function () {
                    var label = $(this).attr("name");
                    console.log(label, data.data[label])
                    $(this)
                      .find("option").prop("selected", false)
                    $(this)
                      .find("option").removeAttr("selected")
                    $(this)
                      .find("option[value='" + data.data[label] + "']")
                      .prop("selected", true);
                  })
                  
                  $("#" + form)
                    .closest(".modal")
                    .modal("show");
                    $("#bookingModal").modal("hide")
                }
              },
              error: function (res) {
                swal.fire({
                  icon: "error",
                  title: "Error",
                  text: "Something Went Wrong",
                });
              },
              complete: function() {
                $('#loader').hide();
              }
            });
        }
    },
    error: function (res) {
        swal.fire({
            icon: 'error',
            title: 'Error',
            text: "Something Went Wrong",
        })
    },
    complete: function() {
      $('#loader').hide();
    }
  })
});



let imagesPreview = function (input, placeToInsertImagePreview) {
  if (input.files) {
    let filesAmount = input.files.length;
    for (i = 0; i < filesAmount; i++) {
      let reader = new FileReader();
      reader.onload = function (event) {
        $($.parseHTML("<img class='pre-img'>"))
          .attr("src", event.target.result)
          .appendTo(
            $("[name=" + placeToInsertImagePreview + "]")
              .closest(".form-group")
              .find(".clientphoto")
          );
      };
      reader.readAsDataURL(input.files[i]);
    }
  }
};
let documentsPreview = function (input, placeToInsertImagePreview) {
  if (input.files) {
    let filesAmount = input.files.length;
    for (i = 0; i < filesAmount; i++) {
      let reader = new FileReader();
      reader.onload = function (event) {
        $($.parseHTML("<img class='pre-img'>"))
          .attr("src", "../../assets/images/google-docs.png")
          .appendTo(
            $("[name=" + placeToInsertImagePreview + "]")
              .closest(".form-group")
              .find(".clientphoto")
          );
      };
      reader.readAsDataURL(input.files[i]);
    }
  }
};

const ucWords = (str) => {
  return (str + "").replace(
    /^[\u00C0-\u1FFF\u2C00-\uD7FF\w]|\s[\u00C0-\u1FFF\u2C00-\uD7FF\w]/g,
    function (letter) {
      return letter.toUpperCase();
    }
  );
};
const countryCodeCheck = (code) => {
  countryy = "IN";
  if (code == "+880") {
    countryy = "BD";
  } else if (code == "+1") {
    countryy = "US";
  } else if (code == "+977") {
    countryy = "NP";
  } else if (code == "+41") {
    countryy = "CH";
  } else if (code == "+44") {
    countryy = "GB";
  } else if (code == "+61") {
    countryy = "AU";
  } else if (code == "+91") {
    countryy = "IN";
  } else if (code == "+43") {
    countryy = "AT";
  } else if (code == "+994") {
    countryy = "AZ";
  }
  return countryy;
};

