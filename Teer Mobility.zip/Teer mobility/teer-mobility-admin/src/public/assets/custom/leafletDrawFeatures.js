let map = '';
let osm = '';
let drawnFeatures = '';
// let zoomlevel = 13;

let dangerCoOrdinates = [];

let dangerLatitude = '22.5744';
let dangerLongitude = '88.3629';

var initLeafletMap = function initLeafletMap(dangerLatitude, dangerLongitude, zoomlevel){
    map = L.map('map').setView([dangerLatitude, dangerLongitude],20);
    map.panTo(new L.LatLng(dangerLatitude, dangerLongitude));

    // add the openStreet map tiles ========================================
    osm = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">Open Street Map</a> contributors'
    });
    osm.addTo(map);
    
    drawnFeatures = new L.FeatureGroup();
    map.addLayer(drawnFeatures);
    // add the openStreet map tiles ========================================
}

$(document).ready(function(){
    if($("#map").length){
        initLeafletMap(dangerLatitude, dangerLongitude, 20);
        // leaflet draw ==========================
        let drawControl = new L.Control.Draw({
            // edit: {
            //     featureGroup: drawnFeatures,
            //     remove: false,
            // },
        });
        map.addControl(drawControl);

        // ========= Triggers =============================================
        map.on("draw:created", function(e){
            let type = e.layerType;
            let layer = e.layer;
            // console.log(layer.toGeoJSON().geometry.coordinates[0]);
            layer.bindPopup(`<p>${JSON.stringify(layer.toGeoJSON().geometry.coordinates[0])}</p>`);
            drawnFeatures.addLayer(layer);

            localStorage.setItem("dangerCoOrdinates", JSON.stringify(layer.toGeoJSON().geometry.coordinates[0]))

        });

        // map.on("draw:edited", function(e){
        //     let layers = e.layers;
        //     // console.log(e);
        //     layers.eachLayer(function(layer){
        //         console.log(layer);
        //     })
        // });
        // ========= Triggers =============================================
    }
});

$(document).on("change", "#dangerLatitude", function(){
    localStorage.removeItem('dangerCoOrdinates');

    dangerLatitude = $("#dangerLatitude").val()
    dangerLongitude = $("#dangerLongitude").val()
    // pan the map to searched location =======
    map.panTo(new L.LatLng(dangerLatitude, dangerLongitude));
    // pan the map to searched location =======
});



