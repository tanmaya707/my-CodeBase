const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const RequestHandler = require("../utils/RequestHandler");
const axios = require('axios');
const { API_URL, APPURL } = require('../../src/config/index')
const { calculateDistance,
    calculateDistanceInsTentApi,
    calculateTimeInKilometers,
    getRateChartCategory } = require("../utils/utilities");
const {
    MSG_RECORD_STATUS_SUCCESS,
    MSG_RECORD_FETCH_SUCCESS
} = require("../config/constants");
const requestHandler = new RequestHandler();

class ModuleController extends BaseController {
    constructor() {
        super();
    }

    static index = catchAsyncErrors(async (req, res, next) => {
        let pageTitle = 'Manage Modules'
        return res.render('modules/index',{
            pageTitle
        })
    });
    static reorderModule = catchAsyncErrors(async (req, res, next) => {
        let pageTitle = 'Reorder Modules'
        await axios({
            method: 'get',
            url: API_URL + 'parent-child-module-list',
        }).then(moduleChecker => {
            let all_modules = moduleChecker.data.data;
            return res.render('modules/reorder',{
                pageTitle, all_modules
            })
        }).catch(error=>{
            console.log(error);
        });
    });
}

module.exports = ModuleController;