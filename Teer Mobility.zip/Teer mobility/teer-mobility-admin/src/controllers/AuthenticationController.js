const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const RequestHandler = require("../utils/RequestHandler");
const { calculateDistance,
    calculateDistanceInsTentApi,
    calculateTimeInKilometers,
    getRateChartCategory } = require("../utils/utilities");
const {
    MSG_RECORD_STATUS_SUCCESS,
    MSG_RECORD_FETCH_SUCCESS
} = require("../config/constants");
const requestHandler = new RequestHandler();

class AuthenticationController extends BaseController {

    constructor() {
        super();
    }

    static index = catchAsyncErrors(async (req, res, next) => {
        let pageTitle = 'Login'
        return res.render('login',{
            pageTitle
        })
    });
    static dashboard = catchAsyncErrors(async (req, res, next) => {
        let pageTitle = 'Dashboard'
        return res.render('dashboard',{
            pageTitle
        })
    });
    static storeSession = catchAsyncErrors(async (req, res, next) => {
        req.session.email = ''
        req.session.name = req.body.data.user.name
        req.session.token = "Bearer "+req.body.data.token
        req.session.imageUrl = ''
        req.session.userId = req.body.data.user._id
        req.session.roleId = req.body.data.user.roleId
        req.session.rolePermissionChecker = res.locals.rolePermissionChecker

        if(req.body.data.user.isGod){
            req.session.superId = req.body.data.user._id 
        } else {
            req.session.superId = null
        }

        if(req.session.token){
            res.send({
                "status": true, 
                "message": "Profile Updated Successfully",
            })
        }
    });
    static logout = catchAsyncErrors(async (req, res, next) => {
        req.session.destroy()
        res.redirect('/')
    });

    static forgetPassword = catchAsyncErrors(async (req, res, next) => {

        let pageTitle = 'Forget password'
        return res.render('forget_password',{
            pageTitle
        })
    });
    static changePassword = catchAsyncErrors(async (req, res, next) => {
        let pageTitle = 'Change Password'
        return res.render('change_password',{
            pageTitle
        })
    });

    static myAccount = catchAsyncErrors(async (req, res, next) => {
        let pageTitle = 'My Account'
        return res.render('myAccount',{
            pageTitle
        })
    });

    static unauthorizedAccess = catchAsyncErrors((req, res, next) => {
        let pageTitle = "Unauthorized Access"
        return res.render('access-forbidden',{
            pageTitle
        });
    });

}


module.exports = AuthenticationController;
