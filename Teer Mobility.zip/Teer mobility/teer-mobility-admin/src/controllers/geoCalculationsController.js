const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const RequestHandler = require("../utils/RequestHandler");
const { calculateDistance,
    calculateDistanceInsTentApi,
    calculateTimeInKilometers,
    getRateChartCategory } = require("../utils/utilities");
const {
    MSG_RECORD_STATUS_SUCCESS,
    MSG_RECORD_FETCH_SUCCESS
} = require("../config/constants");
const requestHandler = new RequestHandler();

const moment = require('moment-timezone');
const dateFns = require('date-fns');
const geolib = require('geolib');

class GeoCalculationsController extends BaseController {
    constructor() {
        super();
    }

    static getPreciseDistance = catchAsyncErrors(async (req, res, next) => {
        let accuracy = 1;
        let start = req.body.start
        let end = req.body.end
        let distanceInMeters = geolib.getPreciseDistance(start, end)

        if(distanceInMeters){
            let distanceInKm = geolib.convertDistance(distanceInMeters, 'km');
            return res.status(200).json({
                status: true,
                message: "Success",
                data: distanceInKm,
            });
        }else{
            if(distanceInMeters == 0){
                return res.status(200).json({
                    status: false,
                    message: "Stop already Exists",
                    data: "",
                });
            }else{
                return res.status(500).json({
                    status: false,
                    message: "Distance can't be calculated. Please enter manually",
                    data: "",
                });
            }
        }
        
    });

    static getAutoCalculatedEndTime = catchAsyncErrors(async (req, res, next) => {
        let startTimeValue = req.body.startTimeValue
        let routeTime = req.body.routeTime
        
        let startTimeMoment = moment(startTimeValue, 'HH:mm');
        let routeTimeMoment = moment(routeTime, "HH:mm");

        let endTimeMoment = startTimeMoment.add(routeTimeMoment.hours(), 'hours').add(routeTimeMoment.minutes(), 'minutes');

        let endTimeOnly = endTimeMoment.format('HH:mm')

        if(endTimeMoment){
            res.status(200).json({
                status: true,
                message: "Success",
                data: endTimeOnly
            });
        }
    });
}

module.exports = GeoCalculationsController;