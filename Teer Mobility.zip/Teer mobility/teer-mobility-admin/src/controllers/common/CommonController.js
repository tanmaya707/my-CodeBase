const axios = require('axios');
const BaseController = require("../BaseController");
const catchAsyncErrors = require("../../middleware/catchAsyncErrors");

// const RiderModel = require("../../models/rider");
// const PrivacyPolicyModel = require("../../models/privacyPolicy");

const RequestHandler = require("../../utils/RequestHandler");
const { calculateDistance,
    calculateDistanceInsTentApi,
    calculateTimeInKilometers,
    getRateChartCategory } = require("../../utils/utilities");
const {
    MSG_RECORD_STATUS_SUCCESS,
    MSG_RECORD_FETCH_SUCCESS
} = require("../../config/constants");
const requestHandler = new RequestHandler();

class CommonController extends BaseController {

    constructor() {
        super();
    }

    // static updateStatus = catchAsyncErrors(async (req, res, next) => {
    //     const collcetionId = req.body.rider_id;
    //     const collection = req.body.collection;

    //     if (req.body.status === "0" || req.body.status === "1") {
    //         req.body.status === "0" ? false : true;
    //     }
    //     let updated;
    //     const data = {
    //         isActive: req.body.status
    //     };
    //     switch (collection) {
    //         case "riders":
    //             updated = await super.statusChange(RiderModel, collcetionId, data);
    //             break;

    //         default:
    //             break;
    //     }
    //     if (updated) {
    //         requestHandler.sendSuccess(res, MSG_RECORD_STATUS_SUCCESS)({
    //         });
    //     }
    // });

    // static getPrivacyPolicyList = catchAsyncErrors(async (req, res, next) => {
    //     const privacyPolicy = await PrivacyPolicyModel.find({ isActive: true }).select('content').exec();
    //     if (privacyPolicy) {
    //         requestHandler.sendSuccess(res, MSG_RECORD_FETCH_SUCCESS)({
    //             privacyPolicy
    //         });
    //     } else {
    //         return requestHandler.customError(res, 200, "Privacy policy content are not available!");
    //     }
    // });
}


module.exports = CommonController;
