const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const RequestHandler = require("../utils/RequestHandler");
const { calculateDistance,
    calculateDistanceInsTentApi,
    calculateTimeInKilometers,
    getRateChartCategory } = require("../utils/utilities");
const {
    MSG_RECORD_STATUS_SUCCESS,
    MSG_RECORD_FETCH_SUCCESS
} = require("../config/constants");
const requestHandler = new RequestHandler();

class ContentManagementController extends BaseController {
    constructor() {
        super();
    }

    static index = catchAsyncErrors(async (req, res, next) => {
        let pageTitle = 'Manage Contents'
        return res.render('contents/index',{
            pageTitle
        })
    });
}

module.exports = ContentManagementController;