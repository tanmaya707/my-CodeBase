const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const RequestHandler = require("../utils/RequestHandler");
const { calculateDistance,
    calculateDistanceInsTentApi,
    calculateTimeInKilometers,
    getRateChartCategory } = require("../utils/utilities");
const {
    MSG_RECORD_STATUS_SUCCESS,
    MSG_RECORD_FETCH_SUCCESS
} = require("../config/constants");
const requestHandler = new RequestHandler();

class VehicleController extends BaseController {
    constructor() {
        super();
    }
    static index = catchAsyncErrors(async (req, res, next) => {
        let pageTitle = 'Manage Vehicle Categories'
        return res.render('vehicleCategory/index',{
            pageTitle
        })
    });

    static vehicleModels = catchAsyncErrors(async (req, res, next) => {
        let pageTitle = 'Manage Vehicle Models'
        return res.render('vehicleModel/index',{
            pageTitle
        })
    });
    static vehicles = catchAsyncErrors(async (req, res, next) => {
        let pageTitle = 'Manage Vehicles'
        return res.render('vehicles/index',{
            pageTitle
        })
    });
}

module.exports = VehicleController;