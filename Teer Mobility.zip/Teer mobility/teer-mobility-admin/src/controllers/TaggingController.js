const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const RequestHandler = require("../utils/RequestHandler");
const { calculateDistance,
    calculateDistanceInsTentApi,
    calculateTimeInKilometers,
    getRateChartCategory } = require("../utils/utilities");
const {
    MSG_RECORD_STATUS_SUCCESS,
    MSG_RECORD_FETCH_SUCCESS
} = require("../config/constants");
const requestHandler = new RequestHandler();

class TaggingController extends BaseController {
    constructor() {
        super();
    }

    static vendorDriverTag = catchAsyncErrors(async (req, res, next) => {
        let pageTitle = 'Manage Vendor Driver Tagging'
        return res.render('mapping/vendorDriverMap',{
            pageTitle
        })
    });
    
    static vendorCorporateTag = catchAsyncErrors(async (req, res, next) => {
        let pageTitle = 'Manage Vendor Corporate Tagging'
        return res.render('mapping/vendorCorporateMap',{
            pageTitle
        })
    });
    
    static vendorVehicleTag = catchAsyncErrors(async (req, res, next) => {
        let pageTitle = 'Manage Vendor Vehicle Tagging'
        return res.render('mapping/vendorVehicleMap',{
            pageTitle
        })
    });

    static routeVehicleTag = catchAsyncErrors(async (req, res, next) => {
        let pageTitle = 'Manage Route Vehicle Tagging'
        return res.render('mapping/routeVehicleMap',{
            pageTitle
        })
    });
}

module.exports = TaggingController;