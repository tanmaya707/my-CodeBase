const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const RequestHandler = require("../utils/RequestHandler");
const { calculateDistance,
    calculateDistanceInsTentApi,
    calculateTimeInKilometers,
    getRateChartCategory } = require("../utils/utilities");
const {
    MSG_RECORD_STATUS_SUCCESS,
    MSG_RECORD_FETCH_SUCCESS
} = require("../config/constants");
const requestHandler = new RequestHandler();

class UserController extends BaseController {

    constructor() {
        super();
    }
    static userList = catchAsyncErrors(async (req, res, next) => {
        let pageTitle = "";

        if(res.locals.currentUrl == "users"){
            pageTitle = 'Manage Users'
        } else if(res.locals.currentUrl == "drivers"){
            pageTitle = 'Manage Drivers'
        } else if(res.locals.currentUrl == "corporate-users"){
            pageTitle = 'Manage Corporate Users'
        } else if(res.locals.currentUrl == "employees"){
            pageTitle = 'Manage Employees'
        } else if(res.locals.currentUrl == "students"){
            pageTitle = 'Manage Students'
        }

        return res.render('user/index',{
            pageTitle
        })
    });

    static driverList = catchAsyncErrors(async (req, res, next) => {
        let pageTitle = "";
        pageTitle = 'Manage Drivers';

        return res.render('driver/index',{
            pageTitle
        })
    });
    
    static employeeList = catchAsyncErrors(async (req, res, next) => {
        let pageTitle = "";
        pageTitle = 'Manage Employees';

        return res.render('employee/index',{
            pageTitle
        })
    });
    
    static studentList = catchAsyncErrors(async (req, res, next) => {
        let pageTitle = "";
        pageTitle = 'Manage Students';

        return res.render('student/index',{
            pageTitle
        })
    });
    
    static corporateUserList = catchAsyncErrors(async (req, res, next) => {
        let pageTitle = "";
        pageTitle = 'Manage Corporate Users';

        return res.render('corporateUser/index',{
            pageTitle
        })
    });
}


module.exports = UserController;
