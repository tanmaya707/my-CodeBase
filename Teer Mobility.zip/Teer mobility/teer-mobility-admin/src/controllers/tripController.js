const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const RequestHandler = require("../utils/RequestHandler");
const { calculateDistance,
    calculateDistanceInsTentApi,
    calculateTimeInKilometers,
    getRateChartCategory } = require("../utils/utilities");
const {
    MSG_RECORD_STATUS_SUCCESS,
    MSG_RECORD_FETCH_SUCCESS
} = require("../config/constants");
const requestHandler = new RequestHandler();

class TripController extends BaseController {
    constructor() {
        super();
    }

    static index = catchAsyncErrors(async (req, res, next) => {
        let pageTitle = 'Manage Trips'
        return res.render('trip/index',{
            pageTitle
        });
    });

    static tripTabularView = catchAsyncErrors(async (req, res, next) => {
        let pageTitle = 'Trips Tabular View'
        return res.render('tripTabularView/index',{
            pageTitle
        });
    });

}

module.exports = TripController;