const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const RequestHandler = require("../utils/RequestHandler");
const { calculateDistance,
    calculateDistanceInsTentApi,
    calculateTimeInKilometers,
    getRateChartCategory } = require("../utils/utilities");
const {
    MSG_RECORD_STATUS_SUCCESS,
    MSG_RECORD_FETCH_SUCCESS
} = require("../config/constants");
const requestHandler = new RequestHandler();

class CorporateController extends BaseController {

    constructor() {
        super();
    }
    static index = catchAsyncErrors(async (req, res, next) => {
        // console.log(res.locals.currentUrl);
        let pageTitle = ""
        if(res.locals.currentUrl == "corporates"){
            pageTitle = 'Manage Corporate'
        } else if(res.locals.currentUrl == "vendors"){
            pageTitle = 'Manage Vendor'
        } else if(res.locals.currentUrl == "schools"){
            pageTitle = 'Manage School'
        }
        return res.render('corporate/index',{
            pageTitle
        })
    });
}
module.exports = CorporateController;