const mongoose = require('mongoose');
const moment = require('moment-timezone');
const RiderModel = require('../models/rider');


// Function to calculate total duration
function calculateTotalDuration(user, startTime, endTime) {
    let totalDuration = 0;

    // if (user.loginTimes != 'undefined' && user.logoutTimes != 'undefined') {
    if (typeof user.loginTimes !== 'undefined' && typeof user.logoutTimes !== 'undefined') {
        // if (user.loginTimes && user.logoutTimes) {

        user.loginTimes.forEach((loginTime, index) => {
            const logoutTime = user.logoutTimes[index];

            const loginMoment = moment(loginTime).tz('Asia/Kolkata');
            const logoutMoment = moment(logoutTime).tz('Asia/Kolkata');

            startTime = moment.utc(startTime);
            endTime = moment.utc(endTime);

            // Assuming loginMoment and logoutMoment are also valid Moment.js objects
            if (loginMoment.isBefore(endTime) && logoutMoment.isAfter(startTime)) {
                const withinRangeLoginTime = moment.max(loginMoment, startTime);
                const withinRangeLogoutTime = moment.min(logoutMoment, endTime);

                totalDuration += withinRangeLogoutTime.diff(withinRangeLoginTime, 'minutes');
            }
        });
    }

    return totalDuration;
}


module.exports = {
    calculateDailyTime: calculateTotalDuration
}