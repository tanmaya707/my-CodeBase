const ErrorHandler = require("../utils/errorHandler");
const catchAsyncErrors = require("./catchAsyncErrors");

exports.isLoggedIn = catchAsyncErrors(async (req, res, next) => {
    if(req.session && (req.session.userId != '') && (req.session.userId != null)){
        next()
    }else{
        res.redirect('/')
    }
});

exports.isTokenAvailable = catchAsyncErrors(async (req, res, next) => {
    if(
        (req.session.token != undefined) &&
        (req.session.token != '')
    ){
        res.redirect('/dashboard')
    } else {
        next()
    }
});

exports.userHasPermission = catchAsyncErrors(async (req, res, next) => {
    let moduleAttemptingToAccess = '';
    res.locals.permissionModuleChecker.forEach(menu => {
        if(res.locals.superId != null){
            moduleAttemptingToAccess = menu._id.toString();
        }else{
            if(
                (res.locals.currentUrl.toString() == menu.moduleSlug.toString())
            ){
                moduleAttemptingToAccess = menu._id.toString();
            }
        }
        
    });

    console.assert(res.locals.rolePermissionChecker.includes(moduleAttemptingToAccess), `You don't have access to visit the forbidden forest : ${res.locals.currentUrl}`);
    // console.log(res.locals.rolePermissionChecker, moduleAttemptingToAccess)
    if(
        (res.locals.rolePermissionChecker.includes(moduleAttemptingToAccess))
    ){
        // ------- access permission found ------
        // ----- Let the poor peasant pass ------
        next();
    } else {
        // ------- access permission NOT found ------
        // ---- Y O U  S H A L L  N O T  P A S S ----
        
        // console.log(`Yo sorry ass don hav required permissions to access this module n!gga..!! Go back to from where u came..!! currentUrl => '${res.locals.currentUrl}'`);

        res.redirect('/dashboard');
    }

});