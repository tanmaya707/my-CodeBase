require('dotenv').config();
const app = require('./app');
const connectDatabase = require('./src/config/connect');
// const riderLogoutCron = require('./utils/logoutRiderCron');
// const { DateTime } = require('luxon');
const cron = require('node-cron');

moment = require('moment-timezone');
const dateFns = require('date-fns');

const Emitter = require('events');

// Function to start the server
function startServer() {
  app.listen(process.env.PORT, () => {
    if (process.env.APP_ENV == "production") {
      console.log(`server is working on ${process.env.APP_URL}`);
    } else {
      console.log(`server is working on http://localhost:` + process.env.PORT + "/");
    }
  });
}

process.on("uncaughtException", (err) => {
    console.log(`Error: ${err.message}`);
    console.log(`Shutting down the server due to unhandled Uncaught Rejection`);
  
    server.close(() => {
      // startServer();
    });
  });
  
  connectDatabase();
  
  // Event emitter
  const eventEmitter = new Emitter();
  app.set('eventEmitter', eventEmitter);
  
  process.env.TZ = 'Asia/Kolkata';
  
  
  const server = app.listen(process.env.PORT, () => {
    if (process.env.APP_ENV == "production") {
      console.log(`server is working on ${process.env.APP_URL}`);
    } else {
      console.log(`server is working on http://localhost:` + process.env.PORT + "/");
    }
  });
  
  process.on("unhandledRejection", err => {
    console.log(`Error: ${err.message}`);
    console.log(`Shutting down the server due to unhandled Promise Rejection`);
  
    // Close the server gracefully
    server.close(() => {
      console.log('Server closed. Restarting...');
  
      // Restart the server after it's closed
      // startServer();
    });
  });

  // ============================ socket.io START ============================
  const io = require('socket.io')(server, {
      cors: {
          origin: "*",
          methods: ["GET", "POST"]
      }
  });
  // const RiderModel = require('./models/rider');
  
  const { calculateDistance,
    calculateDistanceInsTentApi,
    calculateTimeInKilometers,
    getRateChartCategory, 
    calculateTimeDifferenceInMinutes,
    dateFormat,
  } = require("./src/utils/utilities");

  const driverModel = require('./src/models/driverModel');
  const driverLocationsModel = require('./src/models/driverLocationsModel');
  const tripsModel = require('./src/models/tripsModel');
  const tripLocationsHistoryModel = require('./src/models/tripLocationsHistoryModel');
  const socketRoomModel = require('./src/models/socketRoomModel');

  // Handle WebSocket connections
  let currentRoom = null;

  let passengerSockets = {};
  let registerAsPassengerHitCount = 0;
  io.on('connection', async (socket) => {
    // console.log(`a client connected =============>`);

    // Handle passengers joining the system
    socket.on("register as passenger", async (data) => {
      try{
        if(
          (data) && 
          (data.tripId != '') && 
          (data.tripId != null)
        ){
          registerAsPassengerHitCount++;
    
          console.log(`hitting: "register as passenger" with data => ${registerAsPassengerHitCount}`);
          // console.log(data);
          
          passengerSockets[socket.id] = socket;
          console.log(`Passenger ${socket.id} registered`);
          
          let socketRoom = await socketRoomModel.findOne({
            tripId: data.tripId,
          });
    
          if(socketRoom){
            socket.join(socketRoom.roomId);
            console.log(`Passenger with socketId: ${socket.id} joined room: ${socketRoom.roomId}`);
          } else {
            console.log(`No room found for this tripId : ${data.tripId}`);
            console.log(`Passenger can not enter room as room not created.`);
          }
          socket.emit("acknowledgement: passenger registered and joined from backend", socketRoom.roomId);
        } else {
          console.log("No tripId provided from customer app.");
        }
      } catch(error){
        console.log(`error ==> from "register as passenger" catch =>`);
        console.log(error);
      }
    });

    socket.on('room created by driver', async ({roomId, tripId}) => {
      // console.log("roomId =====>");
      // console.log(roomId);
      // console.log("tripId =====>");
      // console.log(tripId);
      
      let roomData = {
        tripId: tripId,
        roomId: roomId,
      };
      let checkRoomExists = await socketRoomModel.findOne({
        tripId: tripId,
        isActive: true,
        isDeleted: false,
      });
      // console.log("checkRoomExists ==>");
      // console.log(checkRoomExists);
      
      if(!checkRoomExists){
        console.log("if room has not been created yet");
        // === if room has not been created yet ====
        // ======= driver joins room =======
        socket.join(roomId);
        console.log(`Driver has joined room: ${roomId}`);
        // ======= driver joins room =======
        currentRoom = roomId;

        const document = new socketRoomModel(roomData);
        let socketRoom = await document.save();

        // console.log("socketRoom ===>");
        // console.log(socketRoom);
        
        // ======== tripPassenger's should join this room to get trip updates =======

        // Notify all connected passengers about the new room
        Object.keys(passengerSockets).forEach(passengerId => {
          const passengerSocket = passengerSockets[passengerId];

          if (passengerSocket) {
            passengerSocket.emit("trip room created", socketRoom);
          }
        });

        // ========= emit room details in the room for driver/passenger to listen ==========
        console.log(`hitting if : roomDetails emitting inside room. roomDetails: ${socketRoom}`);
        
        io.to(roomId).emit("room details", socketRoom);
        // ========= emit room details in the room for driver/passenger to listen ==========

        // ======== tripPassenger's should join this room to get trip updates =======
      } else {
        // ===== rejoin driver in the room =====
        socket.join(roomId);
        // ===== rejoin driver in the room =====
        console.log(`Driver with socketId: ${socket.id} is already in room: ${roomId}`);
        // ======== tripPassenger's should join this room to get trip updates =======

        // Notify all connected passengers about the new room
        Object.keys(passengerSockets).forEach(passengerId => {
          const passengerSocket = passengerSockets[passengerId];

          if (passengerSocket) {
            passengerSocket.emit("trip room created", checkRoomExists);
          }
        });

        // ========= emit room details in the room for driver/passenger to listen ==========
        console.log(`hitting else : roomDetails emitting inside room. roomDetails: ${checkRoomExists}`);

        io.to(roomId).emit("room details", checkRoomExists);
        // ========= emit room details in the room for driver/passenger to listen ==========

        // ======== tripPassenger's should join this room to get trip updates =======
      }
    });

    // Handle passengers joining a room
    // socket.on("passenger join", (roomId) => {
    //   socket.join(roomId);
    //   console.log(`Passenger with socketId: ${socket.id} joined room: ${roomId}`);

    //   socket.emit("acknowledgement: passenger joined room", socket.id);
    // });

    socket.on('driver location update emmitted', async (data) => {
      // console.log(`Driver location update data ${JSON.stringify(data)} received.`);

      let { driverUserId, lat, long, heading, address, source, accuracy, roomId } = data;
      // Get the current time in "Asia/Kolkata" time zone =======
      let momentKolkata = moment().tz("Asia/Kolkata");
      let currentDate = momentKolkata.format("YYYY-MM-DD");
      let currentDateTime = momentKolkata.format("YYYY-MM-DD HH:mm:ss");
      let currentDay = momentKolkata.format("dddd");
      // let currentTime = momentKolkata.format('HH:mm');
      // Get the current time in "Asia/Kolkata" time zone =======
      let driver = await driverModel.findOne({
        userId: driverUserId,
      });
      
      let checkExist = await driverLocationsModel.findOne({
        userId: driverUserId,
      });
      let dataToBeUpdated = {
        userId: driverUserId,
        coordinates: [lat, long],
        heading: heading,
      };

      let updated = [];
      if(checkExist){
        // if record found, udpate ======
        let existingCoords = checkExist.coordinates;
        // updated = await super.updateById(driverLocationsModel, checkExist._id.toString(), dataToBeUpdated);

        updated = await driverLocationsModel.findByIdAndUpdate(checkExist._id.toString(), dataToBeUpdated, {
          new: true, // Return the updated document instead of the old one
          runValidators: true, // Run the model's validators on update
        });

        // if driver is in a trip, then notify all the passengers of that trip ====
        let checkOngoingTrips = await tripsModel.find({
          isCancelled: false,
          isDeleted: false,
          isActive: true,

          driverId: driver._id,

          tripStatus: {
            $in: ["Started", "Paused", "Onboarding", "DropOff"]
          },
        }).populate([
          {
            path: "tripPlanId",
            model: "tripPlanCollection",
            populate: [
              {
                path: "vendorId",
                model: "corporateCollection",
              },
              {
                path: "corporateId",
                model: "corporateCollection",
              },
            ],
          },
          {
            path: "vehicleId",
            model: "vehicleCollection",
            populate: {
              path: "modelId",
              model: "vehicleModelCollection",
            },
          },
        ]);

        if(checkOngoingTrips.length > 0){
          let currentTrip = checkOngoingTrips.filter((trip)=>{
            let startTime = new Date(dateFormat(trip.tripDate)+" "+trip.tripStartTime);
            let endTime = new Date(dateFormat(trip.tripDate)+" "+trip.tripEndTime);
            let currentTime = new Date();
            if(
              // ((startTime >= currentTime) && (endTime <= currentTime)) &&
              ((currentTime >= startTime) && (currentTime <= endTime)) &&
              ((trip.tripStatus == "Started"))
            ){
              return trip;
            }
          });

          if(currentTrip.length > 0){
            // =========== if trip ongoing ==========
            let tripId = currentTrip[0]._id;
            
            // =================================================================
            // ============ tripLocationHistory store/update STARTS ============
            // =================================================================
            let driver = await driverModel.findOne({
              userId: driverUserId,
            });
            let tripLocationsHistoryExist = await tripLocationsHistoryModel.findOne({
              tripId: tripId,
            }).lean();

            let updatedTripLocationsHistory = [];
            if(tripLocationsHistoryExist){
              // ============ update; push in locationHistory Array field STARTS ============
              let locationHistory = {
                driverId: driver._id,
                // ==== location parameters ====
                address: address,
                coordinates: [lat, long],
                // ==== location parameters ====

                // ==== vehicle parameters ====
                speed: 0,
                ignitionStatus: false,
                acStatus: false,
                odometerKm: 0,
                fuel: 0,
                // ==== vehicle parameters ====
                source: source,
                accuracy: accuracy,
                feedTime: currentDateTime,
              };

              let existingHistory = tripLocationsHistoryExist.locationHistory;
              existingHistory.push(locationHistory)

              let tripLocationHistoryData = {
                tripId: tripId,
                locationHistory: existingHistory,
              };

              updatedTripLocationsHistory = await tripLocationsHistoryModel.findByIdAndUpdate(
                tripLocationsHistoryExist._id.toString(),
                tripLocationHistoryData,
                {
                  new: true, // Return the updated document instead of the old one
                  runValidators: true, // Run the model's validators on update
                }
              );
              // ============ update; push in locationHistory Array field ENDS ============
            } else {
              // ================== create new record START ==================
              let locationHistory = {
                driverId: driver._id,
                // ==== location parameters ====
                address: address,
                coordinates: [lat, long],
                // ==== location parameters ====

                // ==== vehicle parameters ====
                speed: 0,
                ignitionStatus: false,
                acStatus: false,
                odometerKm: 0,
                fuel: 0,
                // ==== vehicle parameters ====
                source: source,
                accuracy: accuracy,
                feedTime: currentDateTime,
              };
              let tripLocationHistoryData = {
                tripId: tripId,
                locationHistory: [locationHistory],
              };

              const document = new tripLocationsHistoryModel(tripLocationHistoryData);
              updatedTripLocationsHistory = await document.save();
              // ================== create new record ENDS ==================
            }
            // =================================================================
            // ============= tripLocationHistory store/update ENDS =============
            // =================================================================

            let locationData = {
              "tripId": `${tripId}`,
              "driverLat": `${updated.coordinates[0]}`,
              "driverLong": `${updated.coordinates[1]}`,
              "heading": `${updated.heading}`,
            };

            let socketRoom = await socketRoomModel.findOne({
              tripId: tripId,
              isActive: true,
              isDeleted: false,
            });

            // ======== tripPassenger's should join this room to get trip updates =======
            socket.emit("trip room created", socketRoom);
            // ======== tripPassenger's should join this room to get trip updates =======

            // ======== passengers & corporates and vendors should listen to this =======
            // console.log(`locationData being emitted to room ${roomId} => emitted data ==>`);
            // console.log(locationData);
            
            io.to(roomId).emit("updated driver location", locationData);
            // ======== passengers & corporates and vendors should listen to this =======
          } else{
            // ============= no current trip found =============
            console.log("No current trip found; Nothing to emit..!!");
            console.log(`Socket.io says, "... kya boring life hay yaar, currentTrip hay hi nehi, kya emit karu?"`);
          }
        } else{
          // ============= no ongoing trips found =============
          console.log("No ongoing trips found; Nothing to emit..!!");
          console.log(`Socket.io says, "... kya boring life hay yaar, currentTrip hay hi nehi, kya emit karu?"`);
        }

      } else {
        // if record not found, create ======
        // updated = await super.create(res, driverLocationsModel, data);
        const document = new driverLocationsModel(dataToBeUpdated);
        updated = await document.save();
      }
    });

    // Handle disconnection
    socket.on('disconnect', () => {
      console.log(`Client disconnected: ${socket.id}`);
      delete passengerSockets[socket.id];
    });

    // Handle error =======
    socket.on('error', (err) => {
      console.error(`Socket error: ${err.message}`);
    });
  });


  // ============================ socket.io END ============================