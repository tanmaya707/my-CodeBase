const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/errorHandler");
const RequestHandler = require("../utils/RequestHandler");
const mongoose = require("mongoose");
const ObjectId = mongoose.Types.ObjectId;
const moment = require('moment-timezone');
const dateFns = require('date-fns');

const {
  calculateDistance,
  calculateDistanceInsTentApi,
  calculateTimeInKilometers,
  getRateChartCategory,
  dateFormat,
} = require("../utils/utilities");
const {
  vehicleCategoryDetails,
  vehicleModelDetails,
	tripStopDetails,
} = require("../utils/common");
const {
  MSG_RECORD_STATUS_SUCCESS,
  MSG_RECORD_FETCH_SUCCESS,
} = require("../config/constants");
const requestHandler = new RequestHandler();

const countryModel = require("../models/countryModel");
const tripStopModel = require("../models/tripStopModel");
const routeMapModel = require("../models/routeMapModel");
const tripPassengerModel = require("../models/tripPassengerModel");

const { includes } = require("lodash");
const tripsModel = require("../models/tripsModel");

class TripStopController extends BaseController {
  constructor() {
    super();
  }

  static tripStopList = catchAsyncErrors(async (req, res, next) => {
		const { countryCode, text } = req.body;

    let totalTripStops = []
    let tripStops = []
		
		let totalCount = 0;
		let totalPages= 0;
		let page = 0;
		let limit = 0;
		let skip = 0;
		
    if(req.method == "POST"){
      // Pagination parameters ===========
      page = req.body.pageNo ? parseInt(req.body.pageNo) : 1; // Current page number
      limit = req.body.documentPerPage ? parseInt(req.body.documentPerPage) : 3; // Number of documents per page
      skip = (page - 1) * limit; // Number of documents to skip
      // Pagination parameters ===========
			let match = {
				$and: [
					{
						$or: [
							{
								stopName: {
									$regex: ".*" + text + ".*",
									$options: "i",
								},
							},
							{
								stopType: {
									$regex: ".*" + text + ".*",
									$options: "i",
								},
							},
							// {
							// 	accessibility: {
							// 		$regex: ".*" + text + ".*",
							// 		$options: "i",
							// 	},
							// },
						],
					}
				]
			};
			if(countryCode != ''){
				let country = await countryModel.findOne({ _id: countryCode });
				match['countryCode'] = country._id;
			}
			const aggregatorOpts = [
				{
					$addFields: {
						countryCode: "$countryCode",
						stopName: "$stopName",
						stopType: "$stopType",
						// accessibility: {
						// 	"$in": "$accessibility"
						// },
					},
				},
				{
					$match: match,
				},
				{
						$sort: { createdAt: -1 } // Sort by createdAt in descending order
				},
			];
			totalTripStops = await tripStopModel.aggregate(aggregatorOpts).exec();
			tripStops = await tripStopModel.aggregate(aggregatorOpts).skip(skip).limit(limit).exec();
			await countryModel.populate(
				tripStops,
				{
					"path": "countryCode",
					"model": "countryCollection",
					"select": ["name",]
				}
			);
    } else {
        // ======= for dropdown ===========
        tripStops = await super.getList(req, tripStopModel, "");
				await countryModel.populate(
					tripStops,
					{
						"path": "countryCode",
						"model": "countryCollection",
            "select": ["name",]
					}
				);
    }

    totalCount = totalTripStops.length;
    totalPages= Math.ceil(totalCount/limit);
    
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: tripStopDetails(tripStops),
			pagination: {
				total: totalCount,
				totalPages: totalPages,
				rowsPerPage: limit,
				currentPage: page,
				hasNextPage: page < totalPages,
				hasPrevPage: page > 1
			},
    });
  });
  static stopsList = catchAsyncErrors(async (req, res, next) => {
    let route = [];
    let stopIdsArr = [];
    let stops = []
    let capacity = []
    const { routeId, text } = req.body;

    if(req.method == "POST"){
      route = await routeMapModel.findOne({ _id: routeId });
      await tripStopModel.populate(
        route,
        [
          {
            "path": "routeStops.stopId",
            "model": "tripStopCollection"
          }
        ]
      );

      route.routeStops.forEach((stop)=>{
        stopIdsArr.push(stop.stopId._id.toString())
      }); 

      stops = await tripStopModel.find(
        {
          _id: {
            $in: stopIdsArr
          }
        }
      ).sort({ createdAt: -1 });

      stops.forEach(element => {
        element.accessibility.forEach(val => {
          if(!capacity.includes(val)){
            capacity.push(val)
          }
        })
      })
    } else {
      // ======= for dropdown ===========
      // route = await super.getList(req, tripStopModel, "");
      // await countryModel.populate(
      // 	route,
      // 	{
      // 		path: "countryCode",
      // 		model: "countryCollection"
      // 	}
      // );
    }
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      routeStops: route.routeStops,
      data: stops,
      capacity: capacity.sort(function (a,b) {
        return b - a; // Descending
      }),
      // data: tripStopDetails(tripStops),
    });
  });
  static stopsListWithTime = catchAsyncErrors(async (req, res, next)=>{
    let { tripId, routeId } = req.body;

    let tripPassenger = await tripPassengerModel.findOne({
      tripId: tripId,
    }).lean().populate([
      {
        "path": "tripId",
        "model": "tripsCollection",
        "populate": {
          "path": "tripPlanId",
          "model": "tripPlanCollection",
        }
      },
    ]);
    await tripStopModel.populate(
      tripPassenger,
      [
        {
          "path": "tripId.tripPlanId.stops.tripStopId",
          "model": "tripStopCollection",
        },
      ]
    );
    // return res.status(200).json({
    //   data: tripPassenger
    // });

    let startTime = dateFormat(tripPassenger.tripId.tripDate) +" "+ tripPassenger.tripId.tripStartTime + ":00";

    tripPassenger.tripId.tripPlanId.stops.forEach((stop)=>{
      startTime = new Date(startTime);
      let seconds = stop.time * 3600;
      if(seconds > 0){
        startTime = startTime.setSeconds(startTime.getSeconds() + seconds);
      }
      stop['eta'] = new Date(startTime);
    });

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      stopListWithTime: tripPassenger.tripId.tripPlanId.stops,
      // tripPassenger: tripPassenger,
    });
    
    
  });
  static stopsListWithTimeForCorporateApp = catchAsyncErrors(async (req, res, next)=>{
    let { tripId, routeId } = req.body;

    // Get the current time in "Asia/Kolkata" time zone =======
    let momentKolkata = moment().tz('Asia/Kolkata');
    let currentDate = momentKolkata.format('YYYY-MM-DD');
		let currentDay = momentKolkata.format('dddd');
    let currentTime = momentKolkata.format('HH:mm');
		// Get the current time in "Asia/Kolkata" time zone =======

    let trip = await tripsModel.findOne({
      _id: tripId,
    }).lean().populate([
      {
        "path": "tripPlanId",
        "model": "tripPlanCollection",
      },
    ]);
    
    await tripStopModel.populate(
      trip,
      [
        {
          "path": "tripPlanId.stops.tripStopId",
          "model": "tripStopCollection",
        },
      ]
    );
    let todayTrips = await tripsModel.find(
      {
        tripDate: currentDate
      }
    ).populate(
      {
        "path": "tripPlanId",
        "model": "tripPlanCollection"
      }
    );
    let tripCount = 0;
    todayTrips.forEach((todayTrip)=>{
      if(todayTrip.tripPlanId.routeId.toString() == trip.tripPlanId.routeId.toString()){
        tripCount++
      }
    });

    let startTime = dateFormat(trip.tripDate) +" "+ trip.tripStartTime + ":00";

    trip.tripPlanId.stops.forEach((stop)=>{
      startTime = new Date(startTime);
      let seconds = stop.time * 3600;
      if(seconds > 0){
        startTime = startTime.setSeconds(startTime.getSeconds() + seconds);
      }
      stop['eta'] = new Date(startTime);
    });

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      stopListWithTime: trip.tripPlanId.stops,
      tripCount: tripCount,
    });
    
    
  });
  static tripStopAddUpdate = catchAsyncErrors(async (req, res, next) => {
    let { countryCode, stopType, stopName, address, latitude, longitude, accessibility, dangerAddress, dangerLatitude, dangerLongitude, dangerCoOrdinates,  _id } = req.body;

    let data = {
      countryCode: countryCode,
      stopName: stopName,
      address: address,
      location: {
        type: "Point",
        coordinates: [latitude, longitude],
      },
      stopType: stopType,
      accessibility: accessibility,
    };
    if(dangerAddress){
			data.dangerAddress = dangerAddress
			data.dangerLatitude = dangerLatitude
			data.dangerLongitude = dangerLongitude
			data.dangerZone = {
					status: true,
					dangerLocation: {
            type: "Polygon",
            coordinates: JSON.parse(dangerCoOrdinates),
          },
          
			}
    }
    const updated =
      _id && _id != null && _id != ""
        ? await super.updateById(tripStopModel, _id.toString(), data)
        : await super.create(res, tripStopModel, data);

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: updated,
    });
  });

  static gettripStopDetail = catchAsyncErrors(async (req, res, next) => {
    const { id } = req.body;
    const asset = await tripStopModel.findOne({ _id: id });
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: asset,
    });
  });

  static deletetripStop = catchAsyncErrors(async (req, res, next) => {
    const { id } = req.body;
    const updated = await super.deleteById(tripStopModel, id);
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: updated,
    });
  });

}

module.exports = TripStopController;
