const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/errorHandler");
const RequestHandler = require("../utils/RequestHandler");
const mongoose = require("mongoose");
const ObjectId = mongoose.Types.ObjectId;
const crypto = require("crypto");
// ------- STRIPE INITIALIZE -------
const stripe = require('stripe')(
  (process.env.APP_ENV == 'production')
    ? process.env.STRIPE_LIVE_SECRET_KEY 
    : process.env.STRIPE_TEST_SECRET_KEY
);
// ------- STRIPE INITIALIZE -------

// ------- RAZORPAY INITIALIZE -------
const razorpayConfig = require("../config/index").RAZORPAY;
const Razorpay = require('razorpay');
// const razorpay = new Razorpay({
//   key_id: (process.env.APP_ENV == 'production')
//     ? process.env.RAZORPAY_LIVE_KEY_ID 
//     : process.env.RAZORPAY_TEST_KEY_ID,
//   key_secret: (process.env.APP_ENV == 'production')
//     ? process.env.RAZORPAY_LIVE_KEY_SECRET 
//     : process.env.RAZORPAY_TEST_KEY_SECRET,
// });
const razorpay = new Razorpay(
  razorpayConfig.mode === "TEST"
    ? razorpayConfig.testCred
    : razorpayConfig.liveCred
);
// ------- RAZORPAY INITIALIZE -------

const {
  calculateDistance,
  calculateDistanceInsTentApi,
  calculateTimeInKilometers,
  getRateChartCategory,
} = require("../utils/utilities");
const {
  vehicleCategoryDetails,
  vehicleModelDetails,
} = require("../utils/common");
const {
  MSG_RECORD_STATUS_SUCCESS,
  MSG_RECORD_FETCH_SUCCESS,
} = require("../config/constants");
const requestHandler = new RequestHandler();

const countryModel = require("../models/countryModel");
const trackingApiModel = require("../models/trackingApiModel");
const assetModel = require("../models/assetModel");
const settingModel = require("../models/settingModel");
const walletModel = require("../models/walletModel");
const transactionModel = require("../models/transactionModel");
const transactionLogModel = require("../models/transactionLogModel");
const walletLedgerModel = require("../models/walletLedgerModel");
const transactionHistoryModel = require("../models/transactionHistoryModel");

class walletController extends BaseController {
  constructor() {
    super();
  }

  // ====================================== STRIPE ======================================
  static rechargeWalletWithStripe = catchAsyncErrors(async (req, res, next) => {
    const { amount, currency } = req.body;

    if (!amount) {
      return res.status(422).json({
        status: false,
        message: "Amount is required",
        data: {},
      });
    }
    if (!currency) {
      return res.status(422).json({
        status: false,
        message: "Currency is required",
        data: {},
      });
    }

    const customer = await stripe.customers.create({
      name: "Jenny Rosen",
      address: {
        line1: "510 Townsend St",
        postal_code: "98140",
        city: "San Francisco",
        state: "CA",
        country: "US",
      },
    });
    const ephemeralKey = await stripe.ephemeralKeys.create(
      { customer: customer.id },
      { apiVersion: "2024-06-20" }
    );

    let options = {
      amount: parseFloat(amount.toString()) * 100,
      currency: currency,
      customer: customer.id,
    };

    // Create Payment Intent
    const paymentIntent = await stripe.paymentIntents.create({
      amount: options.amount,
      currency: options.currency,
      customer: options.customer,
      description: "Teer Mobility Wallet Recharge",
      payment_method_types: ["card"],
      // automatic_payment_methods: {
      //   enabled: true,
      // },
    });
    // return res.status(200).json({
    //   paymentIntent: paymentIntent,
    // });

    let transactionCreated = await transactionModel.create({
      userId: req.user._id,
      paymentGatewayOrderId: paymentIntent.id,
      paidAmount: paymentIntent.amount,
			paidCurrency: paymentIntent.currency,
      type: "walletRecharge",
      remark: "Wallet Recharge",
      paymentDate: new Date(),
      paymentStatus: "Pending",
    });

    // console.log("transactionCreated ===>");
    // console.log(transactionCreated);

    if (transactionCreated) {
      let transactionLogCreated = await transactionLogModel.create({
        transactionId: transactionCreated._id,
        request: JSON.stringify(req.body),
        response: JSON.stringify(paymentIntent),
      });
      if (transactionLogCreated) {
        return res.status(200).json({
          status: true,
          message: "Intent created successfully in Stripe Server",
          data: {
            amount: paymentIntent.amount,
            stripeOrderId: paymentIntent.id,
            paymentIntent: paymentIntent.client_secret,
            ephemeralKey: ephemeralKey.secret,
            customer: customer.id,
            publishableKey:
              process.env.APP_ENV == "production"
                ? process.env.STRIPE_LIVE_PUBLISHABLE_KEY
                : process.env.STRIPE_TEST_PUBLISHABLE_KEY,
          },
          errors: null,
        });
      }
    }
  });

  static updateWalletWithStripe = catchAsyncErrors(async (req, res, next) => {
    const {
      stripeOrderId,
      // amount,
      currency,
    } = req.body;

    if (!stripeOrderId) {
      return res.status(422).json({
        status: false,
        message: "Stripe order Id is required",
        data: {},
      });
    }

    // Retrieve the Payment Intent from Stripe
    const paymentIntent = await stripe.paymentIntents.retrieve(stripeOrderId);

    if (paymentIntent) {
      if (paymentIntent.status === "succeeded") {
        // Payment was successful
        let existingTransaction = await super.getByCustomOptionsSingle(
          req,
          transactionModel,
          {
            paymentGatewayOrderId: stripeOrderId,
          }
        );
        // transactionModel.findByRazorPayOrderId(stripeOrderId);

        if (existingTransaction) {
          await super.updateById(transactionModel, existingTransaction._id, {
            paymentStatus: "Paid",
            paidVia: "Stripe",
          });

          await super.create(res, transactionLogModel, {
            transactionId: existingTransaction._id,
            request: JSON.stringify(req.body),
            response: JSON.stringify(paymentIntent),
          });

          let checkWallet = await super.getByCustomOptionsSingle(
            req,
            walletModel,
            {
              userId: req.user._id,
              currency: currency,
            }
          );
          let amount = parseFloat(existingTransaction.paidAmount) / 100;
          // console.log("amount ===>");
          // console.log(amount);
          // console.log("checkWallet ====>");
          // console.log(checkWallet);
          
          if (checkWallet) {
            // ==== if record present in wallet --- update-wallet ====
            amount += parseFloat(checkWallet.amount.toString());
            await super.updateById(walletModel, checkWallet._id, {
              amount: amount,
            });
            // ==== if record present in wallet --- update-wallet ====
          } else {
            // console.log("creating new wallet");
            
            // ==== if record NOT present in wallet --- create-wallet record ====
            await super.create(res, walletModel, {
              userId: req.user._id,
              amount: amount,
              currency: currency,
            });
            // ==== if record NOT present in wallet --- create-wallet record ====
          }
          let checkUpdatedWallet = await super.getByCustomOptionsSingle(
            req,
            walletModel,
            {
              userId: req.user._id,
              currency: currency,
            }
          );
          // console.log("checkUpdatedWallet ===>");
          // console.log(checkUpdatedWallet);
          
          // ==== creating wallet ledger ====
          await super.create(res, walletLedgerModel, {
            // walletId: checkWallet ? checkWallet._id : existingTransaction._id,
            walletId: checkWallet ? checkWallet._id : checkUpdatedWallet._id,
            amount: amount.toFixed(2),
            tranactionType: "credit",
            gatewayName: "Stripe",
            currentBalance: checkUpdatedWallet.amount.toFixed(2),
            remarks: `Wallet recharge of ${amount.toFixed(2)} is successful.`,
          });
          // ==== creating wallet ledger ====

          let transactionHistoryData = {
            userId: req.user._id,
            transactionId: existingTransaction._id,
            
            amount: parseFloat(existingTransaction.paidAmount) / 100,
            currency: currency,

            gatewayName: "Stripe",

            type: "walletRecharge",
            remarks: "Wallet recharge via Stripe successful.",
            
            isSuccess: true,
          };
          let transactionHistory = await super.create(res, transactionHistoryModel, transactionHistoryData);

          return res.status(200).json({
            status: true,
            message: "Wallet recharged Successfully!",
            data: {},
          });
        } else {
          let transactionHistoryData = {
            userId: req.user._id,
            transactionId: existingTransaction._id,
            
            amount: parseFloat(existingTransaction.paidAmount) / 100,
            currency: currency,
    
            gatewayName: "Stripe",
    
            type: "walletRecharge",
            remarks: "Wallet recharge via Stripe failed as transaction not found probably due to incorrect Stripe Order Id..!!",
            
            isSuccess: false,
          };
          let transactionHistory = await super.create(res, transactionHistoryModel, transactionHistoryData);

          return res.status(404).json({
            status: false,
            message: "Transaction not found",
            data: {},
          });
        }
      } else {
        // Payment status is not 'succeeded' ====
        let transactionHistoryData = {
          userId: req.user._id,
          transactionId: existingTransaction._id,
          
          amount: parseFloat(existingTransaction.paidAmount) / 100,
          currency: currency,

          gatewayName: "Stripe",

          type: "walletRecharge",
          remarks: "Wallet recharge via Stripe failed or not completed yet..!!",
          
          isSuccess: false,
        };
        let transactionHistory = await super.create(res, transactionHistoryModel, transactionHistoryData);

        return res.status(400).json({
          status: false,
          message: "Payment failed or is not yet completed.",
          data: {},
        });
      }
    } else {
      let transactionHistoryData = {
        userId: req.user._id,
        transactionId: existingTransaction._id,
        
        amount: parseFloat(existingTransaction.paidAmount) / 100,
        currency: currency,

        gatewayName: "Stripe",

        type: "walletRecharge",
        remarks: "Wallet recharge via Stripe failed as payment intent not found due to incorrect Stripe Order Id..!!",
        
        isSuccess: false,
      };
      let transactionHistory = await super.create(res, transactionHistoryModel, transactionHistoryData);

      return res.status(404).json({
        status: false,
        message: "Payment intent not found.",
        data: {},
      });
    }
  });
  // ====================================== STRIPE ======================================

  // ====================================== RAZORPAY ======================================
  static rechargeWalletWithRazorPay = catchAsyncErrors(async (req, res, next) => {
		const { amount, currency } = req.body;

		if (!amount) {
			return res.status(422).json({
				status: false,
				message: "Amount is required",
				data: {},
			});
		}
		if (!currency) {
			return res.status(422).json({
				status: false,
				message: "Currency is required",
				data: {},
			});
		}

		// Create a Razorpay order
		const options = {
			amount: parseFloat(amount.toString()) * 100, // amount in paise
			currency: currency,
			receipt: `receipt_${Date.now()}`,
		};

		const order = await razorpay.orders.create(options);
		// console.log("order =====>");
		// console.log(order);
		
		if (order) {
			let transactionCreated = await transactionModel.create({
				userId: req.user._id,

				paymentGatewayOrderId: order.id,
				paidVia: "Razorpay",
				
				type: "walletRecharge",

				paidAmount: order.amount,
				paidCurrency: order.currency,

				paymentDate: new Date(),
				paymentStatus: "Pending",

				remark: "Wallet Recharge",
			});

			// console.log("transactionCreated ===>");
			// console.log(transactionCreated);

			if (transactionCreated) {
				let transactionLogCreated = await transactionLogModel.create({
					transactionId: transactionCreated._id,
					request: JSON.stringify(req.body),
					response: JSON.stringify(order),
				});
				if (transactionLogCreated) {
					return res.status(200).json({
						status: true,
						message: "Order created successfully in Razorpay",
						data: {
							amount: order.amount,
							razorpayOrderId: order.id,
							currency: order.currency,
							orderId: order.id,
							key: razorpayConfig.mode === "TEST" ? razorpayConfig.testCred.key_id : razorpayConfig.liveCred.key_id
							// key: (process.env.APP_ENV == 'production')
							// 	? process.env.RAZORPAY_LIVE_KEY_ID 
							// 	: process.env.RAZORPAY_TEST_KEY_ID,
						},
						errors: null,
					});
				} else {
					return res.status(500).json({
						status: false,
						message: "Oopss..!! Something wrong happened while creating transaction log..!!",
						data: {}
					});
				}
			}
		} else {
			return res.status(400).josn({
				status: false,
				message: "Oopss..!! Something went wrong while creating order in Razorpay gateway..!!",
				data: {},
			});
		}
	});

  static updateWalletWithRazorPay = catchAsyncErrors(async (req, res, next) => {
    const { razorpayPaymentId, razorpayOrderId, razorpaySignature, currency } = req.body;

    if (!razorpayPaymentId) {
      return res.status(422).json({
        status: false,
        message: "Razorpay payment ID is required",
        data: {},
      });
    }
    if (!razorpayOrderId) {
      return res.status(422).json({
        status: false,
        message: "Razorpay order ID is required",
        data: {},
      });
    }
    // if (!razorpaySignature) {
    //   return res.status(422).json({
    //     status: false,
    //     message: "Razorpay signature is required",
    //     data: {},
    //   });
    // }

		// let encryptedString = razorpayOrderId + "|" + razorpayPaymentId;
		// let expectedSignature = crypto.createHmac(
		// 	"sha256",
		// 	razorpayConfig.mode === "TEST" ? razorpayConfig.testCred.key_secret : razorpayConfig.liveCred.key_secret
		// ).update(encryptedString.toString()).digest("hex");

		let existingTransaction = await super.getByCustomOptionsSingle(
			req,
			transactionModel,
			{
				paymentGatewayOrderId: razorpayOrderId,
			}
		);
    
		if (existingTransaction) {
			// Capture payment
			try {
        const captureResponse = await razorpay.payments.capture(
          razorpayPaymentId,
          existingTransaction.paidAmount,
          existingTransaction.paidCurrency
        );
        let fetchRazorpay = await razorpay.payments.fetch(razorpayPaymentId);
        
        if (fetchRazorpay.status !== "captured") {
          let transactionHistoryData = {
            userId: req.user._id,
            transactionId: existingTransaction._id,
            
            amount: parseFloat(existingTransaction.paidAmount) / 100,
            currency: currency,
  
            gatewayName: "Razorpay",
  
            type: "walletRecharge",
            remarks: "Wallet recharge via Razorpay failed or not captured yet..!!",
            
            isSuccess: false,
          };
          let transactionHistory = await super.create(res, transactionHistoryModel, transactionHistoryData);

          return res.status(400).json({
            status: false,
            message: "Payment not yet captured..!! Can't process further..!!",
            data: {},
          });
        }

        // Update transaction status
        await super.updateById(transactionModel, existingTransaction._id, {
          paidVia: "Razorpay",
          paymentStatus: "Paid",
        });

        // Log the transaction
        await super.create(res, transactionLogModel, {
          transactionId: existingTransaction._id,
          request: JSON.stringify(req.body),
          response: JSON.stringify(fetchRazorpay),
        });

        // Update or create wallet
        let checkWallet = await super.getByCustomOptionsSingle(
          req,
          walletModel,
          { 
            userId: req.user._id, 
            currency: currency,
          }
        );

        let amount = parseFloat(existingTransaction.paidAmount) / 100;
        if (checkWallet) {
          amount += parseFloat(checkWallet.amount.toString());
          await super.updateById(walletModel, checkWallet._id, {
						"amount": amount,
					});
        } else {
          await super.create(res, walletModel, {
            userId: req.user._id,
            amount: amount,
            currency: currency,
          });
        }
        let checkUpdatedWallet = await super.getByCustomOptionsSingle(
          req,
          walletModel,
          {
            userId: req.user._id,
            currency: currency,
          }
        );
        // Create wallet ledger entry
        await super.create(res, walletLedgerModel, {
          // walletId: checkWallet ? checkWallet._id : existingTransaction._id,
          walletId: checkWallet ? checkWallet._id : checkUpdatedWallet._id,
          amount: amount.toFixed(2),
          transactionType: "credit",
          gatewayName: "Razorpay",
          currentBalance: checkUpdatedWallet.amount.toFixed(2),
          remarks: `Wallet recharge of ${amount.toFixed(2)} is successful.`,
        });

        let transactionHistoryData = {
          userId: req.user._id,
          transactionId: existingTransaction._id,
          
          amount: parseFloat(existingTransaction.paidAmount) / 100,
          currency: currency,

          gatewayName: "Razorpay",

          type: "walletRecharge",
          remarks: "Wallet recharge via Razorpay successful.",
          
          isSuccess: true,
        };
        let transactionHistory = await super.create(res, transactionHistoryModel, transactionHistoryData);

        return res.status(200).json({
          status: true,
          message: "Wallet recharged Successfully!",
          data: {},
        });
      } catch (error) {
        // Handle errors
        let transactionHistoryData = {
          userId: req.user._id,
          transactionId: existingTransaction._id,
          
          amount: parseFloat(existingTransaction.paidAmount) / 100,
          currency: currency,

          gatewayName: "Razorpay",

          type: "walletRecharge",
          remarks: "Wallet recharge via Razorpay failed due to some error with Razorpay gateway or internal failure..!!",
          
          isSuccess: false,
        };
        let transactionHistory = await super.create(res, transactionHistoryModel, transactionHistoryData);

        return res.status(500).json({
          status: false,
          message: "Error processing payment",
          data: { error: error.message },
        });
      }
		} else {
      let transactionHistoryData = {
        userId: req.user._id,
        transactionId: existingTransaction._id,
        
        amount: parseFloat(existingTransaction.paidAmount) / 100,
        currency: currency,

        gatewayName: "Razorpay",

        type: "walletRecharge",
        remarks: "Wallet recharge via Razorpay failed as transaction not found probably due to incorrect Razorpay Order Id..!!",
        
        isSuccess: false,
      };
      let transactionHistory = await super.create(res, transactionHistoryModel, transactionHistoryData);
      
			return res.status(404).json({
				status: false,
				message: "Transaction not found",
				data: {},
			});
		}
  });

  // ====================================== RAZORPAY ======================================

  static getWalletValue = catchAsyncErrors(async (req, res, next) => {
    let { currency } = req.body;
    const data = await walletModel.findOne({ 
      userId: req.user._id,
      currency: currency,
    });
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: data,
    });
  });
}

module.exports = walletController;
