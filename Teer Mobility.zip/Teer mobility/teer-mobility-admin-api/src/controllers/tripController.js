const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/errorHandler");
const RequestHandler = require("../utils/RequestHandler");
const mongoose = require("mongoose");
const ObjectId = mongoose.Types.ObjectId;
const moment = require('moment-timezone');
const dateFns = require('date-fns');
const axios = require('axios');
const sendPushNotification = require("../helpers/sendPushNotification");
const GoogleApiKey = require("../config/index").GoogleApiKey;


const {
  calculateDistance,
  calculateDistanceInsTentApi,
  calculateTimeInKilometers,
  getRateChartCategory,
  dateFormatDDMMYYYY,
  dateFormatYYYYMMDD,
	dateFormat,
} = require("../utils/utilities");
const {
  vehicleCategoryDetails,
  vehicleModelDetails,
  tripStopDetails,
  tripPlanDetails,
  tripDetails,
} = require("../utils/common");
const {
  MSG_RECORD_STATUS_SUCCESS,
  MSG_RECORD_FETCH_SUCCESS,
} = require("../config/constants");
const requestHandler = new RequestHandler();

const routeMapModel = require("../models/routeMapModel");
const corporateModel = require("../models/corporateModel");
const tripPlanModel = require("../models/tripPlanModel");
const tripsModel = require("../models/tripsModel");
const rollModel = require("../models/rollModel");
const userModel = require("../models/userModel");
const userCorporateMappingCollection = require("../models/userCorporateMappingCollection");
const corporateUserModel = require("../models/corporateUserModel");
const tripStopModel = require("../models/tripStopModel");
const tripPassengerModel = require("../models/tripPassengerModel");
const savedRouteModel = require("../models/savedRouteModel");
const customerModel = require("../models/customerModel");
const driverModel = require("../models/driverModel");
const tripStatusLogModel = require("../models/tripStatusLogModel");
const driverFeedbackModel = require("../models/driverFeedbackModel");
const vehicleFeedbackmodel = require("../models/vehicleFeedbackmodel");
const notificationModel = require("../models/notificationModel");
const vehicleModel = require("../models/vehicleModel");

const { APPURL } = require("../config");

class TripController extends BaseController {
  constructor() {
    super();
  }

  static tripList = catchAsyncErrors(async (req, res, next) => {
		// let tripStatus = await tripsModel.updateMany(
		//   {}, 
		//   {
		//     $set: {
		//       "tripStatus": "Pending",
		//     }
		//   }
		// );

    let trips = [];

    let { text, fromDate, toDate, routeId, superId } = req.body;

    if (req.method == "POST") {
      let match = {
        // $and: [
        // 	{
        // 		$or: [
        // 			{
        // 				tripName: {
        // 					$regex: ".*" + text + ".*",
        // 					$options: "i",
        // 				},
        // 			},
        // 		],
        // 	}
        // ]
      };
      // if(countryCode != ''){
      // 	let country = await countryModel.findOne({ _id: countryCode });
      // 	match['countryCode'] = country._id;
      // }
      const aggregatorOpts = [
        {
          $addFields: {
            // tripName: "$tripName",
          },
        },
        {
          $match: match,
        },
        {
          $sort: { tripStartTime: 1 } // Sort by tripStartTime in ascending order
        }
      ];
      trips = await tripsModel.aggregate(aggregatorOpts).exec();

      await tripPlanModel.populate(trips, [
        {
          path: "tripPlanId",
          model: "tripPlanCollection",
          populate: [
            {
              path: "routeId",
              model: "routeMapCollection",
            },
            {
              path: "corporateId",
              model: "corporateCollection",
              populate: {
                path: "userId",
                model: "usersCollection",
              },
            },
            {
              path: "vendorId",
              model: "corporateCollection",
              populate: {
                path: "userId",
                model: "usersCollection",
              },
            },
          ],
        },
        {
          path: "driverId",
          model: "driverCollection",
          populate: {
            path: "userId",
            model: "usersCollection",
            populate: {
              path: "roleId",
              model: "roleCollection",
            },
          },
        },
      ]);
      await routeMapModel.populate(trips, [
        {
          path: "tripPlanId.routeId.routeStops.stopId",
          model: "tripStopCollection",
        },
      ]);
			
			let customFilteredTrips = await Promise.all(
				trips.map(async (trip) => {
					if (routeId) {
						if (trip?.tripPlanId?.routeId?._id.toString() == routeId.toString()) {
							return trip;
						} else {
							return null;
						}
					} else {
						return trip;
					}
				})
			);
			
			customFilteredTrips = customFilteredTrips.filter(trip => trip !== null)
			trips = customFilteredTrips;

      let super_admin = await rollModel.findOne({ name: "Super Admin" });
      let superUser = await userModel.findOne({ roleId: super_admin._id.toString() });

      let admin_userRole = await rollModel.findOne({ name: "Admin User" });
      let adminUser = await userModel.findOne({ roleId: admin_userRole._id.toString() });

      let filteredTripsUserWise = [];
      if(superUser._id.toString() == req.user._id) {
        filteredTripsUserWise = trips;
      } else if(adminUser._id.toString() == req.user._id){
        filteredTripsUserWise = trips;
      }
      else {
        filteredTripsUserWise = trips.filter((trip) => {
          if (trip?.tripPlanId?.vendorId?.userId?._id == req.user._id) { 
						// logged as vendor ======
            return trip;
          } else if(trip?.tripPlanId?.corporateId?.userId?._id == req.user._id){
						// logged as corporate/company/school ======
            return trip;
					}
        });
      }

      let bookings = await tripPassengerModel.find({
        createdAt: {
          $gte: new Date(fromDate)
        },
        isCancelled: false,
      }).populate([
        {
          path: "userId",
          model: "usersCollection",
        },
      ]);

      let alltrips = [];
      while (fromDate <= toDate) {
        var trps = [];
        if (filteredTripsUserWise.length > 0) {
          filteredTripsUserWise.forEach(async (trip, index) => {
            if (dateFormatYYYYMMDD(trip.tripDate) == fromDate) {
              trip["bookings"] = [];
              bookings.forEach((elem) => {
                if (elem.tripId.toString() == trip._id.toString()) {
                  trip["bookings"].push(elem);
                }
              });
              trps.push(trip);
            }
            if (index == filteredTripsUserWise.length - 1) {
              alltrips.push({
                date: fromDate,
                trips: trps,
              });

              fromDate = new Date(fromDate);
              fromDate.setDate(fromDate.getDate() + 1);
              fromDate = dateFormatYYYYMMDD(new Date(fromDate));

              if (fromDate > toDate) {
                return requestHandler.sendSuccess(
                  res,
                  "Successful"
                )({
                  data: alltrips,
                  // data: tripPlanDetails(trips),
                });
              }
            }
          });
        } else {
          alltrips.push({
            date: fromDate,
            trips: [],
          });
          fromDate = new Date(fromDate);
          fromDate.setDate(fromDate.getDate() + 1);
          fromDate = dateFormatYYYYMMDD(new Date(fromDate));

          if (fromDate > toDate) {
            return requestHandler.sendSuccess(
              res,
              "Successful"
            )({
              // data: tripPlanDetails(trips),
              data: alltrips,
            });
          }
        }
      }
    } else {
      // ======= for dropdown ===========
      trips = await super.getList(req, tripsModel, "");
      trips.sort((a, b) => new Date(a.tripDate) - new Date(b.tripDate));
      return requestHandler.sendSuccess(
        res,
        "Successful"
      )({
        data: trips,
        // data: tripPlanDetails(trips),
      });
    }
  });

  static tripListTabularView = catchAsyncErrors(async (req, res, next) => {
    let totalUnfilteredTrips = [];
    let totalTrips = [];
    let trips = [];

    let totalCount = 0;
		let totalPages= 0;
		let page = 0;
		let limit = 0;
		let skip = 0;

    // Pagination parameters ===========
		page = req.body.pageNo ? parseInt(req.body.pageNo) : 1; // Current page number
		// limit = req.body.documentPerPage ? parseInt(req.body.documentPerPage) : 3; // Number of documents per page
		limit = 30; // Number of documents per page
		skip = (page - 1) * limit; // Number of documents to skip
		// Pagination parameters ===========

    let { text, fromDate, toDate, countryCode, corporateId, routeId, tripStatus, accessibility, isOnDemand, timeRanges, type, tripType, } = req.body;
    
    if (req.method == "POST") {
      let match = {
        $and: [
        	{
        		$or: [
        			{
        				// tripName: {
        				// 	$regex: ".*" + text + ".*",
        				// 	$options: "i",
        				// },
        			},
        		],
        	}
        ]
      };
      // if(countryCode != ''){
      // 	let country = await countryModel.findOne({ _id: countryCode });
      // 	match['countryCode'] = country._id;
      // }
      if (fromDate && toDate) {
        match.tripDate = {
          $gte: new Date(fromDate),
          $lte: new Date(toDate)
        };
      } else if (fromDate) {
        match.tripDate = {
          $gte: new Date(fromDate)
        };
      } else if (toDate) {
        match.tripDate = {
          $lte: new Date(toDate)
        };
      } 
      if (tripStatus) {
        match.tripStatus = tripStatus;
      }
      const aggregatorOpts = [
        {
          $addFields: {
            // tripName: "$tripName",
            tripDate: "$tripDate",
            tripStatus: "$tripStatus",
          },
        },
        {
          $match: match,
        },
        {
          $sort: { tripDate: -1 , tripStartTime: 1 }// Sort by tripStartTime in ascending order
        }
      ];
      
      totalUnfilteredTrips = await tripsModel.aggregate(aggregatorOpts).exec();
      // trips = await tripsModel.aggregate(aggregatorOpts).skip(skip).limit(limit).exec();
      // trips = await tripsModel.aggregate(aggregatorOpts).exec();

      await tripPlanModel.populate(totalUnfilteredTrips, [
        {
          path: "tripPlanId",
          model: "tripPlanCollection",
          populate: [
            {
              path: "routeId",
              model: "routeMapCollection",
            },
            {
              path: "corporateId",
              model: "corporateCollection",
              populate: {
                path: "userId",
                model: "usersCollection",
              },
            },
            {
              path: "vendorId",
              model: "corporateCollection",
              populate: {
                path: "userId",
                model: "usersCollection",
              },
            },
          ],
        },
        {
          path: "driverId",
          model: "driverCollection",
          populate: {
            path: "userId",
            model: "usersCollection",
            populate: {
              path: "roleId",
              model: "roleCollection",
            },
          },
        },
      ]);
      await routeMapModel.populate(totalUnfilteredTrips, [
        {
          path: "tripPlanId.routeId.routeStops.stopId",
          model: "tripStopCollection",
        },
      ]);
      await vehicleModel.populate(totalUnfilteredTrips, [
        {
          path: "vehicleId",
          model: "vehicleCollection",
          populate: [
            {
              path: "modelId",
              model: "vehicleModelCollection",
              populate: [
                {
                  path: "type",
                  model: "vehicleCategoriesCollection",
                },
              ]
            },
          ]
        },
      ]);

      let tripIdsArr = [];
      totalUnfilteredTrips.forEach((trip) => {
        let tripId = trip?._id;
        // ------------ add custom filters here ------------

        let shouldAddTrip = true; // assume the trip should be added unless it fails a condition

        if (corporateId) {
          if (trip?.tripPlanId?.corporateId?._id.toString() !== corporateId.toString()) {
            shouldAddTrip = false; // Condition failed
          }
        }

        if (routeId) {
          if (trip?.tripPlanId?.routeId?._id.toString() !== routeId.toString()) {
            shouldAddTrip = false; // Condition failed
          }
        }

        if (accessibility) {          
          if (trip?.tripPlanId?.accessibility != accessibility) {
            shouldAddTrip = false; // Condition failed
          }
        }

        if (tripType) {
          if (trip?.tripPlanId?.tripType.toString() !== tripType.toString()) {
            shouldAddTrip = false; // Condition failed
          }
        }

        if (isOnDemand) {
          let onDemandStatus = isOnDemand === "yes" ? true : isOnDemand === "no" ? false : undefined;
          if (trip?.tripPlanId?.isOnDemand !== onDemandStatus) {
            shouldAddTrip = false; // Condition failed
          }
        }

        if (timeRanges) {
          let timeRangeMatch = false;
          if (Array.isArray(timeRanges)) {
            timeRanges.forEach((timeRange) => {
              let [startTime, endTime] = timeRange.split('-');
              if (trip?.tripStartTime === startTime && trip?.tripEndTime === endTime) {
                timeRangeMatch = true;
              }
            });
          } else {
            let [startTime, endTime] = timeRanges[0].split('-');
            if (trip?.tripStartTime === startTime && trip?.tripEndTime === endTime) {
              timeRangeMatch = true;
            }
          }

          if (!timeRangeMatch) {
            shouldAddTrip = false; // Condition failed
          }
        }

        if (type) {
          if (trip?.vehicleId?.modelId?.type?._id.toString() !== type.toString()) {
            shouldAddTrip = false; // Condition failed
          }
        }

        // after applying all conditions, check if we should add the trip
        if (shouldAddTrip) {
          if (!tripIdsArr.includes(tripId)) {
            tripIdsArr.push(tripId);
          }
        } else {
          // remove the tripId if it doesn't match the filters
          const index = tripIdsArr.indexOf(tripId);
          if (index !== -1) {
            tripIdsArr.splice(index, 1);
          }
        }
      });

      totalTrips = await tripsModel.find({
        _id: {
          $in: tripIdsArr
        },
      }).exec();
      trips = await tripsModel.find({
        _id: {
          $in: tripIdsArr
        },
      }).skip(skip).limit(limit).sort({ tripDate: -1, tripStartTime: 1 }).exec();

      await vehicleModel.populate(trips, [
        {
          path: "vehicleId",
          model: "vehicleCollection",
          populate: [
            {
              path: "modelId",
              model: "vehicleModelCollection",
              populate: [
                {
                  path: "type",
                  model: "vehicleCategoriesCollection",
                },
              ]
            },
          ]
        },
      ]);
      await tripPlanModel.populate(trips, [
        {
          path: "tripPlanId",
          model: "tripPlanCollection",
          populate: [
            {
              path: "routeId",
              model: "routeMapCollection",
            },
            {
              path: "corporateId",
              model: "corporateCollection",
              populate: {
                path: "userId",
                model: "usersCollection",
              },
            },
            {
              path: "vendorId",
              model: "corporateCollection",
              populate: {
                path: "userId",
                model: "usersCollection",
              },
            },
          ],
        },
        {
          path: "driverId",
          model: "driverCollection",
          populate: {
            path: "userId",
            model: "usersCollection",
            populate: {
              path: "roleId",
              model: "roleCollection",
            },
          },
        },
      ]);
      await routeMapModel.populate(trips, [
        {
          path: "tripPlanId.routeId.routeStops.stopId",
          model: "tripStopCollection",
        },
      ]);

      totalCount = totalTrips.length;
      totalPages= Math.ceil(totalCount/limit);

      if(trips.length > 0){
        return res.status(200).json({
          status: true,
          message: "Trips found",
          data: {
            data: tripDetails(trips),
            pagination: {
              total: totalCount,
              totalPages: totalPages,
              rowsPerPage: limit,
              currentPage: page,
              hasNextPage: page < totalPages,
              hasPrevPage: page > 1
            },
          },
        });
      } else {
        return res.status(200).json({
          status: true,
          message: "No data found",
          data: {
            data: [],
            pagination: {
              total: totalCount,
              totalPages: totalPages,
              rowsPerPage: limit,
              currentPage: page,
              hasNextPage: page < totalPages,
              hasPrevPage: page > 1
            },
          },
        });
      }
    } else {
      // get method ====
    }
  });

  static tripListForApp = catchAsyncErrors(async (req, res, next) => {
		
    let trips = [];
    let { superId } = req.body;
    if (req.method == "POST") {
      let momentKolkata = moment().tz('Asia/Kolkata');
      let currentDate = momentKolkata.format('YYYY-MM-DD');
      let match = {
        $and: [
        	{
            tripDate: new Date(currentDate)
          },
          {
        		// $or: [
        			// {
        			// 	tripName: {
        			// 		$regex: ".*" + text + ".*",
        			// 		$options: "i",
        			// 	},
        			// },
        		// ],
        	},
        ]
      };
      // if(countryCode != ''){
      // 	let country = await countryModel.findOne({ _id: countryCode });
      // 	match['countryCode'] = country._id;
      // }
      const aggregatorOpts = [
        {
          $addFields: {
            tripDate: "$tripDate",
            // tripName: "$tripName",
          },
        },
        {
          $match: match,
        },
      ];
      trips = await tripsModel.aggregate(aggregatorOpts).exec();

      await tripPlanModel.populate(trips, [
        {
          path: "tripPlanId",
          model: "tripPlanCollection",
          populate: [
            {
              path: "routeId",
              model: "routeMapCollection",
            },
            {
              path: "corporateId",
              model: "corporateCollection",
              populate: {
                path: "userId",
                model: "usersCollection",
              },
            },
            {
              path: "vendorId",
              model: "corporateCollection",
              populate: {
                path: "userId",
                model: "usersCollection",
              },
            },
          ],
        },
        {
          path: "driverId",
          model: "driverCollection",
          populate: {
            path: "userId",
            model: "usersCollection",
            populate: {
              path: "roleId",
              model: "roleCollection",
            },
          },
        },
        {
          path: "vehicleId",
          model: "vehicleCollection",
          populate: {
            path: "modelId",
            model: "vehicleModelCollection",
            populate: {
              path: "type",
              model: "vehicleCategoriesCollection",
            },
          },
        },
      ]);
      await routeMapModel.populate(trips, [
        {
          path: "tripPlanId.routeId.routeStops.stopId",
          model: "tripStopCollection",
        },
      ]);

      let tripsWithDriverVehicleImages = await Promise.all(trips.map(async (trip)=>{
        // console.log("=========================")
        // console.log(APPURL + 'uploads/vehicles/' + trip?.vehicleId?.imagePath)
        // console.log(APPURL + 'uploads/userImages/' + trip?.driverId?.userId?.profileImage)
        if(trip.driverId){
          trip['driverImage'] = APPURL + 'uploads/userImages/' + trip?.driverId?.userId?.profileImage;
        }
        if(trip.vehicleId){
          trip['vehicleImage'] = APPURL + 'uploads/vehicles/' + trip?.vehicleId?.imagePath;
        }
        return trip;
      }));
      
      let filteredTripsUserWise = [];
      filteredTripsUserWise = tripsWithDriverVehicleImages;

      if (superId) {
        filteredTripsUserWise = trips;
      } else {
        filteredTripsUserWise = trips.filter((trip) => {
          if (trip?.tripPlanId?.vendorId?.userId?._id == req.user._id) { 
						// logged as vendor ======
            return trip;
          } else if(trip?.tripPlanId?.corporateId?.userId?._id == req.user._id){
						// logged as corporate/company/school ======
            return trip;
					}
        });
      }

      let bookings = await tripPassengerModel.find(
        // { 
        //   createdAt: { 
        //     $gte: new Date(fromDate) 
        //   } 
        // }
      ).populate([
        {
          path: "userId",
          model: "usersCollection",
        },
      ]);

      let tripsWithDriverAndVehicleRatings = await Promise.all(filteredTripsUserWise.map(async (trip)=>{
        // console.log("trip.driverId =========>");
        // console.log(trip.driverId);
        // ===== rating ========
        let averageDriverRating = '';
        let averageVehicleRating = '';
        if(trip.driverId){
          let driverRating = await driverFeedbackModel.aggregate([
            {
              $match: {
                driverId: trip.driverId.userId._id, 
                isDeleted: false,
              }
            },
            {
              $group: {
                _id: "$driverId",
                averageRating: { $avg: "$rating" } // Calculate average of ratings
              }
            }
          ]);
          // Result will be an array with one element containing _id and averageRating fields ===
          if (driverRating.length > 0) {
            averageDriverRating = driverRating[0].averageRating;
          }
        }
        trip['averageDriverRating'] = averageDriverRating;
        if(trip.vehicleId){
          let vehicleRating = await vehicleFeedbackmodel.aggregate([
            {
              $match: {
                vehicleId: trip.vehicleId._id, 
                isDeleted: false,
              }
            },
            {
              $group: {
                _id: "$vehicleId",
                averageRating: { $avg: "$rating" } // Calculate average of ratings
              }
            }
          ]);
          // Result will be an array with one element containing _id and averageRating fields ===
          if (vehicleRating.length > 0) {
            averageVehicleRating = vehicleRating[0].averageRating;
          }
        }
        trip['averageVehicleRating'] = averageVehicleRating;
        return trip;
      }));
      filteredTripsUserWise = tripsWithDriverAndVehicleRatings;

      filteredTripsUserWise.forEach(async (trip, index) => {
        trip["bookings"] = [];
        bookings.forEach((booking) => {
          if (booking.tripId.toString() == trip._id.toString()) {
            trip["bookings"].push(booking);
          }
        });
      });

      let ongoingTrips = [];
      let history = [];
      let upcoming = [];
      filteredTripsUserWise.forEach(async (trip, index) => {
        let startTime = new Date(dateFormat(trip.tripDate)+" "+trip.tripStartTime);
        let endTime = new Date(dateFormat(trip.tripDate)+" "+trip.tripEndTime);
        let currentTime = new Date();

        // ======= Default ==========
        let colourStatus = "blue"; // "grey"=>Past, "blue"=>Present, "yellow"=>Future
        let endStatus = false; // trip ended or not
        // ======= Default ==========

        if(
          (endTime < currentTime)
          && (startTime < currentTime)
        ){
          // ending before currentTime -> history ===========
          colourStatus = 'grey';
          endStatus = true;

          trip['colourStatus'] = colourStatus;
          trip['endStatus'] = endStatus;

          history.push(trip);

        } else if(
          (startTime > currentTime)
          && (endTime > currentTime)
        ){
          // starting later -> upcoming ===========
          colourStatus = 'yellow';

          trip['colourStatus'] = colourStatus;
          trip['endStatus'] = endStatus;

          upcoming.push(trip);

        } else if(
          (startTime <= currentTime) 
          && (endTime > currentTime)
        ){
          // currentTime between start  and endtime -> ongoing ===========
          trip['colourStatus'] = colourStatus;
          trip['endStatus'] = endStatus;

          ongoingTrips.push(trip);

        }
      });

      if(filteredTripsUserWise.length > 0){
        return res.status(200).json({
          status: true,
          message: "Success",
          data: {
            ongoingTrips: ongoingTrips,
            upcoming: upcoming,
            history: history,
          }
        });
      } else { 
        return res.status(200).json({
          status: false,
          message: "No trips found",
          data: {
            ongoingTrips: [],
            history: []
          }
        });

      }
    } else {
      // ======= for dropdown ===========
      trips = await super.getList(req, tripsModel, "");
      trips.sort((a, b) => new Date(a.tripDate) - new Date(b.tripDate));
      return requestHandler.sendSuccess(
        res,
        "Successful"
      )({
        data: trips,
        // data: tripPlanDetails(trips),
      });
    }
  });

  // static tripAddUpdate = catchAsyncErrors(async (req, res, next) => {
  //   let { tripName, tripDescription, routeId, vendorId, tripType, dayName, startTime, endTime, _id } = req.body;
  //   if (!Array.isArray(dayName)) {
  //     dayName = [dayName];
  //   }

  //   if (!Array.isArray(startTime)) {
  //     startTime = [startTime];
  //   }
  //   let filteredStartTime = startTime.filter(time => time !== '');

  //   if (!Array.isArray(endTime)) {
  //     endTime = [endTime];
  //   }
  //   let filteredendTime = endTime.filter(time => time !== '');

  //   // console.log(dayName);
  //   // console.log(filteredStartTime);
  //   // console.log(filteredendTime);
  //   //  return;
  //   // ====== validationFlag decides whether to submit or not =====
  //   let validationFlag = false;
  //   // ====== validationFlag decides whether to submit or not =====
  //   let scheduleArr = []
  //   if (
  //     filteredStartTime.length > 0 &&
  //     filteredendTime.length > 0 &&
  //     filteredStartTime.length == filteredendTime.length
  //   ) {
  //     validationFlag = true;

  //     if (tripType == "Daily") {
  //       for (let i = 0; i < filteredStartTime.length; i++) {
  //         let obj = {
  //           startTime: filteredStartTime[i],
  //           endTime: filteredendTime[i],
  //         }

  //         scheduleArr.push(obj)
  //       }
  //     } else if (tripType == "Customized") {
  //       for (let i = 0; i < dayName.length; i++) {
  //         let obj = {
  //           dayName: dayName[i],
  //           startTime: filteredStartTime[i],
  //           endTime: filteredendTime[i],
  //         }

  //         scheduleArr.push(obj)
  //       }
  //     }
  //   }

  //   if (validationFlag == true) {
  //     let data = {
  //       tripName: tripName,
  //       tripDescription: tripDescription,
  //       routeId: routeId,
  //       vendorId: vendorId,
  //       tripType: tripType,

  //       schedule: scheduleArr,
  //     };

  //     let updated =
  //       _id && _id != null && _id != ""
  //         ? await super.updateById(tripPlanModel, _id.toString(), data)
  //         : await super.create(res, tripPlanModel, data);

  //     return requestHandler.sendSuccess(
  //       res,
  //       "Successful"
  //     )({
  //       data: updated,
  //     });
  //   } else {
  //     return res.status(400).json({
  //       status: false,
  //       message: "Invalid data..!!",
  //       data: '',
  //     });
  //   }
  // });

  // static getTripDetail = catchAsyncErrors(async (req, res, next) => {
  //   const { id } = req.body;
  //   const asset = await tripPlanModel.findOne({ _id: id });
  //   return requestHandler.sendSuccess(
  //     res,
  //     "Successful"
  //   )({
  //     data: asset,
  //   });
  // });

  // static deleteTrip = catchAsyncErrors(async (req, res, next) => {
  //   const { id } = req.body;
  //   const updated = await super.deleteById(tripPlanModel, id);
  //   return requestHandler.sendSuccess(
  //     res,
  //     "Successful"
  //   )({
  //     data: updated,
  //   });
  // });

  static tripRequirements = catchAsyncErrors(async (req, res, next) => {
    let { id } = req.body;
    let trip = await tripsModel.findOne({ _id: id }).populate("tripPlanId");
    let route = await routeMapModel.findOne({ _id: trip.tripPlanId.routeId });
    let stops = [];
    route.routeStops.forEach(async (stop) => {
      let stopp = await tripStopModel.findOne({
        _id: stop.stopId,
      });

      stops.push(
        {
          order: stop.order, 
          stop: stopp,
        }
      );
    });

    let corporateUsers = await corporateUserModel.find({
			corporateId: trip.tripPlanId.corporateId.toString(),
		}).populate("userId");

    // ======= employees ========
		let employees = await customerModel.aggregate([
      {
        $unwind: "$corporates",
      },
      {
        $match: {
          "corporates.corporateId": trip.tripPlanId.corporateId,
        },
      },
    ]);
		await userModel.populate(
			employees,
			[
				{
					"path": "userId",
					"model": "usersCollection"
				}
			]
		);
    // ====== employees ========

    let studentsIdArr = [];
    employees.forEach((employee)=>{
      // console.log("employee.corporates.studentId ===>");
      // console.log(employee.corporates.studentId.toString());
      if(employee.corporates.studentId){
        studentsIdArr.push(employee?.corporates?.studentId.toString());
      }
    });
    let eligibleStudentsOfTrip = await userModel.find({
      _id: {
        $in: studentsIdArr
      }
    });
    let corporateOfTrip = await corporateModel.findOne({
      _id: trip.tripPlanId.corporateId
    }).populate([
      {
        "path": "userId",
        "model": "usersCollection",
        "populate": {
          "path": "roleId",
          "model": "roleCollection",
        }
      },
    ]);
    // console.log(corporateOfTrip.userId.roleId.name);
    return requestHandler.sendSuccess(res, "Successful")({
      data: {
        stops: stops.sort((a, b) => a.order - b.order),
        corporateUsers: corporateUsers,
        employees: employees,
        eligibleStudentsOfTrip: eligibleStudentsOfTrip,
        trip: trip,
        tripFor: corporateOfTrip.userId.roleId.name
      },
    });
  });

  // ==================================================
  // ========= booking being created from WEB =========
  // ==================================================
  // ====================================================================================
  // global search with "static bookingCreate =" to jump to booking from APP function
  // ====================================================================================
  static tripPassengerUpdate = catchAsyncErrors(async (req, res, next) => {
    let { serviceId, tripId, userId, pickupStopId, dropStopId, _id } = req.body;
    
    if(!serviceId){
      return res.status(422).json({
        status: false,
        message: "serviceId not present in payload."
      });
    }

    // Get the current time in "Asia/Kolkata" time zone =======
    let momentKolkata = moment().tz('Asia/Kolkata');
    let currentDate = momentKolkata.format('YYYY-MM-DD');
	  let currentDay = momentKolkata.format('dddd');
    let currentTime = momentKolkata.format('HH:mm');
		// Get the current time in "Asia/Kolkata" time zone =======

    let otp = Math.floor(1000 + Math.random() * 9000);
    let data = {
      userId: userId,
      serviceId: serviceId,
      tripId: tripId,
      pickupStopId: pickupStopId,
      dropStopId: dropStopId,
      bookingDate: currentDate,
      otp: otp,
    };

    let booking = await tripPassengerModel.findOne({
      tripId: tripId,
      userId: userId,
    });

    // ====== check whether passenger's other trip time clashes with the current one ======
    let timeClashedFlag = false;
    let allBookingsForParticularUserForTheDay = await tripPassengerModel.find({
      userId: userId,
      serviceId: serviceId,
      bookingDate: currentDate,
    }).populate([
      {
        "path": "tripId",
        "model": "tripsCollection",
      },
    ]);
    // console.log("allBookingsForParticularUserForTheDay ===>");
    // console.log(allBookingsForParticularUserForTheDay);
    
    if(allBookingsForParticularUserForTheDay){
      let tripInWhichPassengerAssignIsBeingAttempted = await tripsModel.findOne({
        _id: tripId,
      });

      // ====== these two times should not clash with any existing trip timing for the passenger ======
      let startTimeOfTripInWhichPassengerAssignIsBeingAttempted = tripInWhichPassengerAssignIsBeingAttempted.tripStartTime

      let NewStartTime = currentDate + startTimeOfTripInWhichPassengerAssignIsBeingAttempted;
      let momentNewStartTime = moment(NewStartTime, 'YYYY-MM-DD HH:mm');
      
      let endTimeOfTripInWhichPassengerAssignIsBeingAttempted = tripInWhichPassengerAssignIsBeingAttempted.tripEndTime
      
      let NewEndTime = currentDate + endTimeOfTripInWhichPassengerAssignIsBeingAttempted;
      let momentNewEndTime = moment(NewEndTime, 'YYYY-MM-DD HH:mm');
      // ====== these two times should not clash with any existing trip timing for the passenger ======
      
      // ============= Clash check and flag updating =============
      allBookingsForParticularUserForTheDay.forEach((booking)=>{
        let ExistingStartTime = currentDate + booking.tripId.tripStartTime;
        let momentExistingStartTime = moment(ExistingStartTime, 'YYYY-MM-DD HH:mm');
        let ExistingEndTime = currentDate + booking.tripId.tripEndTime;
        let momentExistingEndTime = moment(ExistingEndTime, 'YYYY-MM-DD HH:mm');
        
        // console.log(`NewStartTime => ${momentNewStartTime}`);
        // console.log(`NewEndTime => ${momentNewEndTime}`);
        
        // console.log(`ExistingStartTime => ${momentExistingStartTime}`);
        // console.log(`ExistingEndTime => ${momentExistingEndTime}`);

        console.assert(((momentNewStartTime > ExistingEndTime) || (momentNewStartTime > ExistingStartTime)), "true1SearchMeInCodeBase");
        console.assert(((momentNewEndTime > momentExistingEndTime) || (momentNewEndTime > ExistingStartTime)), "true2SearchMeInCodeBase");
        
        if(
          ((momentNewStartTime > momentExistingEndTime) || (momentNewStartTime > ExistingStartTime))
          && 
          ((momentNewEndTime > momentExistingEndTime) || (momentNewEndTime > ExistingStartTime))
        ){
          // ==== should let book ====
          timeClashedFlag = false;
          // ==== should let book ====
        } else {
          // ========= TIME CLASHING =========
          // ==== should NOT let book ====
          timeClashedFlag = true;
          // ==== should NOT let book ====
          // ========= TIME CLASHING =========
        }
      });

      // console.log(`final status of timeClashedFlag ===> ${timeClashedFlag}`);
      // ============= Clash check and flag updating =============

    }
    // ====== check whether passenger's other trip time clashes with the current one ======

    if (_id && _id != null && _id != "") {
      // ======= updating =======
      let updated = await super.updateById(
        tripPassengerModel,
        _id.toString(),
        data
      );
      let tripPassenger = await tripPassengerModel.findOne({
        userId: updated.userId,
        tripId: updated.tripId,
      }).populate([
        {
          "path": "userId",
          "model": "usersCollection",
          "populate": {
            "path": "roleId",
            "model": "roleCollection",
          }
        },
        {
          "path": "tripId",
          "model": "tripsCollection",
          "populate": {
            "path": "tripPlanId",
            "model": "tripPlanCollection",
            "populate": {
              "path": "routeId",
              "model": "routeMapCollection",
            }
          }
        },
      ]);
      if(tripPassenger){
        // =============== send notification to the customer ===============
        // ========== inApp Notification ===========
        let notiData = {
          userId: tripPassenger.userId._id,
          tripId: tripPassenger.tripId._id,

          title: `Trip Confirmed`,
          body: `Dear ${tripPassenger.userId.firstName}, your trip is confirmed for ${tripPassenger.tripId.tripPlanId.routeId.routeName} route at ${tripPassenger.tripId.tripDate} on ${tripPassenger.tripId.tripStartTime}. We will share the vehicle details soon.`,
        };
        let inAppNotification = await super.create(res, notificationModel, notiData);
        // ========== inApp Notification ===========
        try {
          // let user = await userModel.findOne({ _id: req.user._id });
          // console.log("user.fcmToken ====>", user.fcmToken);
          let fcmToken = "";
          fcmToken = tripPassenger.userId.fcmToken;

          if(tripPassenger.userId.roleId.name == "Student"){
            // ===== if student, noti should go to parent =====
            let parentCustomer = await customerModel.aggregate([
              {
                $unwind: "$corporates",
              },
              {
                $match: {
                  "corporates.studentId": tripPassenger.userId._id,
                },
              },
            ]);
            let user = await userModel.findOne({
              _id: parentCustomer[0].userId
            });
            fcmToken = user.fcmToken;
            // ===== if student, noti should go to parent =====

          } else {
            // ===== if not student, noti should go to the respective user itself =====
            fcmToken = tripPassenger.userId.fcmToken;
            // ===== if not student, noti should go to the respective user itself =====
          }
          if (fcmToken) {
            // ========== Push Notification ===========
            let messages = {
              title: "Trip Confirmed",
              body: JSON.stringify({
                "tripId": tripPassenger.tripId._id.toString(),
                "msg": "Dear "+tripPassenger.userId.firstName+", your trip is confirmed for "+tripPassenger.tripId.tripPlanId.routeId.routeName+" route at "+tripPassenger.tripId.tripDate+" on "+tripPassenger.tripId.tripStartTime+". We will share the vehicle details soon",
                "type": "Show"
              }),
            };
            await sendPushNotification(tripPassenger.userId.fcmToken, messages, "android");
          }

        } catch (error) {
          console.error("Error sending notification:", error.message);
          // Handle or propagate the error as needed
        }
        // =============== send notification to the customer ENDS ===============

        return requestHandler.sendSuccess(
          res,
          "Successful"
        )({
          data: updated,
        });
      }
      return requestHandler.sendSuccess(
        res,
        "Successful"
      )({
        data: updated,
      });
    } else {
      if (
        !booking
        && timeClashedFlag == false
      ) {
        // ==== creating ======
        let updated = await super.create(res, tripPassengerModel, data);
        let tripPassenger = await tripPassengerModel.findOne({
          userId: updated.userId,
          tripId: updated.tripId,
        }).populate([
          {
            "path": "userId",
            "model": "usersCollection",
            "populate": {
              "path": "roleId",
              "model": "roleCollection",
            }
          },
          {
            "path": "tripId",
            "model": "tripsCollection",
            "populate": {
              "path": "tripPlanId",
              "model": "tripPlanCollection",
              "populate": [
                {
                  "path": "routeId",
                  "model": "routeMapCollection",
                },
                {
                  "path": "corporateId",
                  "model": "corporateCollection",
                },
              ]
            }
          },
        ]);
        if(updated){
          let selectedTrip = await tripsModel.findOne({
            _id: tripId,
          });
          if(selectedTrip.driverId){
            let driver = await driverModel.findOne({
              _id: selectedTrip.driverId
            }).populate([
              {
                "path": "userId",
                "model": "usersCollection"
              },
            ]);
            
            // ========== inApp Notification ===========
            let notiData = {
              userId: driver.userId._id,
              tripId: tripId,

              title: `New Passenger Added.`,
              body: `Dear ${driver.userId.firstName}, new passenger: ${tripPassenger.userId.firstName} (${tripPassenger.userId.phone}) has been assigned for ${tripPassenger.tripId.tripPlanId.routeId.routeName} route. - Regards ${tripPassenger.tripId.tripPlanId.corporateId.name} (${tripPassenger.tripId.tripPlanId.corporateId.phoneNumber}).`,
            };
            let inAppNotification = await super.create(res, notificationModel, notiData);
            // ========== inApp Notification ===========
            if(driver.userId.fcmToken){
              // send noti to driver ===
              // ========== push Notification ===========
              try {
                let fcmToken = "";
                fcmToken = driver.userId.fcmToken;
                if (fcmToken) {
                  // ========== Push Notification ===========
                  let messages = {
                    title: `New Passenger Added.`,
                    body: JSON.stringify({
                      "tripId": tripPassenger.tripId._id.toString(),
                      "msg": `Dear ${driver.userId.firstName}, new passenger: ${tripPassenger.userId.firstName} (${tripPassenger.userId.phone}) has been assigned for ${tripPassenger.tripId.tripPlanId.routeId.routeName} route. - Regards ${tripPassenger.tripId.tripPlanId.corporateId.name} (${tripPassenger.tripId.tripPlanId.corporateId.phoneNumber}).`,
                      "type": "Show"
                    }),
                  };
                  await sendPushNotification(fcmToken, messages, "android");
                }

              } catch (error) {
                console.error("Error sending notification:", error.message);
                // Handle or propagate the error as needed
              }
              // =============== send notification to the driver ===============
            }
          }
        }
        if(tripPassenger){
          // =============== send notification to the customer ===============
          // ========== inApp Notification ===========
          let notiData = {
            userId: tripPassenger.userId._id,
            tripId: tripPassenger.tripId._id,

            title: `Trip Confirmed`,
            body: `Dear ${tripPassenger.userId.firstName}, your trip is confirmed for ${tripPassenger.tripId.tripPlanId.routeId.routeName} route at ${tripPassenger.tripId.tripDate} on ${tripPassenger.tripId.tripStartTime}. We will share the vehicle details soon.`,
          };
          let inAppNotification = await super.create(res, notificationModel, notiData);
          // ========== inApp Notification ===========
          try {
            // let user = await userModel.findOne({ _id: req.user._id });
            // console.log("user.fcmToken ====>", user.fcmToken);
            let fcmToken = "";
            fcmToken = tripPassenger.userId.fcmToken;

            if(tripPassenger.userId.roleId.name == "Student"){
              // ===== if student, noti should go to parent =====
              let parentCustomer = await customerModel.aggregate([
                {
                  $unwind: "$corporates",
                },
                {
                  $match: {
                    "corporates.studentId": tripPassenger.userId._id,
                  },
                },
              ]);
              let user = await userModel.findOne({
                _id: parentCustomer[0].userId
              });
              fcmToken = user.fcmToken;
              // ===== if student, noti should go to parent =====

            } else {
              // ===== if not student, noti should go to the respective user itself =====
              fcmToken = tripPassenger.userId.fcmToken;
              // ===== if not student, noti should go to the respective user itself =====
            }
            if (fcmToken) {
              // ========== Push Notification ===========
              let messages = {
                title: "Trip Confirmed",
                body: JSON.stringify({
                  "tripId": tripPassenger.tripId._id.toString(),
                  "msg": "Dear "+tripPassenger.userId.firstName+", your trip is confirmed for "+tripPassenger.tripId.tripPlanId.routeId.routeName+" route at "+tripPassenger.tripId.tripDate+" on "+tripPassenger.tripId.tripStartTime+". We will share the vehicle details soon",
                  "type": "Show"
                }),
              };
              await sendPushNotification(fcmToken, messages, "android");
            }

          } catch (error) {
            console.error("Error sending notification:", error.message);
            // Handle or propagate the error as needed
          }
          // =============== send notification to the customer ===============
          return requestHandler.sendSuccess(
            res,
            "Successful"
          )({
            data: updated,
          });
        }
      } else {
        if(timeClashedFlag == true){
          return res.status(422).json({
            status: false,
            message: "Booking for this user in same timing already exists in some other trip. Time Clashes. Cannot book. Please try assigning this user in a trip whose timing is outside of the current trip for this user.",
            data: {},
          });
        }
        return res.status(500).json({
          status: false,
          message: "Booking already exist for this user",
          data: {},
        });
      }
    }
  });

  static tripBookings = catchAsyncErrors(async (req, res, next) => {
    let { tripId } = req.body;
    let bookings = await tripPassengerModel.find({ 
      tripId: tripId,
      isCancelled: false,
    }).populate([
      {
        path: "userId",
        model: "usersCollection",
      },
    ]).lean();

    if (bookings.length > 0) {
      bookings.forEach(async (val, index) => {
        let pickup = await tripStopModel.findOne({ _id: val.pickupStopId });
        let drop = await tripStopModel.findOne({ _id: val.dropStopId });
        val["pickupStop"] = pickup.stopName;
        val["dropStop"] = drop.stopName;
        let passengerAttendance = await tripStatusLogModel.findOne({
          tripId: tripId,
          passengerId: val.userId._id
        });
        val["boardingStatus"] = "Pending";
        if(passengerAttendance){
          val["boardingStatus"] = ((passengerAttendance.inTime) && !(passengerAttendance.outTime))
              ? "Onboarded" 
              : ((passengerAttendance.inTime) && (passengerAttendance.outTime))
                ? "Dropped Off"
                :"Pending";
        }
        if (index == bookings.length - 1) {
          return requestHandler.sendSuccess(
            res,
            "Successful"
          )({
            data: bookings,
          });
        }
      });
    } else {
      return requestHandler.sendSuccess(
        res,
        "Successful"
      )({
        data: [],
      });
    }
  });

  static deleteTripBooking = catchAsyncErrors(async (req, res, next) => {
    const { id } = req.body;
    const updated = await super.deleteById(tripPassengerModel, id);
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: updated,
      specific: true,
    });
  });

  static getTripBooking = catchAsyncErrors(async (req, res, next) => {
    const { id } = req.body;
    const asset = await tripPassengerModel.findOne({ _id: id });
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: asset,
    });
  });

  static tripAssignDriver = catchAsyncErrors(async (req, res, next) => {
    let { driverId, vendorId, vehicleId, _id } = req.body;
    let trip = await tripsModel.findOne({
      _id: _id
    });
    let data = {
      vendorId: vendorId && vendorId != "" ? vendorId : null,
      driverId: driverId && driverId != "" ? driverId : null,
      vehicleId: vehicleId && vehicleId != "" ? vehicleId : null,
    };
    let existingTrip = await tripsModel.findOne({
      _id: _id
    })
    let updated = await super.updateById(tripsModel, _id, data);
    if(updated){
      let driverOfTrip = await driverModel.findOne({
        _id: updated.driverId
      }).populate([
        {
          "path": "userId",
          "model": "usersCollection"
        },
      ]);
      // ========== inApp Notification ===========
      let notiData = {
        userId: driverOfTrip.userId._id,
        tripId: trip._id,

        title: `Assigned to trip`,
        body: `Dear ${driverOfTrip.userId.firstName}, new request arrives for vehicle booking.`,
      };
      let inAppNotification = await super.create(res, notificationModel, notiData);
      // ========== inApp Notification ===========
      if(driverOfTrip.userId.fcmToken){
        // send noti to driver ===
        // ========== push Notification ===========
        try {
          let fcmToken = "";
          fcmToken = driverOfTrip.userId.fcmToken;
          if (fcmToken) {
            // ========== Push Notification ===========
            let messages = {
              title: `Assigned to trip`,
              body: JSON.stringify({
                "tripId": trip._id.toString(),
                "msg": `Dear ${driverOfTrip.userId.firstName}, new request arrives for vehicle booking.`,
                "type": "Show"
              }),
            };
            await sendPushNotification(fcmToken, messages, "android");
          }

        } catch (error) {
          console.error("Error sending notification:", error.message);
          // Handle or propagate the error as needed
        }
        // =============== send notification to the driver ===============
      }
    }
    let tripPassengers = await tripPassengerModel.find({
      tripId: _id
    }).populate([
      {
        "path": "userId",
        "model": "usersCollection"
      },
      {
				"path": "tripId",
				"model": "tripsCollection",
        "populate":[
          {
            "path": "tripPlanId",
            "model": "tripPlanCollection",
            "populate":{
              "path": "routeId",
              "model": "routeMapCollection",
            }
          },
          {
            "path": "driverId",
            "model": "driverCollection",
            "populate":{
              "path": "userId",
              "model": "usersCollection",
            }
          },
          {
            "path": "vehicleId",
            "model": "vehicleCollection",
            "populate": {
              "path": "modelId",
              "model": "vehicleModelCollection",
            }
          }
        ]
			},
    ]);
    if(tripPassengers.length > 0){
      tripPassengers.forEach(async (passenger) => {
        if (passenger.userId.fcmToken) {
          let notiData = {}
          let inAppNotiData = {
            userId: passenger.userId._id,
            tripId: passenger.tripId._id.toString(),
          };
          if(((!trip.driverId) || (trip.driverId == null)) && (driverId && driverId != "")){
            let driver = await driverModel.findOne({
              _id: driverId
            }).populate([
              {
                "path": "userId",
                "model": "usersCollection"
              }
            ])
            if(vehicleId && vehicleId != ""){
              if(existingTrip.driverId && (existingTrip.driverId != '') && (existingTrip.driverId != null)){
                notiData.title = "Driver Reassigned";
                notiData.body = JSON.stringify({
                  "tripId": passenger.tripId._id.toString(),
                  "msg": "Dear "+passenger.userId.firstName+", Vehicle Number "+passenger.tripId.vehicleId.registrationNumber+" with driver "+driver.userId.firstName+" "+driver.userId.lastName+" and mobile "+driver.userId.phone+" has been assigned for "+passenger.tripId.tripPlanId.routeId.routeName+" route",
                  "type": "Show"
                });

                inAppNotiData.title = "Driver Reassigned";
                inAppNotiData.body = "Dear "+passenger.userId.firstName+", Vehicle Number "+passenger.tripId.vehicleId.registrationNumber+" with driver "+driver.userId.firstName+" "+driver.userId.lastName+" and mobile "+driver.userId.phone+" has been assigned for "+passenger.tripId.tripPlanId.routeId.routeName+" route";
              }else{
                notiData.title = "Driver Assigned";
                notiData.body = JSON.stringify({
                  "tripId": passenger.tripId._id.toString(),
                  "msg": "Dear "+passenger.userId.firstName+", Vehicle Number "+passenger.tripId.vehicleId.registrationNumber+" with driver "+driver.userId.firstName+" "+driver.userId.lastName+" and mobile "+driver.userId.phone+" has been assigned for "+passenger.tripId.tripPlanId.routeId.routeName+" route scheduled at "+passenger.tripId.tripDate+" on "+passenger.tripId.tripStartTime,
                  "type": "Show"
                });

                inAppNotiData.title = "Driver Assigned";
                inAppNotiData.body = "Dear "+passenger.userId.firstName+", Vehicle Number "+passenger.tripId.vehicleId.registrationNumber+" with driver "+driver.userId.firstName+" "+driver.userId.lastName+" and mobile "+driver.userId.phone+" has been assigned for "+passenger.tripId.tripPlanId.routeId.routeName+" route scheduled at "+passenger.tripId.tripDate+" on "+passenger.tripId.tripStartTime;
              }
            }else{
              if(existingTrip.driverId && (existingTrip.driverId != '') && (existingTrip.driverId != null)){
                notiData.title = "Driver Reassigned";
                notiData.body = JSON.stringify({
                  "tripId": passenger.tripId._id.toString(),
                  "msg": "Dear "+passenger.userId.firstName+", driver "+driver.userId.firstName+" "+driver.userId.lastName+" and mobile "+driver.userId.phone+" has been assigned for "+passenger.tripId.tripPlanId.routeId.routeName+" route",
                  "type": "Show"
                });

                inAppNotiData.title = "Driver Reassigned";
                inAppNotiData.body = "Dear "+passenger.userId.firstName+", driver "+driver.userId.firstName+" "+driver.userId.lastName+" and mobile "+driver.userId.phone+" has been assigned for "+passenger.tripId.tripPlanId.routeId.routeName+" route";
              }else{
                notiData.title = "Driver Assigned";
                notiData.body = JSON.stringify({
                  "tripId": passenger.tripId._id.toString(),
                  "msg": "Dear "+passenger.userId.firstName+", driver "+driver.userId.firstName+" "+driver.userId.lastName+" and mobile "+driver.userId.phone+" has been assigned for "+passenger.tripId.tripPlanId.routeId.routeName+" route scheduled at "+passenger.tripId.tripDate+" on "+passenger.tripId.tripStartTime,
                  "type": "Show"
                });

                inAppNotiData.title = "Driver Assigned";
                inAppNotiData.body = "Dear "+passenger.userId.firstName+", driver "+driver.userId.firstName+" "+driver.userId.lastName+" and mobile "+driver.userId.phone+" has been assigned for "+passenger.tripId.tripPlanId.routeId.routeName+" route scheduled at "+passenger.tripId.tripDate+" on "+passenger.tripId.tripStartTime;
              }
            }
          }else{
            if(existingTrip.driverId && (existingTrip.driverId != '') && (existingTrip.driverId != null)){
              let driver = await driverModel.findOne({
                _id: existingTrip.driverId
              }).populate([
                {
                  "path": "userId",
                  "model": "usersCollection"
                }
              ])
              notiData.title = "Driver Deleted";
              notiData.body = JSON.stringify({
                "tripId": passenger.tripId._id.toString(),
                "msg": "Dear "+passenger.userId.firstName+", Vehicle Number "+passenger.tripId.vehicleId.registrationNumber+" with driver "+driver.userId.firstName+" "+driver.userId.lastName+" has been deleted for "+passenger.tripId.tripPlanId.routeId.routeName+" route. We will assign a driver soon.",
                "type": "Show"
              });

              inAppNotiData.title = "Driver Deleted";
              inAppNotiData.body = "Dear "+passenger.userId.firstName+", Vehicle Number "+passenger.tripId.vehicleId.registrationNumber+" with driver "+driver.userId.firstName+" "+driver.userId.lastName+" has been deleted for "+passenger.tripId.tripPlanId.routeId.routeName+" route. We will assign a driver soon.";
            }else{
              notiData.title = "Vehicle Assigned";
              notiData.body = JSON.stringify({
                "tripId": passenger.tripId._id.toString(),
                "msg": "Dear "+passenger.userId.firstName+", Vehicle Number "+passenger.tripId.vehicleId.registrationNumber+" has been assigned for "+passenger.tripId.tripPlanId.routeId.routeName+" route scheduled at "+passenger.tripId.tripDate+" on "+passenger.tripId.tripStartTime,
                "type": "Show"
              });

              inAppNotiData.title = "Vehicle Assigned";
              inAppNotiData.body = "Dear "+passenger.userId.firstName+", Vehicle Number "+passenger.tripId.vehicleId.registrationNumber+" has been assigned for "+passenger.tripId.tripPlanId.routeId.routeName+" route scheduled at "+passenger.tripId.tripDate+" on "+passenger.tripId.tripStartTime;
            }
          }
          
          let inAppNotification = await super.create(res, notificationModel, inAppNotiData);
          try{
            await sendPushNotification(passenger.userId.fcmToken, notiData, "android");
          } catch (error) {
            console.error("Error sending notification:", error.message);
            // Handle or propagate the error as needed
          }
        }
      })
    }

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: updated,
    });
  });

  static tripAssignment = catchAsyncErrors(async (req, res, next) => {
    let { tripId } = req.body;
    const trips = await tripsModel.findOne({ _id: tripId });
    await tripPlanModel.populate(trips, [
      {
        path: "tripPlanId",
        model: "tripPlanCollection",
        populate: [
          {
            path: "routeId",
            model: "routeMapCollection",
          },
        ],
      },
    ]);
    await routeMapModel.populate(trips, [
      {
        path: "tripPlanId.routeId.routeStops.stopId",
        model: "tripStopCollection",
      },
    ]);
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: trips,
    });
  });

  static timeRanges = catchAsyncErrors(async (req, res, next) => {
    // get the current time in "Asia/Kolkata" time zone
    let momentKolkata = moment().tz('Asia/Kolkata');
    let currentDate = momentKolkata.format('YYYY-MM-DD');
    let currentDay = momentKolkata.format('dddd');
    let currentTime = momentKolkata.format('HH:mm');
    
    let trips = await tripsModel.find({
      isCancelled: false,
      isDeleted: false,
    });

    let timeRangesArr = [];
    
    trips.forEach((trip) => {
      let timeRangeObj = {};
      timeRangeObj.tripStartTime = trip.tripStartTime;
      timeRangeObj.tripEndTime = trip.tripEndTime;

      timeRangesArr.push(timeRangeObj);
    });

    let uniqueTimeRangesWithCountArr = [];

    timeRangesArr.forEach((timeRange) => {
      // check if this time range already exists in the uniqueTimeRangesWithCountArr
      let existingRange = uniqueTimeRangesWithCountArr.find((t) => (
        t.tripStartTime === timeRange.tripStartTime && t.tripEndTime === timeRange.tripEndTime
      ));

      if (existingRange) {
        // if the time range exists, increment the count
        existingRange.count++;
      } else {
        // if the time range does not exist, add it to the array with count 1
        uniqueTimeRangesWithCountArr.push({ ...timeRange, count: 1 });
      }
    });

    return res.status(200).json({
      status: true,
      data: uniqueTimeRangesWithCountArr
    });
  });



  static completedTrips = catchAsyncErrors(async (req, res, next) => {
    let trips = [];
    if (req.method == "POST") {
      let match = {
        // $and: [
        // 	{
        // 		$or: [
        // 			{
        // 				tripName: {
        // 					$regex: ".*" + text + ".*",
        // 					$options: "i",
        // 				},
        // 			},
        // 		],
        // 	}
        // ]
      };
      const aggregatorOpts = [
        {
          $addFields: {
            // tripName: "$tripName",
          },
        },
        {
          $match: match,
        },
      ];
      trips = await tripsModel.aggregate(aggregatorOpts).exec();

      await tripPlanModel.populate(trips, [
        {
          path: "tripPlanId",
          model: "tripPlanCollection",
          populate: [
            {
              path: "routeId",
              model: "routeMapCollection",
            },
            {
              path: "vendorId",
              model: "corporateCollection",
              populate: {
                path: "userId",
                model: "usersCollection",
              },
            },
          ],
        },
        {
          path: "driverId",
          model: "driverCollection",
          populate: {
            path: "userId",
            model: "usersCollection",
            populate: {
              path: "roleId",
              model: "roleCollection",
            },
          },
        },
      ]);
      await routeMapModel.populate(trips, [
        {
          path: "tripPlanId.routeId.routeStops.stopId",
          model: "tripStopCollection",
        },
      ]);

      let filteredTripsUserWise = [];
      if (superId) {
        filteredTripsUserWise = trips;
      } else {
        filteredTripsUserWise = trips.filter((trip) => {
          if (trip?.tripPlanId?.vendorId?.userId?._id == req.user._id) {
            return trip;
          }
        });
      }

      let bookings = await tripPassengerModel
        .find({ createdAt: { $gte: new Date(fromDate) } })
        .populate([
          {
            path: "userId",
            model: "usersCollection",
          },
        ]);
      let alltrips = [];
      while (fromDate <= toDate) {
        var trps = [];
        if (filteredTripsUserWise.length > 0) {
          filteredTripsUserWise.forEach(async (trip, index) => {
            if (dateFormatYYYYMMDD(trip.tripDate) == fromDate) {
              trip["bookings"] = [];
              bookings.forEach((elem) => {
                if (elem.tripId.toString() == trip._id.toString()) {
                  trip["bookings"].push(elem);
                }
              });
              trps.push(trip);
            }
            if (index == filteredTripsUserWise.length - 1) {
              alltrips.push({
                date: fromDate,
                trips: trps,
              });

              fromDate = new Date(fromDate);
              fromDate.setDate(fromDate.getDate() + 1);
              fromDate = dateFormatYYYYMMDD(new Date(fromDate));

              if (fromDate > toDate) {
                return requestHandler.sendSuccess(
                  res,
                  "Successful"
                )({
                  data: alltrips,
                  // data: tripPlanDetails(trips),
                });
              }
            }
          });
        } else {
          alltrips.push({
            date: fromDate,
            trips: [],
          });
          fromDate = new Date(fromDate);
          fromDate.setDate(fromDate.getDate() + 1);
          fromDate = dateFormatYYYYMMDD(new Date(fromDate));

          if (fromDate > toDate) {
            return requestHandler.sendSuccess(
              res,
              "Successful"
            )({
              data: alltrips,
              // data: tripPlanDetails(trips),
            });
          }
        }
      }
    } else {
      // ======= for dropdown ===========
      trips = await super.getList(req, tripsModel, "");
      trips.sort((a, b) => new Date(a.tripDate) - new Date(b.tripDate));
      return requestHandler.sendSuccess(
        res,
        "Successful"
      )({
        data: trips,
        // data: tripPlanDetails(trips),
      });
    }
  });

  // ============== App APIs ===================
  static routeSpecificTrips = catchAsyncErrors(async (req, res, next) => {
    let { routeId, choosenDate, lat, long, pickLat, pickLong, loggedInAs } = req.body;
    let morningTrips = [];
    let eveningTrips = [];
    // console.log("loggedInAs ====>");
    // console.log(loggedInAs);
    let loggedUserRole = await rollModel.findOne({
      _id: loggedInAs
    });
    // console.log("loggedUserRole ==>");
    // console.log(loggedUserRole.name); // "Customer"

    // Get the current time in "Asia/Kolkata" time zone =======
    let momentKolkata = moment().tz("Asia/Kolkata");
    let currentDate = momentKolkata.format("YYYY-MM-DD");
    // let currentDay = momentKolkata.format('dddd');
    // let currentTime = momentKolkata.format('HH:mm');
    // Get the current time in "Asia/Kolkata" time zone =======
    let tripDate = "";
    if (choosenDate == undefined) {
      tripDate = currentDate;
    } else {
      tripDate = moment(choosenDate).format("YYYY-MM-DD");
    }

    let todayTrips = await tripsModel.find({
      tripDate: tripDate,
      isCancelled: false,
    }).sort({ tripStartTime: 1 }) // ASC order
    .lean().populate({
      path: "tripPlanId",
      model: "tripPlanCollection",
    });
    // console.log("todayTrips ====>");
    // console.log(todayTrips);
    
    let routeWiseFilteredTrips = todayTrips.filter((trip) => {
      if (trip?.tripPlanId?.routeId.toString() == routeId.toString()) {
        return trip;
      }
    });
    await tripsModel.populate(routeWiseFilteredTrips, [
      {
        path: "tripPlanId.routeId",
        model: "routeMapCollection",
      },
    ]);
    await tripStopModel.populate(routeWiseFilteredTrips, [
      {
        path: "tripPlanId.stops.tripStopId",
        model: "tripStopCollection",
      },
    ]);

    // console.log("routeWiseFilteredTrips ===>");
    // console.log(routeWiseFilteredTrips);
    
    routeWiseFilteredTrips.map((trip)=>{
      trip.tripPlanId["firstStop"] = trip.tripPlanId.stops[0];
      trip.tripPlanId["lastStop"] = trip.tripPlanId.stops[trip.tripPlanId.stops.length - 1];

      return trip;
    });
    let customer = await customerModel.find({
      userId: req.user._id,
    });
    // console.log("customer ===>");
    // console.log(customer);
    
    let userCorporateIdArr = [];
    customer.forEach((item) => {
      item.corporates.forEach((corporate) => {
        userCorporateIdArr.push(corporate.corporateId.toString());
      });
    });
    
    let corporateWiseRouteWiseDateWiseFilteredTrips = [];
    let count = 0;
    corporateWiseRouteWiseDateWiseFilteredTrips = routeWiseFilteredTrips.filter((trip) => {
      count++;
      if (
        userCorporateIdArr.includes(trip.tripPlanId.corporateId.toString())
      ) {
        if(loggedUserRole.name == "Customer"){
          // onDemand check ======
          if(trip.tripPlanId.isOnDemand == true){
            return trip;
          }
        } else {
          return trip;
        }
      } else {
        // ====== for users that are not part of any organization ======
        if(loggedUserRole.name == "Customer"){
          // console.log(`Now here ===> ${count}`);
          
          // onDemand check ======
          if(trip.tripPlanId.isOnDemand == true){
            return trip;
          }
        } else {
          // return trip;
          console.log(`Lord Arnab's special debugging log ==> ${count}`);
          
        }
      }
    });
    // console.log("corporateWiseRouteWiseDateWiseFilteredTrips ====>");
    // console.log(corporateWiseRouteWiseDateWiseFilteredTrips);
    
    // ============ ETA calculation ============
    let cnt = 0;
    for(let i=0; i < corporateWiseRouteWiseDateWiseFilteredTrips.length; i++ ){
      let trip = corporateWiseRouteWiseDateWiseFilteredTrips[i];
      let originLat = lat.toString();
      let originLong = long.toString();
      // return res.status(200).json({
      //   status: true,
      //   data: trip,
      // });
      let tripStartLat = pickLat.toString();
      let tripStartLong = pickLong.toString();
      let config = {
        method: 'get',
        maxBodyLength: Infinity,
        url: `https://maps.googleapis.com/maps/api/distancematrix/json?origins=${originLat},${originLong}&destinations=${tripStartLat},${tripStartLong}&mode=walking&key=${GoogleApiKey}`,
        headers: { }
      };
      axios.request(config).then(async (response) => {
        // console.log(response.data.rows);
        trip['eta'] = response?.data?.rows[0]?.elements[0]?.duration?.text;
        // console.log("trip.pickupStopId['eta'] ======>");
        // console.log(trip.pickupStopId['eta']);
        cnt++;
        if(cnt == corporateWiseRouteWiseDateWiseFilteredTrips.length){
          // ============ ETA calculation ============
          let currentTime = new Date();
          // ======== set current time to 2 pm ==============
          currentTime.setHours(14, 0, 0, 0);
          // ======== set current time to 2 pm ==============

          // ====== sorting morning and evening trips ===========
          corporateWiseRouteWiseDateWiseFilteredTrips.forEach((trip) => {
            let startTime = new Date(
              dateFormat(trip.tripDate) + " " + trip.tripStartTime
            );
            let endTime = new Date(
              dateFormat(trip.tripDate) + " " + trip.tripEndTime
            );
            if (startTime <= currentTime) {
              morningTrips.push(trip);
            } else if (startTime > currentTime) {
              eveningTrips.push(trip);
            }
          });
          // ====== sorting morning and evening trips ===========

          if (corporateWiseRouteWiseDateWiseFilteredTrips.length > 0) {
            return res.status(200).json({
              status: true,
              message: "Trips found.",
              data: {
                morningTrips: morningTrips,
                eveningTrips: eveningTrips,
              },
            });
          } else {
            return res.status(200).json({
              status: true,
              message: "No trips found..!!",
              data: [],
            });
          }
        }
      })
      .catch((error) => {
        console.log(error);
      });
      
    }
  });

  static upcomingAndCompletedTrips = catchAsyncErrors(async (req, res, next) => {
    let { lat, long, serviceId, } = req.body;

    if(!serviceId){
      return res.status(422).json({
        status: false,
        message: "serviceId is not present in payload.",
        data: {}
      });
    }

		let trips = [];
		let upcomingTrips = [];
		let completedTrips = [];
		let upcomingAndCompeletedTrips = {};
		trips = await tripPassengerModel.find({
				userId: req.user._id,
        serviceId: serviceId,
				// isCancelled: false,
		}).sort({ bookingDate: -1 }) // DESC order
    .populate([
			{
				"path": "tripId",
				"model": "tripsCollection",
        "populate":[
          {
            "path": "tripPlanId",
            "model": "tripPlanCollection",
            "populate":{
              "path": "routeId",
              "model": "routeMapCollection",
            }
          },
          {
            "path": "driverId",
            "model": "driverCollection",
            "populate":{
              "path": "userId",
              "model": "usersCollection",
            }
          },
          {
            "path": "vehicleId",
            "model": "vehicleCollection",
            "populate": {
              "path": "modelId",
              "model": "vehicleModelCollection",
            }
          }
        ]
			},
			{
				"path": "pickupStopId",
				"model": "tripStopCollection",
			},
			{
				"path": "dropStopId",
				"model": "tripStopCollection",
			},
		]).lean();

    if(trips.length > 0){
      let tripsWithDriverAndVehicleRatings = await Promise.all(trips.map(async (trip)=>{
        // ===== rating ========
        let averageDriverRating = '';
        let averageVehicleRating = '';
        if(trip.tripId.driverId){
          let driverRating = await driverFeedbackModel.aggregate([
            {
              $match: {
                driverId: trip.tripId.driverId.userId._id, 
                isDeleted: false,
              }
            },
            {
              $group: {
                _id: "$driverId",
                averageRating: { $avg: "$rating" } // Calculate average of ratings
              }
            }
          ]);
          // Result will be an array with one element containing _id and averageRating fields ===
          if (driverRating.length > 0) {
            averageDriverRating = driverRating[0].averageRating;
          }
          trip.tripId.driverId['averageRating'] = averageDriverRating;
        }
        if(trip.tripId.vehicleId){
          let vehicleRating = await vehicleFeedbackmodel.aggregate([
            {
              $match: {
                vehicleId: trip.tripId.vehicleId._id, 
                isDeleted: false,
              }
            },
            {
              $group: {
                _id: "$vehicleId",
                averageRating: { $avg: "$rating" } // Calculate average of ratings
              }
            }
          ]);
          // Result will be an array with one element containing _id and averageRating fields ===
          if (vehicleRating.length > 0) {
            averageVehicleRating = vehicleRating[0].averageRating;
          }
          trip.tripId.vehicleId['averageRating'] = averageVehicleRating;
        }
        return trip;
      }));
      trips = tripsWithDriverAndVehicleRatings;
      // ===== rating ========
      // ===== ETA calculation =====
      let cnt = 0;
      for(let i=0; i < trips.length; i++ ){
        let trip = trips[i];
        let originLat = lat.toString();
        let originLong = long.toString();
        
        let tripStartLat = trip.pickupStopId.location.coordinates[0].toString();
        let tripStartLong = trip.pickupStopId.location.coordinates[1].toString();
        let config = {
          method: 'get',
          maxBodyLength: Infinity,
          url: `https://maps.googleapis.com/maps/api/distancematrix/json?origins=${originLat},${originLong}&destinations=${tripStartLat},${tripStartLong}&mode=walking&key=${GoogleApiKey}`,
          headers: { }
        };
        axios.request(config).then(async (response) => {
          // console.log(response.data.rows);
          trip.pickupStopId['eta'] = response?.data?.rows[0]?.elements[0]?.duration?.text;
          // console.log("trip.pickupStopId['eta'] ======>");
          // console.log(trip.pickupStopId['eta']);
          cnt++;
          if(cnt == trips.length){
            // ===== ETA calculation =====
            // Get the current time in "Asia/Kolkata" time zone =======
            let momentKolkata = moment().tz("Asia/Kolkata");
            let currentDate = momentKolkata.format("YYYY-MM-DD");
            let currentDay = momentKolkata.format("dddd");
            // let currentTime = momentKolkata.format('HH:mm');
            // Get the current time in "Asia/Kolkata" time zone =======
            let currentTime = new Date();
            trips.forEach((trip) => {
              let startTime = new Date(
                dateFormat(trip.tripId.tripDate) + " " + trip.tripId.tripStartTime
              );
              let endTime = new Date(
                dateFormat(trip.tripId.tripDate) + " " + trip.tripId.tripEndTime
              );
  
              if(endTime < startTime){
                // if endTime less than startTime, i.e: Trip ends on the next day, setting date to next day
                endTime = endTime.setDate(endTime.getDate + 1)
                endTime = new Date(endTime)
              }
  
              if (
                (endTime <= currentTime)
              ){
                // ========== completed trips =========
                completedTrips.push(trip);
              } else if (
                (startTime >= currentTime)
              ) {
                // ========== upcoming trips ==========
                if(trip.isCancelled == false){
                  upcomingTrips.push(trip);
                } else {
                  // if trip is cancelled === will be inside completed ===
                  completedTrips.push(trip);
                }
              }
            });
            // ======== upcoming and completed trips ========
            upcomingAndCompeletedTrips.completedTrips = completedTrips;
            upcomingAndCompeletedTrips.upcomingTrips = upcomingTrips;
            upcomingAndCompeletedTrips.userImageUrl = process.env.API_URL + 'uploads/userImages/';
            upcomingAndCompeletedTrips.vehicleImageUrl = process.env.API_URL + 'uploads/vehicles/';
            // ======== upcoming and completed trips ========
            if (upcomingAndCompeletedTrips) {
              return res.status(200).json({
                status: true,
                message: "Data found",
                data: upcomingAndCompeletedTrips,
              });
            } else {
              return res.status(200).json({
                status: true,
                message: "No data found",
                data: {},
              });
            }
          }
        })
        .catch((error) => {
          console.log(error);
        });
      }
      // let tripsWithEtaCalculation = await Promise.all(trips.map(async (trip)=>{
      //   let originLat = lat.toString();
      //   let originLong = long.toString();
        
      //   let tripStartLat = trip.pickupStopId.location.coordinates[0].toString();
      //   let tripStartLong = trip.pickupStopId.location.coordinates[1].toString();
  
      //   let etaObj = {};
      //   let config = {
      //     method: 'get',
      //     maxBodyLength: Infinity,
      //     url: `https://maps.googleapis.com/maps/api/distancematrix/json?origins=${originLat},${originLong}&destinations=${tripStartLat},${tripStartLong}&mode=walking&key=${GoogleApiKey}`,
      //     headers: { }
      //   };
    
      //   axios.request(config).then(async (response) => {
      //     // console.log(JSON.stringify(response.data)); 
      //     // console.log(response.data.rows);
      //     trip.pickupStopId['eta'] = response?.data?.rows[0]?.elements[0]?.duration?.text;
      //     console.log("trip.pickupStopId['eta'] ======>");
      //     console.log(trip.pickupStopId['eta']);
      //     cnt++
      //     return trip;
      //   })
      //   .catch((error) => {
      //     console.log(error);
      //   });
  
      // }));
      // trips = tripsWithEtaCalculation;
    } else {
      return res.status(200).json({
        status: true,
        message: "No data found",
        data: {},
      });
    }

    
	});

  static upcomingAndCompletedTripsForStudent = catchAsyncErrors(async (req, res, next) => {
    let { studentId, schoolId, lat, long } = req.body;
		let trips = [];
		let upcomingTrips = [];
		let completedTrips = [];
		let upcomingAndCompeletedTrips = {};
		trips = await tripPassengerModel.find({
				userId: studentId,
				// isCancelled: false,
		}).sort({ bookingDate: -1 }) // DESC order
    .populate([
			{
				"path": "tripId",
				"model": "tripsCollection",
        "populate":[
          {
            "path": "tripPlanId",
            "model": "tripPlanCollection",
            "populate":{
              "path": "routeId",
              "model": "routeMapCollection",
            }
          },
          {
            "path": "driverId",
            "model": "driverCollection",
            "populate":{
              "path": "userId",
              "model": "usersCollection",
            }
          },
          {
            "path": "vehicleId",
            "model": "vehicleCollection",
            "populate": {
              "path": "modelId",
              "model": "vehicleModelCollection",
            }
          }
        ]
			},
			{
				"path": "pickupStopId",
				"model": "tripStopCollection",
			},
			{
				"path": "dropStopId",
				"model": "tripStopCollection",
			},
		]).lean();
    
    let tripsWithDriverAndVehicleRatings = await Promise.all(trips.map(async (trip)=>{
      // ===== rating ========
      let averageDriverRating = '';
      let averageVehicleRating = '';
      if(trip.tripId.driverId){
        let driverRating = await driverFeedbackModel.aggregate([
          {
            $match: {
              driverId: trip.tripId.driverId.userId._id, 
              isDeleted: false,
            }
          },
          {
            $group: {
              _id: "$driverId",
              averageRating: { $avg: "$rating" } // Calculate average of ratings
            }
          }
        ]);
        // Result will be an array with one element containing _id and averageRating fields ===
        if (driverRating.length > 0) {
          averageDriverRating = driverRating[0].averageRating;
        }
        trip.tripId.driverId['averageRating'] = averageDriverRating;
      }
      if(trip.tripId.vehicleId){
        let vehicleRating = await vehicleFeedbackmodel.aggregate([
          {
            $match: {
              vehicleId: trip.tripId.vehicleId._id, 
              isDeleted: false,
            }
          },
          {
            $group: {
              _id: "$vehicleId",
              averageRating: { $avg: "$rating" } // Calculate average of ratings
            }
          }
        ]);
        // Result will be an array with one element containing _id and averageRating fields ===
        if (vehicleRating.length > 0) {
          averageVehicleRating = vehicleRating[0].averageRating;
        }
        trip.tripId.vehicleId['averageRating'] = averageVehicleRating;
      }
      return trip;
    }));
    trips = tripsWithDriverAndVehicleRatings;
    // ===== rating ========
    // ===== ETA calculation =====
    let cnt = 0;
    for(let i=0; i < trips.length; i++ ){
      let trip = trips[i];
      let originLat = lat.toString();
      let originLong = long.toString();
      
      let tripStartLat = trip.pickupStopId.location.coordinates[0].toString();
      let tripStartLong = trip.pickupStopId.location.coordinates[1].toString();
      let config = {
        method: 'get',
        maxBodyLength: Infinity,
        url: `https://maps.googleapis.com/maps/api/distancematrix/json?origins=${originLat},${originLong}&destinations=${tripStartLat},${tripStartLong}&mode=walking&key=${GoogleApiKey}`,
        headers: { }
      };
      axios.request(config).then(async (response) => {
        // console.log(response.data.rows);
        trip.pickupStopId['eta'] = response?.data?.rows[0]?.elements[0]?.duration?.text;
        // console.log("trip.pickupStopId['eta'] ======>");
        // console.log(trip.pickupStopId['eta']);
        cnt++;
        if(cnt == trips.length){
          // ===== ETA calculation =====
          // Get the current time in "Asia/Kolkata" time zone =======
          let momentKolkata = moment().tz("Asia/Kolkata");
          let currentDate = momentKolkata.format("YYYY-MM-DD");
          let currentDay = momentKolkata.format("dddd");
          // let currentTime = momentKolkata.format('HH:mm');
          // Get the current time in "Asia/Kolkata" time zone =======
          let currentTime = new Date();
          trips.forEach((trip) => {
            let startTime = new Date(
              dateFormat(trip.tripId.tripDate) + " " + trip.tripId.tripStartTime
            );
            let endTime = new Date(
              dateFormat(trip.tripId.tripDate) + " " + trip.tripId.tripEndTime
            );

            if(endTime < startTime){
              // if endTime less than startTime, i.e: Trip ends on the next day, setting date to next day
              endTime = endTime.setDate(endTime.getDate + 1)
              endTime = new Date(endTime)
            }

            if (
              (endTime <= currentTime)
            ){
              // ========== completed trips =========
              completedTrips.push(trip);
            } else if (
              (startTime >= currentTime)
            ) {
              // ========== upcoming trips ==========
              if(trip.isCancelled == false){
                upcomingTrips.push(trip);
              } else {
                // if trip is cancelled === will be inside completed ===
                completedTrips.push(trip);
              }
            }
          });
          // ======== upcoming and completed trips ========
          upcomingAndCompeletedTrips.completedTrips = completedTrips;
          upcomingAndCompeletedTrips.upcomingTrips = upcomingTrips;
          upcomingAndCompeletedTrips.userImageUrl = process.env.API_URL + 'uploads/userImages/';
          upcomingAndCompeletedTrips.vehicleImageUrl = process.env.API_URL + 'uploads/vehicles/';
          // ======== upcoming and completed trips ========
          if (upcomingAndCompeletedTrips) {
            return res.status(200).json({
              status: true,
              message: "Data found",
              data: upcomingAndCompeletedTrips,
            });
          } else {
            return res.status(200).json({
              status: true,
              message: "No data found",
              data: {},
            });
          }
        }
      })
      .catch((error) => {
        console.log(error);
      });
    }
    // let tripsWithEtaCalculation = await Promise.all(trips.map(async (trip)=>{
    //   let originLat = lat.toString();
    //   let originLong = long.toString();
      
    //   let tripStartLat = trip.pickupStopId.location.coordinates[0].toString();
    //   let tripStartLong = trip.pickupStopId.location.coordinates[1].toString();

    //   let etaObj = {};
    //   let config = {
    //     method: 'get',
    //     maxBodyLength: Infinity,
    //     url: `https://maps.googleapis.com/maps/api/distancematrix/json?origins=${originLat},${originLong}&destinations=${tripStartLat},${tripStartLong}&mode=walking&key=${GoogleApiKey}`,
    //     headers: { }
    //   };
  
    //   axios.request(config).then(async (response) => {
    //     // console.log(JSON.stringify(response.data)); 
    //     // console.log(response.data.rows);
    //     trip.pickupStopId['eta'] = response?.data?.rows[0]?.elements[0]?.duration?.text;
    //     console.log("trip.pickupStopId['eta'] ======>");
    //     console.log(trip.pickupStopId['eta']);
    //     cnt++
    //     return trip;
    //   })
    //   .catch((error) => {
    //     console.log(error);
    //   });

    // }));
    // trips = tripsWithEtaCalculation;

    
	});

  // static routeSpecificTripsForStudent = catchAsyncErrors(async (req, res, next) => {
  //   let { studnetId, schoolId, routeId, choosenDate, lat, long } = req.body;
  //   let morningTrips = [];
  //   let eveningTrips = [];

  //   // Get the current time in "Asia/Kolkata" time zone =======
  //   let momentKolkata = moment().tz("Asia/Kolkata");
  //   let currentDate = momentKolkata.format("YYYY-MM-DD");
  //   // let currentDay = momentKolkata.format('dddd');
  //   // let currentTime = momentKolkata.format('HH:mm');
  //   // Get the current time in "Asia/Kolkata" time zone =======

  //   let tripDate = "";
  //   if (choosenDate == undefined) {
  //     tripDate = currentDate;
  //   } else {
  //     tripDate = moment(choosenDate).format("YYYY-MM-DD");
  //   }

  //   let todayTrips = await tripsModel.find({
  //     tripDate: tripDate,
  //     isCancelled: false,
  //   }).lean().populate({
  //     path: "tripPlanId",
  //     model: "tripPlanCollection",
  //   });
  //   let routeWiseFilteredTrips = todayTrips.filter((trip) => {
  //     if (trip.tripPlanId.routeId.toString() == routeId.toString()) {
  //       return trip;
  //     }
  //   });
  //   await tripsModel.populate(routeWiseFilteredTrips, [
  //     {
  //       path: "tripPlanId.routeId",
  //       model: "routeMapCollection",
  //     },
  //   ]);
  //   await tripStopModel.populate(routeWiseFilteredTrips, [
  //     {
  //       path: "tripPlanId.stops.tripStopId",
  //       model: "tripStopCollection",
  //     },
  //   ]);
    
  //   routeWiseFilteredTrips.map((trip)=>{
  //     trip.tripPlanId["firstStop"] = trip.tripPlanId.stops[0];
  //     trip.tripPlanId["lastStop"] = trip.tripPlanId.stops[trip.tripPlanId.stops.length - 1];

  //     return trip;
  //   });
  //   let customer = await customerModel.find({
  //     userId: req.user._id,
  //   });
  //   let userCorporateIdArr = [];
  //   customer.forEach((item) => {
  //     item.corporates.forEach((corporate) => {
  //       userCorporateIdArr.push(corporate.corporateId.toString());
  //     });
  //   });
  //   let corporateWiseRouteWiseDateWiseFilteredTrips = [];
  //   corporateWiseRouteWiseDateWiseFilteredTrips = routeWiseFilteredTrips.filter(
  //     (trip) => {
  //       if (
  //         userCorporateIdArr.includes(trip.tripPlanId.corporateId.toString())
  //       ) {
  //         return trip;
  //       }
  //     }
  //   );
  //   // ============ ETA calculation ============
  //   let cnt = 0;
  //   for(let i=0; i < corporateWiseRouteWiseDateWiseFilteredTrips.length; i++ ){
  //     let trip = corporateWiseRouteWiseDateWiseFilteredTrips[i];
  //     let originLat = lat.toString();
  //     let originLong = long.toString();
      
  //     let tripStartLat = trip.pickupStopId.location.coordinates[0].toString();
  //     let tripStartLong = trip.pickupStopId.location.coordinates[1].toString();
  //     let config = {
  //       method: 'get',
  //       maxBodyLength: Infinity,
  //       url: `https://maps.googleapis.com/maps/api/distancematrix/json?origins=${originLat},${originLong}&destinations=${tripStartLat},${tripStartLong}&mode=walking&key=${GoogleApiKey}`,
  //       headers: { }
  //     };
  //     axios.request(config).then(async (response) => {
  //       // console.log(response.data.rows);
  //       trip.pickupStopId['eta'] = response?.data?.rows[0]?.elements[0]?.duration?.text;
  //       // console.log("trip.pickupStopId['eta'] ======>");
  //       // console.log(trip.pickupStopId['eta']);
  //       cnt++;
  //       if(cnt == trips.length){
  //         // ============ ETA calculation ============
  //         let currentTime = new Date();
  //         // ======== set current time to 2 pm ==============
  //         currentTime.setHours(14, 0, 0, 0);
  //         // ======== set current time to 2 pm ==============

  //         // ====== sorting morning and evening trips ===========
  //         corporateWiseRouteWiseDateWiseFilteredTrips.forEach((trip) => {
  //           let startTime = new Date(
  //             dateFormat(trip.tripDate) + " " + trip.tripStartTime
  //           );
  //           let endTime = new Date(
  //             dateFormat(trip.tripDate) + " " + trip.tripEndTime
  //           );
  //           if (startTime <= currentTime) {
  //             morningTrips.push(trip);
  //           } else if (startTime > currentTime) {
  //             eveningTrips.push(trip);
  //           }
  //         });
  //         // ====== sorting morning and evening trips ===========

  //         if (corporateWiseRouteWiseDateWiseFilteredTrips.length > 0) {
  //           return res.status(200).json({
  //             status: true,
  //             message: "Trips found.",
  //             data: {
  //               morningTrips: morningTrips,
  //               eveningTrips: eveningTrips,
  //             },
  //           });
  //         } else {
  //           return res.status(200).json({
  //             status: true,
  //             message: "No trips found..!!",
  //             data: [],
  //           });
  //         }
  //       }
  //     })
  //     .catch((error) => {
  //       console.log(error);
  //     });
      
  //   }
  // });

  static bookingConfirmation = catchAsyncErrors(async (req, res, next) => {
    let { tripId, bookingLocation, lat, long, pickupStopId, dropStopId, _id } =
      req.body;
    let data = {
      tripId: tripId,
      userId: req.user._id,
      bookingLocation: bookingLocation,
      coordinates: [lat, long],
      pickupStopId: pickupStopId,
      dropStopId: dropStopId,
    };
    let booking = await tripPassengerModel
      .findOne({ tripId: tripId, userId: req.user._id })
      .populate({
        path: "tripId",
        model: "tripsCollection",
      });
    // Get the current time in "Asia/Kolkata" time zone =======
    let momentKolkata = moment().tz("Asia/Kolkata");
    let currentDate = momentKolkata.format("YYYY-MM-DD");
    let currentDay = momentKolkata.format("dddd");
    // let currentTime = momentKolkata.format('HH:mm');
    // Get the current time in "Asia/Kolkata" time zone =======

    let tripDetail = await tripsModel.findOne({ _id: tripId });

    var startTime = new Date(
      dateFormat(tripDetail.tripDate) + " " + tripDetail.tripStartTime
    );
    var endTime = new Date(
      dateFormat(tripDetail.tripDate) + " " + tripDetail.tripEndTime
    );
    var currentTime = new Date();
    var existingBookingStartTime = new Date(
      dateFormat(booking.tripDate) + " " + booking.tripStartTime
    );
    var existingBookingEndTime = new Date(
      dateFormat(booking.tripDate) + " " + booking.tripEndTime
    );

    if (
      (endTime >= existingBookingStartTime &&
        endTime <= existingBookingEndTime) ||
      (startTime >= existingBookingStartTime &&
        startTime <= existingBookingEndTime)
    ) {
      // ====================== time clashing ======================
      return res.status(400).json({
        status: false,
        message: "You already have a booking for this particular timing.",
        data: "",
      });
    } else {
      // ====================== time not clashing ======================
      if (_id && _id != null && _id != "") {
        let updated = await super.updateById(
          tripPassengerModel,
          _id.toString(),
          data
        );
        return requestHandler.sendSuccess(
          res,
          "Successful"
        )({
          data: updated,
        });
      } else {
        if (!booking) {
          let updated = await super.create(res, tripPassengerModel, data);

          let route = await savedRouteModel.findOne({
            pickupStopId: pickupStopId,
            dropStopId: dropStopId,
            userId: req.user._id,
          });
          if (!route) {
            let routeData = {
              pickupStopId: pickupStopId,
              dropStopId: dropStopId,
              userId: req.user._id,
            };
            let routeUpdated = await super.create(
              res,
              savedRouteModel,
              routeData
            );
          }

          return requestHandler.sendSuccess(
            res,
            "Successful"
          )({
            data: updated,
          });
        } else {
          return res.status(500).json({
            status: false,
            message: "Booking already exist for this user",
            data: "",
          });
        }
      }
    }
  });
  static cancelBooking = catchAsyncErrors(async (req, res, next) => {
    let { _id, cancellationReason } = req.body;
    let data = {
      isCancelled: true,
      cancellationReason: cancellationReason,
    };
    let cancelledBooking = await tripPassengerModel.findOne({
      tripId: _id,
      isCancelled: false,
    }).populate([
      {
        "path": "userId",
        "model": "usersCollection"
      },
      {
        "path": "tripId",
        "model": "tripsCollection",
        "populate": {
          "path": "tripPlanId",
          "model": "tripPlanCollection",
          "populate": {
            "path": "routeId",
            "model": "routeMapCollection",
          }
        }
      },
    ]);
    if (cancelledBooking) {
      let updated = await super.updateById(
        tripPassengerModel,
        cancelledBooking._id.toString(),
        data
      );
      if(updated){
        // ============ successfully cancelled ============
        // ========== inApp Notification ===========
        let notiData = {
          userId: cancelledBooking.userId._id,
          tripId: cancelledBooking.tripId._id,

          title: `Trip Cancelled`,
          body: `Dear ${cancelledBooking.userId.firstName}, booking for ${cancelledBooking.tripId.tripPlanId.routeId.routeName} route at ${cancelledBooking.tripId.tripDate} scheduled at ${cancelledBooking.tripId.tripStartTime} has been cancelled.`,
          // Dear {{username}}, booking for ${cancelledBooking.tripId.tripPlanId.routeId.routeName} route scheduled at {{booking date & time }} been cancelled
        };
        let inAppNotification = await super.create(res, notificationModel, notiData);
        // ========== inApp Notification ===========

        // ========== Push Notification ===========
        if(cancelledBooking.userId.fcmToken){
          console.log("------ Sending Notification ----");
          let messages = {
            title: "Trip Cancelled",
            body: JSON.stringify({
              "tripId": cancelledBooking.tripId._id.toString(),
              "msg": `Dear ${cancelledBooking.userId.firstName}, booking for ${cancelledBooking.tripId.tripPlanId.routeId.routeName} route at ${cancelledBooking.tripId.tripDate} scheduled at ${cancelledBooking.tripId.tripStartTime} has been cancelled.`,
            }),
          };
          await sendPushNotification(cancelledBooking.userId.fcmToken, messages, "android");
        }
        return res.status(200).json({
          status: true,
          message: "Success",
          data: updated,
        });
      } else {
        return res.status(400).json({
          status: false,
          message: "Can not cancel ride.",
          data: {},
        });
      }
    } else {
      return res.status(200).json({
        status: true,
        message: "Booking already cancelled.",
        data: "",
      });
    }
  });
  static currentRide = catchAsyncErrors(async (req, res, next) => {
    let { serviceId } = req.body;

    if(!serviceId){
      return res.status(422).json({
        status: false,
        message: "serviceId is not present in payload.",
        data: {}
      });
    }

    let userRides = await tripPassengerModel.find({
      userId: req.user._id,
      serviceId:serviceId,
      isCancelled: false,
    }).populate([
      {
        "path": "tripId",
        "model": "tripsCollection",
        "populate": [
          {
            "path": "tripPlanId",
            "model": "tripPlanCollection",
            "populate": [
              {
                "path": "routeId",
                "model": "routeMapCollection",
              },
              {
                "path": "stops.tripStopId",
                "model": "tripStopCollection",
              },
            ],
          },
          {
            "path": "driverId",
            "model": "driverCollection",
            "populate": {
              "path": "userId",
              "model": "usersCollection"
            },
          },
          {
            "path": "vehicleId",
            "model": "vehicleCollection",
            "populate": {
              "path": "modelId",
              "model": "vehicleModelCollection",
              "populate": {
                "path": "type",
                "model": "vehicleCategoriesCollection"
              },
            },
          }
        ],
      },
      {
        "path": "pickupStopId",
        "model": "tripStopCollection"
      },
      {
        "path": "dropStopId",
        "model": "tripStopCollection"
      },
    ]).lean();
    // Get the current time in "Asia/Kolkata" time zone =======
    let momentKolkata = moment().tz("Asia/Kolkata");
    let currentDate = momentKolkata.format("YYYY-MM-DD");
    let currentDay = momentKolkata.format("dddd");
    // let currentTime = momentKolkata.format('HH:mm');
    // Get the current time in "Asia/Kolkata" time zone =======
    let currentTime = new Date();
    let currentRide = userRides.filter((ride) => {
      let startTime = new Date(
        dateFormat(ride.tripId.tripDate) + " " + ride.tripId.tripStartTime
      );
      let endTime = new Date(
        dateFormat(ride.tripId.tripDate) + " " + ride.tripId.tripEndTime
      );

      if (
        (
          (currentTime >= startTime) 
          && (currentTime <= endTime)
        ) 
        || 
        (
          (ride?.tripId?.tripStatus == "Started")
          || (ride?.tripId?.tripStatus == "Paused")
          || (ride?.tripId?.tripStatus == "Resumed")
        )
      ) {
        return ride;
      }
    });

    if (currentRide.length > 0) {
      let averageRating = '';
      if(currentRide[0]?.tripId?.driverId){
        let driverRating = await driverFeedbackModel.aggregate([
          {
            $match: {
              driverId: currentRide[0].tripId.driverId.userId._id, 
              isDeleted: false,
            }
          },
          {
            $group: {
              _id: "$driverId",
              averageRating: { $avg: "$rating" } // Calculate average of ratings
            }
          }
        ]);
  
        // Result will be an array with one element containing _id and averageRating fields ===
        if (driverRating.length > 0) {
          averageRating = driverRating[0].averageRating;
        }
        currentRide[0].tripId.driverId['averageRating'] = averageRating;
      }

      // decides whether user can cancel current ride or not ======
      let tripStatusLog = await tripStatusLogModel.findOne({
        tripId: currentRide[0].tripId._id,
        passengerId: req.user._id,
      });
      let canCancel = true;
      let passengerStatus = "pending";
      if(tripStatusLog){
        canCancel = false;
        passengerStatus = tripStatusLog.status;
      }
      currentRide[0]['canCancel'] = canCancel;
      currentRide[0]['passengerStatus'] = passengerStatus;
      // decides whether user can cancel current ride or not ======

      return res.status(200).json({
        status: true,
        message: "Trip found.",
        data: currentRide,
      });
    } else {
      return res.status(200).json({
        status: true,
        message: "No trip found.",
        data: {},
      });
    }
  });
  static currentRideForStudent = catchAsyncErrors(async (req, res, next) => {
    let { studentId, schoolId, } = req.body;
    let userRides = await tripPassengerModel.find({
      userId: studentId,
      isCancelled: false,
    }).populate([
      {
        "path": "tripId",
        "model": "tripsCollection",
        "populate": [
          {
            "path": "tripPlanId",
            "model": "tripPlanCollection",
            "populate": [
              {
                "path": "routeId",
                "model": "routeMapCollection",
              },
              {
                "path": "stops.tripStopId",
                "model": "tripStopCollection",
              },
            ],
          },
          {
            "path": "driverId",
            "model": "driverCollection",
            "populate": {
              "path": "userId",
              "model": "usersCollection"
            },
          },
          {
            "path": "vehicleId",
            "model": "vehicleCollection",
            "populate": {
              "path": "modelId",
              "model": "vehicleModelCollection",
              "populate": {
                "path": "type",
                "model": "vehicleCategoriesCollection"
              },
            },
          }
        ],
      },
      {
        "path": "pickupStopId",
        "model": "tripStopCollection"
      },
      {
        "path": "dropStopId",
        "model": "tripStopCollection"
      },
    ]).lean();
    // Get the current time in "Asia/Kolkata" time zone =======
    let momentKolkata = moment().tz("Asia/Kolkata");
    let currentDate = momentKolkata.format("YYYY-MM-DD");
    let currentDay = momentKolkata.format("dddd");
    // let currentTime = momentKolkata.format('HH:mm');
    // Get the current time in "Asia/Kolkata" time zone =======
    let currentTime = new Date();
    let currentRide = userRides.filter((ride) => {
      let startTime = new Date(
        dateFormat(ride.tripId.tripDate) + " " + ride.tripId.tripStartTime
      );
      let endTime = new Date(
        dateFormat(ride.tripId.tripDate) + " " + ride.tripId.tripEndTime
      );

      if (currentTime >= startTime && currentTime <= endTime) {
        return ride;
      }
    });
    // console.log("currentRide[0].tripId =>");
    // console.log(currentRide[0].tripId);
    
    if (currentRide.length > 0) {
      let averageRating = '';
      if(currentRide[0].tripId.driverId){
        let driverRating = await driverFeedbackModel.aggregate([
          {
            $match: {
              driverId: currentRide[0].tripId.driverId.userId._id, 
              isDeleted: false,
            }
          },
          {
            $group: {
              _id: "$driverId",
              averageRating: { $avg: "$rating" } // Calculate average of ratings
            }
          }
        ]);
        // console.log("driverRating =>");
        // console.log(driverRating);

        // Result will be an array with one element containing _id and averageRating fields ===
        if (driverRating.length > 0) {
          averageRating = (driverRating[0]?.averageRating)? driverRating[0]?.averageRating : 0.0;
        }
      }

      // currentRide[0].tripId.driverId['averageRating'] = averageRating;
      currentRide[0].averageRating = averageRating;

      // decides whether user can cancel current ride or not ======
      // console.log("currentRide[0].tripId._id ===>");
      // console.log(currentRide[0].tripId._id);
      
      let tripStatusLog = await tripStatusLogModel.findOne({
        tripId: currentRide[0].tripId._id,
        passengerId: studentId,
      });
      // console.log("tripStatusLog ====>");
      // console.log(tripStatusLog);
      
      let canCancel = true;
      let passengerStatus = "pending";
      if(tripStatusLog){
        canCancel = false;
        passengerStatus = tripStatusLog.status;
      }
      currentRide[0]['canCancel'] = canCancel;
      currentRide[0]['passengerStatus'] = passengerStatus;
      // decides whether user can cancel current ride or not ======

      return res.status(200).json({
        status: true,
        message: "Trip found.",
        data: currentRide,
      });
    } else {
      return res.status(200).json({
        status: true,
        message: "No trip found.",
        data: {},
      });
    }
  });

  static saveRoute = catchAsyncErrors(async (req, res, next) => {
    let { pickupStopId, dropStopId } = req.body;
    let route = await savedRouteModel.findOne({
      pickupStopId: pickupStopId,
      dropStopId: dropStopId,
      userId: req.user._id,
    });
    if (!route) {
      let data = {
        pickupStopId: pickupStopId,
        dropStopId: dropStopId,
        userId: req.user._id,
      };
      let updated = await super.create(res, savedRouteModel, data);
    }
    let list = await savedRouteModel.find({ userId: req.user._id });
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: list,
    });
  });
  static savedRouteList = catchAsyncErrors(async (req, res, next) => {
    let list = await savedRouteModel.find({ userId: req.user._id }).populate(
      [
        {
          "path": "userId",
          "model": "usersCollection",
        },
        {
          "path": "pickupStopId",
          "model": "tripStopCollection",
        },
        {
          "path": "dropStopId",
          "model": "tripStopCollection",
        },
      ]
    );
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: list,
    });
  });
  static deleteSavedRoute = catchAsyncErrors(async (req, res, next) => {
    const { id } = req.body;
    const updated = await super.deleteById(savedRouteModel, id);
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: updated,
    });
  });

	static tripScheduleForDriver = catchAsyncErrors(async (req, res, next) => {
    let loggedDriver = await driverModel.findOne({
      userId: req.user._id,
    });

    // Get the current time in "Asia/Kolkata" time zone =======
    let momentKolkata = moment().tz("Asia/Kolkata");
    let currentDate = momentKolkata.format("YYYY-MM-DD");
    let currentDay = momentKolkata.format("dddd");
    // let currentTime = momentKolkata.format('HH:mm');
    // Get the current time in "Asia/Kolkata" time zone =======

    let driverTrips = await tripsModel.find({
			isCancelled: false,

			tripDate: currentDate,
			driverId: loggedDriver._id,
		}).populate([
			{
				path: "tripPlanId",
				model: "tripPlanCollection",
				populate: [
					{
						path: "vendorId",
						model: "corporateCollection",
					},
					{
						path: "corporateId",
						model: "corporateCollection",
					},
				],
			},
			{
				path: "vehicleId",
				model: "vehicleCollection",
				populate: {
					path: "modelId",
					model: "vehicleModelCollection",
				},
			},
		]);
    await tripStopModel.populate(
			driverTrips, 
			[
				{
					path: "tripPlanId.stops.tripStopId",
					model: "tripStopCollection",
				},
			]
		);

		if(driverTrips.length > 0){
			return res.status(200).json({
				status: true,
				message: "Trips Found",
				data: driverTrips,
			});
		} else {
			return res.status(200).json({
				status: true,
				message: "No Trips Found",
				data: [],
			});
		}
  });
	static currentUpcomingCompletedTripsForDriver = catchAsyncErrors(async (req, res, next)=>{
		let loggedDriver = await driverModel.findOne({
      userId: req.user._id,
    });

    // Get the current time in "Asia/Kolkata" time zone =======
    let momentKolkata = moment().tz("Asia/Kolkata");
    let currentDate = momentKolkata.format("YYYY-MM-DD");
    let currentDay = momentKolkata.format("dddd");
    // let currentTime = momentKolkata.format('HH:mm');
    // Get the current time in "Asia/Kolkata" time zone =======

    let driverTrips = await tripsModel.find({
			isCancelled: false,
			driverId: loggedDriver._id,
		}).populate([
			{
				path: "tripPlanId",
				model: "tripPlanCollection",
				populate: [
					{
						path: "vendorId",
						model: "corporateCollection",
					},
					{
						path: "corporateId",
						model: "corporateCollection",
					},
				],
			},
			{
				path: "vehicleId",
				model: "vehicleCollection",
				populate: {
					path: "modelId",
					model: "vehicleModelCollection",
				},
			},
		]);
    await tripStopModel.populate(
			driverTrips, 
			[
				{
					path: "tripPlanId.stops.tripStopId",
					model: "tripStopCollection",
				},
			]
		);

		let currentTrip = [];
		let upcomingTrips = [];
		let completedTrips = [];
		driverTrips.filter((trip)=>{
			let startTime = new Date(dateFormat(trip.tripDate)+" "+trip.tripStartTime)
			let endTime = new Date(dateFormat(trip.tripDate)+" "+trip.tripEndTime)
			let currentTime = new Date()
      
			if(
				((startTime <= currentTime) && (endTime >= currentTime)) 
				// && ((trip.tripStatus == "Started") || (trip.tripStatus == "Paused")) || (trip.tripStatus == "Pending")
			){
				currentTrip.push(trip)
			} else if(
				((startTime > currentTime))
			){
				upcomingTrips.push(trip)
			} else if(
				((startTime < currentTime) && (endTime < currentTime)) &&
				(trip.tripStatus == "Completed")
			){
				completedTrips.push(trip)
			}

		});
		if(driverTrips.length > 0){
			return res.status(200).json({
				status: true,
				message: "Trips Found.",
				data: {
					currentTrip: currentTrip,
					upcomingTrips: upcomingTrips,
					completedTrips: completedTrips,
				}
			});
		} else {
			return res.status(200).json({
				status: true,
				message: "No Trips Found.",
				data: []
			});
		}
	});

	static tripStatusUpdate = catchAsyncErrors(async (req, res, next)=>{
		let { tripId, tripStatus } = req.body;
		// tripStatus => [enum] => ["Pending" ,"Started", "Paused", "Resumed", "Completed"];

		let updateFields = {
			tripStatus: tripStatus
		};
		let tripStatusUpdate = await super.statusChange(tripsModel, tripId, updateFields);
    if(tripStatusUpdate){
      // ========== send push notification to corporate and vendor about trip-status ==========
      try {
        let tripDetails = await tripsModel.findOne({
          _id: tripId
        }).populate([
          {
            "path": "tripPlanId",
            "model": "tripPlanCollection",
            "populate": [
              {
                "path": "routeId",
                "model": "routeMapCollection",
              },
              {
                "path": "corporateId",
                "model": "corporateCollection",
                "populate": {
                  "path": "userId",
                  "model": "usersCollection",
                }
              },
              {
                "path": "vendorId",
                "model": "corporateCollection",
                "populate": {
                  "path": "userId",
                  "model": "usersCollection",
                }
              },
            ]
          },
        ]);
        
        let corporateFcm = tripDetails.tripPlanId.corporateId.userId.fcmToken;
        let vendorFcm = tripDetails.tripPlanId.vendorId.userId.fcmToken;
        
        if (corporateFcm) {
          console.log("------ Sending Notification to corporate ----");
          if(tripStatus == "Started"){
            let messages = {
              title: "Trip started.",
              body: JSON.stringify({
                "tripId": `${tripId.toString()}`,
                "msg": `Dear Corporate, Trip for ${tripDetails.tripPlanId.routeId.routeName} route has been started.`,
                "type": "Show"
              }),
            };
            // console.log("messages ---->", messages);
      
            await sendPushNotification(corporateFcm.toString(), messages, "android");
          }
        }
        if(vendorFcm){
          console.log("------ Sending Notification to vendor ----");
          if(tripStatus == "Started"){
            let messages = {
              title: "Trip started.",
              body: JSON.stringify({
                "tripId": `${tripId.toString()}`,
                "msg": `Dear Vendor, Trip for ${tripDetails.tripPlanId.routeId.routeName} route has been started.`,
                "type": "Show"
              }),
            };
            // console.log("messages ---->", messages);
      
            await sendPushNotification(vendorFcm.toString(), messages, "android");
          }
        }
      } catch (error) {
        console.error("Error sending notification to vendor or corporate:", error.message);
        // Handle or propagate the error as needed
      }
      // ========== send push notification to corporate and vendor about trip-status ==========

      let passengersOfTrip = await tripPassengerModel.find({
        isCancelled: false,

        tripId: tripId,
      }).populate(
        [
          {
						"path": "userId",
						"model": "usersCollection",
            "populate": {
              "path": "roleId",
              "model": "roleCollection",
            }
					},
        ]
      );
      // console.log("passengersOfTrip =====>");
      // console.log(passengersOfTrip);
      
      let passengerIdsArr = [];
      let parentIdsArr = [];
      if(passengersOfTrip.length > 0){
        // passengers found ====
        const promises = passengersOfTrip.map(async (passenger)=>{
          if(passenger.userId.roleId.name != "Student"){
            // console.log(`inside : passenger.userId.roleId.name != "Student"`);
            
            // ---- for passengers other than students ----
            passengerIdsArr.push(passenger.userId._id.toString());
            // ---- for passengers other than students ----
          }
          if(passenger.userId.roleId.name == "Student"){
            // console.log(`inside : passenger.userId.roleId.name == "Student"`);
            // ---- for students ---- finding the poor hapless PARENT of the student ---- 
            let parentCustomer = await customerModel.findOne({
              "corporates": {
                $elemMatch: {
                  "studentId": passenger.userId._id,
                }
              }
            });
            // console.log("parentCustomer ===>");
            // console.log(parentCustomer);
            

            if(parentCustomer){
              // console.log("ParentCustomer found");
              // ---- parent userID of the student being pushed ---- 
              parentIdsArr.push(parentCustomer.userId);
              // ---- parent userID of the student being pushed ---- 

              // console.log("inside parentIdsArr =======>");
              // console.log(parentIdsArr);
            }
          }
        });
        // Wait for all promises to resolve
        await Promise.all(promises);

        // console.log("passengerIdsArr =======>");
        // console.log(passengerIdsArr);
        
        // console.log("outside log : parentIdsArr =======>");
        // console.log(parentIdsArr);
        // ==============================================================
        // === send notification to all passengers of passengerIdsArr ===
        // ==============================================================
        if(passengerIdsArr.length > 0){
          passengerIdsArr.forEach(async (passenger) => {
            try {
              let user = await userModel.findOne({ _id: passenger });
              // console.log("user.fcmToken ====>", user.fcmToken);
              
              let tripDetails = await tripsModel.findOne({
                _id: tripId
              }).populate([
                {
                  "path": "tripPlanId",
                  "model": "tripPlanCollection",
                  "populate": {
                    "path": "routeId",
                    "model": "routeMapCollection",
                  }
                },
              ]);
              if (user.fcmToken) {
                console.log("------ Sending Trip Start Notification ----");
                if(tripStatus == "Started"){
                  let messages = {
                    title: "Trip started.",
                    body: JSON.stringify({
                      "tripId": `${tripId.toString()}`,
                      "msg": `Dear ${user.firstName}, trip for ${tripDetails.tripPlanId.routeId.routeName} route has been started and will be reaching your stop soon`,
                      "type": "Show"
                    }),
                  };
                  // console.log("messages ---->", messages);
            
                  await sendPushNotification(user.fcmToken.toString(), messages, "android");
                }
              }
            } catch (error) {
              console.error("Error sending trip start notification:", error.message);
              // Handle or propagate the error as needed
            }
          });
        }
        // ==============================================================
        // === send notification to all passengers of passengerIdsArr ===
        // ==============================================================

        // ==============================================================
        // ====== send notification to all parents of parentIdsArr ======
        // ==============================================================
        if(parentIdsArr.length > 0){
          // console.log("attempting to send noti");
          
          parentIdsArr.forEach(async (parentOfstudent) => {
            try {
              let user = await userModel.findOne({ _id: parentOfstudent });
              // console.log("parent => user.fcmToken ====>", user.fcmToken);
              
              let tripDetails = await tripsModel.findOne({
                _id: tripId
              }).populate([
                {
                  "path": "tripPlanId",
                  "model": "tripPlanCollection",
                  "populate": {
                    "path": "routeId",
                    "model": "routeMapCollection",
                  }
                },
              ]);
              if (user.fcmToken) {
                console.log("------ Sending Trip Start Notification to Parent of student ----");
                if(tripStatus == "Started"){
                  let messages = {
                    title: "Trip started.",
                    body: JSON.stringify({
                      "tripId": `${tripId.toString()}`,
                      "msg": `Dear Parent, ${user.firstName}, trip for ${tripDetails.tripPlanId.routeId.routeName} route for your child has been started.`,
                      "type": "Show"
                    }),
                  };
                  // console.log("messages ---->", messages);
            
                  await sendPushNotification(user.fcmToken.toString(), messages, "android");
                }
              }
            } catch (error) {
              console.error("Error sending trip start notification to parent:", error.message);
              // Handle or propagate the error as needed
            }
          });
        }
        // ==============================================================
        // ====== send notification to all parents of parentIdsArr ======
        // ==============================================================
      } else {
        console.log("No passengers found for this trip. No tripStart notification should fire.");
        
      }

      return res.status(200).json({
        status: true,
        message: "Success.",
        data: tripStatusUpdate
      });
    } else{
      return res.status(400).json({
        status: false,
        message: "Failed to update status of trip",
        data: {}
      });
    }
	});

	static tripStopListForDriver = catchAsyncErrors(async (req, res, next)=>{
		let { tripId } = req.body;

		let tripDetail = await tripsModel.findOne({
			_id: tripId,

			isCancelled: false,
		}).populate(
			[
				{
					"path": "tripPlanId",
					"model": "tripPlanCollection",
				},
			]
		).lean();
		await tripPlanModel.populate(
			tripDetail,
			[
				{
					"path": "tripPlanId.stops.tripStopId",
					"model": "tripStopCollection",
				},
			]
		);
		
    let startTime = dateFormat(tripDetail.tripDate) +" "+ tripDetail.tripStartTime + ":00";

    tripDetail.tripPlanId.stops.forEach((stop)=>{
      startTime = new Date(startTime);
      let seconds = stop.time * 3600;
      if(seconds > 0){
        startTime = startTime.setSeconds(startTime.getSeconds() + seconds);
      }
      stop['eta'] = new Date(startTime);
    });

    let tripStopList = tripDetail.tripPlanId.stops;

		let tripPassengers = await tripPassengerModel.find({
			tripId: tripId,

			isCancelled: false,
		});

		let tripStopsWithPassengers = tripStopList.map((stop)=>{
			let count = 0;
			tripPassengers.forEach((passenger)=>{
				if(stop.tripStopId._id.toString() == passenger.pickupStopId.toString()){
					count++;
				}
			});
			stop.passengersCount = count;
			
			return stop;
		});

		return res.status(200).json({
			status: true,
			message: "Success",
			data: tripStopsWithPassengers
		})
	});

  static seatsAvailabilityCheck = catchAsyncErrors(async (req, res, next)=>{
    let { tripId } = req.body;

    let tripPassengerCount = 0;

    let trip = await tripsModel.findOne({
      _id: tripId
    }).populate([
      {
        "path": "tripPlanId",
        "model": "tripPlanCollection"
      },
    ]);
    let tripCapacity = trip.tripPlanId.accessibility;

    tripPassengerCount = await tripPassengerModel.countDocuments({
      tripId: tripId,
      isCancelled: false,
    });

    let seatsAvailable = Number(tripCapacity) - Number(tripPassengerCount);

    return res.status(200).json({
      status: 200,
      message: "Success",
      data: {
        tripCapacity: tripCapacity,
        tripPassengerCount: tripPassengerCount,
        seatsAvailable: seatsAvailable,
      }
    });
  });

  static getTripDetail = catchAsyncErrors(async (req, res, next)=>{
    let { tripId } = req.body;
    let tripDetail = await tripsModel.findOne({
      _id: tripId
    }).lean().populate([
      {
        "path": "tripPlanId",
        "model": "tripPlanCollection",
        "populate": [
          {
            "path": "routeId",
            "model": "routeMapCollection",
          },
          {
            "path": "vendorId",
            "model": "corporateCollection",
          },
          {
            "path": "corporateId",
            "model": "corporateCollection",
          },
        ]
      },
      {
        "path": "vendorId",
        "model": "corporateCollection",
        "populate": {
          "path": "userId",
          "model": "usersCollection",
        }
      },
      {
        "path": "driverId",
        "model": "driverCollection",
        "populate": {
          "path": "userId",
          "model": "usersCollection",
        }
      },
      {
        "path": "vehicleId",
        "model": "vehicleCollection",
        "populate": {
          "path": "modelId",
          "model": "vehicleModelCollection",
          "populate": {
            "path": "type",
            "model": "vehicleCategoriesCollection",
          }
        }
      },
    ]);
    await tripStopModel.populate(tripDetail, [
      {
        "path": "tripPlanId.stops.tripStopId",
        "model": "tripStopCollection"
      }
    ]);

    // console.log("tripDetail ===>");
    // console.log(tripDetail);

    if(tripDetail){
      // ===== rating ========
      let averageDriverRating = '';
      let averageVehicleRating = '';
      if(tripDetail.driverId){
        let driverRating = await driverFeedbackModel.aggregate([
          {
            $match: {
              driverId: tripDetail.driverId.userId._id, 
              isDeleted: false,
            }
          },
          {
            $group: {
              _id: "$driverId",
              averageRating: { $avg: "$rating" } // Calculate average of ratings
            }
          }
        ]);
        // Result will be an array with one element containing _id and averageRating fields ===
        if (driverRating.length > 0) {
          averageDriverRating = driverRating[0].averageRating;
        }
      }
      tripDetail['averageDriverRating'] = averageDriverRating;
      if(tripDetail.vehicleId){
        let vehicleRating = await vehicleFeedbackmodel.aggregate([
          {
            $match: {
              vehicleId: tripDetail.vehicleId._id, 
              isDeleted: false,
            }
          },
          {
            $group: {
              _id: "$vehicleId",
              averageRating: { $avg: "$rating" } // Calculate average of ratings
            }
          }
        ]);
        // Result will be an array with one element containing _id and averageRating fields ===
        if (vehicleRating.length > 0) {
          averageVehicleRating = vehicleRating[0].averageRating;
        }
      }
      tripDetail['averageVehicleRating'] = averageVehicleRating;
      return res.status(200).json({
        status: true,
        message: "Success",
        data: tripDetail
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "No Detail found.",
        data: {}
      });
    }
  });
  static tripDetailForApp = catchAsyncErrors(async (req, res, next)=>{
    let { lat, long, tripId } = req.body;
    let tripDetail = await tripPassengerModel.findOne({
      userId: req.user._id,
      tripId: tripId
    }).populate([
      {
        "path": "tripId",
        "model": "tripsCollection",
        "populate": [
          {
            "path": "tripPlanId",
            "model": "tripPlanCollection",
            "populate": [
              {
                "path": "routeId",
                "model": "routeMapCollection",
              },
              {
                "path": "vendorId",
                "model": "corporateCollection",
              },
              {
                "path": "corporateId",
                "model": "corporateCollection",
              },
            ]
          },
          {
            "path": "vendorId",
            "model": "corporateCollection",
            "populate": {
              "path": "userId",
              "model": "usersCollection",
            }
          },
          {
            "path": "driverId",
            "model": "driverCollection",
            "populate": {
              "path": "userId",
              "model": "usersCollection",
            }
          },
          {
            "path": "vehicleId",
            "model": "vehicleCollection",
            "populate": {
              "path": "modelId",
              "model": "vehicleModelCollection",
              "populate": {
                "path": "type",
                "model": "vehicleCategoriesCollection",
              }
            }
          },
        ]
      },
      {
        "path": "pickupStopId",
        "model": "tripStopCollection",
      },
      {
        "path": "dropStopId",
        "model": "tripStopCollection",
      },
    ]).lean();

    await tripStopModel.populate(
      tripDetail,
      [
        {
          path: "tripPlanId.stops.tripStopId",
          model: "tripStopCollection",
        },
      ]
    );
    // return res.status(200).json({
    //   data: tripDetail
    // });
    // ===== rating ========
    let averageDriverRating = '';
    let averageVehicleRating = '';
    if(tripDetail.driverId){
      let driverRating = await driverFeedbackModel.aggregate([
        {
          $match: {
            driverId: tripDetail.tripId.driverId.userId._id, 
            isDeleted: false,
          }
        },
        {
          $group: {
            _id: "$driverId",
            averageRating: { $avg: "$rating" } // Calculate average of ratings
          }
        }
      ]);
      // Result will be an array with one element containing _id and averageRating fields ===
      if (driverRating.length > 0) {
        averageDriverRating = driverRating[0].averageRating;
      }
      tripDetail.driverId['averageRating'] = averageDriverRating;
    }
    if(tripDetail.vehicleId){
      let vehicleRating = await vehicleFeedbackmodel.aggregate([
        {
          $match: {
            vehicleId: tripDetail.tripId.vehicleId._id, 
            isDeleted: false,
          }
        },
        {
          $group: {
            _id: "$vehicleId",
            averageRating: { $avg: "$rating" } // Calculate average of ratings
          }
        }
      ]);
      // Result will be an array with one element containing _id and averageRating fields ===
      if (vehicleRating.length > 0) {
        averageVehicleRating = vehicleRating[0].averageRating;
      }
      tripDetail.vehicleId['averageRating'] = averageVehicleRating;
    }

    // ===== ETA calculation =====
    let originLat = lat.toString();
    let originLong = long.toString();
    
    let tripStartLat = tripDetail.pickupStopId.location.coordinates[0].toString();
    let tripStartLong = tripDetail.pickupStopId.location.coordinates[1].toString();
    let config = {
      method: 'get',
      maxBodyLength: Infinity,
      url: `https://maps.googleapis.com/maps/api/distancematrix/json?origins=${originLat},${originLong}&destinations=${tripStartLat},${tripStartLong}&mode=walking&key=${GoogleApiKey}`,
      headers: { }
    };
    await axios.request(config).then(async (response) => {
      // console.log(response.data.rows);
      // console.log(response?.data?.rows[0]?.elements[0]?.duration?.text);
      tripDetail.pickupStopId['eta'] = response?.data?.rows[0]?.elements[0]?.duration?.text;
    });

    if(tripDetail){
      return res.status(200).json({
        status: true,
        message: "Success",
        data: tripDetail
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "No Detail found.",
        data: {}
      });
    }
  });

  static tripBookingsStopwise = catchAsyncErrors(async (req, res, next) => {
    let { tripId, pickupStopId } = req.body;

    let bookings = await tripPassengerModel.find(
      { 
        tripId: tripId, 
        pickupStopId: pickupStopId,

        isCancelled: false,
      }
    ).populate([
      {
        path: "userId",
        model: "usersCollection",
      },
    ]).lean();

    if (bookings.length > 0) {
      bookings.forEach(async (val, index) => {
        let pickup = await tripStopModel.findOne({ _id: val.pickupStopId });
        let drop = await tripStopModel.findOne({ _id: val.dropStopId });
        val["pickupStop"] = pickup.stopName;
        val["dropStop"] = drop.stopName;
        let passengerAttendance = await tripStatusLogModel.findOne({
          tripId: tripId,
          passengerId: val.userId._id
        });
        val["boardingStatus"] = "Pending";
        if(passengerAttendance){
          val["boardingStatus"] = ((passengerAttendance.inTime) && !(passengerAttendance.outTime))
              ? "Onboarded" 
              : ((passengerAttendance.inTime) && (passengerAttendance.outTime))
                ? "Dropped Off"
                :"Pending";
        }
        if (index == bookings.length - 1) {
          return requestHandler.sendSuccess(
            res,
            "Successful"
          )({
            data: bookings,
          });
        }
      });
    } else {
      return requestHandler.sendSuccess(
        res,
        "Successful"
      )({
        data: [],
      });
    }
  });
  // ============== App APIs ===================
}

module.exports = TripController;
