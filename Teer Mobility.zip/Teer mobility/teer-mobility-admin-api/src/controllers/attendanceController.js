const axios = require("axios");
const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/errorHandler");
const RequestHandler = require("../utils/RequestHandler");
const bcrypt = require("bcryptjs");
const JWTAuth = require("../utils/jwtToken");
const jwt = require("jsonwebtoken");
const jwtConfig = require("../config").JWT;
const sendPushNotification = require("../helpers/sendPushNotification");

const {
  calculateDistance,
  calculateDistanceInsTentApi,
  calculateTimeInKilometers,
  getRateChartCategory,
} = require("../utils/utilities");
const {
  MSG_RECORD_STATUS_SUCCESS,
  MSG_RECORD_FETCH_SUCCESS,
} = require("../config/constants");
const requestHandler = new RequestHandler();

const moment2 = require('moment');
const moment = require('moment-timezone');
const dateFns = require('date-fns');

const userModel = require("../models/userModel");
const temporaryOtpModel = require("../models/temporaryOtpModel");
const attendanceModel = require("../models/attendanceModel");
const tripStatusLogModel = require("../models/tripStatusLogModel");
const tripPassengerModel = require("../models/tripPassengerModel");
const tripsModel = require("../models/tripsModel");
const customerModel = require("../models/customerModel");

class AttendanceController extends BaseController {
  constructor() {
    super();
  }

  // =============================== App APIs ===========================
  static sendOtpForAttendance = catchAsyncErrors(async (req, res, next) => {
    // let { userId } = req.body;

    let loggedUser = await userModel.findById(req.user._id);

    // Get the current time in "Asia/Kolkata" time zone =======
    let momentKolkata = moment().tz("Asia/Kolkata");
    let currentDate = momentKolkata.format("YYYY-MM-DD");
    let currentDay = momentKolkata.format("dddd");
    let currentTime = momentKolkata.format("HH:mm");
    // Get the current time in "Asia/Kolkata" time zone =======

    // Add one day to the current date ==========
    let nextDay = moment(currentDate).add(1, "days").format("YYYY-MM-DD");

    // Generate a random 4-digit number ==========
    let otp = Math.floor(1000 + Math.random() * 9000);

    let otpObj = {
      phone: loggedUser.phone,
      otp: {
        code: otp,
        expiration: nextDay,
      },
    };
    let checkOtpExists = await super.getByCustomOptionsSingle(
      req,
      temporaryOtpModel,
      {
        phone: loggedUser.phone,
      }
    );

    let updated = checkOtpExists
      ? await super.updateById(
          temporaryOtpModel,
          checkOtpExists._id.toString(),
          otpObj
        )
      : await super.create(res, temporaryOtpModel, otpObj);

    if (updated) {
      return res.status(200).json({
        status: true,
        message: "OTP Sent.",
        data: {
          phone: loggedUser.phone,
          // email: email,
          otp: otp,
        },
      });
    } else {
      return res.status(500).json({
        status: false,
        message: "Oops.. Something went terribly wrong..!!",
        data: {},
      });
    }
  });

  static getOtpForAttendance = catchAsyncErrors(async (req, res, net) => {
    let loggedUser = await userModel.findById(req.user._id);

    let tempOtp = await temporaryOtpModel.findOne({
      phone: loggedUser.phone,
    });

    if (tempOtp) {
      return res.status(200).json({
        status: true,
        message: "Please use this otp for the ride.",
        data: tempOtp.otp.code,
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Oops.. Something went terribly wrong..!!",
        data: {},
      });
    }
  });

  static markAttendance = catchAsyncErrors(async (req, res, next) => {
    let { otp, routeId, inTime, outTime, inLat, inLong, outLat, outLong } = req.body;

    // Get the current time in "Asia/Kolkata" time zone =======
    let momentKolkata = moment().tz("Asia/Kolkata");
    let currentDate = momentKolkata.format("YYYY-MM-DD");
    let currentDay = momentKolkata.format("dddd");
    let currentTime = momentKolkata.format("HH:mm");
    // Get the current time in "Asia/Kolkata" time zone =======

    let loggedUser = await userModel.findById(req.user._id);
    let checkOtpExists = await super.getByCustomOptionsSingle(
      req,
      temporaryOtpModel,
      {
        phone: loggedUser.phone,
      }
    );
	let checkAttendanceExistsForTheDay = await attendanceModel.findOne({
		userId: req.user._id,
		date: currentDate,
	});
    if (
      checkOtpExists.otp.expiration.toISOString().split("T")[0] != currentDate
    ) {
      if (checkOtpExists.otp.code == otp) {
        // ============ OTP valid ===========
        let attendanceObj = {
          userId: req.user._id,
          // routeId: routeId,
          date: currentDate,
          // inTime: inTime,
          // outTime: outTime,
          // workTime: workTime,
        };
        if (routeId) {
          attendanceObj.routeId = routeId;
        }
        if (inTime) {
          attendanceObj.inTime = inTime;
        }
        if (outTime) {
          attendanceObj.outTime = outTime;

		  let momentKolkata = moment().tz("Asia/Kolkata");
		  // Parse the times into moment objects
		  inTime = checkAttendanceExistsForTheDay.inTime;
		  // Parse the times into moment objects with the specified timezone
		  const start = momentKolkata.clone().set({ hour: parseInt(inTime.split(':')[0]), minute: parseInt(inTime.split(':')[1]) });
		  const end = momentKolkata.clone().set({ hour: parseInt(outTime.split(':')[0]), minute: parseInt(outTime.split(':')[1]) });
		  // Calculate the difference in minutes
		  const duration = moment2.duration(end.diff(start));
		  // Convert the duration to hours
		  const workTime = duration.asHours();
          attendanceObj.workTime = workTime;
        }
        if (inLat && inLong) {
          attendanceObj.inCoOrdinates = [inLat, inLong];
        }
        if (outLat && outLong) {
          attendanceObj.outCoOrdinates = [outLat, outLong];
        }

        let markAttendance = checkAttendanceExistsForTheDay
          ? await super.updateById(
              attendanceModel,
              checkAttendanceExistsForTheDay._id.toString(),
              attendanceObj
            )
          : await super.create(res, attendanceModel, attendanceObj);

        if (markAttendance) {
          return res.status(200).json({
            status: true,
            message: "Success",
            data: markAttendance,
          });
        } else {
          return res.status(400).json({
            status: false,
            message: "Something wrong happened.",
            data: {},
          });
        }
      } else {
        return res.status(400).json({
          status: false,
          message: "Invalid OTP.",
          data: {},
        });
      }
    } else {
      return res.status(200).json({
        status: true,
        message: "OTP expired.",
        data: {},
      });
    }
  });

  static markAttendanceForPassenger = catchAsyncErrors(async (req, res, next) => {
    // =================================================================
    // passenger-attendance marking : 1. with OTP, 2. without OTP ======
    // =================================================================
    let { passengerId, otp, tripId, inTime, outTime, lat, long, status } = req.body;

    // Get the current time in "Asia/Kolkata" time zone =======
    let momentKolkata = moment().tz("Asia/Kolkata");
    let currentDate = momentKolkata.format("YYYY-MM-DD");
    let currentDateTime = momentKolkata.format("YYYY-MM-DD HH:mm:ss");
    let currentDay = momentKolkata.format("dddd");
    let currentTime = momentKolkata.format("HH:mm");
    // Get the current time in "Asia/Kolkata" time zone =======

    // let passenger = await userModel.findById(passengerId);
    let trip = await super.getByCustomOptionsSingle(req, tripPassengerModel, {
      userId: passengerId,
      tripId: tripId,
    });
    await tripsModel.populate(trip, [
      {
        path: "tripId",
        model: "tripsCollection",
        populate: {
          path: "tripPlanId",
          model: "tripPlanCollection",
          populate: {
            path: "routeId",
            model: "routeMapCollection",
          },
        },
      },
    ]);

    if (otp && otp != "" && otp != null) {
      // ====================== with OTP ======================
      if (trip.otp == otp) {
        // ============ OTP valid ===========
        let attendanceObj = {
          tripId: tripId,
          status: status,
        };
        if (passengerId) {
          attendanceObj.passengerId = passengerId;
        }
        if (inTime) {
          attendanceObj.inTime = inTime;
        }
        if (outTime) {
          attendanceObj.outTime = outTime;
        }
        if (lat && long) {
          attendanceObj.coOrdinates = [lat, long];
        }
        let checkExist = await tripStatusLogModel.findOne({
          tripId: tripId,
          passengerId: passengerId,
          status: "Onboarding",
        });

        let logged =
          checkExist && checkExist != null && checkExist != ""
            ? await super.updateById(
                tripStatusLogModel,
                checkExist._id,
                attendanceObj
              )
            : await super.create(res, tripStatusLogModel, attendanceObj);

        if (logged) {
          console.log(`------ Sending passenger ${status} Notification ----`);
          let user = await userModel.findOne({
            _id: passengerId,
          }).populate([
            {
              "path": "roleId",
              "model": "roleCollection",
            },
          ]);
          let fcmToken = "";
          if(user.roleId.name != "Student"){
            // ---- for passengers other than student ----
            fcmToken = user.fcmToken;
            // ---- for passengers other than student ----
          } 
          if (user.roleId.name == "Student") {
            // console.log("for students ---- finding the poor hapless PARENT of the student");
            // ---- for students ---- finding the poor hapless PARENT of the student ---- 
            let parentCustomer = await customerModel.findOne({
              "corporates": {
                $elemMatch: {
                  "studentId": user._id,
                }
              }
            }).populate([
              {
                "path": "userId",
                "model": "usersCollection",
              },
            ]);
            // console.log("parentCustomer ===>");
            // console.log(parentCustomer);

            if(parentCustomer){
              // ---- fcmTOken of parent ----
              fcmToken = parentCustomer.userId.fcmToken;
              // ---- fcmTOken of parent ----
            }
          }
          let messages = {};
          messages = {
            title: `User Attendance`,
            body: JSON.stringify({
              msg: `Dear ${user.firstName},You have ${
                inTime && !outTime ? "boarded" : "deboarded"
              } the ${trip.tripId.tripPlanId.routeId.routeName}.`,
              passengerStatus: `${status}`,
              type: "Show",
            }),
            // body: `Dear ${user.firstName},You have ${(inTime && !outTime)? "boarded":"deboarded"} the ${trip.tripId.tripPlanId.routeId.routeName}.`,
            // type: 1,
          };

          // ======== updating userDeboardTime ========
          let updateTripPassengerWithDropOffTime = await super.updateByCustomOptions(
            tripPassengerModel, 
            {
              userId: user._id,
              tripId: tripId,
            },
            {
              dropoffReachTime: currentDateTime
            },
          ); 

          if(updateTripPassengerWithDropOffTime){
            console.log("DropOff time updated in DB.");
          } else{
            console.log("Problem updating dropOff time in DB.");
          }
          // ======== updating userDeboardTime ========
          if(fcmToken){
            console.log(`------ User Attendance notification sent ----`);
            await sendPushNotification(fcmToken, messages, "android");
          } else {
            console.log(`------ No FCM token found, User Attendance notification can not be sent ----`);
          }

          return res.status(200).json({
            status: true,
            message: "Success",
            data: logged,
          });
        } else {
          return res.status(400).json({
            status: false,
            message: "Something wrong happened.",
            data: {},
          });
        }
      } else {
        return res.status(200).json({
          status: true,
          message: "Invalid OTP.",
          data: {},
        });
      }
    } else {
      // ====================== without OTP ======================
      // ============ mark attendance with swipe =================
      let attendanceObj = {
        tripId: tripId,
        status: status,
      };
      if (passengerId) {
        attendanceObj.passengerId = passengerId;
      }
      if (inTime) {
        attendanceObj.inTime = inTime;
      }
      if (outTime) {
        attendanceObj.outTime = outTime;
      }
      if (lat && long) {
        attendanceObj.coOrdinates = [lat, long];
      }
      let checkExist = await tripStatusLogModel.findOne({
        tripId: tripId,
        passengerId: passengerId,
        status: "Onboarding",
      });
      let logged =
        checkExist && checkExist != null && checkExist != ""
          ? await super.updateById(
              tripStatusLogModel,
              checkExist._id,
              attendanceObj
            )
          : await super.create(res, tripStatusLogModel, attendanceObj);
      if (logged) {
        console.log(`------ Sending passenger ${status} Notification ----`);
        let user = await userModel.findOne({
          _id: passengerId,
        }).populate([
          {
            "path": "roleId",
            "model": "roleCollection",
          },
        ]);
        let fcmToken = "";
        if(user.roleId.name != "Student"){
          // ---- for passengers other than student ----
          fcmToken = user.fcmToken;
          // ---- for passengers other than student ----
        } 
        if (user.roleId.name == "Student") {
          // console.log("for students ---- finding the poor hapless PARENT of the student");
          // ---- for students ---- finding the poor hapless PARENT of the student ---- 
          let parentCustomer = await customerModel.findOne({
            "corporates": {
              $elemMatch: {
                "studentId": user._id,
              }
            }
          }).populate([
            {
              "path": "userId",
              "model": "usersCollection",
            },
          ]);
          // console.log("parentCustomer ===>");
          // console.log(parentCustomer);

          if(parentCustomer){
            // ---- fcmTOken of parent ----
            fcmToken = parentCustomer.userId.fcmToken;
            // ---- fcmTOken of parent ----
          }
        }
        let messages = {};
        messages = {
          title: `User Attendance`,
          body: JSON.stringify({
            msg: `Dear ${user.firstName},You have ${
              inTime && !outTime ? "boarded" : "deboarded"
            } the ${trip.tripId.tripPlanId.routeId.routeName}.`,
            passengerStatus: `${status}`,
            type: "Show",
          }),
          // body: `Dear ${user.firstName},You have ${(inTime && !outTime)? "boarded":"deboarded"} the ${trip.tripId.tripPlanId.routeId.routeName}.`,
          // type: 1,
        };

        // ======== updating userDeboardTime ========
        let updateTripPassengerWithDropOffTime = await super.updateByCustomOptions(
          tripPassengerModel, 
          {
            userId: user._id,
            tripId: tripId,
          },
          {
            dropoffReachTime: currentDateTime
          },
        ); 

        if(updateTripPassengerWithDropOffTime){
          console.log("DropOff time updated in DB.");
        } else{
          console.log("Problem updating dropOff time in DB.");
        }
        // ======== updating userDeboardTime ========
        if(fcmToken){
          console.log(`------ User Attendance notification sent ----`);
          await sendPushNotification(fcmToken, messages, "android");
        } else {
          console.log(`------ No FCM token found, User Attendance notification can not be sent ----`);
        }

        return res.status(200).json({
          status: true,
          message: "Success",
          data: logged,
        });
        
      } else {
        return res.status(400).json({
          status: false,
          message: "Something wrong happened.",
          data: {},
        });
      }
    }
  });

  static markAttendanceWithoutOtp = catchAsyncErrors(async (req, res, next) => {
    let { routeId, inTime, outTime } = req.body;

    // Get the current time in "Asia/Kolkata" time zone =======
    let momentKolkata = moment().tz("Asia/Kolkata");
    let currentDate = momentKolkata.format("YYYY-MM-DD");
    let currentDay = momentKolkata.format("dddd");
    let currentTime = momentKolkata.format("HH:mm");
    // Get the current time in "Asia/Kolkata" time zone =======

    let attendanceObj = {
      userId: req.user._id,
      // routeId: routeId,
      date: currentDate,
      // inTime: inTime,
      // outTime: outTime,
      // workTime: workTime,
    };
    if (routeId) {
      attendanceObj.routeId = routeId;
    }
    if (inTime) {
      attendanceObj.inTime = inTime;
    }
    if (outTime) {
      attendanceObj.outTime = outTime;
    }
    let checkAttendanceExistsForTheDay = await attendanceModel.findOne({
      userId: req.user._id,
      date: currentDate,
    });

    let markAttendance = checkAttendanceExistsForTheDay
      ? await super.updateById(
          attendanceModel,
          checkAttendanceExistsForTheDay._id.toString(),
          attendanceObj
        )
      : await super.create(res, attendanceModel, attendanceObj);

    if (markAttendance) {
      return res.status(200).json({
        status: true,
        message: "Success",
        data: markAttendance,
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Something wrong happened.",
        data: {},
      });
    }
  });

  static attendanceList = catchAsyncErrors(async (req, res, next) => {
	let { month, year } = req.body;

    // Get the current time in "Asia/Kolkata" time zone =======
    let momentKolkata = moment().tz("Asia/Kolkata");
    let currentDate = momentKolkata.format("YYYY-MM-DD");
    let currentDay = momentKolkata.format("dddd");
    let currentTime = momentKolkata.format("HH:mm");
    // Get the current time in "Asia/Kolkata" time zone =======

	// Create a moment object for the first day of the specified month
	let firstDayOfMonth = moment.tz(`${year}-${month}-01`, "Asia/Kolkata");

	// Get the starting date (first day) of the month in YYYY-MM-DD format
	let startingDate = firstDayOfMonth.format("YYYY-MM-DD");

	// Create a moment object for the last day of the specified month
	let lastDayOfMonth = firstDayOfMonth.clone().endOf('month');

	// Get the end date (last day) of the month in YYYY-MM-DD format
	let endingDate = lastDayOfMonth.format("YYYY-MM-DD");

    let attendances = await attendanceModel
      .find({
        userId: req.user._id,
		date: {
			$gte: startingDate,
			$lte: endingDate,
		},
      })
      .populate([
        {
          path: "userId",
          model: "usersCollection",
        },
        {
          path: "routeId",
          model: "routeMapCollection",
        },
      ]);

    let todayAttendance = await attendanceModel
      .findOne({
        userId: req.user._id,
        date: currentDate,
      })
      .populate([
        {
          path: "userId",
          model: "usersCollection",
        },
        {
          path: "routeId",
          model: "routeMapCollection",
        },
      ]);

    if (attendances.length > 0) {
      return res.status(200).json({
        status: true,
        message: "Attendances Found.",
        data: {
          attendances: attendances,
          todayAttendance: todayAttendance,
        },
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No Attendances Found.",
        data: {
			    attendances: [],
          todayAttendance: null,
		    },
      });
    }
  });
  // =============================== App APIs ===========================
}

module.exports = AttendanceController;
