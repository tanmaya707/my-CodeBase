const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/errorHandler");
const RequestHandler = require("../utils/RequestHandler");
const mongoose = require("mongoose");
const ObjectId = mongoose.Types.ObjectId;

const {
  calculateDistance,
  calculateDistanceInsTentApi,
  calculateTimeInKilometers,
  getRateChartCategory,
} = require("../utils/utilities");
const {
  vehicleCategoryDetails,
  vehicleModelDetails,
} = require("../utils/common");
const {
  MSG_RECORD_STATUS_SUCCESS,
  MSG_RECORD_FETCH_SUCCESS,
} = require("../config/constants");
const requestHandler = new RequestHandler();

const countryModel = require("../models/countryModel");
const trackingApiModel = require("../models/trackingApiModel");
const assetModel = require("../models/assetModel");

class AssetController extends BaseController {
  constructor() {
    super();
  }

  static assetsList = catchAsyncErrors(async (req, res, next) => {
    let totalAssets = [];
    let assets = [];

    let totalCount = 0;
		let totalPages= 0;
		let page = 0;
		let limit = 0;
		let skip = 0;

    // Pagination parameters ===========
		page = req.body.pageNo ? parseInt(req.body.pageNo) : 1; // Current page number
		limit = req.body.documentPerPage ? parseInt(req.body.documentPerPage) : 3; // Number of documents per page
		skip = (page - 1) * limit; // Number of documents to skip
		// Pagination parameters ===========

    const { text } = req.body;

    if(req.method == "POST"){
        let match = {
          $or: [
            {
              assetType: {
                $regex: ".*" + text + ".*",
                $options: "i",
              },
            },
            {
              otherAssetDetails: {
                $regex: ".*" + text + ".*",
                $options: "i",
              },
            },
            {
              brand: {
                $regex: ".*" + text + ".*",
                $options: "i",
              },
            },
          ],
        };
        const aggregatorOpts = [
          {
            $addFields: {
              assetType: "$assetType",
              otherAssetDetails: "$otherAssetDetails",
              brand: "$brand",
            },
          },
          {
            $match: match,
          },
          {
						$sort: { createdAt: -1 } // Sort by createdAt in descending order
					},
        ];
        totalAssets = await assetModel.aggregate(aggregatorOpts).exec();
        assets = await assetModel.aggregate(aggregatorOpts).skip(skip).limit(limit).exec();
    } else {
        // ======= for dropdown ===========
        assets = await super.getList(req, assetModel, "");
    }

    totalCount = totalAssets.length;
    totalPages= Math.ceil(totalCount/limit);

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: assets,
      pagination: {
        total: totalCount,
        totalPages: totalPages,
        rowsPerPage: limit,
        currentPage: page,
        hasNextPage: page < totalPages,
        hasPrevPage: page > 1
      },
    });
  });

  static assetAddUpdate = catchAsyncErrors(async (req, res, next) => {
    const { apiId, assetType, otherAssetDetails, phoneNumber, carrier, brand,  _id } = req.body;

    const data = {
      apiId: apiId,
      assetType: assetType,
      otherAssetDetails: otherAssetDetails,
      sim: {
        phoneNumber: phoneNumber,
        carrier: carrier,
      },
      brand: brand,
    };
    const updated =
      _id && _id != null && _id != ""
        ? await super.updateById(assetModel, _id.toString(), data)
        : await super.create(res, assetModel, data);

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: updated,
    });
  });

  static getAssetDetail = catchAsyncErrors(async (req, res, next) => {
    const { id } = req.body;
    const asset = await assetModel.findOne({ _id: id });
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: asset,
    });
  });

  static deleteAsset = catchAsyncErrors(async (req, res, next) => {
    const { id } = req.body;
    const updated = await super.deleteById(assetModel, id);
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: updated,
    });
  });
}

module.exports = AssetController;
