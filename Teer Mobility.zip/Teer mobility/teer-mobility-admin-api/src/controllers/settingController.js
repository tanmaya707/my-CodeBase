const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/errorHandler");
const RequestHandler = require("../utils/RequestHandler");
const mongoose = require("mongoose");
const ObjectId = mongoose.Types.ObjectId;

const {
  calculateDistance,
  calculateDistanceInsTentApi,
  calculateTimeInKilometers,
  getRateChartCategory,
} = require("../utils/utilities");
const {
  vehicleCategoryDetails,
  vehicleModelDetails,
} = require("../utils/common");
const {
  MSG_RECORD_STATUS_SUCCESS,
  MSG_RECORD_FETCH_SUCCESS,
} = require("../config/constants");
const requestHandler = new RequestHandler();

const countryModel = require("../models/countryModel");
const trackingApiModel = require("../models/trackingApiModel");
const assetModel = require("../models/assetModel");
const settingModel = require("../models/settingModel");
const enqueryModel = require("../models/enqueryModel");
const notificationSettingModel = require("../models/notificationSettingModel");
const locationSettingModel = require("../models/locationSettingModel");
const feedbackSettingModel = require("../models/feedbackSettingModel");
const driverFeedbackModel = require("../models/driverFeedbackModel");
const vehicleFeedbackmodel = require("../models/vehicleFeedbackmodel");
const tripFeedbackmodel = require("../models/tripFeedbackmodel");
const fareChartModel = require("../models/fareChartModel");
const rollModel = require("../models/rollModel");
const userModel = require("../models/userModel");
const customerModel = require("../models/customerModel");
const corporateModel = require("../models/corporateModel");
const reasonModel = require("../models/reasonModel");
const generalSupportModel = require("../models/generalSupportModel");

class SettingController extends BaseController {
  constructor() {
    super();
  }

  static supportReasonAdd = catchAsyncErrors(async (req, res, next) => {
    let { reason } = req.body;
    let data = {
      reason: reason,
    };
    let reasonMaster = await super.create(res, reasonModel, data);
    res.status(200).json({
      status: true,
      message: "Success",
      data: reasonMaster,
    });
  });

  static getSupportReason = catchAsyncErrors(async (req, res, next) => {
    let supportReasons = await reasonModel.find({
      isActive: true,
      isDeleted: false,
    });
    res.status(200).json({
      status: true,
      message: "Success",
      data: supportReasons,
    });
  });

  static updateGeneralSetting = catchAsyncErrors(async (req, res, next) => {
    const { phone, email, socialLinks } = req.body;

    const data = {
      phone: phone,
      email: email,
      socialLinks: socialLinks,
    };
    let _id = "";
    let setting = await settingModel.findOne({});
    if (setting) {
      _id = setting._id;
    }

    const updated =
      _id && _id != null && _id != ""
        ? await super.updateById(settingModel, _id.toString(), data)
        : await super.create(res, settingModel, data);

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: updated,
    });
  });

  static getSupportDetails = catchAsyncErrors(async (req, res, next) => {
    let { loggedInAs } = req.body;

    let customerSearch = await customerModel.findOne({
      isActive: true,
      isDeleted: false,

      roleId: loggedInAs,
      userId: req.user._id,
    });

    let corporateIdArr = [];
    let corporateDetail = [];
    let supportDetail = [];
		let teerSupport = [];

		let generalSupportData = await generalSupportModel.findOne({
			isActive: true,
		});
		let generalSupportObj = {
			supportEmail: generalSupportData?.supportEmail || "",
			phoneNumber: generalSupportData?.phoneNumber || "",
		};
		teerSupport.push(generalSupportObj);
		
    if (customerSearch.corporates.length > 0) {
      customerSearch.corporates.forEach((corporate) => {
        corporateIdArr.push(corporate.corporateId.toString());
      });
      corporateDetail = await corporateModel.find({
        _id: {
          $in: corporateIdArr,
        },
      });
      corporateDetail.forEach((corporate) => {
        let supportObj = {
          supportEmail: corporate.supportEmail,
          phoneNumber: corporate.phoneNumber,
        };
        supportDetail.push(supportObj);
      });

			return requestHandler.sendSuccess(
				res,
				"Successful"
			)({
				data: {
					teerSupport: teerSupport,
					corporateSupport: supportDetail,
				},
			});

    } else {
      let generalSupportData = await generalSupportModel.findOne({
				isActive: true,
			});
      let supportObj = {
        supportEmail: generalSupportData?.supportEmail || "",
				phoneNumber: generalSupportData?.phoneNumber || "",
      };
      supportDetail.push(supportObj);
    }

		return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: {
				teerSupport: teerSupport,
				corporateSupport: [],
			},
    });
  });

  static enquirySubmit = catchAsyncErrors(async (req, res, next) => {
    const { message } = req.body;

    const data = {
      userId: req.user._id,
      message: message,
    };
    const updated = await super.create(res, enqueryModel, data);

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      //   data: updated,
    });
  });

  static updateNotificationSetting = catchAsyncErrors(
    async (req, res, next) => {
      const { isActive } = req.body;

      const data = {
        userId: req.user._id,

        isActive: isActive,
      };

      let _id = "";
      let setting = await notificationSettingModel.findOne({
        userId: req.user._id,
      });
      if (setting) {
        _id = setting._id;
      }

      const updated =
        _id && _id != null && _id != ""
          ? await super.updateById(
              notificationSettingModel,
              _id.toString(),
              data
            )
          : await super.create(res, notificationSettingModel, data);

      return requestHandler.sendSuccess(
        res,
        "Successful"
      )({
        data: updated,
      });
    }
  );

  static getNotificationSetting = catchAsyncErrors(async (req, res, next) => {
    let data = await notificationSettingModel.findOne({ userId: req.user._id });

    if (!data) {
      data = await super.create(res, notificationSettingModel, {
        userId: req.user._id,
        isActive: true,
      });
    }
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: data,
    });
  });

  static updateLocationSetting = catchAsyncErrors(async (req, res, next) => {
    const { isActive } = req.body;

    const data = {
      userId: req.user._id,
      isActive: isActive,
    };

    let _id = "";
    let setting = await locationSettingModel.findOne({ userId: req.user._id });
    if (setting) {
      _id = setting._id;
    }

    const updated =
      _id && _id != null && _id != ""
        ? await super.updateById(locationSettingModel, _id.toString(), data)
        : await super.create(res, locationSettingModel, data);

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: updated,
    });
  });

  static getLocationSetting = catchAsyncErrors(async (req, res, next) => {
    let data = await locationSettingModel.findOne({ userId: req.user._id });
    if (!data) {
      data = await super.create(res, locationSettingModel, {
        userId: req.user._id,
        isActive: true,
      });
    }
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: data,
    });
  });

  static updateFeedbackSetting = catchAsyncErrors(async (req, res, next) => {
    const { objectType, objectValue } = req.body;

    const data = {
      objectType: objectType,
      objectValue: objectValue,
    };
    let _id = "";
    let setting = await feedbackSettingModel.findOne({
      objectType: objectType,
    });
    if (setting) {
      _id = setting._id;
    }

    const updated =
      _id && _id != null && _id != ""
        ? await super.updateById(feedbackSettingModel, _id.toString(), data)
        : await super.create(res, feedbackSettingModel, data);

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: updated,
    });
  });

  static getFeedbackSetting = catchAsyncErrors(async (req, res, next) => {
    let data = await feedbackSettingModel.find({});

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: data,
    });
  });

  static driverFeedbackSubmit = catchAsyncErrors(async (req, res, next) => {
    const { tripId, driverId, rating, feedback } = req.body;

    const data = {
      tripId: tripId,
      driverId: driverId,
      rating: rating,
      feedback: feedback,
      userId: req.user._id,
    };
    const updated = await super.create(res, driverFeedbackModel, data);

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: updated,
    });
  });

  static vehicleFeedbackSubmit = catchAsyncErrors(async (req, res, next) => {
    const { tripId, vehicleId, rating, feedback } = req.body;

    const data = {
      tripId: tripId,
      vehicleId: vehicleId,
      rating: rating,
      feedback: feedback,
      userId: req.user._id,
    };
    const updated = await super.create(res, vehicleFeedbackmodel, data);

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: updated,
    });
  });
  static tripFeedbackSubmit = catchAsyncErrors(async (req, res, next) => {
    let {
      tripId,
      driverId,
      vehicleId,
      driverRating,
      vehicleRating,
      driverfeedback,
      vehiclefeedback,
      review,
    } = req.body;

    let tripRatingData = {
      tripId: tripId,
      userId: req.user._id,
      review: review,
    };
    let tripRatingUpdated = await super.create(
      res,
      tripFeedbackmodel,
      tripRatingData
    );

    let driverData = {
      tripId: tripId,
      driverId: driverId,
      rating: driverRating,
      feedback: driverfeedback,
      userId: req.user._id,
    };
    let driverFeedbackUpdated = await super.create(
      res,
      driverFeedbackModel,
      driverData
    );

    let vehicleData = {
      tripId: tripId,
      vehicleId: vehicleId,
      rating: vehicleRating,
      feedback: vehiclefeedback,
      userId: req.user._id,
    };
    let vehicleFeedbackUpdated = await super.create(
      res,
      vehicleFeedbackmodel,
      vehicleData
    );

    if (tripRatingUpdated && driverFeedbackUpdated && vehicleFeedbackUpdated) {
      return requestHandler.sendSuccess(
        res,
        "Successful"
      )({
        data: {
          tripRatingUpdated: tripRatingUpdated,
          driverFeedbackUpdated: driverFeedbackUpdated,
          vehicleFeedbackUpdated: vehicleFeedbackUpdated,
        },
      });
    } else {
      return requestHandler.sendSuccess(
        res,
        "Oops.. There was problem posting your review."
      )({
        data: {},
      });
    }
  });

  static fareChartAddUpdate = catchAsyncErrors(async (req, res, next) => {
    let { countryId, baseFare, forFirstHowManyKm, farePerExtraKm } = req.body;

    let super_admin = await rollModel.findOne({ name: "Super Admin" });
    let superUser = await userModel.findOne({
      roleId: super_admin._id.toString(),
    });

    if (superUser._id.toString() == req.user._id.toString()) {
      // only super admin can add update fare chart =========
      const data = {
        countryId: countryId,
        baseFare: baseFare,
        forFirstHowManyKm: forFirstHowManyKm,
        farePerExtraKm: farePerExtraKm,
      };

      let _id = "";
      let fareChart = await fareChartModel.findOne({
        countryId: countryId,
      });
      if (fareChart) {
        _id = fareChart._id;
      }

      const updated =
        _id && _id != null && _id != ""
          ? await super.updateById(fareChartModel, _id.toString(), data)
          : await super.create(res, fareChartModel, data);

      return requestHandler.sendSuccess(
        res,
        "Successful"
      )({
        data: updated,
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "Only Super-admin can add/update fare-chart.",
      });
    }
  });

  static getFareChart = catchAsyncErrors(async (req, res, next) => {
    let { countryId } = req.body;
    let fareChart = await fareChartModel.findOne({
      countryId: countryId,
    });

    if (fareChart) {
      return res.status(200).json({
        status: true,
        message: "Success",
        data: fareChart,
      });
    } else {
      return res.status(200).json({
        status: true,
        message: "No Fare Chart Fund",
        data: {},
      });
    }
  });

}

module.exports = SettingController;
