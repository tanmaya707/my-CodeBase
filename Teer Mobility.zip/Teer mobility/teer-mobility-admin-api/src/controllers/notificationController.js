const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/errorHandler");
const RequestHandler = require("../utils/RequestHandler");
const mongoose = require("mongoose");
const ObjectId = mongoose.Types.ObjectId;

const {
  calculateDistance,
  calculateDistanceInsTentApi,
  calculateTimeInKilometers,
  getRateChartCategory,
} = require("../utils/utilities");
const {
  vehicleCategoryDetails,
  vehicleModelDetails,
} = require("../utils/common");
const {
  MSG_RECORD_STATUS_SUCCESS,
  MSG_RECORD_FETCH_SUCCESS,
} = require("../config/constants");
const notificationModel = require("../models/notificationModel");
const requestHandler = new RequestHandler();


class NotificationController extends BaseController {
  constructor() {
    super();
  }

  static notificationList = catchAsyncErrors(async (req, res, next) => {
    let notificationList = await notificationModel.find({
      userId: req.user._id,
      isDeleted: false,
    }).sort({ createdAt: -1 });

    let unreadCount = 0;
    notificationList.forEach((noti)=>{
      if(noti.isRead == false){
        unreadCount++;
      }
    });

    if(notificationList.length > 0){
      return res.status(200).json({
        status: true,
        message: "Notifications found.",
        data: {
          unreadCount: unreadCount,
          notificationList: notificationList,
        }
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No notifications found.",
        data: {
          unreadCount: unreadCount,
          notificationList: [],
        }
      });
    }
  });

  static notificationStatusChange = catchAsyncErrors(async (req, res, next)=>{
    let { id, isRead } = req.body;
    let updateFields = {
      isRead: isRead,
    };
    let updated = await super.updateById(notificationModel, id, updateFields);

    if(updated){
      return res.status(200).json({
        status: true,
        message: "Success",
        data: updated
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Problem changing status.",
        data: {}
      });
    }
  });

  // static getAssetDetail = catchAsyncErrors(async (req, res, next) => {
  //   const { id } = req.body;
  //   const asset = await assetModel.findOne({ _id: id });
  //   return requestHandler.sendSuccess(
  //     res,
  //     "Successful"
  //   )({
  //     data: asset,
  //   });
  // });

  static deleteNotification = catchAsyncErrors(async (req, res, next) => {
    let { id } = req.body;
    let updated = await super.deleteById(notificationModel, id);
    if(updated){
      return res.status(200).json({
        status: true,
        message: "Deleted.",
        data: updated
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Can not delete.",
        data: {}
      });
    }
  });
}

module.exports = NotificationController;
