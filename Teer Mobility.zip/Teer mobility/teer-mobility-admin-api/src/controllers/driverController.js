const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/errorHandler");
const RequestHandler = require("../utils/RequestHandler");
const mongoose = require("mongoose");
const ObjectId = mongoose.Types.ObjectId;
const moment = require('moment-timezone');
const dateFns = require('date-fns');
const sendPushNotification = require("../helpers/sendPushNotification");
const axios = require("axios");
const GoogleApiKey = require("../config/index").GoogleApiKey;

const {
  calculateDistance,
  calculateDistanceInsTentApi,
  calculateTimeInKilometers,
  getRateChartCategory,
  dateFormat,
} = require("../utils/utilities");
const {
  userDetails,
  vehicleCategoryDetails,
  vehicleModelDetails,
	vendorDriverMapDetails,
} = require("../utils/common");
const {
  MSG_RECORD_STATUS_SUCCESS,
  MSG_RECORD_FETCH_SUCCESS,
} = require("../config/constants");
const requestHandler = new RequestHandler();

const rollModel = require("../models/rollModel");
const rolePermissionUserwiseModel = require("../models/rolePermissionUserwiseModel");
const driverModel = require("../models/driverModel");
const vendorDriverModel = require("../models/vendorDriverModel");
const corporateModel = require("../models/corporateModel");
const tripsModel = require("../models/tripsModel");
const driverLocationsModel = require("../models/driverLocationsModel");
const tripPassengerModel = require("../models/tripPassengerModel");
const userModel = require("../models/userModel");
const tripLocationsHistoryModel = require("../models/tripLocationsHistoryModel");
const tripStatusLogModel = require("../models/tripStatusLogModel");
const customerModel = require("../models/customerModel");

class DriverController extends BaseController {
  constructor() {
    super();
  }

  static driverListWithPagination = catchAsyncErrors(async (req, res, next) => {
    // ========= check who is logged in ==========
    let loggedUser = await userModel.findOne({ _id: req.user._id }).populate(
      {
        path: "roleId",
        model: "roleCollection"
      }
    ); 
    // console.log("loggedUser =======================================================> ");
    // console.log(loggedUser.roleId.name);
    // console.log("loggedUser =======================================================> ");

    // ========= check who is logged in ==========
    let users = [];
    let { text, phoneSearch, roleId, roleOfUserType, corporateId, pageNo, documentPerPage, } = req.body;

    let totalCount = 0;
    let totalPages= 0;
    // Pagination parameters ===========
    const page = req.body.pageNo ? parseInt(req.body.pageNo) : 1; // Current page number
    const limit = req.body.documentPerPage ? parseInt(req.body.documentPerPage) : 3; // Number of documents per page
    const skip = (page - 1) * limit; // Number of documents to skip
    // Pagination parameters ===========

    if(roleId == undefined){
      roleId = roleOfUserType;
    }
    const super_admin = await rollModel.findOne({ name: "Super Admin" });
    let match = {
      roleId: {
        $ne: super_admin._id,
      },
      $and: [
        {
          $or: [
            {
              nameFilter: {
                $regex: ".*" + text + ".*",
                $options: "i",
              },
            },
            {
              phone: {
                $regex: ".*" + text + ".*",
                $options: "i",
              },
            },
            {
              email: {
                $regex: ".*" + text + ".*",
                $options: "i",
              },
            },
          ],
        },
      ],
    };
    if (roleId != "") {
      const role = await rollModel.findOne({ _id: roleId });
      match["roleId"] = role._id;
    }
    if (phoneSearch) {
      match["phone"] = parseInt(phoneSearch); 
    }
    const aggregatorOpts = [
      {
        $addFields: {
          nameFilter: {
            $concat: ["$firstName", " ", "$lastName"],
          },
          phone: "$phone",
          email: "$email",
          roleId: "$roleId",
        },
      },
      {
        $match: match,
      },
    ];
    // let totalUsers = await userModel.aggregate(aggregatorOpts).exec();
    // users = await userModel.aggregate(aggregatorOpts).skip(skip).limit(limit).exec();
    users = await userModel.aggregate(aggregatorOpts).exec();
    await rollModel.populate(users, { path: "roleId" });
    
    let searchedUsers = [];
    let filteredUsers = [];
    let mappedFilteredUsers = [];

    if(corporateId){
      searchedUsers = await Promise.all(
        users.map(async (user) => {
          let driverIdOfUser = await driverModel.findOne({
            userId: user?._id,
          });
          let vendorDriverMapping = await vendorDriverModel.find({
            driverId: driverIdOfUser?._id,
          });
          
          let vendorDriverMappingsArr = [];
          vendorDriverMapping.forEach(async (mapping) => {
            vendorDriverMappingsArr.push(mapping?.vendorId.toString());
          });

          if(
            vendorDriverMappingsArr.length > 0
            && (vendorDriverMappingsArr.includes(corporateId.toString()))
          ){
            return user;
          } else {
            return null;
          }
        })
      );
    } else {
      searchedUsers = users;
    }

    // Filter out null values
    searchedUsers = searchedUsers.filter(user => user !== null);

    users = searchedUsers;

    let userIdsAfterSearch = [];
    users.forEach(async (user) => {
      userIdsAfterSearch.push(user?._id);
    });

    let totalUsers = await userModel.find({
      _id: {
        $in: userIdsAfterSearch,
      }
    });
    users = await userModel.find({
      _id: {
        $in: userIdsAfterSearch,
      }
    }).lean().skip(skip).limit(limit).exec();
    await rollModel.populate(users, [
      { 
        path: "roleId",
        model: "roleCollection"
      }
    ]);

    if(roleOfUserType){
      // ========== filters user according to role (user-type) ==========
      filteredUsers = users.filter((user) => {
        if (user?.roleId?._id.toString() === roleOfUserType) {
          return user;
        }
      });
      // ========== filters user according to role (user-type) ==========
      
      // ========== filters user according to user-id ==========
      let super_admin = await rollModel.findOne({ name: "Super Admin" });
      let superUser = await userModel.findOne({ roleId: super_admin?._id.toString() });

      let admin_userRole = await rollModel.findOne({ name: "Admin User" });
      let adminUser = await userModel.findOne({ roleId: admin_userRole?._id.toString() });

      if(
        // superadmin using =======
        (superUser?._id.toString() == req.user._id)
        // adminUser using =======
        || (adminUser?._id.toString() == req.user._id)
      ){
        // superadmin or adminUser using =======
        // can see all data =========
        mappedFilteredUsers = users

      } else {
        // other user using =========
        if(loggedUser?.roleId?.name == "Vendor"){
          let loggedCorporate = await corporateModel.findOne({
            userId: req.user._id
          });
          let vendorDriverMapping = await vendorDriverModel.find({
            vendorId: loggedCorporate?._id
          }).populate(
            {
              path: "driverId",
              model: "driverCollection",
              populate: {
                path: "userId",
                model: "usersCollection",
              }
            }
          );
          let mappedDriverIdArr = [];
          vendorDriverMapping.forEach((mappedDriver)=>{
            mappedDriverIdArr.push(mappedDriver?.driverId?.userId?._id.toString())
          })
          mappedFilteredUsers = filteredUsers.filter((user) => {
            if(mappedDriverIdArr.includes(user?._id.toString())){
              return user;
            }
          });
        } 
      }

      filteredUsers = mappedFilteredUsers
      // ========== filters user according to user-id ==========

    } else {
      // unfiltered users =====
      filteredUsers = users
    }

    // let filteredDrivers = await Promise.all(
    //   filteredUsers.map(async (user)=>{
    //     if(user?.roleId?.name == "Driver"){
    //       let driver = await driverModel.findOne({
    //         userId: user?._id
    //       });
          
    //       user['employeeId'] = driver.employeeId;
    //     }
    //     return user;
    //   })
    // );

    let rolePermissionsUserWise = [];
    rolePermissionsUserWise = await rolePermissionUserwiseModel.find({
      isActive: true,
      isDeleted: false,
    });

    totalCount = totalUsers.length;
    totalPages= Math.ceil(totalCount/limit);

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: userDetails(filteredUsers, rolePermissionsUserWise),
      pagination: {
        total: totalCount,
        totalPages: totalPages,
        rowsPerPage: limit,
        currentPage: page,
        hasNextPage: page < totalPages,
        hasPrevPage: page > 1
      },
    });
  });

  static driverList = catchAsyncErrors(async (req, res, next) => {
    let drivers = []
    // ======= for dropdown ===========
    drivers = await driverModel.find({
        isActive: true,
        isDeleted: false,
      }).populate(
        {
          path: "userId",
          model: "usersCollection",
        },
      );
    // ======= for dropdown ===========
    
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: drivers,
    });
  });
  static vendorDriverMapList = catchAsyncErrors(async (req, res, next) => {
    let mappings = [];

    if (req.method == "POST") {

      let { text, vendorId, driverId, tripId } = req.body;
      
      let match = {
        
      };
      let drivers = []
      if(tripId){
        let trip = await tripsModel.findOne({ _id: tripId })
        
        let existing_trip = [];

        if(trip){
          existing_trip = await tripsModel.find({ 
            $and: [
              { _id: { $ne: tripId } },
              {  
                tripDate: trip?.tripDate
              }
              // {
              //   $or:[ 
              //     {'tripStartTime':
              //       {
              //         $gte: trip.tripStartTime, 
              //         $lt: trip.tripEndTime
              //       }
              //     }, 
              //     {'tripEndTime':
              //       {
              //         $gte: trip.tripStartTime, 
              //         $lt: trip.tripEndTime
              //       }
              //     }
              //   ]
              // }
            ]
          })
          if(existing_trip.length > 0){
            existing_trip.forEach(elem => {
              if(elem.driverId && (elem.driverId != null)){
                drivers.push(elem.driverId)
              }
            })
  
            if(drivers.length > 0){
              match["driverId"] = {
                  $nin: drivers
              }
            }
          }

        }
      }
      if (
        vendorId &&
        vendorId != ""
      ) {
        let vendor = await corporateModel.findOne({ _id: vendorId });
        match["vendorId"] = vendor._id;
      }
      if (
        driverId &&
        driverId != ""
      ) {
        let driver = await driverModel.findOne({ _id: driverId });
        
        match["driverId"] = driver._id;
      }
      const aggregatorOpts = [
        {
          $addFields: {
            vendorId: "$vendorId",
            driverId: "$driverId",
          },
        },
        {
          $match: match,
        },
        {
          $sort: { createdAt: -1 } // Sort by createdAt in descending order
        },
      ];
      
      mappings = await vendorDriverModel.aggregate(aggregatorOpts).exec();
      await corporateModel.populate(
        mappings,
        [
          {
            path: "vendorId",
            model: "corporateCollection",
          },
          {
            path: "driverId",
            model: "driverCollection",
            populate: {
              path: "userId",
              model: "usersCollection",
            }
          }
        ]
      );
    } else {
      
    }

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      // data: mappings,
      data: vendorDriverMapDetails(mappings),
      // pagination: {
      //   total: totalCount,
      //   totalPages: totalPages,
      //   rowsPerPage: limit,
      //   currentPage: page,
      //   hasNextPage: page < totalPages,
      //   hasPrevPage: page > 1
      // },
    });
  });

	static vendorDriverMapListWithPagination = catchAsyncErrors(async (req, res, next) => {
    let totalMappings = [];
    let mappings = [];

    let totalCount = 0;
		let totalPages= 0;
		let page = 0;
		let limit = 0;
		let skip = 0;

    if (req.method == "POST") {
      // Pagination parameters ===========
			page = req.body.pageNo ? parseInt(req.body.pageNo) : 1; // Current page number
			limit = req.body.documentPerPage ? parseInt(req.body.documentPerPage) : 3; // Number of documents per page
			skip = (page - 1) * limit; // Number of documents to skip
			// Pagination parameters ===========

      let { text, vendorId, driverId, tripId } = req.body;
      let match = {
        
      };
      let drivers = []
      if(tripId){
        let trip = await tripsModel.findOne({ _id: tripId })
        let existing_trip = await tripsModel.find({ 
					$and: [
						{ _id: { $ne: tripId } },
						{  
							tripDate: trip.tripDate
						}
						// {
						//   $or:[ 
						//     {'tripStartTime':
						//       {
						//         $gte: trip.tripStartTime, 
						//         $lt: trip.tripEndTime
						//       }
						//     }, 
						//     {'tripEndTime':
						//       {
						//         $gte: trip.tripStartTime, 
						//         $lt: trip.tripEndTime
						//       }
						//     }
						//   ]
						// }
					]
				})
        if(existing_trip.length > 0){
          existing_trip.forEach(elem => {
            if(elem.driverId && (elem.driverId != null)){
              drivers.push(elem.driverId)
            }
          })

          if(drivers.length > 0){
            match["driverId"] = {
                $nin: drivers
            }
          }
        }
      }
      if (
        vendorId &&
        vendorId != ""
      ) {
        let vendor = await corporateModel.findOne({ _id: vendorId });
        match["vendorId"] = vendor._id;
      }
      if (
        driverId &&
        driverId != ""
      ) {
        let driver = await driverModel.findOne({ _id: driverId });
        
        match["driverId"] = driver._id;
      }
      const aggregatorOpts = [
        {
          $addFields: {
            vendorId: "$vendorId",
            driverId: "$driverId",
          },
        },
        {
          $match: match,
        },
        {
          $sort: { createdAt: -1 } // Sort by createdAt in descending order
        },
      ];
      totalMappings = await vendorDriverModel.aggregate(aggregatorOpts).exec();
      mappings = await vendorDriverModel.aggregate(aggregatorOpts).skip(skip).limit(limit).exec();
      await corporateModel.populate(
        mappings,
        [
          {
            path: "vendorId",
            model: "corporateCollection",
          },
          {
            path: "driverId",
            model: "driverCollection",
            populate: {
              path: "userId",
              model: "usersCollection",
            }
          }
        ]
      );
    } else {
      // mappings = await vendorDriverModel.find()
    }
    // console.log("mappings ===>");
    // console.log(mappings);
    // return res.status(200).json({
    //   status: true,
    //   data: mappings,
    // });
    
    totalCount = totalMappings.length;
    totalPages= Math.ceil(totalCount/limit);

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      // data: mappings,
      data: vendorDriverMapDetails(mappings),
      pagination: {
        total: totalCount,
        totalPages: totalPages,
        rowsPerPage: limit,
        currentPage: page,
        hasNextPage: page < totalPages,
        hasPrevPage: page > 1
      },
    });
  });

  static vendorDriverMapAddUpdate = catchAsyncErrors(async (req, res, next) => {
    let { vendorId, driverId, _id } = req.body;
    let data = {
        vendorId: vendorId,
        driverId: driverId,
    };
		let checkExist = await super.getByCustomOptionsSingle(req, vendorDriverModel, data);
		if(checkExist == null){
			// if mapping does not exist already =====
			let updated =
				_id && _id != null && _id != ""
					? await super.updateById(vendorDriverModel, _id.toString(), data)
					: await super.create(res, vendorDriverModel, data);

			return requestHandler.sendSuccess(
				res,
				"Successful"
			)({
				data: updated,
			});
		} else{
			// if mapping exist already =====
			return res.status(400).json({
				status: false,
				message: "Driver already mapped to this vendor.",
				data: checkExist
			})
		}
    
  });

  static getVendorDriverMapDetail = catchAsyncErrors(async (req, res, next) => {
    let { id } = req.body;
    let vendorDriverMap = await vendorDriverModel.findOne({ _id: id });
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: vendorDriverMap,
    });
  });

	static deleteVendorDriverMap = catchAsyncErrors(async (req, res, next) => {
    const { id } = req.body;
    const updated = await super.deleteById(vendorDriverModel, id);
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: updated,
    });
  });

  // ========== APP APIs ===========
  static driverLocationUpdate = catchAsyncErrors(async (req, res, next)=>{
    let { lat, long, heading, address, source, accuracy, } = req.body;

    // Get the current time in "Asia/Kolkata" time zone =======
    let momentKolkata = moment().tz("Asia/Kolkata");
    let currentDate = momentKolkata.format("YYYY-MM-DD");
    let currentDateTime = momentKolkata.format("YYYY-MM-DD HH:mm:ss");
    let currentDay = momentKolkata.format("dddd");
    // let currentTime = momentKolkata.format('HH:mm');
    // Get the current time in "Asia/Kolkata" time zone =======
    let driver = await driverModel.findOne({
      userId: req.user._id,
    });
    
    let checkExist = await driverLocationsModel.findOne({
      userId: req.user._id,
    });
    let data = {
      userId: req.user._id,
      coordinates: [lat, long],
      heading: heading,
    };

    let updated = [];
    if(checkExist){
      
      // if record found, udpate ======
      let existingCoords = checkExist.coordinates;

      // if((existingCoords[0] != lat) && (existingCoords[1] != long)){
        // only if lat, long changes, then update ====
        updated = await super.updateById(driverLocationsModel, checkExist._id.toString(), data);

        // if lat long changes and driver is in a trip, then notify all the passengers of that trip ====
        let checkOngoingTrips = await tripsModel.find({
          isCancelled: false,
          isDeleted: false,
          isActive: true,

          driverId: driver._id,

          tripStatus: {
            $in: ["Started", "Paused", "Onboarding", "DropOff"]
          },
        }).populate([
          {
            path: "tripPlanId",
            model: "tripPlanCollection",
            populate: [
              {
                path: "vendorId",
                model: "corporateCollection",
              },
              {
                path: "corporateId",
                model: "corporateCollection",
              },
            ],
          },
          {
            path: "vehicleId",
            model: "vehicleCollection",
            populate: {
              path: "modelId",
              model: "vehicleModelCollection",
            },
          },
        ]);

        if(checkOngoingTrips.length > 0){
          let currentTrip = checkOngoingTrips.filter((trip)=>{
            let startTime = new Date(dateFormat(trip.tripDate)+" "+trip.tripStartTime);
            let endTime = new Date(dateFormat(trip.tripDate)+" "+trip.tripEndTime);
            let currentTime = new Date();
            if(
              // ((startTime >= currentTime) && (endTime <= currentTime)) &&
              ((currentTime >= startTime) && (currentTime <= endTime)) &&
              ((trip.tripStatus == "Started"))
            ){
              return trip;
            }
          });
          if(currentTrip.length > 0){
            // =========== if trip ongoing ==========
            let tripId = currentTrip[0]._id;

            // =================================================================
            // ============ tripLocationHistory store/update STARTS ============
            // =================================================================
            // let driver = await driverModel.findOne({
            //   userId: req.user._id,
            // });
            // let tripLocationsHistoryExist = await tripLocationsHistoryModel.findOne({
            //   tripId: tripId,
            // }).lean();

            // let updatedTripLocationsHistory = [];
            // if(tripLocationsHistoryExist){
            //   // ============ update; push in locationHistory Array field STARTS ============
            //   let locationHistory = {
            //     driverId: driver._id,
            //     // ==== location parameters ====
            //     address: address,
            //     coordinates: [lat, long],
            //     // ==== location parameters ====

            //     // ==== vehicle parameters ====
            //     speed: 0,
            //     ignitionStatus: false,
            //     acStatus: false,
            //     odometerKm: 0,
            //     fuel: 0,
            //     // ==== vehicle parameters ====
            //     source: source,
            //     accuracy: accuracy,
            //     feedTime: currentDateTime,
            //   };

            //   let existingHistory = tripLocationsHistoryExist.locationHistory;
            //   existingHistory.push(locationHistory)

            //   let tripLocationHistoryData = {
            //     tripId: tripId,
            //     locationHistory: existingHistory,
            //   };

            //   updatedTripLocationsHistory = await super.updateById(tripLocationsHistoryModel, tripLocationsHistoryExist._id.toString(), tripLocationHistoryData);
            //   // ============ update; push in locationHistory Array field ENDS ============
            // } else {
            //   // ================== create new record START ==================
            //   let locationHistory = {
            //     driverId: driver._id,
            //     // ==== location parameters ====
            //     address: address,
            //     coordinates: [lat, long],
            //     // ==== location parameters ====

            //     // ==== vehicle parameters ====
            //     // ==== vehicle parameters ====
            //     source: source,
            //     accuracy: accuracy,
            //     feedTime: currentDateTime,
            //   };
            //   let tripLocationHistoryData = {
            //     tripId: tripId,
            //     locationHistory: [locationHistory],
            //   };
            //   updatedTripLocationsHistory = await super.create(res, tripLocationsHistoryModel, tripLocationHistoryData);
            //   // ================== create new record ENDS ==================
            // }
            // =================================================================
            // ============= tripLocationHistory store/update ENDS =============
            // =================================================================

            // ===== notifications to passengers =====
            let passengersOfTrip = await tripPassengerModel.find({
              isCancelled: false,
  
              tripId: tripId,
            }).populate([
              {
                "path": "pickupStopId",
                "model": "tripStopCollection"
              },
              {
                "path": "dropStopId",
                "model": "tripStopCollection"
              },
            ]);
            // console.log("passengersOfTrip =====>");
            // console.log(passengersOfTrip);
            let passengerIdsArr = [];
            if(passengersOfTrip.length > 0){
              // passengers found ====
              passengersOfTrip.forEach((passenger)=>{
                passengerIdsArr.push(passenger.userId.toString());
  
                // ========= eta and distance calculation API ==========
                let originLat = updated.coordinates[0].toString();
                let originLong = updated.coordinates[1].toString();
                
                let tripStartLat = passenger.pickupStopId.location.coordinates[0].toString();
                let tripStartLong = passenger.pickupStopId.location.coordinates[1].toString();
                let config = {
                  method: 'get',
                  maxBodyLength: Infinity,
                  url: `https://maps.googleapis.com/maps/api/distancematrix/json?origins=${originLat},${originLong}&destinations=${tripStartLat},${tripStartLong}&mode=walking&key=${GoogleApiKey}`,
                  headers: { }
                };
  
                axios.request(config).then(async (response) => {
                  // console.log(response.data.rows);
                  // value in meters
                  let distanceFromPickstop = response?.data?.rows[0]?.elements[0]?.distance?.value;
  
                  if(distanceFromPickstop <= 50){
                    // ===== driver reached pickup location =====
                    let passengerStatusLog = await tripStatusLogModel.findOne({
                      tripId: tripId,
                      passengerId: passenger.userId,
                    });

                    if(!passengerStatusLog){
                      // ====== passenger not onboarded or dropped ======
                      console.log("Passenger not onboarded or dropped; attempting to send Reached pickupStop Noti.");
                      try {
                        let user = await userModel.findOne({ _id: passenger.userId });
                        // console.log("user.fcmToken ====>", user.fcmToken);
                    
                        if (user.fcmToken) {
                          console.log("------ Reached pickupStop Noti send ----");
                          let messages = {
                            title: "Driver Reached Pickup location.",
                            body: JSON.stringify({
                              "tripId": `${passenger.tripId.toString()}`,
                              "msg": `Dear ${user.firstName}, the bus has arrived at your stop.`,
                              "type": "Show"
                            }),
                          };
                    
                          await sendPushNotification(user.fcmToken, messages, "android");
                        }
  
                        let updateTripPassengerWithStopReachTime = await super.updateByCustomOptions(
                          tripPassengerModel, 
                          {
                            userId: passenger.userId,
                            tripId: passenger.tripId
                          },
                          {
                            pickupReachTime: currentDateTime
                          },
                        ); 
  
                        if(updateTripPassengerWithStopReachTime){
                          console.log("Pickup reach time updated in DB.");
                        } else{
                          console.log("Problem updating pickup reach time in DB.");
                        }
  
                      } catch (error) {
                        // Handle or propagate the error as needed
                        console.error("Error sending notification:", error.message);
                      }
                    } else{
                      // passenger either onboarded or dropped ==== 
                      // no noti to send ====
                      console.log("passenger either onboarded or dropped; no noti to send");
                      
                    }

                  } else if(distanceFromPickstop == 1000){
                    // ===== bus is 1km away =====
                    try {
                      let user = await userModel.findOne({ _id: passenger.userId });
                      // console.log("user.fcmToken ====>", user.fcmToken);
                  
                      if (user.fcmToken) {
                        console.log("------ 1km away Noti send ----");
                        let messages = {
                          title: "Bus is 1km away.",
                          body: JSON.stringify({
                            "tripId": `${passenger.tripId.toString()}`,
                            "msg": `The Bus is 1 km away and will be reaching your stop soon. Kindly track the bus on the Teer Mobility App for more accurate location.`,
                            "type": "Show"
                          }),
                        };
                  
                        await sendPushNotification(user.fcmToken, messages, "android");
                      }
                    } catch (error) {
                      // Handle or propagate the error as needed
                      console.error("Error sending notification:", error.message);
                    }
                  } else if(distanceFromPickstop == 2000){
                    // ===== bus is 2km away =====
                    try {
                      let user = await userModel.findOne({ _id: passenger.userId });
                      // console.log("user.fcmToken ====>", user.fcmToken);
                  
                      if (user.fcmToken) {
                        console.log("------ 2km away Noti send ----");
                        let messages = {
                          title: "Bus is 2km away.",
                          body: JSON.stringify({
                            "tripId": `${passenger.tripId.toString()}`,
                            "msg": `Driver is heading towards your location and will be reaching your stop soon.Track Vehicle in the Teer Mobility App.`,
                            "type": "Show"
                          }),
                        };
                  
                        await sendPushNotification(user.fcmToken, messages, "android");
                      }
                    } catch (error) {
                      // Handle or propagate the error as needed
                      console.error("Error sending notification:", error.message);
                    }
                  }
                });
                // ========= eta and distance calculation API ==========
              });
  
              // ======== segregating passengers according to boarding status ========
              let passengersYetToOnboard = [];
              let passengersAlredyOnboarded = [];
              let passengersDroppedOff = [];

              // Prepare an array of promises for each async operation
              let promises = passengerIdsArr.map(async (passengerId) => {
                let passengerStatusLog = await tripStatusLogModel.findOne({
                  tripId: tripId,
                  passengerId: passengerId,
                });

                // console.log("passengerStatusLog ==>");
                // console.log(passengerStatusLog);
                
                if (passengerStatusLog) {
                  if (passengerStatusLog.status == "Onboarding") {
                    // --- passenger already onboarded ---
                    passengersAlredyOnboarded.push(passengerId);
                  } else if (passengerStatusLog.status == "DropOff") {
                    // --- passenger dropped off ---
                    passengersDroppedOff.push(passengerId);
                  } else {
                    // technically this should never run, but in case above two cases does not match, it will definitely be a passenger who is yet to onboard ---
                    console.log("technically this should never run, but in case above two cases does not match, it will definitely be a passenger who is yet to onboard");
                    // hence ---------------------------
                    // --- passenger yet to onboard ---
                    passengersYetToOnboard.push(passengerId);
                  }
                } else {
                  // --- passenger yet to onboard ---
                  passengersYetToOnboard.push(passengerId);
                }
              });

              // Wait for all promises to resolve -----
              await Promise.all(promises);

              console.log("passengersYetToOnboard ===>");
              console.log(passengersYetToOnboard);
              console.log("passengersAlredyOnboarded ===>");
              console.log(passengersAlredyOnboarded);
              console.log("passengersDroppedOff ===>");
              console.log(passengersDroppedOff);
              
              // ======== segregating passengers according to boarding status ========
              
              // =====================================================================
              // === send hidden notification to all passengers of passengerIdsArr ===
              // =====================================================================

              // --------------------------- on 20-08-2024 ---------------------------
              // changing passengerIdsArr to passengersYetToOnboard
              // passengersYetToOnboard.forEach(async (passenger) => {
              // // this hidden notification should only be sent to passengersYetToOnboard
              // // --------------------------- on 20-08-2024 ---------------------------
              //   try {
              //     let user = await userModel.findOne({ _id: passenger });
              //     // console.log("user.fcmToken ====>", user.fcmToken);
              
              //     if (user.fcmToken) {
              //       console.log("------ Sending Hidden Notification ----");
              //       let messages = {
              //         title: "Updated driver location.", // please do not change this particular title, this is being checked in APP-end.
              //         body: JSON.stringify({
              //           "tripId": `${tripId.toString()}`,
              //           "coordinates": `coordinates: [${updated.coordinates}]`,
              //           "driverLat": `${updated.coordinates[0]}`,
              //           "driverLong": `${updated.coordinates[1]}`,
              //           "heading": `${updated.heading}`,
              //           "type": "Hidden"
              //         }),
              //       };
              
              //       await sendPushNotification(user.fcmToken, messages, "android");
              //     }
              //   } catch (error) {
              //     // Handle or propagate the error as needed
              //     console.error("Error sending notification:", error.message);
              //   }
              // });
              // =====================================================================
              // === send hidden notification to all passengers of passengerIdsArr ===
              // =====================================================================
            } else {
              // no passengers to notify ====
            }
            // =====================================================================
            // === send hidden notification to corporate and vendor of the trip ===
            // =====================================================================
            // let vendorOfCurrentTrip = currentTrip[0].tripPlanId.vendorId.userId;
            // let corporateOfCurrentTrip = currentTrip[0].tripPlanId.corporateId.userId;
  
            // let vendorUserOfCurrentTrip = await userModel.findOne({
            //   _id: vendorOfCurrentTrip
            // });
            // let corporateUserOfCurrentTrip = await userModel.findOne({
            //   _id: corporateOfCurrentTrip
            // });
            
            // let vendorOfCurrentTripFcm = vendorUserOfCurrentTrip.fcmToken;
            // let corporateOfCurrentTripFcm = corporateUserOfCurrentTrip.fcmToken;
  
            // let messages = {
            //   title: "Updated driver location.", // please do not change this particular title, this is being checked in APP-end.
            //   body: JSON.stringify({
            //     "tripId": `${tripId.toString()}`,
            //     "coordinates": `coordinates: [${updated.coordinates}]`,
            //     "driverLat": `${updated.coordinates[0]}`,
            //     "driverLong": `${updated.coordinates[1]}`,
            //     "type": "Hidden"
            //   }),
            // };
            // try {
            //   if (vendorOfCurrentTripFcm) {
            //     console.log("------ Sending hidden notification to vendor ----");
            //     await sendPushNotification(vendorOfCurrentTripFcm, messages, "android");
            //   }
            // } catch (error) {
            //   // Handle or propagate the error as needed
            //   console.error("Error sending hidden notification to vendor:", error.message);
            // }
            // try {
            //   if (corporateOfCurrentTripFcm) {
            //     console.log("------ Sending hidden notification to corporate ----");
            //     await sendPushNotification(corporateOfCurrentTripFcm, messages, "android");
            //   }
            // } catch (error) {
            //   // Handle or propagate the error as needed
            //   console.error("Error sending hidden notification to corporate:", error.message);
            // }
            // =====================================================================
            // === send hidden notification to corporate and vendor of the trip ===
            // =====================================================================
          } else {
            // ======== no ongoing trip === nothing to do ========
          }
        // } 
        // else {
        //   // if lat long same, do not update ====
        //   // console.log("Location not changed.");
        // }
        }
    } else {
      // if record not found, create ======
      updated = await super.create(res, driverLocationsModel, data);
    }

    if(updated){
      return res.status(200).json({
        status: true,
        message: "Success",
        data: updated,
      });
    } else{
      return res.status(400).json({
        status: false,
        message: "Error",
        data: {},
      });
    }
  });

  static tripLocationHistory = catchAsyncErrors(async (req, res, next)=>{
    let { tripId } = req.body;

    let tripLocationHistory = await tripLocationsHistoryModel.findOne({
      tripId: tripId,
    }).populate([
      {
        "path": "tripId",
        "model": "tripsCollection",
        "populate": [
          {
            "path": "tripPlanId",
            "model": "tripPlanCollection",
            "populate": [
              {
                "path": "routeId",
                "model": "routeMapCollection",
                "populate": {
                  "path": "routeStops.stopId",
                  "model": "tripStopCollection",
                }
              },
              {
                "path": "stops.tripStopId",
                "model": "tripStopCollection",
              },
            ]
          },
          {
            "path": "vendorId",
            "model": "corporateCollection",
          },
          {
            "path": "driverId",
            "model": "driverCollection",
            "populate": {
              "path": "userId",
              "model": "usersCollection",
            }
          },
          {
            "path": "vehicleId",
            "model": "vehicleCollection",
            "populate": {
              "path": "modelId",
              "model": "vehicleModelCollection",
              "populate": {
                "path": "type",
                "model": "vehicleCategoriesCollection",
              }
            }
          },
        ]
      },
      {
        "path": "locationHistory.driverId",
        "model": "driverCollection",
        "populate": {
          "path": "userId",
          "model": "usersCollection",
        }
      }
    ]);

    if(tripLocationHistory){
      return res.status(200).json({
        status: true,
        message: "Trip location history found.",
        data: tripLocationHistory,
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No trip location history found.",
        data: {},
      });

    }
  });
  // ========== APP APIs ===========

  // ========== Notification Test ===========
  static sendTestNoti = catchAsyncErrors(async (req, res, next)=>{
    // send notification =====
    console.log("Sending Notification ----");
    let messages = {};
    messages = {
      title: "hi",
      body: JSON.stringify({
        "id": "1234",
        "hghjk": "hgtuyuio",
        "type": "Show"
      }),
      // tripId: "67890876"
    };
    await sendPushNotification( "fFPl2KC1RWyADlLfGFYqdz:APA91bHFnBeqAhprvNJLZVBSMyoF79ojtqYdyebrjr_CQJy90ns-rssdP-cO6ff66fRMEByoITSG7WUSfeanFhM9fdp-iyvqIKXoIzwRdx8MuvjjA6oNuc6woGzhTLMst01A-ylqVVcH", messages, "android" );
    // console
    return res.status(200).json({ 
      message: "Notification sent successfully.",
    });
  });
  // ========== Notification Test ===========

}



module.exports = DriverController;
