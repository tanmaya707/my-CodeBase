const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/errorHandler");
const RequestHandler = require("../utils/RequestHandler");
const mongoose = require("mongoose");
const ObjectId = mongoose.Types.ObjectId;
const fs = require('fs');
const APPURL = require("../config/index").APPURL

const {
  calculateDistance,
  calculateDistanceInsTentApi,
  calculateTimeInKilometers,
  getRateChartCategory,
  dateFormatDDMMYYYY,
  dateFormatYYYYMMDD,
} = require("../utils/utilities");
const {
  vehicleCategoryDetails,
  vehicleModelDetails,
	vendorVehicleMapDetails,
} = require("../utils/common");
const {
  MSG_RECORD_STATUS_SUCCESS,
  MSG_RECORD_FETCH_SUCCESS,
} = require("../config/constants");
const requestHandler = new RequestHandler();
const fileUploaderSingle = require("../utils/fileUpload").fileUploaderSingle;

const rollModel = require("../models/rollModel");
const vehicleModel = require("../models/vehicleModel");
const vehicleCategoryModel = require("../models/vehicleCategoriesModel");
const vehicleModelModel = require("../models/vehicleModelModel");
const corporateModel = require("../models/corporateModel");
const vendorVehicleModel = require("../models/vendorVehicleModel");
const userModel = require("../models/userModel");
const tripsModel = require("../models/tripsModel");
const tripPlanModel = require("../models/tripPlanModel");

class VehicleController extends BaseController {
  constructor() {
    super();
  }

  // ================= vehicle category ====================
  static vehicleCategoryList = catchAsyncErrors(async (req, res, next) => {

    let totalVehicleCategories = [];
    let vehicleCategories = [];
    let vehicles = [];

		let totalCount = 0;
		let totalPages= 0;
		let page = 0;
		let limit = 0;
		let skip = 0;

    const { text } = req.body;

    if (req.method == "POST") {
			// Pagination parameters ===========
			page = req.body.pageNo ? parseInt(req.body.pageNo) : 1; // Current page number
			limit = req.body.documentPerPage ? parseInt(req.body.documentPerPage) : 3; // Number of documents per page
			skip = (page - 1) * limit; // Number of documents to skip
			// Pagination parameters ===========

      let match = {
        $or: [
          {
            type: {
              $regex: ".*" + text + ".*",
              $options: "i",
            },
          },
        ],
      };
      const aggregatorOpts = [
        {
          $match: match,
        },
				{
          $sort: { createdAt: -1 } // Sort by createdAt in descending order
        },
      ];
      totalVehicleCategories = await vehicleCategoryModel.aggregate(aggregatorOpts).exec();
      vehicleCategories = await vehicleCategoryModel.aggregate(aggregatorOpts).skip(skip).limit(limit).exec();
    } else {
      // ======= for dropdown ===========
      vehicleCategories = await super.getList(req, vehicleCategoryModel, "");

      vehicles = await vehicleModel.find({ isDeleted: false, isActive: true }).populate([
        {
          "path": "modelId",
          "model": "vehicleModelCollection",
          "populate": [
            {
              "path": "type",
              "model": "vehicleCategoriesCollection",
            },
          ]
        },
      ]);
    }

		totalCount = totalVehicleCategories.length;
    totalPages= Math.ceil(totalCount/limit);

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: vehicleCategories,
      vehicles: vehicles,
			pagination: {
				total: totalCount,
				totalPages: totalPages,
				rowsPerPage: limit,
				currentPage: page,
				hasNextPage: page < totalPages,
				hasPrevPage: page > 1
			},
    });
  });

  static vehicleCategoryAddUpdate = catchAsyncErrors(async (req, res, next) => {
    const { type, _id } = req.body;

    const data = {
      type: type,
    };
    const updated =
      _id && _id != null && _id != ""
        ? await super.updateById(vehicleCategoryModel, _id.toString(), data)
        : await super.create(res, vehicleCategoryModel, data);

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: updated,
    });
  });

  static getVehicleCategory = catchAsyncErrors(async (req, res, next) => {
    const { id } = req.body;
    const vehicleCategory = await vehicleCategoryModel.findOne({ _id: id });
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: vehicleCategory,
    });
  });

  static deleteVehicleCategory = catchAsyncErrors(async (req, res, next) => {
    const { id } = req.body;
    const updated = await super.deleteById(vehicleCategoryModel, id);
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: updated,
    });
  });
  // ================= vehicle category ENDS ====================

  // ================= vehicle model ====================
  static vehicleModelList = catchAsyncErrors(async (req, res, next) => {

    let totalVehicleModels = [];
    let vehicleModels = [];

		let totalCount = 0;
		let totalPages= 0;
		let page = 0;
		let limit = 0;
		let skip = 0;

    const { text, type } = req.body;

    if (req.method == "POST") {
			// Pagination parameters ===========
			page = req.body.pageNo ? parseInt(req.body.pageNo) : 1; // Current page number
			limit = req.body.documentPerPage ? parseInt(req.body.documentPerPage) : 3; // Number of documents per page
			skip = (page - 1) * limit; // Number of documents to skip
			// Pagination parameters ===========

      let match = {
        $and: [
          {
            $or: [
              {
                model: {
                  $regex: ".*" + text + ".*",
                  $options: "i",
                },
              },
              {
                make: {
                  $regex: ".*" + text + ".*",
                  $options: "i",
                },
              },
            ],
          },
        ],
      };
      if (type != "") {
        const vehicleCategory = await vehicleCategoryModel.findOne({
          _id: type,
        });
        match["type"] = vehicleCategory._id;
      }
      const aggregatorOpts = [
        {
          $addFields: {
            model: "$model",
            make: "$make",
            type: "$type",
          },
        },
        {
          $match: match,
        },
				{
          $sort: { createdAt: -1 } // Sort by createdAt in descending order
        },
      ];
      totalVehicleModels = await vehicleModelModel.aggregate(aggregatorOpts).exec();
      vehicleModels = await vehicleModelModel.aggregate(aggregatorOpts).skip(skip).limit(limit).exec();
      await vehicleModelModel.populate(vehicleModels, { path: "type" });
    } else {
      // for dropdown ========
      vehicleModels = await super.getList(req, vehicleModelModel, "");
      await vehicleModelModel.populate(vehicleModels, { path: "type" });
    }

		totalCount = totalVehicleModels.length;
    totalPages= Math.ceil(totalCount/limit);

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: vehicleCategoryDetails(vehicleModels),
			pagination: {
				total: totalCount,
				totalPages: totalPages,
				rowsPerPage: limit,
				currentPage: page,
				hasNextPage: page < totalPages,
				hasPrevPage: page > 1
			},
    });
  });

  static vehicleModelAddUpdate = catchAsyncErrors(async (req, res, next) => {
    const { type, make, model, _id } = req.body;

    const data = {
      type: type,
      make: make,
      model: model,
    };
    const updated =
      _id && _id != null && _id != ""
        ? await super.updateById(vehicleModelModel, _id.toString(), data)
        : await super.create(res, vehicleModelModel, data);

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: updated,
    });
  });

  static getVehicleModel = catchAsyncErrors(async (req, res, next) => {
    const { id } = req.body;
    const vehicleModel = await vehicleModelModel.findOne({ _id: id });
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: vehicleModel,
    });
  });

  static deleteVehicleModel = catchAsyncErrors(async (req, res, next) => {
    const { id } = req.body;
    const updated = await super.deleteById(vehicleModelModel, id);
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: updated,
    });
  });
  // ================= vehicle model ENDS ====================

  // ================= vehicle ====================
  static vehicleList = catchAsyncErrors(async (req, res, next) => {
    // let updateVehiclesAc = await vehicleModel.updateMany(
    //   {}, 
    //   {
    //     $set: {
    //       "isAC": true,
    //     }
    //   }
    // );
    // let updateVehiclesSeatingArrangement = await vehicleModel.updateMany(
    //   {}, 
    //   {
    //     $set: {
    //       "seatingArrangement": "2+2",
    //     }
    //   }
    // );

    let totalVehicles = [];
    let vehicles = [];
    let filteredVehicle = [];

		let totalCount = 0;
		let totalPages= 0;
		let page = 0;
		let limit = 0;
		let skip = 0;

    if (req.method == "POST") {
			// Pagination parameters ===========
			page = req.body.pageNo ? parseInt(req.body.pageNo) : 1; // Current page number
			limit = req.body.documentPerPage ? parseInt(req.body.documentPerPage) : 3; // Number of documents per page
			skip = (page - 1) * limit; // Number of documents to skip
			// Pagination parameters ===========

      const { text, modelId } = req.body;

      let match = {
        $and: [
          {
            $or: [
              {
                registrationNumber: {
                  $regex: ".*" + text + ".*",
                  $options: "i",
                },
              },
              {
                chassisNumber: {
                  $regex: ".*" + text + ".*",
                  $options: "i",
                },
              },
            ],
          },
        ],
      };
      if (modelId != "") {
        const vehicleModel = await vehicleModelModel.findOne({ _id: modelId });
        match["modelId"] = vehicleModel._id;
      }
      const aggregatorOpts = [
        {
          $addFields: {
            registrationNumber: "$registrationNumber",
            chassisNumber: "$chassisNumber",
            modelId: "$modelId",
          },
        },
        {
          $match: match,
        },
				{
          $sort: { createdAt: -1 } // Sort by createdAt in descending order
        },
      ];
      totalVehicles = await vehicleModel.aggregate(aggregatorOpts).exec();
      vehicles = await vehicleModel.aggregate(aggregatorOpts).skip(skip).limit(limit).exec();
      // =========== populate details of references =============
      await vehicleModelModel.populate(vehicles, [
        {
          path: "modelId",
          model: "vehicleModelCollection",
          populate: {
            path: "type",
            model: "vehicleCategoriesCollection",
          },
        },
        {
          path: "assets", // array of objIds ====
          model: "assetCollection",
          populate: {
            path: "apiId",
            model: "trackingApiCollection",
          },
        },
      ]);
      // =========== populate details of references =============
      let super_admin = await rollModel.findOne({ name: "Super Admin" });
      let superUser = await userModel.findOne({ roleId: super_admin._id.toString() });

      let admin_userRole = await rollModel.findOne({ name: "Admin User" });
      let adminUser = await userModel.findOne({ roleId: admin_userRole._id.toString() });

      if(superUser._id.toString() == req.user._id){
        // superadmin using =======
        filteredVehicle = vehicles
      } else if(adminUser._id.toString() == req.user._id){
        // adminUser using =======
        filteredVehicle = vehicles
      }
      else {
        // other user =========
        let loggedCorporate = await corporateModel.findOne({
          userId: req.user._id
        });
        let vendorVehicleMapping = await vendorVehicleModel.find({
          vendorId: loggedCorporate._id
        });
        let mappedVehicleIdArr = [];
        vendorVehicleMapping.forEach((mappedVehicle)=>{
          mappedVehicleIdArr.push(mappedVehicle.vehicleId.toString())
        })
        filteredVehicle = vehicles.filter((vehicle) => {
          if(mappedVehicleIdArr.includes(vehicle._id.toString())){
            return vehicle;
          }
        });
      }
    } else {
      // ======== for dropdown ========
      vehicles = await super.getList(req, vehicleModel, "");
      // =========== populate details of references =============
      await vehicleModelModel.populate(vehicles, [
        {
          path: "modelId",
          model: "vehicleModelCollection",
          populate: {
            path: "type",
            model: "vehicleCategoriesCollection",
          },
        },
        {
          path: "assets", // array of objIds ====
          model: "assetCollection",
          populate: {
            path: "apiId",
            model: "trackingApiCollection",
          },
        },
      ]);
      // =========== populate details of references =============
      let super_admin = await rollModel.findOne({ name: "Super Admin" });
      let superUser = await userModel.findOne({ roleId: super_admin._id.toString() });

      let admin_userRole = await rollModel.findOne({ name: "Admin User" });
      let adminUser = await userModel.findOne({ roleId: admin_userRole._id.toString() });

      if(superUser._id.toString() == req.user._id){
        // superadmin using =======
        filteredVehicle = vehicles

      } else if(adminUser._id.toString() == req.user._id){
        // adminUser using =======
        filteredVehicle = vehicles
      }
      else {
        // other user =========
        let loggedCorporate = await corporateModel.findOne({
          userId: req.user._id
        });
        let vendorVehicleMapping = await vendorVehicleModel.find({
          vendorId: loggedCorporate._id
        });
        let mappedVehicleIdArr = [];
        vendorVehicleMapping.forEach((mappedVehicle)=>{
          mappedVehicleIdArr.push(mappedVehicle.vehicleId.toString())
        })
        filteredVehicle = vehicles.filter((vehicle) => {
          if(mappedVehicleIdArr.includes(vehicle._id.toString())){
            return vehicle;
          }
        });
      }
    }

		totalCount = totalVehicles.length;
    totalPages= Math.ceil(totalCount/limit);

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      // data: vehicles,
      data: vehicleModelDetails(filteredVehicle),
			pagination: {
				total: totalCount,
				totalPages: totalPages,
				rowsPerPage: limit,
				currentPage: page,
				hasNextPage: page < totalPages,
				hasPrevPage: page > 1
			},
    });
  });

  static vehicleAddUpdate = catchAsyncErrors(async (req, res, next) => {
    let { isAC, modelId, assets, registrationNumber, chassisNumber, manufacturerDate, seatingArrangement, capacity, _id, } = req.body;
    // console.log(isAC); // on, off
    // =========== single file upload ================
    let fileName = "";

    if (req.files.imagePath) {
      let image = await fileUploaderSingle( "./src/public/uploads/vehicles/", req.files.imagePath );
      fileName = image.newfileName;
    }
    // =========== single file upload ================
    const data = {
      modelId: modelId,
      assets: assets,
      registrationNumber: registrationNumber,
      chassisNumber: chassisNumber,
      manufacturerDate: manufacturerDate,
      seatingArrangement: seatingArrangement,
      capacity: Math.abs(capacity),
      isAC: (isAC == "on")? true : false,
    };
    if (fileName != "") {
      data.imagePath = fileName;
    }
    let updated =
      _id && _id != null && _id != ""
        ? await super.updateById(vehicleModel, _id.toString(), data)
        : await super.create(res, vehicleModel, data);

    // =============================================================================
    let super_admin = await rollModel.findOne({ name: "Super Admin" });
    let superUser = await userModel.findOne({ roleId: super_admin._id.toString() });
    // =============================================================================
    if(
      superUser._id.toString() != req.user._id
    ){
      // if user is not superAdmin ======== map vehicle to the respective vendor too =======
      let corprateIdOfVendor = await corporateModel.findOne({ userId: req.user._id });
      let data = {
        vendorId: corprateIdOfVendor._id,
        vehicleId: updated._id,
      };
      let mapped =
        _id && _id != null && _id != ""
          ? ""
          : await super.create(res, vendorVehicleModel, data);

      if(mapped){
        // console.log("Vehicle mapped to logged vendor.");
        return requestHandler.sendSuccess(
          res,
          "Successful"
        )({
          data: mapped,
        });
      } else {
        // console.log("Mapping not affected.");
        return requestHandler.sendSuccess(
          res,
          "Successful"
        )({
          data: mapped,
        });

      }

    } else {
      return requestHandler.sendSuccess(
        res,
        "Successful"
      )({
        data: updated,
      });
    }

  });

  static getVehicle = catchAsyncErrors(async (req, res, next) => {
    const { id } = req.body;
    let vehicle = await vehicleModel.findOne({ _id: id });
    let obj = {
      _id: vehicle._id,
      modelId: vehicle.modelId,
      assets: vehicle.assets,
      registrationNumber: vehicle.registrationNumber,
      chassisNumber: vehicle.chassisNumber,
      manufacturerDate: dateFormatYYYYMMDD(vehicle.manufacturerDate),
      imagePath: APPURL+"uploads/vehicles/"+vehicle.imagePath,
      seatingArrangement: vehicle.seatingArrangement,
      capacity: vehicle.capacity,
      isAC: vehicle.isAC,
    };
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: obj,
    });
  });

  static deleteVehicle = catchAsyncErrors(async (req, res, next) => {
    const { id } = req.body;
    let vendorVehicleMappingExist = await vendorVehicleModel.find({
      vehicleId: id,
    });
    if(vendorVehicleMappingExist){
      if(vendorVehicleMappingExist.length > 0){
        vendorVehicleMappingExist.forEach(async (mapping)=>{
          let vendorVehicleMappingDelete = await super.deleteById(vendorVehicleModel, mapping._id);
        });
      }
    }
    const updated = await super.deleteById(vehicleModel, id);
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: updated,
    });
  });
  // ================= vehicle ENDS ====================

  // ================= vendor vehicle mapping ====================
  static vendorVehicleMapList = catchAsyncErrors(async (req, res, next) => {
    let { text, vendorId, vehicleId, tripId } = req.body;
    let mappings = [];
    let match = {};
    if (vendorId && vendorId != "") {
      let vendor = await corporateModel.findOne({ _id: vendorId });
      match["vendorId"] = vendor._id;
    }
    if (vehicleId && vehicleId != "") {
      let vehicle = await vehicleModel.findOne({ _id: vehicleId });
      match["vehicleId"] = vehicle._id;
    }
    let trip = [];
    if(tripId){
      let vehicles = []
      trip = await tripsModel.findOne({ _id: tripId });
      await tripPlanModel.populate(
        trip,
        [
          {
            "path": "tripPlanId",
            "model": "tripPlanCollection",
          },
        ]
      );
      let existing_trip = await tripsModel.find({ 
        $and: [
          { _id: { $ne: tripId } },
          {  
            tripDate: trip.tripDate
          }
          // {
          //   $or:[ 
          //     {'tripStartTime':
          //       {
          //         $gte: trip.tripStartTime, 
          //         $lt: trip.tripEndTime
          //       }
          //     }, 
          //     {'tripEndTime':
          //       {
          //         $gte: trip.tripStartTime, 
          //         $lt: trip.tripEndTime
          //       }
          //     }
          //   ]
          // }
        ]
      });
      await vehicleModel.populate(
        existing_trip,
        [
          {
            "path": "vehicleId",
            "model": "vehicleCollection"
          },
        ]
      );
      if(existing_trip.length > 0){
        existing_trip.forEach(elem => {
          if(
            elem.vehicleId 
            && (elem.vehicleId != null) 
          ){
            vehicles.push(elem.vehicleId._id)
          }
        })
        if(vehicles.length > 0){
          match["vehicleId"] = {
              $nin: vehicles
          }
        }
      }
    }

    const aggregatorOpts = [
      {
        $addFields: {
          vendorId: "$vendorId",
          vehicleId: "$vehicleId",
        },
      },
      {
        $match: match,
      },
    ];
    mappings = await vendorVehicleModel.aggregate(aggregatorOpts).exec();
    await corporateModel.populate(mappings, [
      {
        path: "vendorId",
        model: "corporateCollection",
      },
      {
        path: "vehicleId",
        model: "vehicleCollection",
        populate: {
          path: "modelId",
          model: "vehicleModelCollection",
					populate: {
						path: "type",
						model: "vehicleCategoriesCollection",
					},
        },
      },
    ]);

    let accessibilityWiseMappings = [];

    if(tripId){
      accessibilityWiseMappings = mappings.filter((mapping)=>{
        if(mapping.vehicleId.capacity == trip.tripPlanId.accessibility){
          return mapping;
        }
      });
    } else {
      accessibilityWiseMappings = mappings
    }

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: vendorVehicleMapDetails(accessibilityWiseMappings),
      // data: vendorVehicleMapDetails(mappings),
      // data: mappings,
    });
  });

	static vendorVehicleMapListWithPagination = catchAsyncErrors(async (req, res, next) => {
    let totalMappings = [];
    let mappings = [];

		let totalCount = 0;
		let totalPages= 0;
		let page = 0;
		let limit = 0;
		let skip = 0;

		// Pagination parameters ===========
		page = req.body.pageNo ? parseInt(req.body.pageNo) : 1; // Current page number
		limit = req.body.documentPerPage ? parseInt(req.body.documentPerPage) : 3; // Number of documents per page
		skip = (page - 1) * limit; // Number of documents to skip
		// Pagination parameters ===========

    let { text, vendorId, vehicleId, tripId } = req.body;

    let match = {};
    if (vendorId && vendorId != "") {
      let vendor = await corporateModel.findOne({ _id: vendorId });
      match["vendorId"] = vendor._id;
    }
    if (vehicleId && vehicleId != "") {
      let vehicle = await vehicleModel.findOne({ _id: vehicleId });
      match["vehicleId"] = vehicle._id;
    }
    let trip = [];
    if(tripId){
      let vehicles = []
      trip = await tripsModel.findOne({ _id: tripId });
      await tripPlanModel.populate(
        trip,
        [
          {
            "path": "tripPlanId",
            "model": "tripPlanCollection",
          },
        ]
      );
      let existing_trip = await tripsModel.find({ 
        $and: [
          { _id: { $ne: tripId } },
          {  
            tripDate: trip.tripDate
          }
          // {
          //   $or:[ 
          //     {'tripStartTime':
          //       {
          //         $gte: trip.tripStartTime, 
          //         $lt: trip.tripEndTime
          //       }
          //     }, 
          //     {'tripEndTime':
          //       {
          //         $gte: trip.tripStartTime, 
          //         $lt: trip.tripEndTime
          //       }
          //     }
          //   ]
          // }
        ]
      });
      await vehicleModel.populate(
        existing_trip,
        [
          {
            "path": "vehicleId",
            "model": "vehicleCollection"
          },
        ]
      );
      if(existing_trip.length > 0){
        existing_trip.forEach(elem => {
          if(
            elem.vehicleId 
            && (elem.vehicleId != null) 
          ){
            vehicles.push(elem.vehicleId._id)
          }
        })
        if(vehicles.length > 0){
          match["vehicleId"] = {
              $nin: vehicles
          }
        }
      }
    }

    const aggregatorOpts = [
      {
        $addFields: {
          vendorId: "$vendorId",
          vehicleId: "$vehicleId",
        },
      },
      {
        $match: match,
      },
			{
				$sort: { createdAt: -1 } // Sort by createdAt in descending order
			},
    ];
    totalMappings = await vendorVehicleModel.aggregate(aggregatorOpts).exec();
    mappings = await vendorVehicleModel.aggregate(aggregatorOpts).skip(skip).limit(limit).exec();
    await corporateModel.populate(mappings, [
      {
        path: "vendorId",
        model: "corporateCollection",
      },
      {
        path: "vehicleId",
        model: "vehicleCollection",
        populate: {
          path: "modelId",
          model: "vehicleModelCollection",
					populate: {
						path: "type",
						model: "vehicleCategoriesCollection",
					},
        },
      },
    ]);

    let accessibilityWiseMappings = [];
    let accessibilityWiseTotalMappings = [];

    if(tripId){
      accessibilityWiseMappings = mappings.filter((mapping)=>{
        if(mapping.vehicleId.capacity == trip.tripPlanId.accessibility){
          return mapping;
        }
      });
      
			accessibilityWiseTotalMappings = totalMappings.filter((mapping)=>{
        if(mapping.vehicleId.capacity == trip.tripPlanId.accessibility){
          return mapping;
        }
      });
    } else {
      accessibilityWiseMappings = mappings
      accessibilityWiseTotalMappings = totalMappings
    }

		totalCount = accessibilityWiseTotalMappings.length;
    totalPages= Math.ceil(totalCount/limit);

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      // data: vendorVehicleMapDetails(mappings),
      // data: mappings,
      data: vendorVehicleMapDetails(accessibilityWiseMappings),
			pagination: {
        total: totalCount,
        totalPages: totalPages,
        rowsPerPage: limit,
        currentPage: page,
        hasNextPage: page < totalPages,
        hasPrevPage: page > 1
      },
    });
  });

  static vendorVehicleMapAddUpdate = catchAsyncErrors( async (req, res, next) => {
    let { vendorId, vehicleId, _id } = req.body;
    let data = {
      vendorId: vendorId,
      vehicleId: vehicleId,
    };
    let checkExist = await super.getByCustomOptionsSingle(
      req,
      vendorVehicleModel,
      data
    );
    if (checkExist == null) {
      // if mapping does not exist already =====
      let updated =
        _id && _id != null && _id != ""
          ? await super.updateById(vendorVehicleModel, _id.toString(), data)
          : await super.create(res, vendorVehicleModel, data);

      return requestHandler.sendSuccess(
        res,
        "Successful"
      )({
        data: updated,
      });
    } else {
      // if mapping exist already =====
      return res.status(400).json({
        status: false,
        message: "Vehicle already mapped to this vendor.",
        data: checkExist,
      });
    }
  });
	static getVendorVehicleMapDetail = catchAsyncErrors(async (req, res, next) => {
    let { id } = req.body;
    let vendorVehicleMapDetail = await vendorVehicleModel.findOne({ _id: id });
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: vendorVehicleMapDetail,
    });
  });
	static deleteVendorVehicleMapDetail = catchAsyncErrors(async (req, res, next) => {
    const { id } = req.body;
    const updated = await super.deleteById(vendorVehicleModel, id);
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: updated,
    });
  });
  // ================= vendor vehicle mapping ENDS ====================
}

module.exports = VehicleController;
