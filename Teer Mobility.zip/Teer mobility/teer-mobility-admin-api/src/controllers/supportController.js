const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/errorHandler");
const RequestHandler = require("../utils/RequestHandler");
const mongoose = require("mongoose");
const ObjectId = mongoose.Types.ObjectId;

const {
  calculateDistance,
  calculateDistanceInsTentApi,
  calculateTimeInKilometers,
  getRateChartCategory,
} = require("../utils/utilities");
const {
  vehicleCategoryDetails,
  vehicleModelDetails,
  couponDetails,
  supportDetails,
} = require("../utils/common");
const {
  MSG_RECORD_STATUS_SUCCESS,
  MSG_RECORD_FETCH_SUCCESS,
} = require("../config/constants");
const requestHandler = new RequestHandler();

const roleModel = require("../models/rollModel");
const userModel = require("../models/userModel");
const corporateModel = require("../models/corporateModel");
const generalSupportModel = require("../models/generalSupportModel");
const enqueryModel = require("../models/enqueryModel");

class SupportController extends BaseController {
  constructor() {
    super();
  }

  static getsupportDetail = catchAsyncErrors(async (req, res, next) => {
    let { userId } = req.body;

    let loggedUser = await userModel.findOne({
      _id: userId,
    });
    
    let roleOfLoggedUser = await roleModel.findOne({
      _id: loggedUser?.roleId,
    });
    
    if(
      (roleOfLoggedUser.name == "Super Admin") ||
      (roleOfLoggedUser.name == "Admin User")
    ){
      let generalSupport = await generalSupportModel.findOne({
        // userId: userId,
      });
      
      return res.status(200).json({
        status: true,
        message: "Support details found.",
        data: {
          supportEmail: generalSupport?.supportEmail || "",
          phoneNumber: generalSupport?.phoneNumber || "",
        }
      });

    } else if(
      (roleOfLoggedUser.name == "Corporate")
      || (roleOfLoggedUser.name == "School")
      || (roleOfLoggedUser.name == "Vendor")
    ){
      let corporate = await corporateModel.findOne({
        userId: userId,
      });
      
      return res.status(200).json({
        status: true,
        message: "Support details found.",
        data: {
          supportEmail: corporate?.supportEmail || "",
          phoneNumber: corporate?.phoneNumber || "",
        }
      });
    }

  });

  static supportDetailAddUpdate = catchAsyncErrors(async (req, res, next) => {
    let { supportEmail, phoneNumber } = req.body;

    let loggedUser = await userModel.findOne({
      _id: req.user._id,
    });
    
    let roleOfLoggedUser = await roleModel.findOne({
      _id: loggedUser?.roleId,
    });

    if(
      (roleOfLoggedUser.name == "Super Admin") ||
      (roleOfLoggedUser.name == "Admin User")
    ){
      let checkSuppportDetailsExist = await generalSupportModel.findOne({
        // userId: req.user._id,
        isActive: true,
      });

      let supportData = {
        // userId: req.user._id,
        supportEmail: supportEmail,
        phoneNumber: phoneNumber,
      };
      
      let updatedSupport = 
        (checkSuppportDetailsExist && checkSuppportDetailsExist.userId != "" && checkSuppportDetailsExist.userId != null)
          ? await super.updateByCustomOptions(
              generalSupportModel, 
              {
                // userId: req.user._id,
                isActive: true,
              },
              {
                supportEmail: supportEmail,
                phoneNumber: phoneNumber,
              }
            )
          : await super.create(res, generalSupportModel, supportData);
      
      if(updatedSupport){
        return res.status(200).json({
          status: true,
          message: "Support details updated.",
          data: {
            supportEmail: updatedSupport?.supportEmail || "",
            phoneNumber: updatedSupport?.phoneNumber || "",
          }
        });
      } else {
        return re.status(400).json({
          status: false,
          message: "Oopss..!! Something went wrong",
          data: {
            supportEmail: "",
            phoneNumber: "",
          }
        });
      }
    } else if(
      (roleOfLoggedUser.name == "Corporate") 
      || (roleOfLoggedUser.name == "School")
      || (roleOfLoggedUser.name == "Vendor")
    ){
      let corporateAccountOfLoggedUser = await corporateModel.findOne({
        userId: req.user._id,
      });

      let updatedCoporate = 
        (corporateAccountOfLoggedUser && corporateAccountOfLoggedUser._id != "" && corporateAccountOfLoggedUser._id != null)
          ? await super.updateByCustomOptions(
              corporateModel, 
              {
                userId: req.user._id,
              },
              {
                supportEmail: supportEmail,
                phoneNumber: phoneNumber,
              }
            )
          : "";

      if(updatedCoporate){
        return res.status(200).json({
          status: true,
          message: "Support details updated.",
          data: {
            supportEmail: updatedCoporate?.supportEmail || "",
            phoneNumber: updatedCoporate?.phoneNumber || "",
          }
        });
      } else {
        return re.status(400).json({
          status: false,
          message: "Oopss..!! Something went wrong",
          data: {
            supportEmail: "",
            phoneNumber: "",
          }
        });
      }
    }
  });

  static supportListWithPagination = catchAsyncErrors(async (req, res, next) => {
    let { fromDate, toDate } = req.body;
    let totalCount = 0;
    let totalPages= 0;
    // Pagination parameters ===========
    const page = req.body.pageNo ? parseInt(req.body.pageNo) : 1; // Current page number
    const limit = req.body.documentPerPage ? parseInt(req.body.documentPerPage) : 3; // Number of documents per page
    const skip = (page - 1) * limit; // Number of documents to skip
    // Pagination parameters ===========

    let totalSupportRequests = [];
    let supportRequests = [];
    let match = {};

    if(fromDate){
      match["createdAt"] = {
        $gte: new Date(fromDate)
      };
    }
    if(toDate){
      match["createdAt"] = {
        $lte: new Date(toDate)
      };
    }

    const aggregatorOpts = [
      {
        $addFields: {
          createdAt: "$createdAt",
        },
      },
      {
        $match: match,
      },
      {
        $sort: { createdAt: -1 } // Sort by createdAt in descending order
      },
    ];

    totalSupportRequests = await enqueryModel.aggregate(aggregatorOpts).exec();
    supportRequests = await enqueryModel.aggregate(aggregatorOpts).skip(skip).limit(limit).exec();
    await userModel.populate(
      supportRequests,
      [
        {
          "path": "userId",
          "model": "usersCollection",
        },
        {
          "path": "replies.repliedBy",
          "model": "usersCollection",
        }
      ]
    );

    totalCount = totalSupportRequests.length;
    totalPages= Math.ceil(totalCount/limit);

    if(supportRequests.length > 0){
      return res.status(200).json({
        status: true,
        message: "Support requests found.",
        data: {
          data: supportDetails(supportRequests),
          pagination: {
            total: totalCount,
            totalPages: totalPages,
            rowsPerPage: limit,
            currentPage: page,
            hasNextPage: page < totalPages,
            hasPrevPage: page > 1
          },
        }
      });
    } else {
      return res.status(200).json({
        status: true,
        message: "No support requests found.",
        data: {
          data: [],
          pagination: {
            total: totalCount,
            totalPages: totalPages,
            rowsPerPage: limit,
            currentPage: page,
            hasNextPage: page < totalPages,
            hasPrevPage: page > 1
          },
        },
      });
    }
  });

  static sendReplyToCustomer = catchAsyncErrors(async (req, res, next) => {
    let { _id, message, } = req.body;

    // Get the current time in "Asia/Kolkata" time zone =======
    let momentKolkata = moment().tz('Asia/Kolkata');
    let currentDate = momentKolkata.format('YYYY-MM-DD');
	  let currentDay = momentKolkata.format('dddd');
    let currentTime = momentKolkata.format('HH:mm');
		// Get the current time in "Asia/Kolkata" time zone =======

    let checkReplyExist = await enqueryModel.findOne({
      _id: _id,
    });

    let repliesArr = [];
    if(checkReplyExist && checkReplyExist.replies.length > 0){
      checkReplyExist.replies.forEach((reply) => {
        repliesArr.push(reply);
      });
    } 

    let replyObj = {
      date: currentDate,
      message: message,
      repliedBy: req.user._id,
    };
    repliesArr.push(replyObj);

    let replySubmit = await super.updateById(enqueryModel, _id.toString(), {
      replies: repliesArr
    });

    if(replySubmit){
      return res.status(200).json({
        status: true,
        message: "Successfully sent.",
        data: {}
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Something wrong happened while sending reply.",
        data: {}
      });
    }
  });

}

module.exports = SupportController;
