const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/errorHandler");
const RequestHandler = require("../utils/RequestHandler");
const mongoose = require("mongoose");
const ObjectId = mongoose.Types.ObjectId;

const {
  calculateDistance,
  calculateDistanceInsTentApi,
  calculateTimeInKilometers,
  getRateChartCategory,
} = require("../utils/utilities");
const {
  vehicleCategoryDetails,
  vehicleModelDetails,
  getPermissionDetails,
} = require("../utils/common");
const {
  MSG_RECORD_STATUS_SUCCESS,
  MSG_RECORD_FETCH_SUCCESS,
} = require("../config/constants");
const requestHandler = new RequestHandler();

const moduleModel = require("../models/moduleModel");
const rollModel = require("../models/rollModel");
const rolePermissionModel = require("../models/rolePermissionModel");

class RolePermissionController extends BaseController {
  constructor() {
    super();
  }

  static rolePermissionList = catchAsyncErrors(async (req, res, next) => {
    let modules = [];
    let totalRolePermissions = [];
    let rolePermissions = [];

    let totalCount = 0;
		let totalPages= 0;
		let page = 0;
		let limit = 0;
		let skip = 0;

    // Pagination parameters ===========
		page = req.body.pageNo ? parseInt(req.body.pageNo) : 1; // Current page number
		limit = req.body.documentPerPage ? parseInt(req.body.documentPerPage) : 3; // Number of documents per page
		// limit = req.body.documentPerPage ? 30 : 3; // Number of documents per page
		// skip = ((page - 1) * limit) + 1; // Number of documents to skip
		skip = ((page - 1) * limit); // Number of documents to skip
		// Pagination parameters ===========

    const { roleId, text } = req.body;

    if(req.method == "POST"){
        const super_admin = await rollModel.findOne({ name: "Super Admin" });
        let match = {
          isActive: true,
          isDeleted: false,
          roleId: {
            $ne: super_admin._id,
          },
          //   $and:[
          //     {
          //         $or: [
          //           {
          //             moduleName: {
          //               $regex: ".*" + text + ".*",
          //               $options: "i",
          //             },
          //           },
          //         ],
          //     }
          //   ]
        };
        if (roleId != "") {
            const role = await rollModel.findOne({ _id: roleId });
            match["roleId"] = role._id;
        }
        const aggregatorOpts = [
          {
            $addFields: {
                roleId: "$roleId",
            },
          },
          {
            $match: match,
          },
          {
						$sort: { createdAt: -1 } // Sort by createdAt in descending order
					},
        ];
        totalRolePermissions = await rolePermissionModel.aggregate(aggregatorOpts).exec();
        rolePermissions = await rolePermissionModel.aggregate(aggregatorOpts).skip(skip).limit(limit).exec();
        await rolePermissionModel.populate(
            rolePermissions,
            [
                {
                    path: 'roleId',
                    model: 'roleCollection',
                },
                {
                    path: 'moduleId', // array if objIds
                    model: 'moduleCollection',
                    populate: {
                        path: 'parentModuleId', 
                        model: 'moduleCollection',
                    }
                },
            ]
        );
    } else {
        // ======= for dropdown ===========
        // modules = await super.getList(req, rolePermissionModel, "");
    }

    totalCount = totalRolePermissions.length;
    // totalCount = totalRolePermissions.length - 1;
    totalPages= Math.ceil(totalCount/limit);
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: getPermissionDetails(rolePermissions),
      pagination: {
        total: totalCount,
        totalPages: totalPages,
        rowsPerPage: limit,
        currentPage: page,
        hasNextPage: page < totalPages,
        hasPrevPage: page > 1
      },
    });
  });

  static rolePermissionAddUpdate = catchAsyncErrors(async (req, res, next) => {
    const { roleId, moduleId, _id } = req.body;
    let data = {
        roleId: roleId,
        moduleId: moduleId,

        updatedBy: req.user._id,
    };
    let checkRolePermissionExists = await rolePermissionModel.findOne({
      roleId: roleId,

      isDeleted: false,
    });

    if(checkRolePermissionExists){
      if(_id && _id != null && _id != ""){
        // edit happening === do not check self ====
      } else {
        // prevent during add ====
        return res.status(400).json({
          status: false,
          message: "Permission already created for this role.",
          data: {},
        });
      }
    }
    const updated =
      _id && _id != null && _id != ""
        ? await super.updateById(rolePermissionModel, _id.toString(), data)
        : await super.create(res, rolePermissionModel, data);

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: updated,
    });
  });

  static getRolePermissionDetail = catchAsyncErrors(async (req, res, next) => {
    const { id } = req.body;
    const rolePermissionDetail = await rolePermissionModel.findOne({ _id: id });
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: rolePermissionDetail,
    });
  });

  static deleteRolePermission = catchAsyncErrors(async (req, res, next) => {
    const { id } = req.body;
    let updated = [];
    // =================== soft delete ===================
    updated = await super.updateById(rolePermissionModel, id, {
        isDeleted: true
    });
    // =================== soft delete ===================
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: updated,
    });
  });


  // =========== App APIs ================

  // =========== App APIs ================
}

module.exports = RolePermissionController;
