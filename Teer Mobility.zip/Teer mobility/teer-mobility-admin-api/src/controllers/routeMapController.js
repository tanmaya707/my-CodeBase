const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/errorHandler");
const RequestHandler = require("../utils/RequestHandler");
const mongoose = require("mongoose");
const ObjectId = mongoose.Types.ObjectId;

const {
  calculateDistance,
  calculateDistanceInsTentApi,
  calculateTimeInKilometers,
  getRateChartCategory,
} = require("../utils/utilities");
const {
  vehicleCategoryDetails,
  vehicleModelDetails,
	tripStopDetails,
	routeMapDetails,
	routeVehicleMapDetails,
} = require("../utils/common");
const {
  MSG_RECORD_STATUS_SUCCESS,
  MSG_RECORD_FETCH_SUCCESS,
} = require("../config/constants");
const requestHandler = new RequestHandler();

const moment = require('moment-timezone');
const dateFns = require('date-fns');

const countryModel = require("../models/countryModel");
const tripStopModel = require("../models/tripStopModel");
const routeMapModel = require("../models/routeMapModel");
const vehicleModel = require("../models/vehicleModel");
const routeVehicleModel = require("../models/routeVehicleModel");
const tripsModel = require("../models/tripsModel");
const tripPlanModel = require("../models/tripPlanModel");
const recentSearchesModel = require("../models/recentSearchesModel");
const userModel = require("../models/userModel");
const customerModel = require("../models/customerModel");

class RouteMapController extends BaseController {
  constructor() {
    super();
  }

  static routeMapList = catchAsyncErrors(async (req, res, next) => {
    
    let totalRouteMaps = []
    let routeMaps = []

    let totalCount = 0;
		let totalPages= 0;
		let page = 0;
		let limit = 0;
		let skip = 0;

    const { countryCode, text } = req.body;
    if(req.method == "POST"){
			// Pagination parameters ===========
      page = req.body.pageNo ? parseInt(req.body.pageNo) : 1; // Current page number
      limit = req.body.documentPerPage ? parseInt(req.body.documentPerPage) : 3; // Number of documents per page
      skip = (page - 1) * limit; // Number of documents to skip
      // Pagination parameters ===========
			let match = {
				$and: [
					{
						$or: [
							{
								routeName: {
									$regex: ".*" + text + ".*",
									$options: "i",
								},
							},
							{
								routeType: {
									$regex: ".*" + text + ".*",
									$options: "i",
								},
							},
							// {
							// 	accessibility: {
							// 		$regex: ".*" + text + ".*",
							// 		$options: "i",
							// 	},
							// },
						],
					}
				]
			};
			if(countryCode != ''){
				let country = await countryModel.findOne({ _id: countryCode });
				match['countryCode'] = country._id;
			}
			const aggregatorOpts = [
				{
					$addFields: {
						countryCode: "$countryCode",
						routeName: "$routeName",
						routeType: "$routeType",
						
					},
				},
				{
					$match: match,
				},
				{
          $sort: { createdAt: -1 } // Sort by createdAt in descending order
        },
			];
			totalRouteMaps = await routeMapModel.aggregate(aggregatorOpts).exec();
			routeMaps = await routeMapModel.aggregate(aggregatorOpts).skip(skip).limit(limit).exec();
			await countryModel.populate(
				routeMaps,
				{
					"path": "countryCode",
					"model": "countryCollection",
					"select": ["name"],
				},
			);
			await routeMapModel.populate(routeMaps, {
				"path": "routeStops.stopId",
				"model": "tripStopCollection",
			});
    } else {
			// ======= for dropdown ===========
			routeMaps = await super.getList(req, routeMapModel, "");
			await countryModel.populate(
				routeMaps,
				{
					"path": "countryCode",
					"model": "countryCollection",
					"select": ["name"],
				},
			);
			await routeMapModel.populate(routeMaps, {
				"path": "routeStops.stopId",
				"model": "tripStopCollection",
			});
    }

		totalCount = totalRouteMaps.length;
    totalPages= Math.ceil(totalCount/limit);

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      // data: routeMaps,
      data: routeMapDetails(routeMaps),
			pagination: {
				total: totalCount,
				totalPages: totalPages,
				rowsPerPage: limit,
				currentPage: page,
				hasNextPage: page < totalPages,
				hasPrevPage: page > 1
			},
    });
  });

  static routeMapAddUpdate = catchAsyncErrors(async (req, res, next) => {
    let { countryCode, routeType, routeName, routeDistance, routeTime, stopId, order, distance, _id } = req.body;
    if (!Array.isArray(stopId)) {
      stopId = [stopId];
    }
    if (!Array.isArray(order)) {
      order = [order];
    }
    if (!Array.isArray(distance)) {
      distance = [distance];
    }
    let data = {
      countryCode: countryCode,
      routeName: routeName,
      routeDistance: routeDistance,
      routeTime: routeTime,
      routeType: routeType,
    };
		let routeStopsArr = []
    if(
        stopId.length > 0 &&
        order.length > 0 &&
        distance.length > 0 &&
        stopId.length == order.length &&
        stopId.length == distance.length
    ){
			let index = 1;
			stopId.forEach((stop)=>{
				let obj = {
					stopId: stop.toString(),
					order: index,
					distance: distance[index - 1],
				}
				routeStopsArr.push(obj)
				index++
			});

			data.routeStops = routeStopsArr
    }
    const updated =
      _id && _id != null && _id != ""
        ? await super.updateById(routeMapModel, _id.toString(), data)
        : await super.create(res, routeMapModel, data);

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: updated,
    });
  });

  static getRouteMapDetail = catchAsyncErrors(async (req, res, next) => {
    const { id } = req.body;
    const route = await routeMapModel.findOne({ _id: id });
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: route,
    });
  });

  static deleteRouteMap = catchAsyncErrors(async (req, res, next) => {
    const { id } = req.body;
    const updated = await super.deleteById(routeMapModel, id);
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: updated,
    });
  });

	// ========= route-vehicle mapping =============
	static routeVehicleMapList = catchAsyncErrors(async (req, res, next) => {
    let { text, routeId, vehicleId } = req.body;
    let mappings = [];
    let match = {};
    if (routeId != "") {
      let route = await routeMapModel.findOne({ _id: routeId });
      match["routeId"] = route._id;
    }
    if (vehicleId != "") {
      let vehicle = await vehicleModel.findOne({ _id: vehicleId });
      match["vehicleId"] = vehicle._id;
    }
    const aggregatorOpts = [
      {
        $addFields: {
          routeId: "$routeId",
          vehicleId: "$vehicleId",
        },
      },
      {
        $match: match,
      },
    ];
    mappings = await routeVehicleModel.aggregate(aggregatorOpts).exec();
    await routeMapModel.populate(mappings, [
      {
        path: "routeId",
        model: "routeMapCollection",
				populate: {
					path: "countryCode",
					model: "countryCollection",
				}
      },
      {
        path: "vehicleId",
        model: "vehicleCollection",
        populate: {
          path: "modelId",
          model: "vehicleModelCollection",
					populate: {
						path: "type",
						model: "vehicleCategoriesCollection",
					},
        },
      },
    ]);

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: routeVehicleMapDetails(mappings),
      // data: mappings,
    });
  });

	static routeVehicleMappingAddUpdate = catchAsyncErrors(
    async (req, res, next) => {
      let { routeId, vehicleId, _id } = req.body;
      let data = {
        routeId: routeId,
        vehicleId: vehicleId,
      };
      let checkExist = await super.getByCustomOptionsSingle(
        req,
        routeVehicleModel,
        data
      );
      if (checkExist == null) {
        // if mapping does not exist already =====
        let updated =
          _id && _id != null && _id != ""
            ? await super.updateById(routeVehicleModel, _id.toString(), data)
            : await super.create(res, routeVehicleModel, data);

        return requestHandler.sendSuccess(
          res,
          "Successful"
        )({
          data: updated,
        });
      } else {
        // if mapping exist already =====
        return res.status(400).json({
          status: false,
          message: "Vehicle already mapped to this route.",
          data: checkExist,
        });
      }
    }
  );

	static getRouteVehicleMappingDetail = catchAsyncErrors(async (req, res, next) => {
    let { id } = req.body;
    let routeVehicleMappingDetail = await routeVehicleModel.findOne({ _id: id });
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: routeVehicleMappingDetail,
    });
  });

	static deleteRouteVehicleMappingDetail = catchAsyncErrors(async (req, res, next) => {
    const { id } = req.body;
    const updated = await super.deleteById(routeVehicleModel, id);
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: updated,
    });
  });
	// ========= route-vehicle mapping =============

  // ================= App APIs ===========================
  // ====================== search-routes-V-1.0 ======================
  static searchRoutes = catchAsyncErrors(async (req, res, next)=>{
    let totalCount = 0;
    let totalPages= 0;
    // Pagination parameters ===========
    const page = req.query.page ? parseInt(req.query.page) : 1; // Current page number
    const limit = req.query.limit ? parseInt(req.query.limit) : 3; // Number of documents per page
    const skip = (page - 1) * limit; // Number of documents to skip
    // Pagination parameters ===========

    let pickStops = [];
    let dropStops = [];

    let searchedStopsIdArr = []
    let routeMaps = []
    let country = []
    let routeMapsWithTripsCount = [];

    let { pickLat, pickLong, dropLat, dropLong, sourceDestination, dropDestination, countryCode, loggedInAs } = req.body;
    
    if(req.method == "POST"){
      let nearbyPickStops = await tripStopModel.aggregate([
        {
          "$geoNear": {
            "near": {
                "type": "Point",
                "coordinates": [ pickLat, pickLong ]
            }, 
            // "maxDistance": 0.5 * 1000, // 500 meters converted to meters
            "maxDistance": 500, // 500 meters converted to meters
            "key" : "location",
            "spherical": true,
            "distanceField": "distance",
            // "distanceMultiplier": 0.000621371, // If you want distance in miles
          }
        }
      ]);
      nearbyPickStops.forEach((stop)=>{
        pickStops.push(stop._id);
      });
      let nearbyDropStops = await tripStopModel.aggregate([
        {
          "$geoNear": {
            "near": {
                "type": "Point",
                "coordinates": [ dropLat, dropLong ]
            }, 
            // "maxDistance": 0.5 * 1000, // 500 meters converted to meters
            "maxDistance": 500, // 500 meters converted to meters
            "key" : "location",
            "spherical": true,
            "distanceField": "distance",
            "distanceMultiplier": 0.001, // Convert meters to kilometers
          }
        }
      ]);
      nearbyDropStops.forEach((stop)=>{
        dropStops.push(stop._id);
      });
      // return res.status(200).json({
      //   status: true,
      //   data: nearbyDropStops,
      // });
      // ========== case insensitive search ============
      let searchedStop = {
        $and: [
          {
            $or: [
              {
                stopName: {
                  $regex: ".*" + sourceDestination + ".*",
                  $options: "i",
                }
              },
              {
                address: {
                  $regex: ".*" + sourceDestination + ".*",
                  $options: "i",
                }
              },
              {
                stopName: {
                  $regex: ".*" + dropDestination + ".*",
                  $options: "i",
                }
              },
              {
                address: {
                  $regex: ".*" + dropDestination + ".*",
                  $options: "i",
                }
              },
            ]
          }
        ]
      };
      let countryId = {};
      if(countryCode && countryCode != ''){
        country = await countryModel.findOne({ iso2: countryCode });
        searchedStop['countryCode'] = country._id;
      }
      const tripAggregatorOpts = [
        {
          $addFields: {
            countryCode: "$countryCode",
          },
        },
        {
          $match: searchedStop,
        },
      ];
      
      let searchedStops = await tripStopModel.aggregate(tripAggregatorOpts).exec();
      // // ========== case insensitive search ============

      // // === source ====
      // let sourceDestinationRegexPattern = sourceDestination.split(/\s+/).map(word => `(?=.*${word})`).join('');
      // let searchedSource = {
      //   $and: [
      //     {
      //       $or: [
      //         {
      //           stopName: {
      //             // $regex: ".*" + sourceDestinationRegexPattern + ".*",
      //             $regex: sourceDestinationRegexPattern,
      //             $options: "i",
      //           }
      //         },
      //         {
      //           address: {
      //             // $regex: ".*" + sourceDestinationRegexPattern + ".*",
      //             $regex: sourceDestinationRegexPattern,
      //             $options: "i",
      //           }
      //         },
      //       ]
      //     }
      //   ]
      // };
      // if(countryCode && countryCode != ''){
      //   country = await countryModel.findOne({ iso2: countryCode });
      //   searchedStop['countryCode'] = country._id;
      // }
      // const sourceAggregatorOpts = [
      //   {
      //     $addFields: {
      //       countryCode: "$countryCode",
      //     },
      //   },
      //   {
      //     $match: searchedSource,
      //   },
      // ];
      
      // let searchedSourceStop = await tripStopModel.aggregate(sourceAggregatorOpts).exec();
      // let sourceStopId = [];
      // searchedSourceStop.forEach(async (stop)=>{
      //   sourceStopId.push(stop._id);
      // });
      // // === source ====
      // // === destination ====
      // // Constructing the regex pattern
      // let dropDestinationRegexPattern = dropDestination.split(/\s+/).map(word => `(?=.*${word})`).join('');
      // let searchedDestination = {
      //   $and: [
      //     {
      //       $or: [
      //         {
      //           stopName: {
      //             // $regex: ".*" + dropDestinationRegexPattern + ".*",
      //             $regex: dropDestinationRegexPattern,
      //             $options: "i",
      //           }
      //         },
      //         {
      //           address: {
      //             // $regex: ".*" + dropDestinationRegexPattern + ".*",
      //             $regex: dropDestinationRegexPattern,
      //             $options: "i",
      //           }
      //         },
      //       ]
      //     }
      //   ]
      // };
      // if(countryCode && countryCode != ''){
      //   country = await countryModel.findOne({ iso2: countryCode });
      //   searchedStop['countryCode'] = country._id;
      // }
      // const destinationAggregatorOpts = [
      //   {
      //     $addFields: {
      //       countryCode: "$countryCode",
      //     },
      //   },
      //   {
      //     $match: searchedDestination,
      //   },
      // ];
      
      // let searchedDestinationStop = await tripStopModel.aggregate(destinationAggregatorOpts).exec();
      // let destinationStopId = [];
      // searchedDestinationStop.forEach(async (stop)=>{
      //   destinationStopId.push(stop._id);
      // });
      // // === destination ====
      // searchedStopsIdArr.push(...sourceStopId, ...destinationStopId);

      // ============== add to recent search ===================
      searchedStops.forEach(async (stop)=>{
        // searchedStopsIdArr.push(stop._id);

        let data = {
          userId: req.user._id,
          stopId: stop._id,
        };
        let checkExist = await recentSearchesModel.findOne(data);

        const updated =
          checkExist?._id
            ? await super.updateById(recentSearchesModel, checkExist._id.toString(), data)
            : await super.create(res, recentSearchesModel, data);
      });
      // ============== add to recent search ===================
      
      let match = {
        $and: [
          {
            "routeStops": {
              $elemMatch: {
                "stopId": { $in: pickStops }
              }
            }
          },
          {
            "routeStops": {
              $elemMatch: {
                "stopId": { $in: dropStops }
              }
            }
          },
        ]
      };
      if(countryCode && countryCode != ''){
        country = await countryModel.findOne({ iso2: countryCode });
        match['countryCode'] = country._id;
      }
      const aggregatorOpts = [
        {
          $addFields: {
            countryCode: "$countryCode",
          },
        },
        {
          $match: match,
        },
        // {
        //   $facet: {
        //     response: [{ $skip: limit * page }, { $limit: limit }],
        //     pagination: [
        //       {
        //         $count: 'totalDocs',
        //       },
        //       {
        //         $addFields: {
        //           page: page + 1,
        //           totalPages: {
        //             $floor: {
        //               $divide: ['$totalDocs', limit],
        //             },
        //           },
        //         },
        //       },
        //     ],
        //   },
        // },
      ];

      routeMaps = await routeMapModel.aggregate(aggregatorOpts).skip(skip).limit(limit).exec();
      // return res.status(200).json({
      //   status: true,
      //   data: routeMaps,
      // });
      // ========================
      let pickStopsHexStrings = pickStops.map(objId => objId.toString());
      let dropStopsHexStrings = dropStops.map(objId => objId.toString());
      let stopOrderWiseFilteredRoute = []
      routeMaps.forEach(async (route)=>{
        let start = ''
        let end = ''
        route.routeStops.forEach((item)=>{
          if(pickStopsHexStrings.includes(item.stopId.toString())){
            start = item
          }
          if(dropStopsHexStrings.includes(item.stopId.toString())){
            end = item
          }
        });
        
        if((start != '') && (end != '') && (start.order < end.order)){
          route['pickupPoint'] = start
          route['dropPoint'] = end
          stopOrderWiseFilteredRoute.push(route)
        }
      });
      routeMaps = stopOrderWiseFilteredRoute;
      // ========================

      // return res.status(200).json({
      //   status: true,
      //   data: routeMaps
      // });
      
      // await countryModel.populate(
      //   routeMaps,
      //   {
      //     path: "countryCode",
      //     model: "countryCollection"
      //   },
      // );
      await routeMapModel.populate(routeMaps, {
        path: "routeStops.stopId",
        model: "tripStopCollection"
      });
    } else {
        // ======= for dropdown ===========
        routeMaps = await super.getList(req, routeMapModel, "");
				// await countryModel.populate(
				// 	routeMaps,
				// 	{
				// 		path: "countryCode",
				// 		model: "countryCollection"
				// 	},
				// );
				await routeMapModel.populate(routeMaps, {
					path: "routeStops.stopId",
					model: "tripStopCollection"
				});
    }

    // Get the current time in "Asia/Kolkata" time zone =======
    let momentKolkata = moment().tz('Asia/Kolkata');
    let currentDate = momentKolkata.format('YYYY-MM-DD');
		let currentDay = momentKolkata.format('dddd');
    let currentTime = momentKolkata.format('HH:mm');
		// Get the current time in "Asia/Kolkata" time zone =======

    let todayTrips = await tripsModel.find(
      {
        tripDate: currentDate
      }
    ).populate(
      {
        "path": "tripPlanId",
        "model": "tripPlanCollection"
      }
    );

    let userService = await customerModel.findOne({
      userId: req.user._id,
      roleId: loggedInAs
    }).populate("roleId");

    // console.log("req.user._id ======>");
    // console.log(req.user._id);
    // console.log("loggedInAs ======>");
    // console.log(loggedInAs);
    // console.log("userService ======>");
    // console.log(userService);

    let corporateIdsOfLoggedUser = [];
    if(userService){
      userService.corporates.forEach((corporate)=>{
        corporateIdsOfLoggedUser.push(corporate.corporateId.toString());
      });
    }
    
    let onDemandWiseFilteredTrips = [];
    // ========= choosen service wise filtration =========
    if(userService?.roleId?.name == "Employee"){
      routeMapsWithTripsCount = routeMaps.map((routeMap)=>{
        let filteredTrips = todayTrips.filter((todayTrip)=>{
          if(
            todayTrip?.tripPlanId?.routeId.toString() == routeMap?._id.toString() &&
            corporateIdsOfLoggedUser.includes(todayTrip?.tripPlanId?.corporateId.toString())
          ){
            return todayTrip;
          }
        });
        let tripsCount = filteredTrips.length;
  
        // ========= Number of trips available for the searched route ============
        routeMap.tripsCount = tripsCount;
        // ========= Number of trips available for the searched route ============
  
        return routeMap;
      });
    } else if(userService?.roleId?.name == "Student"){
      routeMapsWithTripsCount = routeMaps.map((routeMap)=>{
        let filteredTrips = todayTrips.filter((todayTrip)=>{
          if(
            todayTrip?.tripPlanId?.routeId.toString() == routeMap?._id.toString() &&
            corporateIdsOfLoggedUser.includes(todayTrip?.tripPlanId?.corporateId.toString())
          ){
            return todayTrip;
          }
        });
        let tripsCount = filteredTrips.length;
  
        // ========= Number of trips available for the searched route ============
        routeMap.tripsCount = tripsCount;
        // ========= Number of trips available for the searched route ============
  
        return routeMap;
      });
    } else if(userService?.roleId?.name == "Customer"){
      routeMapsWithTripsCount = routeMaps.map((routeMap)=>{
        let filteredTrips = todayTrips.filter((todayTrip)=>{
          if(todayTrip?.tripPlanId?.routeId.toString() == routeMap?._id.toString()){
            return todayTrip;
          }
        });
        let tripsCount = filteredTrips.length;
  
        // ========= Number of trips available for the searched route ============
        routeMap.tripsCount = tripsCount;
        // ========= Number of trips available for the searched route ============
  
        return routeMap;
      });
    }
    // ========= choosen service wise filtration =========
    
    let routeMapsWithTripsCountWhereTripsAvailable = routeMapsWithTripsCount.filter((route)=>{
      if(Number(route.tripsCount) > 0){
        return route;
      }
    });

    totalCount = routeMapsWithTripsCountWhereTripsAvailable.length;
    totalPages= Math.ceil(totalCount/limit);

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: routeMapDetails(routeMapsWithTripsCountWhereTripsAvailable),
      pagination: {
          total: totalCount,
          totalPages: totalPages,
          rowsPerPage: limit,
          currentPage: page,
          hasNextPage: page < totalPages,
          hasPrevPage: page > 1
      },
      // data: routeMaps,
    });
  });
  // ====================== search-routes-V-1.0 ======================
  
  // ====================== search-routes-V-2.0 with logic revamp ======================
  static searchRoutesV2 = catchAsyncErrors(async (req, res, next)=>{
    let totalCount = 0;
    let totalPages= 0;
    // Pagination parameters ===========
    const page = req.query.page ? parseInt(req.query.page) : 1; // Current page number
    const limit = req.query.limit ? parseInt(req.query.limit) : 3; // Number of documents per page
    const skip = (page - 1) * limit; // Number of documents to skip
    // Pagination parameters ===========

    let country = [];

    let pickStops = [];
    let dropStops = [];

    let searchedStopsIdArr = [];
    let tripsWithinSeachedDate = [];
    let routeMapsWithPickupMatching = [];
    let routeMapsWithTripsCount = [];

    let routeMaps = [];

    let { pickLat, pickLong, dropLat, dropLong, sourceDestination, dropDestination, fromDate, toDate, countryCode, loggedInAs } = req.body;

    // Get the current time in "Asia/Kolkata" time zone =======
    let momentKolkata = moment().tz('Asia/Kolkata');
    let currentDate = momentKolkata.format('YYYY-MM-DD');
		let currentDay = momentKolkata.format('dddd');
    let currentTime = momentKolkata.format('HH:mm');
		// Get the current time in "Asia/Kolkata" time zone =======

    // Clone the moment object to a new variable to add 7 days
    let sevenDaysFromCurrentDate = momentKolkata.clone().add(7, 'days').format('YYYY-MM-DD');

    if(req.method == "POST"){
      let matchSevenDaysTrips = {
        $and: [
        	{
    				tripDate: {
    					$gte: new Date(currentDate)
    				},
    			},
        	{
    				tripDate: {
    					$lte: new Date(sevenDaysFromCurrentDate)
    				},
    			},
        ]
      };
      // if(countryCode != ''){
      // 	let country = await countryModel.findOne({ iso2: countryCode });
      // 	match['countryCode'] = country._id;
      // }
      const aggregatorOptsSevenDaysTrips = [
        {
          $addFields: {
            // tripName: "$tripName",
          },
        },
        {
          $match: matchSevenDaysTrips,
        },
      ];
      tripsWithinSeachedDate = await tripsModel.aggregate(aggregatorOptsSevenDaysTrips).exec();

      await tripPlanModel.populate(tripsWithinSeachedDate, [
        {
          path: "tripPlanId",
          model: "tripPlanCollection",
          populate: [
            {
              path: "routeId",
              model: "routeMapCollection",
            },
            {
              path: "corporateId",
              model: "corporateCollection",
              populate: {
                path: "userId",
                model: "usersCollection",
              },
            },
            {
              path: "vendorId",
              model: "corporateCollection",
              populate: {
                path: "userId",
                model: "usersCollection",
              },
            },
          ],
        },
        {
          path: "driverId",
          model: "driverCollection",
          populate: {
            path: "userId",
            model: "usersCollection",
            populate: {
              path: "roleId",
              model: "roleCollection",
            },
          },
        },
      ]);
      await routeMapModel.populate(tripsWithinSeachedDate, [
        {
          path: "tripPlanId.routeId.routeStops.stopId",
          model: "tripStopCollection",
        },
      ]);

      let stopIdsOfTripsWithinSearchDate = [];
      tripsWithinSeachedDate.forEach(async (trip)=>{
        trip.tripPlanId.routeId.routeStops.forEach(async (stop)=>{
          // will contain duplicates -----
          stopIdsOfTripsWithinSearchDate.push(stop.stopId._id);
        });
      });

      let uniqueStopIdsOfTripsWithinSearchDate = [...new Set(stopIdsOfTripsWithinSearchDate)];
      
      let nearbyPickStops = await tripStopModel.aggregate([
        {
          $geoNear: {
            near: {
              type: "Point",
              coordinates: [pickLat, pickLong]
            },
            maxDistance: 500, // search within 500 meters 
            distanceField: "distance",
            spherical: true,
            key: "location"
            // distanceMultiplier: 0.000621371, // If you want distance in miles
          }
        },
        {
          $match: {
            _id: { $in: uniqueStopIdsOfTripsWithinSearchDate }
          }
        },
      ]);

      nearbyPickStops.forEach((stop)=>{
        pickStops.push(stop._id);
      });

      let pickStopsMatch = {
        $and: [
          {
            "routeStops": {
              $elemMatch: {
                "stopId": { $in: pickStops }
              }
            }
          }
        ]
      };
      if(countryCode && countryCode != ''){
        country = await countryModel.findOne({ iso2: countryCode });
        match['countryCode'] = country._id;
      }
      const pickStopsAggregatorOpts = [
        {
          $addFields: {
            countryCode: "$countryCode",
          },
        },
        {
          $match: pickStopsMatch,
        },
      ];
      routeMapsWithPickupMatching = await routeMapModel.aggregate(pickStopsAggregatorOpts).exec();

      let stopIdsOfRouteMapsWithPickupMatching = [];
      routeMapsWithPickupMatching.forEach(async (route)=>{
        route.routeStops.forEach(async (stop)=>{
          stopIdsOfRouteMapsWithPickupMatching.push(stop.stopId);
        });
      });

      let uniqueStopIdsOfRouteMapsWithPickupMatching = [...new Set(stopIdsOfRouteMapsWithPickupMatching)];

      let nearbyDropStops = await tripStopModel.aggregate([
        {
          $geoNear: {
            near: {
                type: "Point",
                coordinates: [ dropLat, dropLong ]
            },
            maxDistance: 500, // search within 500 meters 
            distanceField: "distance",
            spherical: true,
            key: "location"
            // distanceMultiplier: 0.000621371, // If you want distance in miles
          }
        },
        {
          $match: {
            _id: { $in: uniqueStopIdsOfRouteMapsWithPickupMatching }
          }
        },
      ]);

      nearbyDropStops.forEach((stop)=>{
        dropStops.push(stop._id);
      });

      // ========== case insensitive search ============
      let searchedStop = {
        $and: [
          {
            $or: [
              {
                stopName: {
                  $regex: ".*" + sourceDestination + ".*",
                  $options: "i",
                }
              },
              {
                address: {
                  $regex: ".*" + sourceDestination + ".*",
                  $options: "i",
                }
              },
              {
                stopName: {
                  $regex: ".*" + dropDestination + ".*",
                  $options: "i",
                }
              },
              {
                address: {
                  $regex: ".*" + dropDestination + ".*",
                  $options: "i",
                }
              },
            ]
          }
        ]
      };
      let countryId = {};
      if(countryCode && countryCode != ''){
        country = await countryModel.findOne({ iso2: countryCode });
        searchedStop['countryCode'] = country._id;
      }
      const tripAggregatorOpts = [
        {
          $addFields: {
            countryCode: "$countryCode",
          },
        },
        {
          $match: searchedStop,
        },
      ];
      let searchedStops = await tripStopModel.aggregate(tripAggregatorOpts).exec();
      // ============== add to recent search ===================
      searchedStops.forEach(async (stop)=>{
        let data = {
          userId: req.user._id,
          stopId: stop._id,
        };
        let checkExist = await recentSearchesModel.findOne(data);

        const updated =
          checkExist?._id
            ? await super.updateById(recentSearchesModel, checkExist._id.toString(), data)
            : await super.create(res, recentSearchesModel, data);
      });
      // ============== add to recent search ===================
      
      let dropStopsMatch = {
        $and: [
          {
            "routeStops": {
              $elemMatch: {
                "stopId": { $in: dropStops }
              }
            }
          },
        ]
      };
      if(countryCode && countryCode != ''){
        country = await countryModel.findOne({ iso2: countryCode });
        match['countryCode'] = country._id;
      }
      const dropStopsAggregatorOpts = [
        {
          $addFields: {
            countryCode: "$countryCode",
          },
        },
        {
          $match: dropStopsMatch,
        },
      ];

      routeMaps = await routeMapModel.aggregate(dropStopsAggregatorOpts).skip(skip).limit(limit).exec();

      // ========================
      let pickStopsHexStrings = pickStops.map(objId => objId.toString());
      let dropStopsHexStrings = dropStops.map(objId => objId.toString());
      let stopOrderWiseFilteredRoute = []
      routeMaps.forEach(async (route)=>{
        let start = ''
        let end = ''
        route.routeStops.forEach((item)=>{
          if(pickStopsHexStrings.includes(item.stopId.toString())){
            start = item
          }
          if(dropStopsHexStrings.includes(item.stopId.toString())){
            end = item
          }
        });
        
        if((start != '') && (end != '') && (start.order < end.order)){
          route['pickupPoint'] = start
          route['dropPoint'] = end
          stopOrderWiseFilteredRoute.push(route)
        }
      });
      routeMaps = stopOrderWiseFilteredRoute;
      // ========================
      
      // await countryModel.populate(
      //   routeMaps,
      //   {
      //     path: "countryCode",
      //     model: "countryCollection"
      //   },
      // );

      await routeMapModel.populate(routeMaps, {
        path: "routeStops.stopId",
        model: "tripStopCollection"
      });

    } else {
        // ======= for dropdown ===========
        routeMaps = await super.getList(req, routeMapModel, "");
				// await countryModel.populate(
				// 	routeMaps,
				// 	{
				// 		path: "countryCode",
				// 		model: "countryCollection"
				// 	},
				// );
				await routeMapModel.populate(routeMaps, {
					path: "routeStops.stopId",
					model: "tripStopCollection"
				});
    }

    let todayTrips = await tripsModel.find(
      {
        tripDate: currentDate
      }
    ).populate(
      {
        "path": "tripPlanId",
        "model": "tripPlanCollection"
      }
    );

    let userService = await customerModel.findOne({
      userId: req.user._id,
      roleId: loggedInAs
    }).populate("roleId");

    let corporateIdsOfLoggedUser = [];
    if(userService){
      userService.corporates.forEach((corporate)=>{
        corporateIdsOfLoggedUser.push(corporate.corporateId.toString());
      });
    }
    
    // ========= choosen service wise filtration =========
    if(userService?.roleId?.name == "Employee"){
      routeMapsWithTripsCount = routeMaps.map((routeMap)=>{
        let filteredTrips = todayTrips.filter((todayTrip)=>{
          if(
            todayTrip.tripPlanId.routeId.toString() == routeMap._id.toString() &&
            corporateIdsOfLoggedUser.includes(todayTrip.tripPlanId.corporateId.toString())
          ){
            return todayTrip;
          }
        });
        let tripsCount = filteredTrips.length;
  
        // ========= Number of trips available for the searched route ============
        routeMap.tripsCount = tripsCount;
        // ========= Number of trips available for the searched route ============
  
        return routeMap;
      });
    } else if(userService?.roleId?.name == "Student"){
      routeMapsWithTripsCount = routeMaps.map((routeMap)=>{
        let filteredTrips = todayTrips.filter((todayTrip)=>{
          if(
            todayTrip.tripPlanId.routeId.toString() == routeMap._id.toString() &&
            corporateIdsOfLoggedUser.includes(todayTrip.tripPlanId.corporateId.toString())
          ){
            return todayTrip;
          }
        });
        let tripsCount = filteredTrips.length;
  
        // ========= Number of trips available for the searched route ============
        routeMap.tripsCount = tripsCount;
        // ========= Number of trips available for the searched route ============
  
        return routeMap;
      });
    } else if(userService?.roleId?.name == "Customer"){
      routeMapsWithTripsCount = routeMaps.map((routeMap)=>{
        let filteredTrips = todayTrips.filter((todayTrip)=>{
          if(todayTrip.tripPlanId.routeId.toString() == routeMap._id.toString()){
            return todayTrip;
          }
        });
        let tripsCount = filteredTrips.length;
  
        // ========= Number of trips available for the searched route ============
        routeMap.tripsCount = tripsCount;
        // ========= Number of trips available for the searched route ============
  
        return routeMap;
      });
    }
    // ========= choosen service wise filtration =========

    let routeMapsWithTripsCountWhereTripsAvailable = routeMapsWithTripsCount.filter((route)=>{
      if(route.tripsCount > 0){
        return route;
      }
    });

    totalCount = routeMapsWithTripsCountWhereTripsAvailable.length;
    totalPages= Math.ceil(totalCount/limit);
    
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: routeMapDetails(routeMapsWithTripsCountWhereTripsAvailable),
      pagination: {
          total: totalCount,
          totalPages: totalPages,
          rowsPerPage: limit,
          currentPage: page,
          hasNextPage: page < totalPages,
          hasPrevPage: page > 1
      },
      // data: routeMaps,
    });
  });
  // ====================== search-routes-V-2.0 with logic revamp ENDS ======================
  
  // ====================== search-routes-V-3.0 with logic revamp ======================
  static searchRoutesV3 = catchAsyncErrors(async (req, res, next) => {
    const { pickLat, pickLong, dropLat, dropLong, sourceDestination, dropDestination, fromDate, toDate, countryCode, loggedInAs } = req.body;
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 3;
    const skip = (page - 1) * limit;
    // Get the current time in "Asia/Kolkata" time zone
    const momentKolkata = moment().tz('Asia/Kolkata');
    const currentDate = new Date(momentKolkata.format('YYYY-MM-DD'));
    const sevenDaysFromCurrentDate = new Date(momentKolkata.clone().add(7, 'days').format('YYYY-MM-DD'));
    // Create a cache key for country data
    const countryKey = `country_${countryCode}`;
    let country = await redisClient.get(countryKey);
    if (!country) {
      country = await countryModel.findOne({ _id: countryCode });
      await redisClient.set(countryKey, JSON.stringify(country), 'EX', 3600); // Cache for 1 hour
    } else {
      country = JSON.parse(country);
    }
    const matchSevenDaysTrips = {
      tripDate: {
        $gte: currentDate,
        $lte: sevenDaysFromCurrentDate
      }
    };
    if (country) {
      matchSevenDaysTrips.countryCode = country._id;
    }
    const aggregationPipeline = [
      {
        $match: matchSevenDaysTrips
      },
      {
        $lookup: {
          from: "tripPlanCollection",
          localField: "tripPlanId",
          foreignField: "_id",
          as: "tripPlan"
        }
      },
      { $unwind: "$tripPlan" },
      {
        $lookup: {
          from: "routeMapCollection",
          localField: "tripPlan.routeId",
          foreignField: "_id",
          as: "route"
        }
      },
      { $unwind: "$route" },
      {
        $lookup: {
          from: "tripStopCollection",
          localField: "route.routeStops.stopId",
          foreignField: "_id",
          as: "stops"
        }
      },
      {
        $addFields: {
          nearbyPickups: {
            $filter: {
              input: "$stops",
              as: "stop",
              cond: {
                $lte: [
                  {
                    $geoNear: {
                      near: { type: "Point", coordinates: [pickLat, pickLong] },
                      distanceField: "distance",
                      key: "location",
                      maxDistance: 500,
                      spherical: true
                    }
                  },
                  500
                ]
              }
            }
          },
          nearbyDropoffs: {
            $filter: {
              input: "$stops",
              as: "stop",
              cond: {
                $lte: [
                  {
                    $geoNear: {
                      near: { type: "Point", coordinates: [dropLat, dropLong] },
                      distanceField: "distance",
                      key: "location",
                      maxDistance: 500,
                      spherical: true
                    }
                  },
                  500
                ]
              }
            }
          }
        }
      },
      {
        $match: {
          $and: [
            { nearbyPickups: { $ne: [] } },
            { nearbyDropoffs: { $ne: [] } }
          ]
        }
      },
      {
        $addFields: {
          pickupPoint: { $arrayElemAt: ["$nearbyPickups", 0] },
          dropPoint: { $arrayElemAt: ["$nearbyDropoffs", 0] }
        }
      },
      {
        $match: {
          $expr: {
            $lt: [
              { $indexOfArray: ["$route.routeStops.stopId", "$pickupPoint._id"] },
              { $indexOfArray: ["$route.routeStops.stopId", "$dropPoint._id"] }
            ]
          }
        }
      },
      {
        $lookup: {
          from: "tripsCollection",
          let: { routeId: "$route._id" },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $eq: ["$tripPlanId.routeId", "$$routeId"] },
                    { $eq: [{ $dateToString: { format: "%Y-%m-%d", date: "$tripDate" } }, momentKolkata.format('YYYY-MM-DD')] }
                  ]
                }
              }
            }
          ],
          as: "todayTrips"
        }
      },
      {
        $addFields: {
          tripsCount: { $size: "$todayTrips" }
        }
      },
      {
        $match: {
          tripsCount: { $gt: 0 }
        }
      },
      {
        $facet: {
          data: [
            { $skip: skip },
            { $limit: limit },
            {
              $project: {
                _id: "$route._id",
                routeName: "$route.routeName",
                routeStops: "$route.routeStops",
                countryCode: "$route.countryCode",
                pickupPoint: 1,
                dropPoint: 1,
                tripsCount: 1
              }
            }
          ],
          totalCount: [
            { $count: "count" }
          ]
        }
      }
    ];
    const result = await tripsModel.aggregate(aggregationPipeline);
    const routes = result[0].data;
    const totalCount = result[0].totalCount[0] ? result[0].totalCount[0].count : 0;
    const totalPages = Math.ceil(totalCount / limit);
    // Add to recent searches
    if (routes.length > 0) {
      const recentSearchData = {
        userId: req.user._id,
        stopId: routes[0].pickupPoint._id, // Assuming we use the pickup point for recent searches
      };
      await recentSearchesModel.findOneAndUpdate(recentSearchData, recentSearchData, { upsert: true });
    }
    return requestHandler.sendSuccess(res, "Successful")({
      data: routeMapDetails(routes),
      pagination: {
        total: totalCount,
        totalPages: totalPages,
        rowsPerPage: limit,
        currentPage: page,
        hasNextPage: page < totalPages,
        hasPrevPage: page > 1
      },
    });
  });
  // ====================== search-routes-V-3.0 with logic revamp ENDS ======================
  

  static recentSearches = catchAsyncErrors(async (req, res, next)=>{
    let recentSearches = await recentSearchesModel.find({
      userId: req.user._id
    });

    await userModel.populate(
      recentSearches,
      [
        {
          "path": "userId",
          "model": "usersCollection"
        },
        {
          "path": "stopId",
          "model": "tripStopCollection"
        },
      ]
    );

    return res.status(200).json({
      status: true,
      message: "Success",
      data: recentSearches
    });
  });
  // ================= App APIs ===========================
}

module.exports = RouteMapController;
