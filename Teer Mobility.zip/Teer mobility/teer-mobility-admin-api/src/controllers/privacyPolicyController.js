const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/errorHandler");
const RequestHandler = require("../utils/RequestHandler");
const mongoose = require("mongoose");
const ObjectId = mongoose.Types.ObjectId;

const {
  calculateDistance,
  calculateDistanceInsTentApi,
  calculateTimeInKilometers,
  getRateChartCategory,
} = require("../utils/utilities");
const {
  vehicleCategoryDetails,
  vehicleModelDetails,
  couponDetails,
} = require("../utils/common");
const {
  MSG_RECORD_STATUS_SUCCESS,
  MSG_RECORD_FETCH_SUCCESS,
} = require("../config/constants");
const requestHandler = new RequestHandler();

const privacyPolicyModel = require("../models/privacyPolicyModel");

class PrivacyPolicyController extends BaseController {
  constructor() {
    super();
  }

  static privacyPoliciesList = catchAsyncErrors(async (req, res, next) => {
    let privacyPolicies = []
    const { text } = req.body;
    if(req.method == "POST"){
        let match = {
          $or: [
            {
              privacyPolicyHeading: {
                $regex: ".*" + text + ".*",
                $options: "i",
              },
            },
          ],
        };
        const aggregatorOpts = [
          {
            $addFields: {
              privacyPolicyHeading: "$privacyPolicyHeading",
            },
          },
          {
            $match: match,
          },
        ];
        privacyPolicies = await privacyPolicyModel.aggregate(aggregatorOpts).exec();
    } else {
        // ======= for dropdown ===========
        privacyPolicies = await super.getList(req, privacyPolicyModel, "");
        // ======= for dropdown ===========
    }

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: privacyPolicies,
    });
  });

  static privacyPoliciesListWithPagination = catchAsyncErrors(async (req, res, next) => {
    let totalPrivacyPolicies = [];
    let privacyPolicies = [];

    let totalCount = 0;
		let totalPages= 0;
		let page = 0;
		let limit = 0;
		let skip = 0;

    // Pagination parameters ===========
		page = req.body.pageNo ? parseInt(req.body.pageNo) : 1; // Current page number
		limit = req.body.documentPerPage ? parseInt(req.body.documentPerPage) : 3; // Number of documents per page
		skip = (page - 1) * limit; // Number of documents to skip
		// Pagination parameters ===========

    const { text } = req.body;

    if(req.method == "POST"){
        let match = {
          $or: [
            {
              privacyPolicyHeading: {
                $regex: ".*" + text + ".*",
                $options: "i",
              },
            },
          ],
        };
        const aggregatorOpts = [
          {
            $addFields: {
              privacyPolicyHeading: "$privacyPolicyHeading",
            },
          },
          {
            $match: match,
          },
          {
						$sort: { createdAt: -1 } // Sort by createdAt in descending order
					},
        ];
        totalPrivacyPolicies = await privacyPolicyModel.aggregate(aggregatorOpts).exec();
        privacyPolicies = await privacyPolicyModel.aggregate(aggregatorOpts).skip(skip).limit(limit).exec();
    } else {
        // ======= for dropdown ===========
        privacyPolicies = await super.getList(req, privacyPolicyModel, "");
        // ======= for dropdown ===========
    }

    totalCount = totalPrivacyPolicies.length;
    totalPages= Math.ceil(totalCount/limit);

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: privacyPolicies,
      pagination: {
        total: totalCount,
        totalPages: totalPages,
        rowsPerPage: limit,
        currentPage: page,
        hasNextPage: page < totalPages,
        hasPrevPage: page > 1
      },
    });
  });

  static privacyPoliciesAddUpdate = catchAsyncErrors(async (req, res, next) => {
    const { privacyPolicyHeading, privacyPolicyDescription, _id } = req.body;

    const data = {
      privacyPolicyHeading: privacyPolicyHeading,
      privacyPolicyDescription: privacyPolicyDescription,
    };
    const updated =
      _id && _id != null && _id != ""
        ? await super.updateById(privacyPolicyModel, _id.toString(), data)
        : await super.create(res, privacyPolicyModel, data);

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: updated,
    });
  });

  static getPrivacyPoliciesDetail = catchAsyncErrors(async (req, res, next) => {
    const { id } = req.body;
    const privacyPolicy = await privacyPolicyModel.findOne({ _id: id });
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: privacyPolicy,
    });
  });

  static deletePrivacyPolicies = catchAsyncErrors(async (req, res, next) => {
    const { id } = req.body;
    const updated = await super.deleteById(privacyPolicyModel, id);
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: updated,
    });
  });
}

module.exports = PrivacyPolicyController;
