const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/errorHandler");
const RequestHandler = require("../utils/RequestHandler");
const bcrypt = require("bcryptjs");
const JWTAuth = require("../utils/jwtToken");
const mongoose = require("mongoose");
const ObjectId = mongoose.Types.ObjectId;
const fileUploaderSingle = require("../utils/fileUpload").fileUploaderSingle;

const {
  calculateDistance,
  calculateDistanceInsTentApi,
  calculateTimeInKilometers,
  getRateChartCategory,
} = require("../utils/utilities");
const { userDetails, corporateDetails, vendorCorporateMapDetails } = require("../utils/common");
const {
  MSG_RECORD_STATUS_SUCCESS,
  MSG_RECORD_FETCH_SUCCESS,
} = require("../config/constants");
const requestHandler = new RequestHandler();

const userModel = require("../models/userModel");
const rollModel = require("../models/rollModel");
const moduleModel = require("../models/moduleModel");
const rolePermissionModel = require("../models/rolePermissionModel");
const rolePermissionUserwiseModel = require("../models/rolePermissionUserwiseModel");
const corporateModel = require("../models/corporateModel");
const vendorCorporateModel = require("../models/vendorCorporateModel");
const vendorVehicleModel = require("../models/vendorVehicleModel");
const customerModel = require("../models/customerModel");
const vendorDriverModel = require("../models/vendorDriverModel");
const tripPlanModel = require("../models/tripPlanModel");
const corporateUserModel = require("../models/corporateUserModel");
const studentModel = require("../models/studentModel");
const tripsModel = require("../models/tripsModel");

class CorporateController extends BaseController {
  constructor() {
    super();
  }

  static corporateList = catchAsyncErrors(async (req, res, next) => {
    // ========= check who is logged in ==========
    let loggedUser = await userModel.findOne({ _id: req.user._id }).populate(
      {
        path: "roleId",
        model: "roleCollection"
      }
    ); 
    // console.log("loggedUser =======================================================> ");
    // console.log(loggedUser.roleId.name);
    // console.log("loggedUser =======================================================> ");

    // ========= check who is logged in ==========
    let totalCount = 0;
		let totalPages= 0;
		let page = 0;
		let limit = 0;
		let skip = 0;

    let { text, phoneSearch, roleOfCorporateType } = req.body;

    if (req.method == "POST") {
      // Pagination parameters ===========
			page = req.body.pageNo ? parseInt(req.body.pageNo) : 1; // Current page number
			limit = req.body.documentPerPage ? parseInt(req.body.documentPerPage) : 3; // Number of documents per page
			skip = (page - 1) * limit; // Number of documents to skip
			// Pagination parameters ===========

      const super_admin = await rollModel.findOne({ name: "Super Admin" });

      let match = {
        $and: [
          {
            $or: [
              { name: { $regex: ".*" + text + ".*", $options: "i" } },
              { supportEmail: { $regex: ".*" + text + ".*", $options: "i" } },
            ],
          },
        ],
      };
      
      if (phoneSearch) {
        match["phoneNumber"] = parseInt(phoneSearch); 
      }
      const aggregatorOpts = [
        {
          $addFields: {
            name: "$name",
            supportEmail: "$supportEmail",
          },
        },
        {
          $match: match,
        },
        {
          $sort: { createdAt: -1 } // Sort by createdAt in descending order
        },
      ];

      let corporates = await corporateModel.aggregate(aggregatorOpts).exec();
      
      // let corporates = await corporateModel.aggregate(aggregatorOpts).skip(skip).limit(limit).exec();
      // let corporates = await corporateModel.aggregate(aggregatorOpts).exec();
      await rollModel.populate(corporates, [
        {
          path: "userId",
          model: "usersCollection",
          populate: {
            path: "roleId",
            model: "roleCollection",
          },
        },
        {
          path: "countryCode",
          model: "countryCollection",
        },
      ]);

      let corporatesToSearchIdsArr = [];
      let totalCorporatesAccordingToRole = corporates.filter((corporate) => {
        if (corporate.userId.roleId._id.toString() === roleOfCorporateType) {
          corporatesToSearchIdsArr.push(corporate._id);
        }
      });

      let match2 = {
        _id: {
          $in: corporatesToSearchIdsArr,
        },
        $and: [
          {
            $or: [
              { name: { $regex: ".*" + text + ".*", $options: "i" } },
              { supportEmail: { $regex: ".*" + text + ".*", $options: "i" } },
            ],
          },
        ],
      };
      const aggregatorOpts2 = [
        {
          $addFields: {
            name: "$name",
            supportEmail: "$supportEmail",
          },
        },
        {
          $match: match2,
        },
        {
          $sort: { createdAt: -1 } // Sort by createdAt in descending order
        },
      ];

      let totalCorporates = await corporateModel.aggregate(aggregatorOpts2).exec();
      let corporatesAccordingToRole = await corporateModel.aggregate(aggregatorOpts2).skip(skip).limit(limit).exec();
      await rollModel.populate(corporatesAccordingToRole, [
        {
          path: "userId",
          model: "usersCollection",
          populate: {
            path: "roleId",
            model: "roleCollection",
          },
        },
        {
          path: "countryCode",
          model: "countryCollection",
        },
      ]);
      // ========== filters coporate according to role (corporate-type) ==========
      let filteredCorporates = corporatesAccordingToRole.filter((corporate) => {
        if (corporate.userId.roleId._id.toString() === roleOfCorporateType) {
          return corporate;
        }
      });
      // ========== filters coporate according to role (corporate-type) ==========

      // ========== filters corporate according to user-id ==========
      let filteredCorporatesByLoggedUser = []
      // ========== default before filtering ==========
      filteredCorporatesByLoggedUser = filteredCorporates
      // ========== default before filtering ==========
      if(loggedUser.roleId.name == "Corporate"){
        filteredCorporatesByLoggedUser = filteredCorporates.filter((corporate)=>{
          if(corporate.userId._id == req.user._id){
            return corporate;
          }
        });
      }
      // ========== filters corporate according to user-id ==========

      // totalCount = filteredCorporatesByLoggedUser.length;
      totalCount = totalCorporates.length;
      totalPages= Math.ceil(totalCount/limit);

      return requestHandler.sendSuccess(
        res,
        "Successful"
      )({
        //   data: userDetails(users),
        // data: filteredCorporates,
        data: filteredCorporatesByLoggedUser,
        pagination: {
          total: totalCount,
          totalPages: totalPages,
          rowsPerPage: limit,
          currentPage: page,
          hasNextPage: page < totalPages,
          hasPrevPage: page > 1
        },
      });
    } else if (req.method == "GET") {
      let corporates = await corporateModel.find({
        isActive: true,
        isDeleted: false,
      }).populate(
        {
          path: "userId",
          model: "usersCollection",
          populate: {
            path: "roleId",
            model: "roleCollection",
          },
        },
      );

      // ========================================================================================
      // can not filter here as vendor, corporate, company, school all will come from this corporateModel and the dropdowns for all of them will come from here; hence filter for this must be implemented in the frontend 
      // ========================================================================================

      // // ========== filters corporate according to user-id ==========
      // let filteredCorporatesByLoggedUser = []
      // // ========== default before filtering ==========
      // filteredCorporatesByLoggedUser = corporates
      // // ========== default before filtering ==========
      // if(loggedUser.roleId.name == "Corporate"){
      //   filteredCorporatesByLoggedUser = corporates.filter((corporate)=>{
      //     if(corporate.userId._id == req.user._id){
      //       return corporate;
      //     }
      //   });
      // }
      // // ========== filters corporate according to user-id ==========
      // console.log("filteredCorporatesByLoggedUser =======> ");
      // console.log(filteredCorporatesByLoggedUser);


      // ========================================================================================
      // can not filter here as vendor, corporate, company, school all will come from this corporateModel and the dropdowns for all of them will come from here; hence filter for this must be implemented in the frontend
      // ========================================================================================

      return requestHandler.sendSuccess(
        res,
        "Successful"
      )({
        data: corporates,
        // data: filteredCorporates,
        // data: filteredCorporatesByLoggedUser,
      });
    }
  });

  // static corporateAddUpdate = catchAsyncErrors(async (req, res, next) => {
  //   let { roleOfCorporateType, countryCode, parentCorporateId, name, supportEmail, password, phoneNumber, dialcode, address, latitude, longitude, state, city, zipcode, orgBranch, orgAddress, orgLatitude, orgLongitude, attendanceSystem, regularWeekends, payer, paymentType, holidays, _id, } = req.body;
  //   // console.log("roleOfCorporateType ===>");
  //   // console.log(roleOfCorporateType);
    
  //   if (!Array.isArray(orgBranch)) {
  //     orgBranch = [orgBranch];
  //   }
  //   if (!Array.isArray(orgAddress)) {
  //     orgAddress = [orgAddress];
  //   }
  //   if (!Array.isArray(orgLatitude)) {
  //     orgLatitude = [orgLatitude];
  //   }
  //   if (!Array.isArray(orgLongitude)) {
  //     orgLongitude = [orgLongitude];
  //   }
  //   if (!Array.isArray(holidays)) {
  //     holidays = [holidays];
  //   }
  //   // console.log(orgBranch);
  //   // console.log(orgAddress);
  //   // console.log(orgLatitude);
  //   // console.log(orgLongitude); return;

  //   // ====== validationFlag decides whether to submit or not =====
  //   let validationFlag = false;
  //   // ====== validationFlag decides whether to submit or not =====
  //   let branchLocationsArr = [];
  //   let holidaysArr = [];

  //   if (
  //     orgBranch.length > 0 &&
  //     orgAddress.length > 0 &&
  //     orgLatitude.length > 0 &&
  //     orgLongitude.length > 0 &&

  //     orgBranch.length == orgAddress.length &&
  //     orgAddress.length == orgLatitude.length &&
  //     orgLatitude.length == orgLongitude.length &&

  //     (orgBranch != "" || null || "undefined") &&
  //     (orgAddress != "" || null || "undefined") &&
  //     (orgLatitude != "" || null || "undefined") &&
  //     (orgLongitude != "" || null || "undefined")
  //   ) {
  //     validationFlag = true;

  //     for (let i = 0; i < orgBranch.length; i++) {
  //       let addrObj = {
  //         branchName: orgBranch[i],
  //         locationName: orgAddress[i],
  //         location: {
  //           type: "Point",
  //           coordinates: [orgLatitude[i], orgLongitude[i]],
  //         },
  //       };
  //       branchLocationsArr.push(addrObj);
  //     }
  //   }

  //   if (holidays.length > 0) {
  //     if (Array.isArray(holidays)) {
  //       holidays.forEach((holiday) => {
  //         holidaysArr.push(holiday);
  //       });
  //     } else {
  //       holidaysArr.push(holidays[0]);
  //     }
  //   }

  //   if (validationFlag == true) {
  //     // =========== single file upload ================
  //     let fileName = "";
  //     if (req.files.logoImage) {
  //       let image = await fileUploaderSingle(
  //         "./src/public/uploads/userImages/",
  //         req.files.logoImage
  //       );
  //       fileName = image.newfileName;
  //     }
  //     // =========== single file upload ================
  //     let userDataObj = {
  //       firstName: name,
  //       lastName: " ",
  //       email: supportEmail,
  //       phone: phoneNumber,
  //       dialcode: dialcode,
  //       password: password,
  //       location: {
  //         type: "Point",
  //         coordinates: [latitude, longitude],
  //       },
  //       address: address,
  //       zipcode: Math.abs(zipcode),
  //       city: city,
  //       state: state,
  //       roleId: roleOfCorporateType.toString(),
  //     };
  //     if (fileName != "") {
  //       userDataObj.profileImage = fileName;
  //     }
  //     let userProfileOfCorporate = [];
  //     if (_id && _id != null && _id != "") {
  //       // while edit enters here ======
  //       userProfileOfCorporate = await corporateModel.findOne({
  //         _id: _id.toString(),
  //       });
  //     }
  //     // =========== add-update userProfile ===========
  //     let updated =
  //       _id && _id != null && _id != ""
  //         ? await super.updateById(
  //             userModel,
  //             userProfileOfCorporate.userId,
  //             userDataObj
  //           )
  //         : await super.create(res, userModel, userDataObj);
  //     // =========== add-update userProfile ===========

  //     let userWisePermissionProfile = [];
  //     let modules = await rolePermissionModel.findOne({
  //       roleId: roleOfCorporateType.toString(),
  //     });
  //     // ============== enters here to create permission only during add ==============
  //     if (!_id || _id == null || _id == "") {
  //       // during edit === no need to edit permissions ======
  //       if (updated?._id != undefined) {
  //         let permissionObj = {
  //           userId: updated._id.toString(),
  //           moduleId: modules.moduleId,

  //           updatedBy: req.user._id,
  //         };

  //         userWisePermissionProfile =
  //           _id && _id != null && _id != ""
  //             ? await super.updateByCustomOptions(
  //                 rolePermissionUserwiseModel,
  //                 {
  //                   userId: updated._id,
  //                 },
  //                 permissionObj
  //               )
  //             : await super.create(
  //                 res,
  //                 rolePermissionUserwiseModel,
  //                 permissionObj
  //               );
  //       }
  //     }
  //     // ============== enters here to create permission only during add ==============

  //     // ====== corporateProfile creation ==========
  //     if (updated._id != undefined) {
  //       let corporateDataObj = {
  //         userId: updated._id,
  //         countryCode: countryCode.toString(),
  //         name: name,
  //         locations: branchLocationsArr,
  //         attendanceSystem: attendanceSystem,
  //         payment: {
  //           payer: payer,
  //           paymentType: paymentType,
  //         },
  //         address: address,
  //         city: city,
  //         state: state,
  //         zipcode: zipcode,
  //         supportEmail: supportEmail,
  //         phoneNumber: phoneNumber,
  //         regularWeekends: regularWeekends,
  //         holidays: holidaysArr,
  //       };
  //       if (fileName != "") {
  //         corporateDataObj.logoImage = fileName;
  //       }
  //       if (parentCorporateId != "") {
  //         corporateDataObj.parentCorporateId = parentCorporateId.toString();
  //       }

  //       // ======== add-update corporateProfile =========
  //       let corporate =
  //         _id && _id != null && _id != ""
  //           ? await super.updateById(
  //               corporateModel,
  //               _id.toString(),
  //               corporateDataObj
  //             )
  //           : await super.create(res, corporateModel, corporateDataObj);
  //       // ======== add-update corporateProfile =========
  //       // ====== corporateProfile creation ENDS ==========
        
  //       if (corporate) {
  //         return requestHandler.sendSuccess(
  //           res,
  //           "Successful"
  //         )({
  //           data: updated,
  //         });
  //       }
  //     }
  //   } else {
  //     return res.status(400).json({
  //       status: false,
  //       message:
  //         "Oops..!! Invalid Data..!! Please check all the entered data carefully..!! Check the organization branches data carefully. All values must be present.",
  //       data: {},
  //     });
  //   }
  // });

  static corporateAddUpdate = catchAsyncErrors(async (req, res, next) => {
    let { roleOfCorporateType, countryCode, parentCorporateId, name, supportEmail, password, phoneNumber, dialcode, address, latitude, longitude, state, city, zipcode, isOnDemand, orgBranch, orgAddress, orgLatitude, orgLongitude, attendanceSystem, regularWeekends, payer, paymentType, holidays, _id, } = req.body;
    
    if (!Array.isArray(orgBranch)) {
      orgBranch = [orgBranch];
    }
    if (!Array.isArray(orgAddress)) {
      orgAddress = [orgAddress];
    }
    if (!Array.isArray(orgLatitude)) {
      orgLatitude = [orgLatitude];
    }
    if (!Array.isArray(orgLongitude)) {
      orgLongitude = [orgLongitude];
    }
    if (!Array.isArray(holidays)) {
      holidays = [holidays];
    }
    // console.log(orgBranch);
    // console.log(orgAddress);
    // console.log(orgLatitude);
    // console.log(orgLongitude); return;

    // ====== validationFlag decides whether to submit or not =====
    let validationFlag = false;
    // ====== validationFlag decides whether to submit or not =====
    let branchLocationsArr = [];
    let holidaysArr = [];

    if (
      orgBranch.length > 0 &&
      orgAddress.length > 0 &&
      orgLatitude.length > 0 &&
      orgLongitude.length > 0 &&

      orgBranch.length == orgAddress.length &&
      orgAddress.length == orgLatitude.length &&
      orgLatitude.length == orgLongitude.length &&

      (orgBranch != "" || null || "undefined") &&
      (orgAddress != "" || null || "undefined") &&
      (orgLatitude != "" || null || "undefined") &&
      (orgLongitude != "" || null || "undefined")
    ) {
      validationFlag = true;

      for (let i = 0; i < orgBranch.length; i++) {
        if(
          (orgBranch[i] && orgBranch[i] != '' && orgBranch[i] != null) 
          && (orgAddress[i] && orgAddress[i] != '' && orgAddress[i] != null)
          && (orgLatitude[i] && orgLatitude[i] != '' && orgLatitude[i] != null)
          && (orgLongitude[i] && orgLongitude[i] != '' && orgLongitude[i] != null)
        ){
          let addrObj = {
            branchName: orgBranch[i],
            locationName: orgAddress[i],
            location: {
              type: "Point",
              coordinates: [orgLatitude[i], orgLongitude[i]],
            },
          };
          branchLocationsArr.push(addrObj);
        }
      }
    }

    if (holidays.length > 0) {
      if (Array.isArray(holidays)) {
        holidays.forEach((holiday) => {
          if(holiday && holiday != '' && holiday != null){
            holidaysArr.push(holiday);
          }
        });
      } else {
        if(holidays[0] && holidays[0] != '' && holidays[0] != null){
          holidaysArr.push(holidays[0]);
        }
      }
    }

    if (validationFlag == true) {
      // =========== single file upload ================
      let fileName = "";
      if (req.files.logoImage) {
        let image = await fileUploaderSingle(
          "./src/public/uploads/userImages/",
          req.files.logoImage
        );
        fileName = image.newfileName;
      }
      // =========== single file upload ================
      let userDataObj = {
        firstName: name,
        lastName: " ",
        email: supportEmail,
        phone: phoneNumber,
        dialcode: dialcode,
        password: password,
        location: {
          type: "Point",
          coordinates: [latitude, longitude],
        },
        address: address,
        zipcode: Math.abs(zipcode),
        city: city,
        state: state,
        roleId: roleOfCorporateType,
      };
      if (fileName != "") {
        userDataObj.profileImage = fileName;
      }
      let userProfileOfCorporate = [];
      if (_id && _id != null && _id != "") {
        // while edit enters here ======
        userProfileOfCorporate = await corporateModel.findOne({
          _id: _id,
        });
      }
      
      // =========== add-update userProfile ===========
      let updated =
        _id && _id != null && _id != ""
          ? await super.updateById(
              userModel,
              userProfileOfCorporate.userId,
              userDataObj
            )
          : await super.create(res, userModel, userDataObj);
      // =========== add-update userProfile ===========

      let userWisePermissionProfile = [];
      let modules = await rolePermissionModel.findOne({
        roleId: roleOfCorporateType,
      });
      // ============== enters here to create permission only during add ==============
      if (!_id || _id == null || _id == "") {
        // add happening ====
        // during edit === no need to edit permissions ======
        if (updated?._id != undefined) {
          let permissionObj = {
            userId: updated._id,
            moduleId: modules.moduleId,

            updatedBy: req.user._id,
          };

          userWisePermissionProfile =
            _id && _id != null && _id != ""
              ? await super.updateByCustomOptions(
                  rolePermissionUserwiseModel,
                  {
                    userId: updated._id,
                  },
                  permissionObj
                )
              : await super.create(
                  res,
                  rolePermissionUserwiseModel,
                  permissionObj
                );
        }
      }
      // ============== enters here to create permission only during add ==============

      // ====== corporateProfile creation ==========
      if (updated._id != undefined) {
        let corporateDataObj = {
          userId: updated._id,
          countryCode: countryCode,
          name: name,
          locations: branchLocationsArr,
          attendanceSystem: attendanceSystem,
          payment: {
            payer: payer,
            paymentType: paymentType,
          },
          address: address,
          city: city,
          state: state,
          zipcode: zipcode,
          isOnDemand: (isOnDemand == "on")? true : false,
          supportEmail: supportEmail,
          phoneNumber: phoneNumber,
          regularWeekends: regularWeekends,
          holidays: holidaysArr,
        };
        if (fileName != "") {
          corporateDataObj.logoImage = fileName;
        }
        if (parentCorporateId != "") {
          corporateDataObj.parentCorporateId = parentCorporateId;
        }

        // ======== add-update corporateProfile =========
        let corporate =
          _id && _id != null && _id != ""
            ? await super.updateById(
                corporateModel,
                _id,
                corporateDataObj
              )
            : await super.create(res, corporateModel, corporateDataObj);
        // ======== add-update corporateProfile =========
        // ====== corporateProfile creation ENDS ==========
        
        if (corporate) {
          // handle trip-plan and trips isOnDemand on corporate update =======
          if(_id && _id != null && _id != ""){
            if((isOnDemand == "off")){
              let updateTripPlans = await super.updateByCustomOptions(
                tripPlanModel,
                {
                  corporateId: _id,
                },
                {
                  isOnDemand: isOnDemand
                }
              );
            }

            // // Get the current time in "Asia/Kolkata" time zone =======
            // let momentKolkata = moment().tz('Asia/Kolkata');
            // let currentDate = momentKolkata.format('YYYY-MM-DD');
            // let currentDay = momentKolkata.format('dddd');
            // let currentTime = momentKolkata.format('HH:mm');
            // // Get the current time in "Asia/Kolkata" time zone =======

            // let upcomingTrips = await tripsModel.find({
            //   $or: [
            //     { // ===== trips scheduled for today after the current time =====
            //       tripDate: currentDate,
            //       tripStartTime: { $gt: currentTime }
            //     },
            //     { // ===== future trips (date after today) =====
            //       tripDate: { $gt: currentDate }
            //     }
            //   ],
            //   isCancelled: false,
            //   isDeleted: false,
            // });

            // let upcomingTripsIdsArr = [];
            // upcomingTrips.forEach((upcomingTrip) => {
            //   upcomingTripsIdsArr.push(upcomingTrip?._id);
            // });
          }
          // handle isOnDemand on update =======

          return requestHandler.sendSuccess(
            res,
            "Successful"
          )({
            data: updated,
          });
        }
      }
    } else {
      return res.status(400).json({
        status: false,
        message:
          "Oops..!! Invalid Data..!! Please check all the entered data carefully..!! Check the organization branches data carefully. All values must be present.",
        data: {},
      });
    }
  });

  static getCorporate = catchAsyncErrors(async (req, res, next) => {
    let { id } = req.body;
    
    if(!id){
      let corporateEntity = await corporateModel.findOne({
        userId: req.user._id
      }).populate([
        {
          "path": "userId",
          "model": "usersCollection",
          "populate": {
            "path": "roleId",
            "model": "roleCollection",
          }
        },
      ]);
      id = corporateEntity._id
    }
    const corporate = await corporateModel.findOne({ _id: id }).populate([
      {
        "path": "userId",
        "model": "usersCollection",
        "populate": {
            "path": "roleId",
            "model": "roleCollection",
          }
      },
      {
        path: "countryCode",
        model: "countryCollection",
      },
      // {
      //   path: "parentCorporateId",
      //   model: "corporateCollection"
      // },
    ]);
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: corporateDetails(corporate),
      // data: corporate,
    });
  });

  static deleteCorporate = catchAsyncErrors(async (req, res, next) => {
    const { id } = req.body;

    let corporateAccount = await corporateModel.findOne({
      _id: id,
    });
    let userId = corporateAccount.userId;
    let roleOfCorporateType = await userModel.findOne({
      _id: userId,
    }).populate([
      {
        "path": "roleId",
        "model": "roleCollection",
      },
    ]);

    let corporateVendorMappingExist = [];
    let corporateEmployeeOrStudentMappingExist = [];
    let corporateUserMappingExist = [];
    let studentMappingExist = [];

    let vendorVehicleMappingExist = [];
    let vendorDriverMappingExist = [];

    let corporateTripPlanMappingExist = [];
    let vendorTripPlanMappingExist = [];
    if(
      (roleOfCorporateType.roleId.name == "Corporate")
      || (roleOfCorporateType.roleId.name == "School")
    ){
      corporateVendorMappingExist = await vendorCorporateModel.find({
        corporateId: id,
      });

      let match = {
        isActive: true,
        isDeleted: false,
        $and: [
          {
            "corporates": {
              $elemMatch: {
                "corporateId": id,
              }
            }
          },
        ],
      };
      let aggregatorOpts = [
        // {
        //   $addFields: {
        //     countryCode: "$countryCode",
        //   },
        // },
        {
          $match: match,
        },
      ];
      corporateEmployeeOrStudentMappingExist = await customerModel.aggregate(aggregatorOpts).exec();

      corporateTripPlanMappingExist = await tripPlanModel.find({
        corporateId: id,
      });

      corporateUserMappingExist = await corporateUserModel.find({
        corporateId: id,
      });

      studentMappingExist = await studentModel.find({
        schoolId: id,
      });

      if(corporateVendorMappingExist.length > 0){
        return res.status(422).json({
          status: false,
          message: "Mapping of this corporate/school with vendor exist. Please delete all taggings before proceeding.",
          data: {}
        });
      }
      if(corporateEmployeeOrStudentMappingExist.length > 0){
        return res.status(422).json({
          status: false,
          message: "Mapping of this corporate/school with employee/student exist. Please delete all taggings before proceeding.",
          data: {}
        });
      }
      if(corporateTripPlanMappingExist.length > 0){
        return res.status(422).json({
          status: false,
          message: "Trip plans for this corporate/school exist. Please delete all trip plans created for this entity before proceeding.",
          data: {}
        });
      }
      if(corporateUserMappingExist.length > 0){
        return res.status(422).json({
          status: false,
          message: "Mapping of this corporate/school with corporate users exist. Please delete all taggings before proceeding.",
          data: {}
        });
      }
      if(studentMappingExist.length > 0){
        return res.status(422).json({
          status: false,
          message: "Mapping of this school with students exist. Please delete all taggings before proceeding.",
          data: {}
        });
      }

    } else if(roleOfCorporateType.roleId.name == "Vendor"){
      corporateVendorMappingExist = await vendorCorporateModel.find({
        vendorId: id,
      });
      vendorVehicleMappingExist = await vendorVehicleModel.find({
        vendorId: id,
      });
      vendorDriverMappingExist = await vendorDriverModel.find({
        vendorId: id,
      });
      vendorTripPlanMappingExist = await tripPlanModel.find({
        vendorId: id,
      });
      corporateUserMappingExist = await corporateUserModel.find({
        corporateId: id,
      });

      if(corporateVendorMappingExist.length > 0){
        return res.status(422).json({
          status: false,
          message: "Mapping of this vendor with corporate/school exist. Please delete all taggings before proceeding.",
          data: {}
        });
      }
      if(vendorVehicleMappingExist.length > 0){
        return res.status(422).json({
          status: false,
          message: "Mapping of this vendor with vehicles exist. Please delete all taggings before proceeding.",
          data: {}
        });
      }
      if(vendorDriverMappingExist.length > 0){
        return res.status(422).json({
          status: false,
          message: "Mapping of this vendor with drivers exist. Please delete all taggings before proceeding.",
          data: {}
        });
      }
      if(vendorTripPlanMappingExist.length > 0){
        return res.status(422).json({
          status: false,
          message: "Trip plans for this vendor exist. Please delete all trip plans created for this entity before proceeding.",
          data: {}
        });
      }
      if(corporateUserMappingExist.length > 0){
        return res.status(422).json({
          status: false,
          message: "Mapping of this vendor with corporate users exist. Please delete all taggings before proceeding.",
          data: {}
        });
      }

    } 

    if(corporateVendorMappingExist.length > 0){
      corporateVendorMappingExist.forEach(async (corporate)=>{
        let vendorCorporateMappingDelete = await super.deleteById(vendorCorporateModel, corporate._id);
      });
    }
    if(vendorVehicleMappingExist.length > 0){
      vendorVehicleMappingExist.forEach(async (vendor)=>{
        let vendorVehicleMappingDelete = await super.deleteById(vendorVehicleModel, vendor._id);
      });
    }

    let deleteCorporateProfile = await super.deleteById(corporateModel, id);
    let deleteUserProfile = await super.deleteById(userModel, userId);
    let deleteUserPermissionProfile = await rolePermissionUserwiseModel.deleteOne({
      userId: userId,
    });

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: deleteUserProfile,
    });
  });

  // ============== vendor-corporate mapping ==============
  static vendorCorporateMapList = catchAsyncErrors(async (req, res, next) => {
    // ========= check who is logged in ==========
    let loggedUser = await userModel.findOne({ _id: req.user._id }).populate(
      {
        path: "roleId",
        model: "roleCollection"
      }
    ); 
    // console.log("loggedUser =======================================================> ");
    // console.log(loggedUser.roleId.name);
    // console.log("loggedUser =======================================================> ");

    // ========= check who is logged in ==========

    let totalMappings = [];
    let mappings = [];

    let totalCount = 0;
		let totalPages= 0;
		let page = 0;
		let limit = 0;
		let skip = 0;

		let { text, vendorId, corporateId } = req.body;

    // Pagination parameters ===========
    page = req.body.pageNo ? parseInt(req.body.pageNo) : 1; // Current page number
    limit = req.body.documentPerPage ? parseInt(req.body.documentPerPage) : 3; // Number of documents per page
    skip = (page - 1) * limit; // Number of documents to skip
    // Pagination parameters ===========

		let match = {
    };
    if (vendorId && (vendorId != "")) {
      let vendor = await corporateModel.findOne({ _id: vendorId });
      match["vendorId"] = vendor._id;
    }
    if (corporateId && (corporateId != "")) {
      let corporate = await corporateModel.findOne({ _id: corporateId });
      match["corporateId"] = corporate._id;
    }
    const aggregatorOpts = [
      {
        $addFields: {
          vendorId: "$vendorId",
          corporateId: "$corporateId",
        },
      },
      {
        $match: match,
      },
      {
        $sort: { createdAt: -1 } // Sort by createdAt in descending order
      },
    ];
    totalMappings = await vendorCorporateModel.aggregate(aggregatorOpts).exec();
    mappings = await vendorCorporateModel.aggregate(aggregatorOpts).skip(skip).limit(limit).exec();
    await corporateModel.populate(
			mappings,
			[
				{
					path: "vendorId",
					model: "corporateCollection",
				},
				{
					path: "corporateId",
					model: "corporateCollection",
          populate: {
            path: "userId",
            model: "usersCollection",
          }
				}
			]
		);
    let mappedFilteredVendorsOrCorporates = []
    // ========= for default superadmin view =========
    mappedFilteredVendorsOrCorporates = mappings
    // ========= for default superadmin view =========
    if((loggedUser.roleId.name == "Corporate") || loggedUser.roleId.name == "School"){
      let loggedCorporate = await corporateModel.findOne({
        userId: req.user._id
      });
      let corporateVendorMapping = await vendorCorporateModel.find({
        corporateId: loggedCorporate._id
      });
      let mappedVendorIdArr = [];
      corporateVendorMapping.forEach((mappedVendor)=>{
        mappedVendorIdArr.push(mappedVendor.vendorId.toString());
      });
      mappedFilteredVendorsOrCorporates = mappings.filter((mapping) => {
        if(
          mappedVendorIdArr.includes(mapping.vendorId._id.toString()) &&
          mapping.corporateId._id.toString() == loggedCorporate._id
        ){
          return mapping;
        }
      });
    } else if(loggedUser.roleId.name == "Vendor"){
      let loggedCorporate = await corporateModel.findOne({
        userId: req.user._id
      });
      let corporateVendorMapping = await vendorCorporateModel.find({
        vendorId: loggedCorporate._id
      });
      let mappedCorporateIdArr = [];
      corporateVendorMapping.forEach((mappedCorporate)=>{
        mappedCorporateIdArr.push(mappedCorporate.corporateId.toString());
      });
      mappedFilteredVendorsOrCorporates = mappings.filter((mapping) => {
        if(
          mappedCorporateIdArr.includes(mapping.corporateId._id.toString()) &&
          mapping.vendorId._id.toString() == loggedCorporate._id
        ){
          return mapping;
        }
      });
    } 

    totalCount = mappedFilteredVendorsOrCorporates.length;
    totalPages= Math.ceil(totalCount/limit);

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      // data: vendorCorporateMapDetails(mappings),
      // data: mappings,
      data: vendorCorporateMapDetails(mappedFilteredVendorsOrCorporates),
      pagination: {
        total: totalCount,
        totalPages: totalPages,
        rowsPerPage: limit,
        currentPage: page,
        hasNextPage: page < totalPages,
        hasPrevPage: page > 1
      },
    });
  });
  static vendorCorporateMapAddUpdate = catchAsyncErrors(async (req, res, next) => {
    let { vendorId, corporateId, _id } = req.body;
    let data = {
        vendorId: vendorId,
        corporateId: corporateId,
    };
		let checkExist = await super.getByCustomOptionsSingle(req, vendorCorporateModel, data);
		if(checkExist == null){
			// if mapping does not exist already =====
			let updated =
				_id && _id != null && _id != ""
					? await super.updateById(vendorCorporateModel, _id.toString(), data)
					: await super.create(res, vendorCorporateModel, data);

			return requestHandler.sendSuccess(
				res,
				"Successful"
			)({
				data: updated,
			});
		} else{
			// if mapping exist already =====
			return res.status(400).json({
				status: false,
				message: "Vendor already mapped to this organization.",
				data: checkExist
			})
		}
    
  });
  static getVendorCorporateMapDetail = catchAsyncErrors(async (req, res, next) => {
    let { id } = req.body;
    let vendorCorporateMap = await vendorCorporateModel.findOne({ _id: id });
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: vendorCorporateMap,
    });
  });
  static deleteVendorCorporateMapDetail = catchAsyncErrors(async (req, res, next) => {
    const { id } = req.body;
    const updated = await super.deleteById(vendorCorporateModel, id);
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: updated,
    });
  });
  // ============== vendor-corporate mapping ==============
}

module.exports = CorporateController;
