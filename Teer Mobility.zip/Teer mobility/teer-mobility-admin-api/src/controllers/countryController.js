const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/errorHandler");
const RequestHandler = require("../utils/RequestHandler");
const mongoose = require("mongoose");
const ObjectId = mongoose.Types.ObjectId;

const {
  calculateDistance,
  calculateDistanceInsTentApi,
  calculateTimeInKilometers,
  getRateChartCategory,
} = require("../utils/utilities");
const { userDetails } = require("../utils/common");
const {
  MSG_RECORD_STATUS_SUCCESS,
  MSG_RECORD_FETCH_SUCCESS,
} = require("../config/constants");
const requestHandler = new RequestHandler();

const countryModel = require("../models/countryModel");

class CountryController extends BaseController {
  constructor() {
    super();
  }

  // =================== for dropdown population ===================
  static countryList = catchAsyncErrors(async (req, res, next) => {
    let countries = await countryModel.find({ 
      isActive: true, 
      isDeleted: false, 
    });
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: countries,
    });
  });
  // =================== for dropdown population ===================


  // =================== for country management ===================
  static countriesList = catchAsyncErrors(async (req, res, next) => {
    
    let totalCountries = []
    let countries = []

    let totalCount = 0;
		let totalPages= 0;
		let page = 0;
		let limit = 0;
		let skip = 0;

    const { text } = req.body;
    if(req.method == "POST"){
			// let countries = await countryModel.updateMany(
			//   {}, 
			//   {
			//     $set: {
			//       "isActive": false,
			//       "isDeleted": false,
			//     }
			//   }
			// );

			// Pagination parameters ===========
			page = req.body.pageNo ? parseInt(req.body.pageNo) : 1; // Current page number
			limit = req.body.documentPerPage ? parseInt(req.body.documentPerPage) : 3; // Number of documents per page
			skip = (page - 1) * limit; // Number of documents to skip
			// Pagination parameters ===========

			let match = {
        isActive: true,
        isDeleted: false,
				$or: [
					{
						name: {
							$regex: ".*" + text + ".*",
							$options: "i",
						},
					},
				],
			};
			const aggregatorOpts = [
				{
					$addFields: {
						name: "$name",
					},
				},
				{
					$match: match,
				},
				{
          $sort: { createdAt: -1 } // Sort by createdAt in descending order
        },
			];
			totalCountries = await countryModel.aggregate(aggregatorOpts).exec();
			countries = await countryModel.aggregate(aggregatorOpts).skip(skip).limit(limit).exec();
    } else {
			// ======= for dropdown ===========
			countries = await super.getList(req, countryModel, "");
    }

		totalCount = totalCountries.length;
    totalPages= Math.ceil(totalCount/limit);

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: countries,
			pagination: {
				total: totalCount,
				totalPages: totalPages,
				rowsPerPage: limit,
				currentPage: page,
				hasNextPage: page < totalPages,
				hasPrevPage: page > 1
			},
    });
  });
  
  static countryUpdate = catchAsyncErrors(async (req, res, next) => {
    const { name, isActive, iso2, iso3, numeric_code, phone_code, capital, currency, currency_name, currency_symbol, tld, native, region, region_id, subregion, subregion_id, nationality, latitude, longitude, _id } = req.body;

    // console.log(isActive); return;
    let data = {
      name: name,
      iso2: iso2?? iso2,
      iso3: iso3?? iso3,
      numeric_code: numeric_code?? numeric_code,
      phone_code: phone_code?? phone_code,
      capital: capital?? capital,
      currency: currency?? currency,
      currency_name: currency_name?? currency_name,
      currency_symbol: currency_symbol?? currency_symbol,
      tld: tld?? tld,
      native: native?? native,
      region: region?? region,
      region_id: region_id?? region_id,
      subregion: subregion?? subregion,
      subregion_id: subregion_id?? subregion_id,
      nationality: nationality?? nationality,
      latitude: latitude?? latitude,
      longitude: longitude?? longitude,

      isActive: isActive,
    };
    const updated =
      _id && _id != null && _id != ""
        ? await super.updateById(countryModel, _id.toString(), data)
        : await super.create(res, countryModel, data);

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: updated,
    });
  });

  static getCountryDetail = catchAsyncErrors(async (req, res, next) => {
    const { id } = req.body;
    const country = await countryModel.findOne({ _id: id });
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: country,
      // data: userDetails(country),
    });
  });

  static countryDelete = catchAsyncErrors(async (req, res, next) => {

    return res.status(200).json({
      status: false,
      message: "Country deletion is not allowed. You can deactive a country insted. Try editing it."
    });
  });
  // =================== for country management ===================
  

}

module.exports = CountryController;
