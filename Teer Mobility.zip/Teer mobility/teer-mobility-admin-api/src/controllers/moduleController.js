const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/errorHandler");
const RequestHandler = require("../utils/RequestHandler");
const mongoose = require("mongoose");
const ObjectId = mongoose.Types.ObjectId;

const {
  calculateDistance,
  calculateDistanceInsTentApi,
  calculateTimeInKilometers,
  getRateChartCategory,
} = require("../utils/utilities");
const {
  vehicleCategoryDetails,
  vehicleModelDetails,
} = require("../utils/common");
const {
  MSG_RECORD_STATUS_SUCCESS,
  MSG_RECORD_FETCH_SUCCESS,
} = require("../config/constants");
const requestHandler = new RequestHandler();

const moduleModel = require("../models/moduleModel");

class ModuleController extends BaseController {
  constructor() {
    super();
  }

  static modulesList = catchAsyncErrors(async (req, res, next) => {
    let modules = []
    const { text } = req.body;
    if(req.method == "POST"){
        let match = {
          isActive: true,
          isDeleted: false,
          $and:[
            {
                $or: [
                  {
                    moduleName: {
                      $regex: ".*" + text + ".*",
                      $options: "i",
                    },
                  },
                ],
            }
          ]
        };
        const aggregatorOpts = [
          {
            $addFields: {
              moduleName: "$moduleName",
            },
          },
          {
            $match: match,
          },
        ];
        modules = await moduleModel.aggregate(aggregatorOpts).exec();
        await moduleModel.populate(
            modules,
            {
                path: 'parentModuleId',
                model: 'moduleCollection',
            }
        );
    } else {
        // ======= for dropdown ===========
        modules = await super.getList(req, moduleModel, "");
    }

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: modules,
    });
  });

  static modulesListWithPagination = catchAsyncErrors(async (req, res, next) => {
    let totalModules = [];
    let modules = [];

    let totalCount = 0;
		let totalPages= 0;
		let page = 0;
		let limit = 0;
		let skip = 0;

    // Pagination parameters ===========
		page = req.body.pageNo ? parseInt(req.body.pageNo) : 1; // Current page number
		limit = req.body.documentPerPage ? parseInt(req.body.documentPerPage) : 3; // Number of documents per page
		skip = (page - 1) * limit; // Number of documents to skip
		// Pagination parameters ===========

    const { text } = req.body;

    if(req.method == "POST"){
        let match = {
          isActive: true,
          isDeleted: false,
          $and:[
            {
                $or: [
                  {
                    moduleName: {
                      $regex: ".*" + text + ".*",
                      $options: "i",
                    },
                  },
                ],
            }
          ]
        };
        const aggregatorOpts = [
          {
            $addFields: {
              moduleName: "$moduleName",
            },
          },
          {
            $match: match,
          },
          // {
          //   $sort: { createdAt: -1 } // Sort by createdAt in descending order
          // },
        ];
        totalModules = await moduleModel.aggregate(aggregatorOpts).exec();
        modules = await moduleModel.aggregate(aggregatorOpts).sort({ position: 1 }).skip(skip).limit(limit).exec();
        await moduleModel.populate(
            modules,
            {
                path: 'parentModuleId',
                model: 'moduleCollection',
            }
        );
    } else {
        // ======= for dropdown ===========
        modules = await super.getList(req, moduleModel, "");
    }

    totalCount = totalModules.length;
    totalPages= Math.ceil(totalCount/limit);

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: modules,
      pagination: {
        total: totalCount,
        totalPages: totalPages,
        rowsPerPage: limit,
        currentPage: page,
        hasNextPage: page < totalPages,
        hasPrevPage: page > 1
      },
    });
  });

  static moduleAddUpdate = catchAsyncErrors(async (req, res, next) => {
    const { parentModuleId, moduleName, _id } = req.body;

    let data = {
        moduleName: moduleName,
    };
    if(parentModuleId != ""){
        data.parentModuleId = parentModuleId
    }
    const updated =
      _id && _id != null && _id != ""
        ? await super.updateById(moduleModel, _id.toString(), data)
        : await super.create(res, moduleModel, data);

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: updated,
    });
  });

  static getModuleDetail = catchAsyncErrors(async (req, res, next) => {
    const { id } = req.body;
    const asset = await moduleModel.findOne({ _id: id });
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: asset,
    });
  });

  static deleteModule = catchAsyncErrors(async (req, res, next) => {
    const { id } = req.body;
    let foundModule = await moduleModel.find({
        isActive: true,
        isDeleted: false,

        parentModuleId: id.toString(),
    });
    // let foundModuleIdArr = [];
    // foundModule.forEach((item)=>{
    //     // pushing _id of all childModules of the module attempted to delete ==
    //     foundModuleIdArr.push(item._id)
    // });
    // // pushing _id of the module attempted to delete ==
    // // foundModuleIdArr.push(id)
    // console.log("foundModuleIdArr ==> ");
    // console.log(foundModuleIdArr);
    let updated = [];
    // =================== soft delete ===================
    if(foundModule == ''){
        // console.log("deleting single");
        // deleteing single module ====
        updated = await super.updateById(moduleModel, id, {
            isDeleted: true
        });
    } else {
        // console.log("deleting multiple");
        // deleting the module attempted to delete along with all childs of the said module ====
        // childs delete =====
        updated = await moduleModel.updateMany(
            {
                // _id: {
                //     $in: foundModuleIdArr
                // }
                parentModuleId: id
            },
            { 
                $set: { isDeleted: true } 
            },
        );
        // childs delete =====

        // parent delete =====
        updated = await super.updateById(moduleModel, id, {
            isDeleted: true
        });
        // parent delete =====

    }
    // =================== soft delete ===================
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: updated,
    });
  });

  // static perssionModuleList = catchAsyncErrors(async (req, res, next) => {
  //   let modules = []
  //   let moduleArr = await moduleModel.find({ isDeleted: false, isActive: true }).populate('parentModuleId').lean();
    
  //   moduleArr.forEach((modulee, index) => {
  //       if(modulee.parentModuleId == null){
  //           modulee['submodules'] = []
  //           modulee['id'] = modulee._id.toString()
  //           modules.push(modulee)
  //       }
  //       if(index == (moduleArr.length - 1)){
  //           moduleArr.forEach((submodule, subindex) => {
  //               if(submodule.parentModuleId != null){

  //                   let index = modules.findIndex(x => x.id === submodule.parentModuleId._id.toString())
  //                   if(index != -1){
  //                       modules[index]['submodules'].push(submodule)
  //                   }
  //               }
  //               if(subindex == (moduleArr.length - 1)){
  //                   return res.status(200).json({
  //                       status: true,
  //                       data: modules
  //                   });
  //               }
  //           })
            
  //       }
  //   })
  // });

  static perssionModuleList = catchAsyncErrors(async (req, res, next) => {
    let modules = [];
    let moduleArr = await moduleModel.find({ isDeleted: false, isActive: true }).populate('parentModuleId').lean();

    // Sort the module array by position
    moduleArr.sort((a, b) => a.position - b.position);

    moduleArr.forEach((modulee, index) => {
        if (modulee.parentModuleId == null) {
            modulee['submodules'] = [];
            modulee['id'] = modulee._id.toString();
            modules.push(modulee);
        }

        if (index == (moduleArr.length - 1)) {
            moduleArr.forEach((submodule, subindex) => {
                if (submodule.parentModuleId != null) {
                    let index = modules.findIndex(x => x.id === submodule.parentModuleId._id.toString());
                    if (index != -1) {
                        modules[index]['submodules'].push(submodule);
                    }
                }

                if (subindex == (moduleArr.length - 1)) {
                    // Sort submodules by position
                    modules.forEach(module => {
                        module.submodules.sort((a, b) => a.position - b.position);
                    });

                    return res.status(200).json({
                        status: true,
                        data: modules
                    });
                }
            });
        }
    });
});
static parentChildModulesList = catchAsyncErrors(async (req, res, next) => {
  let modules = []
  let moduleArr = await moduleModel.find({ 
    isDeleted: false, 
    isActive: true
   }).populate('parentModuleId').lean();

  moduleArr.sort((a, b) => a.position - b.position);
  
  moduleArr.forEach((modulee, index) => {
      if(modulee.parentModuleId == null){
          modulee['submodules'] = []
          modulee['id'] = modulee._id.toString()
          modules.push(modulee)
      }
      if(index == (moduleArr.length - 1)){
          moduleArr.forEach((submodule, subindex) => {
              if(submodule.parentModuleId != null){

                  let index = modules.findIndex(x => x.id === submodule.parentModuleId._id.toString())
                  if(index != -1){
                      modules[index]['submodules'].push(submodule)
                  }
              }
              if(subindex == (moduleArr.length - 1)){
                  modules.forEach(module => {
                      module.submodules.sort((a, b) => a.position - b.position);
                  });
                  return res.status(200).json({
                      status: true,
                      data: modules
                  });
              }
          })
          
      }
  })
});

  // static parentChildModulesList = catchAsyncErrors(async (req, res, next) => {
  //   let modules = []
  //   let moduleArr = await moduleModel.find({ 
  //     isDeleted: false, 
  //     isActive: true
  //    }).populate('parentModuleId').lean();
    
  //   moduleArr.forEach((modulee, index) => {
  //       if(modulee.parentModuleId == null){
  //           modulee['submodules'] = []
  //           modulee['id'] = modulee._id.toString()
  //           modules.push(modulee)
  //       }
  //       if(index == (moduleArr.length - 1)){
  //           moduleArr.forEach((submodule, subindex) => {
  //               if(submodule.parentModuleId != null){

  //                   let index = modules.findIndex(x => x.id === submodule.parentModuleId._id.toString())
  //                   if(index != -1){
  //                       modules[index]['submodules'].push(submodule)
  //                   }
  //               }
  //               if(subindex == (moduleArr.length - 1)){
  //                   return res.status(200).json({
  //                       status: true,
  //                       data: modules
  //                   });
  //               }
  //           })
            
  //       }
  //   })
  // });
  static reorderModule = catchAsyncErrors(async (req, res, next) => {
    const { order } = req.body;
    order.forEach(async (item, key) => {
      let updated = await super.updateById(moduleModel, item, {
        position: key + 1
      });
    });
    // =================== soft delete ===================
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: {},
    });
  });


  static allPerssionModuleList = catchAsyncErrors(async (req, res, next) => {
    let modules = await moduleModel.find({ isDeleted: false, isActive: true }).lean();

    return res.status(200).json({
          status: true,
          data: modules
      });
  });

}



module.exports = ModuleController;
