const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/errorHandler");
const RequestHandler = require("../utils/RequestHandler");
const mongoose = require("mongoose");
const ObjectId = mongoose.Types.ObjectId;
const moment = require('moment-timezone');
const dateFns = require('date-fns');
const sendPushNotification = require("../helpers/sendPushNotification");

const {
  calculateDistance,
  calculateDistanceInsTentApi,
  calculateTimeInKilometers,
  getRateChartCategory,
} = require("../utils/utilities");
const {
  vehicleCategoryDetails,
  vehicleModelDetails,
} = require("../utils/common");
const {
  MSG_RECORD_STATUS_SUCCESS,
  MSG_RECORD_FETCH_SUCCESS,
} = require("../config/constants");
const requestHandler = new RequestHandler();

// ------- STRIPE INITIALIZE -------
const stripe = require('stripe')(
  (process.env.APP_ENV == 'production')
    ? process.env.STRIPE_LIVE_SECRET_KEY 
    : process.env.STRIPE_TEST_SECRET_KEY
);
// ------- STRIPE INITIALIZE -------

// ------- RAZORPAY INITIALIZE -------
const Razorpay = require('razorpay');
const razorpayConfig = require("../config/index").RAZORPAY;
// const razorpay = new Razorpay({
//   key_id: (process.env.APP_ENV == 'production')
//     ? process.env.RAZORPAY_LIVE_KEY_ID 
//     : process.env.RAZORPAY_TEST_KEY_ID,
//   key_secret: (process.env.APP_ENV == 'production')
//     ? process.env.RAZORPAY_LIVE_KEY_SECRET 
//     : process.env.RAZORPAY_TEST_KEY_SECRET,
// });
const razorpay = new Razorpay(
  razorpayConfig.mode === "TEST"
    ? razorpayConfig.testCred
    : razorpayConfig.liveCred
);;
// ------- RAZORPAY INITIALIZE -------

const countryModel = require("../models/countryModel");
const tripsModel = require("../models/tripsModel");
const fareChartModel = require("../models/fareChartModel");
const couponModel = require("../models/couponModel");
const tripPassengerModel = require("../models/tripPassengerModel");
const walletModel = require("../models/walletModel");
const notificationModel = require("../models/notificationModel");
const userModel = require("../models/userModel");

const transactionModel = require("../models/transactionModel");
const transactionLogModel = require("../models/transactionLogModel");
const walletLedgerModel = require("../models/walletLedgerModel");
const transactionHistoryModel = require("../models/transactionHistoryModel");

class BookingController extends BaseController {
  constructor() {
    super();
  }

  // ====================================================================================
  // ------------------------------ ONLINE PAYMENT FOR RIDE -----------------------------
  // ====================================================================================

  // ------------------------------ WITH STRIPE ---------------------------
  static createTripPaymentIntentWithStripe = catchAsyncErrors(async (req, res, next) => {
    const { amount, currency } = req.body;

    if (!amount) {
      return res.status(422).json({
        status: false,
        message: "Amount is required",
        data: {},
      });
    }
    if (!currency) {
      return res.status(422).json({
        status: false,
        message: "Currency is required",
        data: {},
      });
    }

    let customerDetail = await userModel.findOne({
      _id: req.user._id,
    });

    let fullNameOfCustomer = customerDetail?.firstName + " " + customerDetail?.lastName;

    // const customer = await stripe.customers.create({
    //   name: fullNameOfCustomer,
    //   address: {
    //     line1: customerDetail?.address || "510 Townsend St",
    //     postal_code: customerDetail?.zipcode || "98140",
    //     city: customerDetail?.city || "San Francisco",
    //     state: customerDetail?.state || "CA",
    //     country: "AE",
    //   },
    // });

    const customer = await stripe.customers.create({
      name: fullNameOfCustomer,
      address: {
        line1: "510 Townsend St",
        postal_code: "98140",
        city: "San Francisco",
        state: "CA",
        country: "US",
      },
    });
    const ephemeralKey = await stripe.ephemeralKeys.create(
      { customer: customer.id },
      { apiVersion: "2024-06-20" }
    );

    let options = {
      amount: parseFloat(amount.toString()) * 100,
      currency: currency,
      customer: customer.id,
    };

    // Create Payment Intent
    const paymentIntent = await stripe.paymentIntents.create({
      amount: options.amount,
      currency: options.currency,
      customer: options.customer,
      description: "Payment For Trip Booking.",
      payment_method_types: ["card"],
      // automatic_payment_methods: {
      //   enabled: true,
      // },
    });
    // return res.status(200).json({
    //   paymentIntent: paymentIntent,
    // });

    let transactionCreated = await transactionModel.create({
      userId: req.user._id,
      paymentGatewayOrderId: paymentIntent.id,
      paidAmount: paymentIntent.amount,
			paidCurrency: paymentIntent.currency,
      type: "tripPayment",
      remark: "Payment for trip.",
      paymentDate: new Date(),
      paymentStatus: "Pending",
    });

    // console.log("transactionCreated ===>");
    // console.log(transactionCreated);

    if (transactionCreated) {
      let transactionLogCreated = await transactionLogModel.create({
        transactionId: transactionCreated._id,
        request: JSON.stringify(req.body),
        response: JSON.stringify(paymentIntent),
      });
      if (transactionLogCreated) {
        return res.status(200).json({
          status: true,
          message: "Intent created successfully in Stripe Server for Trip Payment.",
          data: {
            amount: paymentIntent.amount,
            stripeOrderId: paymentIntent.id,
            paymentIntent: paymentIntent.client_secret,
            ephemeralKey: ephemeralKey.secret,
            customer: customer.id,
            publishableKey:
              process.env.APP_ENV == "production"
                ? process.env.STRIPE_LIVE_PUBLISHABLE_KEY
                : process.env.STRIPE_TEST_PUBLISHABLE_KEY,
          },
          errors: null,
        });
      }
    }
  });

  static verifyTripPaymentViaStripe = catchAsyncErrors(async (req, res, next) => {
    const {
      stripeOrderId,
      amount,
      currency,
      tripId,
    } = req.body;

    if (!stripeOrderId) {
      return res.status(422).json({
        status: false,
        message: "Stripe order Id is required",
        data: {},
      });
    }

    // Retrieve the Payment Intent from Stripe
    const paymentIntent = await stripe.paymentIntents.retrieve(stripeOrderId);

    if (paymentIntent) {
      if (paymentIntent.status === "succeeded") {
        // Payment was successful
        let existingTransaction = await super.getByCustomOptionsSingle(
          req,
          transactionModel,
          {
            paymentGatewayOrderId: stripeOrderId,
          }
        );

        if (existingTransaction) {
          await super.updateById(transactionModel, existingTransaction._id, {
            paymentStatus: "Paid",
            paidVia: "Stripe",
          });

          await super.create(res, transactionLogModel, {
            transactionId: existingTransaction._id,
            request: JSON.stringify(req.body),
            response: JSON.stringify(paymentIntent),
          });

          let transactionHistoryData = {
            userId: req.user._id,
            transactionId: existingTransaction._id,
            tripId: tripId,
            
            amount: amount,
            currency: currency,

            gatewayName: "Stripe",

            type: "directTripPayment",
            remarks: "Direct payment via Stripe for trip booking successful.",
            
            isSuccess: true,
          };
          let transactionHistory = await super.create(res, transactionHistoryModel, transactionHistoryData);

          return res.status(200).json({
            status: true,
            message: "Payment successful..!!",
            data: {},
          });
        } else {
          let transactionHistoryData = {
            userId: req.user._id,
            transactionId: existingTransaction._id,
            tripId: tripId,

            amount: amount,
            currency: currency,
    
            gatewayName: "Stripe",
    
            type: "directTripPayment",
            remarks: "Trip payment via Stripe failed as transaction not found probably due to incorrect Stripe Order Id..!!",
            
            isSuccess: false,
          };
          let transactionHistory = await super.create(res, transactionHistoryModel, transactionHistoryData);

          return res.status(404).json({
            status: false,
            message: "Transaction not found",
            data: {},
          });
        }
      } else {
        // Payment status is not 'succeeded' ====
        let transactionHistoryData = {
          userId: req.user._id,
          transactionId: existingTransaction._id,
          tripId: tripId,

          amount: amount,
          currency: currency,

          gatewayName: "Stripe",

          type: "directTripPayment",
          remarks: "Direct payment via Stripe for trip booking failed or not completed yet..!!",
          
          isSuccess: false,
        };
        let transactionHistory = await super.create(res, transactionHistoryModel, transactionHistoryData);

        return res.status(400).json({
          status: false,
          message: "Payment failed or is not yet completed.",
          data: {},
        });
      }
    } else {
      let transactionHistoryData = {
        userId: req.user._id,
        transactionId: existingTransaction._id,
        tripId: tripId,

        amount: amount,
        currency: currency,

        gatewayName: "Stripe",

        type: "directTripPayment",
        remarks: "Trip payment via Stripe failed as payment intent not found due to incorrect Stripe Order Id..!!",
        
        isSuccess: false,
      };
      let transactionHistory = await super.create(res, transactionHistoryModel, transactionHistoryData);

      return res.status(404).json({
        status: false,
        message: "Payment intent not found.",
        data: {},
      });
    }
  });
  // ------------------------------ WITH STRIPE ---------------------------
  
  // ----------------------------- WITH RAZORPAY --------------------------
  static createPaymentIntentWithRazorPay = catchAsyncErrors(async (req, res, next) => {
		const { amount, currency } = req.body;

		if (!amount) {
			return res.status(422).json({
				status: false,
				message: "Amount is required",
				data: {},
			});
		}
		if (!currency) {
			return res.status(422).json({
				status: false,
				message: "Currency is required",
				data: {},
			});
		}

		// Create a Razorpay order
		const options = {
			amount: parseFloat(amount.toString()) * 100, // amount in paise
			currency: currency,
			receipt: `receipt_${Date.now()}`,
		};

		const order = await razorpay.orders.create(options);
		// console.log("order =====>");
		// console.log(order);
		
		if (order) {
			let transactionCreated = await transactionModel.create({
				userId: req.user._id,

				paymentGatewayOrderId: order.id,
				paidVia: "Razorpay",
				
				type: "tripPayment",

				paidAmount: order.amount,
				paidCurrency: order.currency,

				paymentDate: new Date(),
				paymentStatus: "Pending",

				remark: "Payment for trip.",
			});

			// console.log("transactionCreated ===>");
			// console.log(transactionCreated);

			if (transactionCreated) {
				let transactionLogCreated = await transactionLogModel.create({
					transactionId: transactionCreated._id,
					request: JSON.stringify(req.body),
					response: JSON.stringify(order),
				});
				if (transactionLogCreated) {
					return res.status(200).json({
						status: true,
						message: "Order created successfully in Razorpay",
						data: {
							amount: order.amount,
							razorpayOrderId: order.id,
							currency: order.currency,
							orderId: order.id,
							key: razorpayConfig.mode === "TEST" ? razorpayConfig.testCred.key_id : razorpayConfig.liveCred.key_id
							// key: (process.env.APP_ENV == 'production')
							// 	? process.env.RAZORPAY_LIVE_KEY_ID 
							// 	: process.env.RAZORPAY_TEST_KEY_ID,
						},
						errors: null,
					});
				} else {
					return res.status(500).json({
						status: false,
						message: "Oopss..!! Something wrong happened while creating transaction log for direct payment via Razorpay..!!",
						data: {}
					});
				}
			}
		} else {
			return res.status(400).josn({
				status: false,
				message: "Oopss..!! Something went wrong while creating order in Razorpay gateway for direct payment..!!",
				data: {},
			});
		}
	});

  static verifyTripPaymentViaRazorPay = catchAsyncErrors(async (req, res, next) => {
    const { razorpayPaymentId, razorpayOrderId, razorpaySignature, amount, currency, tripId, } = req.body;

    if (!razorpayPaymentId) {
      return res.status(422).json({
        status: false,
        message: "Razorpay payment ID is required",
        data: {},
      });
    }
    if (!razorpayOrderId) {
      return res.status(422).json({
        status: false,
        message: "Razorpay order ID is required",
        data: {},
      });
    }
    // if (!razorpaySignature) {
    //   return res.status(422).json({
    //     status: false,
    //     message: "Razorpay signature is required",
    //     data: {},
    //   });
    // }

		// let encryptedString = razorpayOrderId + "|" + razorpayPaymentId;
		// let expectedSignature = crypto.createHmac(
		// 	"sha256",
		// 	razorpayConfig.mode === "TEST" ? razorpayConfig.testCred.key_secret : razorpayConfig.liveCred.key_secret
		// ).update(encryptedString.toString()).digest("hex");

		let existingTransaction = await super.getByCustomOptionsSingle(
			req,
			transactionModel,
			{
				paymentGatewayOrderId: razorpayOrderId,
			}
		);
    
		if (existingTransaction) {
			// Capture payment
			try {
        const captureResponse = await razorpay.payments.capture(
          razorpayPaymentId,
          existingTransaction.paidAmount,
          existingTransaction.paidCurrency
        );
        let fetchRazorpay = await razorpay.payments.fetch(razorpayPaymentId);
        
        if (fetchRazorpay.status !== "captured") {
          let transactionHistoryData = {
            userId: req.user._id,
            transactionId: existingTransaction._id,
            tripId: tripId,

            amount: amount,
            currency: currency,
  
            gatewayName: "Razorpay",
  
            type: "directTripPayment",
            remarks: "Trip payment via Razorpay failed or not captured yet.",
            
            isSuccess: false,
          };
          let transactionHistory = await super.create(res, transactionHistoryModel, transactionHistoryData);

          return res.status(400).json({
            status: false,
            message: "Payment not yet captured..!! Can't process further..!!",
            data: {},
          });
        }

        // Update transaction status
        await super.updateById(transactionModel, existingTransaction._id, {
          paidVia: "Razorpay",
          paymentStatus: "Paid",
        });

        // Log the transaction
        await super.create(res, transactionLogModel, {
          transactionId: existingTransaction._id,
          request: JSON.stringify(req.body),
          response: JSON.stringify(fetchRazorpay),
        });

        let transactionHistoryData = {
          userId: req.user._id,
          transactionId: existingTransaction._id,
          tripId: tripId,

          amount: amount,
          currency: currency,

          gatewayName: "Razorpay",

          type: "directTripPayment",
          remarks: "Trip payment via Razorpay successful.",
          
          isSuccess: true,
        };
        let transactionHistory = await super.create(res, transactionHistoryModel, transactionHistoryData);

        return res.status(200).json({
          status: true,
          message: "Trip payment successful..!!",
          data: {},
        });
      } catch (error) {
        // Handle errors

        let transactionHistoryData = {
          userId: req.user._id,
          transactionId: existingTransaction._id,
          tripId: tripId,

          amount: amount,
          currency: currency,

          gatewayName: "Razorpay",

          type: "directTripPayment",
          remarks: "Trip payment via Razorpay failed due to some error with Razorpay gateway or internal failure..!!",
          
          isSuccess: false,
        };
        let transactionHistory = await super.create(res, transactionHistoryModel, transactionHistoryData);

        return res.status(400).json({
          status: false,
          message: "Error processing payment",
          data: { error: error.message },
        });
      }
		} else {
      let transactionHistoryData = {
        userId: req.user._id,
        transactionId: existingTransaction._id,
        tripId: tripId,

        amount: amount,
        currency: currency,

        gatewayName: "Razorpay",

        type: "directTripPayment",
        remarks: "Trip payment via Razorpay failed as transaction not found probably due to incorrect Razorpay Order Id..!!",
        
        isSuccess: false,
      };
      let transactionHistory = await super.create(res, transactionHistoryModel, transactionHistoryData);

			return res.status(404).json({
				status: false,
				message: "Transaction not found",
				data: {},
			});
		}
  });
  // ----------------------------- WITH RAZORPAY --------------------------

  // ====================================================================================
  // ------------------------------ ONLINE PAYMENT FOR RIDE -----------------------------
  // ====================================================================================




  // ====================================================================================
  // ========= booking being created from APP ===========================================
  // ====================================================================================
  // global search with "static tripPassengerUpdate" to jump to booking from web function
  // ====================================================================================
  static bookingCreate = catchAsyncErrors(async (req, res, next) => {
    let { countryId, serviceId, tripId, pickupStopId, dropStopId, bookingDate, bookingLocation, bookingLat, bookingLong, numberOfSeats, paymentMode, payableAmount, currency, couponCode, _id } = req.body;

    if(!serviceId){
      return res.status(422).json({
        status: false,
        message: "serviceId not present in payload.",
        data: {}
      });
    }

    if(
      (paymentMode != "wallet")
      && (paymentMode != "online")
      // || (paymentMode != "coupon")
    ){
      return res.status(400).json({
        status: false,
        message: `Payment mode can either be "wallet" or "online" as of now. Please check the payload for casing or spelling mistakes.`,
        data: {}
      });
    }

    let moneyDeducted = false;

    if(!numberOfSeats){
      // ====== default ======
      numberOfSeats = 1
      // ====== default ======
    }
    // Get the current time in "Asia/Kolkata" time zone =======
    let momentKolkata = moment().tz('Asia/Kolkata');
    let currentDate = momentKolkata.format('YYYY-MM-DD');
    let currentDay = momentKolkata.format('dddd');
    let currentTime = momentKolkata.format('HH:mm');
    // Get the current time in "Asia/Kolkata" time zone =======

    let tripDetail = await tripsModel.findOne({
      _id: tripId
    }).populate([
      {
        "path": "tripPlanId",
        "model": "tripPlanCollection",
        "populate": {
          "path": "routeId",
          "model": "routeMapCollection",
        }
      },
    ]);

    let routeDistance = tripDetail.tripPlanId.routeId.routeDistance;

    let fareChart = await fareChartModel.findOne({
      countryId: countryId
    });

    let calculatedPayableAmount = 0;
    let couponExist = []
    if(couponCode){
      couponExist = await couponModel.findOne({
        couponCode: couponCode
      });
    }

    // ========== "calculatedPayableAmount" calculation ==========
    if(couponExist){
      // ======== with coupon ========
      if(routeDistance <= fareChart.forFirstHowManyKm){
        calculatedPayableAmount = numberOfSeats * Number(fareChart.baseFare)
      } else {
        let extraKm = (Number(routeDistance) - Number(fareChart.forFirstHowManyKm))
        calculatedPayableAmount = numberOfSeats * (Number(fareChart.baseFare) + extraKm * Number(fareChart.farePerExtraKm))
      }

      if(couponExist.discountType == "Flat"){
        calculatedPayableAmount = Number(calculatedPayableAmount) - Number(couponExist.discount)
      } else if(couponExist.discountType == "Percentage"){
        let discountAmount = Number(calculatedPayableAmount) * Number(couponExist.discount) / 100

        if(discountAmount < couponExist.maxDiscount){
          calculatedPayableAmount = Number(calculatedPayableAmount) - Number(discountAmount)
        } else if(discountAmount >= couponExist.maxDiscount){
          calculatedPayableAmount = Number(calculatedPayableAmount) - Number(couponExist.maxDiscount)
        }
      }
      // ======== with coupon ENDS ========
    } else {
      // ======== without coupon ========
      if(routeDistance <= fareChart.forFirstHowManyKm){
        calculatedPayableAmount = numberOfSeats * fareChart.baseFare
      } else {
        let extraKm = (Number(routeDistance) - Number(fareChart.forFirstHowManyKm));
        calculatedPayableAmount = numberOfSeats * (Number(fareChart.baseFare) + extraKm * Number(fareChart.farePerExtraKm))
      }
      // ======== without coupon ========
    }
    // ========== "calculatedPayableAmount" calculation ==========

    if(calculatedPayableAmount == payableAmount){
      // ===== proceed for booking ======
      let otp = Math.floor(1000 + Math.random() * 9000);
      let bookingData = {
        userId: req.user._id,
        serviceId: serviceId,
  
        tripId: tripId,
        pickupStopId: pickupStopId,
        dropStopId: dropStopId,
  
        bookingDate: bookingDate,
        bookingLocation: bookingLocation,
        coordinates: [bookingLat, bookingLong],
  
        numberOfSeats: numberOfSeats,
        payment: {
          paymentMode: paymentMode,
          payableAmount: payableAmount,
          currency: currency
        },
        otp: otp,
      };
      if(couponCode){
        bookingData.couponCode = couponCode
      }
      
      let checkBookingExist = await tripPassengerModel.findOne({
        userId: req.user._id,
        serviceId: serviceId,
        tripId: tripId,
        bookingDate: bookingDate,

        isCancelled: false,
      });

      // ====== check whether passenger's other trip time clashes with the current one ======
      let timeClashedFlag = false;
      let allBookingsForParticularUserForTheDay = await tripPassengerModel.find({
        userId: req.user._id,
        serviceId: serviceId,
        bookingDate: currentDate,

        isCancelled: false,
      }).populate([
        {
          "path": "tripId",
          "model": "tripsCollection",
        },
      ]);
      // console.log("allBookingsForParticularUserForTheDay ===>");
      // console.log(allBookingsForParticularUserForTheDay);
      
      if(allBookingsForParticularUserForTheDay){
        let tripInWhichPassengerAssignIsBeingAttempted = await tripsModel.findOne({
          _id: tripId,
        });

        // ====== these two times should not clash with any existing trip timing for the passenger ======
        let startTimeOfTripInWhichPassengerAssignIsBeingAttempted = tripInWhichPassengerAssignIsBeingAttempted.tripStartTime

        let NewStartTime = currentDate + startTimeOfTripInWhichPassengerAssignIsBeingAttempted;
        let momentNewStartTime = moment(NewStartTime, 'YYYY-MM-DD HH:mm');
        
        let endTimeOfTripInWhichPassengerAssignIsBeingAttempted = tripInWhichPassengerAssignIsBeingAttempted.tripEndTime
        
        let NewEndTime = currentDate + endTimeOfTripInWhichPassengerAssignIsBeingAttempted;
        let momentNewEndTime = moment(NewEndTime, 'YYYY-MM-DD HH:mm');
        // ====== these two times should not clash with any existing trip timing for the passenger ======
        
        // ============= Clash check and flag updating =============
        allBookingsForParticularUserForTheDay.forEach((booking)=>{
          let ExistingStartTime = currentDate + booking.tripId.tripStartTime;
          let momentExistingStartTime = moment(ExistingStartTime, 'YYYY-MM-DD HH:mm');
          let ExistingEndTime = currentDate + booking.tripId.tripEndTime;
          let momentExistingEndTime = moment(ExistingEndTime, 'YYYY-MM-DD HH:mm');
          
          // console.log(`NewStartTime => ${momentNewStartTime}`);
          // console.log(`NewEndTime => ${momentNewEndTime}`);
          
          // console.log(`ExistingStartTime => ${momentExistingStartTime}`);
          // console.log(`ExistingEndTime => ${momentExistingEndTime}`);

          console.assert(((momentNewStartTime > ExistingEndTime) || (momentNewStartTime > ExistingStartTime)), "true1SearchMeInCodeBase");
          console.assert(((momentNewEndTime > momentExistingEndTime) || (momentNewEndTime > ExistingStartTime)), "true2SearchMeInCodeBase");
          
          if(
            ((momentNewStartTime > momentExistingEndTime) || (momentNewStartTime > ExistingStartTime))
            && 
            ((momentNewEndTime > momentExistingEndTime) || (momentNewEndTime > ExistingStartTime))
          ){
            // ==== should let book ====
            timeClashedFlag = false;
            // ==== should let book ====
          } else {
            // ========= TIME CLASHING =========
            // ==== should NOT let book ====
            timeClashedFlag = true;
            // ==== should NOT let book ====
            // ========= TIME CLASHING =========
          }
        });

        // console.log(`final status of timeClashedFlag ===> ${timeClashedFlag}`);
        // ============= Clash check and flag updating =============

      }
      // ====== check whether passenger's other trip time clashes with the current one ======
      
      if(
        !checkBookingExist
        && timeClashedFlag == false
      ){

        // creating ====
        if(paymentMode == "wallet"){
          // ------- initiating payment from wallet -------
          let walletBalance = await walletModel.findOne({
            userId: req.user._id,
            currency: currency
          });
          if(walletBalance.amount >= calculatedPayableAmount){
            let updatedBalance = Number(walletBalance.amount) - Number(calculatedPayableAmount);
            // ------- deducting money -------
            let walletBalanceUpdate = await super.updateById(walletModel, walletBalance._id, {
              amount: updatedBalance
            });
            // ------- deducting money -------
  
            if(walletBalanceUpdate){
              moneyDeducted = true;
  
              let transactionHistoryData = {
                userId: req.user._id,
                // transactionId: existingTransaction._id,
                tripId: tripId,

                amount: payableAmount,
                currency: currency,
    
                gatewayName: "Wallet",
    
                type: "payFromWallet",
                remarks: "Trip payment via Wallet for trip booking successful.",
                
                isSuccess: true,
              };
              let transactionHistory = await super.create(res, transactionHistoryModel, transactionHistoryData);
  
            } else {
              moneyDeducted = false;
  
              let transactionHistoryData = {
                userId: req.user._id,
                transactionId: existingTransaction._id,
                tripId: tripId,
                
                amount: payableAmount,
                currency: currency,
    
                gatewayName: "Wallet",
    
                type: "payFromWallet",
                remarks: "Trip payment via Wallet for trip booking failed.",
                
                isSuccess: false,
              };
              let transactionHistory = await super.create(res, transactionHistoryModel, transactionHistoryData);
  
              return res.status(400).json({
                status: 400,
                message: "Oops..! There was problem deducting wallet balance.",
                data: {}
              });
            }
  
          } else {
            return res.status(400).json({
              status: 400,
              message: "Insufficient wallet balance..!!",
              data: {
                balance : walletBalance.amount,
                payableAmount: calculatedPayableAmount
              }
            });
          }
        } else if (paymentMode == "online"){
          moneyDeducted = true;
        }


        // ========== Handles the actual booking based on money deduction status ==========
        if(moneyDeducted == true){
          let tripPassengerAssign = await super.create(res, tripPassengerModel, bookingData);
          let tripPassenger = await tripPassengerModel.findOne({
            userId: tripPassengerAssign.userId,
            tripId: tripPassengerAssign.tripId,
          }).populate([
            {
              "path": "userId",
              "model": "usersCollection"
            },
            {
              "path": "tripId",
              "model": "tripsCollection",
              "populate": {
                "path": "tripPlanId",
                "model": "tripPlanCollection",
                "populate": {
                  "path": "routeId",
                  "model": "routeMapCollection",
                }
              }
            },
          ]);
          if(tripPassenger){
            // =============== send notification to the customer ===============
            // ========== inApp Notification ===========
            let notiData = {
              userId: tripPassenger.userId._id,
              tripId: tripPassenger.tripId._id,

              title: `Trip Confirmed`,
              body: `Dear ${tripPassenger.userId.firstName}, your trip is confirmed for ${tripPassenger.tripId.tripPlanId.routeId.routeName} route at ${tripPassenger.tripId.tripDate} on ${tripPassenger.tripId.tripStartTime}. We will share the vehicle details soon.`,
            };
            let inAppNotification = await super.create(res, notificationModel, notiData);
            // ========== inApp Notification ===========
            if (tripPassenger.userId.fcmToken) {
              // ========== Push Notification ===========
              console.log("------ Sending trip booking Notification ----");
              
              let messages = {
                title: "Trip Confirmed",
                body: JSON.stringify({
                  "tripId": tripPassenger.tripId._id.toString(),
                  "msg": "Dear "+tripPassenger.userId.firstName+", your trip is confirmed for "+tripPassenger.tripId.tripPlanId.routeId.routeName+" route at "+tripPassenger.tripId.tripDate+" on "+tripPassenger.tripId.tripStartTime+". We will share the vehicle details soon",
                  "type": "Show"
                }),
              };
              await sendPushNotification(tripPassenger.userId.fcmToken, messages, "android");
            }
            // =============== send notification to the customer ===============

            return res.status(200).json({
              status: 200,
              message: "Booked Successfully.",
              data: tripPassenger
            });
          } else {
            return res.status(400).json({
              status: 400,
              message: "Oops..!! Something went terribly wrong..!!",
              data: {}
            });
          }

        } else if(moneyDeducted == false){
          return res.status(422).json({
            status: false,
            message: "Ooppss..!! We encountered an error while deducting the money. Can not proceed with booking..!! Please try again in sometime..!!",
            data: {},
          });
        }
        // ========== Handles the actual booking based on money deduction status ==========
        
      } else {
        if(timeClashedFlag == true){
          return res.status(422).json({
            status: false,
            message: "Booking for this user in same timing already exists in some other trip. Time Clashes. Cannot book. Please try assigning this user in a trip whose timing is outside of the current trip for this user.",
            data: {},
          });
        }
        return res.status(400).json({
          status: 400,
          message: "You already have a booking.",
          data: checkBookingExist
        });
      }
    } else {
      // ===== un-processable data ===== 
      return res.status(422).json({
        status: false,
        message: "Oops..!! Incorrect payable amount. Unable to create booking.",
        data: {}
      });
    }
  });

}

module.exports = BookingController;
