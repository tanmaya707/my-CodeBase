const axios = require('axios');
const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/errorHandler");
const RequestHandler = require("../utils/RequestHandler");
const bcrypt = require("bcryptjs");
const JWTAuth = require("../utils/jwtToken");
const jwt = require("jsonwebtoken");
const jwtConfig = require("../config").JWT;

const { calculateDistance,
    calculateDistanceInsTentApi,
    calculateTimeInKilometers,
    getRateChartCategory } = require("../utils/utilities");
const {
    MSG_RECORD_STATUS_SUCCESS,
    MSG_RECORD_FETCH_SUCCESS
} = require("../config/constants");
const requestHandler = new RequestHandler();

const userModel = require('../models/userModel');
const rollModel = require('../models/rollModel');
const moduleModel = require('../models/moduleModel');
const rolePermissionModel = require('../models/rolePermissionModel');
const rolePermissionUserwiseModel = require('../models/rolePermissionUserwiseModel');
const customerModel = require('../models/customerModel');

class AuthenticationController extends BaseController {
  constructor() {
    super();
  }

  static login = catchAsyncErrors(async (req, res, next) => {
    const { userName, dialcode, phone, password, deviceType, userType, fcmToken } = req.body;
    // console.log(phone);
    // console.log(dialcode);
    // console.log(password);
    // if (!userName) {
    //     return next(new ErrorHandler("Please enter username", 400));
    // }
    // if (!phone) {
    //     return next(new ErrorHandler("Please enter phone", 400));
    // }
    
    let isRegistered = false;

    let condition = {
        isActive: true,
    };
    if(userName){
        condition["email"] = userName
    } else if(phone){
        condition["phone"] = phone
    }
    
    if(deviceType == 1){
        if(!dialcode){
            return next(new ErrorHandler("Please enter dialcode.", 403));
        } else {
            condition["dialcode"] = dialcode
        }
    }
    // let condition = { email: userName };
    // let condition = { phone: phone };

    if(userType && (userType != '') && (userType != null)){
        let roles = []
        let role = await rollModel.find({
            name: "Driver" 
        }) 
        if(userType == 'Customer'){
            // "Customer", "Employee", "Student" ---- these three are considered customers in general
            role = await rollModel.find({
                name: { $in: ["Customer", "Employee"] } 
            }) 
        } else if(userType == 'Corporate'){
            role = await rollModel.find({
                name: { $in: ["Corporate", "Vendor", "School"] } 
            }) 
        } else if(userType == 'Super Admin'){
            role = await rollModel.find({
                name: "Super Admin" 
            }) 
        }
        if(role.length > 0){
            role.forEach(val => {
                roles.push(val._id.toString())
            })
        }
        condition["roleId"] = { $in : roles }
    }
    const userExists = await userModel.findOne(condition).select("password");
    if (userExists) {
        isRegistered = true;
    }
    const currentDateTime = new Date();
    // const expirationDateTime = new Date(userExists.otp.expiration);
    if (
        // userExists.otp.expiration 
        // && currentDateTime < expirationDateTime
        isRegistered == true
    ) {   
        const isPasswordMatched = await userExists.comparePassword(password);
        if (!isPasswordMatched) {
            return res.status(400).json({
                status: false,
                message: "Password does not match!",
                data: {},
            });
        } else {
            let userSearchCondition = {}
            if(userName){
                userSearchCondition.email = userName
            } else {
                userSearchCondition.phone = phone
            }
            // console.log("userSearchCondition ===> ");
            // console.log(userSearchCondition);
            // {
            //     // email: userName,
            //     // phone: phone,
            //     // condition
            //     userSearchCondition
            // }
            await userModel.findOne(
                userSearchCondition
            ).then(async user => {
                // console.log("user ======>");
                // console.log(user);
                if (user) {
                    // console.log("here ====");
                    const { _id, firstName, lastName, email } = user;
                    let token = JWTAuth.ClientSign({ _id, firstName, lastName, email, deviceType, userType });
                    let time = new Date()
                    time.setDate(time.getDate() + 30)
                    time  = new Date(time)
                    let data = {}
                    if(Number(deviceType, userType) == 2){
                        data = {
                            webLogin: {
                                accessToken: token
                            }
                        }
                    }else{
                        // console.log("applogin =======");
                        data = {
                            appLogin: {
                                accessToken: token
                            },
                            fcmToken: fcmToken? fcmToken:""
                        }
                    }
                    let userDetailUpdate = await userModel.findByIdAndUpdate(userExists._id, data)
                    // console.log("userDetailUpdate ==>");
                    // console.log(userDetailUpdate);
                    // let userDetail = await userModel.findOne({ email: userName })
                    let userDetail = await userModel.findOne(userSearchCondition)
                    // console.log("userDetail ==>");
                    // console.log(userDetail);
                    
                    let userDetails = JSON.parse(JSON.stringify(userDetail))
                    userDetails.name = userDetails.firstName+" "+userDetails.lastName
                    userDetails.userImageUrl = process.env.API_URL + 'uploads/userImages/';
                    userDetails.profileImage = process.env.API_URL + 'uploads/userImages/' + (userDetails.profileImage)? userDetails.profileImage:process.env.API_URL + 'uploads/userImages/' + 'demo_image.jpg'

                    let roleOfLoggedUser = await rollModel.findOne({
                        _id: userDetails.roleId
                    });
                    userDetails.roleName = roleOfLoggedUser.name;

                    if(userDetailUpdate){
                        return requestHandler.sendSuccess(res, "Login Successfully")({
                            token,
                            isRegistered: isRegistered,
                            user: userDetails
                        });
                    }else{
                        return requestHandler.customError(res, 500, "Something went wrong..!!");
                    }
                } else {
                    return requestHandler.customError(res, 400, "User not found..!!");
                }
            }).catch(error => {
                return requestHandler.customError(res, 500, error);
            });
        }

    } else {
        return requestHandler.customError(res, 404, "User not found.");
    }
  });

  static socialLogin = catchAsyncErrors(async (req, res, next) => {
    const { email, deviceType, userType, provider } = req.body;
    if (!email) {
        return next(new ErrorHandler("Email Required", 400));
    }
    let isRegistered = false;
    let condition = { email: email }
    if(userType && (userType != '') && (userType != null)){
        let roles = []
        let role = await rollModel.find({
            name: "Driver" 
        }) 
        if(userType == 'Customer'){
            role = await rollModel.find({
                name: { $in: ["Corporate User", "Customer"] } 
            }) 
        }else if(userType == 'Corporate'){
            role = await rollModel.find({
                name: { $in: ["Corporate", "Vendor", "School"] } 
            }) 
        }
        if(role.length > 0){
            role.forEach(val => {
                roles.push(val._id.toString())
            })
        }
        
        condition["roleId"] = { $in : roles }
    }
    const userExists = await userModel.findOne(condition);
    if (userExists) {
        isRegistered = true;
    }
    const currentDateTime = new Date();
    // const expirationDateTime = new Date(userExists.otp.expiration);
    if (
        // userExists.otp.expiration 
        // && currentDateTime < expirationDateTime
        isRegistered == true
    ) {   
        await userModel.findOne({
            email: email,
        }).then(async user => {
            if (user) {
                const { _id, firstName, lastName, email } = user;
                let token = JWTAuth.ClientSign({ _id, firstName, lastName, email, deviceType, userType });
                let time = new Date()
                time.setDate(time.getDate() + 30)
                time  = new Date(time)
                let data = {}
                if(Number(deviceType, userType) == 2){
                    data = {
                        webLogin: {
                            provider: (provider)?provider:null,
                            accessToken: token
                        }
                    }
                }else{
                    data = {
                        appLogin: {
                            provider: (provider)?provider:null,
                            accessToken: token
                        }
                    }
                }
                let userDetailUpdate = await userModel.findByIdAndUpdate(userExists._id, data)
                let userDetail = await userModel.findOne({ email: email })
                
                let userDetails = JSON.parse(JSON.stringify(userDetail))
                userDetails.name = userDetails.firstName+" "+userDetails.lastName
                
                if(userDetailUpdate){
                    return requestHandler.sendSuccess(res, "Login Successfully")({
                        token,
                        isRegistered: isRegistered,
                        user: userDetails
                    });
                }else{
                    return requestHandler.customError(res, 500, "Something went wrong..!!");
                }
            } 
            else {
                return requestHandler.customError(res, 400, "User not found..!!");
            }
        }) 
        .catch(error => {
            console.log(error)
            return requestHandler.customError(res, 500, error);
        });

    } else {
        return requestHandler.customError(res, 404, "User not found.");
    }
  });

  static rolePermissionChecker = catchAsyncErrors(async (req, res, next) => {
    let rolePermissionChecker = []
    let roleId = req.body.roleId
    
    // ============== if superAdmin is trying to logIn give all module permissions by default ==========
    const modules = await moduleModel.find({ isActive: true, isDeleted: false });
    let modulesArr = []
    modules.forEach((module)=>{
        modulesArr.push(module._id)
    });
    const super_admin = await rollModel.findOne({ name: "Super Admin" });
    if(roleId == super_admin._id){
        await rolePermissionModel.findOne({ roleId: super_admin._id }).then(async (item)=>{
            await rolePermissionModel.findByIdAndUpdate(item._id, {
                roleId: super_admin._id,
                moduleId: modulesArr,
    
                updatedBy: super_admin._id,
            });
        });
    }
    // ============== if superAdmin is trying to logIn give all module permissions by default ==========

    await rolePermissionModel.findOne(
        {
            roleId: roleId, 
        }
    ).then(async (item) => {
        if(item != null){
            item?.moduleId.forEach((item) => {
                rolePermissionChecker.push(item.toString())
            });
        } 
        if(rolePermissionChecker.length > 0){
            return res.status(200).json({
                status: true,
                message: "Success, permissions found.",
                data: rolePermissionChecker,
            });
        } else {
            return res.status(401).json({
                status: false,
                message: "Oops..!! Looks like your role has no module permissions set yet. Please contact admin.",
                data: rolePermissionChecker,
            });
        }
    }).catch(error => {
        console.log(error);
        return res.status(500).json({
            status: false,
            message: "Oops..!! Something went terribly wrong..!!",
            data: rolePermissionChecker,
        });
    });
  });
  static userPermissionChecker = catchAsyncErrors(async (req, res, next) => {
    let userPermissionChecker = []
    let roleId = req.body.roleId
     // ============== if superAdmin is trying to logIn give all module permissions by default ==========
    const modules = await moduleModel.find({ isActive: true, isDeleted: false });
    let modulesArr = []

    modules.forEach((module)=>{
        modulesArr.push(module._id)
    });
    const super_admin = await rollModel.findOne({ name: "Super Admin" });
    if(roleId == super_admin._id){
        await rolePermissionModel.findOne({ roleId: super_admin._id }).then(async (item)=>{
            await rolePermissionModel.findByIdAndUpdate(item._id, {
                roleId: super_admin._id,
                moduleId: modulesArr,
                updatedBy: super_admin._id,
            });
        });
    }
    // ============== if superAdmin is trying to logIn give all module permissions by default ==========
    if(roleId == super_admin._id){
        await rolePermissionModel.findOne(
            {
                roleId: roleId, 
            }
        ).then(async (item) => {
            if(item != null){
                item?.moduleId.forEach((item) => {
                    userPermissionChecker.push(item.toString())
                });
            } 
            if(userPermissionChecker.length > 0){
                return res.status(200).json({
                    status: true,
                    message: "Success, permissions found.",
                    data: userPermissionChecker,
                });
            } else {
                return res.status(401).json({
                    status: false,
                    message: "Oops..!! Looks like your role has no module permissions set yet. Please contact admin.",
                    data: userPermissionChecker,
                });
            }
        }).catch(error => {
            return res.status(500).json({
                status: false,
                message: "Oops..!! Something went terribly wrong..!!",
                data: userPermissionChecker,
            });
        });
    }else{
        await rolePermissionUserwiseModel.findOne(
            {
                userId: req.user._id, 
            }
        ).then(async (item) => {
            if(item != null){
                item?.moduleId.forEach((item) => {
                    userPermissionChecker.push(item.toString())
                });
            } 
            if(userPermissionChecker.length > 0){
                return res.status(200).json({
                    status: true,
                    message: "Success, permissions found.",
                    data: userPermissionChecker,
                });
            } else {
                return res.status(401).json({
                    status: false,
                    message: "Oops..!! Looks like your role has no module permissions set yet. Please contact admin.",
                    data: userPermissionChecker,
                });
            }
        }).catch(error => {
            return res.status(500).json({
                status: false,
                message: "Oops..!! Something went terribly wrong..!!",
                data: userPermissionChecker,
            });
        });
    }
    
  });

  static roleList = catchAsyncErrors(async (req, res, next) => {
    let roles = [];
    if(req.method == "GET"){
        // for dropdown =====
        roles = await rollModel.find({ isDeleted: { $ne: true }, name: { $ne: 'Super Admin'} });
    } else if(req.method == "POST"){
        roles = await rollModel.find({ isDeleted: { $ne: true }, name: { $ne: 'Super Admin'} });
    }
    return requestHandler.sendSuccess(res, "Successful")({
        data: roles
    });
    
  });

  static forgetPassword = catchAsyncErrors(async (req, res, next) => {
    const { email, otp, password, userType } = req.body;
    if (!email) {
        return next(new ErrorHandler("Please enter email", 400));
    }
    if(otp && (otp != '') && (otp != null)){
        const userExists = await userModel.findOne({ email: email });
        if(userExists.otp && (userExists.otp.code == otp)){
            return res.status(200).json({
                status: true,
                message: "OTP matched",
            });
        }else{
            return requestHandler.customError(res, 404, "OTP doesn't match");
        }
    }else{
        let isRegistered = false;
        let condition = { email: email }
        if(userType && (userType != '') && (userType != null)){
            let roles = []
            let role = await rollModel.find({
                name: "Driver" 
            }) 
            if(userType == 'Customer'){
                role = await rollModel.find({
                    name: { $in: ["Corporate User", "Customer"] } 
                }) 
            }else if(userType == 'Corporate'){
                role = await rollModel.find({
                    name: { $in: ["Corporate", "Vendor", "School"] } 
                }) 
            }
            if(role.length > 0){
                role.forEach(val => {
                    roles.push(val._id.toString())
                })
            }
            condition["roleId"] = { $in : roles }
        }
        const userExists = await userModel.findOne(condition);
        if (userExists) {
            isRegistered = true;
        }
        
        if (
            isRegistered == true
        ) {   
            if(password && (password != '') && (password != null)){
                let pass = await bcrypt.hash(password, 10)
                
                let updated = await super.updateById(userModel, userExists._id.toString(), { password: pass })
                if(updated){
                    return res.status(200).json({
                        status: true,
                        message: "Password changed successfully"
                    });
                }
            }else{
                const otpcode = Math.floor(1000 + Math.random() * 9000)
                const currentDateTime = new Date();
                const expirationDateTime = new Date(currentDateTime.setMinutes(currentDateTime.getMinutes() + 5));
                let userDetail = await userModel.findByIdAndUpdate(userExists._id, {
                    otp: {
                        code: otpcode,
                        expiration: expirationDateTime
                    }
                })

                return res.status(200).json({
                    status: true,
                    message: "OTP sent to your email",
                    otp: otpcode
                });
            }
        } else {
            return requestHandler.customError(res, 404, "User not found.");
        }
    }
  });

  static changePassword = catchAsyncErrors(async (req, res, next) => {
    const { old_password, password } = req.body;
    if (!old_password) {
        return next(new ErrorHandler("Old password required", 400));
    }
    if (!password) {
        return next(new ErrorHandler("New password required", 400));
    }
    let userExists = await userModel.findOne({_id: req.user._id.toString()}).select("password")
    const isPasswordMatched = await userExists.comparePassword(old_password);
    if (!isPasswordMatched) {
        return res.status(400).json({
            status: false,
            message: "Old password does not match!",
            data: {},
        });
    }else{
        let pass = await bcrypt.hash(password, 10)
        let updated = await super.updateById(userModel, req.user._id.toString(), { password: pass })
        if(updated){
            return res.status(200).json({
                status: true,
                message: "Password changed successfully"
            });
        }else{
            return res.status(500).json({
                status: false,
                message: "Something went wrong"
            });
        }
    }
  });

  static logout = catchAsyncErrors(async (req, res, next) => {
    let time = new Date()
    time.setDate(time.getDate() - 1)
    time  = new Date(time)
    let data = {} 
    if(Number(req.user.deviceType) == 2){
        data = {
            webLogin: null
        }
    }else{
        data = {
            appLogin: null
        }
    }
    let updated = await super.updateById(userModel, req.user._id.toString(), data)
    if(updated){
        return res.status(200).json({
            status: true,
            message: "Logged out successfully"
        });
    }
  });

  static deactivateAccount = catchAsyncErrors(async (req, res, next) => {
    const { isActive } = req.body
    let data = {
        isActive: isActive
    } 
    if(isActive == false){
        data['webLogin'] = null
        data['appLogin'] = null
    }
    
    let updated = await super.updateById(userModel, req.user._id.toString(), data)
    if(updated){
        return res.status(200).json({
            status: true,
            message: "Updated successfully"
        });
    }
  });

  // =============================== App APIs ===========================
  static roleListForApp = catchAsyncErrors(async (req, res, next) => {
    let roles = [];
    let appRoles = [];
    let serviceRolesIdArr = [];
    if(req.method == "GET"){
        let userServices = await customerModel.find({
            userId: req.user._id
        });
        userServices.forEach((userService)=>{
            serviceRolesIdArr.push(userService.roleId.toString())
        });
        // for dropdown =====
        roles = await rollModel.find({ isDeleted: { $ne: true }, name: { $ne: 'Super Admin'} });

        roles.forEach((role)=>{
            if(serviceRolesIdArr.includes(role._id.toString())){
                if(role.name == "Customer"){
                    let roleObj = {
                        _id: role._id,
                        name: role.name,
                        displayName: "Individual"
                    };
                    appRoles.push(roleObj);
                } else if(role.name == "Employee"){
                    let roleObj = {
                        _id: role._id,
                        name: role.name,
                        displayName: "Corporate Employee"
                    };
                    appRoles.push(roleObj);
                } else if(role.name == "Student"){
                    let roleObj = {
                        _id: role._id,
                        name: role.name,
                        displayName: "Student/Parent"
                    };
                    appRoles.push(roleObj);
                }
            }
        });
    } else if(req.method == "POST"){
        // roles = await rollModel.find({ isDeleted: { $ne: true }, name: { $ne: 'Super Admin'} });
    }
    
    if(appRoles.length > 0){
        return res.status(200).json({
            status: true,
            message: "Success",
            data: appRoles
        });
    } else {
        return res.status(200).json({
            status: false,
            message: "No Roles Found.",
            data: []
        });
    }

  });
  // =============================== App APIs ===========================
}


module.exports = AuthenticationController;
