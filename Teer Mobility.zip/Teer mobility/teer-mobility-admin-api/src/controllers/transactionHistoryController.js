const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/errorHandler");
const RequestHandler = require("../utils/RequestHandler");
const mongoose = require("mongoose");
const ObjectId = mongoose.Types.ObjectId;
// ------- STRIPE INITIALIZE -------
const stripe = require('stripe')(
  (process.env.APP_ENV == 'production')
    ? process.env.STRIPE_LIVE_SECRET_KEY 
    : process.env.STRIPE_TEST_SECRET_KEY
);
// ------- STRIPE INITIALIZE -------

// ------- RAZORPAY INITIALIZE -------
const Razorpay = require('razorpay');
const razorpayConfig = require("../config/index").RAZORPAY;
const razorpay = new Razorpay(
  razorpayConfig.mode === "TEST"
    ? razorpayConfig.testCred
    : razorpayConfig.liveCred
);;
// ------- RAZORPAY INITIALIZE -------

const {
  calculateDistance,
  calculateDistanceInsTentApi,
  calculateTimeInKilometers,
  getRateChartCategory,
} = require("../utils/utilities");
const {
  vehicleCategoryDetails,
  vehicleModelDetails,
  couponDetails,
  transactionDetails,
  transactionHistoryTripWiseDetails,
} = require("../utils/common");
const {
  MSG_RECORD_STATUS_SUCCESS,
  MSG_RECORD_FETCH_SUCCESS,
} = require("../config/constants");
const requestHandler = new RequestHandler();

const transactionHistoryModel = require("../models/transactionHistoryModel");
const userModel = require("../models/userModel");
const transactionModel = require("../models/transactionModel");
const tripsModel = require("../models/tripsModel");
const tripPlanModel = require("../models/tripPlanModel");
const transactionLogModel = require("../models/transactionLogModel");

class TransactionHistoryController extends BaseController {
  constructor() {
    super();
  }

  static transactionHistoryListWithPagination = catchAsyncErrors(async (req, res, next) => {
    let totalTransactionHistories = [];
    let transactionHistories = [];

    let totalCount = 0;
		let totalPages= 0;
		let page = 0;
		let limit = 0;
		let skip = 0;

    // Pagination parameters ===========
		page = req.body.pageNo ? parseInt(req.body.pageNo) : 1; // Current page number
		limit = req.body.documentPerPage ? parseInt(req.body.documentPerPage) : 3; // Number of documents per page
		skip = (page - 1) * limit; // Number of documents to skip
		// Pagination parameters ===========

    let { gateway, typeOfPayment, amount, currency, isSuccess, fromDate, toDate } = req.body;
    
    if(req.method == "POST"){
        let match = {
          $and: [
            {
              $or: [
                {
                  gatewayName: {
                    $regex: ".*" + gateway + ".*",
                    $options: "i",
                  },
                },
              ],
            },
          ],
        };

        if(amount){
          match["amount"] = parseFloat(amount);
        }
        if(currency){
          match["currency"] = {
            $regex: ".*" + currency + ".*",
            $options: "i",
          };
        }
        if(typeOfPayment){
          match["type"] = {
            $regex: ".*" + typeOfPayment + ".*",
            $options: "i",
          };
        }

        let paymentStatus = "";
        if(isSuccess == "true"){
          paymentStatus = true;
        } else {
          paymentStatus = false;
        }
        if(isSuccess){
          match["isSuccess"] = paymentStatus;
        }

        if(fromDate && toDate){
          match["createdAt"] = {
            $gte: new Date(fromDate + "T00:00:00.000Z"),
            $lt: new Date(new Date(new Date(toDate).setDate(new Date(toDate).getDate() + 1)).toISOString().split('T')[0] + "T00:00:00.000Z")
          };
          
        }else if(fromDate){
          match["createdAt"] = {
            $gte: new Date(fromDate + "T00:00:00.000Z")
          };
        }else if(toDate){
          match["createdAt"] = {
            $lt: new Date(new Date(new Date(toDate).setDate(new Date(toDate).getDate() + 1)).toISOString().split('T')[0] + "T00:00:00.000Z")
          };
        }
        
        const aggregatorOpts = [
          {
            $addFields: {
              gatewayName: "$gatewayName",
              amount: "$amount",
              currency: "$currency",
              type: "$type",
              isSuccess: "$isSuccess",
              createdAt: "$createdAt",
            },
          },
          {
            $match: match,
          },
          {
						$sort: { createdAt: -1 } // Sort by createdAt in descending order
					},
        ];
        totalTransactionHistories = await transactionHistoryModel.aggregate(aggregatorOpts).exec();
        transactionHistories = await transactionHistoryModel.aggregate(aggregatorOpts).skip(skip).limit(limit).exec();
        await userModel.populate(
          transactionHistories,
          [
            {
              "path": "userId",
              "model": "usersCollection",
              "populate": {
                "path": "roleId",
                "model": "roleCollection",
              }
            },
          ]
        );
        await transactionModel.populate(transactionHistories,
          [
            {
              "path": "transactionId",
              "model": "TransactionsCollection",
            },
          ]
        );
        await tripsModel.populate(transactionHistories,
          [
            {
              "path": "tripId",
              "model": "tripsCollection",
              "populate": [
                {
                  "path": "tripPlanId",
                  "model": "tripPlanCollection",
                  "populate": [
                    {
                      "path": "routeId",
                      "model": "routeMapCollection",
                    },
                  ]
                },
                {
                  "path": "vendorId",
                  "model": "corporateCollection",
                },
                {
                  "path": "driverId",
                  "model": "driverCollection",
                  "populate": [
                    {
                      "path": "userId",
                      "model": "usersCollection",
                    },
                  ]
                },
                {
                  "path": "vehicleId",
                  "model": "vehicleCollection",
                },
              ]
            },
          ]
        );
    } else {
        // ======= for dropdown ===========
        transactionHistories = await super.getList(req, transactionHistoryModel, "");
        // ======= for dropdown ===========
    }

    totalCount = totalTransactionHistories.length;
    totalPages= Math.ceil(totalCount/limit);

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: transactionDetails(transactionHistories),
      // data: transactionHistories,
      pagination: {
        total: totalCount,
        totalPages: totalPages,
        rowsPerPage: limit,
        currentPage: page,
        hasNextPage: page < totalPages,
        hasPrevPage: page > 1
      },
    });
  });

  static transactionHistoryTripWiseListWithPagination = catchAsyncErrors(async (req, res, next) => {
    let totalTransactionHistories = [];
    let transactionHistories = [];
    
    let totalCount = 0;
    let totalPages = 0;
    let page = 0;
    let limit = 0;
    let skip = 0;
    
    // Pagination parameters
    page = req.body.pageNo ? parseInt(req.body.pageNo) : 1; // Current page number
    limit = req.body.documentPerPage ? parseInt(req.body.documentPerPage) : 3; // Number of documents per page
    skip = (page - 1) * limit; // Number of documents to skip
    
    let { fromDate, toDate, routeId, } = req.body;
    
    // Initialize match object as empty
    let match = {};

    // Add conditions to match object based on request parameters
    const conditions = [];

    if (fromDate) {
      conditions.push({ "createdAt": { $gte: new Date(fromDate) } });
    }
    if (toDate) {
      conditions.push({ "createdAt": { $lte: new Date(toDate) } });
    }

    // If there are any conditions, wrap them in $and
    if (conditions.length > 0) {
      match.$and = conditions;
    }

    // Aggregation pipeline
    const aggregatorOpts = [
      {
        $match: match, // Filter based on the provided parameters
      },
      {
        $match: {
          "tripId": { $ne: null }  // Exclude transactions with null tripId
        },
      },
      {
        $group: {
          _id: "$tripId", // Group by tripId
          currency: { $first: "$currency" }, // Get the first currency value for each trip
          totalAmount: { $sum: "$amount" }, // Sum of amounts per trip
          transactionCount: { $sum: 1 }, // Count of transactions per trip
        },
      },
      {
        $sort: { _id: 1 }, // Sort by tripId in ascending order (you can change to descending if needed)
      },
    ];

    // Apply aggregation to get total transaction data per trip
    totalTransactionHistories = await transactionHistoryModel.aggregate(aggregatorOpts).exec();
    transactionHistories = await transactionHistoryModel.aggregate(aggregatorOpts).skip(skip).limit(limit).exec();
  
    totalCount = totalTransactionHistories.length;
    totalPages = Math.ceil(totalCount / limit);
  
    // Rename _id to tripId in the response data
    let formattedTransactionHistories = transactionHistories.map(item => ({
      tripId: item._id,  // Renamed _id to tripId
      currency: item.currency,
      totalAmount: item.totalAmount,
      transactionCount: item.transactionCount,
    }));
  
    // Clean up response to exclude null tripId
    let filteredTransactionHistories = formattedTransactionHistories.filter(item => item.tripId !== null);

    await tripsModel.populate(filteredTransactionHistories, [
      {
        "path": "tripId",
        "model": "tripsCollection",
        "populate": [
          {
            "path": "tripPlanId",
            "model": "tripPlanCollection",
            "populate": [
              {
                "path": "routeId",
                "model": "routeMapCollection",
              },
            ]
          },
          {
            "path": "vendorId",
            "model": "corporateCollection",
          },
          {
            "path": "driverId",
            "model": "driverCollection",
            "populate": [
              {
                "path": "userId",
                "model": "usersCollection",
              },
            ]
          },
          {
            "path": "vehicleId",
            "model": "vehicleCollection",
            "populate": {
              "path": "modelId",
              "model": "vehicleModelCollection",
              "populate": {
                "path": "type",
                "model": "vehicleCategoriesCollection",
              }
            }
          },
        ]
      },
    ]);

    // custom filters =====================
    let customFilteredTransactionHistories = await Promise.all(
      filteredTransactionHistories.map(async (transactionHistory) => {
        if(routeId){
          if(transactionHistory?.tripId?.tripPlanId?.routeId?._id.toString() == routeId.toString()){
            return transactionHistory;
          } else{
            return null;
          }
        } else{
          return transactionHistory;
        }
      })
    );

    // Filter out null values
    filteredTransactionHistories = customFilteredTransactionHistories.filter(item => item !== null);

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: transactionHistoryTripWiseDetails(filteredTransactionHistories),
      // data: filteredTransactionHistories,
      pagination: {
        total: totalCount,
        totalPages: totalPages,
        rowsPerPage: limit,
        currentPage: page,
        hasNextPage: page < totalPages,
        hasPrevPage: page > 1,
      },
    });
  });
  
  // =================================== REFUND ===================================
  static refundMoneyViaStripe = catchAsyncErrors(async (req, res, next) => {
    let { _id } = req.body;

    let transactionHistory = await transactionHistoryModel.findOne({
      _id: _id,
    }).populate([
      {
        "path": "transactionId",
        "model": "TransactionsCollection",
      },
    ]);

    const paymentIntent = await stripe.paymentIntents.retrieve(transactionHistory?.transactionId?.paymentGatewayOrderId);
    
    const chargeId = paymentIntent?.latest_charge;

    // refund -----------
    const refund = await stripe.refunds.create({
      charge: chargeId,
      // amount in the smallest currency unit, e.g., cents
      amount: transactionHistory?.transactionId?.paidAmount,
    });
    // refund -----------

    if(refund?.status == "succeeded"){
      let transactionHistoryUpdate = await super.updateById(
        transactionHistoryModel, 
        transactionHistory?._id, 
        {
          isRefunded: true,
        }
      );
      
      let transactionCreated = await transactionModel.create({
        userId: req.user._id,
        paymentGatewayOrderId: transactionHistory?.transactionId?.paymentGatewayOrderId,
        paidAmount: transactionHistory?.transactionId?.paidAmount,
        paidCurrency: transactionHistory?.transactionId?.paidCurrency,
        type: "refund",
        remark: "Refund to customer successful.",
        paymentDate: new Date(),
        paymentStatus: "Paid",
      });
      if (transactionCreated) {
        let transactionLogCreated = await transactionLogModel.create({
          transactionId: transactionCreated._id,
          request: JSON.stringify(req.body),
          response: JSON.stringify(refund),
        }); 
      }
      // save transaction history ==========
      let transactionHistoryData = {
        userId: req.user._id,
        transactionId: transactionCreated._id,
        // tripId: tripId,
        
        amount: Number(transactionHistory?.transactionId?.paidAmount) / 100,
        currency: transactionHistory?.transactionId?.paidCurrency,

        gatewayName: "Stripe",

        type: "refund",
        remarks: "Refund successful.",
        
        isSuccess: true,
      };
      let transactionHistoryCreate = await super.create(res, transactionHistoryModel, transactionHistoryData);
      // save transaction history ==========

      return res.status(200).json({
        status: true,
        message: "Refund successful.",
        data: refund
      });
    } else {
      let transactionCreated = await transactionModel.create({
        userId: req.user._id,
        paymentGatewayOrderId: transactionHistory?.transactionId?.paymentGatewayOrderId,
        paidAmount: transactionHistory?.transactionId?.paidAmount,
        paidCurrency: transactionHistory?.transactionId?.paidCurrency,
        type: "refund",
        remark: "Refund to customer failed.",
        paymentDate: new Date(),
        paymentStatus: "Failed",
      });
      if (transactionCreated) {
        let transactionLogCreated = await transactionLogModel.create({
          transactionId: transactionCreated._id,
          request: JSON.stringify(req.body),
          response: JSON.stringify(refund),
        }); 
      }
      // save transaction history ==========
      let transactionHistoryData = {
        userId: req.user._id,
        transactionId: transactionCreated._id,
        // tripId: tripId,
        
        amount: Number(transactionHistory?.transactionId?.paidAmount) / 100,
        currency: transactionHistory?.transactionId?.paidCurrency,

        gatewayName: "Stripe",

        type: "refund",
        remarks: "Refund failed.",
        
        isSuccess: false,
      };
      let transactionHistoryCreate = await super.create(res, transactionHistoryModel, transactionHistoryData);
      // save transaction history ==========

      return res.status(400).json({
        status: false,
        message: "Refund failed as there is some problem with stripe.",
        data: refund
      });
    }
  });
  
  // static refundMoneyViaRazorpay = catchAsyncErrors(async (req, res, next) => {
  //   let { _id } = req.body;

  //   let transactionHistory = await transactionHistoryModel.findOne({
  //     _id: _id,
  //   }).populate([
  //     {
  //       "path": "transactionId",
  //       "model": "TransactionsCollection",
  //     },
  //   ]);

  //   let paymentId = transactionHistory?.transactionId?.paymentGatewayOrderId;
  //   console.log("paymentId ====>");
  //   console.log(paymentId);
  //   console.log("transactionHistory?.transactionId?.paidAmount ====>");
  //   console.log(transactionHistory?.transactionId?.paidAmount);
    

  //   const refund = await razorpay.payments.refund(paymentId, {
  //     amount: transactionHistory?.transactionId?.paidAmount, // Amount to refund in smallest currency unit (e.g., paise) 
  //     speed: "normal",
  //     receipt: paymentId
  //   });
  //   // try{
  //   // } catch (err) { 
  //   //   console.error('Error creating refund:', err); 
  //   //   res.status(500).send({ 
  //   //     status: false, 
  //   //     error: err.message 
  //   //   }); 
  //   // }
    

  //   res.status(200).json({
  //     status: true,
  //     message: "Refund successful",
  //     data: refund,
  //   });

  //   // if(refund){

  //   // }

  // });
  // =================================== REFUND ===================================
  

  static refundMoneyViaRazorpay = catchAsyncErrors(async (req, res, next) => { 
    let { _id } = req.body; 
    try { 
        let transactionHistory = await transactionHistoryModel.findOne({ _id: _id, }).populate([ 
          { 
            "path": "transactionId", 
            "model": "TransactionsCollection", 
          }, 
        ]); 

        let transactionLogCollection = await transactionLogModel.find({
          transactionId: transactionHistory?.transactionId?._id,
        }).sort({ createdAt: -1 }).limit(1);

        if(transactionLogCollection){
          let respons = JSON.parse(transactionLogCollection[0].response);

          let paymentId = respons.id;
          try { 
            const refund = await razorpay.payments.refund(
              paymentId, 
              { 
                amount: transactionHistory?.transactionId?.paidAmount, 
              }
            ); 

            if(refund){
              let transactionHistoryUpdate = await super.updateById(
                transactionHistoryModel, 
                transactionHistory?._id, 
                {
                  isRefunded: true,
                }
              );

              let transactionCreated = await transactionModel.create({
                userId: req.user._id,
                paymentGatewayOrderId: transactionHistory?.transactionId?.paymentGatewayOrderId,
                paidAmount: (transactionHistory?.transactionId?.paidAmount) / 100,
                paidCurrency: transactionHistory?.transactionId?.paidCurrency,
                type: "refund",
                remark: "Refund to customer successful.",
                paymentDate: new Date(),
                paymentStatus: "Paid",
              });
              if (transactionCreated) {
                let transactionLogCreated = await transactionLogModel.create({
                  transactionId: transactionCreated._id,
                  request: JSON.stringify(req.body),
                  response: JSON.stringify(refund),
                }); 
              }
              // save transaction history ==========
              let transactionHistoryData = {
                userId: req.user._id,
                transactionId: transactionCreated._id,
                // tripId: tripId,
                
                amount: Number(transactionHistory?.transactionId?.paidAmount) / 100,
                currency: transactionHistory?.transactionId?.paidCurrency,
        
                gatewayName: "Razorpay",
        
                type: "refund",
                remarks: "Refund successful.",
                
                isSuccess: true,
              };
              let transactionHistoryCreate = await super.create(res, transactionHistoryModel, transactionHistoryData);
              // save transaction history ==========

              res.status(200).json({ 
                status: true, 
                message: "Refund successful", 
                data: refund, 
              }); 
            } else {
              let transactionCreated = await transactionModel.create({
                userId: req.user._id,
                paymentGatewayOrderId: transactionHistory?.transactionId?.paymentGatewayOrderId,
                paidAmount: transactionHistory?.transactionId?.paidAmount,
                paidCurrency: transactionHistory?.transactionId?.paidCurrency,
                type: "refund",
                remark: "Refund to customer failed.",
                paymentDate: new Date(),
                paymentStatus: "Failed",
              });
              if (transactionCreated) {
                let transactionLogCreated = await transactionLogModel.create({
                  transactionId: transactionCreated._id,
                  request: JSON.stringify(req.body),
                  response: JSON.stringify(refund),
                }); 
              }
              // save transaction history ==========
              let transactionHistoryData = {
                userId: req.user._id,
                transactionId: transactionCreated._id,
                // tripId: tripId,
                
                amount: Number(transactionHistory?.transactionId?.paidAmount) / 100,
                currency: transactionHistory?.transactionId?.paidCurrency,
        
                gatewayName: "Stripe",
        
                type: "refund",
                remarks: "Refund failed.",
                
                isSuccess: false,
              };
              let transactionHistoryCreate = await super.create(res, transactionHistoryModel, transactionHistoryData);
              // save transaction history ==========

              return res.status(400).json({
                status: false,
                message: "Refund can not be made",
                data: {}
              });
            }

          } catch (err) { 
            console.error('Error creating refund:', err); 
            res.status(500).send({ 
              status: false, 
              message: err.message, 
              data: {}
            }); 
          } 
        }
        else { 
          res.status(404).send({ 
            status: false, 
            message: 'No payments found for the given details.', 
            data: {}
          }); 
        }
    } catch (err) { 
      console.error('Error fetching transaction history:', err); 
      res.status(500).send({ 
        status: false, 
        message: 'Failed to fetch transaction history.', 
        data: {}
      }); 
    } 
  });

  static getTransactionHistoryDetail = catchAsyncErrors(async (req, res, next) => {
    const { _id } = req.body;
    const transactionHistory = await transactionHistoryModel.findOne({ _id: _id });
    await userModel.populate(
      transactionHistory,
      [
        {
          "path": "userId",
          "model": "usersCollection",
          "populate": {
            "path": "roleId",
            "model": "roleCollection",
          }
        },
      ]
    );
    await transactionModel.populate(transactionHistory,
      [
        {
          "path": "transactionId",
          "model": "TransactionsCollection",
        },
      ]
    );
    await tripsModel.populate(transactionHistory,
      [
        {
          "path": "tripId",
          "model": "tripsCollection",
          "populate": [
            {
              "path": "tripPlanId",
              "model": "tripPlanCollection",
              "populate": [
                {
                  "path": "routeId",
                  "model": "routeMapCollection",
                },
              ]
            },
            {
              "path": "vendorId",
              "model": "corporateCollection",
            },
            {
              "path": "driverId",
              "model": "driverCollection",
              "populate": [
                {
                  "path": "userId",
                  "model": "usersCollection",
                },
              ]
            },
            {
              "path": "vehicleId",
              "model": "vehicleCollection",
            },
          ]
        },
      ]
    );
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: transactionHistory,
    });
  });

  static deleteTransactionHistory = catchAsyncErrors(async (req, res, next) => {
    const { _id } = req.body;
    const updated = await super.deleteById(transactionHistoryModel, _id);
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: updated,
    });
  });

  static userWiseTransactionHistory = catchAsyncErrors(async (req, res, next) => {
    let { userId } = req.body;

    let transactionHistory = await transactionHistoryModel.findOne({
      userId: userId,
    });
    await userModel.populate(
      transactionHistory,
      [
        {
          "path": "userId",
          "model": "usersCollection",
          "populate": {
            "path": "roleId",
            "model": "roleCollection",
          }
        },
      ]
    );
    await transactionModel.populate(transactionHistory,
      [
        {
          "path": "transactionId",
          "model": "TransactionsCollection",
        },
      ]
    );
    await tripsModel.populate(transactionHistory,
      [
        {
          "path": "tripId",
          "model": "tripsCollection",
          "populate": [
            {
              "path": "tripPlanId",
              "model": "tripPlanCollection",
              "populate": [
                {
                  "path": "routeId",
                  "model": "routeMapCollection",
                },
              ]
            },
            {
              "path": "vendorId",
              "model": "corporateCollection",
            },
            {
              "path": "driverId",
              "model": "driverCollection",
              "populate": [
                {
                  "path": "userId",
                  "model": "usersCollection",
                },
              ]
            },
            {
              "path": "vehicleId",
              "model": "vehicleCollection",
            },
          ]
        },
      ]
    );

    if(transactionHistory){
      return res.status(200).json({
        status: true,
        message: "Transaction history found.",
        data: transactionHistory,
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "Transaction history found.",
        data: {},
      });
    }
    
  });
}

module.exports = TransactionHistoryController;
