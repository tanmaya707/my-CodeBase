const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/errorHandler");
const RequestHandler = require("../utils/RequestHandler");
const mongoose = require("mongoose");
const ObjectId = mongoose.Types.ObjectId;
const moment = require('moment-timezone');
const dateFns = require('date-fns');

const {
  calculateDistance,
  calculateDistanceInsTentApi,
  calculateTimeInKilometers,
  getRateChartCategory,
} = require("../utils/utilities");
const {
  vehicleCategoryDetails,
  vehicleModelDetails,
  couponDetails,
} = require("../utils/common");
const {
  MSG_RECORD_STATUS_SUCCESS,
  MSG_RECORD_FETCH_SUCCESS,
} = require("../config/constants");
const requestHandler = new RequestHandler();

const couponModel = require("../models/couponModel");
const userModel = require("../models/userModel");
const corporateModel = require("../models/corporateModel");
const customerModel = require("../models/customerModel");

class CouponController extends BaseController {
  constructor() {
    super();
  }

  static couponsList = catchAsyncErrors(async (req, res, next) => {
    let totalCoupons = [];
    let coupons = [];

		let totalCount = 0;
		let totalPages= 0;
		let page = 0;
		let limit = 0;
		let skip = 0;

		// Pagination parameters ===========
		page = req.body.pageNo ? parseInt(req.body.pageNo) : 1; // Current page number
		limit = req.body.documentPerPage ? parseInt(req.body.documentPerPage) : 3; // Number of documents per page
		skip = (page - 1) * limit; // Number of documents to skip
		// Pagination parameters ===========

    const { corporateId, discountType, text } = req.body;
    if(req.method == "POST"){
        let match = {
          $or: [
            {
              couponCode: {
                $regex: ".*" + text + ".*",
                $options: "i",
              },
            },
            {
              discount: {
                $regex: ".*" + text + ".*",
                $options: "i",
              },
            },
            {
              maxDiscount: {
                $regex: ".*" + text + ".*",
                $options: "i",
              },
            },
          ],
        };
        if(corporateId){
          let corporate = await corporateModel.findOne({ _id: corporateId });
          match['corporateId'] = corporate._id
        }
        if(discountType){
          match['discountType'] = discountType
        }
        const aggregatorOpts = [
          {
            $addFields: {
              corporateId: "$corporateId",
              discountType: "$discountType",

              couponCode: "$couponCode",
              discount: "$discount",
              maxDiscount: "$maxDiscount",
            },
          },
          {
            $match: match,
          },
					{
						$sort: { createdAt: -1 } // Sort by createdAt in descending order
					},
        ];
        totalCoupons = await couponModel.aggregate(aggregatorOpts).exec();
        coupons = await couponModel.aggregate(aggregatorOpts).skip(skip).limit(limit).exec();
        await corporateModel.populate(
          coupons,
          {
            path: "corporateId",
            model: "corporateCollection",
            populate: {
              path: "userId",
              model: "usersCollection",
              populate:{
                path: "roleId",
                model: "roleCollection",
              }
            }
          }
        )
    } else {
      // ======= for dropdown ===========
      coupons = await super.getList(req, couponModel, "");
      await corporateModel.populate(
        coupons,
        {
          path: "corporateId",
          model: "corporateCollection",
          populate: {
            path: "userId",
            model: "usersCollection",
            populate:{
              path: "roleId",
              model: "roleCollection",
            }
          }
        }
      )
      // ======= for dropdown ===========
    }

		totalCount = totalCoupons.length;
    totalPages= Math.ceil(totalCount/limit);

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      // data: coupons,
      data: couponDetails(coupons),
			pagination: {
        total: totalCount,
        totalPages: totalPages,
        rowsPerPage: limit,
        currentPage: page,
        hasNextPage: page < totalPages,
        hasPrevPage: page > 1
      },
    });
  });

  static couponAddUpdate = catchAsyncErrors(async (req, res, next) => {
    const { corporateId, couponCode, couponDesc, discountType, discount, maxDiscount, effectiveFrom, expiry, _id } = req.body;

    const data = {
      couponCode: couponCode,
      couponDesc: couponDesc,
      discountType: discountType,
      discount: discount,
      maxDiscount: maxDiscount,
      effectiveFrom: effectiveFrom,
      expiry: expiry,
    };
    if(corporateId != ""){
      data.corporateId = corporateId
    }
    const updated =
      _id && _id != null && _id != ""
        ? await super.updateById(couponModel, _id.toString(), data)
        : await super.create(res, couponModel, data);

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: updated,
    });
  });

  static getCouponDetail = catchAsyncErrors(async (req, res, next) => {
    const { id } = req.body;
    const coupon = await couponModel.findOne({ _id: id });
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      // data: coupon,
      data: couponDetails(coupon),
    });
  });

  static deleteCoupon = catchAsyncErrors(async (req, res, next) => {
    const { id } = req.body;
    const updated = await super.deleteById(couponModel, id);
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: updated,
    });
  });

  static checkCoupon = catchAsyncErrors(async (req, res, next)=>{
    let { couponCode, loggedInAs } = req.body;

    // Get the current time in "Asia/Kolkata" time zone =======
    let momentKolkata = moment().tz('Asia/Kolkata');
    let currentDate = momentKolkata.format('YYYY-MM-DD');
    let currentDay = momentKolkata.format('dddd');
    let currentTime = momentKolkata.format('HH:mm');
    // Get the current time in "Asia/Kolkata" time zone =======

    let customerCorporate = await customerModel.findOne({
      userId: req.user._id,
      roleId: loggedInAs
    });
    let corporatesIdArr = [];
    if(customerCorporate?.corporates.length > 0){
      customerCorporate.corporates.forEach((corporate)=>{
        corporatesIdArr.push(corporate.corporateId.toString());
      });
    }
    let findCondition = {
      couponCode: couponCode
    }
    if(corporatesIdArr.length > 0){
      findCondition.corporateId = { $in: corporatesIdArr }
    } else {
      findCondition.corporateId = null
    }
    // console.log("findCondition ====>");
    // console.log(findCondition);
    let checkExist = await couponModel.findOne(findCondition);
    if(checkExist){
      if(new Date(currentDate) <= new Date(checkExist.expiry)){
        return res.status(200).json({
          status: true,
          message: "Success",
          data: checkExist
        });
      } else {
        return res.status(200).json({
          status: false,
          message: "Coupon Expired.",
          data: {}
        });
      }
    } else {
      return res.status(200).json({
        status: false,
        message: "Please enter a valid coupon code.",
        data: {}
      });
    }
  });
}

module.exports = CouponController;
