const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/errorHandler");
const RequestHandler = require("../utils/RequestHandler");
const mongoose = require("mongoose");
const ObjectId = mongoose.Types.ObjectId;

const {
  calculateDistance,
  calculateDistanceInsTentApi,
  calculateTimeInKilometers,
  getRateChartCategory,
} = require("../utils/utilities");
const {
  vehicleCategoryDetails,
  vehicleModelDetails,
	tripStopDetails,
	tripPlanDetails,
} = require("../utils/common");
const {
  MSG_RECORD_STATUS_SUCCESS,
  MSG_RECORD_FETCH_SUCCESS,
} = require("../config/constants");
const requestHandler = new RequestHandler();
const moment = require('moment-timezone');
const dateFns = require('date-fns');

const routeMapModel = require("../models/routeMapModel");
const corporateModel = require("../models/corporateModel");
const tripPlanModel = require("../models/tripPlanModel");
const tripStopModel = require("../models/tripStopModel");
const userModel = require("../models/userModel");

class TripPlanController extends BaseController {
  constructor() {
    super();
  }

  static tripPlanList = catchAsyncErrors(async (req, res, next) => {
    // let updateTripsAc = await tripPlanModel.updateMany(
    //   {},
    //   {
    //     $set: {
    //     //   "isAC": true,
    //     //   "isOnDemand": true,
    //     }
    //   }
    // );
    
    let totalTripPlans = [];
    let tripPlans = [];

    let totalCount = 0;
		let totalPages= 0;
		let page = 0;
		let limit = 0;
		let skip = 0;

    const { text, corporateId, routeId } = req.body;

    if (req.method == "POST") {
      // Pagination parameters ===========
      page = req.body.pageNo ? parseInt(req.body.pageNo) : 1; // Current page number
      limit = req.body.documentPerPage ? parseInt(req.body.documentPerPage) : 3; // Number of documents per page
      skip = (page - 1) * limit; // Number of documents to skip
      // Pagination parameters ===========

      let loggedUserId = req.user._id;
      let user = await userModel
        .findOne({
          _id: loggedUserId,
        })
        .populate([
          {
            path: "roleId",
            model: "roleCollection",
          },
        ]);
		
      let corporateOfLoggedUser = {};
      if (user.roleId.name != "Super Admin") {
        corporateOfLoggedUser = await corporateModel.findOne({
          userId: loggedUserId,
        });
      }
	  
      let match = {
        $and: [
          {
            $or: [
              {
                tripName: {
                  $regex: ".*" + text + ".*",
                  $options: "i",
                },
              },
            ],
          },
        ],
      };
      // if(countryCode != ''){
      // 	let country = await countryModel.findOne({ _id: countryCode });
      // 	match['countryCode'] = country._id;
      // }
      if(corporateId){
        let corporate = await corporateModel.findOne({ _id: corporateId });
        match['$and'].push({
          "corporateId": corporate?._id,
        });
      }
      if(routeId){
        let route = await routeMapModel.findOne({ _id: routeId });
        match['$and'].push({
          "routeId": route?._id,
        });
      }
      
      const aggregatorOpts = [
        {
          $addFields: {
            tripName: "$tripName",
            corporateId: "$corporateId",
          },
        },
        {
          $match: match,
        },
        {
          $sort: { createdAt: -1 } // Sort by createdAt in descending order
        },
      ];
      totalTripPlans = await tripPlanModel.aggregate(aggregatorOpts).exec();
      tripPlans = await tripPlanModel.aggregate(aggregatorOpts).skip(skip).limit(limit).exec();
      await routeMapModel.populate(tripPlans, [
        {
          path: "routeId",
          model: "routeMapCollection",
        },
        {
          path: "vendorId",
          model: "corporateCollection",
        },
        {
          path: "stops.tripStopId",
          model: "tripStopCollection",
        },
      ]);
      if (user.roleId.name != "Super Admin") {
		
				if(user.roleId.name == "Vendor"){
					let filteredTripPlansVendorWise = tripPlans.filter((tripPlan) => {
						if (
							tripPlan.vendorId &&
							tripPlan.vendorId._id.toString() == corporateOfLoggedUser._id.toString()
						) {
							return tripPlan;
						}
					});
					tripPlans = filteredTripPlansVendorWise;
					
				}

				if(user.roleId.name == "Corporate"){
					let filteredTripPlansCorporateWise = tripPlans.filter((tripPlan) => {
						if (
							tripPlan.corporateId.toString() == corporateOfLoggedUser._id.toString()
						) {
							return tripPlan;
						}
					});
					tripPlans = filteredTripPlansCorporateWise;
				}
      }
    } else {
      // ======= for dropdown ===========
      tripPlans = await super.getList(req, tripPlanModel, "");
    }

		totalCount = totalTripPlans.length;
    totalPages= Math.ceil(totalCount/limit);

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      // data: tripPlans,
      data: tripPlanDetails(tripPlans),
			pagination: {
				total: totalCount,
				totalPages: totalPages,
				rowsPerPage: limit,
				currentPage: page,
				hasNextPage: page < totalPages,
				hasPrevPage: page > 1
			},
    });
  });

  static tripPlanAddUpdate = catchAsyncErrors(async (req, res, next) => {
    let { isAC, isOnDemand2, accessibility, tripName, tripDescription, corporateId, routeId, vendorId, vehicleId, driverId, tripType, dayName, startTime, endTime, oneTimeDate, tripStopId, distance, time, _id, } = req.body;
    
    // if((tripType == "" || null || "undefined") || (startTime == "" || null || "undefined") || (endTime == "" || null || "undefined")){
    //   return res.status(422).json({
    //     status: false,
    //     message: "Trip type and trip start time & end time is required, please select one.",
    //     data: {},
    //   });
    // }
    if (!Array.isArray(dayName)) {
      dayName = [dayName];
    }
    if (!Array.isArray(startTime)) {
      startTime = [startTime];
    }
    let filteredStartTime = startTime.filter((time) => time !== "");

    if (!Array.isArray(endTime)) {
      endTime = [endTime];
    }
    let filteredendTime = endTime.filter((time) => time !== "");

    if (!Array.isArray(tripStopId)) {
      tripStopId = [tripStopId];
    }
    if (!Array.isArray(distance)) {
      distance = [distance];
    }
    if (!Array.isArray(time)) {
      time = [time];
    }
    // ====== validationFlag decides whether to submit or not =====
    let validationFlag = false;
    // ====== validationFlag decides whether to submit or not =====
    let scheduleArr = [];
    let stopsArr = [];
    if (
      filteredStartTime.length > 0 &&
      filteredendTime.length > 0 &&
      filteredStartTime.length == filteredendTime.length &&
      tripStopId.length > 0 &&
      distance.length > 0 &&
      time.length > 0 &&
      tripStopId.length == distance.length &&
      distance.length == time.length
    ) {
      validationFlag = true;

      if (tripType == "Daily") {
        for (let i = 0; i < filteredStartTime.length; i++) {
          let obj = {
            startTime: filteredStartTime[i],
            endTime: filteredendTime[i],
          };

          scheduleArr.push(obj);
        }
      } else if (tripType == "Customized") {
        for (let i = 0; i < dayName.length; i++) {
          let obj = {
            dayName: dayName[i],
            startTime: filteredStartTime[i],
            endTime: filteredendTime[i],
          };

          scheduleArr.push(obj);
        }
      } else if (tripType == "OneTime") {
        let dayNameOfOneTimeDate = moment(oneTimeDate).format("dddd");
        let obj = {
          oneTimeDate: oneTimeDate,
          dayName: dayNameOfOneTimeDate,
          startTime: filteredStartTime[0],
          endTime: filteredendTime[0],
        };

        scheduleArr.push(obj);
      }

      for (let i = 0; i < tripStopId.length; i++) {
        let obj = {
          tripStopId: tripStopId[i],
          distance: distance[i],
          time: time[i],
        };

        stopsArr.push(obj);
      }
    }

    if (validationFlag == true) {
      let data = {
        tripName: tripName,
        tripDescription: tripDescription,

        routeId: routeId,
        tripType: tripType,
        accessibility: accessibility,
        schedule: scheduleArr,
        stops: stopsArr,
        isAC: (isAC == "on")? true : false,
        isOnDemand: (isOnDemand2 == "on")? true : false,
      };
      if (corporateId) {
        data.corporateId = corporateId;
      }

      if (vendorId) {
        data.vendorId = vendorId;
      }
      
      if(vehicleId){
        data.vehicleId = vehicleId;
      }
      
      if(driverId){
        data.driverId = driverId;
      }
			
      let updated =
        _id && _id != null && _id != ""
          ? await super.updateById(tripPlanModel, _id.toString(), data)
          : await super.create(res, tripPlanModel, data);

      return requestHandler.sendSuccess(
        res,
        "Successful"
      )({
        data: updated,
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Please provide valid trip starting and ending time..!!",
        data: "",
      });
    }
  });

  static getTripPlanDetail = catchAsyncErrors(async (req, res, next) => {
    const { id } = req.body;
    const asset = await tripPlanModel.findOne({ _id: id });
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: asset,
    });
  });

  static deleteTripPlan = catchAsyncErrors(async (req, res, next) => {
    const { id } = req.body;
    const updated = await super.deleteById(tripPlanModel, id);
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: updated,
    });
  });
}

module.exports = TripPlanController;
