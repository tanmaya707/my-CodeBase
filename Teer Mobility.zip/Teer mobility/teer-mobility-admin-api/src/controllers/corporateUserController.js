const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/errorHandler");
const RequestHandler = require("../utils/RequestHandler");
const bcrypt = require("bcryptjs");
const JWTAuth = require("../utils/jwtToken");
const mongoose = require("mongoose");
const ObjectId = mongoose.Types.ObjectId;
const fileUploaderSingle = require("../utils/fileUpload").fileUploaderSingle;
const fs = require('fs');
const path = require('path');

const {
  calculateDistance,
  calculateDistanceInsTentApi,
  calculateTimeInKilometers,
  getRateChartCategory,
} = require("../utils/utilities");
const { userDetails } = require("../utils/common");
const {
  MSG_RECORD_STATUS_SUCCESS,
  MSG_RECORD_FETCH_SUCCESS,
} = require("../config/constants");
const requestHandler = new RequestHandler();

const moment = require('moment-timezone');
const dateFns = require('date-fns');

const userModel = require("../models/userModel");
const corporateUserModel = require("../models/corporateUserModel");
const rollModel = require("../models/rollModel");
const rolePermissionUserwiseModel = require("../models/rolePermissionUserwiseModel");
const driverModel = require("../models/driverModel");
const corporateModel = require("../models/corporateModel");
const vendorDriverModel = require("../models/vendorDriverModel");
const temporaryOtpModel = require("../models/temporaryOtpModel");
const savedLocationsModel = require("../models/savedLocationsModel");
const customerModel = require("../models/customerModel");
const studentModel = require("../models/studentModel");
const countryModel = require("../models/countryModel");
const userLanguageModel = require("../models/userLanguageModel");


class CorporateUserController extends BaseController {
  constructor() {
    super();
  }

  static corporateUserListWithPagination = catchAsyncErrors(async (req, res, next) => {
    // ========= check who is logged in ==========
    let loggedUser = await userModel.findOne({ _id: req.user._id }).populate(
      {
        path: "roleId",
        model: "roleCollection"
      }
    ); 
    // console.log("loggedUser =======================================================> ");
    // console.log(loggedUser.roleId.name);
    // console.log("loggedUser =======================================================> ");

    // ========= check who is logged in ==========
    let users = [];
    let { text, phoneSearch, roleId, roleOfUserType, corporateId, pageNo, documentPerPage, } = req.body;

    let totalCount = 0;
    let totalPages= 0;
    // Pagination parameters ===========
    const page = req.body.pageNo ? parseInt(req.body.pageNo) : 1; // Current page number
    const limit = req.body.documentPerPage ? parseInt(req.body.documentPerPage) : 3; // Number of documents per page
    const skip = (page - 1) * limit; // Number of documents to skip
    // Pagination parameters ===========

    if(roleId == undefined){
      roleId = roleOfUserType
    }
    const super_admin = await rollModel.findOne({ name: "Super Admin" });
    let match = {
      roleId: {
        $ne: super_admin._id,
      },
      $and: [
        {
          $or: [
            {
              nameFilter: {
                $regex: ".*" + text + ".*",
                $options: "i",
              },
            },
            {
              email: {
                $regex: ".*" + text + ".*",
                $options: "i",
              },
            },
          ],
        },
      ],
    };
    if (roleId != "") {
      const role = await rollModel.findOne({ _id: roleId });
      match["roleId"] = role._id;
    }
    if (phoneSearch) {
      match["phone"] = parseInt(phoneSearch); 
    }
    const aggregatorOpts = [
      {
        $addFields: {
          nameFilter: {
            $concat: ["$firstName", " ", "$lastName"],
          },
          phone: "$phone",
          email: "$email",
          roleId: "$roleId",
        },
      },
      {
        $match: match,
      },
    ];
    // const users = await userModel.find({ isDeleted: { $ne: true } }).populate("roleId");
    // let totalUsers = await userModel.aggregate(aggregatorOpts).exec();
    // users = await userModel.aggregate(aggregatorOpts).skip(skip).limit(limit).exec();
    users = await userModel.aggregate(aggregatorOpts).exec();
    await rollModel.populate(users, { path: "roleId" });
    
    let filteredUsers = [];
    let mappedFilteredUsers = [];
    
    mappedFilteredUsers = await Promise.all(
      users.map(async (user) => {
        // let employeeRole = await rollModel.findOne({name: "Employee"});
        let corporateUser = await corporateUserModel.findOne({
          userId: user?._id,
        }).populate([
          {
            "path": "corporateId",
            "model": "corporateCollection",
          }
        ]);

        if(corporateUser){
          let corporateObj = {
            corporateId: corporateUser?.corporateId?._id,
            corporateName: corporateUser?.corporateId?.name,
          };
          user.corporateDetails = corporateObj;
        } else {
          let corporateObj = {
            corporateId: null,
            corporateName: null,
          };
          user.corporateDetails = corporateObj;
        }
        return user;
      })
    );

    let searchedUsers = [];
    searchedUsers = await Promise.all(
      users.map(async (user) => {
        // custom filters =========
        if (corporateId && corporateId != "" && corporateId != null) {
          if (user.corporateDetails.corporateId && (user.corporateDetails.corporateId.toString() === corporateId.toString())) {
            return user;
          } else {
            return null;
          }
        } else {
          return user;
        }
      })
    );

    // Filter out null values
    searchedUsers = searchedUsers.filter(user => user !== null);

    users = searchedUsers;

    let userIdsAfterSearch = [];
    users.forEach(async (user) => {
      userIdsAfterSearch.push(user?._id);
    });

    let totalUsers = await userModel.find({
      _id: {
        $in: userIdsAfterSearch,
      }
    });
    users = await userModel.find({
      _id: {
        $in: userIdsAfterSearch,
      }
    }).lean().skip(skip).limit(limit).exec();
    await rollModel.populate(users, [
      { 
        path: "roleId",
        model: "roleCollection"
      }
    ]);

    if(roleOfUserType){
      // ========== filters user according to role (user-type) ==========
      filteredUsers = users.filter((user) => {
        if (user?.roleId?._id.toString() === roleOfUserType) {
          return user;
        }
      });
      // ========== filters user according to role (user-type) ==========
      
      // ========== filters user according to user-id ==========
      let super_admin = await rollModel.findOne({ name: "Super Admin" });
      let superUser = await userModel.findOne({ roleId: super_admin?._id.toString() });

      let admin_userRole = await rollModel.findOne({ name: "Admin User" });
      let adminUser = await userModel.findOne({ roleId: admin_userRole?._id.toString() });

      if(
        // superadmin using =======
        (superUser?._id.toString() == req.user._id)
        // adminUser using =======
        || (adminUser?._id.toString() == req.user._id)
      ){
        // superadmin or adminUser using =======
        mappedFilteredUsers = users

        // if user is student add studentClass and studentSection and parentPhone and parentName with listing data ==== not complete ====
        // mappedFilteredUsers.forEach(async (user)=>{
        //   if(user.roleId.name == "Student"){
        //     let studentUsersWithDetails = mappedFilteredUsers.map((user)=>{
        //       studentsOfSchool.forEach((student)=>{
        //         if(student.userId.toString() == user._id.toString()){
        //           user['studentClass'] = student.studentClass;
        //           user['studentSection'] = student.studentSection;
        //         }
        //       });

        //       return user;
        //     });
        //   }
        // });
      } 
      // else if(adminUser._id.toString() == req.user._id){
      //   // adminUser using =======
      //   mappedFilteredUsers = users
      // }
      else {
        // other user =========
        if(loggedUser?.roleId?.name == "Vendor"){
          let loggedCorporate = await corporateModel.findOne({
            userId: req.user._id
          });
          let vendorDriverMapping = await vendorDriverModel.find({
            vendorId: loggedCorporate?._id
          }).populate(
            {
              path: "driverId",
              model: "driverCollection",
              populate: {
                path: "userId",
                model: "usersCollection",
              }
            }
          );
          let mappedDriverIdArr = [];
          vendorDriverMapping.forEach((mappedDriver)=>{
            mappedDriverIdArr.push(mappedDriver?.driverId?.userId?._id.toString())
          })
          mappedFilteredUsers = filteredUsers.filter((user) => {
            if(mappedDriverIdArr.includes(user?._id.toString())){
              return user;
            }
          });
        } else if(loggedUser?.roleId?.name == "Corporate"){
          let loggedCorporate = await corporateModel.findOne({
            userId: req.user._id
          });
          // let corporateUserMapping = await corporateUserModel.find({
          //   corporateId: loggedCorporate._id
          // }).populate(
          //   {
          //     path: "userId",
          //     model: "usersCollection",
          //   }
          // );
          // let mappedCorporateUserIdArr = [];
          // mappedFilteredUsers = filteredUsers.filter((user) => {
          //   if(mappedCorporateUserIdArr.includes(user._id.toString())){
          //     return user;
          //   }
          // });
          let customerEmployeesOfCorporate = await customerModel.find({
            "roleId": roleId,
            "corporates": {
              $elemMatch: {
                "corporateId": loggedCorporate?._id,
              }
            }
          });
          let mappedEmployeesUserIdOfCorporateArr = [];
          customerEmployeesOfCorporate.forEach((employee)=>{
            mappedEmployeesUserIdOfCorporateArr.push(employee?.userId.toString());
          });
          mappedFilteredUsers = filteredUsers.filter((user)=>{
            if(mappedEmployeesUserIdOfCorporateArr.includes(user?._id.toString())){
              return user;
            }
          });
        } else if(loggedUser?.roleId?.name == "School"){
          let loggedCorporate = await corporateModel.findOne({
            userId: req.user._id
          });
          let studentsOfSchool = await studentModel.find({
            schoolId: loggedCorporate?._id,

            isActive: true,
            isDeleted: false,
          });
          let studentUserIdOfSchoolArr = [];
          studentsOfSchool.forEach((student)=>{
            studentUserIdOfSchoolArr.push(student?.userId.toString());
          });
          mappedFilteredUsers = filteredUsers.filter((user)=>{
            if(studentUserIdOfSchoolArr.includes(user?._id.toString())){
              return user;
            }
          });
          let studentUsersWithDetails = mappedFilteredUsers.map((user)=>{
            studentsOfSchool.forEach((student)=>{
              if(student?.userId.toString() == user?._id.toString()){
                user['studentClass'] = student.studentClass;
                user['studentSection'] = student.studentSection;
              }
            });

            return user;
          });

          mappedFilteredUsers = studentUsersWithDetails;
        }
      }

      filteredUsers = mappedFilteredUsers
      // ========== filters user according to user-id ==========

    } else {
      filteredUsers = users
    }

    // filteredUsers.forEach(async (user)=>{
    //   if(user.roleId.name == "Driver"){
    //     let driver = await driverModel.findOne({
    //       userId: user._id
    //     });
        
    //     user.employeeId = driver.employeeId;
    //   }
    //   if(user.roleId.name == "Student"){
    //     let studentProfile = await studentModel.findOne({
    //       userId: user._id,
    //     });
    //     if(studentProfile){
    //       let parentProfile = await userModel.findOne({
    //         _id: studentProfile.parentUserId,
    //       });
  
    //       user.corporateId = studentProfile.schoolId;
    //       user.parentName = parentProfile.firstName + " " + parentProfile.lastName;
    //       user.parentPhone = parentProfile.phone;
    //       user.routeId = studentProfile.routeId;
  
    //       user.studentClass = studentProfile.studentClass;
    //       user.studentSection = studentProfile.studentSection;
    //     }
    //   }
    // });

    let rolePermissionsUserWise = [];
    rolePermissionsUserWise = await rolePermissionUserwiseModel.find({
      isActive: true,
      isDeleted: false,
    });

    totalCount = totalUsers.length;
    totalPages= Math.ceil(totalCount/limit);

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: userDetails(filteredUsers, rolePermissionsUserWise),
      pagination: {
        total: totalCount,
        totalPages: totalPages,
        rowsPerPage: limit,
        currentPage: page,
        hasNextPage: page < totalPages,
        hasPrevPage: page > 1
      },
    });
  });
}

module.exports = CorporateUserController;
