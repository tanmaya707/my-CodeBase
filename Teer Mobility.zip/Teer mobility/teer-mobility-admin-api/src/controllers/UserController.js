const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/errorHandler");
const RequestHandler = require("../utils/RequestHandler");
const bcrypt = require("bcryptjs");
const JWTAuth = require("../utils/jwtToken");
const mongoose = require("mongoose");
const ObjectId = mongoose.Types.ObjectId;
const fileUploaderSingle = require("../utils/fileUpload").fileUploaderSingle;
const fs = require('fs');
const path = require('path');

const {
  calculateDistance,
  calculateDistanceInsTentApi,
  calculateTimeInKilometers,
  getRateChartCategory,
} = require("../utils/utilities");
const { userDetails } = require("../utils/common");
const {
  MSG_RECORD_STATUS_SUCCESS,
  MSG_RECORD_FETCH_SUCCESS,
} = require("../config/constants");
const requestHandler = new RequestHandler();

const moment = require('moment-timezone');
const dateFns = require('date-fns');

const userModel = require("../models/userModel");
const corporateUserModel = require("../models/corporateUserModel");
const rollModel = require("../models/rollModel");
const rolePermissionUserwiseModel = require("../models/rolePermissionUserwiseModel");
const driverModel = require("../models/driverModel");
const corporateModel = require("../models/corporateModel");
const vendorDriverModel = require("../models/vendorDriverModel");
const temporaryOtpModel = require("../models/temporaryOtpModel");
const savedLocationsModel = require("../models/savedLocationsModel");
const customerModel = require("../models/customerModel");
const studentModel = require("../models/studentModel");
const countryModel = require("../models/countryModel");
const userLanguageModel = require("../models/userLanguageModel");


class UserController extends BaseController {
  constructor() {
    super();
  }

  static userList = catchAsyncErrors(async (req, res, next) => {
    // ========= check who is logged in ==========
    let loggedUser = await userModel.findOne({ _id: req.user._id }).populate(
      {
        path: "roleId",
        model: "roleCollection"
      }
    ); 
    // console.log("loggedUser =======================================================> ");
    // console.log(loggedUser.roleId.name);
    // console.log("loggedUser =======================================================> ");

    // ========= check who is logged in ==========
    let users = []
    if(req.method == "POST"){
      let { text, phoneSearch, roleId, roleOfUserType, corporateId, pageNo, documentPerPage, } = req.body;

      let totalCount = 0;
      let totalPages= 0;
      // Pagination parameters ===========
      const page = req.body.pageNo ? parseInt(req.body.pageNo) : 1; // Current page number
      const limit = req.body.documentPerPage ? parseInt(req.body.documentPerPage) : 3; // Number of documents per page
      const skip = (page - 1) * limit; // Number of documents to skip
      // Pagination parameters ===========

      if(roleId == undefined){
        roleId = roleOfUserType
      }
      const super_admin = await rollModel.findOne({ name: "Super Admin" });
      let match = {
        roleId: {
          $ne: super_admin._id,
        },
        $and: [
          {
            $or: [
              {
                nameFilter: {
                  $regex: ".*" + text + ".*",
                  $options: "i",
                },
              },
              {
                email: {
                  $regex: ".*" + text + ".*",
                  $options: "i",
                },
              },
            ],
          },
        ],
      };
      if (roleId != "") {
        const role = await rollModel.findOne({ _id: roleId });
        match["roleId"] = role._id;
      }
      if (phoneSearch) {
        match["phone"] = parseInt(phoneSearch); 
      }
      const aggregatorOpts = [
        {
          $addFields: {
            nameFilter: {
              $concat: ["$firstName", " ", "$lastName"],
            },
            phone: "$phone",
            email: "$email",
            roleId: "$roleId",
          },
        },
        {
          $match: match,
        },
      ];
      // const users = await userModel.find({ isDeleted: { $ne: true } }).populate("roleId");
      let totalUsers = await userModel.aggregate(aggregatorOpts).exec();
      users = await userModel.aggregate(aggregatorOpts).skip(skip).limit(limit).exec();
      await rollModel.populate(users, { path: "roleId" });
      
      let filteredUsers = []
      let mappedFilteredUsers = []
      
      mappedFilteredUsers = await Promise.all(
        users.map(async (user) => {
          let employeeRole = await rollModel.findOne({name: "Employee"});
          let employeeUser = await customerModel.findOne({
            userId: user?._id,
            roleId: employeeRole?._id,
          });

          if(employeeUser){
            let corporateOfUser = await corporateModel.findOne({
              _id: employeeUser?.corporates[0]?.corporateId,
            });

            let corporateObj = {
              corporateId: corporateOfUser?._id,
              corporateName: corporateOfUser?.name,
            };
            user.corporateDetails = corporateObj;
          } else {
            let corporateObj = {
              corporateId: null,
              corporateName: null,
            };
            user.corporateDetails = corporateObj;
          }
          return user;
        })
      );

      let searchedUsers = [];
      searchedUsers = await Promise.all(
        users.map(async (user) => {
          // custom filters =========
          if (corporateId && corporateId != "" && corporateId != null) {
            if (user.corporateDetails.corporateId && (user.corporateDetails.corporateId.toString() === corporateId.toString())) {
              return user;
            } else {
              return null;
            }
          } else {
            return user;
          }
        })
      );

      // Filter out null values
      searchedUsers = searchedUsers.filter(user => user !== null);

      users = searchedUsers;

      if(roleOfUserType){
        // ========== filters user according to role (user-type) ==========
        filteredUsers = users.filter((user) => {
          if (user?.roleId?._id.toString() === roleOfUserType) {
            return user;
          }
        });
        // ========== filters user according to role (user-type) ==========
        
        // ========== filters user according to user-id ==========
        let super_admin = await rollModel.findOne({ name: "Super Admin" });
        let superUser = await userModel.findOne({ roleId: super_admin?._id.toString() });

        let admin_userRole = await rollModel.findOne({ name: "Admin User" });
        let adminUser = await userModel.findOne({ roleId: admin_userRole?._id.toString() });

        if(
          // superadmin using =======
          (superUser?._id.toString() == req.user._id)
          // adminUser using =======
          || (adminUser?._id.toString() == req.user._id)
        ){
          // superadmin or adminUser using =======
          mappedFilteredUsers = users
        } 
        else {
          // other user =========
          if(loggedUser?.roleId?.name == "Vendor"){
            let loggedCorporate = await corporateModel.findOne({
              userId: req.user._id
            });
            let vendorDriverMapping = await vendorDriverModel.find({
              vendorId: loggedCorporate?._id
            }).populate(
              {
                path: "driverId",
                model: "driverCollection",
                populate: {
                  path: "userId",
                  model: "usersCollection",
                }
              }
            );
            let mappedDriverIdArr = [];
            vendorDriverMapping.forEach((mappedDriver)=>{
              mappedDriverIdArr.push(mappedDriver?.driverId?.userId?._id.toString())
            })
            mappedFilteredUsers = filteredUsers.filter((user) => {
              if(mappedDriverIdArr.includes(user?._id.toString())){
                return user;
              }
            });
          } else if(loggedUser?.roleId?.name == "Corporate"){
            let loggedCorporate = await corporateModel.findOne({
              userId: req.user._id
            });
            let customerEmployeesOfCorporate = await customerModel.find({
              "roleId": roleId,
              "corporates": {
                $elemMatch: {
                  "corporateId": loggedCorporate?._id,
                }
              }
            });
            let mappedEmployeesUserIdOfCorporateArr = [];
            customerEmployeesOfCorporate.forEach((employee)=>{
              mappedEmployeesUserIdOfCorporateArr.push(employee?.userId.toString());
            });
            mappedFilteredUsers = filteredUsers.filter((user)=>{
              if(mappedEmployeesUserIdOfCorporateArr.includes(user?._id.toString())){
                return user;
              }
            });
          } else if(loggedUser?.roleId?.name == "School"){
            let loggedCorporate = await corporateModel.findOne({
              userId: req.user._id
            });
            let studentsOfSchool = await studentModel.find({
              schoolId: loggedCorporate?._id,

              isActive: true,
              isDeleted: false,
            });
            let studentUserIdOfSchoolArr = [];
            studentsOfSchool.forEach((student)=>{
              studentUserIdOfSchoolArr.push(student?.userId.toString());
            });
            mappedFilteredUsers = filteredUsers.filter((user)=>{
              if(studentUserIdOfSchoolArr.includes(user?._id.toString())){
                return user;
              }
            });
            let studentUsersWithDetails = mappedFilteredUsers.map((user)=>{
              studentsOfSchool.forEach((student)=>{
                if(student?.userId.toString() == user?._id.toString()){
                  user['studentClass'] = student.studentClass;
                  user['studentSection'] = student.studentSection;
                }
              });

              return user;
            });

            mappedFilteredUsers = studentUsersWithDetails;
          }
        }

        filteredUsers = mappedFilteredUsers
        // ========== filters user according to user-id ==========

      } else {
        filteredUsers = users
      }

      let rolePermissionsUserWise = [];
      rolePermissionsUserWise = await rolePermissionUserwiseModel.find({
        isActive: true,
        isDeleted: false,
      });

      totalCount = totalUsers.length;
      totalPages= Math.ceil(totalCount/limit);

      return requestHandler.sendSuccess(
        res,
        "Successful"
      )({
        data: userDetails(filteredUsers, rolePermissionsUserWise),
        pagination: {
          total: totalCount,
          totalPages: totalPages,
          rowsPerPage: limit,
          currentPage: page,
          hasNextPage: page < totalPages,
          hasPrevPage: page > 1
        },
      });

    } else{
      users = await userModel.find({ isActive: true, isDeleted: false });
      
      return requestHandler.sendSuccess(
        res,
        "Successful"
      )({
        data: users,
      });
    }
  });

  static userUpdate = catchAsyncErrors(async (req, res, next) => {
    let { firstName, lastName, email, phone, gender, password, roleId,  zipcode, city, state, dialcode, latitude, longitude, address, moduleId, roleOfUserType, parentPhone, routeId, studentClass, studentSection, corporateId, userType, frsImage, _id, } = req.body;
    
    let updated = [];
    // ========= check who is logged in ==========
    let loggedUser = await userModel.findOne({ _id: req.user._id }).populate(
      {
        path: "roleId",
        model: "roleCollection"
      }
    ); 
    // console.log("loggedUser =======================================================> ");
    // console.log(loggedUser.roleId.name);
    // console.log("loggedUser =======================================================> "); 
    if(!roleId){
      roleId = loggedUser.roleId._id.toString()
    }
    // ========= check who is logged in ==========

    const role = await rollModel.findOne({ _id: roleId });
    // =========== single file upload ================
    let fileName = "";
    
    if(req.files.profileImage){
        let image = await fileUploaderSingle("./src/public/uploads/userImages/", req.files.profileImage);
        fileName = image.newfileName;
    }
    // if(frsImage){
    //   const base64Image = frsImage.replace(/^data:image\/jpeg;base64,/, '');
    //   const filename = `face_${Date.now()}.jpeg`;
    //   console.log("__dirname ==>");
    //   console.log(__dirname);
    //   const imagePath = path.join(__dirname, '../../public/uploads/frsImages', filename);
    //   console.log("imagePath =>");
    //   console.log(imagePath);
    //   fs.writeFile(imagePath, base64Image, 'base64', (err) => {
    //       if (err) {
    //           console.error('Error saving image: ', err);
    //           res.status(500).json({
    //             status: false,
    //             message: "Error saving FRS image.",
    //             data: {}
    //           });
    //       } else {
    //           console.log('Image saved successfully');
    //           // res.status(200).send('Image saved successfully');
    //       }
    //   });
    // }
    // =========== single file upload ================
    let data = {
      firstName: firstName,
      lastName: lastName,
      email: email,
      // dialcode: (dialcode && (dialcode != '') && (dialcode != null))?dialcode:null,
      // phone: (phone && (phone != '') && (phone != null))?phone:null,
      dialcode: dialcode,
      phone: phone,
      gender: gender,
      password: password,
      location: {
        type: "Point",
        coordinates: [latitude, longitude],
      },
      address: address,
      dob: "",
      zipcode: zipcode,
      city: city,
      state: state,
      roleId: role._id.toString(),
    };
    
    if(fileName != ''){
      data.profileImage = fileName
    }
    let findUser = await userModel.findOne({
      phone: phone
    });

    updated =
      _id && _id != null && _id != ""
        ? await super.updateById(userModel, _id.toString(), data)
        : (!findUser)? await super.create(res, userModel, data) : (updated = findUser);
        
    let driver = [];
    if(role.name == "Driver"){
      let driverData = {
        userId: updated._id
      }
      driver = 
        _id && _id != null && _id != ""
          ? ""
          : await super.create(res, driverModel, driverData)
    } else if(role.name == "Customer") {
      let customerData = {
        userId: updated._id,
        roleId: roleId,
        // corporates: corporatesArr
      };
      let customer = 
        _id && _id != null && _id != ""
            ? ""
            : await super.create(res, customerModel, customerData);
    }

    if(loggedUser.roleId.name == "Vendor"){
      let corprateIdOfVendor = await corporateModel.findOne({ userId: req.user._id });
      let data = {
        vendorId: corprateIdOfVendor._id,
        driverId: driver._id
      };
      let mapped =
        _id && _id != null && _id != ""
          ? ""
          : await super.create(res, vendorDriverModel, data);

      if(mapped){
        console.log("driver mapped to vendor.");
      } else {
        console.log("Mapping not affected.");
      }
    } else if(loggedUser.roleId.name == "Corporate"){
      let corprate = await corporateModel.findOne({ userId: req.user._id });
      let data = {
        userId: updated._id,
        corporateId: corprate._id,
      };
      let mapped =
        _id && _id != null && _id != ""
          ? await super.updateByCustomOptions(
              corporateUserModel, 
              {
                userId: updated._id,
              },
              {
                corporateId: corprate._id,
              },
            )
          : await super.create(res, corporateUserModel, data);

      if(mapped){
        console.log("User mapped to corporate.");
      } else {
        console.log("Corporate user mapping not affected.");
      }

      if(corporateId & userType){
        // ========== if employee/student creation is happening ========
        // ========== "userType" present in req.body =========
        let customerUserType = await rollModel.findOne({
          _id: userType,
        });
        if(customerUserType.name == "Employee"){
          let corporatesArr = [];
          let corporateObj = {
            corporateId: corporateId,
          };
          corporatesArr.push(corporateObj);
  
          let customerData = {
            userId: updated._id,
            roleId: userType,
            corporates: corporatesArr
          };
          
          let checkEmployeeExist = await customerModel.findOne({
            userId: updated._id,
            roleId: userType,
          });
          
          let customer = 
            _id && _id != null && _id != ""
                ? await super.updateByCustomOptions(
                    customerModel, 
                    {
                      userId: updated._id,
                      roleId: userType,
                    },
                    customerData
                  )
                : await super.create(res, customerModel, customerData);
          
          let updateUserRole = await super.updateById(userModel, updated._id, {
            roleId: userType,
          });
          
          if(customer){
            console.log("Employee-Customer created.");
          } else {
            console.log("Employee-Customer mapping not affected.");
          }
        } else if(customerUserType.name == "Student"){
          let corporateObj = {};
          let findParent = await userModel.findOne({
            phone: parentPhone
          });
          let studentData = {
            userId: updated._id,
            schoolId: corporateId,
            parentUserId: findParent._id,
            routeId: routeId,
            studentClass: studentClass,
            studentSection: studentSection,
          };
          let student = 
						_id && _id != null && _id != ""
						? await super.updateByCustomOptions(
							studentModel, 
							{
								userId: updated._id,
							},
							{
								schoolId: corporateId,
							}
						)
						: await super.create(res, studentModel, studentData);

          let corporatesArr = [];
          let checkExist = await customerModel.findOne({
            userId: findParent._id,
            roleId: userType,
          });
          if(checkExist){
            // parent-student mapping FOUND =======
            corporatesArr = checkExist.corporates

						if(_id && _id != null && _id != ""){
							// if edit happening ====
							let newCorporatesArr = [];
							checkExist?.corporates.forEach((corporate)=>{
								if(corporate?.studentId.toString() == updated._id.toString()){
									corporateObj = {
										corporateId: corporateId,
										studentId: updated._id,
									};
									newCorporatesArr.push(corporateObj);
								} else {
									corporateObj = {
										corporateId: corporate?.corporateId,
										studentId: corporate?.studentId,
									};
									newCorporatesArr.push(corporateObj);
								}
							});

							corporatesArr = newCorporatesArr;

						} else {
							// add happening ====
							corporateObj = {
								corporateId: corporateId,
								studentId: updated._id,
							};
							corporatesArr.push(corporateObj);
						}

          } else {
            // parent-student mapping NOT FOUND =======
            corporateObj = {
              corporateId: corporateId,
              studentId: updated._id,
            };
            corporatesArr.push(corporateObj);
          }
  
          let customerData = {
            userId: findParent._id,
            roleId: userType,
            corporates: corporatesArr
          };
          let customer = 
            _id && _id != null && _id != ""
              ? await super.updateById(customerModel, checkExist._id.toString(), customerData)
              : (checkExist && checkExist._id != null && checkExist._id != "")
							? await super.updateById(customerModel, checkExist._id.toString(), customerData)
							: await super.create(res, customerModel, customerData);
  
          if(customer){
            console.log("Student mapping in customerCollection created/updated.1");
          } 
          
        }
      }
    } else if(loggedUser.roleId.name == "Company"){
      
    } else if(
      loggedUser.roleId.name == "Super Admin" &&
      corporateId
    ){
      if(
        // ====== "userType" will be available only if it is an employee/student ========
        // ====== corporateUser entry happening ========
        !userType
      ){
        let data = {
          userId: updated._id,
          corporateId: corporateId,
        };
        
        let mapped =
          _id && _id != null && _id != ""
            ? await super.updateByCustomOptions(
                corporateUserModel, 
                {
                  userId: updated._id,
                },
                {
                  corporateId: corporateId,
                },
              )
            : await super.create(res, corporateUserModel, data);
        
        if(mapped){
          console.log("User mapped to corporate. 2");
        } else {
          console.log("Corporate user Mapping not affected. 2");
        }
      } else {
        // ========== if employee/student creation is happening ========
        // ========== "userType" present in req.body =========
        let customerUserType = await rollModel.findOne({
          _id: userType,
        });
        if(customerUserType.name == "Employee"){
          let corporatesArr = [];
          let corporateObj = {
            corporateId: corporateId,
          };
          corporatesArr.push(corporateObj);
  
          let customerData = {
            userId: updated._id,
            roleId: userType,
            corporates: corporatesArr
          };
          // let checkEmployeeExist = await customerModel.findOne({
          //   userId: updated._id,
          //   roleId: userType,
          // });
					// console.log("checkEmployeeExist ======================>");
					// console.log(checkEmployeeExist);
					
          let customer = [];
					customer = 
					_id && _id != null && _id != ""
							? await super.updateByCustomOptions(
									customerModel, 
									{
										userId: updated._id,
										roleId: userType,
									},
									customerData
								)
							: await super.create(res, customerModel, customerData);

					let updateUserRole = await super.updateById(userModel, updated._id, {
						roleId: userType,
					});
          
          if(customer){
            console.log("Employee-Customer created/updated.");
          } else {
            console.log("Employee-Customer mapping not affected.");
          }
        } else if(customerUserType.name == "Student"){
          let corporateObj = {};
          let findParent = await userModel.findOne({
            phone: parentPhone
          });
          let studentData = {
            userId: updated._id,
            schoolId: corporateId,
            parentUserId: findParent._id,
            routeId: routeId,
            studentClass: studentClass,
            studentSection: studentSection,
          };

          let student = 
						_id && _id != null && _id != ""
						? await super.updateByCustomOptions(
							studentModel, 
							{
								userId: updated._id,
							},
							{
								schoolId: corporateId,
							}
						)
						: await super.create(res, studentModel, studentData);

          let corporatesArr = [];
          let checkExist = await customerModel.findOne({
            userId: findParent._id,
            roleId: userType,
          });
					
          if(checkExist){
            // parent-student mapping FOUND =======
            corporatesArr = checkExist.corporates

						if(_id && _id != null && _id != ""){
							// if edit happening ====
							let newCorporatesArr = [];
							checkExist?.corporates.forEach((corporate)=>{
								if(corporate?.studentId.toString() == updated._id.toString()){
									corporateObj = {
										corporateId: corporateId,
										studentId: updated._id,
									};
									newCorporatesArr.push(corporateObj);
								} else {
									corporateObj = {
										corporateId: corporate?.corporateId,
										studentId: corporate?.studentId,
									};
									newCorporatesArr.push(corporateObj);
								}
							});

							corporatesArr = newCorporatesArr;

						} else {
							// add happening ====
							corporateObj = {
								corporateId: corporateId,
								studentId: updated._id,
							};
							corporatesArr.push(corporateObj);
						}

          } else {
            // parent-student mapping NOT FOUND =======
            corporateObj = {
              corporateId: corporateId,
              studentId: updated._id,
            };
            corporatesArr.push(corporateObj);
          }
  
          let customerData = {
            userId: findParent._id,
            roleId: userType,
            corporates: corporatesArr
          };
          let customer = 
            _id && _id != null && _id != ""
              ? await super.updateById(customerModel, checkExist._id.toString(), customerData)
              : (checkExist && checkExist._id != null && checkExist._id != "")
									? await super.updateById(customerModel, checkExist._id.toString(), customerData)
									: await super.create(res, customerModel, customerData);
  
          if(customer){
            console.log("Student mapping in customerCollection created/updated.2");
          } 
          
        }
      }
    }

    let userWisePermissionProfile = [];
    if(updated?._id != undefined){
      let permissionObj = {
        userId: updated._id.toString(),
        moduleId: moduleId,

        updatedBy: req.user._id,
      };
      
      userWisePermissionProfile = 
        _id && _id != null && _id != ""
        ? await super.updateByCustomOptions(
            rolePermissionUserwiseModel, 
            {
              userId: updated._id,
            },
            permissionObj
          )
        : await super.create(res, rolePermissionUserwiseModel, permissionObj);

      if(userWisePermissionProfile){
        return requestHandler.sendSuccess(
          res,
          "Successful. Permissions updated."
        )({
          data: updated,
        });
      }
    }
  });
  static getUser = catchAsyncErrors(async (req, res, next) => {
    let { id } = req.body;
    if(!id){
      id = req.user._id;
    }
    let user = await userModel.findOne({ _id: id }).populate("roleId").lean();
    // console.log("user ===>");
    // console.log(user);
    
    let match = {
      isActive: true, 
      isDeleted: false,
      $and: [
        {
          $or: [
            {
              phone_code: {
                $regex: ".*" + user.dialcode + ".*",
                $options: "i",
              },
            },
          ],
        },
      ],
    };
    const aggregatorOpts = [
      {
        $addFields: {
          isActive: "$isActive",
          isDeleted: "$isDeleted",
          phone_code: "$phone_code",
        },
      },
      {
        $match: match,
      },
    ];
    let country = await countryModel.aggregate(aggregatorOpts).exec();
    user.countryCode = country[0]?._id.toString();
    
    let userLanguage = await userLanguageModel.findOne({
      userId: id,
    });
    user.userLanguage = userLanguage?.language;

    if(user.roleId.name == "Driver"){
      let driver = await driverModel.findOne({
        userId: user._id
      });
      
      user.employeeId = driver.employeeId;
    }
    if(user.roleId.name == "Student"){
      let studentProfile = await studentModel.findOne({
        userId: user._id,
      });
      if(studentProfile){
        let parentProfile = await userModel.findOne({
          _id: studentProfile.parentUserId,
        });

        user.corporateId = studentProfile.schoolId;
        user.parentName = parentProfile.firstName + " " +parentProfile.lastName;
        user.parentPhone = parentProfile.phone;
        user.ParentAdress = parentProfile.address;
        user.ParentEmail = parentProfile.email;
        user.routeId = studentProfile.routeId;

        user.studentClass = studentProfile.studentClass;
        user.studentSection = studentProfile.studentSection;
      }
    }
		if(user.roleId.name == "Employee"){
      let employeeCustomerProfile = await customerModel.findOne({
        userId: user._id,
				roleId: user.roleId._id,
      });
      
			if(employeeCustomerProfile){
        user.corporateId = employeeCustomerProfile?.corporates[0]?.corporateId;
      }
    }
    if(user.roleId.name == "Corporate User"){
      let corporateUserProfile = await corporateUserModel.findOne({
        userId: user._id,
      });
      
			if(corporateUserProfile){
        user.corporateId = corporateUserProfile?.corporateId;
      }
    }
    
    let rolePermissionsUserWise = await rolePermissionUserwiseModel.findOne({
      userId: user._id,
    });
    
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: userDetails(user, rolePermissionsUserWise),
    });
  });

  static deleteUser = catchAsyncErrors(async (req, res, next) => {
    const { id } = req.body;
    let userDetails = await userModel.findOne({
      _id: id,
    });
    let roleOfUser = await rollModel.findOne({
      _id: userDetails.roleId,
    });
    
    if(roleOfUser.name == "Super Admin"){
      return res.status(403).json({
        status: false,
        message: "You can not delete Super Admin.",
        data: {}
      });
    } else if(roleOfUser.name == "Driver"){
      
      let driver = await driverModel.findOne({
        userId: id,
      });
      
      let checkVendorDriverMappingExist = await vendorDriverModel.find({
        driverId: driver._id,
      });
      
      if(checkVendorDriverMappingExist){
        checkVendorDriverMappingExist.forEach(async (mapping)=>{
          let vendorDriverMappingDelete = await super.deleteById(vendorDriverModel, mapping._id);
        });
      }

      let driverDelete = await super.deleteById(driverModel, driver._id);

    } else if(
      (roleOfUser.name == "Corporate")
      || (roleOfUser.name == "Vendor")
      || (roleOfUser.name == "School")
    ){
      let corporate = await corporateModel.findOne({
        userId: id
      });
      return res.status(422).json({
        status: false,
        message: "You can not delete a corporate/vendor/school from this page. If you delete this corporate from here, all the users associated with it will be missing their mapping with this organization.",
        data: {}
      });
    } else if(roleOfUser.name == "Student") {
      let student = await studentModel.findOne({
        userId: id,
      });
      let studentRole = rollModel.findOne({
        name: "Student"
      });
      let parentOfStudentFind = await customerModel.findOne({
        roleId: studentRole._id,
        "corporates": {
          $elemMatch: {
            "studentId": student.userId,
          }
        }
      });
      if(parentOfStudentFind){
        let corporateIdToDelete = "";
        parentOfStudentFind.corporates.forEach((school)=>{
          if(school.studentId == student.userId){
            corporateIdToDelete = school._id
          }
        });

        let studentCustomerDelete = await customerModel.updateOne(
          {
            _id: parentOfStudentFind._id,
          },
          { 
            $pull: { 
              corporates: { _id: corporateIdToDelete } // Match the specific object by its _id
            } 
          }
        );
        if(!studentCustomerDelete){
          return res.status(400).json({
            status: false,
            message: "Something wrong happened while deleting student.",
            data: {},
          })
        } else {
          let deleteStudent = await super.deleteById(studentModel, student._id);
        }
      }
    } else if(roleOfUser.name == "Employee"){
      let employeeRole = rollModel.findOne({
        name: "Employee"
      });
      let employeeCustomerFind = await customerModel.findOne({
        userId: id,
        roleId: employeeRole._id,
      });
      let employeeCustomerDelete = await super.deleteById(customerModel, employeeCustomerFind._id);

      if(!employeeCustomerDelete){
        return res.status(400).json({
          status: false,
          message: "Something wrong happened while deleting employee.",
          data: {}
        });
      }
    }

    const updated = await super.deleteById(userModel, id);

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: updated,
    });
  });

  // ===========================================================================
  // ================================ APP APIs ================================
  static sendOtp = catchAsyncErrors(async (req, res, next)=>{
    let { firstName, lastName, email, phone, } = req.body;

    // Generate a random 4-digit number ==========
    let otp = Math.floor(1000 + Math.random() * 9000);

    let options = {
      $or: [
        {
          phone: phone,
        },
        {
          email: email,
        },
      ],
    };
    let checkExist = await super.getByCustomOptionsSingle(req, userModel, options);
    
    if(checkExist){
      return res.status(200).json({
        status: false,
        message: "The email/mobile no. is already registered.",
        data: {},
      });
    } else {
      // Get the current time in "Asia/Kolkata" time zone =======
      let momentKolkata = moment().tz('Asia/Kolkata');
      let currentDate = momentKolkata.format('YYYY-MM-DD');
      let currentDay = momentKolkata.format('dddd');
      let currentTime = momentKolkata.format('HH:mm');
      // Get the current time in "Asia/Kolkata" time zone =======
      
      // Add one day to the current date ==========
      let nextDay = moment(currentDate).add(1, 'days').format('YYYY-MM-DD');

      let otpObj = {
        phone: phone,
        otp: {
          code: otp,
          expiration: nextDay
        },
      };
      let checkOtpExists = await super.getByCustomOptionsSingle(req, temporaryOtpModel, {
        phone: phone,
      });

      let updated = checkOtpExists
        ? await super.updateById(temporaryOtpModel, checkOtpExists._id.toString(), otpObj)
        : await super.create(res, temporaryOtpModel, otpObj);

      if(updated){
        return res.status(200).json({
          status: true,
          message: "OTP Sent.",
          data: {
            phone: phone,
            // email: email,
            otp: otp,
          },
        });
      } else {
        return res.status(500).json({
          status: false,
          message: "Oops.. Something went terribly wrong..!!",
          data: {},
        });
      }
    }
  });
  static signUp = catchAsyncErrors(async (req, res, next)=>{
    let { firstName, lastName, email, phone, gender, password, roleId,  zipcode, city, state, dialcode, latitude, longitude, address, moduleId, roleOfUserType, corporateId, otp, language, _id, } = req.body;

    let data = {
      phone: phone,
    };
    let checkExist = await super.getByCustomOptionsSingle(req, temporaryOtpModel, data);

    // Get the current time in "Asia/Kolkata" time zone =======
    let momentKolkata = moment().tz('Asia/Kolkata');
    let currentDate = momentKolkata.format('YYYY-MM-DD');
    let currentDay = momentKolkata.format('dddd');
    let currentTime = momentKolkata.format('HH:mm');
    // Get the current time in "Asia/Kolkata" time zone =======

    if(checkExist.otp.expiration.toISOString().split('T')[0] != currentDate){
      if(checkExist.otp.code == otp){
        // ============ OTP valid ===========
        let data = {
          firstName: firstName,
          lastName: lastName,
          email: email,
          phone: phone,
          // gender: gender,
          password: password,
          // location: {
          //   type: "Point",
          //   coordinates: [latitude, longitude],
          // },
          // address: address,
          dialcode: dialcode,
          // dob: "",
          // zipcode: zipcode,
          // city: city,
          // state: state,
          roleId: roleId.toString(),
        };

        let checkUserExist = await super.getByCustomOptionsSingle(req, userModel, {
          email: email,
          phone: phone,
        });

        if(checkUserExist == null){
          let createUser = await super.create(res, userModel, data);
          let languageUpdate = await super.create(res, userLanguageModel, {
            userId: createUser._id,
            language: language,
          });
          if(createUser){
            let customerData = {
              userId: createUser._id,
              roleId: roleId.toString(),
            };
            let customerCreate = await super.create(res, customerModel, customerData);
            if(customerCreate){
              return res.status(200).json({
                status: true,
                message: "Success",
                data: createUser,
              });
            }
          } else {
            return res.status(500).json({
              status: false,
              message: "Oops..!! Something went wrong.",
              data: {},
            });
          }
        } else {
          return res.status(400).json({
            status: false,
            message: "User already exists..!!",
            data: checkUserExist,
          });
        }
      } else {
        return res.status(400).json({
          status: false,
          message: "Invalid OTP.",
          data: {},
        });
      }
    } else {
      return res.status(200).json({
        status: true,
        message: "OTP expired.",
        data: {},
      });
    }
  });
  static profileUpdate = catchAsyncErrors(async (req, res, next)=>{
    let { firstName, lastName, email, dialcode, phone, gender,  zipcode, city, state, latitude, longitude, address } = req.body;
    
    // =========== single file upload ================
    let fileName = "";
    if(req.files.profileImage){
      let image = await fileUploaderSingle("./src/public/uploads/userImages/", req.files.profileImage);
      fileName = image.newfileName;
    } 
    // =========== single file upload ================
    let data = {};

    if(firstName){
      data.firstName = firstName
    }
    if(lastName){
      data.lastName = lastName
    }
    if(email){
      data.email = email
    }
    if(dialcode){
      data.dialcode = dialcode
    }
    if(phone){
      data.phone = phone
    }
    if(gender){
      data.gender = gender
    }
    if(address){
      data.address = address
    }
    if(latitude && longitude){
      data.location = {
        type: "Point",
        coordinates: [latitude? latitude:'0.0', longitude? longitude:'0.0'],
      }
    }
    if(zipcode){
      data.zipcode = zipcode
    }
    if(city){
      data.city = city
    }
    if(state){
      data.state = state
    }
    
    if(fileName != ''){
      data.profileImage = fileName
    }
    
    let updated = await super.updateById(userModel, req.user._id.toString(), data);
    console.log("updated ===>");
    console.log(updated);
    
    if(updated){
      return res.status(200).json({
        status: true,
        message: "Success",
        data: updated,
      });
    } else{
      return res.status(400).json({
        status: false,
        message: "Oops.. Error updating profile.",
        data: {},
      });
    }
  });

  static saveLocation = catchAsyncErrors(async (req, res, next)=>{
    let { locationName, address, lat, long } = req.body;
    let data = {
      userId: req.user._id,
      locationName: locationName,
      address: address,
      location: {
        type: "Point",
        coordinates: [lat, long]
      }
    };
    let checkExist = await savedLocationsModel.findOne(data);

    const updated =
      checkExist
        ? await super.updateById(savedLocationsModel, checkExist._id.toString(), data)
        : await super.create(res, savedLocationsModel, data);
    
    return res.status(200).json({
      status: true,
      message: "Success",
      data: updated
    });
  });

  static savedLocationList = catchAsyncErrors(async (req, res, next)=>{
    let savedLocations = await savedLocationsModel.find({
      userId: req.user._id,
      isActive: true,
      isDeleted: false,
    });

    return res.status(200).json({
      status: true,
      message: "Success",
      data: savedLocations
    });
  });

  static parentExistCheck = catchAsyncErrors(async (req, res, next)=>{
    let { parentPhone } = req.body;

    const super_admin = await rollModel.findOne({ name: "Super Admin" });

    let parentExist = await userModel.findOne({
      roleId: {
        $ne: super_admin._id,
      },
      phone: parentPhone
    });
    // console.log("parentExist ====>");
    // console.log(parentExist);
    let studentRole = await rollModel.findOne({
      name: "Student"
    });

    if(parentExist){
      let parentUser = await customerModel.findOne({
        userId: parentExist._id,
        roleId: studentRole._id
      });
      // console.log("parentUser ===>");
      // console.log(parentUser);
      let autogeneratedStudentEmail = ``;
      if(parentUser){
        // already have student ==== 
        autogeneratedStudentEmail = `${parentPhone}.${(Number(parentUser.corporates.length))}@gmail.com`;
      } else {
        // doesnot have student ====
        autogeneratedStudentEmail = `${parentPhone}.0@gmail.com`
      }
      // console.log("autogeneratedStudentEmail ====>");
      // console.log(autogeneratedStudentEmail);
      return res.status(200).json({
        status: true,
        message: "Parent found.",
        data: {
          parentExist: parentExist,
          autogeneratedStudentEmail: autogeneratedStudentEmail,
        },
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No parent found. Please create parent account first.",
        data: {},
      });
    }
  });

  static customerExistCheck = catchAsyncErrors(async (req, res, next)=>{
    let { customerPhone } = req.body;

    let customerExist = await userModel.findOne({
      phone: customerPhone
    });

    if(customerExist){
      return res.status(200).json({
        status: true,
        message: "Customer found.",
        data: customerExist,
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No customer found",
        data: {},
      });
    }
  });

  static phoneExistCheck = catchAsyncErrors(async (req, res, next)=>{
    let { phoneNumber } = req.body;
    let phoneExist = await userModel.findOne({
      phone: phoneNumber
    });

    if(phoneExist){
      return res.status(200).json({
        status: false,
        message: "Duplicate",
        data: {},
      });
    } else {
      return res.status(200).json({
        status: true,
        message: "Unique",
        data: {},
      });
    }
  });
  
  static emailExistCheck = catchAsyncErrors(async (req, res, next)=>{
    let { email } = req.body;
    let emailExist = await userModel.findOne({
      email: email
    });

    if(emailExist){
      return res.status(200).json({
        status: false,
        message: "Duplicate",
        data: {},
      });
    } else {
      return res.status(200).json({
        status: true,
        message: "Unique",
        data: {},
      });
    }
  });

  static employeeStudentDriverList = catchAsyncErrors(async (req, res, next)=>{
    // Pagination parameters ===========
    let totalCount = 0;
    let totalPages= 0;
    const page = req.query.page ? parseInt(req.query.page) : 1; // Current page number
    const limit = req.query.limit ? parseInt(req.query.limit) : 3; // Number of documents per page
    const skip = (page - 1) * limit; // Number of documents to skip
    // Pagination parameters ===========

    let loggedUser = await userModel.findOne({
      _id: req.user._id
    });
    let roleOfLoggedUser = await rollModel.findOne({
      _id: loggedUser.roleId
    });

    let usersList = [];
    let corporateEntity = await corporateModel.findOne({
      userId: req.user._id
    });
    if(roleOfLoggedUser.name == "Corporate"){
      // should see their employees list ==========
      let match = {
        isActive: true,
        isDeleted: false,
        $and: [
          {
            "corporates": {
              $elemMatch: {
                "corporateId": corporateEntity._id
              }
            }
          },
        ],
      };
      let aggregatorOpts = [
        // {
        //   $addFields: {
        //     countryCode: "$countryCode",
        //   },
        // },
        {
          $match: match,
        },
      ];
      // Pagination parameters ===========
      totalCount = await customerModel.aggregate(aggregatorOpts).exec();
      totalCount = totalCount.length;
      // Pagination parameters ===========
      let employeeCustomers = await customerModel.aggregate(aggregatorOpts).skip(skip).limit(limit).exec();

      usersList = employeeCustomers;
    } else if(roleOfLoggedUser.name == "School"){
      // should see their students list ==========
      let match = {
        isActive: true,
        isDeleted: false,
        $and: [
          {
            "corporates": {
              $elemMatch: {
                "corporateId": corporateEntity._id
              }
            }
          },
        ],
      };
      let aggregatorOpts = [
        // {
        //   $addFields: {
        //     countryCode: "$countryCode",
        //   },
        // },
        {
          $match: match,
        },
      ];
      let parentCustomers = await customerModel.aggregate(aggregatorOpts).exec();
      let studentIdsArr = [];
      if(parentCustomers){
        parentCustomers.forEach((parent)=>{
          parent.corporates.forEach((school)=>{
            if(school.corporateId.toString() == corporateEntity._id.toString()){
              console.log("here");
              studentIdsArr.push(school.studentId.toString());
            }
          });
        });
        // Pagination parameters ===========
        totalCount = await userModel.find({
          _id: {
            $in: studentIdsArr
          }
        });
        totalCount = totalCount.length;
        // Pagination parameters ===========
        let studentUsersOfLoggedSchool = await userModel.find({
          _id: {
            $in: studentIdsArr
          }
        }).skip(skip).limit(limit);
        usersList = studentUsersOfLoggedSchool;
      }
    } else if(roleOfLoggedUser.name == "Vendor"){
      // should see their drivers list ==========
      // Pagination parameters ===========
      totalCount = await vendorDriverModel.countDocuments({
        vendorId: corporateEntity._id
      });
      // Pagination parameters ===========

      let vendorDriverMappings = await vendorDriverModel.find({
        vendorId: corporateEntity._id
      }).skip(skip).limit(limit).populate([
        {
          "path": "driverId",
          "model": "driverCollection",
          "populate": {
            "path": "userId",
            "model": "usersCollection",
          }
        },
      ]);

      usersList = vendorDriverMappings;
    }

    if(usersList.length > 0){
      // Pagination parameters ===========
      totalPages= Math.ceil(totalCount/limit);
      // Pagination parameters ===========

      return res.status(200).json({
        status: true,
        message: "Success",
        data: usersList,
        pagination: {
          total: totalCount,
          totalPages: totalPages,
          rowsPerPage: limit,
          currentPage: page,
          hasNextPage: page < totalPages,
          hasPrevPage: page > 1
        },
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "No data found.",
        data: []
      });
    }
  });

  static myChildList = catchAsyncErrors(async (req, res, next)=>{
    let studentRole = await rollModel.findOne({
      name: "Student",
    });
    let loggedUserChildExist = await customerModel.findOne({
      userId: req.user._id,
      roleId: studentRole._id,
    });
    if(loggedUserChildExist){
      // user has child ========
      // console.log("Child HAZ..");
      let schoolIdArr = [];
      let studentIdArr = [];
      let studentSchoolArr = [];
      loggedUserChildExist.corporates.forEach((school)=>{
        let studentSchoolObj = {
          studentId: school.studentId.toString(),
          schoolId: school.corporateId.toString(),  
        };

        studentSchoolArr.push(studentSchoolObj);

        schoolIdArr.push(school.corporateId.toString());
        studentIdArr.push(school.studentId.toString());
      });
      let studentUsers = await userModel.find({
        roleId: studentRole._id,
        _id: {
          $in: studentIdArr
        }
      });
      let schools = await corporateModel.find({
        _id: {
          $in: schoolIdArr
        }
      });
      // console.log("studentSchoolArr ===>");
      // console.log(studentSchoolArr);
      // console.log("schoolIdArr ===>");
      // console.log(schoolIdArr);
      // console.log("studentIdArr ===>");
      // console.log(studentIdArr);
      let studentWithSchoolData = [];
      if(studentSchoolArr.length > 0){
        studentSchoolArr.forEach((item)=>{
          studentUsers.forEach((student)=>{
            if(item.studentId == student._id){
              let obj = {
                student: student,
              };
              schools.forEach((school)=>{
                if(item.schoolId == school._id){
                  obj.school = school

                  studentWithSchoolData.push(obj);
                }
              });
            }
          });
        });
      }
      // console.log("studentWithSchoolData ====>");
      // console.log(studentWithSchoolData);
      if(studentUsers.length > 0){
        return res.status(200).json({
          status: true,
          message: "Success",
          data: {
            // studentUsers: studentUsers,
            // schools: schools,
            // studentSchoolArr: studentSchoolArr,
            studentWithSchoolData: studentWithSchoolData
          }
        });
      } else {
        return res.status(400).json({
          status: false,
          message: "No student found.",
          data: {
            studentUsers: [],
            schools: [],
            studentSchoolArr: [],
          }
        });
      }
    } else {
      // user does not have child, poor user... :( ========
      // console.log("No Child HAZ..");
      return res.status(400).json({
        status: false,
        message: "No child found.",
        data: []
      });

    }
  });
  // ================================ APP APIs ================================
  // ===========================================================================
}

module.exports = UserController;
