const express = require('express');
const router = express.Router();
const corporateUserController = require('../controllers/corporateUserController');
const {
    isAuthenticated
} = require('../middleware/auth');

router.route('/corporate-user-list').post(isAuthenticated, corporateUserController.corporateUserListWithPagination);

module.exports = router;
