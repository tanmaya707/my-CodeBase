const express = require('express');
const router = express.Router();
const tripPlanController = require('../controllers/tripPlanController')
const {
    validateUser
} = require('../validation/userValidator');
const {
    isAuthenticated
} = require('../middleware/auth')

// ======== for dropdown =======
router.route('/tripPlan-list').get(isAuthenticated, tripPlanController.tripPlanList);
// ======== for dropdown =======
router.route('/tripPlan-list').post(isAuthenticated, tripPlanController.tripPlanList);
router.route('/tripPlan-addUpdate').post(isAuthenticated, tripPlanController.tripPlanAddUpdate); 
router.route('/get-tripPlanDetail').post(isAuthenticated, tripPlanController.getTripPlanDetail);
router.route('/delete-tripPlanDetail').post(isAuthenticated, tripPlanController.deleteTripPlan);

module.exports = router;