const express = require('express');
const router = express.Router();
const walletController = require('../controllers/walletController')
const {
    validateUser
} = require('../validation/userValidator');
const {
    isAuthenticated
} = require('../middleware/auth')

router.route('/get-wallet-value').post(isAuthenticated, walletController.getWalletValue);

// ====================================== STRIPE ======================================
// -------------------------------------- Step: 1 --------------------------------------
// ---------------------------------- intent creation ----------------------------------
// -------------------------------------------------------------------------------------
router.route('/recharge-wallet-with-stripe').post(isAuthenticated, walletController.rechargeWalletWithStripe);
// -------------------------------------------------------------------------------------

// -------------------------------------- Step: 2 --------------------------------------
// ----------------- verify payment status and update wallet if success ----------------
// -------------------------------------------------------------------------------------
router.route('/update-wallet-with-stripe').post(isAuthenticated, walletController.updateWalletWithStripe);
// -------------------------------------------------------------------------------------
// ====================================== STRIPE ======================================

// ====================================== RAZORPAY ======================================
// -------------------------------------- Step: 1 --------------------------------------
// ---------------------------------- intent creation ----------------------------------
// -------------------------------------------------------------------------------------
router.route('/recharge-wallet-with-razorpay').post(isAuthenticated, walletController.rechargeWalletWithRazorPay);
// -------------------------------------------------------------------------------------

// -------------------------------------- Step: 2 --------------------------------------
// ----------------- verify payment status and update wallet if success ----------------
// -------------------------------------------------------------------------------------
router.route('/update-wallet-with-razorpay').post(isAuthenticated, walletController.updateWalletWithRazorPay);
// ====================================== RAZORPAY ======================================

module.exports = router;