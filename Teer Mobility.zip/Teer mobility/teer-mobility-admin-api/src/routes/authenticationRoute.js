const express = require('express');
const router = express.Router();
const authenticationController = require('../controllers/AuthenticationController')
const {
    isAuthenticated,
  } = require('../middleware/auth')

// login =======
router.route('/login').post(authenticationController.login);
router.route('/social-login').post(authenticationController.socialLogin)
router.route('/role-permission-checker').post(isAuthenticated, authenticationController.rolePermissionChecker);
router.route('/user-permission-checker').post(isAuthenticated, authenticationController.userPermissionChecker);
router.route('/role-list').get(authenticationController.roleList);
router.route('/role-list').post(isAuthenticated, authenticationController.roleList);
router.route('/forget-password').post(authenticationController.forgetPassword);
router.route('/change-password').post(isAuthenticated, authenticationController.changePassword);
router.route('/logout').post(isAuthenticated, authenticationController.logout);
router.route('/deactivate-account').post(isAuthenticated, authenticationController.deactivateAccount);

// ========================== App APIs ====================
router.route('/role-list-for-app').get(isAuthenticated, authenticationController.roleListForApp);
// ========================== App APIs ====================
module.exports = router;