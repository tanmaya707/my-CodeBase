const express = require('express');
const router = express.Router();
const notificationController = require('../controllers/notificationController')
const {
    validateUser
} = require('../validation/userValidator');
const {
    isAuthenticated
} = require('../middleware/auth')

// ======== assets ==========
router.route('/notification-list').post(isAuthenticated, notificationController.notificationList);
router.route('/notification-status-change').post(isAuthenticated, notificationController.notificationStatusChange);
router.route('/delete-notification').post(isAuthenticated, notificationController.deleteNotification);
// ======== assets ==========

module.exports = router;