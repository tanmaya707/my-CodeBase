const express = require('express');
const router = express.Router();
const vehicleController = require('../controllers/VehicleController')
const {
  validateUser
} = require('../validation/userValidator');
const {
  isAuthenticated
} = require('../middleware/auth')
// ================== vehicle category =====================
// ======== for dropdown =======
router.route('/vehicleCategory-list').get(isAuthenticated, vehicleController.vehicleCategoryList);
// ======== for dropdown =======
router.route('/vehicleCategory-list').post(isAuthenticated, vehicleController.vehicleCategoryList);
router.route('/vehicleCategory-addUpdate').post(isAuthenticated, vehicleController.vehicleCategoryAddUpdate);
router.route('/get-vehicleCategory').post(isAuthenticated, vehicleController.getVehicleCategory);
router.route('/delete-vehicleCategory').post(isAuthenticated, vehicleController.deleteVehicleCategory);

// ================== vehicle model =====================
// ======== for dropdown =======
router.route('/vehicleModel-list').get(isAuthenticated, vehicleController.vehicleModelList);
// ======== for dropdown =======
router.route('/vehicleModel-list').post(isAuthenticated, vehicleController.vehicleModelList);
router.route('/vehicleModel-addUpdate').post(isAuthenticated, vehicleController.vehicleModelAddUpdate);
router.route('/get-vehicleModel').post(isAuthenticated, vehicleController.getVehicleModel);
router.route('/delete-vehicleModel').post(isAuthenticated, vehicleController.deleteVehicleModel);

// ================== vehicle =====================
// ============ for dropdown ============
router.route('/vehicle-list').get(isAuthenticated, vehicleController.vehicleList);
// ============ for dropdown ============
router.route('/vehicle-list').post(isAuthenticated, vehicleController.vehicleList);
router.route('/vehicle-addUpdate').post(isAuthenticated, vehicleController.vehicleAddUpdate);
router.route('/get-vehicle').post(isAuthenticated, vehicleController.getVehicle);
router.route('/delete-vehicle').post(isAuthenticated, vehicleController.deleteVehicle);

// ================== vendor vehicle mapping ==================

// ---- being used for vendor-vehicle-map-list ----
router.route('/vendorVehicleMap-list-with-pagination').post(isAuthenticated, vehicleController.vendorVehicleMapListWithPagination);
// ---- being used for vendor-vehicle-map-list ----

// ---- being used for vehicle assign ----
router.route('/vendorVehicleMap-list').post(isAuthenticated, vehicleController.vendorVehicleMapList);
// ---- being used for vehicle assign ----

router.route('/vendorVehicleMap-addUpdate').post(isAuthenticated, vehicleController.vendorVehicleMapAddUpdate);
router.route('/get-vendorVehicleMapDetail').post(isAuthenticated, vehicleController.getVendorVehicleMapDetail);
router.route('/delete-vendorVehicleMapDetail').post(isAuthenticated, vehicleController.deleteVendorVehicleMapDetail);
// ================== vendor vehicle mapping ==================

module.exports = router;