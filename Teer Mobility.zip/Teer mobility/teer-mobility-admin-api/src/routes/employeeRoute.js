const express = require('express');
const router = express.Router();
const employeeController = require('../controllers/employeeController');
const {
    isAuthenticated
} = require('../middleware/auth');

router.route('/employee-list').post(isAuthenticated, employeeController.employeeListWithPagination);

module.exports = router;
