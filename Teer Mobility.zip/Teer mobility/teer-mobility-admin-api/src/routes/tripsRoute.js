const express = require('express');
const router = express.Router();
const tripController = require('../controllers/tripController')
const {
    validateUser
} = require('../validation/userValidator');
const {
    isAuthenticated
} = require('../middleware/auth')

// ======== for dropdown =======
router.route('/trip-list').get(isAuthenticated, tripController.tripList);
// ======== for dropdown =======

router.route('/trip-list').post(isAuthenticated, tripController.tripList);

// ------------------------- TABULAR VIEW -------------------------
router.route('/trip-list-tabular-view').post(isAuthenticated, tripController.tripListTabularView);
// ------------------------- TABULAR VIEW -------------------------
 
router.route('/get-tripDetail').post(isAuthenticated, tripController.getTripDetail);
router.route('/trip-requirements').post(isAuthenticated, tripController.tripRequirements);

// ======= booking creation from WEB =======
router.route('/trip-passenger-update').post(isAuthenticated, tripController.tripPassengerUpdate);
// ======= booking creation from WEB =======

// ======= booking list ======
router.route('/trip-bookings').post(isAuthenticated, tripController.tripBookings);
// ======= booking list ======

router.route('/delete-trip-booking').post(isAuthenticated, tripController.deleteTripBooking);
router.route('/get-trip-booking').post(isAuthenticated, tripController.getTripBooking);

// ======= Driver assignment to trip ======
router.route('/trip-assign-driver').post(isAuthenticated, tripController.tripAssignDriver);
// ======= Driver assignment to trip ======

router.route('/trip-assignment').post(isAuthenticated, tripController.tripAssignment);

router.route('/time-ranges').post(isAuthenticated, tripController.timeRanges);

// =================== App APIs ======================
// ================ Customer App ================
router.route('/current-ride').post(isAuthenticated, tripController.currentRide)
router.route('/current-ride-for-student').post(isAuthenticated, tripController.currentRideForStudent)

router.route('/upcoming-and-completed-trips').post(isAuthenticated, tripController.upcomingAndCompletedTrips)
router.route('/route-specific-trips').post(isAuthenticated, tripController.routeSpecificTrips)

router.route('/upcoming-and-completed-trips-for-student').post(isAuthenticated, tripController.upcomingAndCompletedTripsForStudent)
// router.route('/route-specific-trips-for-student').post(isAuthenticated, tripController.routeSpecificTripsForStudent)

router.route('/booking-confirmation').post(isAuthenticated, tripController.bookingConfirmation)
router.route('/cancel-booking').post(isAuthenticated, tripController.cancelBooking)
router.route('/save-route').post(isAuthenticated, tripController.saveRoute)
router.route('/delete-saved-route').post(isAuthenticated, tripController.deleteSavedRoute)
router.route('/saved-route-list').get(isAuthenticated, tripController.savedRouteList)
router.route('/seats-availability-check').post(isAuthenticated, tripController.seatsAvailabilityCheck);

router.route('/tripDetail-for-app').post(isAuthenticated, tripController.tripDetailForApp);
// ================ Customer App ================

// ================ Driver App ================
router.route('/trip-schedule-for-driver').get(isAuthenticated, tripController.tripScheduleForDriver)
router.route('/current-upcoming-completed-trips-for-driver').get(isAuthenticated, tripController.currentUpcomingCompletedTripsForDriver)
router.route('/trip-status-update').post(isAuthenticated, tripController.tripStatusUpdate)
router.route('/tripStop-list-for-driver').post(isAuthenticated, tripController.tripStopListForDriver);
// ================ Driver App ================

// ================ Corporate App ================
router.route('/trip-list-for-app').post(isAuthenticated, tripController.tripListForApp);
router.route('/trip-bookings-stopwise').post(isAuthenticated, tripController.tripBookingsStopwise)
// ================ Corporate App ================
// =================== App APIs ======================

module.exports = router;