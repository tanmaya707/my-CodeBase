const express = require('express');
const router = express.Router();
const privacyPolicyController = require('../controllers/privacyPolicyController')
const {
    validateUser
} = require('../validation/userValidator');
const {
    isAuthenticated
} = require('../middleware/auth')

// ======== privacy policy ==========
// ======== for dropdown =======
router.route('/privacyPolicy-list').get(isAuthenticated, privacyPolicyController.privacyPoliciesList);
// ======== for dropdown =======

router.route('/privacyPolicy-list').post(isAuthenticated, privacyPolicyController.privacyPoliciesList);

// ---- privacy-policy lst web ----
router.route('/privacyPolicy-list-with-pagination').post(isAuthenticated, privacyPolicyController.privacyPoliciesListWithPagination);
// ---- privacy-policy lst web ----

router.route('/privacyPolicy-addUpdate').post(isAuthenticated, privacyPolicyController.privacyPoliciesAddUpdate);
router.route('/get-privacyPolicyDetail').post(isAuthenticated, privacyPolicyController.getPrivacyPoliciesDetail);
router.route('/delete-privacyPolicyDetail').post(isAuthenticated, privacyPolicyController.deletePrivacyPolicies);
// ======== privacy policy ==========

module.exports = router;