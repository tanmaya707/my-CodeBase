const express = require('express');
const router = express.Router();
const moduleController = require('../controllers/moduleController')
const {
    validateUser
  } = require('../validation/userValidator');

// ======== modules ==========
// ======== for dropdown =======
router.route('/module-list').get(moduleController.modulesList);
router.route('/perssion-module-list').get(moduleController.perssionModuleList)
router.route('/all-perssion-module-list').get(moduleController.allPerssionModuleList)
// ======== for dropdown =======

// ---- module-list from web ----
router.route('/module-list-with-pagination').post(moduleController.modulesListWithPagination);
// ---- module-list from web ----

router.route('/module-list').post(moduleController.modulesList);

router.route('/module-addUpdate').post(moduleController.moduleAddUpdate); // validateUser, 
router.route('/get-moduleDetail').post(moduleController.getModuleDetail);
router.route('/delete-moduleDetail').post(moduleController.deleteModule);
router.route('/reorder-module').post(moduleController.reorderModule);
router.route('/parent-child-module-list').get(moduleController.parentChildModulesList);

// ======== modules ==========

module.exports = router;