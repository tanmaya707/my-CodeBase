const express = require('express');
const router = express.Router();
const studentController = require('../controllers/studentController');
const {
    isAuthenticated
} = require('../middleware/auth');

router.route('/student-list').post(isAuthenticated, studentController.studentListWithPagination);

module.exports = router;
