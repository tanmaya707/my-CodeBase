const express = require('express');
const router = express.Router();
const settingController = require('../controllers/settingController')
const {
    validateUser
} = require('../validation/userValidator');
const {
    isAuthenticated
} = require('../middleware/auth')

router.route('/add-support-reason').post(isAuthenticated, settingController.supportReasonAdd);
router.route('/get-support-reason').get(isAuthenticated, settingController.getSupportReason);

router.route('/update-general-setting').post(isAuthenticated, settingController.updateGeneralSetting);
// router.route('/get-general-setting').post(isAuthenticated, settingController.getGeneralSetting);
router.route('/get-support-details-from-app').post(isAuthenticated, settingController.getSupportDetails);

router.route('/enquiry-submit').post(isAuthenticated, settingController.enquirySubmit);

router.route('/update-notification-setting').post(isAuthenticated, settingController.updateNotificationSetting);
router.route('/get-notification-setting').get(isAuthenticated, settingController.getNotificationSetting);

router.route('/update-location-setting').post(isAuthenticated, settingController.updateLocationSetting);
router.route('/get-location-setting').get(isAuthenticated, settingController.getLocationSetting);

router.route('/update-feedback-setting').post(isAuthenticated, settingController.updateFeedbackSetting);
router.route('/get-feedback-setting').get(isAuthenticated, settingController.getFeedbackSetting);

router.route('/driver-feedback-submit').post(isAuthenticated, settingController.driverFeedbackSubmit);
router.route('/vehicle-feedback-submit').post(isAuthenticated, settingController.vehicleFeedbackSubmit);
router.route('/trip-feedback-submit').post(isAuthenticated, settingController.tripFeedbackSubmit);

router.route('/fare-chart-add-update').post(isAuthenticated, settingController.fareChartAddUpdate);
router.route('/get-fare-chart').post(settingController.getFareChart);

module.exports = router;