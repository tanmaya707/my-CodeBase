const express = require('express');
const router = express.Router();
const attendanceController = require('../controllers/attendanceController')
const {
    validateUser
} = require('../validation/userValidator');
const {
    isAuthenticated
} = require('../middleware/auth')

router.route('/attendance-list').post(isAuthenticated, attendanceController.attendanceList);

router.route('/send-otp-for-attendance').post(isAuthenticated, attendanceController.sendOtpForAttendance);
// router.route('/get-otp-for-attendance').get(isAuthenticated, attendanceController.getOtpForAttendance);

router.route('/mark-attendance').post(isAuthenticated, attendanceController.markAttendance);
router.route('/mark-attendance-for-passenger').post(isAuthenticated, attendanceController.markAttendanceForPassenger);
router.route('/mark-attendance-without-otp').post(isAuthenticated, attendanceController.markAttendanceWithoutOtp);

module.exports = router;