const express = require('express');
const router = express.Router();
const routeMapController = require('../controllers/routeMapController')
const {
    validateUser
} = require('../validation/userValidator');
const {
    isAuthenticated
} = require('../middleware/auth')

// ======== for dropdown =======
router.route('/routeMap-list').get(isAuthenticated, routeMapController.routeMapList);
// ======== for dropdown =======
router.route('/routeMap-list').post(isAuthenticated, routeMapController.routeMapList);
router.route('/routeMap-addUpdate').post(isAuthenticated, routeMapController.routeMapAddUpdate); 
router.route('/get-routeMapDetail').post(isAuthenticated, routeMapController.getRouteMapDetail);
router.route('/delete-routeMapDetail').post(isAuthenticated, routeMapController.deleteRouteMap);

// ============================ route-vehicle mapping ========================
router.route('/routeVehicleMap-list').post(isAuthenticated, routeMapController.routeVehicleMapList);
router.route('/routeVehicleMapping-addUpdate').post(isAuthenticated, routeMapController.routeVehicleMappingAddUpdate); 
router.route('/get-routeVehicleMappingDetail').post(isAuthenticated, routeMapController.getRouteVehicleMappingDetail);
router.route('/delete-routeVehicleMappingDetail').post(isAuthenticated, routeMapController.deleteRouteVehicleMappingDetail);
// ============================ route-vehicle mapping ========================

// ============================ App APIs ===============================
// ----- search-routes Version 1.0 -----
router.route('/search-routes').post(isAuthenticated, routeMapController.searchRoutes);
// ----- search-routes Version 1.0 -----

// ----- search-routes Version 2.0 with logic revamp -----
// router.route('/search-routes').post(isAuthenticated, routeMapController.searchRoutesV2);
// ----- search-routes Version 2.0 with logic revamp -----
router.route('/recent-searches').post(isAuthenticated, routeMapController.recentSearches);
// ============================ App APIs ===============================

module.exports = router;