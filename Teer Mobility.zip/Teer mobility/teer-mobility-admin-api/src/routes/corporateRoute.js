const express = require('express');
const router = express.Router();
const corporateController = require('../controllers/corporateController')
const {
    validateUser
} = require('../validation/userValidator');
const {
    isAuthenticated
} = require('../middleware/auth')

// ================== user =====================
// =========== for dropdown ===========
router.route('/corporate-list').get(isAuthenticated, corporateController.corporateList);
// =========== for dropdown ===========
router.route('/corporate-list').post(isAuthenticated, corporateController.corporateList);
router.route('/corporate-add-update').post(isAuthenticated, corporateController.corporateAddUpdate);
router.route('/get-corporate').post(isAuthenticated, corporateController.getCorporate);
router.route('/delete-corporate').post(isAuthenticated, corporateController.deleteCorporate);

// ============== vendor-corporate mapping ==============
router.route('/vendorCorporateMap-list').post(isAuthenticated, corporateController.vendorCorporateMapList);
router.route('/vendorCorporateMap-addUpdate').post(isAuthenticated, corporateController.vendorCorporateMapAddUpdate);
router.route('/get-vendorCorporateMapDetail').post(isAuthenticated, corporateController.getVendorCorporateMapDetail);
router.route('/delete-vendorCorporateMapDetail').post(isAuthenticated, corporateController.deleteVendorCorporateMapDetail);
// ============== vendor-corporate mapping ==============

module.exports = router;