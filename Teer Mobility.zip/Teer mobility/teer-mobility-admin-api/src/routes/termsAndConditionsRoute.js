const express = require('express');
const router = express.Router();
const termsAndConditionsController = require('../controllers/termsAndConditionsController')
const {
    validateUser
} = require('../validation/userValidator');
const {
    isAuthenticated
} = require('../middleware/auth')

// ======== t&c ==========
// ======== for dropdown =======
router.route('/termsAndConditions-list').get(isAuthenticated, termsAndConditionsController.termsAndConditionsList);
// ======== for dropdown =======

router.route('/termsAndConditions-list').post(isAuthenticated, termsAndConditionsController.termsAndConditionsList);

// ---- termsAndConditionsListWithPagination for web ----
router.route('/termsAndConditions-list-with-pagination').post(isAuthenticated, termsAndConditionsController.termsAndConditionsListWithPagination);
// ---- termsAndConditionsListWithPagination for web ----

router.route('/termsAndConditions-addUpdate').post(isAuthenticated, termsAndConditionsController.termsAndConditionsAddUpdate);
router.route('/get-termsAndConditionsDetail').post(isAuthenticated, termsAndConditionsController.getTermsAndConditionsDetail);
router.route('/delete-termsAndConditionsDetail').post(isAuthenticated, termsAndConditionsController.deleteTermsAndConditions);
// ======== t&c ==========

module.exports = router;