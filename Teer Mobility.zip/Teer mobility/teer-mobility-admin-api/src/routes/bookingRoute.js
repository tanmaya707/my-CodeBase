const express = require('express');
const router = express.Router();
const bookingController = require('../controllers/bookingController')
const {
    validateUser
} = require('../validation/userValidator');
const {
    isAuthenticated
} = require('../middleware/auth')

// ================ ONLINE PAYMENTS ================

// ------------------ WITH STRIPE ------------------
router.route('/create-trip-payment-intent-with-stripe').post(isAuthenticated, bookingController.createTripPaymentIntentWithStripe);
router.route('/verify-trip-payment-via-stripe').post(isAuthenticated, bookingController.verifyTripPaymentViaStripe);
// ------------------ WITH STRIPE ------------------

// ----------------- WITH RAZORPAY -----------------
router.route('/create-trip-payment-intent-with-razorpay').post(isAuthenticated, bookingController.createPaymentIntentWithRazorPay);
router.route('/verify-trip-payment-via-razorpay').post(isAuthenticated, bookingController.verifyTripPaymentViaRazorPay);
// ----------------- WITH RAZORPAY -----------------

// ================ ONLINE PAYMENTS ================

// ---------------------------------------------------------------------------
// N.B.:-
// If paymentMode is "online"; the "/booking-create" API SHOULD ONLY BE HIT once SUCCESS (200) response is received from any one of the online payment verify endpoints defined above.
// ---------------------------------------------------------------------------

// ======= booking creation from APP =======
router.route('/booking-create').post(isAuthenticated, bookingController.bookingCreate);
// ======= booking creation from APP =======

module.exports = router;