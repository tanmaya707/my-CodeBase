const express = require('express');
const router = express.Router();
const tripStopController = require('../controllers/tripStopController')
const {
    validateUser
} = require('../validation/userValidator');
const {
    isAuthenticated
} = require('../middleware/auth')

// ======== for dropdown =======
router.route('/tripStop-list').get(isAuthenticated, tripStopController.tripStopList);
// ======== for dropdown =======
// ======== for tripStops and distance input in tripPlan =======
router.route('/stops-list').post(isAuthenticated, tripStopController.stopsList);
// ======== for tripStops and distance input in tripPlan =======
router.route('/tripStop-list').post(isAuthenticated, tripStopController.tripStopList);
router.route('/tripStop-addUpdate').post(isAuthenticated, tripStopController.tripStopAddUpdate); 
router.route('/get-tripStopDetail').post(isAuthenticated, tripStopController.gettripStopDetail);
router.route('/delete-tripStopDetail').post(isAuthenticated, tripStopController.deletetripStop);

router.route('/stops-list-with-time').post(isAuthenticated, tripStopController.stopsListWithTime);
router.route('/stops-list-with-time-for-corporate-app').post(isAuthenticated, tripStopController.stopsListWithTimeForCorporateApp);

module.exports = router;