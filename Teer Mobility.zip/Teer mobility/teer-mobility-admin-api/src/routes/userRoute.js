const express = require('express');
const router = express.Router();
const userController = require('../controllers/UserController')
const {
    validateUser
  } = require('../validation/userValidator');
  const {
    isAuthenticated
  } = require('../middleware/auth')

// ================== user =====================
// ================== dropdown =====================
router.route('/user-list').get(isAuthenticated, userController.userList);
// ================== dropdown =====================
router.route('/user-list').post(isAuthenticated, userController.userList);
router.route('/user-update').post(validateUser, isAuthenticated, userController.userUpdate);
router.route('/get-user').post(isAuthenticated, userController.getUser);
router.route('/delete-user').post(isAuthenticated, userController.deleteUser);

router.route('/parent-exist-check').post(userController.parentExistCheck);
router.route('/customer-exist-check').post(userController.customerExistCheck);
router.route('/phone-exist-check').post(userController.phoneExistCheck);
router.route('/email-exist-check').post(userController.emailExistCheck);

// ======================================= APP APIs ======================================
// =========== Common for Customer & Driver App ============
router.route('/sendOtp').post(userController.sendOtp);
router.route('/signUp').post(userController.signUp);
router.route('/profile-update').post(validateUser, isAuthenticated, userController.profileUpdate);
// =========== Common for Customer & Driver App ============

// ============== For Customer App ==============
router.route('/save-location').post(isAuthenticated, userController.saveLocation);
router.route('/saved-locations').get(isAuthenticated, userController.savedLocationList);
// ============== For Customer App ==============

// ============== For Corporate App ==============
router.route('/employee-student-driver-list').post(isAuthenticated, userController.employeeStudentDriverList);
router.route('/my-child-list').post(isAuthenticated, userController.myChildList);
// ============== For Corporate App ==============
// ======================================= APP APIs ======================================

module.exports = router;