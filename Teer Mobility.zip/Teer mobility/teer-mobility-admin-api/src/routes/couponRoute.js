const express = require('express');
const router = express.Router();
const couponController = require('../controllers/couponController')
const {
    validateUser
} = require('../validation/userValidator');
const {
    isAuthenticated
} = require('../middleware/auth')

// ======== coupons ==========
// ======== for dropdown =======
router.route('/coupon-list').get(isAuthenticated, couponController.couponsList);
// ======== for dropdown =======
router.route('/coupon-list').post(isAuthenticated, couponController.couponsList);
router.route('/coupon-addUpdate').post(isAuthenticated, couponController.couponAddUpdate);
router.route('/get-couponDetail').post(isAuthenticated, couponController.getCouponDetail);
router.route('/delete-couponDetail').post(isAuthenticated, couponController.deleteCoupon);
// ======== coupons ==========

// ======== App APIs =========
router.route('/check-coupon').post(isAuthenticated, couponController.checkCoupon);

// ======== App APIs =========

module.exports = router;