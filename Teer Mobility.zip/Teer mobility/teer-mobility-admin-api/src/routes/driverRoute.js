const express = require('express');
const router = express.Router();
const driverController = require('../controllers/driverController');
const {
    isAuthenticated
} = require('../middleware/auth');

// ================== user =====================
// ========== for dropdown ==========
router.route('/driver-list').get(isAuthenticated, driverController.driverList);
// ========== for dropdown ==========
// ========== for dropdown ==========
router.route('/vendorDriverMap-list').get(isAuthenticated, driverController.vendorDriverMapList);
// ========== for dropdown ==========

router.route('/driver-list').post(isAuthenticated, driverController.driverListWithPagination);

// ---- being used for vendor-driver-map-list page ----
router.route('/vendorDriverMap-list-with-pagination').post(isAuthenticated, driverController.vendorDriverMapListWithPagination);
// ---- being used for vendor-driver-map-list page ----

// ---- being used for driver assign ----
router.route('/vendorDriverMap-list').post(isAuthenticated, driverController.vendorDriverMapList);
// ---- being used for driver assign ----

router.route('/vendorDriverMap-addUpdate').post(isAuthenticated, driverController.vendorDriverMapAddUpdate);
router.route('/get-vendorDriverMapDetail').post(isAuthenticated, driverController.getVendorDriverMapDetail);
router.route('/delete-vendorDriverMapDetail').post(isAuthenticated, driverController.deleteVendorDriverMap);

// ===== APP APIs ======
router.route('/driver-location-update').post(isAuthenticated, driverController.driverLocationUpdate);
router.route('/trip-location-history').post(isAuthenticated, driverController.tripLocationHistory);
// ===== APP APIs ======

// ========== Notification Test ===========
router.route('/send-test-noti').post(driverController.sendTestNoti);
// ========== Notification Test ===========


module.exports = router;