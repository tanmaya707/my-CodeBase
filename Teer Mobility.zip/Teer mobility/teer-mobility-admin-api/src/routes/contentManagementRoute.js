const express = require('express');
const router = express.Router();
const contentManagementController = require('../controllers/contentManagementController')
const {
    validateUser
} = require('../validation/userValidator');
const {
    isAuthenticated
} = require('../middleware/auth')

// ======== content management ==========
// ======== for dropdown =======
router.route('/content-list').get(isAuthenticated, contentManagementController.contentList);
// ======== for dropdown =======
router.route('/content-list').post(isAuthenticated, contentManagementController.contentList);
router.route('/content-addUpdate').post(isAuthenticated, contentManagementController.contentAddUpdate);
router.route('/get-contentDetail').post(isAuthenticated, contentManagementController.getContentDetail);
router.route('/delete-contentDetail').post(isAuthenticated, contentManagementController.deleteContent);
// ======== content management ==========

module.exports = router;