const express = require('express');
const router = express.Router();
const supportController = require('../controllers/supportController')
const {
    validateUser
} = require('../validation/userValidator');
const {
    isAuthenticated
} = require('../middleware/auth')

router.route('/get-support-details').post(isAuthenticated, supportController.getsupportDetail);
router.route('/support-details-add-update').post(isAuthenticated, supportController.supportDetailAddUpdate);

router.route('/support-list-for-web').post(isAuthenticated, supportController.supportListWithPagination);

router.route('/send-reply-to-customer').post(isAuthenticated, supportController.sendReplyToCustomer);

// router.route('/support-details-add-update').post(isAuthenticated, supportController.supportDetailAddUpdate);

// ======== privacy policy ==========

module.exports = router;