const express = require('express');
const router = express.Router();
const assetController = require('../controllers/assetController')
const {
    validateUser
} = require('../validation/userValidator');
const {
    isAuthenticated
} = require('../middleware/auth')

// ======== assets ==========
// ======== for dropdown =======
router.route('/asset-list').get(isAuthenticated, assetController.assetsList);
// ======== for dropdown =======
router.route('/asset-list').post(isAuthenticated, assetController.assetsList);
router.route('/asset-addUpdate').post(isAuthenticated, assetController.assetAddUpdate); // validateUser, 
router.route('/get-assetDetail').post(isAuthenticated, assetController.getAssetDetail);
router.route('/delete-assetDetail').post(isAuthenticated, assetController.deleteAsset);
// ======== assets ==========

module.exports = router;