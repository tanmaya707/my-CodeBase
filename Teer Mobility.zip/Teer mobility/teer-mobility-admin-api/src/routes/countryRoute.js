const express = require('express');
const router = express.Router();
const countryController = require('../controllers/countryController')
const {
    validateUser
} = require('../validation/userValidator');
const {
  isAuthenticated
} = require('../middleware/auth')
// ================== user =====================
router.route('/country-list').get(countryController.countryList);

router.route('/countries-list').post(isAuthenticated, countryController.countriesList);
router.route('/get-countryDetail').post(isAuthenticated, countryController.getCountryDetail);

router.route('/country-update').post(isAuthenticated, countryController.countryUpdate);
router.route('/delete-countryDetail').post(isAuthenticated, countryController.countryDelete);

module.exports = router;