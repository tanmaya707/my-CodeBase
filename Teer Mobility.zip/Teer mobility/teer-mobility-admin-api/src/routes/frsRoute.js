const express = require('express');
const router = express.Router();
const userController = require('../controllers/UserController')
const {
    validateUser
  } = require('../validation/userValidator');
  const {
    isAuthenticated
  } = require('../middleware/auth')

// ================== user =====================
router.route('/add-face').post(isAuthenticated, userController.userList);


module.exports = router;