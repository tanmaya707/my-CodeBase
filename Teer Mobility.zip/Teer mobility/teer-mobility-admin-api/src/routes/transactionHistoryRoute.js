const express = require('express');
const router = express.Router();
const transactionHistoryController = require('../controllers/transactionHistoryController')
const {
    validateUser
} = require('../validation/userValidator');
const {
    isAuthenticated
} = require('../middleware/auth')

// ---- for web ----
router.route('/transaction-history-list-for-web').post(isAuthenticated, transactionHistoryController.transactionHistoryListWithPagination);
router.route('/transaction-history-trip-wise-list-for-web').post(isAuthenticated, transactionHistoryController.transactionHistoryTripWiseListWithPagination);

// ------- refund -------
router.route('/refund-money-via-stripe').post(isAuthenticated, transactionHistoryController.refundMoneyViaStripe);
router.route('/refund-money-via-razorpay').post(isAuthenticated, transactionHistoryController.refundMoneyViaRazorpay);
// ------- refund -------

// ---- for web ----

// ---- for app ----
router.route('/get-user-transaction-history').post(isAuthenticated, transactionHistoryController.userWiseTransactionHistory);
// ---- for app ----

module.exports = router;