const mongoose = require("mongoose");
const mongoConfig = require("./index").Mongo;
mongoose.set("strictQuery", false);
mongoose.set("debug", process.env.APP_ENV == "development" ? true : false);

// =====================================================================
// =========================== mongo-cluster ===========================
// =====================================================================
// let url =
//     process.env.APP_ENV == "development"
//         ? `mongodb://` + mongoConfig.path + "/" + mongoConfig.dbName
//         : "mongodb+srv://" +
//         mongoConfig.user +
//         ":" +
//         mongoConfig.pwd +
//         "@" +
//         mongoConfig.path +
//         "/" +
//         mongoConfig.dbName +
//         "?retryWrites=true&w=majority&appName=TeerMobility";

// mongodb+srv://teerMobility:FOlfiHzWZBYna4MA@teermobility.5noba.mongodb.net/?retryWrites=true&w=majority&appName=TeerMobility
// mongodb+srv://<username>:<password>@teermobility.5noba.mongodb.net/?retryWrites=true&w=majority&appName=TeerMobility

// let options = {
//     // useNewUrlParser: true,
//     // useUnifiedTopology: true,
// };
// =====================================================================
// =========================== mongo-cluster ===========================
// =====================================================================

// =====================================================================
// =============== mongo community-edition office server ===============
// =====================================================================
let url =
  process.env.APP_ENV == "development"
    ? `mongodb://` + mongoConfig.path + "/" + mongoConfig.dbName
    : "mongodb://" +
      mongoConfig.user +
      ":" +
      mongoConfig.pwd +
      "@" +
      mongoConfig.path +
      "/" +
      mongoConfig.dbName +
      "?retryWrites=true&w=majority";

let options = {
  // useNewUrlParser: true, // deprecated
  // useUnifiedTopology: true, // deprecated
  serverSelectionTimeoutMS: 50000, // Increase timeout to 50 seconds
  authSource: "admin", // Add this if authentication is against the 'admin' database
};
// =====================================================================
// =============== mongo community-edition office server ===============
// =====================================================================

// =====================================================================
// ===================== client's mongo instance =======================
// =====================================================================
// let url =
//     process.env.APP_ENV == "development"
//         ? `mongodb://` + mongoConfig.path + "/" + mongoConfig.dbName
//         : 
//         "mongodb://" +
//         mongoConfig.user +
//         ":" +
//         mongoConfig.pwd +
//         "@" +
//         mongoConfig.path +
//         "/" +
//         mongoConfig.dbName +
//         "?authSource=teermobility";

// mongodb://WebUser:WEb334TKleverIeroo4933@route-1.teermobility.tech:27017/?authSource=teermobility
// mongodb+srv://<username>:<password>@teermobility.5noba.mongodb.net/?retryWrites=true&w=majority&appName=TeerMobility

// let options = {
//     // useNewUrlParser: true,
//     // useUnifiedTopology: true,
// };
// =====================================================================
// ===================== client's mongo instance =======================
// =====================================================================


const connectDatabase = async () => {
    try {
        await mongoose.connect(url, options).then((data) => {
            if (process.env.APP_ENV == "development") {
                console.log(`mongodb://` + mongoConfig.path + "/" + mongoConfig.dbName);
            } else {
                console.log(`Mongodb connected with server: mongodb://${data.connection.host}:${data.connection.port}/${data.connection.name}`);
            }
        });
    } catch (error) {
        console.error('Error connecting to MongoDB:', error.message);
        // process.exit(1);
    }
};

module.exports = connectDatabase;
