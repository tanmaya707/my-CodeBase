const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;

const rolePermissionSchema = mongoose.Schema(
    {
        roleId: { type: ObjectId, ref: "roleCollection", required: true },
        moduleId: [{ type: ObjectId, ref: "moduleCollection", required: true }],

        updatedBy: { type: ObjectId, ref: "usersCollection", required: true },

        isActive: { type: Boolean, default: true },
        isDeleted: { type: Boolean, default: false },
    },
    { timestamps: true }
);

module.exports = mongoose.model("rolePermissionCollection", rolePermissionSchema)