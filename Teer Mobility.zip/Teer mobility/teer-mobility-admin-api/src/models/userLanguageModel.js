const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;

const userLanguageSchema = mongoose.Schema(
  {
    userId: { type: ObjectId, ref: "UsersCollection", required: true, default: null },
    language: { type: String, required: false, default: "English" },
  },
  { timestamps: true }
);
module.exports = mongoose.model("userLanguageCollection", userLanguageSchema);
