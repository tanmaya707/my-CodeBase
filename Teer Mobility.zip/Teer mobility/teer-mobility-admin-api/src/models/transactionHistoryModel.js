const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;
const Decimal128 = mongoose.Schema.Types.Decimal128;

const transactionHistorySchema = mongoose.Schema(
  {
    userId: { type: ObjectId, ref: "usersCollection", required: true, default: null, },
    transactionId: { type: ObjectId, ref: "TransactionsCollection", required: false, default: null },
    tripId: { type: ObjectId, ref: "tripsCollection", required: false, default: null, },

    amount: { type: Number, required: true, default: 0 },
    currency: { type: String, required: true, default: "INR" },

    gatewayName: { type: String, required: true, default: null },

    type: { type: String, enum: ["walletRecharge", "payFromWallet", "directTripPayment", "refund"], default: "directTripPayment" },

    remarks:{ type: String, required: false, default: null },

    isRefunded: { type: Boolean, default: false },

    isSuccess: { type: Boolean, default: true },

    isActive: { type: Boolean, default: true },
    isDeleted: { type: Boolean, default: false },
  },
  { timestamps: true }
);

module.exports = mongoose.model("transactionHistoriesCollection", transactionHistorySchema);
