const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId; 

// There could be roles like accounting for TWO COMPANIES, which would constitute one role, and roles managing total trips for four companies, constituting another role ===
const userCorporateMappingSchema = mongoose.Schema(
    {
        userId: { type: ObjectId, ref: "usersCollection", required: true, default: null, },
        corporateId: [{ type: ObjectId, ref: "corporateCollection", required: true, default: null, }],
        
        updatedBy: { type: ObjectId, ref: "usersCollection", required: true },

        isActive: { type: Boolean, default: true },
        isDeleted: { type: Boolean, default: false },
    },
    { timestamps: true }
);

module.exports = mongoose.model("userCorporateMappingCollection", userCorporateMappingSchema);