const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;
const validator = require("validator");

const driverLocationsSchema = new mongoose.Schema(
  {
    userId: { type: ObjectId, ref: "usersCollection", required: true, default: null, },
    coordinates: {
      type: [Number],
      required: false,
      default: [0.0, 0.0],
    },
    heading: { type: Number, required: false, default: 0.0 },
    
    isActive: { type: Boolean, default: true },
    isDeleted: { type: Boolean, default: false },
  },
  { timestamps: true }
);

module.exports = mongoose.model("driverLocationsCollection", driverLocationsSchema);
