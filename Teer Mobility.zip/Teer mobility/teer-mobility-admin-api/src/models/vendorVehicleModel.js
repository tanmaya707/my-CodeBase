const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;

const vendorVehicleSchema = new mongoose.Schema(
  {
    vendorId: { type: ObjectId, ref: "corporateCollection", required: true, default: null, },
    vehicleId: { type: ObjectId, ref: "vehicleCollection", required: true, default: null, },

    isActive: { type: Boolean, default: true },
    isDeleted: { type: Boolean, default: false },
  },
  { timestamps: true }
);

module.exports = mongoose.model("vendorVehicleCollection", vendorVehicleSchema);
