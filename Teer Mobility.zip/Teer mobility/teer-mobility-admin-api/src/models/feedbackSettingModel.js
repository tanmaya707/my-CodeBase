const { values } = require("lodash");
const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;

const feedbackSettingSchema = mongoose.Schema(
  {
    objectType: {
        type: String, 
        enum: ["driver", "vehicle"], 
        default: "driver",
    },
    objectValue: [
        {
            value: {
              type: String,
              required: true,
              default: null,
            },
            weight: {
                type: Number,
                required: true,
                default: null,
            },
            order: {
                type: Number,
                required: true,
                default: null,
            },
        },
    ],
  },
  { timestamps: true }
);
module.exports = mongoose.model("feedbackSettingCollection", feedbackSettingSchema);
