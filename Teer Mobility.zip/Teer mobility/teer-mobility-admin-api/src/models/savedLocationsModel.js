const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;

const savedLocationsSchema = mongoose.Schema(
  {
    userId: { type: ObjectId, ref: "usersCollection", required: true },
    locationName: { type: String, required: true, default: null },
    address: { type: String, required: true, default: null },
    location: {
      type: {
        type: String,
        enum: ["Point"],
        required: false,
        default: "Point",
      },
      coordinates: {
        type: [Number],
        required: false,
        default: [0.0, 0.0],
      },
    },

    isActive: { type: Boolean, default: true },
    isDeleted: { type: Boolean, default: false },
  },
  { timestamps: true }
);

module.exports = mongoose.model(
  "savedLocationsCollection",
  savedLocationsSchema
);
