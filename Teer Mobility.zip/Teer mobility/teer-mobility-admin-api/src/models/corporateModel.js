const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;
const validator = require("validator");

// Different corporate types :- 
// Corporate, Company, School group, Branches of same school group, Vendor Organzation === ENTERS HERE ====
const corporateSchema = new mongoose.Schema(
  {
    userId: { type: ObjectId, ref: "usersCollection", required: true, default: null, },
    countryCode: { type: ObjectId, ref: "countryCollection", required: true, default: null, },
    // (parentId == null) i.e. "Top level Corporate entity"; signifies Top Level Organization Eg. TATA SONS ======
    // (parentId != null) i.e. Company entity; signifies a company under some "Top level Corporate entity"; Eg. TATA MOTORS, which is a company under the TATA SONS umbrella ======
    parentCorporateId: { type: ObjectId, ref: "corporateCollection", required: false, default: null },

    name: {
      type: String,
      required: [true, "Please Enter Name"],
    },
    locations: [
      {
        branchName: {
          type: String,
          required: false,
          default: null,
        },
        locationName: {
          type: String,
          required: false,
          default: null,
        },
        location: {
          type: {
            type: String,
            enum: ["Point"],
            required: false,
            default: "Point",
          },
          coordinates: {
            type: [Number],
            required: false,
            default: [0.0, 0.0],
          },
        },
      },
    ],
    attendanceSystem: { type: String, required: true, default: false },
    payment: {
      payer: {
        type: String,
        default: null,
      },
      paymentType: {
        type: String,
        default: null,
      },
    },
    address: { type: String, required: true, default: null },
    city: {
      type: String,
      required: [true, "Please Enter City"],
    },
    state: {
      type: String,
      required: [true, "Please Enter State"],
    },
    zipcode: {
      type: Number,
      required: false,
      default: null,
    },
    supportEmail: {
      type: String,
      required: [true, "Please Enter Your Support Email"],
      unique: true,
      validate: [validator.isEmail, "Please Enter a valid Support Email"],
    },
    phoneNumber: {
      type: Number,
      required: true,
      unique: true,
    },
    logoImage: {
      type: String,
      required: [true, "Please upload logo image"],
    },
    regularWeekends: [{ type: String }],
    holidays: [{ type: Date }],

    isOnDemand: { type: Boolean, default: false },

    isActive: { type: Boolean, default: true },
    isVerified: { type: Boolean, default: false },
    isVerifiedEmail: { type: Boolean, default: false },
    isVerifiedPhone: { type: Boolean, default: false },

    isDeleted: { type: Boolean, default: false },
  },
  { timestamps: true }
);

module.exports = mongoose.model("corporateCollection", corporateSchema);
