const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;

const attendanceSchema = mongoose.Schema(
  {
    userId: { type: ObjectId, ref: "usersCollection", required: false, default: null, },
    routeId: { type: ObjectId, ref: "routeMapCollection", required: false, default: null, },

    date: { type: Date, required: true, default: null },
    inTime: { type: String, required: false, default: null },
    outTime: { type: String, required: false, default: null },
    workTime: { type: String, required: false, default: null },

    inCoOrdinates: {
      type: [Number],
      required: false,
      default: [0.0, 0.0],
    },
    outCoOrdinates: {
      type: [Number],
      required: false,
      default: [0.0, 0.0],
    },

    isActive: { type: Boolean, default: true },
    isDeleted: { type: Boolean, default: false },
  },
  { timestamps: true }
);
module.exports = mongoose.model("attendanceCollection", attendanceSchema);
