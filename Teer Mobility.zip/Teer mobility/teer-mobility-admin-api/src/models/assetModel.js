const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;

const assetSchema = mongoose.Schema(
  {
    apiId: { type: ObjectId, ref: "trackingApiCollection", required: false, default: null, },

    assetType: { type: String, required: true, },
    otherAssetDetails: { type: String, required: false, default: null },
    sim: {
      phoneNumber: {
        type: Number,
        required: false,
        default: null,
      },
      carrier: {
        type: String,
        required: false,
        default: null,
      },
    },
    brand: { type: String, required: true, },

    isActive: { type: Boolean, default: true },
    isDeleted: { type: Boolean, default: false },
  },
  { timestamps: true }
);
module.exports = mongoose.model("assetCollection", assetSchema);
