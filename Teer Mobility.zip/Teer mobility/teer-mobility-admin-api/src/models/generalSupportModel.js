const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;
const validator = require("validator");

const generalSupportSchema = mongoose.Schema(
  {
    userId: { type: ObjectId, ref: "usersCollection", required: false, default: null, },

    supportEmail: {
      type: String,
      required: [true, "Please Enter Your Support Email"],
      unique: true,
      validate: [validator.isEmail, "Please Enter a valid Support Email"],
    },
    phoneNumber: {
      type: Number,
      required: true,
      unique: true,
    },

    isActive: { type: Boolean, default: true },
    isDeleted: { type: Boolean, default: false },
  },
  { timestamps: true }
);
module.exports = mongoose.model("generalSupportCollection", generalSupportSchema);
