const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;

const tripPlanSchema = mongoose.Schema(
  {
    routeId: { type: ObjectId, ref: "routeMapCollection", required: true, default: null, },
    vendorId: { type: ObjectId, ref: "corporateCollection", default: null, },
    corporateId: { type: ObjectId, ref: "corporateCollection", default: null, },
    driverId: { type: ObjectId, ref: "driverCollection", default: null, },
    vehicleId: { type: ObjectId, ref: "vehicleCollection", default: null, },

    tripName: { type: String, required: true, default: null },
    tripDescription: { type: String, required: false, default: null },
    accessibility: { type: Number, required: true, default: null },
    tripType: { type: String, enum: ["Daily", "Customized", "OneTime"], required: true, default: null },
    schedule: [{
        oneTimeDate: { type: Date, default: null },
        dayName: { type: String, default: false },
        startTime: { 
            type: String,
            match: /^([01]\d|2[0-3]):([0-5]\d)$/, // Regular expression for HH:MM format 
            required: false, 
            default: null 
        },
        endTime: { 
            type: String, 
            match: /^([01]\d|2[0-3]):([0-5]\d)$/, // Regular expression for HH:MM format
            required: false, 
            default: null 
        },
    }],
    stops: [{
			tripStopId: { type: ObjectId, ref: "tripStopCollection", required: true, default: null, },
			distance: { type: Number, required: true, default: null },
			time: { type: Number, required: true, default: null },
    }],

		isAC: { type: Boolean, default: true },
		isOnDemand: { type: Boolean, default: false },
		
    isCancelled: { type: Boolean, default: false },
    isDelayed: { type: Boolean, default: false },
    delayedByTime: { 
        type: String, 
        match: /^([01]\d|2[0-3]):([0-5]\d)$/, // Regular expression for HH:MM format
        default: null 
    },

    isActive: { type: Boolean, default: true },
    isDeleted: { type: Boolean, default: false },
  },
  { timestamps: true }
);
module.exports = mongoose.model("tripPlanCollection", tripPlanSchema);
