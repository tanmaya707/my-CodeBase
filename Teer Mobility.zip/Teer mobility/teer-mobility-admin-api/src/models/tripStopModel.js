const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;

const tripStopSchema = mongoose.Schema(
  {
    countryCode: { type: ObjectId, ref: "countryCollection", required: true, default: null, },

    stopName: { type: String, required: true, default: null },
    address: { type: String, required: true, default: null },
    location: {
      type: {
        type: String,
        enum: ["Point"],
        required: true,
        default: "Point",
      },
      coordinates: {
        type: [Number],
        required: true,
        default: [0.0, 0.0],
      },
    },
    stopType: { type: String, required: true, default: null },
    accessibility: [{ type: Number, required: true, default: null },],
    dangerAddress: { type: String, required: false, default: null },
    dangerLatitude: { type: Number, required: false, default: null },
    dangerLongitude: { type: Number, required: false, default: null },
    dangerZone: {
        status: { type: Boolean, required: false, default: false },
        dangerLocation: {
          type: { type: String, enum: ['Polygon'], required: false, default: "Polygon" },
          coordinates: {
            type: [[Number]], // Array of arrays of arrays of numbers
            required: true
          }
        }
        // coordinates: [{ type: Number, required: false, default: [0.0, 0.0] }],
    },

    isActive: { type: Boolean, default: true },
    isDeleted: { type: Boolean, default: false },
  },
  { timestamps: true }
);

tripStopSchema.index({location: '2dsphere'});

module.exports = mongoose.model("tripStopCollection", tripStopSchema);


// --- use this with find query to make case insensitive search ---
// .collation({ locale: "en", strength: 2 })
// --- use this with find query to make case insensitive search ---