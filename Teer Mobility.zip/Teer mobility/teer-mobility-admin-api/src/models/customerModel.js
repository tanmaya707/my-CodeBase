const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;

const customerSchema = new mongoose.Schema(
  {
    userId: { type: ObjectId, ref: "usersCollection", required: true, default: null, },
    roleId: { type: ObjectId, ref: "roleCollection", required: false, default: null, },
    corporates: [
      {
        corporateId: { type: ObjectId, ref: "corporateCollection", required: false, default: null, },
        studentId: { type: ObjectId, ref: "usersCollection", required: false, default: null, },
      },
    ],

    // updatedBy: { type: ObjectId, ref: "usersCollection", required: true },
    isActive: { type: Boolean, default: true },
    isDeleted: { type: Boolean, default: false },
  },
  { timestamps: true }
);

module.exports = mongoose.model("customerCollection", customerSchema);
