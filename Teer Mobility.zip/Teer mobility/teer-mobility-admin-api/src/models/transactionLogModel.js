const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;

const transactionLogSchema = mongoose.Schema(
  {
    transactionId: { type: ObjectId, ref: "TransactionsCollection", required: true, default: null },

    request: { type: String, default: null },
    response: { type: String, default: null },
  },
  { timestamps: true }
);

module.exports = mongoose.model("TransactionLogCollection", transactionLogSchema);
