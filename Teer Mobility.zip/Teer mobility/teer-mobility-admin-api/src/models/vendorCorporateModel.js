const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;

// The vehicle/driver can be employed by different corporations/companies, and this information can be obtained through the route history, indicating which corporations/companies they have served. Therefore, it is not necessary to pre-assign them to all corporations/companies; they will be deployed as needed for trips ==== 

const vendorCorporateSchema = new mongoose.Schema(
  {
    // ======== as vendor is also a corporate ========
    vendorId: { type: ObjectId, ref: "corporateCollection", required: true, default: null, },
    // ======== as vendor is also a corporate ========
    corporateId: { type: ObjectId, ref: "corporateCollection", required: true, default: null, },

    isActive: { type: Boolean, default: true },
    isDeleted: { type: Boolean, default: false },
  },
  { timestamps: true }
);

module.exports = mongoose.model("vendorCorporateCollection", vendorCorporateSchema);
