const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;

const couponSchema = new mongoose.Schema(
    {
        corporateId: { type: ObjectId, ref: "corporateCollection", required: false, default: null, },

        couponCode: { type: String, required: [true, "Please enter coupon code"], },
        couponDesc: { type: String, required: false, },
        discountType: { type: String, required: true, default: "Flat" },
        discount: { type: Number, required: true, },
        maxDiscount: { type: Number, required: false, },
        effectiveFrom: { type: Date, required: true, default: null },
        expiry: { type: Date, required: true, default: null },

        isActive: { type: Boolean, default: true },
        isDeleted: { type: Boolean, default: false },
    },
    { timestamps: true }
); 

module.exports = mongoose.model("couponCollection", couponSchema);
