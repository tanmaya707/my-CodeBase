const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;

const vehicleModelSchema = mongoose.Schema(
  {
    type: { type: ObjectId, ref: "vehicleCategoriesCollection", required: true, default: null, },
    
    make: { type: String, required: true, default: null },
    model: { type: String, required: true, default: null },

    isActive: { type: Boolean, default: true },
    isDeleted: { type: Boolean, default: false },
  },
  { timestamps: true }
);
module.exports = mongoose.model("vehicleModelCollection", vehicleModelSchema);