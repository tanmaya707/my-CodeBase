const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;

const notificationSchema = mongoose.Schema(
  {
    userId: { type: ObjectId, ref: "usersCollection", required: true, default: null, },
    tripId: { type: ObjectId, ref: "tripsCollection", required: false, default: null, },

    title: { type:String, required: false, default: null },
    body: { type:String, required: false, default: null },

    isRead: { type: Boolean, required: false, default: false },

    isActive: { type: Boolean, default: true },
    isDeleted: { type: Boolean, default: false },
  },
  { timestamps: true }
);
module.exports = mongoose.model("notificationCollection", notificationSchema);
