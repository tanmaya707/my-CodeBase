const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;

const tripsSchema = mongoose.Schema(
  {
    tripPlanId: { type: ObjectId, ref: "tripPlanCollection", required: true, default: null, },
    vendorId: { type: ObjectId, ref: "corporateCollection", default: null, },
    driverId: { type: ObjectId, ref: "driverCollection", default: null, },
    vehicleId: { type: ObjectId, ref: "vehicleCollection", default: null, },
    tripDate: { type: Date, required: true, default: null },
    tripStartTime: { 
        type: String, 
        required: true,
        match: /^([01]\d|2[0-3]):([0-5]\d)$/, // Regular expression for HH:MM format
        default: null 
    },
    tripEndTime: { 
        type: String, 
        required: true,
        match: /^([01]\d|2[0-3]):([0-5]\d)$/, // Regular expression for HH:MM format
        default: null 
    },

    tripStatus: { type: String, enum: ["Pending" ,"Started", "Paused", "Resumed", "Completed"], required: false, default: "Pending" },

    isCancelled: { type: Boolean, default: false },
    isDelayed: { type: Boolean, default: false },
    delayedByTime: { 
        type: String, 
        match: /^([01]\d|2[0-3]):([0-5]\d)$/, // Regular expression for HH:MM format
        default: null 
    },

    isActive: { type: Boolean, default: true },
    isDeleted: { type: Boolean, default: false },
  },
  { timestamps: true }
);
module.exports = mongoose.model("tripsCollection", tripsSchema);
