const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;
const Decimal128 = mongoose.Schema.Types.Decimal128;

const walletLedgerSchema = mongoose.Schema(
  {
    walletId: { type: ObjectId, ref: "walletCollection", required: true, default: null },

    // amount: { type: Decimal128, default: "0.00" },
    amount: { type: Number, required: true, default: 0 },
    tranactionType: { type: String, enum: ["credit", "debit"], required: true, default: "credit" },

    gatewayName: { type: String, required: true, default: null },

    // currentBalance:{ type: Decimal128, default: "0.00" },
    currentBalance:{ type: Number, required: true, default: 0 },

    remarks:{ type: String, required: false, default: null },

    isActive: { type: Boolean, default: true },
    isDeleted: { type: Boolean, default: false },
  },
  { timestamps: true }
);

module.exports = mongoose.model("walletLedger", walletLedgerSchema);
