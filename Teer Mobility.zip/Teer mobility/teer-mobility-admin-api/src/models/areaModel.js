const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;

const areaSchema = mongoose.Schema(
  {
    countryId: {
      type: ObjectId,
      ref: "countryCollection",
      required: true,
      default: null,
    },

    state: {
      type: String,
      required: true,
      default: null,
    },
    city: {
      type: String,
      required: true,
      default: null,
    },
    regions: [
      {
        name: {
          type: String,
          required: true,
          default: null,
        },
        coordinates: {
          type: [Number],
          required: true,
          default: [0.0, 0.0],
        },
      },
    ],

    name: { type: String, required: true, default: null },
    iso: { type: String, required: true, default: null },
    iso3: { type: String, required: true, default: null },
    nicename: { type: String, required: true, default: null },
    phonecode: { type: Number, required: true, default: null },
    timezone: { type: String, required: true, default: null },
    currency: { type: String, required: true, default: null },
    flag: { type: String, required: true, default: null },
    cities: {
      name: {
        type: String,
        required: true,
        default: null,
      },
      state: {
        type: String,
        required: true,
        default: null,
      },
    },

    isActive: { type: Boolean, default: true },
    isDeleted: { type: Boolean, default: false },
  },
  { timestamps: true }
);
module.exports = mongoose.model("areaCollection", areaSchema);
