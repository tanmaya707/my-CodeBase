const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;

const EnquerySchema = mongoose.Schema(
  {
    userId: { type: ObjectId, ref: "usersCollection", required: true, default: null },

    // reason: { type: String, required: true, default: null },
    message: { type: String, required: true, default: null }, 
    replies: [{
      date: { type: Date, required: false, default: null },
      message: { type: String, required: false, default: null },
      repliedBy: { type: ObjectId, ref: "usersCollection", required: false, default: null },
    }],

  },
  { timestamps: true }
);
module.exports = mongoose.model("enqueryCollection", EnquerySchema);
