const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;

const routeMapSchema = mongoose.Schema(
  {
    countryCode: { type: ObjectId, ref: "countryCollection", required: true, default: null, },

    routeName: { type: String, required: true, default: null },
    routeDistance: { type: Number, required: true, default: null },
    routeTime: { type: Number, required: true, default: null },
    routeType: { type: String, required: true, default: null },
    routeStops: [{
      stopId: { type: ObjectId, ref: "tripStopCollection", required: true, default: null, },
      order: { type: Number, required: true, default: null, },
      distance: { type: Number, required: true, default: null, },
    }],

    isActive: { type: Boolean, default: true },
    isDeleted: { type: Boolean, default: false },
  },
  { timestamps: true }
);
module.exports = mongoose.model( "routeMapCollection", routeMapSchema );
