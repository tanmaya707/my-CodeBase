const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;
const validator = require("validator");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const crypto = require("crypto");

const driverSchema = new mongoose.Schema(
  {
    userId: { type: ObjectId, ref: "usersCollection", required: true, default: null, },

    employeeId: { type: String, required: false, default: null },
    
    isActive: { type: Boolean, default: true },
    isVerified: { type: Boolean, default: false },
    isVerifiedEmail: { type: Boolean, default: false },
    isVerifiedPhone: { type: Boolean, default: false },

    isDeleted: { type: Boolean, default: false },
  },
  { timestamps: true }
);

driverSchema.pre("save", async function (next) {
  if (!this.isModified("employeeId")) {
    next();
  }
  this.employeeId = Math.floor(10000000 + Math.random() * 90000000);
});

module.exports = mongoose.model("driverCollection", driverSchema);
