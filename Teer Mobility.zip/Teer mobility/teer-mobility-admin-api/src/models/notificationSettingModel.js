const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;

const notificationSettingSchema = mongoose.Schema(
  {
    userId: { type: ObjectId, ref: "UsersCollection", required: true, default: null },
    
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);
module.exports = mongoose.model("notificationSettingCollection", notificationSettingSchema);
