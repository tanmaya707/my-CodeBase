const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;

const moduleSchema = new mongoose.Schema(
    {
        // "parentId == null" signifies Top Level Menu  =====
        // "parentId != null" signifies Sub Menu ===== 
        // value of parentId defines which menu is under which top level menu ==== 
        parentModuleId: { type: ObjectId, ref: "moduleCollection", required: false, default: null },

        moduleName: {
            type: String,
            required: [true, "Please enter module name"],
        },
        moduleSlug: {
            type: String,
            required: false,
            default: null,
            unique: [true, "Module with same name already exists. Please choose an unique name."]
        }, 

        isActive: { type: Boolean, default: true },
        isDeleted: { type: Boolean, default: false },
        position: { type: Number, required: true }
    },
    { timestamps: true }
); 

moduleSchema.pre("save", async function (next) {
    // "/ /g" => global replacement of <space> to "_"
    this.moduleSlug = this.moduleName.toLowerCase().replace(/ /g, "-"); 
});

module.exports = mongoose.model("moduleCollection", moduleSchema);
