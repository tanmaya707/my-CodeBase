const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;

const generalSettingSchema = mongoose.Schema(
  {
    phone: {
        type: Number,
        unique: true,
        required: true,
        default: null,
    },
    email: { type: String, required: true, default: null },
    socialLinks: [{
        type: { type: String, required: true, default: null },
        url: { type: String, required: true, default: null }
    }],
  },
  { timestamps: true }
);
module.exports = mongoose.model("generalSettingCollection", generalSettingSchema);
