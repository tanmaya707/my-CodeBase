const mongoose = require("mongoose");
const moduleModel = require("./moduleModel");
const rolePermissionModel = require("./rolePermissionModel");
const roleModel = require("./rollModel");
const userModel = require("./userModel");

// => Eg. (1.Super Admin, 2.Admin user), (3.corporate, 4.corporate user), (5.company, 6.company user... also any other company role like accountant, vendor manager etc. as and when required), (7.vendor, 8.vendor user), (9.driver), (10.customer)… and any other user that we may need in future.
// Every user that can access the system must have a predefined role. Role cannot be blank for any user.

const roleSchema = mongoose.Schema(
  {
    name: { type: String, unique: true, required: true, default: null },

    isActive: { type: Boolean, default: true },
    isDeleted: { type: Boolean, default: false },
  },
  { timestamps: true }
);

// ======= post hook to create default blank module-permission in rolePermission ======
// roleSchema.post("save", async function (){
//   let roleId = this._id;

//   let superAdmin = await roleModel.findOne({
//     name: "Super Admin",
//   });
//   let userDetail = await userModel.findOne({
//     roleId: superAdmin._id
//   });
//   let dashboardModule = await moduleModel.findOne({
//     moduleSlug: "dashboard",
//   });

//   let modulesArr = [];
//   modulesArr.push(dashboardModule._id);

//   let data = {
//     roleId: roleId,
//     moduleId: modulesArr,
//     updatedBy: userDetail._id,
//   };

//   let result;
//   try {
//     let rolePermission = new rolePermissionModel(data);
//     result = await rolePermission.save();
//   } catch (error) {
//     return Promise.reject(err);
//   }
//   return result;
// });
// ======= post hook to create default blank module-permission in rolePermission ======

module.exports = mongoose.model("roleCollection", roleSchema);
