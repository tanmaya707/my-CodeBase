const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;

const routeVehicleSchema = new mongoose.Schema(
  {
    routeId: { type: ObjectId, ref: "routeMapCollection", required: true, default: null, },
    vehicleId: { type: ObjectId, ref: "vehicleCollection", required: true, default: null, },

    isActive: { type: Boolean, default: true },
    isDeleted: { type: Boolean, default: false },
  },
  { timestamps: true }
);

module.exports = mongoose.model("routeVehicleCollection", routeVehicleSchema);
