const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;

const smsGatewaySchema = mongoose.Schema(
  {
    countryId: {
      type: ObjectId,
      ref: "countryCollection",
      required: true,
      default: null,
    },
    name: { type: String, required: true, default: null },
    credentials: {
      accountSid: { type: String, required: true, default: null },
      authToken: { type: String, required: true, default: null },
    },

    isActive: { type: Boolean, default: true },
    isDeleted: { type: Boolean, default: false },
  },
  { timestamps: true }
);
module.exports = mongoose.model("smsGatewayCollection", smsGatewaySchema);
