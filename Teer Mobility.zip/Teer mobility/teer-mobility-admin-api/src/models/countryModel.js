const mongoose = require("mongoose");

const countrySchema = mongoose.Schema(
  {
    id: { type: Number, required: false, default: null },
	countryCode: { type: String, required: false, default: null },
    name: { type: String, required: true, default: null },
    iso2: { type: String, required: false, default: null },
    iso3: { type: String, required: false, default: null },
    numeric_code: { type: Number, required: false, default: null },
    phone_code: { type: Number, required: false, default: null },
    capital: { type: String, required: false, default: null },
    currency: { type: String, required: false, default: null },
    currency_name: { type: String, required: false, default: null },
    currency_symbol: { type: String, required: false, default: null },
    tld: { type: String, required: false, default: null },
    native: { type: String, required: false, default: null },
    region: { type: String, required: false, default: null },
    region_id: { type: Number, required: false, default: null },
    subregion: { type: String, required: false, default: null },
    subregion_id: { type: Number, required: false, default: null },
    nationality: { type: String, required: false, default: null },
    timezones: [
			{
				"zoneName": { type: String, required: false, default: null },
				"gmtOffset": { type: Number, required: false, default: null },
				"gmtOffsetName": { type: String, required: false, default: null },
				"abbreviation": { type: String, required: false, default: null },
				"tzName": { type: String, required: false, default: null },
			}
    ],
    translations: {
			"kr": { type: String, required: false, default: false, },
			"pt-BR": { type: String, required: false, default: false, },
			"pt": { type: String, required: false, default: false, },
			"nl": { type: String, required: false, default: false, },
			"hr": { type: String, required: false, default: false, },
			"fa": { type: String, required: false, default: false, },
			"de": { type: String, required: false, default: false, },
			"es": { type: String, required: false, default: false, },
			"fr": { type: String, required: false, default: false, },
			"ja": { type: String, required: false, default: false, },
			"it": { type: String, required: false, default: false, },
			"cn": { type: String, required: false, default: false, },
			"tr": { type: String, required: false, default: false, },
    },
    latitude: { type: Number, required: false, default: null },
    longitude: { type: Number, required: false, default: null },
    emoji: { type: String, required: false, default: null },
    emojiU: { type: String, required: false, default: null },
    states: [
			{
				"id": { type: Number, required: false, default: null },
				"name": { type: String, required: false, default: null },
				"state_code": { type: String, required: false, default: null },
				"latitude": { type: Number, required: false, default: null },
				"longitude": { type: Number, required: false, default: null },
				"type": { type: String, required: false, default: null },
				"cities": [
					{
						"id": { type: Number, required: false, default: null },
						"name": { type: String, required: false, default: null },
						"latitude": { type: String, required: false, default: null },
						"longitude": { type: String, required: false, default: null },
					}
				],
			}
    ],

    isActive: { type: Boolean, default: true },
    isDeleted: { type: Boolean, default: false },
  },
  { timestamps: true }
);
module.exports = mongoose.model("countryCollection", countrySchema);
