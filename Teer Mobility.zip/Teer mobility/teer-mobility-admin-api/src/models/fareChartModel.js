const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;

const fareChartSchema = new mongoose.Schema(
    {
        countryId: { type: ObjectId, ref: "corporateCollection", required: false, default: null, },

        baseFare: { type: Number, required: [true, "Please enter base fare"], },
        forFirstHowManyKm: { type: Number, required: true, default: 0 },
        farePerExtraKm: { type: Number, required: true, default: 0 },

        isActive: { type: Boolean, default: true },
        isDeleted: { type: Boolean, default: false },
    },
    { timestamps: true }
); 

module.exports = mongoose.model("fareChartCollection", fareChartSchema);
