const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;
const transactionSchema = mongoose.Schema(
  {
    userId: { type: ObjectId, ref: "usersCollection", required: true },

    // paymentId: { type: String, default: null },
    paymentGatewayOrderId: { type: String, default: null },
    paidVia: { type: String, default: null },

    type: { type: String, enum: ["walletRecharge", "tripPayment", "refund"], default: "walletRecharge" },
    signature: { type: String, default: null },

    paidAmount: { type: Number, required: true, default: null },
    paidCurrency: { type: String, required: true, default: "INR" },
    
    paymentDate: { type: Date, required: true, default: null },
    paymentStatus: { type: String, enum: ["Pending", "Paid", "Failed"], default: "Pending", required: true, default: null },
    
    remark: { type: String, default: null },

    isActive: { type: Boolean, default: true },
    isDeleted: { type: Boolean, default: false },
  },
  { timestamps: true }
);
module.exports = mongoose.model("TransactionsCollection", transactionSchema);
