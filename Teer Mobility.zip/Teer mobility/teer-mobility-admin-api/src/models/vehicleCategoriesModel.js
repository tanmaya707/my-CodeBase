const mongoose = require("mongoose");

const vehicleCategoriesSchema = mongoose.Schema(
  {
    type: { type: String, unique: true, required: true, default: null },

    isActive: { type: Boolean, default: true },
    isDeleted: { type: Boolean, default: false },
  },
  { timestamps: true }
);
module.exports = mongoose.model("vehicleCategoriesCollection", vehicleCategoriesSchema);