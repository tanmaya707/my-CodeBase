const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;

const routeStatusSchema = mongoose.Schema(
  {
    corporateId: { type: ObjectId, ref: "corporateCollection", required: true, default: null, },
    vehicleId: { type: ObjectId, ref: "vehicleCollection", required: true, default: null, },
    driverId: { type: ObjectId, ref: "driverCollection", required: true, default: null, },
    routeId: { type: ObjectId, ref: "routeCollection", required: true, default: null, },

    slotType: { type: String, required: true, default: "Regular" },

    startTime: { type: Date, required: true, default: null },
    endTime: { type: Date, required: true, default: null },
    
    actualTripStartTime: { type: Date, required: true, default: null },
    actualTripEndTime: { type: Date, required: true, default: null },

    attendanceType: { type: String, required: true, default: null },
    additionalDetails: { type: String, required: true, default: null },
    
    status: { type: String, required: true, default: null },
    payment: { 
        payer:{ type: String, required: true, default: null },
        paymentType:{ type: String, required: true, default: null },
        currency:{ type: String, required: true, default: null },
    },
    stops: [
        {
            stopId: { type: ObjectId, ref: "tripStopCollection", required: true, default: null, },
            // fixed time ===================
            stopTime: { type: Date, reequired: false, default: null },
            // actual time => from GPS ======
            actualTime: { type: Date, reequired: false, default: null },
            users: [
                {
                    userId: { type: ObjectId, ref: "usersCollection", required: true, default: null, },
                    name: { type: String, required: false, default: null },
                    stopType: { type: String, required: false, default: null },
                    attendance: { type: String, required: false, default: null },
                    attendanceTime: { type: Date, required: false, default: null },
                }
            ],

        }
    ],
    locationTracking: [
        {
            address: { type: String, required: true, default: null },
            speed: { type: Number, required: true, default: null },
            accuracy: { type: Number, required: true, default: null },
            ignitionStatus: { type: String, required: true, default: null },
            acStatus: { type: String, required: true, default: null },
            odometerKm: { type: Number, required: true, default: null },
            fuel: { type: Number, required: true, default: null },
            coordinates: {
                type: Number,
                required: true,
                default: [0.0, 0.0],
            },
            timestamp: { type: Date, required: false, default: null },
        }
    ],
    // eg.: -2 => means => you can book before this many hours
    preBookingTime: { type: Number, required: true, default: null },

    isActive: { type: Boolean, default: true },
    isDeleted: { type: Boolean, default: false },
  },
  { timestamps: true }
);
module.exports = mongoose.model("routeStatusCollection", routeStatusSchema);
