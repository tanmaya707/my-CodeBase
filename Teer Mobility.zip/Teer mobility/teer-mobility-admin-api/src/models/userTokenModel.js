const mongoose = require('mongoose');
const ObjectId = mongoose.Schema.Types.ObjectId;
const validator = require('validator');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');

const userTokenSchema = new mongoose.Schema({
    userId: { type: ObjectId, ref: "UsersCollection", required: true, default: null },
    
    deviceToken: { type: String, required: false, default: null },
    deviceType: {
        type: String, 
        enum: ["1", "2", "3"], 
        default: "3",
        // 1- Android, 2-IOS, 3-Web
    },
    accessToken: { type: String, required: false, default: null },
},
    { timestamps: true }
);

module.exports = mongoose.model('UserTokenCollection', userTokenSchema)