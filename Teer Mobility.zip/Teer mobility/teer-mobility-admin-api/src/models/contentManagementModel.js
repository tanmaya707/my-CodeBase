const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;

const contentManagementSchema = mongoose.Schema(
  {
    contentManagementHeading: { type: String, required: true, default: null },
    contentManagementDescription: { type: String, required: true, default: null },
    contentImage: {
      type: String,
      required: [true, "Please upload content image"],
    },

    isActive: { type: Boolean, default: true },
    isDeleted: { type: Boolean, default: false },
  },
  { timestamps: true }
);
module.exports = mongoose.model("contentManagementCollection", contentManagementSchema);
