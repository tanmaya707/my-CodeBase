const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;

const WalletSchema = mongoose.Schema(
  {
    userId: { type: ObjectId, ref: "usersCollection", required: true, default: null },

    amount: { type: Number, required: true, default: 0 },
    currency: { type: String, required: true, default: "INR" },
  },
  { timestamps: true }
);
module.exports = mongoose.model("walletCollection", WalletSchema);
