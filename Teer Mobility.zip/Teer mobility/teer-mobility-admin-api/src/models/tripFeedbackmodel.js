const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;
const validator = require("validator");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const crypto = require("crypto");

const tripFeedbackSchema = new mongoose.Schema(
  {
    userId: { type: ObjectId, ref: "usersCollection", required: true, default: null, },
    tripId: { type: ObjectId, ref: "tripsCollection", required: true, default: null, },

    review: { type: String, required: false, default: null },
    
    isDeleted: { type: Boolean, default: false },
  },
  { timestamps: true }
);


module.exports = mongoose.model("tripFeedbackCollection", tripFeedbackSchema);
