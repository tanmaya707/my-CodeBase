const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;
const validator = require("validator");

const studentSchema = new mongoose.Schema(
  {
    userId: { type: ObjectId, ref: "usersCollection", required: true, default: null, },
    schoolId: { type: ObjectId, ref: "corporateCollection", required: true, default: null, },
    parentUserId: { type: ObjectId, ref: "usersCollection", required: true, default: null },
    routeId: { type: ObjectId, ref: "routeMapCollection", required: false, default: null },

    studentClass: { type: String, required: false, default: null },
    studentSection: { type: String, required: false, default: null },

    isVerified: { type: Boolean, default: false },
    isVerifiedEmail: { type: Boolean, default: false },
    isVerifiedPhone: { type: Boolean, default: false },
    
    isActive: { type: Boolean, default: true },
    isDeleted: { type: Boolean, default: false },
  },
  { timestamps: true }
);

module.exports = mongoose.model("studentCollection", studentSchema);
