const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;

const corporateUserSchema = new mongoose.Schema(
  {
    userId: { type: ObjectId, ref: "usersCollection", required: true, default: null, },
    corporateId: { type: ObjectId, ref: "corporateCollection", required: true, default: null, },
    // updatedBy: { type: ObjectId, ref: "usersCollection", required: true },
    isActive: { type: Boolean, default: true },
    isDeleted: { type: Boolean, default: false },
  },
  { timestamps: true }
);

module.exports = mongoose.model("corporateUserCollection", corporateUserSchema);
