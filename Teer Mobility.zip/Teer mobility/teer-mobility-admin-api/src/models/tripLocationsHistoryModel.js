const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;

const tripLocationsHistorySchema = mongoose.Schema(
  {
    tripId: { type: ObjectId, ref: "tripsCollection", required: true, default: null, },

    locationHistory: [
      {
        driverId: { type: ObjectId, ref: "driverCollection", required: true, default: null, },

        // ==== location parameters ====
        address: { type: String, required: false, default: null },
        coordinates: { type: [Number], required: false, default: [0.0, 0.0], },
        // ==== location parameters ====
        
        // ==== vehicle parameters ====
        speed: { type: Number, required: false, default: 0 },
        ignitionStatus: { type: Boolean, required: false, default: false },
        acStatus: { type: Boolean, required: false, default: false },
        odometerKm: { type: Number, required: false, default: 0 },
        fuel: { type: Number, required: false, default: 0 },
        // ==== vehicle parameters ====
        
        source: { type: String, enum: ["Web", "App",], default: "App" },
        
        accuracy: { type: Number, required: false, default: null },
        
        feedTime: { type: Date, required: true, default: null },
      }
    ],

  },
  { timestamps: true }
);

module.exports = mongoose.model("tripLocationsHistoryCollection", tripLocationsHistorySchema);
