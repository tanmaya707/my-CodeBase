const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;

const vehicleSchema = mongoose.Schema(
  {
    modelId: { type: ObjectId, ref: "vehicleModelCollection", required: true, default: null, },
    assets: [{ type: ObjectId, ref: "assetCollection", required: false, default: null, }],
    
    seatingArrangement: { type: String, required: false, default: null },
    capacity: { type: String, required: false, default: null },
    
    registrationNumber: { type: String, unique: [true, "Duplicate Registration No"], required: true, default: null },
    chassisNumber: { type: String, unique: true, required: true, default: null },
    manufacturerDate: { type: Date, required: false, default: null },
    imagePath : { type: String, required: false, default: null },

    isAC: { type: Boolean, default: true },

    isActive: { type: Boolean, default: true },
    isDeleted: { type: Boolean, default: false },
  },
  { timestamps: true }
);
module.exports = mongoose.model("vehicleCollection", vehicleSchema);