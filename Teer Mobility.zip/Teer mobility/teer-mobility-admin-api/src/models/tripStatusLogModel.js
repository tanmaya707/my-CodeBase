const mongoose = require("mongoose");
const tripsModel = require("./tripsModel");
const ObjectId = mongoose.Schema.Types.ObjectId;

const tripStatusLogSchema = mongoose.Schema(
  {
    tripId: { type: ObjectId, ref: "tripsCollection", required: true, default: null, },
    passengerId: { type: ObjectId, ref: "usersCollection", required: false, default: null, },
    stopId: { type: ObjectId, ref: "tripStopCollection", required: false, default: null, },

    coOrdinates: {
      type: [Number],
      required: false,
      default: [0.0, 0.0],
    },
    inTime: { type: String, required: false, default: null },
    outTime: { type: String, required: false, default: null },

    status: { type: String, enum: ["Started", "Paused", "Onboarding", "DropOff", "Completed"], required: false, default: "Pending" },

    isActive: { type: Boolean, default: true },
    isDeleted: { type: Boolean, default: false },
  },
  { timestamps: true }
);

// tripStatusLogSchema.post("save", async function (next) {
//   if (this.status == "Started") {
//     await tripsModel.updateOne(this.tripId, {
//       tripStatus: "Started"
//     });
//   } else if (this.status == "Paused") {
//     await tripsModel.updateOne(this.tripId, {
//       tripStatus: "Paused"
//     });
//   } else if (this.status == "Completed") {
//     await tripsModel.updateOne(this.tripId, {
//       tripStatus: "Completed"
//     });
//   }
// });

module.exports = mongoose.model("tripStatusLogCollection", tripStatusLogSchema);
