const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;

const termsAndConditionsSchema = mongoose.Schema(
  {
    termsAndConditionsHeading: { type: String, required: true, default: null },
    termsAndConditionsDescription: { type: String, required: true, default: null },

    isActive: { type: Boolean, default: true },
    isDeleted: { type: Boolean, default: false },
  },
  { timestamps: true }
);
module.exports = mongoose.model("termsAndConditionsCollection", termsAndConditionsSchema);
