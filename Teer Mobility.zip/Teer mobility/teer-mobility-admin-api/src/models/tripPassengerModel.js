const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;

const tripPassengerSchema = mongoose.Schema(
  {
    userId: { type: ObjectId, ref: "usersCollection", required: true, default: null, },
    serviceId: { type: ObjectId, ref: "roleCollection", required: true, default: null },
    
    tripId: { type: ObjectId, ref: "tripsCollection", required: true, default: null, },
    pickupStopId: { type: ObjectId, ref: "tripStopCollection", required: true, default: null, },
    dropStopId: { type: ObjectId, ref: "tripStopCollection", required: true, default: null, },

    bookingLocation: { type: String, required: false, default: null },
    coordinates: {
      type: [Number],
      required: false,
      default: [0.0, 0.0],
    },
    
    bookingDate: { type: Date, required: false, default: null },
    numberOfSeats: { type: Number, required: false, default: 1 },
    payment: { 
      paymentMode: { type: String, enum: ["online", "wallet", "coupon"], default: "wallet" },
      payableAmount: { type: Number, required: false, default: 0 },
      currency:{ type: String, required: false, default: null },
    },
    couponCode: { type: String, required: false, default: null },
    
    otp: { type: Number, required: false, default: null },

    pickupReachTime: { type: Date, required: false, default: null },
    dropoffReachTime: { type: Date, required: false, default: null },

    isCancelled: { type: Boolean, default: false },
    cancellationReason: { type: String, required: false, default: null },

    isActive: { type: Boolean, default: true },
    isDeleted: { type: Boolean, default: false },
  },
  { timestamps: true }
);
module.exports = mongoose.model("tripPassengerCollection", tripPassengerSchema);
