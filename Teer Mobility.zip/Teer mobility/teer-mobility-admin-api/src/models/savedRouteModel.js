const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;

const savedRouteSchema = mongoose.Schema(
  {
    userId: { type: ObjectId, ref: "usersCollection", required: true, default: null, },
    pickupStopId: { type: ObjectId, ref: "tripStopCollection", required: true, default: null, },
    dropStopId: { type: ObjectId, ref: "tripStopCollection", required: true, default: null, },
    isDeleted: { type: Boolean, default: false },
  },
  { timestamps: true }
);

module.exports = mongoose.model(
  "savedRouteCollection",
  savedRouteSchema
);
