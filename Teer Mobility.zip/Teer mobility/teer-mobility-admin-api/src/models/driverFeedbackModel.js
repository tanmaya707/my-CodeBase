const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;
const validator = require("validator");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const crypto = require("crypto");

const driverFeedbackSchema = new mongoose.Schema(
  {
    userId: { type: ObjectId, ref: "usersCollection", required: true, default: null, },
    tripId: { type: ObjectId, ref: "tripsCollection", required: true, default: null, },
    driverId: { type: ObjectId, ref: "driverCollection", default: null, },
    rating: { type: Number, required: true, default: null },
    feedback: {
        value: {
          type: String,
          required: true,
          default: null,
        },
        weight: {
            type: Number,
            required: true,
            default: null,
        }
    },
    isDeleted: { type: Boolean, default: false },
  },
  { timestamps: true }
);


module.exports = mongoose.model("driverFeedbackCollection", driverFeedbackSchema);
