const mongoose = require("mongoose");

const tempOtpSchema = mongoose.Schema(
  {
    email: { type: String, required: false, },
    phone: { type: Number, required: true, },
    otp: {
      code: {
        type: Number,
        required: true,
        default: null,
      },
      expiration: {
        type: Date,
        default: null,
      },
    },

    isActive: { type: Boolean, default: true },
    isDeleted: { type: Boolean, default: false },
  },
  { timestamps: true }
);
module.exports = mongoose.model("tempOtpCollection", tempOtpSchema);
