const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;

const recentSearchesSchema = mongoose.Schema(
    {
        userId: { type: ObjectId, ref: "usersCollection", required: true },
        stopId: { type: ObjectId, ref: "tripStopCollection", required: true },

        isActive: { type: Boolean, default: true },
        isDeleted: { type: Boolean, default: false },
    },
    { timestamps: true }
);

module.exports = mongoose.model("recentSearchesCollection", recentSearchesSchema)