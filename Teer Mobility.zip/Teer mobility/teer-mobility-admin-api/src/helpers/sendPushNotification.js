const axios = require("axios");
const { google } = require("googleapis");
const FirebaseAdmin = require("firebase-admin");
const FCMServiceAccount = require("../config/serviceAccountKey.json");

const FCM = FirebaseAdmin.initializeApp({
  credential: FirebaseAdmin.credential.applicationDefault(),
});

module.exports = async (deviceToken, message, deviceType) => {
  try {
    if (!deviceToken || !deviceType) {
      throw new Error('Device token or device type is missing.');
    }

    let notificationMessage = {
      message: {
        token: deviceToken,
      },
    };
    let msg = JSON.parse(message.body);
    notificationMessage.message.data = msg;
    notificationMessage.message.notification = {
      title: message.title,
      body: (msg.msg)?msg.msg:''
    };
      
    // if(message.type == "Hidden"){
    //   notificationMessage.message.data = {
    //     title: message.title,
    //     body: message.body,
    //     type: message.type,
    //     tripId: message.tripId,
    //     coordinates: message.coordinates,
    //     driverLat: message.driverLat,
    //     driverLong: message.driverLong,
    //   }
    // } else {
    //   notificationMessage.message.notification = {
    //     title: message.title,
    //     body: message.body,
    //   }
    // }

    const jwtClient = new google.auth.JWT(
      FCMServiceAccount.client_email,
      null,
      FCMServiceAccount.private_key,
      ["https://www.googleapis.com/auth/firebase.messaging"],
      null
    );

    const tokens = await jwtClient.authorize();
    const accessToken = tokens.access_token;

    const config = {
      method: "post",
      url: `https://fcm.googleapis.com/v1/projects/${FCMServiceAccount.project_id}/messages:send`,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${accessToken}`,
      },
      data: notificationMessage,
    };

    const response = await axios(config);
    console.log("FCM response:", response.data);

    return response.data; // Return FCM response data

  } catch (error) {
    if (error.response) {
      // The request was made and the server responded with a status code
      console.error("FCM Error Response Data:", error.response.data);
      console.error("FCM Error Response Status:", error.response.status);
      console.error("FCM Error Response Headers:", error.response.headers);
    } else if (error.request) {
      // The request was made but no response was received
      console.error("FCM No Response:", error.request);
    } else {
      // Something happened in setting up the request that triggered an Error
      console.error("FCM Error:", error.message);
    }
    throw error; // Ensure the error is propagated if not handled (For any other error types not handled above)
  }
};
