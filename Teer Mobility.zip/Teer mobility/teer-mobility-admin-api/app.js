const express = require("express");
const app = express();
const axios = require("axios");
const morgan = require("morgan");
const cors = require("cors");
const errorMiddleware = require("./src/middleware/error");
const cookieParser = require("cookie-parser");
const expressFileUpload = require("express-fileupload");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const path = require("path");
const cron = require("node-cron");
const moment = require("moment-timezone");
const dateFns = require("date-fns");

const routeMapModel = require("./src/models/routeMapModel");
const corporateModel = require("./src/models/corporateModel");
const tripPlanModel = require("./src/models/tripPlanModel");
const tripsModel = require("./src/models/tripsModel");
const tripPassengerModel = require("./src/models/tripPassengerModel");
const rollModel = require("./src/models/rollModel");

const {
  calculateDistance,
  calculateDistanceInsTentApi,
  calculateTimeInKilometers,
  getRateChartCategory,
  dateFormatDDMMYYYY,
  dateFormatYYYYMMDD,
	dateFormat,
} = require("./src/utils/utilities");

// require('./src/routes/authenticationRoute')(app)
// require('./src/routes/userRoute')(app)

// app.use(express.json({ limit: "50mb" }))
// CORS configuration
// const corsOptions = {
//   origin: "*", // Allow all origins
//   methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"], // Allowed methods
//   allowedHeaders: ["Content-Type", "Authorization", "X-Requested-With"], // Allowed headers
// };

// Use the CORS middleware with options
// app.use(cors(corsOptions));

app.use(express.json());
/*************** Morgan Log Configuration ****************/
if (process.env.APP_ENV == "production") {
  app.use(morgan("combined"));
}
if (process.env.APP_ENV == "development") {
  app.use(morgan("dev"));
}
// app.use(express.urlencoded({ limit: "50mb", extended: true }))
app.use(
  express.urlencoded({
    extended: true,
  })
);

app.use(cookieParser());
app.use(expressFileUpload({ parseNested: true }));
app.use(cors());
app.all("/*", function (req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "X-Requested-With");
  res.header("Cross-Origin-Resource-Policy", "cross-origin");
  next();
});
app.use(
  helmet({
    // contentSecurityPolicy: false,
    // crossOriginOpenerPolicy: false,
    // crossOriginEmbedderPolicy: false,
    contentSecurityPolicy: true,
    crossOriginOpenerPolicy: true,
    crossOriginEmbedderPolicy: true,
  })
);

// app.use('./public/uploads', express.static('uploads'))

// =================== express-rate-limit ===================
const limiter = rateLimit({
  windowMs: 1 * 1000, // 1 minutes
  // max: 100, // limit each IP to 100 requests per windowMs
  max: 500, // limit each IP to 500 requests per windowMs
  message: "Too many requests from this IP, please try again later.",
});
app.use(limiter);
// ========== error handling for rateLimit exceeded ============
app.use((err, req, res, next) => {
  if (err instanceof rateLimit.RateLimitError) {
    // Handle rate limit exceeded error
    res.status(429).send("Rate limit exceeded");
  } else {
    next(err);
  }
});
// ========== error handling for rateLimit exceeded ============
// =================== express-rate-limit ===================

app.use("/", require("./src/routes/attendanceRoute"));
app.use("/", require("./src/routes/authenticationRoute"));
app.use("/", require("./src/routes/rolePermissionRoute"));
app.use("/", require("./src/routes/countryRoute"));
app.use("/", require("./src/routes/moduleRoute"));
app.use("/", require("./src/routes/userRoute"));
app.use("/", require("./src/routes/assetRoute"));
app.use("/", require("./src/routes/vehicleRoute"));
app.use("/", require("./src/routes/corporateRoute"));
app.use("/", require("./src/routes/driverRoute"));
app.use("/", require("./src/routes/tripStopRoute"));
app.use("/", require("./src/routes/routeMapRoute"));
app.use("/", require("./src/routes/couponRoute"));
app.use("/", require("./src/routes/termsAndConditionsRoute"));
app.use("/", require("./src/routes/privacyPolicyRoute"));
app.use("/", require("./src/routes/contentManagementRoute"));
app.use("/", require("./src/routes/tripPlanRoute"));
app.use("/", require("./src/routes/tripsRoute"));
app.use("/", require("./src/routes/settingRoute"));
app.use("/", require("./src/routes/walletRoute"));
app.use("/", require("./src/routes/bookingRoute"));
app.use("/", require("./src/routes/notificationRoute"));
app.use("/", require("./src/routes/supportRoute"));
app.use("/", require("./src/routes/transactionHistoryRoute"));
app.use("/", require("./src/routes/employeeRoute"));
app.use("/", require("./src/routes/studentRoute"));
app.use("/", require("./src/routes/corporateUserRoute"));

app.use("src/public/uploads", express.static("uploads"));
// app.use('./public/uploads/userImages', express.static('userImages'))
// app.use('./public/uploads/vehicles', express.static('vehicles'))

// app.get('/', function (req, res) {
//     res.send("Home Page")
// })

// ============================= CRON TO CREATE TRIPS START =============================
cron.schedule(
  "*/10 * * * * *",
  async function () {
		// ====================================================================================
		// ---------------------- DO NOT DELETE STRATEGIC console.logs() ----------------------
		// ====================================================================================
    // console.log("cron running");
		// Get the current time in "Asia/Kolkata" time zone =======
    let momentKolkata = moment().tz('Asia/Kolkata');
    let currentDate = momentKolkata.format('YYYY-MM-DD');
	  let currentDay = momentKolkata.format('dddd');
    let currentTime = momentKolkata.format('HH:mm');
		// Get the current time in "Asia/Kolkata" time zone =======

		let tripPlans = await tripPlanModel.find(
			{
				isActive: true,
				isDeleted: false,
				isCancelled: false,
			}
		);
		await routeMapModel.populate(
			tripPlans,
			[
				{
					path: "routeId",
					model: "routeMapCollection"
				},
				{
					path: "vendorId",
					model: "corporateCollection"
				},
			]
		);

		tripPlans.forEach(async (tripPlan)=>{
			tripPlan.schedule.forEach(async (day)=>{

				if(tripPlan.tripType == "Daily"){
					let nextDay = currentDate
					// ====== Loop through 7 days and create trips ===========
					for(let d=1; d<=7; d++){

						let data = {
							tripPlanId: tripPlan._id,
							vendorId: tripPlan?.vendorId?._id,
							tripDate: nextDay,
							tripStartTime: day.startTime,
							tripEndTime: day.endTime,
						};
            if(tripPlan?.corporateId){
              data.driverId = tripPlan?.driverId;
							data.vehicleId = tripPlan?.vehicleId;
            }

						let checkExist = await tripsModel.findOne({
							tripPlanId: tripPlan._id,
							vendorId: tripPlan?.vendorId?._id,
							tripDate: nextDay,
							tripStartTime: day.startTime,
							tripEndTime: day.endTime,
						});
						if(!checkExist){
							const document = new tripsModel(data);
							let createTrip = await document.save();
						} else {
							// console.log("Daily Trip Already created...");
              if(tripPlan?.corporateId){
                let updateFields = {
                  driverId: tripPlan?.driverId,
                  vehicleId: tripPlan?.vehicleId
                };
                let updateTrip = await tripsModel.findByIdAndUpdate(
                  checkExist?._id,
                  updateFields,
                  {
                    new: true, // Return the updated document instead of the old one
                    runValidators: true, // Run the model's validators on update
                  }
                );
              }
						}
						// Add one day to the current date ==========
						nextDay = moment(nextDay).add(1, 'days').format('YYYY-MM-DD');

					}
					// ====== Loop through 7 days and create trips ===========

				} else if(tripPlan.tripType == "Customized"){
					let nextDay = currentDate
					// ====== Loop through 7 days and create trips ===========
					for(let d=1; d<=7; d++){
						// Get the day of the week for the nextDay date ====
						let currentDay = moment(nextDay).format('dddd');
						// Get the day of the week for the nextDay date ====
						if(currentDay == day.dayName){
							let data = {
								tripPlanId: tripPlan._id,
								vendorId: tripPlan.vendorId._id,
								tripDate: nextDay,
								tripStartTime: day.startTime,
								tripEndTime: day.endTime,
							};
              if(tripPlan?.corporateId){
                data.driverId = tripPlan?.driverId;
                data.vehicleId = tripPlan?.vehicleId;
              }
              
							let checkExist = await tripsModel.findOne({
								tripPlanId: tripPlan._id,
								vendorId: tripPlan.vendorId._id,
								tripDate: nextDay,
								tripStartTime: day.startTime,
								tripEndTime: day.endTime,
							});
							if(!checkExist){
								const document = new tripsModel(data);
								let createTrip = await document.save();
							} else {
								// console.log("Customized Trip Already created...");
                if(tripPlan?.corporateId){
                  let updateFields = {
                    driverId: tripPlan?.driverId,
                    vehicleId: tripPlan?.vehicleId
                  };
                  let updateTrip = await tripsModel.findByIdAndUpdate(
                    checkExist?._id,
                    updateFields,
                    {
                      new: true, // Return the updated document instead of the old one
                      runValidators: true, // Run the model's validators on update
                    }
                  );
                }
							}
						} else {
							// console.log("Day does not match, Skipping...");
						}

						// Add one day to the current date ==========
						nextDay = moment(nextDay).add(1, 'days').format('YYYY-MM-DD');
					}
					// ====== Loop through 7 days and create trips ===========
				}
				else if(tripPlan.tripType == "OneTime"){
					let nextDay = currentDate
					// ====== Loop through 7 days and create trips ===========
					for(let d=1; d<=7; d++){
						// Get the day of the week for the nextDay date ====
						let currentDay = moment(nextDay).format('dddd');
						// Get the day of the week for the nextDay date ====

						// subtract seven days from the oneTimeDate ==========
						let sevenDaysBeforeOneTimeDate = moment(day.oneTimeDate).subtract(7, 'days').format('YYYY-MM-DD');

						let dayDifference = moment(currentDate).diff(sevenDaysBeforeOneTimeDate, 'days');
						// console.log("dayDifference ======> ");
						// console.log(dayDifference);
						// console.log(typeof(dayDifference)); return;
						if(
							// currentDate == sevenDaysBeforeOneTimeDate
							dayDifference <= 7
						){
							if(currentDay == day.dayName){
								let data = {
									tripPlanId: tripPlan._id,
									vendorId: (tripPlan.vendorId)?tripPlan.vendorId._id:null,
									tripDate: nextDay,
									tripStartTime: day.startTime,
									tripEndTime: day.endTime,
								};
                if(tripPlan?.corporateId){
                  data.driverId = tripPlan?.driverId;
                  data.vehicleId = tripPlan?.vehicleId;
                }

								let checkExist = await tripsModel.findOne({ tripPlanId: tripPlan._id });
								if(!checkExist){
									const document = new tripsModel(data);
									let createTrip = await document.save();

								} else {
									// console.log("One TIme Trip Already created...");
                  if(tripPlan?.corporateId){
                    let updateFields = {
                      driverId: tripPlan?.driverId,
                      vehicleId: tripPlan?.vehicleId
                    };
                    let updateTrip = await tripsModel.findByIdAndUpdate(
                      checkExist?._id,
                      updateFields,
                      {
                        new: true, // Return the updated document instead of the old one
                        runValidators: true, // Run the model's validators on update
                      }
                    );
                  }
								}
							} else {
								// console.log("Day does not match, Skipping...");
							}
						}

						// Add one day to the current date ==========
						nextDay = moment(nextDay).add(1, 'days').format('YYYY-MM-DD');
					}
					// ====== Loop through 7 days and create trips ===========
				}

			});

		});

    // ======= assign regular passengers =======
    let todayTrips = await tripsModel.find({
      tripDate: currentDate,
      isCancelled: false,
      isDeleted: false,
    });
    if(todayTrips.length > 0){
      // if there is trips today ===
      let todayTripsIdsArr = [];
      let todayTripsIdsWithTripPlanIdsArr = [];
      todayTrips.forEach((todayTrip)=>{
        todayTripsIdsArr.push(todayTrip._id);
        let obj = {
          tripId: todayTrip._id,
          tripPlanId: todayTrip.tripPlanId,
        };
        todayTripsIdsWithTripPlanIdsArr.push(obj);
      });

      // finding tripPassengers of today's trips who are Employee or Student and not individual =====
      let roleOfEmployeeOrStudent = await rollModel.find({
        name: {
          $in : ["Employee", "Student"]
        }
      });
      let eligibleServiceIdsArr = [];
      roleOfEmployeeOrStudent.forEach((role)=>{
        eligibleServiceIdsArr.push(role._id);
      });

      let todayTripPassengers = await tripPassengerModel.find({
        serviceId: {
          $in: eligibleServiceIdsArr
        },
        tripId: {
          $in: todayTripsIdsArr
        },
        isCancelled: false,
      }).populate([
        {
          "path": "tripId",
          "model": "tripsCollection",
          "populate": {
            "path": "tripPlanId",
            "model": "tripPlanCollection",
          }
        }
      ]);

      // console.log("todayTripPassengers ====>");
      // console.log(todayTripPassengers);

      // =============================
      // ==== Disaster management ====
      // =============================
      // =================== make todayTripPassengers as an unique array ===================
      let uniqueTodayTripPassengers = [...new Set(todayTripPassengers)];
      // console.log("uniqueTodayTripPassengers ===>");
      // console.log(uniqueTodayTripPassengers);

      // =================== make todayTripPassengers as an unique array ===================
      // =============================
      // ==== Disaster management ====
      // =============================

      let upcomingTrips = await tripsModel.find({
        tripDate: {
          $gt: currentDate
        },
        isCancelled: false,
        isDeleted: false,
      }).populate([
        {
          "path": "tripPlanId",
          "model": "tripPlanCollection"
        },
      ]);
      // console.log("upcomingTrips ======>");
      // console.log(upcomingTrips);

      // looping over upcoming trips to assign passengers automatically ===
      upcomingTrips.forEach(async (upcomingTrip)=>{
        // looping over uniqueTodayTripPassengers to match and check which passgengers tripPlanId matches with upcoming trip's planId =====
        uniqueTodayTripPassengers.forEach(async (todayTripPassenger)=>{
          if(
            upcomingTrip?.tripPlanId?._id.toString() == todayTripPassenger?.tripId?.tripPlanId?._id.toString()
          ){
            // ============ random OTP generation ============
            let otp = Math.floor(1000 + Math.random() * 9000);
            // ============ random OTP generation ============
            let tripPassengerAssignData = {
              userId: todayTripPassenger.userId,
              serviceId: todayTripPassenger.serviceId,

              tripId: upcomingTrip._id,
              pickupStopId: todayTripPassenger.pickupStopId,
              dropStopId: todayTripPassenger.dropStopId,

              bookingDate: upcomingTrip.tripDate,
              // ==== trip OTP ====
              otp: otp,
              // ==== trip OTP ====
            };

            // ====== check whether passenger already assigned to the trip ======
            let checkTripPassengerExist = await tripPassengerModel.findOne({
              userId: todayTripPassenger.userId,
              serviceId: todayTripPassenger.serviceId,

              tripId: upcomingTrip._id,
              // pickupStopId: todayTripPassenger.pickupStopId,
              // dropStopId: todayTripPassenger.dropStopId,

              bookingDate: upcomingTrip.tripDate,
            });
            // ====== check whether passenger already assigned to the trip ======

            if(!checkTripPassengerExist){
              // ======== passenger not assigned ========
              // console.log("trying to assign tripPassengerAssignData ===> ");
              // console.log(tripPassengerAssignData);

              // ================ passenger assign happens here ================
              const document = new tripPassengerModel(tripPassengerAssignData);
              let tripPassengerCreate = await document.save();
              // ================ passenger assign happens here ================

            } else {
              // ======== passenger already assigned; no need to assign again ========
            }
          }
        });

      });
    } else {
      // no trips, nothing to do ===
    }
    // ======= assign regular passengers =======

  },
  {
    scheduled: true,
    timezone: "Asia/Kolkata",
  }
);
// ============================= CRON TO CREATE TRIPS END =============================

// === Cron job (hourly) to forcefully complete a ride after 3 hours of completion time ===
cron.schedule(
  "0 0 */1 * * *",
  // "*/30 * * * * *",
  async function () {
    // console.log("force complete trips => cron running");
    // Get the current time in "Asia/Kolkata" time zone =======
    let momentKolkata = moment().tz('Asia/Kolkata');
    let currentDate = momentKolkata.format('YYYY-MM-DD');
	  let currentDay = momentKolkata.format('dddd');
    let currentTime = momentKolkata.format('HH:mm');
		// Get the current time in "Asia/Kolkata" time zone =======
    // ========== three hours before the current time ==========
    let threeHoursBefore = momentKolkata.clone().subtract(3, 'hours'); 
    let timeThreeHoursBefore = threeHoursBefore.format('HH:mm');
    let dateThreeHoursBefore = threeHoursBefore.format('YYYY-MM-DD'); 
    let dayThreeHoursBefore = threeHoursBefore.format('dddd');
    // ========== three hours before the current time ==========

    let incompleteTrips = await tripsModel.find({
      tripStatus: {
        $in: ["Pending" ,"Started", "Paused", "Resumed"],
      },
      tripDate: {
        $lte: currentDate,
      },
      // tripEndTime: {
      //   $lte: threeHoursBefore
      // },
    });
    
    let incompleteTripsIdsArr = [];
    if(incompleteTrips.length > 0){
      incompleteTrips.forEach(async (incompleteTrip) => {
        let tripEndTime = new Date(
          dateFormat(incompleteTrip?.tripDate) + " " + incompleteTrip?.tripEndTime
        ); 
        // Add three hours to tripEndTime 
        tripEndTime.setHours(tripEndTime.getHours() + 3); 
        // Get current date time in Kolkata timezone 
        let currentDateTime = new Date(); 

        if (currentDateTime >= tripEndTime) { 
          incompleteTripsIdsArr.push(incompleteTrip?._id); 
        }
      });
    }
    
    let forceCompleteTrips = await tripsModel.updateMany( 
      { 
        _id: { 
          $in: incompleteTripsIdsArr 
        } 
      }, 
      { 
        tripStatus: "Completed" 
      },
      {
        new: true, // Return the updated document instead of the old one
        runValidators: true, // Run the model's validators on update
      }
    );


  },
  {
    scheduled: true,
    timezone: "Asia/Kolkata",
  }
);
// === Cron job (hourly) to forcefully complete a ride after 3 hours of completion time ===

// ================= CRON TO SEND NOTIFICATION ================
cron.schedule(
  "*/10 * * * * *",
  async function () {
    // ====================================================================================
    // ---------------------- DO NOT DELETE STRATEGIC console.logs() ----------------------
    // ====================================================================================

    // Task to be executed =========
    // console.log("cron running");
    // Get the current time in "Asia/Kolkata" time zone =======
    let momentKolkata = moment().tz("Asia/Kolkata");
    let currentDate = momentKolkata.format("YYYY-MM-DD");
    let currentDay = momentKolkata.format("dddd");
    let currentTime = momentKolkata.format("HH:mm");
    // Get the current time in "Asia/Kolkata" time zone =======
    let tripPassenger = await tripPassengerModel
      .findOne({
        isActive: true,
        isDeleted: false,
        isCancelled: false,

        userId: req.user._id,
        bookingDate: currentDate,
      })
      .lean()
      .populate([
        {
          path: "userId",
          model: "usersCollection",
        },
        {
          path: "tripId",
          model: "tripsCollection",
          populate: [
            {
              path: "tripPlanId",
              model: "tripPlanCollection",
              populate: {
                path: "routeId",
                model: "routeMapCollection",
              },
            },
          ],
        },
      ]);
    await Promise.all(
      tripPassenger.forEach(async (passenger) => {
        let tripStartTime = passenger.tripId.tripStartTime;

        // Convert tripStartTime and currentTime to moment objects ===
        let startMoment = moment(tripStartTime, "HH:mm");
        let currentMoment = moment(currentTime, "HH:mm");
        // Calculate the difference in minutes ===
        let timeDifferenceMinutes = currentMoment.diff(startMoment, "minutes");
        // Check if the time difference is exactly 60 minutes (1 hour) ====
        if (timeDifferenceMinutes == 60) {
          console.log("The time difference is exactly 1 hour.");
          // ============== send OTP notification ==============
          // ========== push Notification ===========
          // ===== send notification to the driver =====
          try {
            let fcmToken = "";
            fcmToken = passenger.userId.fcmToken;
            if (fcmToken) {
              // ========== Push Notification ===========
              let messages = {
                title: `OTP for Trip`,
                body: JSON.stringify({
                  tripId: passenger.tripId._id.toString(),
                  msg: `Dear ${passenger.userId.firstName}, otp for the trip for ${passenger.tripId.tripPlanId.routeId.routeName} route at ${passenger.tripId.tripDate} on ${passenger.tripId.tripStartTime} is ${passenger.otp}. Please share the OTP with the driver to start the journey`,
                  type: "Show",
                }),
              };
              await sendPushNotification(fcmToken, messages, "android");
            }
          } catch (error) {
            console.error("Error sending notification:", error.message);
            // Handle or propagate the error as needed
          }
          // ===== send notification to the driver =====
          // ============== send OTP notification ==============
        } else {
          console.log("The time difference is not 1 hour.");
        }
      })
    );
  },
  {
    scheduled: true,
    timezone: "Asia/Kolkata",
  }
);
// ================= CRON TO SEND NOTIFICATION ================

app.use(errorMiddleware);
app.use("/uploads", express.static("src/public/uploads"));

module.exports = app;
