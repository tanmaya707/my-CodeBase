const express = require('express');
const router = express.Router();
const moduleController = require('../controllers/moduleController')
const rolePermissionController = require('../controllers/rolePermissionController')

const {
    validateUser
} = require('../validation/userValidator');
const {
    isAuthenticated
} = require('../middleware/auth')

// ======== for dropdown =======
router.route('/rolePermission-list').get(isAuthenticated, rolePermissionController.rolePermissionList);
// ======== for dropdown =======
router.route('/rolePermission-list').post(isAuthenticated, rolePermissionController.rolePermissionList);
router.route('/rolePermission-addUpdate').post(isAuthenticated, rolePermissionController.rolePermissionAddUpdate); // validateUser, 
router.route('/get-rolePermissionDetail').post(isAuthenticated, rolePermissionController.getRolePermissionDetail);
router.route('/delete-rolePermissionDetail').post(isAuthenticated, rolePermissionController.deleteRolePermission);

// ============================== App APIs ==============================

// ============================== App APIs ==============================


module.exports = router;