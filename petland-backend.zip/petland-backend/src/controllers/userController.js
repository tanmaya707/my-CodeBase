const axios = require("axios");
const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/errorHandler");
const RequestHandler = require("../utils/RequestHandler");
const fileUploaderSingle = require("../utils/fileUpload").fileUploaderSingle;
const bcrypt = require("bcryptjs");
const JWTAuth = require("../utils/jwtToken");
const jwt = require("jsonwebtoken");
const jwtConfig = require("../config").JWT;
const { Op } = require("sequelize");
// const { generateUniqueAccountId } = require("../utils/utilities");
const crypto = require("crypto");

const {
  calculateDistance,
  calculateDistanceInsTentApi,
  calculateTimeInKilometers,
  getRateChartCategory,
} = require("../utils/utilities");
const {
  MSG_RECORD_STATUS_SUCCESS,
  MSG_RECORD_FETCH_SUCCESS,
} = require("../config/constants");
const requestHandler = new RequestHandler();

const db = require("../models");
// const userLocationModel = require("../models/userLocationModel");
// const parkingGroundsModel = require("../models/parkingGroundsModel");
const vendorModel = db.Vendors;
const userModel = db.Users;
const userCompanyModel = db.UserCompanies;
const roleModel = db.Roles;
const usersrolesModel = db.UsersRoles;
const modulePermissionsModel = db.ModulePermissions;
const bookingRequestsModel = db.BookingRequests;
const slotsModel = db.Slots;
const vehicleTypesModel = db.VehicleTypes;
const notificationModel = db.Notifications;
const subscriptionModel = db.Subscriptions;
const subscriptionDetailsModel = db.SubscriptionDetails;
const permissionModel = db.Permissions;
const parkingBusinessModel = db.ParkingBusinesses;
const parkingGroundsModel = db.ParkingGrounds;
const userLocationModel = db.UserLocations;
const userGroundModel = db.UserGrounds;

class UserController extends BaseController {
  constructor() {
    super();
  }
/****
     **** User Management Section
     ****/
    static userSignUp = catchAsyncErrors(async (req, res, next) => {
        var {
            device_type,
            email_id,
            country_code,
            phone_number,
            name,
            password,
            confirm_password,
            resend
        } = req.body;

        let condition = {
            deletedAt: null,
        };

        let checkExist = await userModel.findOne({
            attributes: ["name"],
            where: {
                ...condition,
                [Op.or]: [{ email_id: email_id }, { phone_number: phone_number }],
            },
        });

        if (password !== confirm_password) {
            return res.status(422).json({
                status: false,
                message: "Passwords do not match.",
                data: {},
            });
        }

        if (checkExist) {
            return res.status(200).json({
                status: false,
                message: "User already exist!",
                data: checkExist,
            });
        }


        if (!name) {
            return res.status(422).json({
                status: false,
                message: "Name is required.",
                data: {},
            });
        }
        if (!email_id) {
            return res.status(422).json({
                status: false,
                message: "Email is required.",
                data: {},
            });
        }
        // if (!phone_number) {
        //     return res.status(422).json({
        //         status: false,
        //         message: "Phone number is required.",
        //         data: {},
        //     });
        // }

        if (!password) {
            return res.status(422).json({
                status: false,
                message: "Password is required.",
                data: {},
            });
        }

        let updateFields = {};

        if (name) {
            updateFields.name = name;
        }
        if (email_id) {
            updateFields.email_id = email_id;
        }
        if (phone_number) {
            updateFields.phone_number = phone_number;
        }
        if (password) {
            updateFields.password = await bcrypt.hash(password, 10);
        }

        if(device_type){
          updateFields.device_type = device_type;
        }

        if(country_code){
          updateFields.country_code = country_code;
        }

        if(resend){
          updateFields.resend = resend;
        }

        updateFields.device_token = crypto.randomUUID();

        // updateFields.account_id = await generateUniqueAccountId();
        updateFields.uuid = crypto.randomUUID();
        updateFields.otp = crypto.randomInt(1000, 10000);

        var updated = await super.create(res, userModel, updateFields);

        var token = JWTAuth.ClientSign({
            id: updated?.id,
            uuid: updateFields.uuid,
            name: name,
            email: email_id,
            deviceType: device_type,
            isVerified: false,
            isSubscribed: false
        });
        let userUpdateFields = {};
        if (Number(device_type) == 1) {
            userUpdateFields.webLogin = token;
        } else {
            userUpdateFields.appLogin = token;
        }

        await super.updateById(userModel, updated?.id, userUpdateFields);

        let userDetails = await userModel.findOne({
            where: {
                id: updated?.id,
            }
        });
        if (userDetails) {
            return res.status(200).json({
                status: true,
                message: "Successful.",
                data: { userDetails, device_type, deviceToken: token },
            });
        } else {
            return res.status(400).json({
                status: false,
                message: "Oops.. Something wrong happened!",
                data: {},
            });
        }
    });

    static emailLoggedIn = catchAsyncErrors(async (req, res, next) => {
        const { email_id, password, device_type } = req.body;

        const user = await userModel.findOne({ where: { email_id } });

        if (!user) {
            return res.status(200).json({
                status: false,
                message: "User not found!",
                data: null,
            });
        }

        const passwordMatch = await bcrypt.compare(password, user.password);
        if (!passwordMatch) {
            return res.status(200).json({
                status: false,
                message: "Authentication failed!",
                data: null,
            });
        }

        var token = JWTAuth.ClientSign({
            id: user?.id,
            uuid: user.uuid,
            name: user.name,
            email: email_id,
            deviceType: device_type,
            isVerified: user.isVerified
        });
        let clientpUdateFields = {};
        if (Number(device_type) == 1) {
            clientpUdateFields.webLogin = token;
        } else {
            clientpUdateFields.appLogin = token;
        }
        await super.updateById(userModel, user?.id, clientpUdateFields);

        return res.status(200).json({
            status: true,
            message: "Login successful.",
            data: {
                user: user, 
                deviceToken: token
            },
        });
    });

    static mobileLoggedIn = catchAsyncErrors(async (req, res, next) => {
        const { phone_number, device_type } = req.body;

        const user = await userModel.findOne({ where: { phone_number } });

        if (!user) {
            return res.status(200).json({
                status: false,
                message: "User not found!",
                data: null,
            });
        }

        // const passwordMatch = await bcrypt.compare(password, user.password);
        // if (!passwordMatch) {
        //     return res.status(200).json({
        //         status: false,
        //         message: "Authentication failed!",
        //         data: null,
        //     });
        // }

        var token = JWTAuth.ClientSign({
            id: user?.id,
            uuid: user.uuid,
            name: user.name,
            email: user.email_id,
            deviceType: device_type,
            isVerified: user.isVerified
        });
        let clientpUdateFields = {};
        if (Number(device_type) == 1) {
            clientpUdateFields.webLogin = token;
        } else {
            clientpUdateFields.appLogin = token;
        }
        // Generate and update OTP for the user
        clientpUdateFields.otp = crypto.randomInt(1000, 10000);
        await super.updateById(userModel, user?.id, clientpUdateFields);

        // Fetch the updated user to get the latest OTP value
        const updatedUser = await userModel.findOne({ where: { id: user?.id } });

        return res.status(200).json({
            status: true,
            message: "Login successful.",
            data: {
          user: {
              "id": user.id,
              "uuid": user.uuid,
              "name": user.name,
              "otp": updatedUser.otp
          }, deviceToken: token
            },
        });
    });

    static emailPhoneVerifyOtp = catchAsyncErrors(async (req, res, next) => {
        const { email_id, phone_number, otp } = req.body;
        let user = null;
        if(email_id){
            user = await userModel.findOne({ where: { email_id, otp: otp } });
        } else if(phone_number){
            user = await userModel.findOne({ where: { phone_number, otp: otp } });
        }

        console.log(user, "123");

        if (!user) {
            return res.status(200).json({
                status: false,
                message: "Verification failed!",
                data: null,
            });
        }
        let updateFields = {};
        updateFields.isVerified = true;
        var updated = await super.updateById(userModel, user.id, updateFields);
        return res.status(200).json({
            status: true,
            message: "Verification successful.",
            data: { user: updated },
        });
    });

    static resetPassword = catchAsyncErrors(async (req, res, next) => {
      const { otp, password, confirm_password } = req.body;
        if (!otp) {
          return next(new ErrorHandler("Invalid url", 400));
        }
        let condition = { otp: otp };
        const userExists = await userModel.findOne({ where: condition });
        if (userExists) {
          if (!password) {
            return next(new ErrorHandler("Password is required", 400));
          } else if (!confirm_password) {
            return next(new ErrorHandler("Confirm password is required", 400));
          } else if (password != confirm_password) {
            return requestHandler.customError(res, 404, "Password doesn't match");
          } else {
            let pass = await bcrypt.hash(password, 10);
            let updated = await super.updateByCustomOptions(
              userModel,
              { otp: otp },
              {
                password: pass,
                otp: ''
              }
            );
            // console.log(updated);
            if (updated[0]) {
              return res.status(200).json({
                status: true,
                message: "Password updated successfully"
              });
            } else {
              return requestHandler.customError(res, 500, "Something went wrong.");
            }
          }
        } else {
          return requestHandler.customError(res, 404, "User does not exist.");
        }
    });

    static forgotPassword = catchAsyncErrors(async (req, res, next) => {
        const { email, otp } = req.body;
        if (!email) {
        return next(new ErrorHandler("Please enter email", 400));
        }
        let condition = { email_id: email };
        const userExists = await userModel.findOne({ where: condition });
        if (userExists) {
        if (otp && otp != "" && otp != null) {
            if (userExists.otp && userExists.otp.toString() == otp.toString()) {
            let resetToken = this.generateToken(userExists.id)
            console.log(resetToken)
            let tokenUpdated = await super.updateById(
                userModel,
                userExists.id,
                {
                resetToken: resetToken
                }
            );
            if (tokenUpdated) {
                return res.status(200).json({
                status: true,
                message: "OTP verified successfully",
                resetToken: resetToken,
                });
            }
            } else {
            return requestHandler.customError(res, 404, "OTP doesn't match");
            }
        } else {
            const otpcode = Math.floor(1000 + Math.random() * 9000);
            // const currentDateTime = new Date();
            // const expirationDateTime = new Date(
            //   currentDateTime.setMinutes(currentDateTime.getMinutes() + 5)
            // );
            let updated = await super.updateById(
            userModel,
            userExists.id,
            {
                otp: otpcode
            }
            );
            if (updated) {
            return res.status(200).json({
                status: true,
                message: "OTP sent to your email",
                otp: otpcode,
            });
            } else {
            return requestHandler.customError(res, 500, "Something went wrong.");
            }
        }
        } else {
        return requestHandler.customError(res, 404, "User does not exist.");
        }
    });

    static changePassword = catchAsyncErrors(async (req, res, next) => {
        const { old_password, password, confirm_password } = req.body;
        console.log(req.user, "1234")
        if (!old_password) {
          return next(new ErrorHandler("Old password required", 400));
        }
        if (!password) {
          return next(new ErrorHandler("New password required", 400));
        }

        if(password !== confirm_password){
          return next(new ErrorHandler("Passwords do not match", 400));
        }
        let userExists = await userModel.findOne({
          where: { id: req.user.id },
          attributes: ['password']
        });
        if (!userExists) {
          return res.status(404).json({
            status: false,
            message: "User not found!",
            data: {},
          });
        }
        const isPasswordMatched = await bcrypt.compare(old_password, userExists.password);
        if (!isPasswordMatched) {
          return res.status(400).json({
            status: false,
            message: "Old password does not match!",
            data: {},
          });
        } else {
          let pass = await bcrypt.hash(password, 10);
          let updated = await super.updateById(userModel, req.user.id, {
            password: pass,
          });
          if (updated) {
            return res.status(200).json({
              status: true,
              message: "Password changed successfully",
            });
          } else {
            return res.status(500).json({
              status: false,
              message: "Something went wrong",
            });
          }
        }
    });

    static clientProfile = catchAsyncErrors(async (req, res, next) => {
        let userId = req.user.id;
        // console.log("userIduserId", userId);
        let user = await clientModel.findOne({
            attributes: ['id', 'uuid', 'account_id', 'name', 'phone', 'email', 'password', 'isVerified', 'database_name', 'dialCode', 'phone', 'profileImage'],
            where: { id: userId }
        });

        const profileImage = user.profileImage ? `${req.protocol}://${req.get('host')}/uploads/user/${user.profileImage}` : null

        let userCompany = null;
        const str = user.database_name;
        if (str) {
            const companyNameCheck = str.split("_").join(" ");

            userCompany = await userCompanyModel.findOne({
                where: { userId: userId }
            });
        }

        if (!user) {
            return res.status(404).json({
                status: false,
                message: "Client not found!",
                data: null,
            });
        }
        const db_name = user.database_name;
        // if (!db_name) {
        //     return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.' ,data:{}});
        // }
        // const { sequelize2, ClientSubscriptionModel } = await connectSpecificToDatabase(user.database_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306');

        let userSubscription = {};
        let companyLanguageDetails = {};
        let companyTaxDetails = {};
        let isSecurity = false;
        let clientCreation = false;
        let invoiceCreation = false;
        let plan = null;
        let daysLeft = null;
        if (db_name) {
            const connection = await connectSpecificToDatabase(
                db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
            );

            const clientAdmin = await connection.ClientAdmin.findOne({
                where: { email: user.email }
            });

            if (clientAdmin) {
                // console.log(db_name, clientAdmin);
                // userId = req.user.id;
                userId = clientAdmin.id;

                // console.log("userIduserIduserId", userId);

                userSubscription = await connection.Subscription.findOne({
                    where: { userId: userId }
                });
                // console.log(userSubscription);

                companyLanguageDetails = await connection.UserLanguage.findOne({
                    where: { userId: userId }
                });
                companyTaxDetails = await connection.CompanyTaxSecurity.findOne({
                    where: { userId: userId }
                });

                if (userSubscription) {
                    plan = await planModel.findOne({
                        where: { id: userSubscription.subscriptionId },
                        attributes: ['id', 'uuid', 'name']
                    });

                    const startDate = new Date(userSubscription.startDate);
                    const endDate = new Date(userSubscription.endDate);
                    const currentDate = new Date();
                    // Calculate the difference in milliseconds
                    const differenceInMilliseconds = endDate - currentDate;
                    // console.log(differenceInMilliseconds);

                    // Convert milliseconds to days
                    daysLeft = Math.ceil(differenceInMilliseconds / (1000 * 60 * 60 * 24));
                }

                user.isSubscribed = userSubscription ? true : false;

                isSecurity = false;

                clientCreation = await connection.Client.findOne({
                    where: { created_by: userId }
                }) ? true : false;

                invoiceCreation = await connection.Invoice.findOne({
                    where: { client_id: userId }
                }) ? true : false;
            }
        }

        const { password, ...userData } = user.get({ plain: true });
        // console.log(user);
        return res.status(200).json({
            status: true,
            message: "Client found!",
            data: { ...userData, isSubscribed: user.isSubscribed, planDetails: plan, planType: userSubscription?.planType, dayLeft: daysLeft, companyLanguageDetails, userCompany, companyTaxDetails, isSecurity, clientCreation, invoiceCreation, profileImage },
        });
    });

    static sendVerificationCode = catchAsyncErrors(async (req, res, next) => {
        const { email, subject = "Verification Code" } = req.body;

        const user = await clientModel.findOne({ attributes: ['id', 'uuid', 'name', 'OTP', 'password', 'isVerified', 'database_name'], where: { email } });

        if (!user) {
            return res.status(404).json({ error: 'Client not found' });
        }

        let clientpUdateFields = {};
        let OTP = crypto.randomInt(1000, 10000);
        clientpUdateFields.OTP = OTP;
        clientpUdateFields.expiresAt = new Date(Date.now() + 3600000), // 1 hour from now
        clientpUdateFields.used = false
        const name = user.name || '';
        const body = `Hi ${name},<br><br>
            We received a request to reset the password for your account associated with this email address.<br><br>
            To proceed, please use the One-Time Password (OTP) below:<br><br>
            🔐 Your OTP: ${OTP}<br><br>
            This OTP is valid for the next 1 hour. If you did not request a password reset, please ignore this email or contact our support team immediately.<br><br>
            Thanks,<br>
            Raise Invoice<br>
            Customer Support Team
        `;
        await sendMail(email, null, null, subject, null, body, false);
        var clientpUdate = await super.updateById(clientModel, user?.id, clientpUdateFields);

        //////////////////////////////////////////////////////////////////////////////////////////////////

        return res.status(200).json({
            status: true,
            message: "Otp generate successfully.",
            data: { email },
        });
    });

    static clientVerifyOtp = catchAsyncErrors(async (req, res, next) => {
        const { email, otp } = req.body;
        const user = await clientModel.findOne({ attributes: ['id', 'uuid', 'name', 'password', 'isVerified', 'database_name'], where: { email, OTP: otp } });
        if (!user) {
            return res.status(200).json({
                status: false,
                message: "Verification failed!",
                data: null,
            });
        }
        let updateFields = {};
        updateFields.isVerified = true;
        var updated = await super.updateById(clientModel, user.id, updateFields);
        return res.status(200).json({
            status: true,
            message: "Verification successful.",
            data: { user: updated },
        });
    });

    static clientResetPassword = catchAsyncErrors(async (req, res, next) => {
        const { email, otp, password, confirm_password, deviceType } = req.body;

        const user = await clientModel.findOne({ attributes: ['id', 'uuid', 'name', 'password', 'isVerified', 'database_name','used', 'expiresAt'], where: { email, OTP: otp } });

        if (!user) {
            return res.status(200).json({
                status: false,
                message: "Client Not found!",
                data: null,
            });
        }

        // Check if Link is already used
        if (user.used === true) {
            return res.status(200).json({
                status: false,
                message: "This password reset link has already been used. Please request a new one.",
                data: null,
            });
        }

        // Check if Link is expired
        if (user.expiresAt && user.expiresAt < Date.now()) {
            return res.status(200).json({
                status: false,
                message: "This password reset link has expired. Please request a new one.",
                data: null,
            });
        }

        var results = null;
        let updateFields = {};
        if (password) {
            if (password !== confirm_password) {
                return res.status(200).json({
                    status: false,
                    message: "Passwords do not match.",
                    data: null,
                });
            }
            updateFields.password = await bcrypt.hash(password, 10);
            var updated = await super.updateById(clientModel, user.id, updateFields);

            var token = JWTAuth.ClientSign({
                id: user?.id,
                uuid: user.uuid,
                name: user.name,
                email: email,
                deviceType: deviceType,
                isVerified: user.isVerified,
                isSubscribed: false
            });
            let clientpUdateFields = {};
            if (Number(deviceType) == 2) {
                clientpUdateFields.webLogin = token;
            } else {
                clientpUdateFields.appLogin = token;
            }
            var clientpUdate = await super.updateById(clientModel, user?.id, clientpUdateFields);


            //////////////////////////////////////////////////////////////////////////////////////////////////

            /******************************* Specific DB Connected Start ************************************/
            const db_name = user.database_name;
            if (!db_name) {
                return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
            }
            const sequelize = await getConnectedSpecificDB(db_name);
            /******************************* Specific DB Connected End ************************************/

            var newPassword = updateFields.password;
            var uuid = user.uuid;

            var [results, metadata] = await sequelize.query(
                "UPDATE clientadmins SET password = :newPassword WHERE uuid = :uuid",
                {
                    replacements: { newPassword, uuid: uuid },
                }
            );

            // const asasasa = await clientModel.findAll({ attributes: ['id', 'uuid', 'name'] });
            var [results, metadata] = await sequelize.query("SELECT id, uuid, name FROM clientadmins");

            if (sequelize) {
                await sequelize.close();
            }
        }
        //////////////////////////////////////////////////////////////////////////////////////////////////

        return res.status(200).json({
            status: true,
            message: "Password reset successfully.",
            data: { user, deviceToken: token, clientAdmins: results },
        });
    });

    static clientChangePassword = catchAsyncErrors(async (req, res, next) => {
        const { old_password, password } = req.body;
        if (!old_password) {
            return res.status(400).json({ status: false, message: "Old password required" });
        }
        if (!password) {
            return res.status(400).json({ status: false, message: "New password required" });
        }

        const userId = req.user.id;
        const user = await clientModel.findOne({ where: { id: userId } });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const isPasswordMatched = await bcrypt.compare(old_password, user.password);
        if (!isPasswordMatched) {
            return res.status(400).json({
                status: false,
                message: "Old password does not match!",
                data: {},
            });
        } else {
            let pass = await bcrypt.hash(password, 10);
            let updated = await super.updateById(clientModel, userId, {
                password: pass,
            });
            if (updated) {
                return res.status(200).json({
                    status: true,
                    message: "Password changed successfully",
                });
            } else {
                return res.status(500).json({
                    status: false,
                    message: "Something went wrong",
                });
            }
        }
    });

    static editProfile = catchAsyncErrors(async (req, res, next) => {
        const userId = req.user.id;
        const { first_name, last_name, email_id, address, city, postal_code, country, aboutMe, phone_number } = req.body;
        let updateFields = {};
        if (first_name && last_name) {
            updateFields.name = first_name + ' ' + last_name;
        }else if(first_name){
            updateFields.name = first_name;
        }else if(last_name){
            updateFields.name = last_name;
        }
        if (phone_number) {
            updateFields.phone_number = phone_number;
        }
        if (email_id) {
            updateFields.email_id = email_id;
        }
        if (address) {
            updateFields.address = address;
        }
        if (city) {
            updateFields.city = city;
        }
        if (postal_code) {
            updateFields.postal_code = postal_code;
        }
        if (country) {
            updateFields.country = country;
        }
        if (aboutMe) {
            updateFields.aboutMe = aboutMe;
        }
        let fileName = "";

        if (req.files && req.files.document) {
            let image = await fileUploaderSingle("src/public/uploads/", req.files.document);
            fileName = image.newfileName;
        }

        if (fileName) {
            updateFields.profileImage = fileName;
        }

        var updated = await super.updateById(userModel, userId, updateFields);
        if (updated) {
            return res.status(200).json({
                status: true,
                message: "Profile updated successfully",
                data: { user: updated },
            });
        } else {
            return res.status(500).json({
                status: false,
                message: "Something went wrong",
            });
        }
    });

    static getUserDetails = catchAsyncErrors(async (req, res, next) => {
        const userId = req.user.id;
        const user = await userModel.findOne({ where: { id: userId } });
        if (!user) {
            return res.status(404).json({
                status: false,
                message: "User not found!",
                data: null,
            });
        }
        return res.status(200).json({
            status: true,
            message: "User found!",
            data: { user },
        });
    });

    /****
    **** Role & Permission Management Section
    *****/
    static getPermissionList = catchAsyncErrors(async (req, res, next) => {
        //////////////////////////////////////////////////////////////////////////////////////////////////
        const user = await clientModel.findOne({ attributes: ['id', 'database_name'], where: { id: req.user.id } });
        /******************************* Specific DB Connected Start ************************************/

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const sequelize = await getConnectedSpecificDB(db_name);
        /******************************* Specific DB Connected End ************************************/
        try {
            // Query to get all modules and their permissions
            const [results] = await sequelize.query(`
            SELECT m.moduleName, p.id AS permissionId, p.name
            FROM modules m
            LEFT JOIN permissions p ON m.id = p.moduleId
        `);

            const response = results.reduce((acc, curr) => {
                let moduleEntry = acc.find(item => item.module === curr.moduleName);
                if (!moduleEntry) {
                    moduleEntry = {
                        module: curr.moduleName,
                        permissions: []
                    };
                    acc.push(moduleEntry);
                }
                if (curr.permissionId) {
                    moduleEntry.permissions.push({
                        id: curr.permissionId,
                        permissionName: curr.name
                    });
                }
                return acc;
            }, []);

            return res.status(200).json({
                status: true,
                message: "Get permissions successfully.",
                data: response
            });

        } finally {
            // Ensure the connection is closed
            if (sequelize) {
                await sequelize.close();
            }
        }
        //////////////////////////////////////////////////////////////////////////////////////////////////
    });

    static createRoleAdmin = catchAsyncErrors(async (req, res, next) => {
        const { role_name, permissions } = req.body;

        //////////////////////////////////////////////////////////////////////////////////////////////////
        const user = await clientModel.findOne({ attributes: ['id', 'database_name'], where: { id: req.user.id } });
        /******************************* Specific DB Connected Start ************************************/
        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const sequelize = await getConnectedSpecificDB(db_name);
        /******************************* Specific DB Connected End ************************************/

        try {
            // Start a transaction
            const transaction = await sequelize.transaction();
            const uuid = crypto.randomUUID();
            const [roleResult] = await sequelize.query(
                "INSERT INTO roles (uuid, roleName, roleSlug) VALUES (:uuid, :roleName, :roleSlug)",
                {
                    replacements: {
                        uuid: uuid,
                        roleName: role_name,
                        roleSlug: role_name.toLowerCase().replace(/\s+/g, '_')
                    },
                    transaction
                }
            );

            const newRoleId = roleResult;

            const permissionInsertPromises = permissions.map(permissionId => {
                return sequelize.query(
                    "INSERT INTO rolespermissions (roleId, permissionId) VALUES (:roleId, :permissionId)",
                    {
                        replacements: {
                            roleId: newRoleId,
                            permissionId: permissionId
                        },
                        transaction
                    }
                );
            });
            await Promise.all(permissionInsertPromises);

            // Commit the transaction
            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: `Role "${role_name}" added with permissions successfully.`,
                data: { id: newRoleId, role_name },
            });
        } catch (error) {
            console.error('Error adding role with permissions:', error);
            // Rollback the transaction in case of error
            await transaction.rollback();
        } finally {
            // Close the connection
            await sequelize.close();
        }
        //////////////////////////////////////////////////////////////////////////////////////////////////
    });

    static getRoleList = catchAsyncErrors(async (req, res, next) => {
        //////////////////////////////////////////////////////////////////////////////////////////////////
        const user = await clientModel.findOne({ attributes: ['id', 'database_name'], where: { id: req.user.id } });
        /******************************* Specific DB Connected Start ************************************/
        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const sequelize = await getConnectedSpecificDB(db_name);
        /******************************* Specific DB Connected End ************************************/
        try {
            var [results, metadata] = await sequelize.query("SELECT id, uuid, roleName FROM roles");
            return res.status(200).json({
                status: true,
                message: "Get roles successfully.",
                data: results
            });
        } finally {
            // Ensure the connection is closed
            if (sequelize) {
                await sequelize.close();
            }
        }
        //////////////////////////////////////////////////////////////////////////////////////////////////
    });

    static getRoleDetails = catchAsyncErrors(async (req, res, next) => {
        const { id } = req.body;

        // Fetch user details to get the database name
        const user = await clientModel.findOne({ attributes: ['id', 'database_name'], where: { id: req.user.id } });

        // Connect to the specific database
        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const sequelize = await getConnectedSpecificDB(db_name);

        try {
            // Use parameterized query to prevent SQL injection
            const [results] = await sequelize.query("SELECT id,uuid, roleName, roleSlug FROM roles WHERE id = :role_id", {
                replacements: { role_id }
            });

            // Check if the role was found
            if (results.length === 0) {
                return res.status(404).json({
                    status: false,
                    message: "Role not found."
                });
            }

            // Return the role details
            return res.status(200).json({
                status: true,
                message: "Get role successfully.",
                data: results[0] // Return the first result
            });
        } catch (error) {
            console.error('Error fetching role details:', error);
            return res.status(500).json({
                status: false,
                message: "An error occurred while fetching role details."
            });
        } finally {
            // Ensure the connection is closed
            if (sequelize) {
                await sequelize.close();
            }
        }
    });

    //--------------------------------------------------------------------------------------------
    static updateClientRole = catchAsyncErrors(async (req, res, next) => {
        // const { role_name, permissions } = req.body;

        // // Fetch user details to get the database name
        // const user = await clientModel.findOne({ attributes: ['id', 'database_name'], where: { id: req.user.id } });

        // // Connect to the specific database
        // const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        // const sequelize = await getConnectedSpecificDB(db_name);

        // try {
        //     // Start a transaction
        //     const transaction = await sequelize.transaction();
        //     const uuid = crypto.randomUUID();
        //     const [roleResult] = await sequelize.query(
        //         "INSERT INTO roles (uuid, roleName, roleSlug) VALUES (:uuid, :roleName, :roleSlug)",
        //         {
        //             replacements: {
        //                 uuid: uuid,
        //                 roleName: role_name,
        //                 roleSlug: role_name.toLowerCase().replace(/\s+/g, '_')
        //             },
        //             transaction
        //         }
        //     );

        //     const newRoleId = roleResult;

        //     const permissionInsertPromises = permissions.map(permissionId => {
        //         return sequelize.query(
        //             "INSERT INTO rolespermissions (roleId, permissionId) VALUES (:roleId, :permissionId)",
        //             {
        //                 replacements: {
        //                     roleId: newRoleId,
        //                     permissionId: permissionId
        //                 },
        //                 transaction
        //             }
        //         );
        //     });
        //     await Promise.all(permissionInsertPromises);

        //     // Commit the transaction
        //     await transaction.commit();

        //     return res.status(200).json({
        //         status: true,
        //         message: `Role "${role_name}" updated with permissions successfully.`,
        //         data: { id: newRoleId, role_name },
        //     });
        // } catch (error) {
        //     console.error('Error fetching role details:', error);
        //     return res.status(500).json({
        //         status: false,
        //         message: "An error occurred while fetching role details."
        //     });
        // } finally {
        //     // Ensure the connection is closed
        //     if (sequelize) {
        //         await sequelize.close();
        //     }
        // }
    });

    static deleteClientRole = catchAsyncErrors(async (req, res, next) => {
        const { id } = req.params;
        const userId = req.user.id;
        const user = await clientModel.findOne({ attributes: ['id', 'database_name'], where: { id: userId } });

        if (!user) {
            throw new Error('User not found');
        }
        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        // const { sequelize2, RoleModelClient } = await connectSpecificToDatabase(db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306');
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );


        let roleDetail = await super.getByCustomOptionsSingle(req, connection.UserRole, {
            where: {
                id: id
            },
            attributes: ["id"],
        });

        if (!roleDetail) {
            return res.status(403).json({
                status: false,
                message: "Role not found!",
                data: {},
            });
        }
        let deleted = await super.deleteByCondition(
            connection.UserRole,
            {
                id: roleDetail.id,
            }
        );

        if (deleted) {
            return res.status(200).json({
                status: true,
                message: "Role successfully deleted.",
                data: {}
            });
        } else {
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }

    });
    //--------------------------------------------------------------------------------------------

    /****
    *** Team Member Management Section
    ****/
    static createTeamMember = catchAsyncErrors(async (req, res, next) => {
        //////////////////////////////////////////////////////////////////////////////////////////////////
        const { name, email, password, roleId } = req.body;
        const userId = req.user.id;

        const user = await clientModel.findOne({ attributes: ['id', 'database_name'], where: { id: userId } });

        if (!user) {
            throw new Error('User  not found');
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const sequelize = await getConnectedSpecificDB(db_name);

        try {
            let updateFields = {};
            updateFields.uuid = crypto.randomUUID();
            if (password) {
                updateFields.password = await bcrypt.hash(password, 10);
            }
            const [newUser] = await sequelize.query(
                "INSERT INTO clientadmins (uuid,name, email, password) VALUES (:uuid, :name, :email, :password)",
                {
                    replacements: {
                        uuid: updateFields.uuid,
                        name,
                        email,
                        password: updateFields.password
                    }
                }
            );

            const newUserId = newUser;

            await sequelize.query(
                "INSERT INTO usersroles (userId, roleId) VALUES (:userId, :roleId)",
                {
                    replacements: {
                        userId: newUserId,
                        roleId: roleId
                    }
                }
            );
            console.log(`User  ${name} added successfully with role ID ${roleId}.`);

            // Step 5: Retrieve the user's name, email, and role
            const [userData] = await sequelize.query(`
            SELECT c.name, c.email, r.roleName AS role
            FROM clientadmins c
            JOIN usersroles ur ON c.id = ur.userId
            JOIN roles r ON ur.roleId = r.id
            WHERE c.id = :userId
        `, {
                replacements: { userId: newUserId }
            });

            return res.status(200).json({
                status: true,
                message: "Team memeber added successfully.",
                data: userData
            });
        } catch (error) {
            console.error('Error adding user:', error);
            throw error;
        } finally {
            await sequelize.close();
        }
    });

    static getAllUsersWithRoles = catchAsyncErrors(async (req, res, next) => {
        const user = await clientModel.findOne({ attributes: ['id', 'database_name'], where: { id: req.user.id } });

        if (!user) {
            throw new Error('User  not found');
        }
        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const sequelize = await getConnectedSpecificDB(db_name);

        try {
            const [usersData] = await sequelize.query(`
                SELECT c.name, c.email, r.roleName AS role
                FROM clientadmins c
                LEFT JOIN usersroles ur ON c.id = ur.userId
                LEFT JOIN roles r ON ur.roleId = r.id
            `);
            return res.status(200).json({
                status: true,
                message: "Team memeber lists.",
                data: usersData
            });
        } catch (error) {
            console.error('Error fetching users:', error);
            throw error; // Rethrow the error for further handling
        } finally {
            // Step 7: Close the connection
            await sequelize.close();
        }
    });

    //--------------------------------------------------------------------------------------------
    static detailsClientAdmin = catchAsyncErrors(async (req, res, next) => {
        const { id } = req.params;

        // Fetch user details to get the database name
        const user = await clientModel.findOne({ attributes: ['id', 'database_name'], where: { id: req.user.id } });

        // Connect to the specific database
        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const sequelize = await getConnectedSpecificDB(db_name);

        try {
            // Use parameterized query to prevent SQL injection
            const [results] = await sequelize.query("SELECT id, uuid, name, email FROM clientadmins WHERE id = :id", {
                replacements: { id }
            });

            // Check if the role was found
            if (results.length === 0) {
                return res.status(404).json({
                    status: false,
                    message: "User not found."
                });
            }

            return res.status(200).json({
                status: true,
                message: "Get user successfully.",
                data: results[0]
            });
        } catch (error) {
            console.error('Error fetching user details:', error);
            return res.status(500).json({
                status: false,
                message: "An error occurred while fetching user details."
            });
        } finally {
            // Ensure the connection is closed
            if (sequelize) {
                await sequelize.close();
            }
        }
    });
    //--------------------------------------------------------------------------------------------

    static editClientAdmin = catchAsyncErrors(async (req, res, next) => {
        const { id } = req.params;
        const { name, email, roleId } = req.body;
        const userId = req.user.id;

        try {
            const user = await clientModel.findOne({ attributes: ['id', 'database_name'], where: { id: userId } });

            if (!user) {
                throw new Error('User  not found');
            }
            const password = await bcrypt.hash(req.body.password, 10);
            const db_name = user.database_name;
            if (!db_name) {
                return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
            }
            const sequelize = await getConnectedSpecificDB(db_name);

            await sequelize.query(
                "UPDATE clientadmins SET name = :name, email = :email, password = :password WHERE id = :id",
                {
                    replacements: {
                        name,
                        email,
                        password,
                        id
                    }
                }
            );

            if (roleId) {
                await sequelize.query(
                    "UPDATE usersroles SET roleId = :roleId WHERE userId = :userId",
                    {
                        replacements: {
                            roleId,
                            userId: id
                        }
                    }
                );
            }

            // Step 5: Retrieve the user's name, email, and role
            const [userData] = await sequelize.query(`
                SELECT c.name, c.email, r.roleName AS role
                FROM clientadmins c
                JOIN usersroles ur ON c.id = ur.userId
                JOIN roles r ON ur.roleId = r.id
                WHERE c.id = :userId
            `, {
                replacements: { userId: id }
            });

            return res.status(200).json({
                status: true,
                message: "Client admin updated successfully",
                data: userData
            });
        } catch (error) {
            console.error('Error updating client admin:', error);
            return res.status(500).json({ message: 'Internal server error' });
        }
    });

    static deleteClientAdmin = catchAsyncErrors(async (req, res, next) => {
        const { id } = req.params;
        const userId = req.user.id;
        const user = await clientModel.findOne({ attributes: ['id', 'database_name'], where: { id: userId } });

        if (!user) {
            throw new Error('User  not found');
        }
        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const sequelize = await getConnectedSpecificDB(db_name);

        try {
            await sequelize.query(
                "DELETE FROM usersroles WHERE userId = :userId",
                {
                    replacements: { userId: id }
                }
            );

            const result = await sequelize.query(
                "DELETE FROM clientadmins WHERE id = :id",
                {
                    replacements: { id }
                }
            );

            if (result[0].affectedRows === 0) {
                return res.status(404).json({ message: 'Client admin not found' });
            }

            return res.status(200).json({
                status: true,
                message: "Client admin deleted successfully.",
                data: null
            });
        } catch (error) {
            console.error('Error deleting client admin:', error);
            return res.status(500).json({ message: 'Internal server error' });
        }
    });

    /****
    *** Team Member Management Section
    ****/
    static clientLogout = catchAsyncErrors(async (req, res, next) => {
        const { deviceType } = req.body;
        // console.log(req.user);
        // let conditions = { userId: req.user.id };
        // console.log(conditions);

        let clientpUdateFields = {};
        if (Number(deviceType) == 2) {
            clientpUdateFields.webLogin = '';
        } else {
            clientpUdateFields.appLogin = '';
        }
        var clientpUdate = await super.updateById(clientModel, req.user.id, clientpUdateFields);
        if (clientpUdate) {
            return res.status(200).json({
                status: true,
                message: "Logged out successfully",
                data: {}
            });
        }
    });

    static updateClientAdminProfile = catchAsyncErrors(async (req, res, next) => {
        let userId = req.user.id;

        let user = await clientModel.findOne({
            attributes: ['id', 'uuid', 'name', 'password', 'isVerified', 'database_name', 'email'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({
                status: false,
                message: "Client not found!",
                data: null,
            });
        }

        let updateFields = {};
        if (req.body.name) {
            updateFields.name = req.body.name;
        }
        if (req.body.email) {
            updateFields.email = req.body.email;
        }
        if (req.body.phone) {
            updateFields.phone = req.body.phone;
        }
        if (req.body.password) {
            if (!bcrypt.compareSync(req.body.current_password, user.password)) {
                return res.status(200).json({
                    status: false,
                    message: "Password does not match.",
                    data: {},
                });
            }
            updateFields.password = await bcrypt.hash(req.body.password, 10);
        }

        // =========== single file upload ================
        if (req.files.profileImage) {
            let imageData = await fileUploaderSingle(
                "src/public/uploads/user/",
                req.files.profileImage
            );
            updateFields.profileImage = imageData.newfileName;
        }

        if (user.database_name) {
            const updated = await super.updateById(clientModel, userId, updateFields);
        } else {
            user = await clientModel.findOne({});
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );
        const clientAdmin = await connection.ClientAdmin.update(updateFields, {
            where: { uuid: user.uuid }
        });

        return res.status(200).json({
            status: true,
            message: "Updated Successfuly!",
            data: updateFields
        });

    })

}

module.exports = UserController;
