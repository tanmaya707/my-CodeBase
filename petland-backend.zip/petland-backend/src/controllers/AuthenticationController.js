const axios = require("axios");
const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/errorHandler");
const RequestHandler = require("../utils/RequestHandler");
const Mailable = require("../helpers/email");
const bcrypt = require("bcryptjs");
const JWTAuth = require("../utils/jwtToken");
const jwt = require("jsonwebtoken");
const jwtConfig = require("../config").JWT;
const pkg = require("getmac").default;
const { Op } = require("sequelize");
// const validator = require('../helpers/validate');


const {
  calculateDistance,
  calculateDistanceInsTentApi,
  calculateTimeInKilometers,
  getRateChartCategory,
  slugify
} = require("../utils/utilities");
const {
  MSG_RECORD_STATUS_SUCCESS,
  MSG_RECORD_FETCH_SUCCESS,
} = require("../config/constants");
const requestHandler = new RequestHandler();

const db = require("../models");
// const rolesPermissionModel = require("../models/rolesPermissionModel");
const rolesPermissionModel = db.RolesPermissions;
const permissionModel = db.Permissions;
// const permissionModel = require("../models/permissionModel");
const userModel = db.Users;
const roleModel = db.Roles;
const modulesModel = db.Modules;
const userTokensModel = db.UserTokens;

// const rollModel = require('../models/rollModel');
// const rolePermissionModel = require('../models/rolePermissionModel');
// const rolePermissionUserwiseModel = require('../models/rolePermissionUserwiseModel');

class AuthenticationController extends BaseController {
  constructor() {
    super();
  }

  // ===================== Park Prime APIs WEB =====================
  static login = catchAsyncErrors(async (req, res, next) => {
    const { email, dialcode, phone, password, deviceType, fcmToken, deviceId, platform, } = req.body;
    if (!email) {
      return res.status(401).json({
        status: false,
        message: "Email is required",
        data: {},
      });
    }
    if (!password) {
      return res.status(401).json({
        status: false,
        message: "Password is required",
        data: {},
      });
    }
    // platform => "AdminPanel" <OR> "CustomerPanel"

    let rolesNotAllowedToLoginFromAdminPanel = await super.getByCustomOptions(req, roleModel, {
      where: {
        roleSlug: {
          [Op.in]: ["customer", "guest"]
        }
      },
    });

    let rolesNotAllowedIdsArr = [];
    rolesNotAllowedToLoginFromAdminPanel.forEach((role)=>{
      rolesNotAllowedIdsArr.push(role.id);
    });

    let condition = {};
    if (email) {
      condition["email"] = email;
    } else if (phone) {
      condition["phone"] = phone;
    }

    if (deviceType == 1) {
      if (!dialcode) {
        return next(new ErrorHandler("Please enter dialcode.", 403));
      } else {
        condition["dialcode"] = dialcode;
      }
    }

    let user = await userModel.findOne({
      where: {
        ...condition,
        isActive: true,
      },
      include: [
        {
          model: roleModel, 
          attributes: ["id", "roleName", "roleSlug"], 
          as: 'userRole',
          include: [
            {
              model: permissionModel, 
              attributes: ["slug"],
            },
          ],
        },
      ]
    });
    let permissions = [];
        
    if (user) {
      user['userRole'].forEach((obj) => {
        permissions = [...obj.permissions.map((o) => o.slug), ...permissions];
      })
      if(platform == "AdminPanel"){
        if(rolesNotAllowedIdsArr.includes(user['userRole.id'])){
          return res.status(401).json({
            status: false,
            message: "You are not authorized to use this panel with customer credentials. If you are an admin user or employee, please use the credentials specific to that. If you are a customer, head to the customer panel to book a spot. If you think, you are seeing this message by mistake, please contact the admin.",
            data: {},
          });
        }
      }
      // Password comparison
      if (!bcrypt.compareSync(password, user.password)) {
        return res.status(400).json({
          status: false,
          message: "Password does not match.",
          data: {},
        });
      } else {
        // Destructure user properties to exclude password
        const { id, userRole, firstName, lastName, email, dialCode, phone, ...rest } = user;
        // console.log('User Details', user['userRole.id']);
        
        let MAC = pkg();
        // console.log(MAC);
        let clientDeviceId = deviceId ? deviceId : "";
        let roleId = user['userRole'][0].id;
        let roleSlug = user['userRole'][0].roleSlug;
        // let permissions = user['userRole'][0].permissions;
        // console.log(roleSlug, permissions);
        let token = JWTAuth.ClientSign({
          id: id,
          roleId: roleId,
          roleSlug: roleSlug,
          firstName: firstName,
          lastName: lastName,
          email: email,
          phone: phone,
          deviceType: deviceType,
          macAddress: MAC,
          deviceId: clientDeviceId,
          permissions: permissions,
        });
        

        let time = new Date();
        time.setDate(time.getDate() + 30);
        time = new Date(time);

        // let conditions = { email: email };
        let updateFields = {
          loginFlag: true,
          macAddress: MAC,
          deviceId: clientDeviceId,
        };
        
        let userWebLoginToken = null;
        let userAppLoginToken = null;
        let userFcmToken = null;
        if (Number(deviceType) == 2) {
          userWebLoginToken = token;
          updateFields.webLogin = token;
        } else {
          userAppLoginToken = token;
          userFcmToken = fcmToken ? fcmToken : "";
          updateFields.appLogin = token;
          updateFields.fcmToken = fcmToken ? fcmToken : "";
        }

        // let userDetailsUpdate = await super.updateByCustomOptions(
        //   userModel,
        //   conditions,
        //   updateFields
        // );

        
        updateFields.userId = id;
        updateFields.deviceId = clientDeviceId;

        let tokenCondition = {userId: id, deviceId: clientDeviceId};
        let userToken = await userTokensModel.findOne({
          where: tokenCondition,
        });
        let userTokenDetailsUpdate = null;
        if(userToken){
          userTokenDetailsUpdate = await super.updateByCustomOptions(
            userTokensModel,
            tokenCondition,
            updateFields
          );
        }else{
          userTokenDetailsUpdate = await super.create(res, userTokensModel, updateFields);
        }
        // console.log(userTokenDetailsUpdate);
        
        let userDetail = await super.getByCustomOptionsSingle(req, userModel, {
          where: { email: email },
        });
        
        let userDetails = JSON.parse(JSON.stringify(userDetail));

        // Add necessary fields to userDetails and remove password ====
        let userDetailsToBeSent = {
          id,
          roleId,
          roleSlug,
          firstName,
          lastName,
          email,
          dialCode,
          phone,
          permissions,
          loginFlag: userDetails.loginFlag,
          isActive: userDetails.isActive,
          isVerified: userDetails.isVerified,
          webLogin: userWebLoginToken,
          appLogin: userAppLoginToken,
          fcmToken: userFcmToken,
          macAddress: userDetails.macAddress,
          deviceId: userDetails.deviceId,
          name: `${firstName} ${lastName}`,
          userImageUrl: process.env.API_URL + "uploads/userImages/",
          profileImage: userDetails.profileImage
            ? `${process.env.API_URL}uploads/userImages/${userDetails.profileImage}`
            : `${process.env.API_URL}uploads/userImages/demo_image.jpg`,
        };

        if (userTokenDetailsUpdate) {
          return res.status(200).json({
            status: true,
            message: "Logged in.",
            data: {
              user: userDetailsToBeSent,
            },
          });
        } else {
          return res.status(500).json({
            status: false,
            message: "Oops.. Something went terribly wrong..",
            data: {},
          });
        }
      }
    } else {
      return res.status(400).json({
        status: false,
        message: "No user with this email found.",
        data: {},
      });
    }
  });

  static logout = catchAsyncErrors(async (req, res, next) => {
    // let time = new Date();
    // time.setDate(time.getDate() - 1);
    // time = new Date(time);
    // let data = {};
    // if (Number(req.user.deviceType) == 2) {
    //   data = {
    //     webLogin: null,
    //   };
    // } else {
    //   data = {
    //     appLogin: null,
    //   };
    // }

    // // turning login flag off =====
    // data.loginFlag = false
    // // turning login flag off =====

    let conditions = { userId: req.user.id, deviceId: req.user.deviceId };  
    let updateFields = {
      loginFlag: false,
    };
    
    let updated = await super.updateByCustomOptions(
      userTokensModel,
      conditions,
      updateFields
    );

    // let updated = await super.updateById(
    //   userModel,
    //   req.user.id.toString(),
    //   data
    // );
    if (updated) {
      return res.status(200).json({
        status: true,
        message: "Logged out successfully",
      });
    }
  });

  /*static addEditRole = catchAsyncErrors(async (req, res, next) => {
    const { id, role_name } = req.body;
    const validationRule = {
      "role_name": "required|exist:Roles,roleName"
    };
    await validator(req.body, validationRule, {}, async (err, status) => {
        if (!status) {
            res.status(412)
                .send({
                    success: false,
                    message: 'Validation failed',
                    data: err
                });
        } else {
          // next();
          // if (!role_name) {
          //   return next(new ErrorHandler("Role name is required", 400));
          // }
          let roleAdded = await super.create(res, roleModel, {roleName: role_name, roleSlug: slugify(role_name)});
          if(roleAdded){
            return res.status(200).json({
              status: true,
              message: "Role added successfully",
              data: {errors: {}}
            });
          }else{
            return requestHandler.customError(res, 500, "Something went wrong.");
          }
        }
    }).catch( err => console.log(err))

  });*/
  static addEditRole = catchAsyncErrors(async (req, res, next) => {
    const { id, role_name } = req.body;
    if (!role_name) {
      return res.status(422).json({
        status: false,
        message: "Role name is required.",
        data: {},
      });
    }
    let condition = {
      deletedAt: null,
      roleName: role_name
    };
    if (id) {
      condition.id = `{
            [Op.ne]: id
        }`;
    }
    let checkExist = await roleModel.findOne({
      attributes: ["id"],
      where: condition,
    });
    if (checkExist) {
      return res.status(400).json({
        status: false,
        message: "Role name already exist!",
        data: checkExist,
      });
    }
    let updated = null;
    let message = "";
    if(id){
      updated = await super.updateById(roleModel, id, {roleName: role_name});
      message = "Role updated successfully";
    }else{
      updated = await super.create(res, roleModel, {roleName: role_name, roleSlug: slugify(role_name)});
      message = "Role added successfully";
    }
    if(updated){
      return res.status(200).json({
        status: true,
        message: message,
        data: {errors: {}}
      });
    }else{
      return requestHandler.customError(res, 500, "Something went wrong.");
    }

  });
  
  static deleteRole = catchAsyncErrors(async (req, res, next) => {
    const { id } = req.body;
    if (!id) {
      return next(new ErrorHandler("Role is required", 400));
    }
    // =================== soft delete ===================
    let roleDeleted = await super.softDeleteByCondition(
      roleModel, 
      {
        id: id,
      },
      req.user.id,
    );
    // =================== soft delete ===================
    if(roleDeleted[0]){
      return res.status(200).json({
        status: true,
        message: "Role deleted successfully"
      });
    }else{
      return requestHandler.customError(res, 500, "Something went wrong.");
    }
  });
  static roleList = catchAsyncErrors(async (req, res, next) => {
    let { searchText, excludedRoleSlug } = req.body;
    let roles = [];
    let queryConditions = {};
    let whereClause = {
      deletedAt: null,
    };
    if(excludedRoleSlug){
      whereClause.roleSlug = {
        [Op.notIn]: ["super-admin", excludedRoleSlug]
      };
    }

    if(searchText){
      // let searchId = searchText.toLowerCase().replace('accu-usr-','').replace(/^0+/, '');
      whereClause[Op.or] = [
        {
          id: 
          {
              [Op.like]: `%${searchText}%`
          }
        }, 
        {
          roleName: 
          {
              [Op.like]: `%${searchText}%`
          }
        }, 
        {
          roleSlug: 
          {
              [Op.like]: `%${searchText}%`
          }
        }
      ] ;
    }

    // if (req.method == "POST") {
    //   whereClause = {
    //     deletedAt: null,
    //     roleSlug: {
    //       [Op.notIn]: ["super-admin", "admin", "guest"]
    //     }
    //   };
    // } else if (req.method == "GET"){
    //   whereClause = {
    //     deletedAt: null,
    //     roleSlug: {
    //       [Op.not]: "super-admin",
    //     }
    //   };
    // }
    queryConditions = {
      where: whereClause
    };

    roles = await roleModel.findAll(queryConditions);
  
    if(roles){
      return res.status(200).json({
        status: true,
        message: "Success",
        data: roles
      });
    } else{
      return res.status(200).json({
        status: false,
        message: "No records found.",
        data: {}
      });
    }
  });
  static roleDetails = catchAsyncErrors(async (req, res, next) => {
    const { id, slug } = req.body;
    let queryConditions = {};

    if(id){
      queryConditions.id = id
    }
    if(slug){
      queryConditions.roleSlug = slug
    }

    let roleDetails = await super.getByCustomOptionsSingle(req, roleModel, {
      where: queryConditions,
    });
  
    if(roleDetails){
      return res.status(200).json({
        status: true,
        message: "Success",
        data: roleDetails
      });
    } else{
      return res.status(200).json({
        status: false,
        message: "No records found.",
        data: {}
      });
    }
  });

  static moduleList = catchAsyncErrors(async (req, res, next) => {
    let { searchText } = req.body;
    let modules = [];
    let whereClause = {
      deletedAt: null,
    };
    if(searchText){
      whereClause[Op.or] = [
        {
          id: 
          {
              [Op.like]: `%${searchText}%`
          }
        }, 
        {
          moduleName: 
          {
              [Op.like]: `%${searchText}%`
          }
        }, 
        {
          moduleSlug: 
          {
              [Op.like]: `%${searchText}%`
          }
        }
      ] ;
    }
    const queryConditions = {
      where: whereClause,      
      include: [
        {
          model: permissionModel, // including associated model
          attributes: ["id", "name", "slug"], // Attributes to select from the included model
        },
      ],
    };

    modules = await modulesModel.findAll(queryConditions);
  
    let userWithModules = [];
    let moduleAccessIdArr = [];
    let filteredModules = modules;
    /*if(req.user.id != 1){
      userWithModules = await userModel.findByPk(req.user.id, {
        include: modulesModel
      });
      console.log(userWithModules)
      userWithModules.modules.forEach((item)=>{
        moduleAccessIdArr.push(item.id);
      });
      filteredModules = modules.filter((item)=>{
        if(moduleAccessIdArr.includes(item.id)){
          return item;
        }
      });
    }*/

    if(filteredModules){
      return res.status(200).json({
        status: true,
        message: "Success",
        data: filteredModules
      });
    } else{
      return res.status(200).json({
        status: false,
        message: "No records found.",
        data: {}
      });
    }
  });
  static addEditModule = catchAsyncErrors(async (req, res, next) => {
    const { id, moduleName, parentModuleId } = req.body;
    if (!moduleName) {
      return res.status(422).json({
        status: false,
        message: "Module name is required.",
        data: {},
      });
    }
    let condition = {
      deletedAt: null,
      moduleName: moduleName
    };
    if (id) {
      condition.id = `{
            [Op.ne]: id
        }`;
    }
    let checkExist = await modulesModel.findOne({
      attributes: ["id"],
      where: condition,
    });
    if (checkExist) {
      return res.status(400).json({
        status: false,
        message: "Module name already exist!",
        data: checkExist,
      });
    }
    let updated = null;
    let message = "";
    if(id){
      updated = await super.updateById(modulesModel, id, {moduleName: moduleName, parentModuleId: parentModuleId});
      message = "Module updated successfully";
    }else{
      updated = await super.create(res, modulesModel, {moduleName: moduleName, moduleSlug: slugify(moduleName), parentModuleId: parentModuleId});
      let permissionData = [
        {
          moduleId: parseInt(updated.id), name: "View " + updated.moduleName, slug: 'view-' + updated.moduleSlug
        },
        {
          moduleId: parseInt(updated.id), name: "Add " + updated.moduleName, slug: 'add-' + updated.moduleSlug
        },
        {
          moduleId: parseInt(updated.id), name: "Edit " + updated.moduleName, slug: 'edit-' + updated.moduleSlug
        },
        {
          moduleId: parseInt(updated.id), name: "Delete " + updated.moduleName, slug: 'delete-' + updated.moduleSlug
        }
      ];
      await permissionModel.bulkCreate(permissionData, {returning: true});
      message = "Module added successfully";
    }
    if(updated){
      return res.status(200).json({
        status: true,
        message: message,
        data: {errors: {}}
      });
    }else{
      return requestHandler.customError(res, 500, "Something went wrong.");
    }

  });
  
  static deleteModule = catchAsyncErrors(async (req, res, next) => {
    const { id } = req.body;
    if (!id) {
      return next(new ErrorHandler("Module is required", 400));
    }
    // =================== soft delete ===================
    let moduleDeleted = await super.softDeleteByCondition(
      modulesModel, 
      {
        id: id,
      },
      req.user.id,
    );
    // =================== soft delete ===================
    if(moduleDeleted[0]){
      let permissionDeleted = await super.softDeleteByCondition(
        permissionModel, 
        {
          moduleId: id,
        },
        req.user.id,
      );
      return res.status(200).json({
        status: true,
        message: "Module deleted successfully"
      });
    }else{
      return requestHandler.customError(res, 500, "Something went wrong.");
    }
  });

  static permissionList = catchAsyncErrors(async (req, res, next) => {
    const { moduleId } = req.body;
    let permissions = [];
    let queryConditions = {
      deletedAt: null
    };

    if (moduleId) {
      queryConditions.moduleId = moduleId;
    }

    permissions = await permissionModel.findAll({
      where: queryConditions
    });
  
    if(permissions){
      return res.status(200).json({
        status: true,
        message: "Success",
        data: permissions
      });
    } else{
      return res.status(200).json({
        status: false,
        message: "No records found.",
        data: {}
      });
    }
  });

  static updateRolePermission = catchAsyncErrors(async (req, res, next) => {
    const { roleId, rolePermissions } = req.body;
    // if (!rolePermissions.length) {
    //   return res.status(422).json({
    //     status: false,
    //     message: "Role wise permissions are required.",
    //     data: {},
    //   });
    // }
    await super.deleteByCondition(
      rolesPermissionModel, 
      {
        roleId: roleId,
      }
    );
    
    let created = await rolesPermissionModel.bulkCreate(rolePermissions, {returning: true});
    
    if(created){
      return res.status(200).json({
        status: true,
        message: "Role wise permissions are updated.",
      });
    }else{
      return requestHandler.customError(res, 500, "Something went wrong.");
    }   

  });
  static getRolePermissions = catchAsyncErrors(async (req, res, next) => {
    const { roleId } = req.body;
    let rolePermissions = [];
    if (!roleId) {
      return res.status(422).json({
        status: false,
        message: "Role id is required.",
        data: {},
      });
    }
    rolePermissions = await rolesPermissionModel.findAll({
      attributes: ["roleId", "permissionId"],
      where: {
        roleId: roleId
      }
    });
  
    if(rolePermissions){
      return res.status(200).json({
        status: true,
        message: "Success",
        data: rolePermissions
      });
    } else{
      return res.status(200).json({
        status: false,
        message: "No records found.",
        data: {}
      });
    }
  });
  // static roleWiseModuleList = catchAsyncErrors(async (req, res, next) => {
  //   let { roleId } = req.body;
  //   let modules = [];
  //   const queryConditions = {
  //     where: {
  //       deletedAt: null,
  //     }
  //   };

  //   modules = await modulesModel.findAll(queryConditions);
  
  //   let userWithModules = [];
  //   let moduleAccessIdArr = [];
  //   let filteredModules = modules;
  //   if(req.user.id != 1){
  //     userWithModules = await userModel.findByPk(req.user.id, {
  //       include: modulesModel
  //     });
  //     userWithModules.modules.forEach((item)=>{
  //       moduleAccessIdArr.push(item.id);
  //     });
  //     filteredModules = modules.filter((item)=>{
  //       if(moduleAccessIdArr.includes(item.id)){
  //         return item;
  //       }
  //     });
  //   }

  //   if(filteredModules){
  //     return res.status(200).json({
  //       status: true,
  //       message: "Success",
  //       data: filteredModules
  //     });
  //   } else{
  //     return res.status(200).json({
  //       status: false,
  //       message: "No records found.",
  //       data: {}
  //     });
  //   }
  // });
  // ===================== Park Prime APIs WEB =====================


  static socialLogin = catchAsyncErrors(async (req, res, next) => {
    const { email, deviceType, userType, provider } = req.body;
    if (!email) {
      return next(new ErrorHandler("Email Required", 400));
    }
    let isRegistered = false;
    let condition = { email: email };
    if (userType && userType != "" && userType != null) {
      let roles = [];
      let role = await rollModel.find({
        name: "Driver",
      });
      if (userType == "Customer") {
        role = await rollModel.find({
          name: { $in: ["Corporate User", "Customer"] },
        });
      } else if (userType == "Corporate") {
        role = await rollModel.find({
          name: { $in: ["Corporate", "Vendor", "School"] },
        });
      }
      if (role.length > 0) {
        role.forEach((val) => {
          roles.push(val._id.toString());
        });
      }

      condition["roleId"] = { $in: roles };
    }
    const userExists = await userModel.findOne(condition);
    if (userExists) {
      isRegistered = true;
    }
    const currentDateTime = new Date();
    // const expirationDateTime = new Date(userExists.otp.expiration);
    if (
      // userExists.otp.expiration
      // && currentDateTime < expirationDateTime
      isRegistered == true
    ) {
      await userModel
        .findOne({
          email: email,
        })
        .then(async (user) => {
          if (user) {
            const { _id, firstName, lastName, email } = user;
            let token = JWTAuth.ClientSign({
              _id,
              firstName,
              lastName,
              email,
              deviceType,
              userType,
            });
            let time = new Date();
            time.setDate(time.getDate() + 30);
            time = new Date(time);
            let data = {};
            if (Number(deviceType, userType) == 2) {
              data = {
                webLogin: {
                  provider: provider ? provider : null,
                  accessToken: token,
                },
              };
            } else {
              data = {
                appLogin: {
                  provider: provider ? provider : null,
                  accessToken: token,
                },
              };
            }
            let userDetailUpdate = await userModel.findByIdAndUpdate(
              userExists._id,
              data
            );
            let userDetail = await userModel.findOne({ email: email });

            let userDetails = JSON.parse(JSON.stringify(userDetail));
            userDetails.name =
              userDetails.firstName + " " + userDetails.lastName;

            if (userDetailUpdate) {
              return requestHandler.sendSuccess(
                res,
                "Login Successfully"
              )({
                token,
                isRegistered: isRegistered,
                user: userDetails,
              });
            } else {
              return requestHandler.customError(
                res,
                500,
                "Something went wrong."
              );
            }
          } else {
            return requestHandler.customError(res, 400, "User not found.");
          }
        })
        .catch((error) => {
          console.log(error);
          return requestHandler.customError(res, 500, error);
        });
    } else {
      return requestHandler.customError(res, 404, "User not found.");
    }
  });

  static rolePermissionChecker = catchAsyncErrors(async (req, res, next) => {
    let rolePermissionChecker = [];
    let roleId = req.body.roleId;

    // ============== if superAdmin is trying to logIn give all module permissions by default ==========
    const modules = await moduleModel.find({
      isActive: true,
      isDeleted: false,
    });
    let modulesArr = [];
    modules.forEach((module) => {
      modulesArr.push(module._id);
    });
    const super_admin = await rollModel.findOne({ name: "Super Admin" });
    if (roleId == super_admin._id) {
      await rolePermissionModel
        .findOne({ roleId: super_admin._id })
        .then(async (item) => {
          await rolePermissionModel.findByIdAndUpdate(item._id, {
            roleId: super_admin._id,
            moduleId: modulesArr,

            updatedBy: super_admin._id,
          });
        });
    }
    // ============== if superAdmin is trying to logIn give all module permissions by default ==========

    await rolePermissionModel
      .findOne({
        roleId: roleId,
      })
      .then(async (item) => {
        if (item != null) {
          item?.moduleId.forEach((item) => {
            rolePermissionChecker.push(item.toString());
          });
        }
        if (rolePermissionChecker.length > 0) {
          return res.status(200).json({
            status: true,
            message: "Success, permissions found.",
            data: rolePermissionChecker,
          });
        } else {
          return res.status(401).json({
            status: false,
            message:
              "Oops! Looks like your role has no module permissions set yet. Please contact admin.",
            data: rolePermissionChecker,
          });
        }
      })
      .catch((error) => {
        console.log(error);
        return res.status(500).json({
          status: false,
          message: "Oops! Something went terribly wrong.",
          data: rolePermissionChecker,
        });
      });
  });
  static userPermissionChecker = catchAsyncErrors(async (req, res, next) => {
    let userPermissionChecker = [];
    let roleId = req.body.roleId;
    // ============== if superAdmin is trying to logIn give all module permissions by default ==========
    const modules = await moduleModel.find({
      isActive: true,
      isDeleted: false,
    });
    let modulesArr = [];

    modules.forEach((module) => {
      modulesArr.push(module._id);
    });
    const super_admin = await rollModel.findOne({ name: "Super Admin" });
    if (roleId == super_admin._id) {
      await rolePermissionModel
        .findOne({ roleId: super_admin._id })
        .then(async (item) => {
          await rolePermissionModel.findByIdAndUpdate(item._id, {
            roleId: super_admin._id,
            moduleId: modulesArr,
            updatedBy: super_admin._id,
          });
        });
    }
    // ============== if superAdmin is trying to logIn give all module permissions by default ==========
    if (roleId == super_admin._id) {
      await rolePermissionModel
        .findOne({
          roleId: roleId,
        })
        .then(async (item) => {
          if (item != null) {
            item?.moduleId.forEach((item) => {
              userPermissionChecker.push(item.toString());
            });
          }
          if (userPermissionChecker.length > 0) {
            return res.status(200).json({
              status: true,
              message: "Success, permissions found.",
              data: userPermissionChecker,
            });
          } else {
            return res.status(401).json({
              status: false,
              message:
                "Oops! Looks like your role has no module permissions set yet. Please contact admin.",
              data: userPermissionChecker,
            });
          }
        })
        .catch((error) => {
          return res.status(500).json({
            status: false,
            message: "Oops! Something went terribly wrong.",
            data: userPermissionChecker,
          });
        });
    } else {
      await rolePermissionUserwiseModel
        .findOne({
          userId: req.user._id,
        })
        .then(async (item) => {
          if (item != null) {
            item?.moduleId.forEach((item) => {
              userPermissionChecker.push(item.toString());
            });
          }
          if (userPermissionChecker.length > 0) {
            return res.status(200).json({
              status: true,
              message: "Success, permissions found.",
              data: userPermissionChecker,
            });
          } else {
            return res.status(401).json({
              status: false,
              message:
                "Oops! Looks like your role has no module permissions set yet. Please contact admin.",
              data: userPermissionChecker,
            });
          }
        })
        .catch((error) => {
          return res.status(500).json({
            status: false,
            message: "Oops! Something went terribly wrong.",
            data: userPermissionChecker,
          });
        });
    }
  });

  static forgotPassword = catchAsyncErrors(async (req, res, next) => {
    const { email, otp, uuid, password, confirm_password } = req.body;
    if (!email) {
      return next(new ErrorHandler("Please enter email", 400));
    }
    let condition = { email: email };
    const userExists = await userModel.findOne({where: condition});
    if (userExists) {
      if (otp && otp != "" && otp != null) {
        if (userExists.OTP && userExists.OTP.toString() == otp.toString()) {
          return res.status(200).json({
            status: true,
            message: "OTP verified successfully",
            uuid: userExists.uuid,
          });
          
        } else {
          return requestHandler.customError(res, 404, "OTP doesn't match");
        }
      }else if(uuid){
        if (!password) {
          return next(new ErrorHandler("Password is required", 400));
        }else if (!confirm_password) {
          return next(new ErrorHandler("Confirm password is required", 400));
        }else if(password != confirm_password){
          return requestHandler.customError(res, 404, "Password doesn't match");
        }else{
          let pass = await bcrypt.hash(password, 10);
          let updated = await super.updateByCustomOptions(
            userModel,
            {uuid: uuid},
            { 
              password: pass,
              otp: '' 
            }
          );
          console.log(updated);
          if(updated[0]){
            return res.status(200).json({
              status: true,
              message: "Password updated successfully"
            });
          }else{
            return requestHandler.customError(res, 500, "Something went wrong.");
          }
        }
      }else{
        const otpcode = Math.floor(1000 + Math.random() * 9000);
        // const currentDateTime = new Date();
        // const expirationDateTime = new Date(
        //   currentDateTime.setMinutes(currentDateTime.getMinutes() + 5)
        // );
        let updated = await super.updateById(
          userModel,
          userExists.id,
          { 
            OTP: otpcode 
          }
        );
        if(updated){
          return res.status(200).json({
            status: true,
            message: "OTP sent to your email",
            otp: otpcode,
          });
        }else{
          return requestHandler.customError(res, 500, "Something went wrong.");
        } 
      }
    } else {
      return requestHandler.customError(res, 404, "User not found.");
    }
  });

  static changePassword = catchAsyncErrors(async (req, res, next) => {
    const { old_password, password } = req.body;
    if (!old_password) {
      return next(new ErrorHandler("Old password required", 400));
    }
    if (!password) {
      return next(new ErrorHandler("New password required", 400));
    }
    let userExists = await userModel
      .findOne({ _id: req.user._id.toString() })
      .select("password");
    const isPasswordMatched = await userExists.comparePassword(old_password);
    if (!isPasswordMatched) {
      return res.status(400).json({
        status: false,
        message: "Old password does not match!",
        data: {},
      });
    } else {
      let pass = await bcrypt.hash(password, 10);
      let updated = await super.updateById(userModel, req.user._id.toString(), {
        password: pass,
      });
      if (updated) {
        return res.status(200).json({
          status: true,
          message: "Password changed successfully",
        });
      } else {
        return res.status(500).json({
          status: false,
          message: "Something went wrong",
        });
      }
    }
  });

  static deactivateAccount = catchAsyncErrors(async (req, res, next) => {
    const { isActive } = req.body;
    let data = {
      isActive: isActive,
    };
    if (isActive == false) {
      data["webLogin"] = null;
      data["appLogin"] = null;
    }

    let updated = await super.updateById(
      userModel,
      req.user._id.toString(),
      data
    );
    if (updated) {
      return res.status(200).json({
        status: true,
        message: "Updated successfully",
      });
    }
  });

  // =============================== App APIs ===========================
  static roleListForApp = catchAsyncErrors(async (req, res, next) => {
    let roles = [];
    let appRoles = [];
    let serviceRolesIdArr = [];
    if (req.method == "GET") {
      let userServices = await customerModel.find({
        userId: req.user._id,
      });
      userServices.forEach((userService) => {
        serviceRolesIdArr.push(userService.roleId.toString());
      });
      // for dropdown =====
      roles = await rollModel.find({
        isDeleted: { $ne: true },
        name: { $ne: "Super Admin" },
      });

      roles.forEach((role) => {
        if (serviceRolesIdArr.includes(role._id.toString())) {
          if (role.name == "Customer") {
            let roleObj = {
              _id: role._id,
              name: role.name,
              displayName: "Individual",
            };
            appRoles.push(roleObj);
          } else if (role.name == "Employee") {
            let roleObj = {
              _id: role._id,
              name: role.name,
              displayName: "Corporate Employee",
            };
            appRoles.push(roleObj);
          } else if (role.name == "Student") {
            let roleObj = {
              _id: role._id,
              name: role.name,
              displayName: "Student/Parent",
            };
            appRoles.push(roleObj);
          }
        }
      });
    } else if (req.method == "POST") {
      // roles = await rollModel.find({ isDeleted: { $ne: true }, name: { $ne: 'Super Admin'} });
    }

    if (appRoles.length > 0) {
      return res.status(200).json({
        status: true,
        message: "Success",
        data: appRoles,
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No Roles Found.",
        data: [],
      });
    }
  });
  // =============================== App APIs ===========================
}

module.exports = AuthenticationController;
