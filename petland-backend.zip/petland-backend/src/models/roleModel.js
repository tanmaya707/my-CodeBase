module.exports = (sequelize, DataTypes) => {
  const rolesSchema = sequelize.define("roles", {
    roleName: {
      type: DataTypes.STRING,
      allowNull: false,
    },

    createdAt: {
      field: "created_at",
      type: DataTypes.DATE,
    },
    updatedAt: {
      field: "updated_at",
      type: DataTypes.DATE,
    },

    deletedAt: {
      field: "deleted_at",
      type: DataTypes.DATE,
    },
  });

  return rolesSchema;
};
