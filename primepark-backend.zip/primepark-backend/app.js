const express = require("express");
const app = express();
const axios = require("axios");
const morgan = require("morgan")
const cors = require("cors");
const session = require('express-session');
const errorMiddleware = require("./src/middleware/error");
const cookieParser = require("cookie-parser");
const expressFileUpload = require("express-fileupload");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const path = require("path");
const cron = require("node-cron");
const moment = require('moment-timezone');
const timeZone = require("./src/config/index").Timezone;
const dateFns = require('date-fns');
const oneYear = 1000 * 60 * 60 * 24 * 365;
const { Op, Sequelize } = require("sequelize");

const db = require("./src/models");
const slotsModel = db.Slots;
const bookingRequestsModel = db.BookingRequests;

// app.use(express.json({ limit: "50mb" }))


app.use(express.json());
// app.use(express.urlencoded({ limit: "50mb", extended: true }))
app.use(express.static(`${__dirname}/src/public`));
app.use(
  express.urlencoded({
    extended: true,
  })
);
app.set('trust proxy', 1);
app.use(cookieParser());
app.use(expressFileUpload({ parseNested: true }));
app.use(cors());
/*************** Morgan Log Configuration ****************/
if (process.env.APP_ENV == 'production') {
  // app.use(morgan('combined'));
  app.use(morgan('dev'));
}
if (process.env.APP_ENV == 'development') {
  // app.use(morgan("combined"));
  app.use(morgan("dev"));
}
app.use(session({
  secret: "53536311secrctekeyfhgfgrfrty0687564rw3234e5659884fwir764",
  saveUninitialized:true,
  cookie: { maxAge: oneYear },
  resave: false
}));
app.use(
  helmet({
    contentSecurityPolicy: true,
    crossOriginOpenerPolicy: true,
    crossOriginEmbedderPolicy: true,
  })
);

// app.use('./public/uploads', express.static('uploads'))

// =================== express-rate-limit ===================
const limiter = rateLimit({
	windowMs: 1 * 1000, // 1 minutes
	max: 100, // limit each IP to 100 requests per windowMs
	message: "Too many requests from this IP, please try again later."
});
app.use(limiter);
// ========== error handling for rateLimit exceeded ============
app.use((err, req, res, next) => {
	if (err instanceof rateLimit.RateLimitError) {
			// Handle rate limit exceeded error
			res.status(429).send("Rate limit exceeded");
	} else {
			next(err);
	}
});
// ========== error handling for rateLimit exceeded ============
// =================== express-rate-limit ===================

// ======= use the route files here =======
app.use("/", require("./src/routes/authenticationRoute"));
app.use("/", require("./src/routes/policiesRoute"));
app.use("/", require("./src/routes/userRoute"));
app.use("/", require("./src/routes/vehicleTypesRoute"));
app.use("/", require("./src/routes/priceChartRoute"));
app.use("/", require("./src/routes/vendorRoute"));
app.use("/", require("./src/routes/slotsRoute"));
app.use("/", require("./src/routes/bookingRoute"));
app.use("/", require("./src/routes/agentRoute"));
app.use("/", require("./src/routes/agentBookingRequestMappingRoute"));
app.use("/", require("./src/routes/notificationRoute"));
app.use("/", require("./src/routes/transactionRoute"));
// ======= use the route files here =======

// app.use('src/public/uploads', express.static('uploads'));

// =====================================================================================
// --------------------------------------- CRONS ---------------------------------------
// =====================================================================================
cron.schedule(
  "*/10 * * * * *",
  async function () {
    // console.log("cron running");

    let momentZone = moment().tz(timeZone);
		// format today's date as dd-mm-yy without spaces or hyphens
		let todayDate = momentZone.format('DDMMYY'); // "280924" for 28-09-2024
		
		// format current time in 24 (hh:mm) format without spaces or hyphens
		let currentTime = momentZone.format('HHmm'); // "2230" for 22:30

    let checkTakenSlots = await slotsModel.findAll({
      where: {
        isActive: true,
        deletedAt: null,

        occupancyStatus: {
          [Op.in]: ["Occupied", "Booked"]
        },
      },
    });
    
    let takenSlotsIdArr = [];
    if(checkTakenSlots.length > 0){
      checkTakenSlots.forEach(async (slot) => {
        takenSlotsIdArr.push(slot.id);
      });
    }
    
    let bookingRequestsOfTakenSlots = await bookingRequestsModel.findAll({
      where: {
        slotId: {
          [Op.in]: takenSlotsIdArr
        }
      }
    });

    if(bookingRequestsOfTakenSlots.length > 0){
      bookingRequestsOfTakenSlots.forEach(async (bookingRequest)=>{
        let selectedToDate = bookingRequest.toDate;
        let selectedCheckOutTime = bookingRequest.selectedCheckOutTime;

        // console.log("selectedToDate ==>");
        // console.log(selectedToDate); // 2024-09-01
        // console.log("selectedCheckOutTime ==>");
        // console.log(selectedCheckOutTime); // 19:45:00
        
        // Combine selectedToDate and selectedCheckOutTime to form a full date-time object
        let selectedDateTime = moment(selectedToDate + ' ' + selectedCheckOutTime, 'YYYY-MM-DD HH:mm:ss');

        // Get the current date and time for comparison
        let currentDateTime = moment(momentZone.format('YYYY-MM-DD') + ' ' + currentTime, 'YYYY-MM-DD HHmm');
        
        // Compare the dates: Check if selectedDateTime is before the currentDateTime
        if (selectedDateTime.isBefore(currentDateTime)) {
          // console.log(`Booking for Slot ID ${bookingRequest.slotId} has exceeded the current time.`);
          
          // Add further actions here if needed, such as updating the booking status
          let updateFields = {
            occupancyStatus: "Overstay"
          };
          let markSlotAsOverStay = await slotsModel.update(
            updateFields,
            {
              where: {
                id: bookingRequest.slotId,
              }
            }
          );
          if(markSlotAsOverStay){
            // console.log(`Marked Booking for Slot ID ${bookingRequest.slotId} as OverStay.`);
          }
        } else {
          // console.log(`Booking for Slot ID ${bookingRequest.slotId} has NOT exceeded the current time.`);
        }
      });
    }
  }
)
// =====================================================================================
// --------------------------------------- CRONS ---------------------------------------
// =====================================================================================

app.use(errorMiddleware);
app.use('/uploads', express.static('src/public/uploads/'));

module.exports = app;
