const express = require('express');
const router = express.Router();
const slotController = require('../controllers/slotController')
const {
  isAuthenticated,
} = require('../middleware/auth')

// ===============================================================
// ==================== RUN FROM POSTMAN ONLY ====================
// ===============================================================
router.route('/create-slot-the-smart-way').post(isAuthenticated, slotController.createSlotsTheSmartWay);
// ===============================================================
// ==================== RUN FROM POSTMAN ONLY ====================
// ===============================================================

router.route('/slot-list').post(isAuthenticated, slotController.slotList);

router.route('/slot-analytics').post(isAuthenticated, slotController.slotAnalytics);

module.exports = router;