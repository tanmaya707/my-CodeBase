const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController')
const {
    isAuthenticated,
  } = require('../middleware/auth')


router.route('/user-add-update').post(isAuthenticated, userController.userAddUpdate);
router.route('/user-details').post(isAuthenticated, userController.userDetails);
router.route('/my-profile-details').post(isAuthenticated, userController.userProfileDetails);
router.route('/user-list').post(isAuthenticated, userController.userList);

router.route('/user-soft-delete').post(isAuthenticated, userController.userSoftDelete);
router.route('/user-reactivate').post(isAuthenticated, userController.userReactivate);

router.route('/user-permanent-delete').post(isAuthenticated, userController.userPermanentDelete);

// ============================ CUSTOMER APIs ============================
// -------------- forgot password --------------
router.route('/forgot-password-initiate').post(userController.forgotPasswordInitiate);
router.route('/validate-forgot-password-otp').post(userController.validateForgotPasswordOtp);

router.route('/reset-password').post(userController.resetPassword);
// -------------- forgot password --------------

router.route('/customer-register').post(userController.customerRegister);
router.route('/validate-customer-register-otp').post(userController.validateCustomerRegisterOtp);

router.route('/customer-current-checkins').post(isAuthenticated, userController.customerCurrentCheckins);
router.route('/customer-booking-history').post(isAuthenticated, userController.customerBookingHistory);
router.route('/request-to-mark-ready').post(isAuthenticated, userController.requestToMarkReady);
// ============================ CUSTOMER APIs ============================

// ============ from admin-end ============
router.route('/car-ready-status-change').post(isAuthenticated, userController.carReadyStatusChange);
// ============ from admin-end ============

module.exports = router;