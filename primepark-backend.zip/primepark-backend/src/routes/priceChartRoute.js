const express = require('express');
const router = express.Router();
const priceChartController = require('../controllers/priceChartController');
const {
  isAuthenticated,
} = require('../middleware/auth')


router.route('/price-chart-add-update').post(isAuthenticated, priceChartController.priceChartAddUpdate);
router.route('/price-chart-list').post(isAuthenticated, priceChartController.priceChartsList);
router.route('/price-chart-delete').post(isAuthenticated, priceChartController.priceChartDelete);

module.exports = router;