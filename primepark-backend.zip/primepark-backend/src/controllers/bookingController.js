const axios = require("axios");
const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/errorHandler");
const RequestHandler = require("../utils/RequestHandler");
const fileUploaderSingle = require("../utils/fileUpload").fileUploaderSingle;
const bcrypt = require("bcryptjs");
const JWTAuth = require("../utils/jwtToken");
const jwt = require("jsonwebtoken");
const jwtConfig = require("../config").JWT;
const { Op, Sequelize } = require("sequelize");
const APPURL = require("../config/index.js").APPURL;
const fs = require('fs');
const path = require('path');
const puppeteer = require('puppeteer');
const sendPushNotification = require("../helpers/sendPushNotification");

const timeZone = require("../config/index.js").Timezone;
const moment = require('moment-timezone');
const ccEmail = process.env.CC_EMAIL;

const mailer = require("nodemailer");

const {
	calculateDistance,
	calculateDistanceInsTentApi,
	calculateTimeInKilometers,
	getRateChartCategory,
} = require("../utils/utilities");
const {
	MSG_RECORD_STATUS_SUCCESS,
	MSG_RECORD_FETCH_SUCCESS,
} = require("../config/constants");
const sendMail = require("../helpers/email");
const requestHandler = new RequestHandler();

const db = require("../models");
const userModel = db.Users;
const roleModel = db.Roles;
const modulePermissionsModel = db.ModulePermissions;
const vendorModel = db.Vendors;
const priceChartsModel = db.PriceCharts;
const staticChargesModel = db.StaticCharges;
const parkingLotsModel = db.ParkingLots;
const slotsModel = db.Slots;
const bookingRequestsModel = db.BookingRequests;
const vehicleTypesModel = db.VehicleTypes;
const agentModel = db.Agents;
const agentBookingMappingsModel = db.AgentBookingMappings;
const carMovementsModel = db.CarMovements;
const invoiceModel = db.Invoices;
const notificationModel = db.Notifications;
const policiesModel = db.Policies;
const transactionModel = db.Transactions;
const transactionLogsModel = db.TransactionLogs;
const transactionHistoryModel = db.TransactionHistory;

class BookingController extends BaseController {
	constructor() {
		super();
	}

	static generateBookingTicket(businessNameInitials, groundNameInitials) {
		let momentZone = moment().tz(timeZone);
		// format today's date as dd-mm-yy without spaces or hyphens
		let todayDate = momentZone.format('DDMMYY'); // "280924" for 28-09-2024

		// format current time in 24 (hh:mm) format without spaces or hyphens
		let currentTime = momentZone.format('HHmm'); // "2230" for 22:30

		// -------- generate ticket --------
		let ticket = `${businessNameInitials}-${groundNameInitials}-${todayDate}-${currentTime}`;
		// -------- generate ticket --------

		return ticket;
	}

	static customerExistCheck = catchAsyncErrors(async (req, res, next) => {
		let { customerMobile } = req.body;

		let roleIdsToCheckArr = [];
		let cusotmerRole = await roleModel.findOne({
			where: {
				roleName: "Customer",
			}
		});
		roleIdsToCheckArr.push(cusotmerRole?.id);

		let guestRole = await roleModel.findOne({
			where: {
				roleName: "Guest",
			}
		});
		roleIdsToCheckArr.push(guestRole?.id);

		let checkReturningCustomer = await userModel.findOne({
			where: {
				deletedAt: null,
				phone: customerMobile,
				roleId: {
					[Op.in]: roleIdsToCheckArr
				},
			},
			include: [
				{
					model: roleModel,
				}
			],
			attributes: {
				exclude: [
					"password",
					"webLogin",
					"appLogin",
					"fcmToken",
					"OTP",
					"macAddress",
				],
			},
		});
		if (checkReturningCustomer) {
			return res.status(200).json({
				status: true,
				message: "Returning customer found.",
				data: checkReturningCustomer,
			});
		} else {
			return res.status(200).json({
				status: false,
				message: "New customer.",
				data: {},
			});
		}
	});

	static slotDeciderOld = catchAsyncErrors(async (req, res, next) => {
		let { vehicleTypeId, checkinDate, checkoutDate, startTime, endTime } = req.body;

		// Define startDate and endDate in the same time zone
		let startDate = moment.tz(checkinDate + " " + startTime, timeZone);
		let endDate = moment.tz(checkoutDate + " " + endTime, timeZone);

		// Calculate the difference in total minutes
		const totalMinutes = endDate.diff(startDate, 'minutes');

		// Calculate the full days, rounding up if minutes exceed 15
		// 1440 minutes in a day ---------------
		let dayCount = Math.floor(totalMinutes / 1440);
		// Remaining minutes after full days ---------------
		let remainingMinutes = totalMinutes % 1440;

		// Check if remaining minutes exceed 15 ---------------
		if (remainingMinutes > 15) {
			// Count an additional day if more than 15 minutes ---------------
			dayCount += 1;
		}

		let termArray = ["ST", "FM", "LT", "OF"];
		let term = "";
		if (dayCount <= 3) {
			// ===== SHORT TERM =====
			term = "ST";

		} else if (
			(dayCount >= 4) && (dayCount <= 15)
		) {
			// ===== FAST MOVING =====
			term = "FM";

		} else if (
			(dayCount >= 16)
		) {
			// ===== LONG TERM =====
			term = "LT";

		}

		let foundLotsIdArr = [];
		// ===== find lots according to STAY TERM =====
		foundLotsIdArr = await BookingController.findSlotTermWise(term);

		let searchedInTerms = [];
		if (foundLotsIdArr) {
			termArray.forEach((item, index) => {
				if (item == term) {
					searchedInTerms.push(term);
				}
			});
		}

		let slotAvailableInFoundLots = await slotsModel.findAll({
			where: {
				occupancyStatus: "Vacant",
				parkingLotId: {
					[Op.in]: foundLotsIdArr
				}
			},
			order: [["slotRowNumber", "DESC"]],
		});
		if (slotAvailableInFoundLots.length > 0) {
			// atleast one empty slot found =======
		} else {
			// search lot for another "term" =====

		}

		return res.status(200).json({
			status: true,
			data: {
				dayCount: dayCount,
				slotAvailableInFoundLots: slotAvailableInFoundLots,
			}
		});
	});

	static checkSlotValidity = catchAsyncErrors(async (req, res, next) => {
		let { slotName } = req.body;

		let foundSlot = await slotsModel.findOne({
			where: Sequelize.where(
				Sequelize.fn('lower', Sequelize.col('slotName')),
				Sequelize.fn('lower', `${slotName}`)
			),
			include: [
				{ model: parkingLotsModel }
			],
		});

		let message = 'The Slot is invalid';

		if (foundSlot) {
			if (foundSlot.occupancyStatus == 'Vacant') {
				let termArr = foundSlot.parkingLot.lotName.split("-");
				let term = termArr[termArr.length - 1];
				switch (term) {
					case "ST":
						message = 'The Slot is available. The minimum day for booking is 1 and the maximum day is 3.';
						break;
					case "FM":
						message = 'The Slot is available. The minimum day for booking is 4 and the maximum day is 15.';
						break;
					case "LT":
						message = 'The Slot is available. The minimum day for booking is 16';
						break;
				}

				return res.status(200).json({
					status: true,
					message: message,
					data: {
						foundSlot: foundSlot ?? [],
					}
				});
			} else {
				message = 'The Slot is already booked';
			}

		}
		return res.status(200).json({
			status: false,
			message: message,
			data: {
				foundSlot: foundSlot ?? [],
			}
		});
	});

	static slotDecider = catchAsyncErrors(async (req, res, next) => {
		let { vehicleTypeId, checkinDate, checkoutDate, startTime, endTime } = req.body;

		// Define startDate and endDate in the same time zone
		// let startDate = moment.tz(checkinDate+ " " +startTime, timeZone);
		// let endDate = moment.tz(checkoutDate+ " " +endTime, timeZone);

		let startDate = moment.tz(checkinDate, timeZone).startOf('day');
		let endDate = moment.tz(checkoutDate, timeZone).endOf('day');
		let dayCount = endDate.diff(startDate, 'days') + 1;

		// Calculate the difference in total minutes
		// const totalMinutes = endDate.diff(startDate, 'minutes');

		// Calculate the full days, rounding up if minutes exceed 15
		// 1440 minutes in a day ---------------
		// let dayCount = Math.floor(totalMinutes / 1440); 
		// Remaining minutes after full days ---------------
		// let remainingMinutes = totalMinutes % 1440; 

		// // Check if remaining minutes exceed 15 ---------------
		// if (remainingMinutes > 15) {
		// 	// Count an additional day if more than 15 minutes ---------------
		// 	dayCount += 1; 
		// }

		// let termArray = ["ST", "FM", "LT", "OF"];
		let termArray = {
			"ST": {
				"minDays": 1, "maxDays": 3
			},
			"FM": {
				"minDays": 4, "maxDays": 15
			},
			"LT": {
				"minDays": 16, "maxDays": 365
			},
		};
		let term = "";
		if (dayCount <= 3) {
			// ===== SHORT TERM =====
			term = "ST";
		} else if (
			(dayCount >= 4) && (dayCount <= 15)
		) {
			// ===== FAST MOVING =====
			term = "FM";
		} else if (
			(dayCount >= 16)
		) {
			// ===== LONG TERM =====
			term = "LT";
		}

		let bookedSlot = await BookingController.getBookingSlotByLot(termArray, dayCount, term);

		return res.status(200).json({
			status: true,
			data: {
				dayCount: dayCount,
				bookedSlot: bookedSlot,
				// daysArr: daysArr.reverse(),
				// slotAvailableInFoundLots: foundLotsIdArr,
			}
		});
	});
	static async getBookingSlotByLot(termArray = {}, dayCount = 0, term = "ST") {
		let minDays = termArray[term].minDays;
		let maxDays = termArray[term].maxDays;

		var foundLotsIdArr = await BookingController.findLotsWithAvailableSlots(term);

		let parkingLotCount = foundLotsIdArr.length;
		const step = (maxDays - minDays) / parkingLotCount;
		const daysArr = Array.from({ length: parkingLotCount }, (_, i) => Math.ceil(minDays + (i * step)));

		let lotKey = BookingController.findClosest(daysArr, dayCount);

		let bookedSlot = BookingController.getBookingSlot(foundLotsIdArr, daysArr, lotKey);
		if (bookedSlot == null) {
			if (term == "ST") {
				term = "FM";
				bookedSlot = BookingController.getBookingSlotByLot(termArray, dayCount, term);
			} else if (term == "FM") {
				term = "LT";
				bookedSlot = BookingController.getBookingSlotByLot(termArray, dayCount, term);
			}
		}
		return bookedSlot;
	}
	static getBookingSlot(availableLots, daysArr, lotKey = 0, updatedKey = 0, isPrevious = false, isNext = false) {
		if (!isPrevious && !isNext) {
			isPrevious = true;
			isNext = false;
		} else if (isPrevious && !isNext) {
			lotKey -= updatedKey;
			isPrevious = false;
			isNext = true;
		} else if (!isPrevious && isNext) {
			lotKey += updatedKey;
			isPrevious = true;
			isNext = false;
		}
		updatedKey++;
		if (lotKey >= 0 && lotKey <= availableLots.length) {
			if (availableLots[lotKey]?.slots.length) {
				return availableLots[lotKey].slots[0];
			} else {
				return BookingController.getBookingSlot(
					availableLots,
					daysArr,
					lotKey,
					updatedKey,
					isPrevious,
					isNext
				);
			}
		} else {
			return null;
		}
	}
	static async findLotsWithAvailableSlots(term = "ST") {
		let foundLots = [];
		foundLots = await parkingLotsModel.findAll({
			attributes: [
				'id', 'lotName'
			],
			where: {
				lotName: {
					[Op.like]: `%${term}%`
				},
			},
			include: [
				{ model: slotsModel, as: 'slots', where: { occupancyStatus: "Vacant" } }
			],
			order: [["slots", "slotRowNumber", "DESC"]],
		});

		return foundLots;
	}
	static findClosest(arr, target) {
		let left = 0,
			right = arr.length - 1;
		while (left < right) {
			if (Math.abs(arr[left] - target) <= Math.abs(arr[right] - target)) {
				right--;
			} else {
				left++;
			}
		}
		//return arr[left];
		return left;
	}

	static async findSlotTermWise(term = "ST") {
		let foundLots = [];
		foundLots = await parkingLotsModel.findAll({
			where: {
				lotName: {
					[Op.like]: `%${term}%`
				}
			}
		});
		let foundLotsIdArr = [];
		foundLots.forEach((lot) => {
			foundLotsIdArr.push(lot.id);
		});

		return foundLotsIdArr;
	}

	static async bookingRequestUpdate(id, data) {
		let slotStatusUpdate = await super.updateById(bookingRequestsModel, id, data);
		return slotStatusUpdate;
	}

	static bookingRequestList = catchAsyncErrors(async (req, res, next) => {
		let loggedUserId = req.user.id;

		let loggedUserDetail = await super.getByCustomOptionsSingle(req, userModel, {
			where: {
				id: loggedUserId,
			},
			include: [
				{
					model: roleModel,
				}
			]
		});

		let roleOfLoggedUser = await super.getByCustomOptionsSingle(req, roleModel, {
			where: {
				id: loggedUserDetail?.roleId,
			}
		});

		let options = {
			include: [
				{
					model: userModel,
					attributes: {
						exclude: [
							"password",
							"webLogin",
							"appLogin",
							"fcmToken",
							"OTP",
							"macAddress",
						],
					},
					required: false,
				},
				{
					model: slotsModel,
					required: false,
				},
				{
					model: agentBookingMappingsModel,
					include: [
						{
							model: agentModel,
							required: false,
						},
					],
				},
			],
			where: {
				isActive: true,
				deletedAt: null,
			},
			order: [["createdAt", "DESC"]],
		};

		let totalCount = await bookingRequestsModel.count();
		let bookingRequests = await super.getList(req, bookingRequestsModel, options);

		let filteredBookingRequestsUserWise = [];
		filteredBookingRequestsUserWise = bookingRequests;

		// if(roleOfLoggedUser.roleName == "Super Admin"){
		// 	filteredBookingRequestsUserWise = bookingRequests;
		// }

		// if(roleOfLoggedUser.roleName == "Agent"){
		// 	// --------- agent can only see the bookings he is tagged in ---------
		// 	// filteredBookingRequestsUserWise = bookingRequests.filter(async (bookingRequest)=>{
		// 	// 	if(bookingRequest?.agentBookingMapping?.agent?.userId == loggedUserId){
		// 	// 		return bookingRequest;
		// 	// 	}
		// 	// });
		// }

		if (filteredBookingRequestsUserWise.length > 0) {
			return res.status(200).json({
				status: true,
				message: "Data found.",
				data: filteredBookingRequestsUserWise,
				totalCount: totalCount,
			});
		} else {
			return res.status(200).json({
				status: false,
				message: "No data found.",
				data: {}
			});
		}
	});

	static bookingRequestDetail = catchAsyncErrors(async (req, res, next) => {
		let {
			// ================= INSTRUCTIONS =================
			// ===== send parameter/s from either Group-1 <or> Group-2 ======
			// ================= INSTRUCTIONS =================

			// ============= Group-1 ============= 
			// ---- single search fields (send either of the following ones) ----
			bookingRequestId,
			bookingTicketNo,
			// ---- single search fields (send either of the following ones) ----
			// ============= Group-1 ============= 

			// ============= <OR> =============

			// ============= Group-2 ============= 
			// ---- search with these 2 fields is possible together (send single <or> both as per need)----
			customerMobile,
			plateNumber,
			// ---- search with these 2 fields is possible together (send single <or> both as per need)----
			// ============= Group-2 ============= 
		} = req.body;

		if (!bookingRequestId && !bookingTicketNo && !customerMobile && !plateNumber) {
			return res.status(422).json({
				status: false,
				message: "Blank search not allowed. Please search with either bookingRequestId <or> bookingTicketNo <or> customerMobile <or> plateNumber",
				data: {}
			});
		}

		let searchOptions = {};

		if (bookingRequestId) {
			searchOptions.id = bookingRequestId;

		} else if (bookingTicketNo) {
			searchOptions.bookingTicketNo = bookingTicketNo;

		} else if (customerMobile || plateNumber) {
			// ===== only these two things can be searched together =====
			if (customerMobile) {
				searchOptions.customerMobile = customerMobile;
			}
			if (plateNumber) {
				searchOptions.plateNumber = plateNumber;
			}
			// ===== only these two things can be searched together =====
		}

		let bookingRequest = await super.getByCustomOptionsSingle(
			req,
			bookingRequestsModel,
			{
				where: searchOptions,
				include: [
					{
						model: slotsModel
					},
					{
						model: userModel,
						attributes: {
							exclude: [
								"password",
								"webLogin",
								"appLogin",
								"fcmToken",
								"OTP",
								"macAddress",
							],
						},

					}
				],
			}
		);

		if (bookingRequest) {
			if (bookingRequest.isCancelled) {
				return res.status(200).json({
					status: false,
					message: "Booking request data found. But request was cancelled.",
					data: bookingRequest
				});
			}
			return res.status(200).json({
				status: true,
				message: "Booking request found.",
				data: bookingRequest
			});
		} else {
			return res.status(400).json({
				status: false,
				message: "No data found.",
				data: {}
			});
		}
	});

	static bookingRequestCreate = catchAsyncErrors(async (req, res, next) => {
		let { bookingPlatform, logInType, customerId, vehicleTypeId, transactionHistoryId, transactionCreatedId, firstName, lastName, email, dialCode, phone, plateNumber, fromDate, selectedCheckInTime, toDate, selectedCheckOutTime, passengerCount, vendorId, reservationId, actualvehicleTypeId, actualFromDate, actualCheckInTime, actualToDate, actualCheckOutTime, slotId, onSiteChargeForVendor, platformMedium } = req.body;

		let roleOfSuperAdmin = await super.getByCustomOptionsSingle(req, roleModel, {
			where: {
				roleName: "Super Admin",
			},
		});

		let superUser = await super.getByCustomOptionsSingle(req, userModel, {
			where: {
				roleId: roleOfSuperAdmin?.id,
			},
		});

		if (!bookingPlatform) {
			// ==== bookingPlatform => "adminPanel", "customerPanel"
			return res.status(422).json({
				status: false,
				message: "Booking platform is required.",
				data: {},
			});
		}
		if ((bookingPlatform != "adminPanel") && (bookingPlatform != "customerPanel")) {
			return res.status(422).json({
				status: false,
				message: `Booking platform can either be "adminPanel", "customerPanel"`,
				data: {},
			});
		}
		if (bookingPlatform == "customerPanel") {
			// ==== bookingPlatform =>"adminPanel", "customerPanel"
			if (!logInType) {
				return res.status(422).json({
					status: false,
					message: `Please specify login type: "as a guest" or "as a customer".`,
					data: {},
				});
			}
			if ((logInType != "Guest") && (logInType != "Customer")) {
				return res.status(422).json({
					status: false,
					message: `Login type can either be "Guest" or "Customer".`,
					data: {},
				});
			}
		}
		if (!vehicleTypeId) {
			return res.status(422).json({
				status: false,
				message: "Vehicle type is required.",
				data: {},
			});
		}
		// if(!transactionHistoryId){
		// 	return res.status(422).json({
		// 		status: false,
		// 		message: "Transaction history id is required.",
		// 		data: {},
		// 	});
		// }
		if (!email) {
			return res.status(422).json({
				status: false,
				message: "Email is required.",
				data: {},
			});
		}

		if (!phone || !dialCode) {
			return res.status(422).json({
				status: false,
				message: "Phone and dialcode is required.",
				data: {},
			});
		}
		if (!plateNumber || !fromDate || !selectedCheckInTime || !toDate || !selectedCheckOutTime) {
			return res.status(422).json({
				status: false,
				message: "Plate no., From Date, Check-in time, To Date, Check-out time is required.",
				data: {},
			});
		}

		let cusotmerRole = await roleModel.findOne({
			where: {
				roleName: "Customer",
			}
		});

		let createCustomer = {};
		let transactionUpdate = {};
		let transactionHistoryUpdate = {};
		if (!customerId || customerId == '' || customerId == null || customerId == undefined) {
			// ========= login as guest =========
			// --------- guest customer profile should be created ---------
			let guestRole = await roleModel.findOne({
				where: {
					roleName: "Guest",
				}
			});
			// ----- default password for guests -----
			let password = "password";
			let encryptedPass = await bcrypt.hash(password, 10);
			// ----- default password for guests -----

			let customerData = {
				roleId: guestRole.id,
				// firstName: "Guest",
				// lastName: "User",
				firstName: firstName,
				lastName: lastName,
				email: email,
				dialCode: dialCode,
				phone: phone,
				password: encryptedPass,
			};
			createCustomer = await super.create(res, userModel, customerData);

			if (createCustomer) {
				// ===== created customerId =====
				customerId = createCustomer.id;
				// ===== created customerId =====

				if (transactionCreatedId) {
					transactionUpdate = await super.updateByCustomOptions(
						transactionModel,
						{
							id: transactionCreatedId
						},
						{
							userId: customerId,
						}
					);
				}

				if (transactionHistoryId) {
					transactionHistoryUpdate = await super.updateByCustomOptions(
						transactionHistoryModel,
						{
							id: transactionHistoryId
						},
						{
							userId: customerId,
						}
					);

				}
			} else {
				return res.status(400).json({
					status: false,
					message: "Oops.. we ran into some problem and can't proceed with the booking..!!",
					data: {},
				});
			}
		} else {
			if (!firstName || !lastName) {
				return res.status(422).json({
					status: false,
					message: "First Name and Last Name is required.",
					data: {},
				});
			}

			if (transactionCreatedId) {
				transactionUpdate = await super.updateByCustomOptions(
					transactionModel,
					{
						id: transactionCreatedId
					},
					{
						userId: customerId,
					}
				);
			}

			if (transactionHistoryId) {
				transactionHistoryUpdate = await super.updateByCustomOptions(
					transactionHistoryModel,
					{
						id: transactionHistoryId
					},
					{
						userId: customerId,
					}
				);
			}
		}

		// ============== booking STARTS ==============
		// ----- auto-generate booking ticket -----
		let bookingTicketNo = BookingController.generateBookingTicket("PP", "JFKA");
		// ----- auto-generate booking ticket -----
		let bookingData = {
			customerId: customerId,
			// ----- to be decided by "/decide-slot" API -----
			slotId: slotId,
			// ----- to be decided by "/decide-slot" API -----

			vehicleTypeId: vehicleTypeId,
			passengerCount: passengerCount ? passengerCount : 4,
			transactionHistoryId: transactionHistoryId ?? transactionHistoryId,

			customerMobile: phone,
			plateNumber: plateNumber,

			fromDate: fromDate,
			selectedCheckInTime: selectedCheckInTime,

			toDate: toDate,
			selectedCheckOutTime: selectedCheckOutTime,

			bookingStatus: "Booked",

			bookingTicketNo: bookingTicketNo,
		};

		let checkSlot = {};
		if (slotId) {
			checkSlot = await super.getByCustomOptionsSingle(req, slotsModel, {
				where: {
					id: slotId,
				},
			});

			if (checkSlot.occupancyStatus != "Vacant") {
				return res.status(422).json({
					status: false,
					message: "Ooppss..!! Someone already booked this slot while you were filling up the form. Please try again.",
					data: {}
				});
			}
		}

		let createBookingRequest = await super.create(res, bookingRequestsModel, bookingData);
		// ============== booking ENDS ==============

		if (createBookingRequest) {
			let customer = await super.getByCustomOptionsSingle(req, userModel, {
				where: {
					id: customerId,
				}
			});



			// Define startDate and endDate in the same time zone
			// let startDate = moment.tz(fromDate+ " " +selectedCheckInTime, timeZone);
			// let endDate = moment.tz(toDate+ " " +selectedCheckOutTime, timeZone);

			let startDate = moment.tz(fromDate, timeZone).startOf('day');
			let endDate = moment.tz(toDate, timeZone).endOf('day');
			let dayCount = endDate.diff(startDate, 'days') + 1;

			// Calculate the difference in total minutes
			// const totalMinutes = endDate.diff(startDate, 'minutes');

			// Calculate the full days, rounding up if minutes exceed 15
			// 1440 minutes in a day ---------------
			// let dayCount = Math.floor(totalMinutes / 1440); 
			// Remaining minutes after full days ---------------
			// let remainingMinutes = totalMinutes % 1440; 

			// // Check if remaining minutes exceed 15 ---------------
			// if (remainingMinutes > 15) {
			// 	// Count an additional day if more than 15 minutes ---------------
			// 	dayCount += 1; 
			// }
			let staticCharges = await staticChargesModel.findOne({
				where: {
					parkingGroundId: 1,
					isActive: true,
				},
			});
			let priceChart = await priceChartsModel.findOne({
				where: {

					vehicleTypeId: vehicleTypeId,
					isActive: true,
				},
			});
			let vehicleTypeName = await vehicleTypesModel.findOne({
				where: {

					id: vehicleTypeId,
					isActive: true,
				},
			});

			let reservationAmount = staticCharges.reservationCharge;
			let onlineBookingAmount = staticCharges.onlineBookingCharge;
			let parkingChargeTotal = 0;
			let overSizeChargeTotal = 0;

			let extraPassengers = 0;
			let extraPassengerChargesTotal = 0;
			let pCount = passengerCount ? passengerCount : 4;
			// ----- extra charges for more than 4 passengers -----
			if (Number(pCount) > Number(staticCharges.defaultPassengerCount)) {
				extraPassengers = Number(pCount) - Number(staticCharges.defaultPassengerCount);
			}
			// ----- extra charges for more than 4 passengers -----
			extraPassengerChargesTotal = Number(extraPassengers) * Number(staticCharges.extraPassengerChargePerHead);

			let overstayAmountTotal = 0;
			let payableAmount = 0;

			let earlyCheckinAmountTotal = 0;
			let totalExtraDays = 0;

			
			if (onSiteChargeForVendor && vendorId) {
				parkingChargeTotal = Number(dayCount) * Number(priceChart.overSizeRate);
			} else {
				if (platformMedium != "AdminBooking") {
					parkingChargeTotal = Number(dayCount) * (Number(priceChart.dailyParkingRate) + Number(priceChart.overSizeRate));
				} else {
					parkingChargeTotal = Number(dayCount) * Number(priceChart.dailyParkingRate)
				}
			}

			// if (vendorId) {
			// 	parkingChargeTotal = Number(dayCount) * Number(priceChart.overSizeRate);
			// } else {
			// 	parkingChargeTotal = Number(dayCount) * Number(priceChart.dailyParkingRate);
			// }



			let today = moment.tz(timeZone).startOf('day');
			let checkedDate = moment.tz(fromDate, timeZone).startOf('day');
			totalExtraDays = checkedDate.diff(today, 'days');

			if (
				bookingPlatform == "adminPanel"
			) {
				earlyCheckinAmountTotal = Number(totalExtraDays) * Number(priceChart.dailyParkingRate);
				// if(Number(totalExtraDays) == 0){
				// 	let extraMinutes = moment.tz(fromDate+ " " +selectedCheckInTime, timeZone).diff(moment.tz(timeZone), 'minutes');
				// 	console.log("extraMinutes ====>");
				// 	console.log(extraMinutes);

				// 	if(extraMinutes > 120){
				// 		earlyCheckinAmountTotal = Number(priceChart.dailyParkingRate);
				// 	}
				// }
				onlineBookingAmount = 0;
			}

			onSiteChargeForVendor = onSiteChargeForVendor ? onSiteChargeForVendor : 0;
			payableAmount = Number(parkingChargeTotal) + Number(overSizeChargeTotal) + Number(extraPassengerChargesTotal) + Number(overstayAmountTotal) + Number(onSiteChargeForVendor) + Number(earlyCheckinAmountTotal) + Number(onlineBookingAmount);

			let paidAmount = 0;

			if (
				bookingPlatform != "adminPanel"
			) {
				if (Number(payableAmount) <= (Number(reservationAmount))) {
					paidAmount = payableAmount - Number(onlineBookingAmount);
				} else {
					paidAmount = Number(reservationAmount);
				}
			}


			let dueAmount = Number(payableAmount) - Number(paidAmount);

			let policies = await policiesModel.findOne({
				where: {
					deletedAt: null,
					policies: {
						[Op.ne]: null
					},
				},
			});

			let slotName = checkSlot?.slotName
			let policie = policies?.policies
			let vehicleName = vehicleTypeName?.typeName
			let earlyCheckinAmount = Math.abs(earlyCheckinAmountTotal)
			let onlineBookAmount = Number(onlineBookingAmount)


			if (bookingPlatform == "adminPanel") {
				// ----- admin panel -----
				let slotStatusUpdate = await super.updateById(slotsModel, slotId, {
					occupancyStatus: "Occupied"
				});
				// ----- create carMovementRecord -----
				let carMovementData = {
					bookingRequestId: createBookingRequest.id,
					actualvehicleTypeId: actualvehicleTypeId,

					actualFromDate: actualFromDate,
					actualCheckInTime: actualCheckInTime,

					// actualToDate: actualToDate,
					// actualCheckOutTime: actualCheckOutTime,
				};
				if (vendorId) {
					// ----- booking through a vendor -----
					carMovementData.vendorId = vendorId ?? vendorId;
					carMovementData.reservationId = reservationId ?? reservationId;
					carMovementData.onSiteChargeForVendor = onSiteChargeForVendor ?? onSiteChargeForVendor;
				}
				let carMovementRecordCreate = await super.create(res, carMovementsModel, carMovementData);

				if (carMovementRecordCreate) {
					// ----- car movement record created -----
					console.log(`Car movement record created. carMovementId: ${carMovementRecordCreate.id}`);

					// ----- check-in -----
					let dataToBeUpdated = {
						bookingStatus: "Checked In",
					};
					let checkInTheBookedRequest = await super.updateByCustomOptions(
						bookingRequestsModel,
						{
							id: createBookingRequest.id,
						},
						dataToBeUpdated
					);
					if (checkInTheBookedRequest) {
						console.log("Booking from admin panel, so checked-in as well.");
					}
					// ----- check-in -----
					let createdBookingRequest = await super.getByCustomOptionsSingle(req, bookingRequestsModel, {
						where: {
							id: createBookingRequest.id,
						},
					});

					// ================================
					// ----- Handle Notifications -----
					// ================================
					// ----- send successful booking notification -----

					// ----- 1. to customer -----
					let notiDataForCustomer = {
						userId: customerId ?? customerId,
						bookingRequestId: createdBookingRequest?.id,

						notiTitle: `On Site Booking Successful..!! Spot confirmed..!!`,

						notiBody: `Dear Customer, Booking confirmed. Parking slot no.: ${checkSlot?.slotName}; Slot location: [Bay-no.: ${checkSlot?.slotBayNumber}, Row-no.: ${checkSlot?.slotRowNumber}]. For more details, please refer to ticket: ${createdBookingRequest?.bookingTicketNo}.`
					}
					let createNotificationForCustomer = await super.create(res, notificationModel, notiDataForCustomer);

					//  ========== push noti ==========
					console.log("------ Sending booking Notification ----");
					let messages = {
						title: "On Site Booking Successful..!! Spot confirmed..!!",
						body: JSON.stringify({
							// "tripId": tripPassenger.tripId._id.toString(),
							"msg": `Dear Customer, Booking confirmed. Parking slot no.: ${checkSlot?.slotName}; Slot location: [Bay-no.: ${checkSlot?.slotBayNumber}, Row-no.: ${checkSlot?.slotRowNumber}]. For more details, please refer to ticket: ${createdBookingRequest?.bookingTicketNo}.`,
							"type": "Show"
						}),
					};
					if (customer?.fcmToken) {
						await sendPushNotification(customer?.fcmToken, messages, "android");
					}
					//  ========== push noti ==========
					// ----- 1. to customer -----

					// ----- 2. to super admin -----
					let notiDataForSuperAdmin = {
						userId: superUser.id ?? superUser.id,
						bookingRequestId: createdBookingRequest?.id,

						notiTitle: `New On Site Booking Made..!!`,

						notiBody: `Dear Admin, Booking confirmed. Parking slot no.: ${checkSlot?.slotName}; Slot location: [Bay-no.: ${checkSlot?.slotBayNumber}, Row-no.: ${checkSlot?.slotRowNumber}]; assigned to customer (${createCustomer?.firstName} ${createCustomer?.lastName})(Ph.: ${phone ?? phone}). For more details, please refer to ticket: ${createdBookingRequest?.bookingTicketNo}.`
					}
					let createNotificationForSuperAdmin = await super.create(res, notificationModel, notiDataForSuperAdmin);
					// ----- 2. to super admin -----

					// ----- send successful booking notification -----
					// ================================
					// ----- Handle Notifications -----
					// ================================
					// createdBookingRequest.reservationId = reservationId;

					let content = `
					<div>
						Dear ${customer?.firstName}, 
						<p>Thank you for choosing Prime Park. Your booking is now confirmed. Please find the details of your booking below.</p>
						Parking slot no.: ${checkSlot?.slotName} <br/>
						Slot location: [Bay-no.: ${checkSlot?.slotBayNumber} <br/> 
						Row-no.: ${checkSlot?.slotRowNumber}]. <br/>
						<strong>Reservation Amount (Non Refundable): </strong>$${paidAmount} <br/>
						<strong>Amount to pay On-Site: </strong>$${dueAmount} <br/>
						<strong>Total Amount: </strong>$${payableAmount} <br/>
						<p>In case of any queries, please reach out to us at <a href="mailto:customercare.primepark@gmail.com">Prime Park Customer Care</a> and please cite the ticket number: ${createBookingRequest?.bookingTicketNo}.</p> 
						<h4>Terms &amp; Conditions</h4>
						<ol>
								<li>Your reservation will be subject to over size rate($5/day, $7/day, or $10/day) if your vehicle is a small SUV, midsize or large SUV, or Truck.</li>
								<li>Customer is required to take pictures of their vehicles (all sides) at the location during drop-off and also agree that no damage claim can be filed without providing those pictures.</li>
								<li>Customer must leave the car key to the attendant and agree that failure to do so may result to towing fees from $75-$150.</li>
								<li>Customer agrees that all balance must be paid in full prior to retrieval of vehicle.</li>
								<li>Your reservation will be subject to Parking hourly and daily rate as soon as the voucher is expired. Hourly rate is $10/hour and daily rate is $15 or $18 per day.</li>
								<li>This facility does <b>NOT</b> allow in/out privileges. You CANNOT enter & exit more than once.</li>
								<li>For all Canceled online vouchers/Reservation customers are required to pay for one day of parking and a $10 service fee.</li>
								<li>This facility does not allow online reservation extensions. Additional time must be paid on-site at regular.</li>
						</ol>

						<p>
							Thanks & Regards, </br>
							Prime Park Team
						</p>
					<div>`;

					// sendMail(customer?.email, `Booking confirmed! Ticket No: ${createBookingRequest?.bookingTicketNo}`, content);


					let templateBody = this.invoiceReceipt(
						true,
						toDate,
						fromDate,
						selectedCheckInTime,
						selectedCheckOutTime,
						firstName,
						lastName,
						phone,
						bookingTicketNo,
						slotName,
						payableAmount,
						onSiteChargeForVendor,
						vehicleName,
						parkingChargeTotal,
						overstayAmountTotal,
						earlyCheckinAmount,
						extraPassengers,
						onlineBookAmount,
						extraPassengerChargesTotal,
						paidAmount,
						dueAmount,
						policie,
					);
					templateBody += `<div style="page-break-before:always">&nbsp;</div>` + this.invoiceReceipt(
						false,
						toDate,
						fromDate,
						selectedCheckInTime,
						selectedCheckOutTime,
						firstName,
						lastName,
						phone,
						bookingTicketNo,
						slotName,
						payableAmount,
						onSiteChargeForVendor,
						vehicleName,
						parkingChargeTotal,
						overstayAmountTotal,
						earlyCheckinAmount,
						extraPassengers,
						onlineBookAmount,
						extraPassengerChargesTotal,
						paidAmount,
						dueAmount,
						policie,
					);
					let htmlTemplate = `
					<html>
						<head>
							<meta charset="utf8">
							<title>Prime Park Receipt</title>
							<style>
								.common-table {
									border: 1px solid hsla(0, 0%, 85%, 1);
									background: #fff;
									margin: 0;
									padding: 0;
									width: 100%;
									display: block;
									font-size: 10px;
								}
								.common-table tr td {
									padding: 0;
								}
								.bg-black {
									background: hsla(0, 0%, 0%, 1);
									padding: 4px 0; 
								}
								.bg-black h5 {
									font-size: 16px; 
									font-weight: 600;
									line-height: 20px;
									letter-spacing: 0.02em;
									text-align: center;
									color: #fff;
									margin: 0;
								}
								.bg-black p {
									font-size: 10px; 
									font-weight: 400;
									line-height: 14px;
									letter-spacing: 0.02em;
									text-align: center;
									color: hsla(0, 0%, 100%, 1);
									padding: 0 4px;
								}
								.body-top {
									background: hsla(240, 3%, 94%, 1);
									width: 100%;
								}
								.body-top h3 {
									font-size: 17px; 
									padding: 0;
									margin: 0;
								}
								.biling-details {
									width: 80%;
								}
								#terms-title {
									font-weight: normal;
									color: black;
								}
								.biling-details h2 {
									font-size: 18px;
									font-weight: 600;
									line-height: 22px;
									text-align: left;
								}
								.biling-details tr {
									border-bottom: 1.5px dotted hsla(0, 0%, 0%, 0.41);
								}
								.bottom-table {
									width: 100%;
								}
								.biling-details tr td,
								.body-top tr td,
								.bottom-table tr td {
									padding: 7px 7px; 
								}
								.biling-details td h5 {
									font-weight: 700;
									font-size: 16px;
									padding: 0;
									margin: 0;
								}
								.biling-details tbody tr:last-child {
									border-bottom: 0;
								}
								.biling-details span {
									font-size: 14px;
									font-style: italic;
									font-weight: 400;
									line-height: 22px;
									text-align: left;
									color: hsla(227, 80%, 64%, 1);
								}
								.bottom-table td h5 {
									font-size: 14px; 
									line-height: 16px;
								}
								.bottom-table tbody tr:last-child td {
									padding-bottom: 20px; 
									white-space: normal;
								}
								.signature h4 {
									font-size: 10px; 
									line-height: 12px;
									white-space: normal;
								}
							</style>
						</head>
						<body>
							${templateBody}
						</body>
					</html>
					`;

					var pdf = require('html-pdf');
					var options = {
						format: 'Letter',
						childProcessOptions: {
							env: {
								OPENSSL_CONF: '/dev/null',
							},
						}
					};
					let fileName = `customer-receipt-${createBookingRequest?.bookingTicketNo}.pdf`;
					const pdfPath = path.join(__dirname, '../public/attachments', fileName);
					pdf.create(htmlTemplate, options).toFile(pdfPath, function (err, res) {
						if (err) return console.log(err);
						// console.log(res);
						sendMail(customer?.email, `Booking confirmed! Ticket No: ${createBookingRequest?.bookingTicketNo}`, content, pdfPath);
					});

					let adminMailContent = `
						<div>
							Dear Prime Park Team, 
							<p>A new booking has been generated which needs your prompt attention. Please find the details of the booking below:</p>

							<strong>Ticket Number:</strong> ${createBookingRequest?.bookingTicketNo} </br>
							<strong>Customer Name:</strong> ${customer?.firstName} ${customer?.lastName} </br>
							<strong>Email ID:</strong> ${customer?.email} </br>
							<strong>Phone Number:</strong> ${customer?.phone} </br>
							<strong>Parking Lot Name:</strong> Prime Park JFK </br>
							<strong>Car drop-off date:</strong> ${fromDate} </br>
							<strong>Car pick-up date:</strong> ${toDate} </br>
							<strong>Plate Number:</strong> ${plateNumber} </br>
							<strong>Number of passengers:</strong> ${passengerCount} </br>
							<strong>Slot Details:</strong> ${checkSlot?.slotName} [Bay-no.: ${checkSlot?.slotBayNumber}, Row-no.: ${checkSlot?.slotRowNumber}] </br>
							<strong>Reservation Amount (Non Refundable): </strong>$${paidAmount} <br/>
							<strong>Amount to pay On-Site: </strong>$${dueAmount} <br/>
							<strong>Total Amount: </strong>$${payableAmount} <br/>

							Please take the necessary action regarding the same.
							<p>
								Thanks & Regards, </br>
								Prime Park Admin
							</p>
						<div>
					`;

					// sendMail(ccEmail, `Booking confirmed! Ticket No: ${createBookingRequest?.bookingTicketNo}`, adminMailContent);

					let TemplateBody = this.invoiceReceipt(
						false,
						toDate,
						fromDate,
						selectedCheckInTime,
						selectedCheckOutTime,
						firstName,
						lastName,
						phone,
						bookingTicketNo,
						slotName,
						payableAmount,
						onSiteChargeForVendor,
						vehicleName,
						parkingChargeTotal,
						overstayAmountTotal,
						earlyCheckinAmount,
						extraPassengers,
						onlineBookAmount,
						extraPassengerChargesTotal,
						paidAmount,
						dueAmount,
						policie,
					);
					let HtmlTemplate = `
					<html>
						<head>
							<meta charset="utf8">
							<title>Prime Park Receipt</title>
							<style>
								.common-table {
									border: 1px solid hsla(0, 0%, 85%, 1);
									background: #fff;
									margin: 0;
									padding: 0;
									width: 100%;
									display: block;
									font-size: 10px;
								}
								.common-table tr td {
									padding: 0;
								}
								.bg-black {
									background: hsla(0, 0%, 0%, 1);
									padding: 4px 0; 
								}
								.bg-black h5 {
									font-size: 16px; 
									font-weight: 600;
									line-height: 20px;
									letter-spacing: 0.02em;
									text-align: center;
									color: #fff;
									margin: 0;
								}
								.bg-black p {
									font-size: 10px; 
									font-weight: 400;
									line-height: 14px;
									letter-spacing: 0.02em;
									text-align: center;
									color: hsla(0, 0%, 100%, 1);
									padding: 0 4px;
								}
								.body-top {
									background: hsla(240, 3%, 94%, 1);
									width: 100%;
								}
								.body-top h3 {
									font-size: 17px; 
									padding: 0;
									margin: 0;
								}
								.biling-details {
									width: 80%;
								}
								#terms-title {
									font-weight: normal;
									color: black;
								}
								.biling-details h2 {
									font-size: 18px;
									font-weight: 600;
									line-height: 22px;
									text-align: left;
								}
								.biling-details tr {
									border-bottom: 1.5px dotted hsla(0, 0%, 0%, 0.41);
								}
								.bottom-table {
									width: 100%;
								}
								.biling-details tr td,
								.body-top tr td,
								.bottom-table tr td {
									padding: 7px 7px; 
								}
								.biling-details td h5 {
									font-weight: 700;
									font-size: 16px;
									padding: 0;
									margin: 0;
								}
								.biling-details tbody tr:last-child {
									border-bottom: 0;
								}
								.biling-details span {
									font-size: 14px;
									font-style: italic;
									font-weight: 400;
									line-height: 22px;
									text-align: left;
									color: hsla(227, 80%, 64%, 1);
								}
								.bottom-table td h5 {
									font-size: 14px; 
									line-height: 16px;
								}
								.bottom-table tbody tr:last-child td {
									padding-bottom: 20px; 
									white-space: normal;
								}
								.signature h4 {
									font-size: 10px; 
									line-height: 12px;
									white-space: normal;
								}
							</style>
						</head>
						<body>
							${TemplateBody}
						</body>
					</html>
					`;

					var pdf = require('html-pdf');
					var options = {
						format: 'Letter',
						childProcessOptions: {
							env: {
								OPENSSL_CONF: '/dev/null',
							},
						}
					};
					let FileName = `admin-receipt-${createBookingRequest?.bookingTicketNo}.pdf`;
					const PdfPath = path.join(__dirname, '../public/attachments', FileName);
					pdf.create(HtmlTemplate, options).toFile(PdfPath, function (err, res) {
						if (err) return console.log(err);
						// console.log(res);
						sendMail(ccEmail, `Booking confirmed! Ticket No: ${createBookingRequest?.bookingTicketNo}`, adminMailContent, pdfPath);
					});


					return res.status(200).json({
						status: true,
						message: "Booked Successfully.",
						data: createdBookingRequest,
						reservationId: reservationId
					});
				} else {
					return res.status(400).json({
						status: false,
						message: "Ooppss..!! Some error occured while creating car movement record.",
						data: {},
					});
				}

			} else if (bookingPlatform == "customerPanel") {
				// ----- customer panel -----
				let slotStatusUpdate = await super.updateById(slotsModel, slotId, {
					occupancyStatus: "Booked"
				});
				// ----- DO NOT CREATE carMovementRecord, it will be created during CHECK-IN -----

				// ================================
				// ----- Handle Notifications -----
				// ================================
				// ----- send successful booking notification -----

				// ----- 1. to customer -----
				let notiDataForCustomer = {
					userId: customerId ?? customerId,
					bookingRequestId: createBookingRequest?.id,

					notiTitle: `On Site Booking Successful..!! Spot confirmed..!!`,

					notiBody: `Dear Customer, Booking confirmed. Parking slot no.: ${checkSlot?.slotName}; Slot location: [Bay-no.: ${checkSlot?.slotBayNumber}, Row-no.: ${checkSlot?.slotRowNumber}]. For more details, please refer to ticket: ${createBookingRequest?.bookingTicketNo}.`
				}
				let createNotificationForCustomer = await super.create(res, notificationModel, notiDataForCustomer);

				//  ========== push noti ==========
				console.log("------ Sending booking Notification ----");
				let messages = {
					title: "On Site Booking Successful..!! Spot confirmed..!!",
					body: JSON.stringify({
						// "tripId": tripPassenger.tripId._id.toString(),
						"msg": `Dear Customer, Booking confirmed. Parking slot no.: ${checkSlot?.slotName}; Slot location: [Bay-no.: ${checkSlot?.slotBayNumber}, Row-no.: ${checkSlot?.slotRowNumber}]. For more details, please refer to ticket: ${createBookingRequest?.bookingTicketNo}.`,
						"type": "Show"
					}),
				};
				if (customer?.fcmToken) {
					await sendPushNotification(customer?.fcmToken, messages, "android");
				}
				//  ========== push noti ==========
				// ----- 1. to customer -----

				// ----- 2. to super admin -----
				let notiDataForSuperAdmin = {
					userId: superUser.id ?? superUser.id,
					bookingRequestId: createBookingRequest?.id,

					notiTitle: `New Booking Request Arrived..!!`,

					notiBody: `Dear Admin, a new booking has been made; expected arrival on ${createBookingRequest.fromDate} at ${createBookingRequest.selectedCheckInTime}. Parking slot no.: ${checkSlot?.slotName}; Slot location: [Bay-no.: ${checkSlot?.slotBayNumber}, Row-no.: ${checkSlot?.slotRowNumber}]; assigned to customer (${createCustomer?.firstName} ${createCustomer?.lastName})(Ph.: ${phone ?? phone}). For more details, please refer to ticket: ${createBookingRequest?.bookingTicketNo}.`
				}
				let createNotificationForSuperAdmin = await super.create(res, notificationModel, notiDataForSuperAdmin);
				// ----- 2. to super admin -----

				// ----- send successful booking notification -----
				// ================================
				// ----- Handle Notifications -----
				// ================================
				// createBookingRequest.reservationId = reservationId;

				// ============= send email =============
				let content = `
				<div>
					Dear ${customer?.firstName}, 
					<p>Thank you for choosing Prime Park. Your booking is now confirmed. Please find the details of your booking below.</p>
					Parking slot no.: ${checkSlot?.slotName} <br/>
					Slot location: [Bay-no.: ${checkSlot?.slotBayNumber} <br/> 
					Row-no.: ${checkSlot?.slotRowNumber}]. <br/>
					<strong>Reservation Amount (Non Refundable): </strong>$${paidAmount} <br/>
					<strong>Amount to pay On-Site: </strong>$${dueAmount} <br/>
					<strong>Total Amount: </strong>$${payableAmount} <br/>
					<p>In case of any queries, please reach out to us at <a href="mailto:customercare.primepark@gmail.com">Prime Park Customer Care</a> and please cite the ticket number: ${createBookingRequest?.bookingTicketNo}.</p> 
					<h4>Terms &amp; Conditions</h4>
					<ol>
							<li>Your reservation will be subject to over size rate($5/day, $7/day, or $10/day) if your vehicle is a small SUV, midsize or large SUV, or Truck.</li>
							<li>Customer is required to take pictures of their vehicles (all sides) at the location during drop-off and also agree that no damage claim can be filed without providing those pictures.</li>
							<li>Customer must leave the car key to the attendant and agree that failure to do so may result to towing fees from $75-$150.</li>
							<li>Customer agrees that all balance must be paid in full prior to retrieval of vehicle.</li>
							<li>Your reservation will be subject to Parking hourly and daily rate as soon as the voucher is expired. Hourly rate is $10/hour and daily rate is $15 or $18 per day.</li>
							<li>This facility does <b>NOT</b> allow in/out privileges. You CANNOT enter & exit more than once.</li>
							<li>For all Canceled online vouchers/Reservation customers are required to pay for one day of parking and a $10 service fee.</li>
							<li>This facility does not allow online reservation extensions. Additional time must be paid on-site at regular.</li>
					</ol>

					<p>
						Thanks & Regards, </br>
						Prime Park Team
					</p>
				<div>`;

				// sendMail(customer?.email, `Booking confirmed! Ticket No: ${createBookingRequest?.bookingTicketNo}`, content);



				let templateBody = this.invoiceReceipt(
					true,
					toDate,
					fromDate,
					selectedCheckInTime,
					selectedCheckOutTime,
					firstName,
					lastName,
					phone,
					bookingTicketNo,
					slotName,
					payableAmount,
					onSiteChargeForVendor,
					vehicleName,
					parkingChargeTotal,
					overstayAmountTotal,
					earlyCheckinAmount,
					extraPassengers,
					onlineBookAmount,
					extraPassengerChargesTotal,
					paidAmount,
					dueAmount,
					policie,
				);
				templateBody += `<div style="page-break-before:always">&nbsp;</div>` + this.invoiceReceipt(
					false,
					toDate,
					fromDate,
					selectedCheckInTime,
					selectedCheckOutTime,
					firstName,
					lastName,
					phone,
					bookingTicketNo,
					slotName,
					payableAmount,
					onSiteChargeForVendor,
					vehicleName,
					parkingChargeTotal,
					overstayAmountTotal,
					earlyCheckinAmount,
					extraPassengers,
					onlineBookAmount,
					extraPassengerChargesTotal,
					paidAmount,
					dueAmount,
					policie,
				);
				let htmlTemplate = `
				<html>
					<head>
						<meta charset="utf8">
						<title>Prime Park Receipt</title>
						<style>
							.common-table {
								border: 1px solid hsla(0, 0%, 85%, 1);
								background: #fff;
								margin: 0;
								padding: 0;
								width: 100%;
								display: block;
								font-size: 10px;
							}
							.common-table tr td {
									padding: 0;
							}
							.bg-black {
								background: hsla(0, 0%, 0%, 1);
								padding: 4px 0; 
							}
							.bg-black h5 {
								font-size: 16px; 
								font-weight: 600;
								line-height: 20px;
								letter-spacing: 0.02em;
								text-align: center;
								color: #fff;
								margin: 0;
							}
							.bg-black p {
								font-size: 10px; 
								font-weight: 400;
								line-height: 14px;
								letter-spacing: 0.02em;
								text-align: center;
								color: hsla(0, 0%, 100%, 1);
								padding: 0 4px;
							}
							.body-top {
								background: hsla(240, 3%, 94%, 1);
								width: 100%;
							}
							.body-top h3 {
								font-size: 12px; 
								padding: 0;
								margin: 0;
							}
							.biling-details {
								width: 80%;
							}
							#terms-title {
								font-weight: normal;
								color: black;
							}
							.biling-details h2 {
								font-size: 18px;
								font-weight: 600;
								line-height: 22px;
								text-align: left;
							}
							.biling-details tr {
								border-bottom: 1.5px dotted hsla(0, 0%, 0%, 0.41);
							}
							.bottom-table {
								width: 100%;
							}
							.biling-details tr td,
							.body-top tr td,
							.bottom-table tr td {
								padding: 7px 7px; 
							}
							.biling-details td h5 {
								font-weight: 700;
								font-size: 16px;
								padding: 0;
								margin: 0;
							}
							.biling-details tbody tr:last-child {
								border-bottom: 0;
							}
							.biling-details span {
								font-size: 14px;
								font-style: italic;
								font-weight: 400;
								line-height: 22px;
								text-align: left;
								color: hsla(227, 80%, 64%, 1);
							}
							.bottom-table td h5 {
								font-size: 14px; 
								line-height: 16px;
							}
							.bottom-table tbody tr:last-child td {
								padding-bottom: 20px; 
								white-space: normal;
							}
							.signature h4 {
								font-size: 10px; 
								line-height: 12px;
								white-space: normal;
							}
						</style>
					</head>
					<body>
						${templateBody}
					</body>
				</html>
				`;

				var pdf = require('html-pdf');
				var options = {
					format: 'Letter',
					childProcessOptions: {
						env: {
							OPENSSL_CONF: '/dev/null',
						},
					}
				};
				let fileName = `customer-receipt-${createBookingRequest?.bookingTicketNo}.pdf`;
				const pdfPath = path.join(__dirname, '../public/attachments', fileName);
				pdf.create(htmlTemplate, options).toFile(pdfPath, function (err, res) {
					if (err) return console.log(err);
					// console.log(res);
					sendMail(customer?.email, `Booking confirmed! Ticket No: ${createBookingRequest?.bookingTicketNo}`, content, pdfPath);
				});

				let adminMailContent = `
						<div>
							Dear Prime Park Team, 
							<p>A new booking has been generated which needs your prompt attention. Please find the details of the booking below:</p>

							<strong>Ticket Number:</strong> ${createBookingRequest?.bookingTicketNo} </br>
							<strong>Customer Name:</strong> ${customer?.firstName} ${customer?.lastName} </br>
							<strong>Email ID:</strong> ${customer?.email} </br>
							<strong>Phone Number:</strong> ${customer?.phone} </br>
							<strong>Parking Lot Name:</strong> Prime Park JFK </br>
							<strong>Car drop-off date:</strong> ${fromDate} </br>
							<strong>Car pick-up date:</strong> ${toDate} </br>
							<strong>Plate Number:</strong> ${plateNumber} </br>
							<strong>Number of passengers:</strong> ${passengerCount} </br>
							<strong>Slot Details:</strong> ${checkSlot?.slotName} [Bay-no.: ${checkSlot?.slotBayNumber}, Row-no.: ${checkSlot?.slotRowNumber}] </br>
							<strong>Reservation Amount (Non Refundable): </strong>$${paidAmount} <br/>
							<strong>Amount to pay On-Site: </strong>$${dueAmount} <br/>
							<strong>Total Amount: </strong>$${payableAmount} <br/>

							Please take the necessary action regarding the same.
							<p>
								Thanks & Regards, </br>
								Prime Park Admin
							</p>
						<div>
				`;

				// sendMail(ccEmail, `Booking confirmed! Ticket No: ${createBookingRequest?.bookingTicketNo}`, adminMailContent);

				let TemplateBody = this.invoiceReceipt(
					false,
					toDate,
					fromDate,
					selectedCheckInTime,
					selectedCheckOutTime,
					firstName,
					lastName,
					phone,
					bookingTicketNo,
					slotName,
					payableAmount,
					onSiteChargeForVendor,
					vehicleName,
					parkingChargeTotal,
					overstayAmountTotal,
					earlyCheckinAmount,
					extraPassengers,
					onlineBookAmount,
					extraPassengerChargesTotal,
					paidAmount,
					dueAmount,
					policie,
				);
				let HtmlTemplate = `
				<html>
					<head>
						<meta charset="utf8">
						<title>Prime Park Receipt</title>
						<style>
							.common-table {
								border: 1px solid hsla(0, 0%, 85%, 1);
								background: #fff;
								margin: 0;
								padding: 0;
								width: 100%;
								display: block;
								font-size: 10px;
							}
							.common-table tr td {
								padding: 0;
							}
							.bg-black {
								background: hsla(0, 0%, 0%, 1);
								padding: 4px 0; 
							}
							.bg-black h5 {
								font-size: 16px; 
								font-weight: 600;
								line-height: 20px;
								letter-spacing: 0.02em;
								text-align: center;
								color: #fff;
								margin: 0;
							}
							.bg-black p {
								font-size: 10px; 
								font-weight: 400;
								line-height: 14px;
								letter-spacing: 0.02em;
								text-align: center;
								color: hsla(0, 0%, 100%, 1);
								padding: 0 4px;
							}
							.body-top {
								background: hsla(240, 3%, 94%, 1);
								width: 100%;
							}
							.body-top h3 {
								font-size: 17px; 
								padding: 0;
								margin: 0;
							}
							.biling-details {
								width: 80%;
							}
							#terms-title {
								font-weight: normal;
								color: black;
							}
							.biling-details h2 {
								font-size: 18px;
								font-weight: 600;
								line-height: 22px;
								text-align: left;
							}
							.biling-details tr {
								border-bottom: 1.5px dotted hsla(0, 0%, 0%, 0.41);
							}
							.bottom-table {
								width: 100%;
							}
							.biling-details tr td,
							.body-top tr td,
							.bottom-table tr td {
								padding: 7px 7px; 
							}
							.biling-details td h5 {
								font-weight: 700;
								font-size: 16px;
								padding: 0;
								margin: 0;
							}
							.biling-details tbody tr:last-child {
								border-bottom: 0;
							}
							.biling-details span {
								font-size: 14px;
								font-style: italic;
								font-weight: 400;
								line-height: 22px;
								text-align: left;
								color: hsla(227, 80%, 64%, 1);
							}
							.bottom-table td h5 {
								font-size: 14px; 
								line-height: 16px;
							}
							.bottom-table tbody tr:last-child td {
								padding-bottom: 20px; 
								white-space: normal;
							}
							.signature h4 {
								font-size: 10px; 
								line-height: 12px;
								white-space: normal;
							}
						</style>
					</head>
					<body>
						${TemplateBody}
					</body>
				</html>
				`;

				var pdf = require('html-pdf');
				var options = {
					format: 'Letter',
					childProcessOptions: {
						env: {
							OPENSSL_CONF: '/dev/null',
						},
					}
				};
				let FileName = `admin-receipt-${createBookingRequest?.bookingTicketNo}.pdf`;
				const PdfPath = path.join(__dirname, '../public/attachments', FileName);
				pdf.create(HtmlTemplate, options).toFile(PdfPath, function (err, res) {
					if (err) return console.log(err);
					// console.log(res);
					sendMail(ccEmail, `Booking confirmed! Ticket No: ${createBookingRequest?.bookingTicketNo}`, adminMailContent, pdfPath);
				});

				// ============= send email =============

				return res.status(200).json({
					status: true,
					message: "Booked Successfully.",
					data: createBookingRequest,
					reservationId: reservationId
				});
			}
		} else {
			return res.status(400).json({
				status: false,
				message: "Ooppss..!! Some error occured during booking creation.",
				data: {},
			});
		}
	});

	static preBookingChargeSummaryBack = catchAsyncErrors(async (req, res, next) => {
		let { onSiteChargeForVendor, vehicleTypeId, checkinDate, startTime, checkoutDate, endTime, passengerCount, } = req.body;

		// Define startDate and endDate in the same time zone
		let startDate = moment.tz(checkinDate + " " + startTime, timeZone);
		let endDate = moment.tz(checkoutDate + " " + endTime, timeZone);

		// Calculate the difference in total minutes
		const totalMinutes = endDate.diff(startDate, 'minutes');

		// Calculate the full days, rounding up if minutes exceed 15
		// 1440 minutes in a day ---------------
		let dayCount = Math.floor(totalMinutes / 1440);
		// Remaining minutes after full days ---------------
		let remainingMinutes = totalMinutes % 1440;

		// Check if remaining minutes exceed 15 ---------------
		if (remainingMinutes > 15) {
			// Count an additional day if more than 15 minutes ---------------
			dayCount += 1;
		}

		let staticCharges = await staticChargesModel.findOne({
			where: {
				parkingGroundId: 1,
				isActive: true,
			},
		});

		let priceChart = await priceChartsModel.findOne({
			where: {
				vehicleTypeId: vehicleTypeId,
				isActive: true,
			},
		});

		let reservationAmount = staticCharges.reservationCharge;
		let parkingChargeTotal = 0;
		let overSizeChargeTotal = 0;

		let extraPassengers = 0;
		let extraPassengerChargesTotal = 0;
		// ----- extra charges for more than 4 passengers -----
		if (Number(passengerCount) > Number(staticCharges.defaultPassengerCount)) {
			extraPassengers = Number(passengerCount) - Number(staticCharges.defaultPassengerCount);
		}
		// ----- extra charges for more than 4 passengers -----
		extraPassengerChargesTotal = Number(extraPassengers) * Number(staticCharges.extraPassengerChargePerHead);

		let overstayDays = 0;
		let overstayAmountTotal = 0;
		let payableAmount = 0;

		parkingChargeTotal = Number(dayCount) * Number(priceChart.dailyParkingRate);

		if (!onSiteChargeForVendor) {
			onSiteChargeForVendor = 0;
		}

		payableAmount = Number(parkingChargeTotal) + Number(overSizeChargeTotal) + Number(extraPassengerChargesTotal) + Number(overstayAmountTotal) + Number(onSiteChargeForVendor)  + Number(onlineBookingAmount);

		let paidAmount = 0;
		paidAmount = Number(reservationAmount);
		let dueAmount = 0;

		dueAmount = (Number(payableAmount)) - Number(paidAmount);

		let bookingChargesSummary = {
			reservationAmount: reservationAmount,

			parkingChargeTotal: parkingChargeTotal,
			overSizeChargeTotal: overSizeChargeTotal,

			extraPassengers: extraPassengers,
			extraPassengerChargesTotal: extraPassengerChargesTotal,

			overstayDays: overstayDays,
			overstayAmountTotal: overstayAmountTotal,

			onSiteChargeForVendor: onSiteChargeForVendor,

			payableAmount: payableAmount,

			paidAmount: paidAmount,

			dueAmount: dueAmount,

			paymentStatus: "Due",
		};

		return res.status(200).json({
			status: true,
			message: "Estimated booking charges summary.",
			data: {
				bookingChargesSummary: bookingChargesSummary
			},
		});
	});

	static preBookingChargeSummary = catchAsyncErrors(async (req, res, next) => {
		let { platform, platformMedium, vendorId, onSiteChargeForVendor, vehicleTypeId, checkinDate, startTime, checkoutDate, endTime, passengerCount, } = req.body;

		console.log("timeZone ===>");
		console.log(timeZone);

		// Define startDate and endDate in the same time zone
		// let startDate = moment.tz(checkinDate+ " " +startTime, timeZone);
		// let endDate = moment.tz(checkoutDate+ " " +endTime, timeZone);

		let startDate = moment.tz(checkinDate, timeZone).startOf('day');
		let endDate = moment.tz(checkoutDate, timeZone).endOf('day');

		let dayCount = endDate.diff(startDate, 'days') + 1;
		console.log('dayCount', dayCount);
		// Calculate the difference in total minutes
		// const totalMinutes = endDate.diff(startDate, 'minutes');
		// Calculate the full days, rounding up if minutes exceed 15
		// 1440 minutes in a day ---------------
		// let dayCount = Math.ceil(totalMinutes / 1440); 
		// console.log('totalMinutes', totalMinutes);
		// Remaining minutes after full days ---------------
		// let remainingMinutes = totalMinutes % 1440; 

		// // Check if remaining minutes exceed 15 ---------------
		// if (remainingMinutes > 15) {
		// 	// Count an additional day if more than 15 minutes ---------------
		// 	dayCount += 1; 
		// }		

		let staticCharges = await staticChargesModel.findOne({
			where: {
				parkingGroundId: 1,
				isActive: true,
			},
		});

		let priceChart = await priceChartsModel.findOne({
			where: {
				vehicleTypeId: vehicleTypeId,
				isActive: true,
			},
		});

		let reservationAmount = staticCharges.reservationCharge;
		let onlineBookingAmount = staticCharges.onlineBookingCharge;
		let parkingChargeTotal = 0;
		let overSizeChargeTotal = 0;

		let extraPassengers = 0;
		let extraPassengerChargesTotal = 0;
		// ----- extra charges for more than 4 passengers -----
		if (Number(passengerCount) > Number(staticCharges.defaultPassengerCount)) {
			extraPassengers = Number(passengerCount) - Number(staticCharges.defaultPassengerCount);
		}
		// ----- extra charges for more than 4 passengers -----
		extraPassengerChargesTotal = Number(extraPassengers) * Number(staticCharges.extraPassengerChargePerHead);

		let overstayDays = 0;
		let overstayAmountTotal = 0;
		let payableAmount = 0;

		let earlyCheckinAmountTotal = 0;
		let totalExtraDays = 0;

		if (onSiteChargeForVendor && vendorId) {
			parkingChargeTotal = Number(dayCount) * Number(priceChart.overSizeRate);
		} else {
			if (platformMedium != "AdminBooking") {
				parkingChargeTotal = Number(dayCount) * (Number(priceChart.dailyParkingRate) + Number(priceChart.overSizeRate));
			} else {
				parkingChargeTotal = Number(dayCount) * Number(priceChart.dailyParkingRate)
			}
		}

		// if(onSiteChargeForVendor && vendorId){
		// 	parkingChargeTotal = Number(dayCount) * Number(priceChart.overSizeRate);
		// }else{
		// 	parkingChargeTotal = Number(dayCount) * Number(priceChart.dailyParkingRate);
		// }

		// let today = moment.tz(timeZone).endOf('day');
		let today = moment.tz(timeZone).startOf('day');
		let checkedDate = moment.tz(checkinDate, timeZone).startOf('day');
		totalExtraDays = checkedDate.diff(today, 'days');

		if (
			platform == "AdminPanel"
		) {
			// if(platformMedium != "AdminBooking"){
			// 	let newDate = new Date()
			// 	let startDate = moment.tz(checkinDate, timeZone).startOf('day');
			// 	let todayDate = moment.tz(newDate, timeZone).endOf('day');
			// 	let dayCount = startDate.diff(todayDate, 'days');

			// 	console.log(day)

			// 	if(dayCount >= 0){
			// 		earlyCheckinAmountTotal = 0;
			// 	}else{
			earlyCheckinAmountTotal = Number(totalExtraDays) * Number(priceChart.dailyParkingRate);
			// 	}
			// }
			// if(Number(totalExtraDays) == 0){
			// 	let extraMinutes = moment.tz(checkinDate+ " " +startTime, timeZone).diff(moment.tz(timeZone), 'minutes');
			// 	console.log("extraMinutes ====>");
			// 	console.log(extraMinutes);

			// 	if(extraMinutes > 120){
			// 		earlyCheckinAmountTotal = Number(priceChart.dailyParkingRate);
			// 	}
			// }
			onlineBookingAmount = 0;
			reservationAmount = 0;
		}

		// if(!onSiteChargeForVendor){
		// 	onSiteChargeForVendor = 0;
		// }
		if (platformMedium != "AdminBooking") {
			onlineBookingAmount = staticCharges.onlineBookingCharge;
			reservationAmount = staticCharges.reservationCharge;
		}

		payableAmount = Number(parkingChargeTotal) + Number(overSizeChargeTotal) + Number(extraPassengerChargesTotal) + Number(overstayAmountTotal) + Number(onSiteChargeForVendor) + Number(earlyCheckinAmountTotal) + Number(onlineBookingAmount);


		let paidAmount = 0;

		if (platformMedium == "AdminBooking") {
			paidAmount = paidAmount
		} else {
			onlineBookingAmount = staticCharges.onlineBookingCharge;
			reservationAmount = staticCharges.reservationCharge;
			if (Number(payableAmount) <= (Number(reservationAmount))) {
				paidAmount = payableAmount - Number(onlineBookingAmount);
			} else {
				paidAmount = Number(reservationAmount);
			}
		}


		let dueAmount = (Number(payableAmount) ) - Number(paidAmount);

		let bookingChargesSummary = {
			reservationAmount: reservationAmount,
			onlineBookingAmount: onlineBookingAmount,

			parkingChargeTotal: parkingChargeTotal,
			overSizeChargeTotal: overSizeChargeTotal,

			extraPassengers: extraPassengers,
			extraPassengerChargesTotal: extraPassengerChargesTotal,

			earlyCheckinAmountTotal: earlyCheckinAmountTotal,
			totalExtraMinutes: moment.tz(checkinDate + " " + startTime, timeZone).diff(moment.tz(timeZone), 'minutes'),

			overstayDays: overstayDays,
			overstayAmountTotal: overstayAmountTotal,

			onSiteChargeForVendor: onSiteChargeForVendor,

			payableAmount: payableAmount,

			paidAmount: paidAmount,

			dueAmount: dueAmount,

			paymentStatus: "Due",
		};

		return res.status(200).json({
			status: true,
			message: "Estimated booking charges summary.",
			data: {
				bookingChargesSummary: bookingChargesSummary
			},
		});
	});

	// ----- creates a invoice with booking request data received while booking -----
	// ----- invoice data needs to be updated after check-in and before final check-out ----- 
	static calculateBookingChargesBeforeBooking = catchAsyncErrors(async (req, res, next) => {
		let { platform, platformMedium, bookingRequestId, vendorId, onSiteChargeForVendor, vehicleTypeId, checkinDate, startTime, checkoutDate, endTime, passengerCount, } = req.body;

		// Define startDate and endDate in the same time zone
		// let startDate = moment.tz(checkinDate+ " " +startTime, timeZone);
		// let endDate = moment.tz(checkoutDate+ " " +endTime, timeZone);
		// let startDate = moment.tz(checkinDate+ " 00:00:00", timeZone);
		// let endDate = moment.tz(checkoutDate+ " 23:59:59", timeZone);

		let startDate = moment.tz(checkinDate, timeZone).startOf('day');
		let endDate = moment.tz(checkoutDate, timeZone).endOf('day');
		let dayCount = endDate.diff(startDate, 'days') + 1;

		// Calculate the difference in total minutes
		// const totalMinutes = endDate.diff(startDate, 'minutes');

		// // Calculate the full days, rounding up if minutes exceed 15
		// // 1440 minutes in a day ---------------
		// let dayCount = Math.floor(totalMinutes / 1440); 
		// Remaining minutes after full days ---------------
		// let remainingMinutes = totalMinutes % 1440; 

		// // Check if remaining minutes exceed 15 ---------------
		// if (remainingMinutes > 15) {
		// 	// Count an additional day if more than 15 minutes ---------------
		// 	dayCount += 1; 
		// }

		let staticCharges = await staticChargesModel.findOne({
			where: {
				parkingGroundId: 1,
				isActive: true,
			},
		});

		let priceChart = await priceChartsModel.findOne({
			where: {
				vehicleTypeId: vehicleTypeId,
				isActive: true,
			},
		});

		let reservationAmount = 0;
		let onlineBookingAmount = 0;
		if (
			platform != "AdminPanel"
		) {
			reservationAmount = staticCharges.reservationCharge;
			onlineBookingAmount = staticCharges.onlineBookingCharge;
		}

		let parkingChargeTotal = 0;
		let overSizeChargeTotal = 0;

		let extraPassengers = 0;
		let extraPassengerChargesTotal = 0;
		// ----- extra charges for more than 4 passengers -----
		if (Number(passengerCount) > Number(staticCharges.defaultPassengerCount)) {
			extraPassengers = Number(passengerCount) - Number(staticCharges.defaultPassengerCount);
		}
		// ----- extra charges for more than 4 passengers -----
		extraPassengerChargesTotal = Number(extraPassengers) * Number(staticCharges.extraPassengerChargePerHead);

		let overstayDays = 0;
		let overstayAmountTotal = 0;
		let payableAmount = 0;

		parkingChargeTotal = Number(dayCount) * Number(priceChart.dailyParkingRate);

		let bookingRequestDetail = await super.getByCustomOptionsSingle(req, bookingRequestsModel, {
			where: {
				id: bookingRequestId,
			},
			include: [
				{
					model: userModel,
					attributes: {
						exclude: [
							"password",
							"webLogin",
							"appLogin",
							"fcmToken",
							"OTP",
							"macAddress",
							"deviceId",
						],
					},
					include: [
						{
							model: roleModel,
						}
					],
					required: false,
				},
			],
		});

		let earlyCheckinAmountTotal = 0;
		let totalExtraDays = 0;
		if (vendorId && onSiteChargeForVendor) {
			// if(onSiteChargeForVendor && onSiteChargeForVendor != undefined){
			parkingChargeTotal = Number(dayCount) * Number(priceChart.overSizeRate);
			// } else{
			// 	onSiteChargeForVendor = 0;
			// 	// parkingChargeTotal = Number(dayCount) * Number(priceChart.dailyParkingRate);
			// 	parkingChargeTotal = Number(dayCount) * Number(priceChart.overSizeRate);
			// }
		} else {
			if (platformMedium != "AdminBooking") {
				parkingChargeTotal = Number(dayCount) * (Number(priceChart.dailyParkingRate) + Number(priceChart.overSizeRate));
			} else {
				parkingChargeTotal = Number(dayCount) * Number(priceChart.dailyParkingRate)
			}
		}

		let today = moment.tz(timeZone).startOf('day');
		let checkedDate = moment.tz(checkinDate, timeZone).startOf('day');
		totalExtraDays = checkedDate.diff(today, 'days');

		if (
			platform == "AdminPanel"
		) {
			// let newDate = new Date()
			// let startDate = moment.tz(checkinDate, timeZone).startOf('day');
			// let todayDate = moment.tz(newDate, timeZone).endOf('day');
			// let dayCount = startDate.diff(todayDate, 'days');

			// if(dayCount >= 0){
			// 	earlyCheckinAmountTotal = 0;
			// }else{
			earlyCheckinAmountTotal = Number(totalExtraDays) * Number(priceChart.dailyParkingRate);
			// }
			// if(Number(totalExtraDays) == 0){
			// 	let extraMinutes = moment.tz(checkinDate+ " " +startTime, timeZone).diff(moment.tz(timeZone), 'minutes');
			// 	if(extraMinutes > 120){
			// 		earlyCheckinAmountTotal = Number(priceChart.dailyParkingRate);
			// 	}
			// }
		}

		// if(!onSiteChargeForVendor){
		// 	onSiteChargeForVendor = 0;
		// }
		payableAmount = Number(parkingChargeTotal) + Number(overSizeChargeTotal) + Number(extraPassengerChargesTotal) + Number(overstayAmountTotal) + Number(onSiteChargeForVendor) + Number(earlyCheckinAmountTotal) + Number(onlineBookingAmount);

		let paidAmount = 0;
		// if(vendorId && vendorId != "" && vendorId != null){
		// 	// ====== if booking through a vendor all charges are paid to vendor ======
		// 	paidAmount = payableAmount;
		// 	// ====== if booking through a vendor all charges are paid to vendor ======
		// } else {
		// 	paidAmount = reservationAmount;
		// }

		// booking-create API and this API shall only be hit on success response of payment-verify API
		// user only pays the reservation amount before booking; hence =====

		if (
			platform != "AdminPanel"
		) {
			if (Number(payableAmount) <= (Number(reservationAmount))) {
				paidAmount = payableAmount - Number(onlineBookingAmount);
			} else {
				paidAmount = Number(reservationAmount);
			}
		}

		let dueAmount = 0;

		dueAmount = Number(payableAmount) - Number(paidAmount);

		let invoiceData = {
			bookingRequestId: bookingRequestId,

			reservationAmount: reservationAmount,
			onlineBookingAmount: onlineBookingAmount,

			parkingChargeTotal: parkingChargeTotal,
			overSizeChargeTotal: overSizeChargeTotal,

			extraPassengers: extraPassengers,
			extraPassengerChargesTotal: extraPassengerChargesTotal,

			earlyCheckinAmountTotal: earlyCheckinAmountTotal,

			overstayDays: overstayDays,
			overstayAmountTotal: overstayAmountTotal,

			onSiteChargeForVendor: onSiteChargeForVendor,

			payableAmount: payableAmount,

			paidAmount: paidAmount,

			dueAmount: dueAmount,

			paymentStatus: "Due",
		};

		let invoiceCreate = await super.create(res, invoiceModel, invoiceData);

		if (invoiceCreate) {
			let prebookingInvoice = await super.getByCustomOptionsSingle(req, invoiceModel, {
				where: {
					id: invoiceCreate.id,
				}
			});



			return res.status(200).json({
				status: true,
				message: "Pre-booking invoice created.",
				data: {
					invoiceCreate: invoiceCreate,
					bookingRequestDetail: bookingRequestDetail,
				},
			});
		} else {
			return res.status(400).json({
				status: false,
				message: "Trouble creating pre-booking invoice.",
				data: {},
			});
		}

	});

	static markCheckIn = catchAsyncErrors(async (req, res, next) => {
		let { bookingRequestId, onSiteChargeForVendor, vendorId, reservationId, actualvehicleTypeId, actualFromDate, actualCheckInTime, slotId, plateNumber, } = req.body;

		if (
			(!bookingRequestId || bookingRequestId == "" || bookingRequestId == null || bookingRequestId == undefined)
			// || (!vendorId || vendorId == "" || vendorId == null || vendorId == undefined)
			// || (!reservationId || reservationId == "" || reservationId == null || reservationId == undefined)
			|| (!actualvehicleTypeId || actualvehicleTypeId == "" || actualvehicleTypeId == null || actualvehicleTypeId == undefined)
			|| (!actualFromDate || actualFromDate == "" || actualFromDate == null || actualFromDate == undefined)
			|| (!actualCheckInTime || actualCheckInTime == "" || actualCheckInTime == null || actualCheckInTime == undefined)
			|| (!slotId || slotId == "" || slotId == null || slotId == undefined)
			|| (!plateNumber || plateNumber == "" || plateNumber == null || plateNumber == undefined)
		) {
			return res.status(422).json({
				status: false,
				message: "All parameters are not present. Please pass all the required parameters.",
				data: {},
			});
		}

		let checkCarMovementExist = await super.getByCustomOptionsSingle(req, carMovementsModel, {
			where: {
				bookingRequestId: bookingRequestId,
			},
		});

		if (checkCarMovementExist) {
			// if an attempt to mark a car as check-in is made, then carMovement record should not pre-exist ===
			return res.status(422).json({
				status: false,
				message: "Ooppss..!! Unable to process request. Either this car has already checked in or something wrong happened.",
				data: checkCarMovementExist,
			});
		}

		let carMovementData = {
			bookingRequestId: bookingRequestId,

			actualvehicleTypeId: actualvehicleTypeId,

			actualFromDate: actualFromDate,
			actualCheckInTime: actualCheckInTime,

			// default value
			carStatus: "Checked In",
		};

		if (vendorId) {
			carMovementData.vendorId = vendorId ?? vendorId;
			carMovementData.reservationId = reservationId ?? reservationId;
			carMovementData.onSiteChargeForVendor = onSiteChargeForVendor ?? onSiteChargeForVendor;
		}

		let carMovementCreate = await super.create(
			res,
			carMovementsModel,
			carMovementData,
		);

		let bookingRequest = await super.getByCustomOptionsSingle(req, bookingRequestsModel, {
			where: {
				id: bookingRequestId,
			}
		});
		let customerData = await super.getByCustomOptionsSingle(req, userModel, {
			where: {
				id: bookingRequest?.customerId,
			}
		});

		if (carMovementCreate) {
			let slotStatusUpdate = await super.updateById(slotsModel, slotId, {
				occupancyStatus: "Occupied"
			});
			let updateBookingRequest = await super.updateById(
				bookingRequestsModel,
				bookingRequestId,
				{
					slotId: slotId,
					plateNumber: plateNumber,
					bookingStatus: "Checked In",
					vehicleTypeId: actualvehicleTypeId,

				}
			);
			let updatedBookingRequest = await super.getById(req, bookingRequestsModel, bookingRequestId);

			// ============= send email =============
			let content = `
			<div>
				<h4>Dear ${customerData?.firstName}, we checked in your car. We will make sure your car is safe and shiny till you return. Have a safe and happy journey. For more details refer to ticket no.: ${updatedBookingRequest?.bookingTicketNo}</h4>
			<div>`;

			sendMail(customerData?.email, `Checked in..!!`, content);
			// ============= send email =============

			//  ========== push noti ==========
			console.log("------ Sending check-in Notification ----");
			let messages = {
				title: "Checked-in..!!",
				body: JSON.stringify({
					// "tripId": tripPassenger.tripId._id.toString(),
					"msg": `Dear ${customerData?.firstName}, we checked in your car. We will make sure your car is safe and shiny till you return. Have a safe and happy journey. For more details refer to ticket no.: ${updatedBookingRequest?.bookingTicketNo}`,
					"type": "Show"
				}),
			};
			if (customerData?.fcmToken) {
				await sendPushNotification(customerData?.fcmToken, messages, "android");
			}
			//  ========== push noti ==========

			if (updatedBookingRequest) {
				return res.status(200).json({
					status: true,
					message: "Successfully checked in.",
					data: {
						updatedBookingRequest: updatedBookingRequest,
						updatedCarMovement: carMovementCreate,
					}
				});
			} else {
				return res.status(200).json({
					status: false,
					message: "Succesfully checked-in, but error fetching updated booking request.",
					data: {
						updatedBookingRequest: {},
						updatedCarMovement: carMovementCreate,
					}
				});
			}
		} else {
			return res.status(400).json({
				status: false,
				message: "Something went wrong while checking the car in.",
				data: {}
			});
		}
	});

	static calculateBookingChargesAfterCheckIn = catchAsyncErrors(async (req, res, next) => {
		let { bookingRequestId, platformMedium, vehicleTypeId, checkinDate, startTime, checkoutDate, endTime, passengerCount, } = req.body;

		console.log("timeZone ===>");
		console.log(timeZone);


		if (
			(!bookingRequestId || bookingRequestId == "" || bookingRequestId == null || bookingRequestId == undefined)
			|| (!vehicleTypeId || vehicleTypeId == "" || vehicleTypeId == null || vehicleTypeId == undefined)
			|| (!checkinDate || checkinDate == "" || checkinDate == null || checkinDate == undefined)
			|| (!startTime || startTime == "" || startTime == null || startTime == undefined)
			|| (!checkoutDate || checkoutDate == "" || checkoutDate == null || checkoutDate == undefined)
			|| (!endTime || endTime == "" || endTime == null || endTime == undefined)
			|| (!passengerCount || passengerCount == "" || passengerCount == null || passengerCount == undefined)
		) {
			return res.status(422).json({
				status: false,
				message: "All parameters are not present. Please pass all the required parameters.",
				data: {},
			});
		}

		let bookingRequestData = await super.getByCustomOptionsSingle(req, bookingRequestsModel, {
			where: {
				id: bookingRequestId
			},
		});

		let carMovementData = await super.getByCustomOptionsSingle(req, carMovementsModel, {
			where: {
				bookingRequestId: bookingRequestId,
			},
		});

		// Define startDate and endDate in the same time zone
		// let startDate = moment.tz(checkinDate+ " " +startTime, timeZone);
		// let endDate = moment.tz(checkoutDate+ " " +endTime, timeZone);
		// let startDate = moment.tz(checkinDate+ " 00:00:00", timeZone);
		// let endDate = moment.tz(checkoutDate+ " 23:59:59", timeZone);

		let startDate = moment.tz(checkinDate, timeZone).startOf('day');
		let endDate = moment.tz(checkoutDate, timeZone).endOf('day');
		let dayCount = endDate.diff(startDate, 'days') + 1;

		// Calculate the difference in total minutes
		// const totalMinutes = endDate.diff(startDate, 'minutes');

		// // Calculate the full days, rounding up if minutes exceed 15
		// // 1440 minutes in a day ---------------
		// let dayCount = Math.floor(totalMinutes / 1440); 
		// Remaining minutes after full days ---------------
		// let remainingMinutes = totalMinutes % 1440; 

		// // Check if remaining minutes exceed 15 ---------------
		// if (remainingMinutes > 15) {
		// 	// Count an additional day if more than 15 minutes ---------------
		// 	dayCount += 1; 
		// }

		// let selectedStartDate = moment.tz(bookingRequestData.fromDate+ " " +bookingRequestData.selectedCheckInTime, timeZone);
		// let selectedEndDate = moment.tz(bookingRequestData.toDate+ " " +bookingRequestData.selectedCheckOutTime, timeZone);
		// let selectedStartDate = moment.tz(bookingRequestData.fromDate+ " 00:00:00", timeZone);
		// let selectedEndDate = moment.tz(bookingRequestData.toDate+ " 23:59:59", timeZone);

		let selectedStartDate = moment.tz(bookingRequestData.fromDate, timeZone).startOf('day');
		let selectedEndDate = moment.tz(bookingRequestData.toDate, timeZone).endOf('day');
		let selectedDayCount = selectedEndDate.diff(selectedStartDate, 'days') + 1;

		// Calculate the difference in total minutes
		// const selectedTotalMinutes = selectedEndDate.diff(selectedStartDate, 'minutes');

		// // Calculate the full days, rounding up if minutes exceed 15
		// // 1440 minutes in a day ---------------
		// let selectedDayCount = Math.floor(selectedTotalMinutes / 1440); 
		// Remaining minutes after full days ---------------
		// let selectedRemainingMinutes = selectedTotalMinutes % 1440; 

		// // Check if remaining minutes exceed 15 ---------------
		// if (selectedRemainingMinutes > 15) {
		// 	// Count an additional day if more than 15 minutes ---------------
		// 	selectedDayCount += 1; 
		// }

		if (selectedDayCount >= dayCount) {
			// if user checkes in later than the booked date ==== day count will be selected days ====
			dayCount = selectedDayCount;
		}

		let staticCharges = await staticChargesModel.findOne({
			where: {
				parkingGroundId: 1,
				isActive: true,
			},
		});

		let priceChart = await priceChartsModel.findOne({
			where: {
				vehicleTypeId: vehicleTypeId,
				isActive: true,
			},
		});

		let reservationAmount = Number(staticCharges.reservationCharge);

		let parkingChargeTotal = 0;
		let overSizeRate = Number(priceChart.overSizeRate);
		let overSizeChargeTotal = 0;

		let extraPassengers = 0;
		let extraPassengerChargesTotal = 0;
		// ----- extra charges for more than 4 passengers -----
		if (Number(passengerCount) > Number(staticCharges.defaultPassengerCount)) {
			extraPassengers = Number(passengerCount) - Number(staticCharges.defaultPassengerCount);
		}
		// ----- extra charges for more than 4 passengers -----
		extraPassengerChargesTotal = Number(extraPassengers) * Number(staticCharges.extraPassengerChargePerHead);

		let overstayDays = 0;
		let overstayAmountTotal = 0;
		let payableAmount = 0;

		let existingInvoice = await super.getByCustomOptionsSingle(req, invoiceModel, {
			where: {
				bookingRequestId: bookingRequestId,
			},
		});

		let onlineBookingAmount = Number(existingInvoice.onlineBookingAmount);

		let earlyCheckinAmountTotal = 0;
		let totalExtraDays = 0;

		let existingOnSiteChargeForVendor = 0;
		existingOnSiteChargeForVendor = Number(existingInvoice?.onSiteChargeForVendor);

		// if(existingOnSiteChargeForVendor){
		// 	parkingChargeTotal = Number(dayCount) * Number(priceChart.overSizeRate);
		// }else{
		// }
		// parkingChargeTotal = Number(dayCount) * Number(priceChart.dailyParkingRate);
		if (carMovementData.vendorId && existingOnSiteChargeForVendor) {
			parkingChargeTotal = Number(dayCount) * Number(priceChart.overSizeRate);
		} else {
			if (platformMedium != "AdminBooking") {
				parkingChargeTotal = Number(dayCount) * (Number(priceChart.dailyParkingRate) + Number(priceChart.overSizeRate));
			} else {
				parkingChargeTotal = Number(dayCount) * Number(priceChart.dailyParkingRate)
			}
		}

		let today = moment.tz(timeZone).startOf('day');
		let checkedDate = moment.tz(checkinDate, timeZone).startOf('day');
		totalExtraDays = checkedDate.diff(today, 'days');
		earlyCheckinAmountTotal = Number(totalExtraDays) * Number(priceChart.dailyParkingRate);
		// if(Number(totalExtraDays) == 0){
		// 	let extraMinutes = moment.tz(checkinDate+ " " +startTime, timeZone).diff(moment.tz(timeZone), 'minutes');
		// 	if(extraMinutes > 120){
		// 		earlyCheckinAmountTotal = Number(priceChart.dailyParkingRate);
		// 	}
		// }

		payableAmount = Number(parkingChargeTotal) + Number(overSizeChargeTotal) + Number(extraPassengerChargesTotal) + Number(overstayAmountTotal) + Number(existingOnSiteChargeForVendor) + Number(earlyCheckinAmountTotal)  + Number(onlineBookingAmount);

		let paidAmount = 0;
		// ======================================================================
		paidAmount = Number(reservationAmount);
		let dueAmount = 0;

		dueAmount = (Number(payableAmount)) - Number(paidAmount);

		let invoiceData = {
			reservationAmount: reservationAmount,
			onlineBookingAmount: onlineBookingAmount,

			parkingChargeTotal: parkingChargeTotal,
			overSizeChargeTotal: overSizeChargeTotal,

			extraPassengers: extraPassengers,
			extraPassengerChargesTotal: extraPassengerChargesTotal,

			earlyCheckinAmountTotal: earlyCheckinAmountTotal,

			overstayDays: overstayDays,
			overstayAmountTotal: overstayAmountTotal,

			payableAmount: payableAmount,

			paidAmount: paidAmount,

			dueAmount: dueAmount,

			paymentStatus: "Due",
		};

		let conditions = {
			bookingRequestId: bookingRequestId
		};

		let updateInvoice = await super.updateByCustomOptions(
			invoiceModel,
			conditions,
			invoiceData
		);

		let updatedInvoice = await super.getByCustomOptionsSingle(req, invoiceModel, {
			where: {
				bookingRequestId: bookingRequestId
			},
		});

		let bookingRequestDetail = await super.getByCustomOptionsSingle(req, bookingRequestsModel, {
			where: {
				id: updatedInvoice.bookingRequestId,
			},
		});

		if (updateInvoice) {
			return res.status(200).json({
				status: true,
				message: "Invoice updated after check-in.",
				data: {
					updatedInvoice: updatedInvoice,
					bookingRequestDetail: bookingRequestDetail,
				},
			});
		} else {
			return res.status(400).json({
				status: false,
				message: "Trouble creating after check-in invoice.",
				data: {},
			});
		}
	});

	static markCheckOut = catchAsyncErrors(async (req, res, next) => {
		let { bookingRequestId, actualToDate, actualCheckOutTime, } = req.body;

		if (
			(!bookingRequestId || bookingRequestId == "" || bookingRequestId == null || bookingRequestId == undefined)
			|| (!actualToDate || actualToDate == "" || actualToDate == null || actualToDate == undefined)
			|| (!actualCheckOutTime || actualCheckOutTime == "" || actualCheckOutTime == null || actualCheckOutTime == undefined)
		) {
			return res.status(422).json({
				status: false,
				message: "All parameters are not present. Please pass all the required parameters.",
				data: {},
			});
		}

		let checkCarMovementExist = await super.getByCustomOptionsSingle(req, carMovementsModel, {
			where: {
				bookingRequestId: bookingRequestId,
			},
		});

		if (!checkCarMovementExist) {
			// if an attempt to mark a car as check-out is made, then carMovement record must pre-exist ===
			return res.status(400).json({
				status: false,
				message: "Ooppss..!! Car movement record not found.",
				data: {},
			});
		}

		let bookingRequestDetail = await super.getByCustomOptionsSingle(req, bookingRequestsModel, {
			where: {
				id: bookingRequestId,
			},
		});

		// check if overstay =====

		// handle check-out =====
		let carMovementData = {
			actualToDate: actualToDate,
			actualCheckOutTime: actualCheckOutTime,

			// default value
			carStatus: "Checked Out",
		};

		let conditions = {
			bookingRequestId: bookingRequestId,
		};
		let carMovementUpdate = await super.updateByCustomOptions(
			carMovementsModel,
			conditions,
			carMovementData
		);

		let bookingRequest = await super.getByCustomOptionsSingle(req, bookingRequestsModel, {
			where: {
				id: bookingRequestId,
			}
		});
		let customerData = await super.getByCustomOptionsSingle(req, userModel, {
			where: {
				id: bookingRequest?.customerId,
			}
		});

		if (carMovementUpdate) {
			let updatedCarMovement = await super.getByCustomOptionsSingle(req, carMovementsModel, {
				where: {
					bookingRequestId: bookingRequestId,
				},
			});
			let slotStatusUpdate = await super.updateById(slotsModel, bookingRequestDetail.slotId, {
				occupancyStatus: "Vacant"
			});
			let updateBookingRequest = await super.updateById(
				bookingRequestsModel,
				bookingRequestId,
				{
					bookingStatus: "Checked Out",
				}
			);
			let updatedBookingRequest = await super.getById(req, bookingRequestsModel, bookingRequestId);

			// ============= send email =============
			let content = `
			<div>
				<h4>Dear ${customerData?.firstName}, we checked out your car. For more details refer to ticket no.: ${updatedBookingRequest?.bookingTicketNo}. We look forward to serving you again. Adios.. till next time..!!</h4>
			<div>`;

			sendMail(customerData?.email, `Checked out..!!`, content);
			// ============= send email =============

			//  ========== push noti ==========
			console.log("------ Sending check-out Notification ----");
			let messages = {
				title: "Checked-out..!!",
				body: JSON.stringify({
					// "tripId": tripPassenger.tripId._id.toString(),
					"msg": `Dear ${customerData?.firstName}, we checked out your car. For more details refer to ticket no.: ${updatedBookingRequest?.bookingTicketNo}. We look forward to serving you again. Adios.. till next time..!!`,
					"type": "Show"
				}),
			};
			if (customerData?.fcmToken) {
				await sendPushNotification(customerData?.fcmToken, messages, "android");
			}
			//  ========== push noti ==========

			if (updatedBookingRequest) {
				return res.status(200).json({
					status: true,
					message: "Successfully checked Out.",
					data: {
						updatedBookingRequest: updatedBookingRequest,
						updatedCarMovement: updatedCarMovement,
					}
				});
			} else {
				return res.status(200).json({
					status: false,
					message: "Succesfully checked-out, but error fetching updated booking request.",
					data: {
						updatedBookingRequest: {},
						updatedCarMovement: updatedCarMovement,
					}
				});
			}
		} else {
			return res.status(400).json({
				status: false,
				message: "Something went wrong while checking the car out.",
				data: {}
			});
		}
	});

	static calculateBookingChargesAfterCheckOut = catchAsyncErrors(async (req, res, next) => {
		let { bookingRequestId, platformMedium, checkoutDate, endTime, } = req.body;

		if (
			(!bookingRequestId || bookingRequestId == "" || bookingRequestId == null || bookingRequestId == undefined)
			|| (!checkoutDate || checkoutDate == "" || checkoutDate == null || checkoutDate == undefined)
			|| (!endTime || endTime == "" || endTime == null || endTime == undefined)
		) {
			return res.status(422).json({
				status: false,
				message: "All parameters are not present. Please pass all the required parameters.",
				data: {},
			});
		}

		let bookingRequestData = await super.getByCustomOptionsSingle(req, bookingRequestsModel, {
			where: {
				id: bookingRequestId
			},
		});

		let carMovementData = await super.getByCustomOptionsSingle(req, carMovementsModel, {
			where: {
				bookingRequestId: bookingRequestId,
			},
		});

		let existingInvoice = await super.getByCustomOptionsSingle(req, invoiceModel, {
			where: {
				bookingRequestId: bookingRequestId,
			},
		});

		// Define startDate and endDate in the same time zone
		// let startDate = moment.tz(bookingRequestData.fromDate+ " " +bookingRequestData.selectedCheckInTime, timeZone);
		// let endDate = moment.tz(checkoutDate+ " " +endTime, timeZone);
		// let startDate = moment.tz(bookingRequestData.fromDate+ " 00:00:00", timeZone);
		// let endDate = moment.tz(checkoutDate+ " 23:59:59", timeZone);

		let startDate = moment.tz(bookingRequestData.fromDate, timeZone).startOf('day');
		let endDate = moment.tz(checkoutDate, timeZone).endOf('day');
		let dayCount = endDate.diff(startDate, 'days') + 1;


		// Calculate the difference in total minutes
		// const totalMinutes = endDate.diff(startDate, 'minutes');

		// // Calculate the full days, rounding up if minutes exceed 15
		// // 1440 minutes in a day ---------------
		// let dayCount = Math.floor(totalMinutes / 1440); 
		// Remaining minutes after full days ---------------
		// let remainingMinutes = totalMinutes % 1440; 

		// // Check if remaining minutes exceed 15 ---------------
		// if (remainingMinutes > 15) {
		// 	// Count an additional day if more than 15 minutes ---------------
		// 	dayCount += 1; 
		// }

		// let selectedStartDate = moment.tz(bookingRequestData.fromDate+ " " +bookingRequestData.selectedCheckInTime, timeZone);
		// let selectedEndDate = moment.tz(bookingRequestData.toDate+ " " +bookingRequestData.selectedCheckOutTime, timeZone);
		// let selectedStartDate = moment.tz(bookingRequestData.fromDate+ " 00:00:00", timeZone);
		// let selectedEndDate = moment.tz(bookingRequestData.toDate+ " 23:59:59", timeZone);

		let selectedStartDate = moment.tz(bookingRequestData.fromDate, timeZone).startOf('day');
		let selectedEndDate = moment.tz(bookingRequestData.toDate, timeZone).endOf('day');
		let selectedDayCount = selectedEndDate.diff(selectedStartDate, 'days') + 1;

		// Calculate the difference in total minutes
		// const selectedTotalMinutes = selectedEndDate.diff(selectedStartDate, 'minutes');

		// Calculate the full days, rounding up if minutes exceed 15
		// 1440 minutes in a day ---------------
		// let selectedDayCount = Math.floor(selectedTotalMinutes / 1440); 
		// Remaining minutes after full days ---------------
		// let selectedRemainingMinutes = selectedTotalMinutes % 1440; 

		// // Check if remaining minutes exceed 15 ---------------
		// if (selectedRemainingMinutes > 15) {
		// 	// Count an additional day if more than 15 minutes ---------------
		// 	selectedDayCount += 1; 
		// }

		if (selectedDayCount >= dayCount) {
			// if user checkes out earlier than the booked date ==== day count will be selected days ====
			dayCount = selectedDayCount;
		}

		let staticCharges = await staticChargesModel.findOne({
			where: {
				parkingGroundId: 1,
				isActive: true,
			},
		});

		let priceChart = await priceChartsModel.findOne({
			where: {
				vehicleTypeId: carMovementData.actualvehicleTypeId,
				isActive: true,
			},
		});

		let reservationAmount = Number(staticCharges?.reservationCharge);
		let onlineBookingAmount = Number(existingInvoice.onlineBookingAmount);
		let parkingChargeTotal = 0;
		let overSizeRate = Number(priceChart.overSizeRate);
		let overSizeCharge = Number(dayCount) * overSizeRate;
		let overSizeChargeTotal = 0;

		let passengerCount = existingInvoice.extraPassengers;
		let extraPassengerChargesTotal= existingInvoice.extraPassengerChargesTotal

		// let extraPassengers = 0;
		// let extraPassengerChargesTotal = 0;
		// // ----- extra charges for more than 4 passengers -----
		// if (Number(passengerCount) > Number(staticCharges.defaultPassengerCount)) {
		// 	extraPassengers = Number(passengerCount) - Number(staticCharges.defaultPassengerCount);
		// }
		// ----- extra charges for more than 4 passengers -----
		// extraPassengerChargesTotal = Number(extraPassengers) * Number(staticCharges.extraPassengerChargePerHead);

		let overstayDays = Number(dayCount) - Number(selectedDayCount);
		let overstayAmountTotal = Number(overstayDays) * Number(priceChart.lateFees);
		let payableAmount = 0;

		let earlyCheckinAmountTotal = existingInvoice.earlyCheckinAmountTotal;
		let totalExtraDays = 0;

		let existingOnSiteChargeForVendor = 0;
		existingOnSiteChargeForVendor = Number(existingInvoice?.onSiteChargeForVendor);

		// if(carMovementData.vendorId && carMovementData.vendorId != "" && carMovementData.vendorId != null){
		// 	parkingChargeTotal = Number(dayCount) * Number(priceChart.overSizeRate);
		// } else {
		// 	parkingChargeTotal = Number(dayCount) * Number(priceChart.dailyParkingRate);
		// }
		if (carMovementData.vendorId && existingOnSiteChargeForVendor) {
			parkingChargeTotal = Number(dayCount) * Number(priceChart.overSizeRate);
		} else {
			if (platformMedium != "AdminBooking") {
				parkingChargeTotal = Number(dayCount) * (Number(priceChart.dailyParkingRate) + Number(priceChart.overSizeRate));
			} else {
				parkingChargeTotal = Number(dayCount) * Number(priceChart.dailyParkingRate)
			}
		}

		payableAmount = Number(parkingChargeTotal) + Number(overSizeChargeTotal) + Number(extraPassengerChargesTotal) + Number(overstayAmountTotal) + Number(existingOnSiteChargeForVendor)  + Number(onlineBookingAmount);

		let paidAmount = 0;
		// before checkout user pays full amount offline as of now; hence =============
		paidAmount = Number(payableAmount);
		let dueAmount = 0;

		dueAmount = Number(payableAmount) - Number(paidAmount);

		let invoiceData = {
			reservationAmount: reservationAmount,
			onlineBookingAmount: onlineBookingAmount,

			parkingChargeTotal: parkingChargeTotal,
			overSizeChargeTotal: overSizeCharge,

			extraPassengers: passengerCount,
			extraPassengerChargesTotal: extraPassengerChargesTotal,

			overstayDays: overstayDays,
			overstayAmountTotal: overstayAmountTotal,

			payableAmount: payableAmount,

			paidAmount: paidAmount,

			dueAmount: dueAmount,

			paymentStatus: "Due",
			// paymentStatus: "Fully Paid",
		};

		let conditions = {
			bookingRequestId: bookingRequestId
		};

		let updateInvoice = await super.updateByCustomOptions(
			invoiceModel,
			conditions,
			invoiceData
		);

		let updatedInvoice = await super.getByCustomOptionsSingle(req, invoiceModel, {
			where: {
				bookingRequestId: bookingRequestId
			},
		});

		let bookingRequestDetail = await super.getByCustomOptionsSingle(req, bookingRequestsModel, {
			where: {
				id: updatedInvoice.bookingRequestId,
			},
		});

		if (updateInvoice) {
			return res.status(200).json({
				status: true,
				message: "Invoice updated after check-out.",
				data: {
					updatedInvoice: updatedInvoice,
					bookingRequestDetail: bookingRequestDetail,
				},
			});
		} else {
			return res.status(400).json({
				status: false,
				message: "Trouble creating final invoice.",
				data: {},
			});
		}
	});

	static invoiceDetail = catchAsyncErrors(async (req, res, next) => {
		let { bookingRequestId, platformMedium } = req.body;

		let invoiceDetail = await super.getByCustomOptionsSingle(req, invoiceModel, {
			where: {
				bookingRequestId: bookingRequestId,
			},
			include: [
				{
					model: bookingRequestsModel,
					include: [
						{
							model: slotsModel,
						},
						{
							model: userModel,
							attributes: {
								exclude: [
									"password",
									"webLogin",
									"appLogin",
									"fcmToken",
									"OTP",
									"macAddress",
									"deviceId",
								],
							},
							include: [
								{
									model: roleModel,
								},
							]
						},
						{
							model: vehicleTypesModel,
						},
					]
				}
			]
		});

		let carMovementDetail = await super.getByCustomOptionsSingle(req, carMovementsModel, {
			where: {
				bookingRequestId: bookingRequestId,
			}
		});

		if (invoiceDetail) {
			// let dayCount = 0;
			let dailyCharge = 0;

			let bookingRequestDetail = await super.getByCustomOptionsSingle(req, bookingRequestsModel, {
				where: {
					id: bookingRequestId,
				}
			});
			// Define startDate and endDate in the same time zone
			// let startDate = moment.tz(bookingRequestDetail?.fromDate+ " " +bookingRequestDetail?.selectedCheckInTime, timeZone);
			// let endDate = moment.tz(bookingRequestDetail?.toDate+ " " +bookingRequestDetail?.selectedCheckOutTime, timeZone);

			let startDate = moment.tz(bookingRequestDetail?.fromDate, timeZone).startOf('day');
			let endDate = moment.tz(bookingRequestDetail?.toDate, timeZone).endOf('day');
			let dayCount = endDate.diff(startDate, 'days') + 1;

			// Calculate the difference in total minutes
			// let totalMinutes = endDate.diff(startDate, 'minutes');

			// // Calculate the full days, rounding up if minutes exceed 15
			// // 1440 minutes in a day ---------------
			// dayCount = Math.floor(totalMinutes / 1440); 
			// // Remaining minutes after full days ---------------
			// let remainingMinutes = totalMinutes % 1440; 

			// // Check if remaining minutes exceed 15 ---------------
			// if (remainingMinutes > 15) {
			// 	// Count an additional day if more than 15 minutes ---------------
			// 	dayCount += 1; 
			// }

			let priceChartOfVehicle = await super.getByCustomOptionsSingle(req, priceChartsModel, {
				where: {
					vehicleTypeId: bookingRequestDetail?.vehicleTypeId,
				}
			});

			dailyCharge = priceChartOfVehicle?.dailyParkingRate;

			if (carMovementDetail) {
				let startDate = '';
				let endDate = '';

				// Define startDate and endDate in the same time zone
				if (new Date(bookingRequestDetail?.fromDate) >= new Date(carMovementDetail?.actualFromDate)) {
					// startDate = moment.tz(bookingRequestDetail?.fromDate+ " " +bookingRequestDetail?.selectedCheckInTime, timeZone);
					startDate = moment.tz(bookingRequestDetail?.fromDate, timeZone).startOf('day');
				} else {
					// startDate = moment.tz(carMovementDetail?.actualFromDate+ " " +carMovementDetail?.actualCheckInTime, timeZone);
					startDate = moment.tz(carMovementDetail?.actualFromDate, timeZone).startOf('day');
				}

				if (carMovementDetail?.actualToDate) {
					// endDate = moment.tz(carMovementDetail?.actualToDate+ " " +carMovementDetail?.actualCheckOutTime, timeZone);
					endDate = moment.tz(carMovementDetail?.actualToDate, timeZone).endOf('day');
				} else {
					// endDate = moment.tz(bookingRequestDetail?.toDate+ " " +bookingRequestDetail?.selectedCheckOutTime, timeZone);
					endDate = moment.tz(bookingRequestDetail?.toDate, timeZone).endOf('day');
				}

				dayCount = endDate.diff(startDate, 'days') + 1;

				// Calculate the difference in total minutes
				// let actualTotalMinutes = endDate.diff(startDate, 'minutes');

				// // Calculate the full days, rounding up if minutes exceed 15
				// // 1440 minutes in a day ---------------
				// dayCount = Math.floor(actualTotalMinutes / 1440); 
				// // Remaining minutes after full days ---------------
				// let actualRemainingMinutes = actualTotalMinutes % 1440; 

				// // Check if remaining minutes exceed 15 ---------------
				// if (actualRemainingMinutes > 15) {
				// 	// Count an additional day if more than 15 minutes ---------------
				// 	dayCount += 1; 
				// }

				// if(carMovementDetail?.vendorId && carMovementDetail?.onSiteChargeForVendor){
				// 	dailyCharge = priceChartOfVehicle?.overSizeRate;
				// } else {
				// 	dailyCharge = priceChartOfVehicle?.dailyParkingRate;
				// }



				if (carMovementDetail?.vendorId && carMovementDetail?.onSiteChargeForVendor) {
					dailyCharge = Number(priceChartOfVehicle.overSizeRate);
				} else {
					if (platformMedium != "AdminBooking") {
						dailyCharge = Number(priceChartOfVehicle.dailyParkingRate) + Number(priceChartOfVehicle.overSizeRate);
					} else {
						dailyCharge = Number(priceChartOfVehicle.dailyParkingRate)
					}
				}

			}

			return res.status(200).json({
				status: true,
				message: "Details found",
				data: {
					invoiceDetail: invoiceDetail,
					carMovementDetail: carMovementDetail,
					dayCount: dayCount,
					dailyCharge: dailyCharge,
				},
			});
		} else {
			return res.status(400).json({
				status: false,
				message: "No details found. Wrong booking id.",
				data: {},
			});
		}
	});

	static generateInvoice = catchAsyncErrors(async (req, res, next) => {
		let { bookingRequestId } = req.body;

		if (!bookingRequestId) {
			return res.status(400).json({
				status: false,
				message: "Booking request id is required.",
				data: {}
			});
		}

		let invoiceDetail = await super.getByCustomOptionsSingle(req, invoiceModel, {
			where: {
				bookingRequestId: bookingRequestId,
			},
			include: [
				{
					model: bookingRequestsModel,
					include: [
						{
							model: slotsModel,
						},
						{
							model: userModel,
							attributes: {
								exclude: [
									"password",
									"webLogin",
									"appLogin",
									"fcmToken",
									"OTP",
									"macAddress",
									"deviceId",
								],
							},
							include: [
								{
									model: roleModel,
								},
							]
						},
						{
							model: vehicleTypesModel,
						},
					]
				}
			]
		});

		let carMovementDetail = await super.getByCustomOptionsSingle(req, carMovementsModel, {
			where: {
				bookingRequestId: bookingRequestId,
			},
			include: [
				{
					model: vehicleTypesModel,
				},
			]
		});

		if (invoiceDetail) {
			let dailyCharge = 0;

			let bookingRequestDetail = await super.getByCustomOptionsSingle(req, bookingRequestsModel, {
				where: {
					id: bookingRequestId,
				}
			});
			// Define startDate and endDate in the same time zone
			// let startDate = moment.tz(bookingRequestDetail?.fromDate+ " " +bookingRequestDetail?.selectedCheckInTime, timeZone);
			// let endDate = moment.tz(bookingRequestDetail?.toDate+ " " +bookingRequestDetail?.selectedCheckOutTime, timeZone);

			let startDate = moment.tz(bookingRequestDetail?.fromDate, timeZone).startOf('day');
			let endDate = moment.tz(bookingRequestDetail?.toDate, timeZone).endOf('day');
			let dayCount = endDate.diff(startDate, 'days') + 1;

			// Calculate the difference in total minutes
			// let totalMinutes = endDate.diff(startDate, 'minutes');

			// Calculate the full days, rounding up if minutes exceed 15
			// 1440 minutes in a day ---------------
			// dayCount = Math.floor(totalMinutes / 1440); 
			// Remaining minutes after full days ---------------
			// let remainingMinutes = totalMinutes % 1440; 

			// Check if remaining minutes exceed 15 ---------------
			// if (remainingMinutes > 15) {
			// 	// Count an additional day if more than 15 minutes ---------------
			// 	dayCount += 1; 
			// }

			let priceChartOfVehicle = await super.getByCustomOptionsSingle(req, priceChartsModel, {
				where: {
					vehicleTypeId: bookingRequestDetail?.vehicleTypeId,
				}
			});

			dailyCharge = priceChartOfVehicle?.dailyParkingRate;

			if (carMovementDetail) {
				let startDate = '';
				let endDate = '';

				// Define startDate and endDate in the same time zone
				if (new Date(bookingRequestDetail?.fromDate) >= new Date(carMovementDetail?.actualFromDate)) {
					startDate = moment.tz(bookingRequestDetail?.fromDate + " " + bookingRequestDetail?.selectedCheckInTime, timeZone);
				} else {
					startDate = moment.tz(carMovementDetail?.actualFromDate + " " + carMovementDetail?.actualCheckInTime, timeZone);
				}

				if (carMovementDetail?.actualToDate) {
					endDate = moment.tz(carMovementDetail?.actualToDate + " " + carMovementDetail?.actualCheckOutTime, timeZone);
				} else {
					endDate = moment.tz(bookingRequestDetail?.toDate + " " + bookingRequestDetail?.selectedCheckOutTime, timeZone);
				}

				// Calculate the difference in total minutes
				let actualTotalMinutes = endDate.diff(startDate, 'minutes');

				// Calculate the full days, rounding up if minutes exceed 15
				// 1440 minutes in a day ---------------
				dayCount = Math.floor(actualTotalMinutes / 1440);
				// Remaining minutes after full days ---------------
				let actualRemainingMinutes = actualTotalMinutes % 1440;

				// Check if remaining minutes exceed 15 ---------------
				if (actualRemainingMinutes > 15) {
					// Count an additional day if more than 15 minutes ---------------
					dayCount += 1;
				}

				if (carMovementDetail?.vendorId) {
					dailyCharge = priceChartOfVehicle?.overSizeRate;
				} else {
					dailyCharge = priceChartOfVehicle?.dailyParkingRate;
				}
			}

			let policies = await policiesModel.findOne({
				where: {
					deletedAt: null,
					policies: {
						[Op.ne]: null
					},
				},
			});

			const htmlContent = `
				<!DOCTYPE html>
				<html lang="en">

				<head>
						<meta charset="UTF-8">
						<meta name="viewport" content="width=device-width, initial-scale=1.0">
						<title>Bill</title>

						<style>
								table,
								div,
								h1,
								h2,
								h3,
								h4,
								h5,
								h6,
								p {
										font-family: "Poppins", sans-serif;
										margin: 0;
								}


								p {
										padding: 4px 0;
										color: hsla(0, 0%, 42%, 1);
										font-size: 12px;
										white-space: normal;
										line-height: 16px;
								}

								h3 {
										font-size: 14px;
										line-height: 21px;
										text-align: left;
										color: hsla(0, 0%, 0%, 1);
										font-weight: 600;
										/* width: max-content; */
										white-space: normal;
								}

								h6 {
										font-size: 17px;
										color: #336b87;
								}


								table tr td {
										/* padding: 5px; */
										vertical-align: middle;
										width: 100%;
										white-space: nowrap;
								}

								table {
										width: 100%;
										border-collapse: collapse;
										border: 0;
										border-spacing: 0;
								}

								table.body-top {
										background: hsla(240, 3%, 94%, 1);
										table-layout: fixed;
										overflow: hidden;
										white-space: nowrap;
										text-overflow: ellipsis;
								}

								.top-table {
										width: 900px !important;
								}

								.bg-black {
										background: hsla(0, 0%, 0%, 1);
										padding: 10px 0;
								}

								.bg-black h5 {
										font-size: 18px;
										font-weight: 600;
										line-height: 30px;
										letter-spacing: 0.02em;
										text-align: center;
										color: #fff;
								}

								.bg-black p {
										font-size: 13px;
										font-weight: 400;
										line-height: 21px;
										letter-spacing: 0.02em;
										text-align: center;
										color: hsla(0, 0%, 100%, 1);
										padding: 0 6px;
								}

								table.biling-details h2 {
										font-size: 18px;
										font-weight: 600;
										line-height: 22px;
										text-align: left;
								}

								table.common-table {
										border: 1px solid hsla(0, 0%, 85%, 1);
										background: #fff;
								}

								.common-table {
										width: fit-content;
										/* Fixed width for each table */
										/* Ensures fixed layout */
										margin: 0;
										/* Reset margin if necessary */
										padding: 0;
										/* Reset padding if necessary */
										border-collapse: collapse;
										/* Optional: to remove spacing between cells */
										table-layout: fixed;
										overflow: hidden;
										/* white-space: nowrap; */
										text-overflow: ellipsis;
								}


								/* .common-table{
										width: 30%;
								} */

								table.biling-details tr {
										border-bottom: 1.5px dotted hsla(0, 0%, 0%, 0.41);
								}

								table.biling-details tr td,
								.body-top tr td,
								.bottom-table tr td {
										padding: 10px 10px;
								}

								table.biling-details td h5 {
										font-weight: 700;
										font-size: 16px;
								}

								.check-img img {
										width: 30px;
								}

								.bottom-table tbody tr:last-child td {
										padding-bottom: 40px;
										white-space: normal;
								}

								.biling-details tbody tr:last-child {
										border-bottom: 0;
								}

								.biling-details span {
										font-size: 14px;
										font-style: italic;
										font-weight: 400;
										line-height: 22px;
										text-align: left;
										color: hsla(227, 80%, 64%, 1);
								}

								.scnr-img img {
										width: 75px;
								}

								.slot {
										border: 1px solid hsla(0, 0%, 0%, 1);
										padding: 10px;
								}

								.slot h2 {
										font-size: 12px;
										font-weight: 600;
										line-height: 19px;
										text-align: left;
										white-space: normal;
								}

								.bg-white {
										background-color: #fff;
								}

								.slot.bg-white h1 {
										font-size: 20px;
								}

								td.cmn-width {
										vertical-align: top;
										width: 33.33%;
								}

								table.bottom-table {
										table-layout: fixed;
										overflow: hidden;
										white-space: nowrap;
										text-overflow: ellipsis;
								}

								tr.Signature h4 {
										font-size: 13px;
										line-height: 17px;
										white-space: normal;
								}

								table tr td {
										white-space: normal;
								}
						</style>
				</head>



				<body>


						<table class="top-table" style="width: 800px; background-color: #fff; padding: 40px; margin: 40px auto; ">

								<tr>
										<td class="cmn-width">
												<table class="common-table">
														<tr>
																<td style="padding:0">
																		<div class="bg-black">
																				<h5>Prime Park Receipt</h5>
																				<p>${invoiceDetail?.bookingRequest?.user?.phone}</p>
																				<p>${(invoiceDetail?.bookingRequest?.user?.address)
					? (invoiceDetail?.bookingRequest?.user?.address)
					: "N/A"}</p>
																		</div>
																</td>
														</tr>
														<tr>
																<td>
																		<table class="body-top">
																				<tr>
																						<td>
																								<div class="check-in">
																										<p>Check In Date & Time</p>
																										<h3>
																											${(carMovementDetail && carMovementDetail.length > 0)
					? (carMovementDetail?.actualFromDate)
					: (invoiceDetail?.bookingRequest?.fromDate)} | ${(carMovementDetail && carMovementDetail.length > 0)
						? (carMovementDetail?.actualCheckInTime)
						: (invoiceDetail?.bookingRequest?.selectedCheckInTime)}</h3>
																								</div>
																						</td>
																						<td>
																								<div class="check-in">
																										<p>Check Out Date & Time</p>
																										<h3>${(carMovementDetail && carMovementDetail.length > 0)
					? (carMovementDetail?.actualToDate)
					: (invoiceDetail?.bookingRequest?.toDate)} | ${(carMovementDetail && carMovementDetail.length > 0)
						? (carMovementDetail?.actualCheckOutTime)
						: (invoiceDetail?.bookingRequest?.selectedCheckOutTime)}</h3>
																								</div>
																						</td>
																				</tr>
																				<tr>
																						<td>
																								<div class="check-in">
																										<p>Name</p>
																										<h3>${invoiceDetail?.bookingRequest?.user?.firstName} ${invoiceDetail?.bookingRequest?.user?.lastName}</h3>
																								</div>
																						</td>
																						<td>
																								<div class="check-in">
																										<p>Phone number</p>
																										<h3>${invoiceDetail?.bookingRequest?.user?.phone}</h3>
																								</div>
																						</td>
																				</tr>
																				<tr>
																						<td>
																								<div class="check-in">
																										<p>Ticket ID</p>
																										<h3>${invoiceDetail?.bookingRequest?.bookingTicketNo}</h3>
																								</div>
																						</td>
																						<td>
																								<div class="check-in">
																										<p>Slot Number</p>
																										<h3>${invoiceDetail?.bookingRequest?.slot?.slotName}</h3>
																								</div>
																						</td>
																				</tr>
																				<tr>
																						<td>
																								<div class="check-in">
																										<p>Payment</p>
																										<h3>Cash</h3>
																								</div>
																						</td>
																						<td>
																								<div class="check-in">
																										<p>Cash</p>
																										<h3>$ ${invoiceDetail?.payableAmount}</h3>
																								</div>
																						</td>
																				</tr>

																		</table>
																</td>

														<tr>
																<td>
																		<table class="biling-details">
																				<tr>
																						<td>
																								<h2>Billing Details</h2>
																						</td>
																				</tr>
																				<tr>
																						<td>
																								<p>Onsite amount charges</p>
																						</td>
																						<td>
																								<h5>$ ${invoiceDetail?.onSiteChargeForVendor}</h5>
																						</td>
																				</tr>
																				<tr>
																						<td>
																								<div class="parking-carge">
																										<p>Parking Charges</p>
																										<span>(${dayCount} days * $${dailyCharge} - ${(carMovementDetail && carMovementDetail.length > 0)
					? (carMovementDetail?.vehicleType?.typeName)
					: (invoiceDetail?.bookingRequest?.vehicleType?.typeName)
				} )</span>
																								</div>
																						</td>
																						<td>
																								<h5>$ ${invoiceDetail?.parkingChargeTotal}</h5>
																						</td>
																				</tr>
																				<tr>
																						<td>
																								<div class="parking-carge">
																										<p>Overstay charges</p>
																										<span>(${invoiceDetail?.overstayDays} days)</span>
																								</div>
																						</td>
																						<td>
																								<h5>$ ${invoiceDetail?.overstayAmountTotal}</h5>
																						</td>
																				</tr>
																				<tr>
																						<td>
																								<div class="parking-carge">
																										<p>Early Check In charges</p>
																										<span>(${invoiceDetail?.earlyCheckinAmountTotal})</span>
																								</div>
																						</td>
																						<td>
																								<h5>$ ${invoiceDetail?.overstayAmountTotal}</h5>
																						</td>
																				</tr>
																				<tr>
																						<td>
																								<div class="parking-carge">
																										<p>Extra Passenger Fees</p>
																										<span>(${invoiceDetail?.extraPassengers} Passengers)</span>
																								</div>
																						</td>
																						<td>
																								<h5>$ ${invoiceDetail?.extraPassengerChargesTotal}</h5>
																						</td>
																				</tr>
																				<tr>
																						<td>
																								<div class="parking-carge">
																										<p>Reservation Fee (Paid)</p>
																								</div>
																						</td>
																						<td>
																								<h5>$ ${invoiceDetail?.reservationAmount}</h5>
																						</td>
																				</tr>
																		</table>
																</td>
														</tr>


														<tr>
																<td>
																		<table class="bottom-table">
																				<tr class="bg-black">
																						<td style="width:50%">
																								<h5 style="text-align: left;">Total amount to pay</h5>
																						</td>
																						<td style="width:50%">
																								<h5 style="text-align: right;">$ ${invoiceDetail?.dueAmount}</h5>
																						</td>
																				</tr>
																				<tr>
																						<td colspan="2">
																								<h4>Terms & Conditions</h4>
																						</td>
																				</tr>
																				<tr>
																						<td colspan="2">
																								${policies?.policies}
																						</td>
																				</tr>

																				<tr class="Signature">
																						<td style="vertical-align: middle; width: 10%;">
																								<div class="check-img">
																										<img src="images/check.png" alt="">
																								</div>
																						</td>
																						<td>
																								<h4>I accept the Terms & Conditions</h4>
																						</td>
																				</tr>
																				<tr class="Signature">
																						<td></td>
																						<td>
																								<h4>Customer's Signature</h4>
																						</td>
																				</tr>

																				<tr>
																						<td></td>
																						<td>...................................................</td>
																				</tr>
																		</table>
																</td>
														</tr>
								</tr>

						</table>
						</td>
						<td class="cmn-width">
								<table class="common-table">
														<tr>
																<td style="padding:0">
																		<div class="bg-black">
																				<h5>Prime Park Receipt</h5>
																				<p>${invoiceDetail?.bookingRequest?.user?.phone}</p>
																				<p>${invoiceDetail?.bookingRequest?.user?.address}</p>
																		</div>
																</td>
														</tr>
														<tr>
																<td>
																		<table class="body-top">
																				<tr>
																						<td>
																								<div class="check-in">
																										<p>Check In Date & Time</p>
																										<h3>
																											${(carMovementDetail && carMovementDetail.length > 0)
					? (carMovementDetail?.actualFromDate)
					: (invoiceDetail?.bookingRequest?.fromDate)} | ${(carMovementDetail && carMovementDetail.length > 0)
						? (carMovementDetail?.actualCheckInTime)
						: (invoiceDetail?.bookingRequest?.selectedCheckInTime)}</h3>
																								</div>
																						</td>
																						<td>
																								<div class="check-in">
																										<p>Check Out Date & Time</p>
																										<h3>${(carMovementDetail && carMovementDetail.length > 0)
					? (carMovementDetail?.actualToDate)
					: (invoiceDetail?.bookingRequest?.toDate)} | ${(carMovementDetail && carMovementDetail.length > 0)
						? (carMovementDetail?.actualCheckOutTime)
						: (invoiceDetail?.bookingRequest?.selectedCheckOutTime)}</h3>
																								</div>
																						</td>
																				</tr>
																				<tr>
																						<td>
																								<div class="check-in">
																										<p>Name</p>
																										<h3>${invoiceDetail?.bookingRequest?.user?.firstName} ${invoiceDetail?.bookingRequest?.user?.lastName}</h3>
																								</div>
																						</td>
																						<td>
																								<div class="check-in">
																										<p>Phone number</p>
																										<h3>${invoiceDetail?.bookingRequest?.user?.phone}</h3>
																								</div>
																						</td>
																				</tr>
																				<tr>
																						<td>
																								<div class="check-in">
																										<p>Ticket ID</p>
																										<h3>${invoiceDetail?.bookingRequest?.bookingTicketNo}</h3>
																								</div>
																						</td>
																						<td>
																								<div class="check-in">
																										<p>Slot Number</p>
																										<h3>${invoiceDetail?.bookingRequest?.slot?.slotName}</h3>
																								</div>
																						</td>
																				</tr>
																				<tr>
																						<td>
																								<div class="check-in">
																										<p>Payment</p>
																										<h3>Cash</h3>
																								</div>
																						</td>
																						<td>
																								<div class="check-in">
																										<p>Cash</p>
																										<h3>$ ${invoiceDetail?.payableAmount}</h3>
																								</div>
																						</td>
																				</tr>

																		</table>
																</td>

														<tr>
																<td>
																		<table class="biling-details">
																				<tr>
																						<td>
																								<h2>Billing Details</h2>
																						</td>
																				</tr>
																				<tr>
																						<td>
																								<p>Onsite amount charges</p>
																						</td>
																						<td>
																								<h5>$ ${invoiceDetail?.onSiteChargeForVendor}</h5>
																						</td>
																				</tr>
																				<tr>
																						<td>
																								<div class="parking-carge">
																										<p>Parking Charges</p>
																										<span>(${dayCount} days * $${dailyCharge} - ${(carMovementDetail && carMovementDetail.length > 0)
					? (carMovementDetail?.vehicleType?.typeName)
					: (invoiceDetail?.bookingRequest?.vehicleType?.typeName)
				} )</span>
																								</div>
																						</td>
																						<td>
																								<h5>$ ${invoiceDetail?.parkingChargeTotal}</h5>
																						</td>
																				</tr>
																				<tr>
																						<td>
																								<div class="parking-carge">
																										<p>Overstay charges</p>
																										<span>(${invoiceDetail?.overstayDays} days)</span>
																								</div>
																						</td>
																						<td>
																								<h5>$ ${invoiceDetail?.overstayAmountTotal}</h5>
																						</td>
																				</tr>
																				<tr>
																						<td>
																								<div class="parking-carge">
																										<p>Early Check In charges</p>
																										<span>(${invoiceDetail?.earlyCheckinAmountTotal})</span>
																								</div>
																						</td>
																						<td>
																								<h5>$ ${invoiceDetail?.overstayAmountTotal}</h5>
																						</td>
																				</tr>
																				<tr>
																						<td>
																								<div class="parking-carge">
																										<p>Extra Passenger Fees</p>
																										<span>(${invoiceDetail?.extraPassengers} Passengers)</span>
																								</div>
																						</td>
																						<td>
																								<h5>$ ${invoiceDetail?.extraPassengerChargesTotal}</h5>
																						</td>
																				</tr>
																				<tr>
																						<td>
																								<div class="parking-carge">
																										<p>Reservation Fee (Paid)</p>
																								</div>
																						</td>
																						<td>
																								<h5>$ ${invoiceDetail?.reservationAmount}</h5>
																						</td>
																				</tr>
																		</table>
																</td>
														</tr>


														<tr>
																<td>
																		<table class="bottom-table">
																				<tr class="bg-black">
																						<td style="width:50%">
																								<h5 style="text-align: left;">Total amount to pay</h5>
																						</td>
																						<td style="width:50%">
																								<h5 style="text-align: right;">$ ${invoiceDetail?.dueAmount}</h5>
																						</td>
																				</tr>
																				<tr>
																						<td colspan="2">
																								<h4>Terms & Conditions</h4>
																						</td>
																				</tr>
																				<tr>
																						<td colspan="2">
																								<p>${policies?.policies}</p>
																						</td>
																				</tr>

																				<tr class="Signature">
																						<td style="vertical-align: middle; width: 10%;">
																								<div class="check-img">
																										<img src="images/check.png" alt="">
																								</div>
																						</td>
																						<td>
																								<h4>I accept the Terms & Conditions</h4>
																						</td>
																				</tr>
																				<tr class="Signature">
																						<td></td>
																						<td>
																								<h4>Customer's Signature</h4>
																						</td>
																				</tr>

																				<tr>
																						<td></td>
																						<td>...................................................</td>
																				</tr>
																		</table>
																</td>
														</tr>
								</tr>

							</table>
						</td>
						<td class="cmn-width">
								<table class="common-table">
										<tr>
												<td style="padding:0">
														<div class="bg-black">
																<h5>Prime Park JFK</h5>
														</div>
												</td>
										</tr>
										<tr>
												<td>
														<table class="body-top">
																<tr>
																		<td>
																				<div class="slot">
																						<p>Slot</p>
																						<h2>${invoiceDetail?.bookingRequest?.slot?.slotName}</h2>
																				</div>
																		</td>
																		<td>
																				<div class="slot">
																						<p>Pickup : Date</p>
																						<h2>${(carMovementDetail && carMovementDetail.length > 0)
					? (carMovementDetail?.actualToDate)
					: (invoiceDetail?.bookingRequest?.toDate)}</h2>
																				</div>
																		</td>
																</tr>
																<tr>
																		<td colspan="2" style="text-align: center;">
																				<div class="slot bg-white">
																						<p>Name</p>
																						<h1>${invoiceDetail?.bookingRequest?.user?.firstName} ${invoiceDetail?.bookingRequest?.user?.lastName}</h1>
																				</div>
																		</td>
																		<td colspan="2" style="text-align: center;">
																				<div class="slot bg-white">
																						<p>Reservation ID</p>
																						<h1>${carMovementDetail?.reservationId}</h1>
																				</div>
																		</td>

																</tr>


														</table>
												</td>




										<tr>
												<td>
														<table class="bottom-table">

																<tr>
																		<td colspan="2">
																				<h4>Terms & Conditions</h4>
																		</td>
																</tr>
																<tr>
																		<td colspan="2">
																				<p>${policies?.policies}</p>
																		</td>
																</tr>

																<tr>
																		<td>
																				<div class="fix-height"></div>
																		</td>
																</tr>



														</table>
												</td>
										</tr>
										</tr>

								</table>
						</td>
						</tr>

						</table>


				</body>

				</html>
			`;

			const browser = await puppeteer.launch({
				// -------- disable this line while checking in local --------
				executablePath: '/usr/bin/chromium-browser',
				// -------- disable this line while checking in local --------
				headless: true,
				args: ['--no-sandbox', '--disable-setuid-sandbox']
			});

			const page = await browser.newPage();
			await page.setContent(htmlContent, { waitUntil: 'networkidle0' });

			let buffer;
			try {
				buffer = await page.pdf({
					format: 'Letter',
					printBackground: true,
					margin: {
						top: '20px',
						right: '20px',
						bottom: '20px',
						left: '20px'
					}
				});
			} catch (pdfError) {
				console.error("PDF Generation Error:", pdfError);
				await browser.close();
				return res.status(500).json({ message: 'Error generating PDF', error: pdfError.message });
			}

			await browser.close();

			// Create a unique filename using a timestamp
			const uniqueFileName = `invoice_${Date.now()}.pdf`;
			const pdfPath = path.join(__dirname, '../public/uploads/invoice', uniqueFileName);
			// console.log('Current working directory:', process.cwd()); // Log current working directory

			// Ensure the directory exists
			const pdfDirectory = path.dirname(pdfPath);
			if (!fs.existsSync(pdfDirectory)) {
				fs.mkdirSync(pdfDirectory, { recursive: true });
			}

			// Write PDF to file
			try {
				fs.writeFileSync(pdfPath, buffer);
				console.log('PDF saved to:', pdfPath);
			} catch (writeError) {
				console.error("Error writing PDF file:", writeError);
				return res.status(500).json({ message: 'Error saving PDF', error: writeError.message });
			}

			const pdfUrl = `${APPURL}/uploads/invoice/${uniqueFileName}`;
			// src\public\uploads\invoice\invoice_1734515364683.pdf

			// Send the URL in the response
			return res.status(200).json({
				status: true,
				message: "Invoice generated successfully.",
				data: {
					pdfUrl: pdfUrl,
				}
			});

		} else {
			return res.status(400).json({
				status: false,
				message: "No details found. Wrong booking id.",
				data: {},
			});
		}
	});

	static testMail = (async (req, res, next) => {
		// const puppeteer = require("puppeteer");
		// const browser = await puppeteer.launch();
		// const page = await browser.newPage();
		// const template = '';
		// const fileName = 'customer-receipt.pdf';
		// const pdfPath = path.join(__dirname, '../public/attachments', fileName);
		// await page.setContent(template, {waitUntil: 'domcontentloaded'});
		// await page.pdf({
		// 	path: pdfPath,
		// 	printBackground: true,
		// 	format: 'A4',
		// })
		// await browser.close();
		// return res.status(200).json({
		// 	status: true,
		// 	message: "Mail Sent.",
		// 	data: {}
		// });

		// var smtpTransport = mailer.createTransport({
		// 	service: 'gmail',
		// 	auth: { user: 'booking.primepark@gmail.com', pass: 'nygxmeibhurwvekn' }
		// });
		// var toMail = req.query.email ? req.query.email : 'suraj.samanta@gmail.com';
		// var mailContent = {
		// 	from: {
		// 		name: "Prime Park",
		// 		address: "booking.primepark@gmail.com",
		// 	},
		// 	// to: ['sm.developer46@gmail.com', 'suraj.samanta@gmail.com'],
		// 	to: toMail,
		// 	attachments: [
		// 	{
		// 		path: pdfPath,
		// 		filename: fileName, 
		// 		// contentType: 'contentType'
		// 	}],
		// 	subject: 'Test mail',
		// 	text: 'Test mail content',
		// };
		// smtpTransport.sendMail(mailContent, function (error, response) {
		// 	if (error) {
		// 		console.log(error);
		// 		return res.status(200).json({
		// 			status: false,
		// 			message: "Mail Not Sent.",
		// 			data: error
		// 		});
		// 	} else {
		// 		console.log(response.response);
		// 		console.log("---------- Mail sent. ----------");
		// 		return res.status(200).json({
		// 			status: true,
		// 			message: "Mail Sent.",
		// 			data: response.response
		// 		});
		// 	}
		// }); 
		var toMail = req.query.email ? req.query.email : 'suraj.samanta@gmail.com';
		let adminMailContent = `
			<div>
				Dear Prime Park Team, 
				<p>A new booking has been generated which needs your prompt attention. Please find the details of the booking below:</p>

				<strong>Ticket Number:</strong> 7777 <br/>
				<strong>Customer Name:</strong> Test User <br/>
				<strong>Email ID:</strong> test@test.com <br/>
				<strong>Phone Number:</strong> 9876543210 <br/>
				<strong>Parking Lot Name:</strong> Prime Park JFK <br/>
				<strong>Car drop-off date:</strong> 11-03-2025 <br/>
				<strong>Car pick-up date:</strong> 11-03-2025 <br/>
				<strong>Plate Number:</strong> 12345 <br/>
				<strong>Number of passengers:</strong> 4 <br/>
				<strong>Slot Details:</strong> 1 [Bay-no.: 1, Row-no.: 1] <br/>
				<strong>Reservation Amount (Non Refundable): </strong>$25 <br/>
				<strong>Amount to pay On-Site: </strong>$20 <br/>
				<strong>Total Amount: </strong>$45 <br/><br/>

				Please take the necessary action regarding the same.
				<p>
					Thanks & Regards, <br/>
					Prime Park Admin
				</p>
			<div>
		`;
		// let template = `
		// 	<html>
		// 		<head></head>
		// 		<body>
		// 			<table style="border: 1px solid #d9d9d9;background: #fff;width: 100%;margin: 0;padding: 0;">
		// 				<tr>
		// 					<td style="padding:0;">
		// 						<div style="background: #000000;padding: 10px 0;">
		// 							<h5 style="font-size:18px;font-weight:600;line-height:30px;letter-spacing:0.02em;text-align:center;color:#fff;font-family: "Poppins", sans-serif;">Prime Park Receipt</h5>
		// 							<p style="font-size: 13px;font-weight: 400;line-height: 21px;letter-spacing: 0.02em;text-align: center;color: #ffffff;padding: 0 6px;">+1 800-884-0153</p>
		// 							<p style="font-size: 13px;font-weight: 400;line-height: 21px;letter-spacing: 0.02em;text-align: center;color: #ffffff;padding: 0 6px;">15115 Lefferts Blvd, South Ozone Park, NY 11420, United States</p>
		// 						</div>
		// 					</td>
		// 				</tr>
		// 				<tr>
		// 					<td>
		// 						<table style="width:100%; background-color:#efeff0;border-collapse: collapse;border: 0;border-spacing: 0;">
		// 							<tr>
		// 								<td>
		// 									<div style="padding:10px 10px 0;">
		// 										<p>Check In Date & Time</p>
		// 										<h3>24-03-2025</h3>
		// 									</div>
		// 								</td>
		// 								<td>
		// 									<div style="padding:10px 10px 0">
		// 										<p>Check Out Date & Time</p>
		// 										<h3>25-03-2025</h3>
		// 										</div>
		// 									</td>
		// 								</tr>
		// 								<tr>
		// 									<td>
		// 										<div style="padding:0 10px;">
		// 											<p>Name</p>
		// 											<h3>Suraj Samanta</h3>
		// 										</div>
		// 									</td>
		// 									<td>
		// 										<div style="padding:0 10px;">
		// 											<p>Phone number</p>
		// 											<h3>+919876543210</h3>
		// 										</div>
		// 									</td>
		// 								</tr>
		// 								<tr>
		// 								<td>
		// 									<div style="padding:0 10px;">
		// 										<p>Ticket ID</p>
		// 										<h3>TKT-1234567890</h3>
		// 										</div>
		// 									</td>
		// 									<td>
		// 										<div style="padding:0 10px;">
		// 										<p>Slot Number</p>
		// 										<h3>SLOT-1</h3>
		// 									</div>
		// 								</td>
		// 							</tr>
		// 							<tr>
		// 								<td>
		// 									<div style="padding:0 10px;">
		// 										<p>Payment</p>
		// 										<h3>Cash</h3>
		// 									</div>
		// 								</td>
		// 								<td>
		// 									<div style="padding:0 10px;">
		// 										<p>Cash</p>
		// 										<h3>$35.00</h3>
		// 									</div>
		// 								</td>
		// 							</tr>
		// 						</table>
		// 					</td>
		// 				</tr>
		// 				<tr>
		// 					<td>
		// 						<table style="width: 100%; border-collapse: collapse;border: 0;border-spacing: 0;">
		// 							<tr>
		// 								<td>
		// 									<h2 style="font-size: 18px; font-weight: 600;line-height: 22px;text-align: left; padding: 10px;">Billing Details</h2>
		// 								</td>
		// 							</tr>
		// 							<tr style="border-bottom: 1.5px dotted hsla(0, 0%, 0%, 0.41);">
		// 								<td>
		// 									<p style="padding-left: 10px;color: #6b6b6b;white-space: normal;">Onsite amount charges</p>
		// 								</td>
		// 								<td>
		// 									<h5 style="font-weight: 700;font-size: 16px;">$ 0</h5>
		// 								</td>
		// 							</tr>
		// 							<tr style="border-bottom: 1.5px dotted hsla(0, 0%, 0%, 0.41);">
		// 								<td>
		// 									<div className="parking-carge">
		// 										<p style="padding-left: 10px;color: #6b6b6b;white-space: normal;">Parking Charges</p>
		// 										<span style="font-size: 14px;font-style: italic;font-weight: 400;line-height: 22px;text-align: left;color: #5a7aed;padding-left:10px;">(Sedan)</span>
		// 									</div>
		// 								</td>
		// 								<td>
		// 									<h5 style="font-weight: 700;font-size: 16px;">$ 40.00</h5>
		// 								</td>
		// 							</tr>
		// 							<tr style="border-bottom: 1.5px dotted hsla(0, 0%, 0%, 0.41);">
		// 								<td>
		// 									<div className="parking-carge">
		// 										<p style="padding-left: 10px;color: #6b6b6b;white-space: normal;">Overstay charges</p>
		// 										<span style="font-size: 14px;font-style: italic;font-weight: 400;line-height: 22px;text-align: left;color: #5a7aed;padding-left:10px;">(0 days)</span>
		// 									</div>
		// 								</td>
		// 								<td>
		// 									<h5 style="font-weight: 700;font-size: 16px;">$ 0</h5>
		// 								</td>
		// 							</tr>
		// 							<tr style="border-bottom: 1.5px dotted hsla(0, 0%, 0%, 0.41);">
		// 								<td>
		// 									<div className="parking-carge">
		// 										<p style="padding-left: 10px;color: #6b6b6b;white-space: normal;">Early Check In charges</p>
		// 									</div>
		// 								</td>
		// 								<td>
		// 									<h5 style="font-weight: 700;font-size: 16px;">$ 0</h5>
		// 								</td>
		// 							</tr>
		// 							<tr style="border-bottom: 1.5px dotted hsla(0, 0%, 0%, 0.41);">
		// 								<td>
		// 									<div className="parking-carge">
		// 										<p style="padding-left: 10px;color: #6b6b6b;white-space: normal;">Extra Passenger Fees</p>
		// 										<span style="font-size: 14px;font-style: italic;font-weight: 400;line-height: 22px;text-align: left;color: #5a7aed;padding-left:10px;">(4 Passengers)</span>
		// 									</div>
		// 								</td>
		// 								<td>
		// 									<h5 style="font-weight: 700;font-size: 16px;">$ 0</h5>
		// 								</td>
		// 							</tr>
		// 							<tr style="border-bottom: 1.5px dotted hsla(0, 0%, 0%, 0.41);">
		// 								<td>
		// 									<div className="parking-carge">
		// 										<p style="padding-left: 10px;color: #6b6b6b;white-space: normal;">Reservation Fees (Paid)</p>
		// 									</div>
		// 								</td>
		// 								<td>
		// 									<h5 style="font-weight: 700;font-size: 16px;">$ 25.00</h5>
		// 								</td>
		// 							</tr>
		// 						</table>
		// 					</td>
		// 				</tr>
		// 				<tr>
		// 					<td>
		// 						<table style="width: 100%;border-collapse: collapse;border: 0;border-spacing: 0;">
		// 							<tr style="background: #000000;padding: 10px 0;">
		// 								<td style="width:75%;">
		// 									<h5 style="text-align:left; font-size: 19px;font-weight: 600;color: #fff;padding:30px 10px 0;">Total amount to pay at loaction</h5>
		// 								</td>
		// 								<td style="width:25%;font-size: 19px;font-weight: 600;color: #fff;padding:20px 10px 20px;">
		// 									<h5 style="text-align:left;padding:30px 10px 0;">$ 5.00</h5>
		// 								</td>
		// 							</tr>
		// 							<tr>
		// 								<td colSpan="2">
		// 									<h4 style="padding:40px 10px 0;font-size:20px;">Terms & Conditions</h4>
		// 								</td>
		// 							</tr>
		// 							<tr>
		// 								<td colSpan="2">
		// 									<h1 style="padding:10px 10px 0;font-size:30px;">Policies</h1> 
		// 									<div style="padding:0px 10px 40px;">
		// 										<p>1. Your reservation will be subject to Parking hourly and daily rate as soon as the voucher is expired. The hourly rate is 10/hour and the daily rate is $15 for small cars and $18 for SUV/ Trucks per day.</p>
		// 										<p>2.This facility does NOT allow in/out privileges. You CANNOT enter & exit more than once.</p>
		// 										<p>3. For all Cancelled online vouchers/Reservation customers are required to pay for one day of parking and a $10 service fee.</p>
		// 										<p>4. This facility does not allow online reservation extensions. Additional time must be paid on-site at a regular rate.</p>
		// 										<p>5. Customer is required to take pictures of their vehicles (all sides) at the location during drop-off and also agree that no damage claim can be filed without providing those pictures.</p>
		// 										<p>6. Customer must leave the car key to the attendant and agree that failure to do so may result to towing fees from $75 to $150.</p>
		// 										<p>7. Customer agree that all balance must be paid in full prior to retrieval of vehicle.</p>
		// 									</div>
		// 								</td>
		// 							</tr>
		// 						</table>
		// 						<table style="width: 100%;border-collapse: collapse;border: 0;border-spacing: 0;">
		// 							<tr className="Signature">
		// 								<td style="width:60%;"></td>
		// 								<td style="width:40%;">
		// 									<h4>I accept the Terms & Conditions</h4>
		// 								</td>
		// 							</tr>
		// 							<tr className="Signature">
		// 								<td></td>
		// 								<td><h4>Customers Signature</h4></td>
		// 							</tr>
		// 							<tr>
		// 								<td></td>
		// 								<td>...................................................</td>
		// 							</tr>
		// 						</table>
		// 					</td>
		// 				</tr>
		// 			</table>
		// 		</body>
		// 	</html>
		// `;



		/* let bookingRequestId = 142;
		let invoiceDetail = await super.getByCustomOptionsSingle(req, invoiceModel, {
			where: {
				bookingRequestId: bookingRequestId,
			},
			include: [
				{
					model: bookingRequestsModel,
					include: [
						{
							model: slotsModel,
						},
						{
							model: userModel,
							attributes: {
								exclude: [
									"password",
									"webLogin",
									"appLogin",
									"fcmToken",
									"OTP",
									"macAddress",
									"deviceId",
								],
							},
							include: [
								{
									model: roleModel,
								},
							]
						},
						{
							model: vehicleTypesModel,
						},
					]
				}
			]
		});

		let carMovementDetail = await super.getByCustomOptionsSingle(req, carMovementsModel, {
			where: {
				bookingRequestId: bookingRequestId,
			}
		}); 

		let dayCount = 0;
		let dailyCharge = 0;
		if(invoiceDetail){

			let bookingRequestDetail = await super.getByCustomOptionsSingle(req, bookingRequestsModel, {
				where: {
					id: bookingRequestId,
				}
			});
			// Define startDate and endDate in the same time zone
			let startDate = moment.tz(bookingRequestDetail?.fromDate+ " " +bookingRequestDetail?.selectedCheckInTime, timeZone);
			let endDate = moment.tz(bookingRequestDetail?.toDate+ " " +bookingRequestDetail?.selectedCheckOutTime, timeZone);

			// Calculate the difference in total minutes
			let totalMinutes = endDate.diff(startDate, 'minutes');

			// Calculate the full days, rounding up if minutes exceed 15
			// 1440 minutes in a day ---------------
			dayCount = Math.floor(totalMinutes / 1440); 
			// Remaining minutes after full days ---------------
			let remainingMinutes = totalMinutes % 1440; 

			// Check if remaining minutes exceed 15 ---------------
			if (remainingMinutes > 15) {
				// Count an additional day if more than 15 minutes ---------------
				dayCount += 1; 
			}

			let priceChartOfVehicle = await super.getByCustomOptionsSingle(req, priceChartsModel, {
				where: {
					vehicleTypeId: bookingRequestDetail?.vehicleTypeId,
				}
			});

			dailyCharge = priceChartOfVehicle?.dailyParkingRate;

			if(carMovementDetail){
				let startDate = '';
				let endDate = '';

				// Define startDate and endDate in the same time zone
				if(new Date(bookingRequestDetail?.fromDate) >= new Date(carMovementDetail?.actualFromDate)){
					startDate = moment.tz(bookingRequestDetail?.fromDate+ " " +bookingRequestDetail?.selectedCheckInTime, timeZone);
				} else {
					startDate = moment.tz(carMovementDetail?.actualFromDate+ " " +carMovementDetail?.actualCheckInTime, timeZone);
				}

				if(carMovementDetail?.actualToDate){
					endDate = moment.tz(carMovementDetail?.actualToDate+ " " +carMovementDetail?.actualCheckOutTime, timeZone);
				} else {
					endDate = moment.tz(bookingRequestDetail?.toDate+ " " +bookingRequestDetail?.selectedCheckOutTime, timeZone);
				}

				// Calculate the difference in total minutes
				let actualTotalMinutes = endDate.diff(startDate, 'minutes');

				// Calculate the full days, rounding up if minutes exceed 15
				// 1440 minutes in a day ---------------
				dayCount = Math.floor(actualTotalMinutes / 1440); 
				// Remaining minutes after full days ---------------
				let actualRemainingMinutes = actualTotalMinutes % 1440; 

				// Check if remaining minutes exceed 15 ---------------
				if (actualRemainingMinutes > 15) {
					// Count an additional day if more than 15 minutes ---------------
					dayCount += 1; 
				}

				if(carMovementDetail?.vendorId){
					dailyCharge = priceChartOfVehicle?.overSizeRate;
				} else {
					dailyCharge = priceChartOfVehicle?.dailyParkingRate;
				}
			}
		}
		let invoiceDetails = {
			invoiceDetail: invoiceDetail,
			carMovementDetail: carMovementDetail,
			dayCount: dayCount,
			dailyCharge: dailyCharge,
		};
		let policyData = await policiesModel.findOne({
			where: {
				deletedAt: null,
				policies: {
					[Op.ne]: null 
				},
			},
		});
		// console.log(invoiceDetails?.invoiceDetail);
		let htmlTemplate = `
			<html>
				<head>
					<meta charset="utf8">
					<title>Prime Park Receipt</title>
					<style>
						.common-table {
							border: 1px solid hsla(0, 0%, 85%, 1);
							background: #fff;
							margin: 0;
							padding: 0;
							width: 100%;
							display:block;
						}
						.common-table tr td {
							padding: 0;
						}
						.bg-black {
							background: hsla(0, 0%, 0%, 1);
							padding: 10px 0;
						}
						.bg-black h5 {
							font-size: 28px;
							font-weight: 600;
							line-height: 40px;
							letter-spacing: 0.02em;
							text-align: center;
							color: #fff;
							padding: 20px 0 0;
							margin: 0;
						}
						.bg-black p {
							font-size: 13px;
							font-weight: 400;
							line-height: 17px;
							letter-spacing: 0.02em;
							text-align: center;
							color: hsla(0, 0%, 100%, 1);
							padding: 0 6px;
						}
						.body-top {
							background: hsla(240, 3%, 94%, 1);
							width: 100%;
						}
						.body-top h3{
							padding: 0;
							margin: 0;
						}
						.biling-details {
							width: 100%;
						}
						.biling-details h2 {
							font-size: 18px;
							font-weight: 600;
							line-height: 22px;
							text-align: left;
						}
						.biling-details tr {
							border-bottom: 1.5px dotted hsla(0, 0%, 0%, 0.41);
						}
						.bottom-table {
							width: 100%;
						}
						.biling-details tr td,
						.body-top tr td,
						.bottom-table tr td {
							padding: 10px 10px;
						}
						.biling-details td h5 {
							font-weight: 700;
							font-size: 16px;
							padding: 0;
							margin: 0;
						}
						.biling-details tbody tr:last-child {
							border-bottom: 0;
						}
						.biling-details span {
							font-size: 14px;
							font-style: italic;
							font-weight: 400;
							line-height: 22px;
							text-align: left;
							color: hsla(227, 80%, 64%, 1);
						}	
						.bottom-table td h5 {
							font-size: 19px;
							line-height: 22px;
						}	
						.bottom-table tbody tr:last-child td {
							padding-bottom: 40px;
							white-space: normal;
						}	
						.signature h4 {
							font-size: 13px;
							line-height: 17px;
							white-space: normal;
						}
					</style>
				</head>
				<body>
					<div style="width:100%;">
						<table class="common-table">
							<tr>
								<td>
									<div class="bg-black">
										<h5>Prime Park Receipt</h5>
										<p>+1 800-884-0153</p>
										<p>15115 Lefferts Blvd, South Ozone Park, NY 11420, United States</p>
									</div>
								</td>
							</tr>
							<tr>
								<td>
									<table class="body-top">
										<tr>
											<td>
												<div>
													<p>Check In Date & Time</p>
													<h3>${invoiceDetails?.invoiceDetail?.bookingRequest?.fromDate} | ${invoiceDetails?.invoiceDetail?.bookingRequest?.selectedCheckInTime}</h3>
												</div>
											</td>
											<td>
												<div>
													<p>Check Out Date & Time</p>
													<h3>${invoiceDetails?.invoiceDetail?.bookingRequest?.toDate} | ${invoiceDetails?.invoiceDetail?.bookingRequest?.selectedCheckOutTime}</h3>
												</div>
											</td>
										</tr>
										<tr>
											<td>
												<div>
													<p>Name</p>
													<h3>${invoiceDetails?.invoiceDetail?.bookingRequest?.user?.firstName} ${invoiceDetails?.invoiceDetail?.bookingRequest?.user?.lastName}</h3>
												</div>
											</td>
											<td>
												<div>
													<p>Phone number</p>
													<h3>${invoiceDetails?.invoiceDetail?.bookingRequest?.user?.phone}</h3>
												</div>
											</td>
										</tr>
										<tr>
											<td>
												<div>
													<p>Ticket ID</p>
													<h3>${invoiceDetails?.invoiceDetail?.bookingRequest?.bookingTicketNo}</h3>
												</div>
											</td>
											<td>
												<div>
													<p>Slot Number</p>
													<h3>${invoiceDetails?.invoiceDetail?.bookingRequest?.slot?.slotName}</h3>
												</div>
											</td>
										</tr>
										<tr>
											<td>
												<div>
													<p>Payment</p>
													<h3>Cash</h3>
												</div>
											</td>
											<td>
												<div>
													<p>Cash</p>
													<h3>$ ${invoiceDetails?.invoiceDetail?.payableAmount}</h3>
												</div>
											</td>
										</tr>

									</table>
								</td>
							</tr>
							<tr>
								<td>
									<table class="biling-details">
										<tr>
											<td>
												<h2>Billing Details</h2>
											</td>
										</tr>
										<tr>
											<td>
												<p>Onsite amount charges</p>
											</td>
											<td>
												<h5>$ ${invoiceDetails?.invoiceDetail?.onSiteChargeForVendor}</h5>
											</td>
										</tr>
										<tr>
											<td>
												<div>
													<p>Parking Charges</p>
													<span>(${invoiceDetails?.invoiceDetail?.bookingRequest?.vehicleType?.typeName})</span>

												</div>
											</td>
											<td>
												<h5>$ ${invoiceDetails?.invoiceDetail?.parkingChargeTotal}</h5>
											</td>
										</tr>
										<tr>
											<td>
												<div>
													<p>Overstay charges</p>
													<span>(${invoiceDetails?.invoiceDetail?.overstayDays} days)</span>
												</div>
											</td>
											<td>
												<h5>$ ${invoiceDetails?.invoiceDetail?.overstayAmountTotal}</h5>
											</td>
										</tr>
										<tr>
											<td>
												<div>
													<p>Early Check In charges</p>
												</div>
											</td>
											<td>
												<h5>$ ${invoiceDetails?.invoiceDetail?.earlyCheckinAmountTotal}</h5>
											</td>
										</tr>
										<tr>
											<td>
												<div>
													<p>Extra Passenger Fees</p>
													<span>(${invoiceDetails?.invoiceDetail?.extraPassengers} Passengers)</span>
												</div>
											</td>
											<td>
												<h5>$ ${invoiceDetails?.invoiceDetail?.extraPassengerChargesTotal}</h5>
											</td>
										</tr>
										<tr>
											<td>
												<div>
													<p>Reservation Fees (Paid)</p>
												</div>
											</td>
											<td>
												<h5>$ ${invoiceDetails?.invoiceDetail?.reservationAmount}</h5>
											</td>
										</tr>

									</table>
								</td>
							</tr>
							<tr>
								<td>
									<table class="bottom-table">
										<tr class="bg-black">
											<td style="width:75%;">
												<h5 style="text-align:left;padding-bottom:20px;">Total amount to pay at loaction</h5>
											</td>
											<td style="width:25%;">
												<h5 style="text-align:left; margin-left: 25px;padding-bottom:20px;">$ ${invoiceDetails?.invoiceDetail?.dueAmount}</h5>
											</td>
										</tr>
										<tr>
											<td colSpan="2">
												<h4 style="padding-top:30px;">Terms & Conditions</h4>
											</td>
										</tr>
										<tr>
											<td colSpan="2">
												${policyData.policies}
											</td>
										</tr>
									</table>
									<table style="width: 100%;border-collapse: collapse;border: 0;border-spacing: 0;">
										<tr class="signature">
											<td style="width:60%;"></td>
											<td style="width:40%;">
												<h4>I accept the Terms & Conditions</h4>
											</td>
										</tr>
										<tr class="signature">
											<td></td>
											<td><h4>Customers Signature</h4></td>
										</tr>
										<tr>
											<td></td>
											<td>...................................................</td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
					</div>
				</body>
			</html>
		`;

		var pdf = require('html-pdf');
		let isSentMail = false;
		// pdf.create(template).toBuffer(function(err, buffer){
		// 	isSentMail = sendMail(toMail, `Booking confirmed! Ticket No: 7777`, adminMailContent, buffer);
		// });

		var options = { 
			format: 'Letter',
			childProcessOptions: {
				env: {
				  OPENSSL_CONF: '/dev/null',
				},
			}
		};
		const pdfPath = path.join(__dirname, '../public/attachments', 'admin-receipt.pdf');
		pdf.create(htmlTemplate, options).toFile(pdfPath, function(err, res) {
			if (err) return console.log(err);
			console.log(res); // { filename: '/app/businesscard.pdf' }
			// isSentMail = sendMail(toMail, `Booking confirmed! Ticket No: 1234`, adminMailContent, pdfPath);
		}); */

		let templateBody = this.invoiceReceipt(true);
		templateBody += `<div style="page-break-before:always">&nbsp;</div>` + this.invoiceReceipt(false);
		let htmlTemplate = `
			<html>
				<head>
					<meta charset="utf8">
					<title>Prime Park Receipt</title>
					<style>
						.common-table {
							border: 1px solid hsla(0, 0%, 85%, 1);
							background: #fff;
							margin: 0;
							padding: 0;
							width: 100%;
							display:block;
						}
						.common-table tr td {
							padding: 0;
						}
						.bg-black {
							background: hsla(0, 0%, 0%, 1);
							padding: 10px 0;
						}
						.bg-black h5 {
							font-size: 28px;
							font-weight: 600;
							line-height: 40px;
							letter-spacing: 0.02em;
							text-align: center;
							color: #fff;
							padding: 20px 0 0;
							margin: 0;
						}
						.bg-black p {
							font-size: 13px;
							font-weight: 400;
							line-height: 17px;
							letter-spacing: 0.02em;
							text-align: center;
							color: hsla(0, 0%, 100%, 1);
							padding: 0 6px;
						}
						.body-top {
							background: hsla(240, 3%, 94%, 1);
							width: 100%;
						}
						.body-top h3{
							padding: 0;
							margin: 0;
						}
						.biling-details {
							width: 100%;
						}
						.biling-details h2 {
							font-size: 18px;
							font-weight: 600;
							line-height: 22px;
							text-align: left;
						}
						.biling-details tr {
							border-bottom: 1.5px dotted hsla(0, 0%, 0%, 0.41);
						}
						.bottom-table {
							width: 100%;
						}
						.biling-details tr td,
						.body-top tr td,
						.bottom-table tr td {
							padding: 10px 10px;
						}
						.biling-details td h5 {
							font-weight: 700;
							font-size: 16px;
							padding: 0;
							margin: 0;
						}
						.biling-details tbody tr:last-child {
							border-bottom: 0;
						}
						.biling-details span {
							font-size: 14px;
							font-style: italic;
							font-weight: 400;
							line-height: 22px;
							text-align: left;
							color: hsla(227, 80%, 64%, 1);
						}	
						.bottom-table td h5 {
							font-size: 19px;
							line-height: 22px;
						}	
						.bottom-table tbody tr:last-child td {
							padding-bottom: 40px;
							white-space: normal;
						}	
						.signature h4 {
							font-size: 13px;
							line-height: 17px;
							white-space: normal;
						}
					</style>
				</head>
				<body>
					${templateBody}
				</body>
			</html>
		`;

		var pdf = require('html-pdf');
		var options = {
			format: 'Letter',
			childProcessOptions: {
				env: {
					OPENSSL_CONF: '/dev/null',
				},
			}
		};
		let fileName = 'customer-receipt.pdf';
		const pdfPath = path.join(__dirname, '../public/attachments', fileName);
		pdf.create(htmlTemplate, options).toFile(pdfPath, function (err, res) {
			if (err) return console.log(err);
			// console.log(res);
			// return res.filename ? 1 : 0;
		});


		// console.log(customerReceipt);

		// const puppeteer = require("puppeteer");
		// const browser = await puppeteer.launch();
		// const page = await browser.newPage();
		// const pdfPath = path.join(__dirname, '../public/attachments', 'customer-receipt.pdf');
		// await page.setContent(template, {waitUntil: 'domcontentloaded'});
		// await page.pdf({
		// 	path: pdfPath,
		// 	printBackground: true,
		// 	format: 'A4',
		// })
		// await browser.close()
		// let isSentMail = sendMail(toMail, `Booking confirmed! Ticket No: 7777`, adminMailContent, pdfPath);
		return res.status(200).json({
			status: true,
			message: "Mail Sent.",
			data: null
		});

	});
	static invoiceReceipt = ((
		signature = true,
		toDate,
		fromDate,
		selectedCheckInTime,
		selectedCheckOutTime,
		firstName,
		lastName,
		phone,
		bookingTicketNo,
		slotName,
		payableAmount,
		onSiteChargeForVendor,
		vehicleName,
		parkingChargeTotal,
		overstayAmountTotal,
		earlyCheckinAmount,
		extraPassengers,
		onlineBookAmount,
		extraPassengerChargesTotal,
		paidAmount,
		dueAmount,
		policie,
	) => {
		let templateBody = `
			<div style="width:100%;">
				<table class="common-table">
					<tr>
						<td>
							<div class="bg-black">
								<h5>Prime Park Receipt</h5>
								<p>+1 800-884-0153</p>
								<p>15115 Lefferts Blvd, South Ozone Park, NY 11420, United States</p>
							</div>
						</td>
					</tr>
					<tr>
						<td>
							<table class="body-top">
								<tr>
									<td>
										<div>
											<p>Check In Date & Time</p>
											<h3>${fromDate + ' | ' + selectedCheckInTime}</h3>
										</div>
									</td>
									<td>
										<div>
											<p>Check Out Date & Time</p>
											<h3>${toDate + ' | ' + selectedCheckOutTime}</h3>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<div>
											<p>Name</p>
											<h3>${firstName + ' ' + lastName}</h3>
										</div>
									</td>
									<td>
										<div>
											<p>Phone number</p>
											<h3>${phone}</h3>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<div>
											<p>Ticket ID</p>
											<h3>${bookingTicketNo}</h3>
										</div>
									</td>
									<td>
										<div>
											<p>Slot Number</p>
											<h3>${slotName}</h3>
										</div>
									</td>
								</tr>

							</table>
						</td>
					</tr>
					<tr>
						<td>
							<table class="biling-details">
									<tr>
										<td>
										<h2>Billing Details</h2>
										</td>
									</tr>
									<tr>
										<td>
										<p>Onsite amount charges</p>
										</td>
										<td>
										<h5>$ ${onSiteChargeForVendor}</h5>
										</td>
									</tr>
									<tr>
										<td>
										<div>
											<p>Online Booking Charges</p>
										</div>
										</td>
										<td>
										<h5>$ ${onlineBookAmount}</h5>
										</td>
									</tr>
									<tr>
										<td>
										<div>
											<p>Total Booking Charges</p>
										</div>
										</td>
										<td>
										<h5>$ ${payableAmount - onSiteChargeForVendor - onlineBookAmount}</h5>
										</td>
									</tr>
									<tr>
										<td colspan="2">
										<ul style="margin-left: 20px;">
											<li>
											Parking Charges <span>(${vehicleName})</span> : $ ${parkingChargeTotal}
											</li>
											<li>
											Overstay charges : $ ${overstayAmountTotal}
											</li>
											<li>
											Early Check-in charges : $ ${earlyCheckinAmount}
											</li>
											<li>
											Extra Passenger Fees <span>(${extraPassengers} Passengers)</span> : $ ${extraPassengerChargesTotal}
											</li>
										</ul>
										</td>
									</tr>
								</table>
						</td>
					</tr>
					<tr>
						<td>
							<hr style="border: 1px solid black; margin: 5px 0;">
							<table style="width: 100%; border-collapse: collapse; margin-left: 20px; font-size: 12px;">
									<tr>
										<td style="width: 61%;">
											<h4 style="text-align: left; font-size: 18px;">Total Amount to Be Pay</h4>
										</td>
										<td style="width: 39%;">
											<h4 style="text-align: left; font-size: 18px;">$ ${dueAmount + paidAmount}</h4>
										</td>
									</tr>
									<tr>
										<td style="width: 61%;">
											<h4 style="text-align: left; font-size: 18px;">Total Paid Amount During Booking</h4>
										</td>
										<td style="width: 39%;">
											<h4 style="text-align: left; font-size: 18px;">$ ${paidAmount}</h4>
										</td>
									</tr>
							</table>
							<table style="background-color: #000000;color:rgb(252, 248, 248); width: 100%; border-collapse: collapse; font-size: 12px;">
									<tr>
										<td style="width: 61%;">
											<h4 style="text-align: left; margin-top: 18px; font-size: 18px;margin-left: 20px;">Total Due Amount</h4>
										</td>
										<td style="width: 39%;">
											<h4 style="text-align: left; margin-top: 18px; font-size: 18px;margin-left: 20px;">$ ${dueAmount}</h4>
										</td>
									</tr>
							</table>

						<table class="bottom-table">
							<tr>
								<td colSpan="2">
									<h1 id="terms-title" style="padding-top:30px;">Terms & Conditions</h1>
								</td>
							</tr>
							<tr>
								<td colSpan="2">
									${policie}
								</td>
							</tr>
						</table>
		`;
		if (signature) {
			templateBody += `
							<table style="width: 100%;border-collapse: collapse;border: 0;border-spacing: 0;">
								<tr class="signature">
									<td style="width:75%;"></td>
									<td style="width:25%;">
										<h4>I accept the Terms & Conditions</h4>
									</td>
								</tr>
								<tr class="signature">
									<td></td>
									<td><h4>Customers Signature</h4></td>
								</tr>
								<tr>
									<td></td>
									<td>...................................................</td>
								</tr>
							</table>
			`;
		}
		templateBody += `
						</td>
					</tr>
				</table>
			</div>
		`;
		return templateBody;

	});
}

module.exports = BookingController;
