module.exports = (sequelize, DataTypes) => {
  const transactionLogSchema = sequelize.define("transactionlogs", {
    transactionId: {
      type: DataTypes.INTEGER,
      references: {
        model: "transactions",
        key: "id",
      },
      allowNull: false,
    },

    request: { type: DataTypes.TEXT('long'), defaultValue: null },
    response: { type: DataTypes.TEXT('long'), defaultValue: null },

    createdAt: {
      field: "created_at",
      type: DataTypes.DATE,
    },
    updatedAt: {
      field: "updated_at",
      type: DataTypes.DATE,
    },

    deletedAt: {
      field: "deleted_at",
      type: DataTypes.DATE,
    },
  });
  return transactionLogSchema;
};
