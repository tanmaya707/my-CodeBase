module.exports = (sequelize, DataTypes) => {
  const bookingRequestSchema = sequelize.define("bookingrequests", {
    // ============= userId of customer =============
    customerId: { type: DataTypes.INTEGER, allowNull: false },
    // ============= userId of customer =============
    
    // ============= to be auto-assigned through alogrithm =============
    // ============= slotId =============
    slotId: { type: DataTypes.INTEGER, allowNull: false },
    // ============= slotId =============
    // ============= to be auto-assigned through alogrithm =============

    vehicleTypeId: { type: DataTypes.INTEGER, allowNull: false },
    passengerCount: { type: DataTypes.INTEGER, allowNull: false },

    transactionHistoryId: { type: DataTypes.INTEGER, allowNull: true, defaultValue: null },

    // customerName: { type: DataTypes.STRING, allowNull: false },
    customerMobile: { type: DataTypes.BIGINT, allowNull: false },
    plateNumber: { type: DataTypes.STRING, allowNull: false },

    // ============= duration =============
    fromDate: { type: DataTypes.DATEONLY, allowNull: false },
    selectedCheckInTime: { type: DataTypes.TIME, allowNull: false },
    
    toDate: { type: DataTypes.DATEONLY, allowNull: false },
    selectedCheckOutTime: { type: DataTypes.TIME, allowNull: false },
    // ============= duration =============

    bookingStatus: { type: DataTypes.ENUM("Booked", "Checked In", "Checked Out", "Failed"), allowNull: false, defaultValue: "Booked" },
    // ============= auto-generated ticket =============
    bookingTicketNo: { type: DataTypes.STRING, allowNull: true },
    // ============= auto-generated ticket =============

    paymentType: { type: DataTypes.STRING, allowNull: true, },
    paymentStatus: { type: DataTypes.ENUM("Due", "Booking Charges Paid", "Fully Paid", "Full Due",  "Onsite Charges Due", "Payment Failed"), allowNull: false, defaultValue: "Due" },

    readyStatus: { type: DataTypes.ENUM("Not Requested", "Requested", "Ready", "Not Ready"), allowNull: false, defaultValue: "Not Requested" },

    isCancelled: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false, // true for "Cancelled", false for "Not Cancelled"
      comment: "false-Not Cancelled, true-Cancelled",
    },
    cancellationReason: { type: DataTypes.STRING, allowNull: true },

    isActive: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true, // true for Active, false for Inactive
      comment: "false-Inactive, true-Active",
    },

    isEmitted: { type: DataTypes.BOOLEAN, allowNull: true, defaultValue: false},

    deleted_by: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    deletedAt: {
      field: "deleted_at",
      type: DataTypes.DATE,
    },

    // ----- to check if it is a new booking that socket is yet to detect -----
    isEmitted: { type: DataTypes.BOOLEAN, allowNull: true, defaultValue: false},
    // ----- to check if it is a new booking that socket is yet to detect -----
  });

  return bookingRequestSchema;
};
