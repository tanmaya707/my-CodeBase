module.exports = (sequelize, DataTypes) => {
  const modulePermissionsSchema = sequelize.define("modulepermissions", {
    userId: {
      type: DataTypes.INTEGER,
      references: {
        model: 'users',
        key: 'id'
      },
      allowNull: false,
      primaryKey: true, // Part of the composite primary key
    },
    moduleId: {
      type: DataTypes.INTEGER,
      references: {
        model: 'modules',
        key: 'id'
      },
      allowNull: false,
      primaryKey: true, // Part of the composite primary key
    },

    createdAt: {
      field: "created_at",
      type: DataTypes.DATE,
    },
    updatedAt: {
      field: "updated_at",
      type: DataTypes.DATE,
    },

    deletedAt: {
      field: "deleted_at",
      type: DataTypes.DATE,
    },
  });

  return modulePermissionsSchema;

  /* 
  ---------------------------------------------------------------------------
  ----------------------------- Example Queries -----------------------------
  ---------------------------------------------------------------------------
  1. To get all modules for a user:
  -----------------------------------
  const userWithModules = await db.Users.findByPk(userId, {
    include: db.Modules
  });

  2. To get all users for a module:
  -----------------------------------
  const moduleWithUsers = await db.Modules.findByPk(moduleId, {
    include: db.Users
  });
  ---------------------------------------------------------------------------
  ----------------------------- Example Queries -----------------------------
  ---------------------------------------------------------------------------
  */
};
