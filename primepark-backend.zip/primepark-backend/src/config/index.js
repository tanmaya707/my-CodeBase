// require("dotenv").config();

const HTTP = {
  port: process.env.APP_ENV == "production" ? process.env.PORT : 4041,
};
const APPNAME = {
  port:
    process.env.APP_ENV == "production"
      ? process.env.APP_NAME
      : "PRIMEPARKBACKEND",
};
const APPURL =
  process.env.APP_ENV == "production"
    ? process.env.API_URL
    : "http://localhost:4041";

const Mongo = {
  path:
    process.env.APP_ENV == "production" ? process.env.MONGO_DB_HOST : "0.0.0.0",
  user: process.env.APP_ENV == "production" ? process.env.MONGO_DB_USER : "",
  pwd: process.env.APP_ENV == "production" ? process.env.MONGO_DB_PASSWORD : "",
  port: process.env.APP_ENV == "production" ? process.env.MONGO_DB_PORT : 27017,
  dbName:
    process.env.APP_ENV == "production"
      ? process.env.MONGO_DB_NAME
      : "PrimeParkUSA",
};
const Mysql = {
  host:
    process.env.APP_ENV == "production"
      ? process.env.MYSQL_DB_HOST
      : "localhost",
  user:
    process.env.APP_ENV == "production" ? process.env.MYSQL_DB_USER : "root",
  pwd: process.env.APP_ENV == "production" ? process.env.MYSQL_DB_PASSWORD : "",
  dialect:
    process.env.APP_ENV == "production"
      ? process.env.MYSQL_DB_DIALECT
      : "mysql",
  dbName: process.env.MYSQL_DB_NAME,
  debug: process.env.APP_ENV == "production" ? false : false,
};

let Mail = {
  auth: {
    user:
      process.env.APP_ENV == "production"
        ? process.env.SMTP_USER
        : "apikey",
    pass:
      process.env.APP_ENV == "production"
        ? process.env.SMTP_PASSWORD
        : "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",
  },
  host:
    process.env.APP_ENV == "production"
      ? process.env.SMTP_HOST
      : "smtp.sendgrid.net",
  port: process.env.APP_ENV == "production" ? process.env.SMTP_PORT : 587,
  fromName:
    process.env.APP_ENV == "production" ? process.env.FROM_NAME : "Prime Park",
  fromMail:
    process.env.APP_ENV == "production"
      ? process.env.FROM_EMAIL
      : "no-reply@primeparkusa.com",
};

let JWT = {
  secret:
    process.env.APP_ENV == "production"
      ? process.env.JWT_SECRET
      : "some-silly-secret-access-token-shit",
  options: {
    expiresIn: 60 * 60 * 24 * 30,
  },
  refresh: {
    secret:
      process.env.APP_ENV == "production"
        ? process.env.JWT_REFRESH_SECRET
        : "some-silly-secret-refresh-token-shit",
    options: {
      expiresIn: 60 * 60 * 24 * 30,
    },
  },
};

// const Timezone = (process.env.APP_ENV == "production")? process.env.PROD_TZ : process.env.DEV_TZ;
const Timezone = (process.env.APP_ENV == "production")? process.env.DEV_TZ : process.env.DEV_TZ;

const GoogleApiKey = process.env.GOOGLE_API_KEY;

module.exports = {
  HTTP,
  APPNAME,
  APPURL,
  Mongo,
  Mysql,
	Mail,
  JWT,
  Timezone,
  GoogleApiKey,
};
