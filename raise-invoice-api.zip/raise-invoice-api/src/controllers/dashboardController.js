const BaseController = require("../controllers/BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const db = require("../models");
const clientModel = db.Clients;
const userCompanyModel = db.UserCompanies;
const planModel = db.Plans;
const mysqlConfig = require("../config/index").Mysql;
const { connectSpecificToDatabase } = require("../config/specificConnect");

class dashboardController extends BaseController {
    constructor() {
        super();
    }

    static dashboard = catchAsyncErrors(async (req, res, next) => {
        const userId = req.user.id;

        // Fetch user
        const user = await clientModel.findOne({
            attributes: [
                'id', 'uuid', 'account_id', 'name', 'phone', 'email', 'password',
                'isVerified', 'database_name', 'dialCode', 'phone', 'profileImage'
            ],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({
                status: false,
                message: "Client not found!",
                data: null,
            });
        }

        // Fetch userCompany only if database_name exists
        let userCompany = null;
        if (user.database_name) {
            userCompany = await userCompanyModel.findOne({
                where: { userId }
            });
        }

        // If no database, return user data only
        if (!user.database_name) {
            const { password, ...userData } = user.get({ plain: true });
            return res.status(200).json({
                status: true,
                message: "Client found!",
                data: { ...userData, userCompany }
            });
        }

        // Connect to specific database
        const connection = await connectSpecificToDatabase(
            user.database_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        // Fetch all data in parallel
        const [
            clientAdmin,
            clientCreation,
            invoiceCreation,
            companyLanguageDetails,
            companyTaxDetails,
            invoiceSetting,
            invoiceOptionSetting
        ] = await Promise.all([
            connection.ClientAdmin.findOne({ where: { email: user.email } }),
            connection.Client.findOne({}),
            connection.Invoice.findOne({}),
            connection.UserLanguage.findOne({ where: { userId } }),
            connection.CompanyTaxSecurity.findOne({ where: { userId } }),
            connection.InvoiceSetting.findOne({ where: { client_admin_id: req.user.id } }),
            connection.InvoiceOptionSetting.findOne({ where: { client_admin_id: req.user.id } })
        ]);

        // Invoice sent/unsent stats
        let totalSentAmount = 0;
        let totalUnsentAmount = 0;
        let thisMonthSentAmount = 0;
        let thisMonthUnsentAmount = 0;
        let totalPaidAmount = 0;
        let thisMonthPaidAmount = 0;
        let thisMonthOverDueAmount = 0;
        let totalOverDueAmount = 0;

        if (connection.Invoice) {
            // Get all invoices for this user/company
            const allInvoices = await connection.Invoice.findAll();

            const now = new Date();
            const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
            const monthEnd = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999);

            allInvoices.forEach(inv => {
                const sentStatus = inv.sentStatus;
                const amount = Number(inv.total || 0);
                const createdAt = inv.createdAt ? new Date(inv.createdAt) : null;
                const dueDate = inv.dueDate ? new Date(inv.dueDate) : null;

                if (sentStatus === 'sent') {
                    totalSentAmount += amount;
                    if (createdAt && createdAt >= monthStart && createdAt <= monthEnd) {
                        thisMonthSentAmount += amount;
                    }
                } else {
                    totalUnsentAmount += amount;
                    if (createdAt && createdAt >= monthStart && createdAt <= monthEnd) {
                        thisMonthUnsentAmount += amount;
                    }
                }

                if (inv.paymentStatus === 'paid') {
                    totalPaidAmount += amount;
                    if (createdAt && createdAt >= monthStart && createdAt <= monthEnd) {
                        thisMonthPaidAmount += amount;
                    }
                }

                // Calculate overdue amount
                if (
                    // sentStatus === 'sent' &&
                    // inv.paymentStatus !== 'paid' &&
                    dueDate &&
                    dueDate.setHours(0,0,0,0) < now.setHours(0,0,0,0)
                ) {
                    totalOverDueAmount += amount;
                    if (createdAt && createdAt >= monthStart && createdAt <= monthEnd) {
                        thisMonthOverDueAmount += amount;
                    }
                }
            });
        }

        let userSubscription = null;
        let plan = null;
        let daysLeft = null;
        let planType = null;

        if (clientAdmin) {
            const subscription = await connection.Subscription.findOne({
                where: { userId: clientAdmin.id }
            });

            if (subscription) {
                plan = await planModel.findOne({
                    where: { id: subscription.subscriptionId },
                    attributes: ['id', 'uuid', 'name']
                });

                const endDate = new Date(subscription.endDate);
                const currentDate = new Date();
                daysLeft = Math.ceil((endDate - currentDate) / (1000 * 60 * 60 * 24));
                planType = subscription.planType;
                userSubscription = true;
            }
        }

        const { password, ...userData } = user.get({ plain: true });

        return res.status(200).json({
            status: true,
            message: "Client found!",
            data: {
                ...userData,
                isSubscribed: !!userSubscription,
                planDetails: plan,
                planType,
                dayLeft: daysLeft,
                companyLanguageDetails,
                userCompany,
                companyTaxDetails,
                isSecurity: false,
                clientCreation: !!clientCreation,
                invoiceCreation: !!invoiceCreation,
                InvoiceSetting: invoiceSetting,
                InvoiceOptionSetting: invoiceOptionSetting,
                invoiceStats: {
                    totalSentAmount,
                    totalUnsentAmount,
                    totalAmount: totalSentAmount + totalUnsentAmount,
                    thisMonthSentAmount,
                    thisMonthUnsentAmount,
                    thisMonthTotalAmount: thisMonthSentAmount + thisMonthUnsentAmount,
                    totalPaidAmount,
                    thisMonthPaidAmount,
                    totalOverDueAmount,
                    thisMonthOverDueAmount
                }
            }
        });
    });
}

module.exports = dashboardController;
