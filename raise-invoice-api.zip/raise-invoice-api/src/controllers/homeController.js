const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");

const db = require("../models");
const MasterLanguageModel = db.LanguageModel;
const currencyModel = db.Currency;
const exchangeRateModel = db.ExchangeRate;
const { Sequelize, Op } = require("sequelize");
const crypto = require("crypto");

class homeController extends BaseController {
  constructor() {
    super();
  }

  static getLanguageList = catchAsyncErrors(async (req, res, next) => {
    let { searchText, status, page = 1, limit = 5 } = req.body;
    let whereClause = {
      // status: true,
      deletedAt: null,
    };
    if (searchText) {
      whereClause[Op.or] = [
        {
          id:
          {
            [Op.like]: `%${searchText}%`
          }
        },
        {
          language:
          {
            [Op.like]: `%${searchText}%`
          }
        },
        {
          lang_code:
          {
            [Op.like]: `%${searchText}%`
          }
        }
      ];
    }
    if(status && status != ''){
      whereClause.status = status;
    }
    let options = {
      where: whereClause,
      order: [['language', 'ASC']],
      // order: [['isDefault', 'DESC'], ['status', 'DESC'], ['language', 'ASC']],
      limit: limit,
      offset: (page - 1) * limit
    };

    let languageLists = await super.getList(req, MasterLanguageModel, options);
    const totalCount = await MasterLanguageModel.count({ where: whereClause });

    if (languageLists.length > 0) {
      return res.status(200).json({
        status: true,
        message: "Data found.",
        data: languageLists,
        totalPages: Math.ceil(totalCount / limit),
        totalCount: totalCount,
        currentPage: page
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No data found.",
        data: [],
        totalPages: 0,
        totalCount: 0,
        currentPage: page

      });
    }
  });
  static saveLanguage = catchAsyncErrors(async (req, res, next) => {
    let { id, language, lang_code, status } = req.body;

    let updateFields = {
      language: language,
      lang_code: lang_code,
      status: status
    };
    let updated = null;
    if (id && id != "" && id != null) {
      updated = await super.updateById(MasterLanguageModel, id, updateFields)
    } else {
      updateFields.uuid = crypto.randomUUID();
      updated = await super.create(res, MasterLanguageModel, updateFields);
    }
    let msg = "";
    if (updated) {
      msg = (id && id != "" && id != null) ? "Language updated successfully." : "Language added successfully.";
    } else {
      msg = "Language addition failed.";
    }

    if (updated) {
      return res.status(200).json({
        status: true,
        message: msg,
        data: updated,
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Oops.. Something wrong happened!",
        data: {},
      });
    }
  });
  static getLanguageDetails = catchAsyncErrors(async (req, res, next) => {
    const { id, uuid, isDefault } = req.body;
    let queryConditions = {
      deletedAt: null,
      status: true,
    };

    if (id) {
      queryConditions.id = id
    }
    if (uuid) {
      queryConditions.uuid = uuid
    }
    if (isDefault) {
      queryConditions.isDefault = isDefault
    }

    let languageDetails = await super.getByCustomOptionsSingle(req, MasterLanguageModel, {
      where: queryConditions,
    });

    if (languageDetails) {
      return res.status(200).json({
        status: true,
        message: "Success",
        data: languageDetails
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No records found.",
        data: {}
      });
    }
  });
  static deleteLanguage = catchAsyncErrors(async (req, res, next) => {
    let { uuid } = req.body;

    let languageDetail = await super.getByCustomOptionsSingle(req, MasterLanguageModel, {
      where: {
        uuid: uuid
      },
      attributes: ["id"],
    });

    if (!languageDetail) {
      return res.status(403).json({
        status: false,
        message: "Language not found!",
        data: {},
      });
    }
    let deleted = await super.deleteByCondition(
      MasterLanguageModel,
      {
        id: languageDetail.id,
      }
    );

    if (deleted) {
      return res.status(200).json({
        status: true,
        message: "Language successfully deleted.",
        data: {}
      });
    } else {
      return res.status(500).json({
        status: false,
        message: "Oops.. something went terribly wrong!",
        data: {}
      });
    }
  });
  static setDefaultLanguage = catchAsyncErrors(async (req, res, next) => {
    let { id } = req.body;
    let updatePrev = await super.updateByCustomOptions(MasterLanguageModel, {isDefault: 1}, {isDefault: 0});
    let updated = null;
    if (updatePrev) {
      updated = await super.updateById(MasterLanguageModel, id, {isDefault: 1})
    }
    let msg = "";
    if (updated) {
      msg = "Default language updated successfully.";
    } else {
      msg = "Default language updation failed.";
    }
    return res.status(200).json({
      status: true,
      message: msg,
    });
  });
  static getCurrencyList = catchAsyncErrors(async (req, res, next) => {
    let { searchText, status, page = 1, limit = 0 } = req.body;
    let whereClause = {
      // status: true,
      deletedAt: null,
    };
    if (searchText) {
      whereClause[Op.or] = [
        {
          id:
          {
            [Op.like]: `%${searchText}%`
          }
        },
        {
          currency_name:
          {
            [Op.like]: `%${searchText}%`
          }
        },
        {
          currency_code:
          {
            [Op.like]: `%${searchText}%`
          }
        },
        {
          symbol:
          {
            [Op.like]: `%${searchText}%`
          }
        }
      ];
    }
    if(status && status != ''){
      whereClause.status = status;
    }
    let options = {
      attributes: [
        "id",
        "currency_name",
        "currency_code",
        "symbol",
        "status",
        "isDefault",
        ["currency_code", "value"], 
        [
          Sequelize.fn('CONCAT',
            Sequelize.col('currency_code'), ' - ',
            Sequelize.col('currency_name')
          ),
          'label'
        ]
      ],
      where: whereClause,
      order: [['currency_name', 'ASC']],
      include: [
        {
          model: exchangeRateModel, 
          required:false
        },
      ],
      // order: [['isDefault', 'DESC'], ['status', 'DESC'], ['currency_name', 'ASC']],
      // limit: limit,
      // offset: (page - 1) * limit
    };

    if(limit){
      options.limit = limit;
      options.offset = (page - 1) * limit;
    }

    let currencyList = await super.getList(req, currencyModel, options);
    const totalCount = await currencyModel.count({ where: whereClause });

    if (currencyList.length > 0) {
      return res.status(200).json({
        status: true,
        message: "Data found.",
        data: currencyList,
        totalPages: limit ? Math.ceil(totalCount / limit) : 0,
        totalCount: totalCount,
        currentPage: page
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No data found.",
        data: [],
        totalPages: 0,
        totalCount: 0,
        currentPage: page

      });
    }
  });
  static saveCurrency = catchAsyncErrors(async (req, res, next) => {
    let { id, status } = req.body;

    let updateFields = {
      status: status
    };
    let updated = null;
    if (id && id != "" && id != null) {
      updated = await super.updateById(currencyModel, id, updateFields)
    } else {
      updateFields.uuid = crypto.randomUUID();
      updated = await super.create(res, currencyModel, updateFields);
    }
    let msg = "";
    if (updated) {
      msg = (id && id != "" && id != null) ? "Currency updated successfully." : "Currency added successfully.";
    } else {
      msg = "Currency addition failed.";
    }

    if (updated) {
      return res.status(200).json({
        status: true,
        message: msg,
        data: updated,
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Oops.. Something wrong happened!",
        data: {},
      });
    }
  });
  static setDefaultCurrency = catchAsyncErrors(async (req, res, next) => {
    let { id } = req.body;
    let updatePrev = await super.updateByCustomOptions(currencyModel, {isDefault: 1}, {isDefault: 0});
    let updated = null;
    if (updatePrev) {
      updated = await super.updateById(currencyModel, id, {isDefault: 1})
    }
    let msg = "";
    if (updated) {
      msg = "Default currency updated successfully.";
    } else {
      msg = "Default currency updation failed.";
    }
    return res.status(200).json({
      status: true,
      message: msg,
    });
  });
  static getCurrencyInfo = catchAsyncErrors(async (req, res, next) => {
    const { id, isDefault, currency_code } = req.body;
    let queryConditions = {
      deletedAt: null,
      status: true,
    };

    if (id) {
      queryConditions.id = id
    }
    if (isDefault) {
      queryConditions.isDefault = isDefault
    }
    if (currency_code) {
      queryConditions.currency_code = currency_code
    }

    let currencyDetails = await super.getByCustomOptionsSingle(req, currencyModel, {
      where: queryConditions,
    });

    if (currencyDetails) {
      return res.status(200).json({
        status: true,
        message: "Success",
        data: currencyDetails
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No records found.",
        data: {}
      });
    }
  });

  static getExchangeRates = catchAsyncErrors(async (req, res, next) => {
    let { currency_from } = req.body;
    let whereClause = {
      deletedAt: null,
    };
    if(currency_from){
      whereClause.currency_from = currency_from;
    }
    let options = {
      where: whereClause,
      order: [['id', 'DESC']],
    };
    let exchangeRates = await super.getList(req, exchangeRateModel, options);
    if (exchangeRates.length > 0) {
      return res.status(200).json({
        status: true,
        message: "Data found.",
        data: exchangeRates,
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No data found.",
        data: [],
      });
    }
  });
  static saveExchangeRate = catchAsyncErrors(async (req, res, next) => {
    let { currency_from, currency_to, exchange_rate } = req.body;

    let updateFields = {
      currency_from: currency_from,
      currency_to: currency_to,
      exchange_rate: exchange_rate,
    };

    let rateExists = await super.getByCustomOptionsSingle(req, exchangeRateModel, {
      where: {
        currency_from: currency_from,
        currency_to: currency_to,
      },
    });

    let updated = null;
    if (rateExists) {
      updated = await super.updateById(exchangeRateModel, rateExists.id, updateFields)
    } else {
      updated = await super.create(res, exchangeRateModel, updateFields);
    }
    let msg = "";
    if (updated) {
      msg = rateExists ? "Rate updated successfully." : "Rate added successfully.";
    } else {
      msg = "Rate addition failed.";
    }
    if (updated) {
      return res.status(200).json({
        status: true,
        message: msg,
        data: updated,
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Oops.. Something wrong happened!",
        data: {},
      });
    }
  });
}

module.exports = homeController;
