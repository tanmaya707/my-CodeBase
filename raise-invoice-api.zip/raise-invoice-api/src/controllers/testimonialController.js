const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const fileUploaderSingle = require("../utils/fileUpload.js").fileUploaderSingle;
const db = require("../models");
const testimonialModel = db.Testimonials;
const { Sequelize, Op } = require("sequelize");
const crypto = require("crypto");

class testimonialController extends BaseController {
  constructor() {
    super();
  }

  static getTestimonialList = catchAsyncErrors(async (req, res, next) => {
    let { searchText, testimonialIds, page, limit } = req.body;
    let whereClause = {
      status: true,
      deletedAt: null,
    };
    if (searchText) {
      whereClause[Op.or] = [
        {
          id:
          {
            [Op.like]: `%${searchText}%`
          }
        },
        {
          name:
          {
            [Op.like]: `%${searchText}%`
          }
        }
      ];
    }
    if(testimonialIds){
      whereClause[Op.and] = [
        {
          id: 
          {
              [Op.in]: testimonialIds
          }
        }
      ] ;
    }
    let options = {
      where: whereClause,
      order: [['id', 'DESC']],

      // limit: limit,
      // offset: (page - 1) * limit
    };
    if(limit){
      options.limit = limit;
    }
    if(page && limit){
      options.offset = (page - 1) * limit;
    }

    let testimonialLists = await super.getList(req, testimonialModel, options);
    const totalCount = await testimonialModel.count({ where: whereClause });

    if (testimonialLists.length > 0) {
      return res.status(200).json({
        status: true,
        message: "Data found.",
        data: testimonialLists,
        totalPages: limit ? Math.ceil(totalCount / limit) : 1,
        currentPage: page ? page : 1
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No data found.",
        data: [],
        totalPages: 0,
        currentPage: page ? page : 1

      });
    }
  });
  static saveTestimonial = catchAsyncErrors(async (req, res, next) => {
    let { id, name, message, description, designation, company, status } = req.body;

    let updateFields = {
      name: name,
      message: message,
      description: description,
      designation: designation,
      company: company,
      status: status
    };
    // =========== single file upload ================
    if (req.files.image) {
      let imageData = await fileUploaderSingle(
        "src/public/uploads/testimonial/",
        req.files.image
      );
      updateFields.image = imageData.newfileName;
    }
    // =========== single file upload ================
    let updated = null;
    if (id && id != "" && id != null && id != 'null') {
      updated = await super.updateById(testimonialModel, id, updateFields)
    } else {
      updateFields.uuid = crypto.randomUUID();
      updated = await super.create(res, testimonialModel, updateFields);
    }
    let msg = "";
    if (updated) {
      msg = (id && id != "" && id != null && id != 'null') ? "Testimonial updated successfully." : "Testimonial added successfully.";
    } else {
      msg = "Testimonial addition failed.";
    }

    if (updated) {
      return res.status(200).json({
        status: true,
        message: msg,
        data: updated,
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Oops.. Something wrong happened!",
        data: {},
      });
    }
  });
  static getTestimonialDetails = catchAsyncErrors(async (req, res, next) => {
    const { id, uuid } = req.body;
    let queryConditions = {
      deletedAt: null,
      status: true,
    };

    if (id) {
      queryConditions.id = id
    }
    if (uuid) {
      queryConditions.uuid = uuid
    }

    let testimonialDetails = await super.getByCustomOptionsSingle(req, testimonialModel, {
      where: queryConditions,
    });

    if (testimonialDetails) {
      return res.status(200).json({
        status: true,
        message: "Success",
        data: testimonialDetails
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No records found.",
        data: {}
      });
    }
  });
  static deleteTestimonial = catchAsyncErrors(async (req, res, next) => {
    let { uuid } = req.body;

    let testimonialDetail = await super.getByCustomOptionsSingle(req, testimonialModel, {
      where: {
        uuid: uuid
      },
      attributes: ["id"],
    });

    if (!testimonialDetail) {
      return res.status(403).json({
        status: false,
        message: "Testimonial not found!",
        data: {},
      });
    }
    let deleted = await super.deleteByCondition(
      testimonialModel,
      {
        id: testimonialDetail.id,
      }
    );

    if (deleted) {
      return res.status(200).json({
        status: true,
        message: "Testimonial successfully deleted.",
        data: {}
      });
    } else {
      return res.status(500).json({
        status: false,
        message: "Oops.. something went terribly wrong!",
        data: {}
      });
    }
  });

}

module.exports = testimonialController;
