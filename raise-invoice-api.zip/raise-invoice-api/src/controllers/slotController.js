const axios = require("axios");
const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/errorHandler");
const RequestHandler = require("../utils/RequestHandler");
const fileUploaderSingle = require("../utils/fileUpload").fileUploaderSingle;
const bcrypt = require("bcryptjs");
const JWTAuth = require("../utils/jwtToken");
const jwt = require("jsonwebtoken");
const jwtConfig = require("../config").JWT;
const { Op, fn, col, } = require("sequelize");
const { sequelizeConnectionInstance, Sequelize } = require("../models");

const {
  calculateDistance,
  calculateDistanceInsTentApi,
  calculateTimeInKilometers,
  getRateChartCategory,
} = require("../utils/utilities");
const {
  MSG_RECORD_STATUS_SUCCESS,
  MSG_RECORD_FETCH_SUCCESS,
} = require("../config/constants");
const requestHandler = new RequestHandler();

const db = require("../models");
const parkingBusinessesModel = db.ParkingBusinesses;
const parkingGroundsModel = db.ParkingGrounds;
const parkingLotsModel = db.ParkingLots;
const slotModel = db.Slots;

class slotController extends BaseController {
  constructor() {
    super();
  }

  static slotList = catchAsyncErrors(async (req, res, next) => {
    // let slotList = await slotModel.findAll({
    //   where: {
    //     isActive: true,
    //     deletedAt: null,
    //   },
    //   include: [
    //     {
    //       model: parkingLotsModel,
    //       required: true,
    //       where: { parkingGroundId: 1 },
    //       attributes: ['parkingGroundId', 'lotName', 'noOfBays', 'noOfRows', 'bayPosition', 'minDays', 'maxDays', 'isLotFull', 'isActive', 'deletedAt'],
    //       // include: [
    //       //   {
    //       //     model: parkingGroundsModel,
    //       //     required: true,
    //       //     attributes: ['parkingBusinessId', 'groundName', 'noOfLots', 'parkingCapacity', 'isGroundFull', 'isActive', 'deletedAt'],
    //       //     include: [
    //       //       {
    //       //         model: parkingBusinessesModel,
    //       //         required: true,
    //       //         attributes: ['businessName', 'noOfGrounds', 'parkingCapacity', 'isAquired', 'isActive', 'deletedAt']
    //       //       },
    //       //     ],
    //       //   },
    //       // ],
    //     },
    //   ],
    //   attributes: [
    //     "id",
    //     "parkingLotId",
    //     "slotName",
    //     "slotBayNumber",
    //     "slotRowNumber",
    //     "occupancyStatus",
    //     "isActive",
    //     // "deleted_by",
    //     // "deletedAt",
    //     // [fn("COUNT", col("slots.id")), "slotCount"], // Counting slots
    //   ],
    //   order: [
    //     ['parkingLotId', 'ASC']
    //   ],
    //   logging: console.log,
    // });

    let parkingGroundDetails = await parkingGroundsModel.findAll({
      where: {
        parkingBusinessId: 1
      },
      include: [
        {
          model: parkingBusinessesModel,
          required: true,
        }
      ]
    });
    
    let slots = await sequelizeConnectionInstance.query(`
      SELECT
        slots.id,
        slots.parkingLotId,
        slots.slotName,
        slots.slotBayNumber,
        slots.slotRowNumber,
        slots.occupancyStatus,
        slots.isActive,
        parkingLot.id,
        parkingLot.parkingGroundId,
        parkingLot.lotName,
        parkingLot.noOfBays,
        parkingLot.noOfRows,
        parkingLot.bayPosition,
        parkingLot.minDays,
        parkingLot.maxDays,
        parkingLot.isLotFull,
        parkingLot.isActive,
        parkingLot.deleted_at
      FROM
        slots AS slots
      INNER JOIN parkingLots AS parkingLot
        ON
          slots.parkingLotId = parkingLot.id AND parkingLot.parkingGroundId = 1
      WHERE
        slots.isActive = TRUE AND slots.deleted_at IS NULL
      ORDER BY
        slots.parkingLotId ASC,
        slots.slotRowNumber ASC,
        slots.slotBayNumber ASC
      `,
      
      { type: Sequelize.QueryTypes.SELECT }
    );

    let formattedSlotsList = [];
    let groupedSlots = {};
    slots.forEach(async (slot) => {
      const parkingLotId = slot.parkingLotId;
      const slotRowNumber = slot.slotRowNumber;

      // Initialize the parking lot if it doesn't exist
      if (!groupedSlots[parkingLotId]) {
        groupedSlots[parkingLotId] = {
          parkingLotId: slot.parkingLotId,
          parkingGroundId: slot.parkingGroundId,
          lotName: slot.lotName,
          noOfBays: slot.noOfBays,
          noOfRows: slot.noOfRows,
          bayPosition: slot.bayPosition,
          minDays: slot.minDays,
          maxDays: slot.maxDays,
          isLotFull: slot.isLotFull,
          isActive: slot.isActive,
          deletedAt: slot.deleted_at,
          rows: {}, // Initialize an object for the rows
        };
      }

      // Initialize the row if it doesn't exist
      if (!groupedSlots[parkingLotId].rows[slotRowNumber]) {
        groupedSlots[parkingLotId].rows[slotRowNumber] = {
          slotRowNumber: slotRowNumber,
          slots: [], // Initialize an array for the slots
        };
      }

      // Push the current slot into the slots array for this row
      groupedSlots[parkingLotId].rows[slotRowNumber].slots.push({
        id: slot.id,
        parkingLotId: slot.parkingLotId,
        slotName: slot.slotName,
        slotBayNumber: slot.slotBayNumber,
        occupancyStatus: slot.occupancyStatus,
        isActive: slot.isActive,
      });
    });

    if (groupedSlots) {
      return res.status(200).json({
        status: true,
        message: "Slots found.",
        data: {
          groupedSlots: groupedSlots,
          parkingGroundDetails: parkingGroundDetails,
        },
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No slots found.",
        data: [],
      });
    }
  });

  static slotAnalytics = catchAsyncErrors(async (req, res, next) => {
    let { parkingGroundId, } = req.body;

    let parkingLots = await super.getByCustomOptions(req, parkingLotsModel, {
      where: { parkingGroundId: parkingGroundId },
    });
    
    let parkingLotsIdArr = [];
    parkingLots.forEach((parkingLot) => {
      parkingLotsIdArr.push(parkingLot.id);
    });
    
    let totalSlotOptions = {
      where: {
        isActive: true,
        deletedAt: null,

        parkingLotId: {
          [Op.in]: parkingLotsIdArr
        },
      },
    };
    let totalSlots = 0;
    totalSlots = await super.countRecords(req, slotModel, totalSlotOptions);
    
    let totalBookedSlotOptions = {
      where: {
        isActive: true,
        deletedAt: null,

        parkingLotId: {
          [Op.in]: parkingLotsIdArr
        },

        occupancyStatus: {
          [Op.in]: ["Booked", "Occupied"]
        }
      },
    };
    let totalBookedSlots = 0;
    totalBookedSlots = await super.countRecords(req, slotModel, totalBookedSlotOptions);
    
    let totalOverstaySlotOptions = {
      where: {
        isActive: true,
        deletedAt: null,

        parkingLotId: {
          [Op.in]: parkingLotsIdArr
        },

        occupancyStatus: {
          [Op.in]: ["Booked", "Occupied"]
        }
      },
    };
    let totalOverstaySlots = 0;
    totalOverstaySlots = await super.countRecords(req, slotModel, totalOverstaySlotOptions);

    let totalFreeSlotOptions = {
      where: {
        isActive: true,
        deletedAt: null,

        parkingLotId: {
          [Op.in]: parkingLotsIdArr
        },

        occupancyStatus: "Vacant"
      },
    };
    let totalFreeSlots = 0;
    totalFreeSlots = await super.countRecords(req, slotModel, totalFreeSlotOptions);

    return res.status(200).json({
      status: true,
      message: "Counting done.",
      data: {
        totalSlots: totalSlots,
        totalBookedSlots: totalBookedSlots,
        totalOverstaySlots: totalOverstaySlots,
        totalFreeSlots: totalFreeSlots,
      }
    });
  });

  // ===============================================================
  // ==================== RUN FROM POSTMAN ONLY ====================
  // ===============================================================
  static createSlotsTheSmartWay = catchAsyncErrors(async (req, res, next) => {
    let {
      parkingLotId,
      bayCount,
      rowCount,
      startRow,
      endRow,
      incrementDirection,
      slotInitials,
    } = req.body;

    let dataCreationCount = 0;
    let noOfDatasThatShouldEnter =
      (Number(endRow) - Number(startRow) + 1) * Number(bayCount);
    // console.log("noOfDatasThatShouldEnter ==>");
    // console.log(noOfDatasThatShouldEnter);

    if (incrementDirection == "V") {
      for (let row = startRow; row <= endRow; row++) {
        for (let bay = 1; bay <= bayCount; bay++) {
          let data = {};

          data.parkingLotId = parkingLotId;
          data.slotName = `${row}${slotInitials}-${bay}`;
          data.slotBayNumber = bay;
          data.slotRowNumber = row;
          data.occupancyStatus = "Vacant";

          let createSlot = await super.create(res, slotModel, data);

          dataCreationCount++;
        }
      }
    } else if (incrementDirection == "H") {
      // console.log("here ====>");

      for (let bay = 1; bay <= bayCount; bay++) {
        // console.log("here 2");

        for (let row = startRow; row <= endRow; row++) {
          // console.log("here 3");
          let data = {};

          data.parkingLotId = parkingLotId;
          data.slotName = `${row}${slotInitials}-${bay}`;
          data.slotBayNumber = bay;
          data.slotRowNumber = row;
          data.occupancyStatus = "Vacant";

          // console.log("data ===>");
          // console.log(data);

          let createSlot = await super.create(res, slotModel, data);

          dataCreationCount++;
        }
      }
    }

    if (noOfDatasThatShouldEnter == dataCreationCount) {
      return res.status(200).json({
        status: true,
        message:
          "Successfully inserted a lot of slots the smart way and saved you a few boring hours..!!",
        data: [
          {
            noOfDatasThatShouldEnter: noOfDatasThatShouldEnter,
            dataCreationCount: dataCreationCount,
          },
        ],
      });
    } else {
      return res.status(500).json({
        status: false,
        message: "Something went terribly wrong..!!",
        data: [
          {
            noOfDatasThatShouldEnter: noOfDatasThatShouldEnter,
            dataCreationCount: dataCreationCount,
          },
        ],
      });
    }
  });
  // ===============================================================
  // ==================== RUN FROM POSTMAN ONLY ====================
  // ===============================================================
}

module.exports = slotController;
