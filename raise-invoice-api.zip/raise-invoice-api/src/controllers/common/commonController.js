const BaseController = require("../BaseController");
const catchAsyncErrors = require("../../middleware/catchAsyncErrors");
const { Sequelize, Op } = require("sequelize");
const db = require("../../models");
const clientModel = db.Clients;
const countriesModel = db.Countries;
const MasterLanguageModel = db.LanguageModel;
const faqModel = db.Faqs;
const faqCategoriesModel = db.Categories;
const testimonialModel = db.Testimonials;
const planModel = db.Plans;
const userEnquiryModel = db.UserEnquiries;
const mysqlConfig = require("../../config/index").Mysql;
const { connectSpecificToDatabase } = require("../../config/specificConnect");
const currencyModel = db.CurrencyModel;
const MenuModel = db.MenuModel;
const pageModel = db.PageModel;
const newsletterSubscriptionModel = db.NewsletterSubscriptions;
class CommonController extends BaseController {
    constructor() {
        super();
    }

    static getFaqList = catchAsyncErrors(async (req, res, next) => {
        let whereClause = {
            status: true,
            deletedAt: null,
        };
        let options = {
            where: whereClause,
            order: [["order", "ASC"]],
            include: [
                {
                    model: faqCategoriesModel,
                    attributes: ["id", "name"],
                    where: {
                        deletedAt: null,
                        status: true,
                    }
                },
            ],
        };

        let faqLists = await super.getList(req, faqModel, options);

        if (faqLists.length > 0) {
            return res.status(200).json({
                status: true,
                message: "Data found.",
                data: faqLists,
            });
        } else {
            return res.status(200).json({
                status: false,
                message: "No data found.",
                data: [],
            });
        }
    });

    static getTestimonialList = catchAsyncErrors(async (req, res, next) => {
        let whereClause = {
            status: true,
            deletedAt: null,
        };
        let options = {
            where: whereClause,
            order: [["name", "ASC"]],
        };

        let testimonialLists = await super.getList(req, testimonialModel, options);

        if (testimonialLists.length > 0) {
            return res.status(200).json({
                status: true,
                message: "Data found.",
                data: testimonialLists,
            });
        } else {
            return res.status(200).json({
                status: false,
                message: "No data found.",
                data: [],
            });
        }
    });

    static getRoleList = catchAsyncErrors(async (req, res, next) => {
        const userId = req.user.id;

        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User  not found' });
        }

        // let excludedRoleSlugs = ["super-admin"];

        // let whereClause = {
        //     deletedAt: null,
        //     roleSlug: {
        //         [Op.notIn]: excludedRoleSlugs,
        //     }
        // };

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        // const queryConditions = {
        //     where: whereClause,
        //     order: [["order", "DESC"]],
        // };

        const roles = await connection.UserRole.findAll({});

        if (roles) {
            return res.status(200).json({
                status: true,
                message: "Success",
                data: roles
            });
        } else {
            return res.status(200).json({
                status: false,
                message: "No records found.",
                data: {}
            });
        }
    });

    static getPlanList = catchAsyncErrors(async (req, res, next) => {
        let { searchText } = req.body;
        let whereClause = {
            status: true,
            deletedAt: null,
        };
        if (searchText) {
            whereClause[Op.or] = [
                {
                    id:
                    {
                        [Op.like]: `%${searchText}%`
                    }
                },
                {
                    name:
                    {
                        [Op.like]: `%${searchText}%`
                    }
                },
                {
                    slug:
                    {
                        [Op.like]: `%${searchText}%`
                    }
                },
                {
                    short_description:
                    {
                        [Op.like]: `%${searchText}%`
                    }
                },
                {
                    description:
                    {
                        [Op.like]: `%${searchText}%`
                    }
                }
            ];
        }
        let options = {
            where: whereClause,
            order: [["name", "ASC"]],
        };

        let planLists = await super.getList(req, planModel, options);
        // let planLists = await planModel.findAll(options);

        if (planLists.length > 0) {
            return res.status(200).json({
                status: true,
                message: "Data found.",
                data: planLists,
            });
        } else {
            return res.status(200).json({
                status: false,
                message: "No data found.",
                data: [],
            });
        }
    });

    static submitEnquiry = catchAsyncErrors(async (req, res, next) => {
        let { userId, countryId, name, email, message, companyName } = req.body;
        if (!countryId) {
            return res.status(422).json({
                status: false,
                message: "Country is required.",
                data: {},
            });
        }
        if (!name) {
            return res.status(422).json({
                status: false,
                message: "Name is required.",
                data: {},
            });
        }
        if (!email) {
            return res.status(422).json({
                status: false,
                message: "Email is required.",
                data: {},
            });
        }
        if (!message) {
            return res.status(422).json({
                status: false,
                message: "Message is required.",
                data: {},
            });
        }

        let enquiryFields = {
            uuid: crypto.randomUUID(),
            userId: userId,
            countryId: countryId,
            name: name,
            email: email,
            message: message,
            companyName: companyName,
        };

        let created = await super.create(res, userEnquiryModel, enquiryFields);

        if (created) {
            return res.status(200).json({
                status: true,
                message: "Enquiry submitted successfully",
                data: {},
            });
        } else {
            return res.status(400).json({
                status: false,
                message: "Oops.. Something wrong happened!",
                data: {},
            });
        }
    });

    static getMasterDataList = catchAsyncErrors(async (req, res, next) => {
        const paymentTerms = [
            { title: "None", value: 0 },
            { title: "Due Today", value: 1 },
            { title: "7 Days", value: 7 },
            { title: "14 Days", value: 14 },
            { title: "21 Days", value: 21 },
            { title: "30 Days", value: 30 },
            { title: "45 Days", value: 45 },
            { title: "60 Days", value: 60 },
            { title: "90 Days", value: 90 },
        ];
        const productUnitTypes = [
            { title: "Piece", value: "piece" },
            { title: "Kg", value: "kg" },
            { title: "Gram", value: "gram" },
            { title: "Liter", value: "liter" },
            { title: "Meter", value: "meter" },
            { title: "Set", value: "set" },
            { title: "Box", value: "box" },
            { title: "Pack", value: "pack" },
            { title: "Dozen", value: "dozen" }
        ];

        let options = {
            attributes: [
                ["id", "value"],
                ["name", "label"],
                ["currency", "currency"]
            ],
            order: [["name", "asc"]],
        };

        let currency = {
            attributes: [
                'id',
                'currency_code',
                'currency_name',
                'symbol',
            ],
            order: [['currency_name', 'asc']],
        };

        let countries = await countriesModel.findAll(options);
        let languageLists = await MasterLanguageModel.findAll({});
        let currencyData = await currencyModel.findAll(currency)

        return res.status(200).json({
            status: true,
            message: "Data found!",
            data: { paymentTerms, countries, languageLists, productUnitTypes, currencyData }
        });
    });

    static getMenuList = catchAsyncErrors(async (req, res, next) => {
        let { menu_type, parent_menu, menu_group } = req.body;
        let whereClause = {
            deletedAt: null,
        };
        if (menu_type) {
            whereClause.menu_type = menu_type;
        }
        if (menu_group) {
            whereClause.menu_group = menu_group;
        }
        if (parent_menu) {
            // Set the condition to find records where parent_id is NULL
            whereClause.parent_id = {
                [Op.is]: null // This checks for records where parent_id is NULL
            };
        }
        let options = {
            where: whereClause,
            order: [['order_number', 'ASC']],
            include: [
                {
                    model: pageModel,
                    attributes: ["id", "page_title", "slug"],
                    where: {
                        deletedAt: null,
                    },
                }
            ],
        };

        let menuLists = await MenuModel.findAll(options);

        if (menuLists.length > 0) {
            return res.status(200).json({
                status: true,
                message: "Data found.",
                data: menuLists,
            });
        } else {
            return res.status(200).json({
                status: false,
                message: "No data found.",
                data: [],
            });
        }
    });
    static getMenuDetails = catchAsyncErrors(async (req, res, next) => {
        const { id, uuid, slug } = req.body;
        let queryConditions = {
            deletedAt: null,
        };

        if (slug) {
            queryConditions.slug = slug
        }
        if (id) {
            queryConditions.id = id
        }
        if (uuid) {
            queryConditions.uuid = uuid
        }

        let menuDetails = await super.getByCustomOptionsSingle(req, MenuModel, {
            where: queryConditions,
            include: [
                {
                    model: pageModel,
                    attributes: ["id", "page_title", "slug"],
                    where: {
                        deletedAt: null,
                    },
                    required: false
                }
            ],
        });

        if (menuDetails) {
            return res.status(200).json({
                status: true,
                message: "Success",
                data: menuDetails
            });
        } else {
            return res.status(200).json({
                status: false,
                message: "No records found.",
                data: {}
            });
        }
    });
    static subscribeNewletter = catchAsyncErrors(async (req, res, next) => {
        let { email } = req.body;
        if (!email) {
            return res.status(422).json({
                status: false,
                message: "Email is required.",
                data: {},
            });
        }

        let subscriptionFields = {
            uuid: crypto.randomUUID(),
            email: email,
        };
        let condition = {
            email: email,
            status: true,
            deletedAt: null,
        };
        const subscriptionExists = await newsletterSubscriptionModel.findOne({
            attributes: ['id'],
            where: condition
        });
        console.log(condition, subscriptionExists);
        if (!subscriptionExists) {
            let created = await super.create(res, newsletterSubscriptionModel, subscriptionFields);

            if (created) {
                return res.status(200).json({
                    status: true,
                    message: "Newsletter successfully subscribed",
                    data: {},
                });
            } else {
                return res.status(400).json({
                    status: false,
                    message: "Oops.. Something went wrong!",
                    data: {},
                });
            }
        } else {
            return res.status(200).json({
                status: false,
                message: "Subscription already exists",
                data: {},
            });
        }
    });
}

module.exports = CommonController;
