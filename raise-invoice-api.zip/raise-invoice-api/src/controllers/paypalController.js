
import paypal from '@paypal/checkout-server-sdk';
// import db from '@/lib/db';
// import { authOptions } from "../auth/[...nextauth]";
// import { getServerSession } from "next-auth/next";
import BaseController from "./BaseController";
import catchAsyncErrors from "../middleware/catchAsyncErrors";


// Set up PayPal environment
const environment = new paypal.core.SandboxEnvironment(
  process.env.PAYPAL_CLIENT_ID,
  process.env.PAYPAL_CLIENT_SECRET
);
const client = new paypal.core.PayPalHttpClient(environment);

class paypalController extends BaseController {
  constructor() {
    super();
  }

    static togglePaypalIntegration = catchAsyncErrors(async (req, res, next) =>{
        const session = await getServerSession(req, res, authOptions);
        if (!session) {
            return res.status(401).json({ error: 'Unauthorized' });
        }
        
        if (req.method === 'POST') {
            try {
            const { enabled } = req.body;
            const userId = session.user.id;
            
            // Update the PayPal integration status
            await db.paypalIntegration.update({
                where: { userId },
                data: { enabled }
            });
            
            res.status(200).json({ success: true });
            } catch (error) {
            console.error('Error toggling PayPal:', error);
            res.status(500).json({ error: 'Failed to update PayPal status' });
            }
        } else {
            res.setHeader('Allow', ['POST']);
            res.status(405).end(`Method ${req.method} Not Allowed`);
        }

    });

    static paypalCallback = catchAsyncErrors(async (req, res, next) =>{
        const { token, PayerID, userId } = req.query;
        
        if (!token || !PayerID || !userId) {
            return res.status(400).json({ error: 'Missing required parameters' });
        }
        
        try {
            // Capture the payment to complete the setup
            const request = new paypal.orders.OrdersCaptureRequest(token);
            request.requestBody({});
            
            const response = await client.execute(request);
            
            if (response.statusCode === 201) {
            // Success - store PayPal details in your database
            const payerInfo = response.result.payer;
            const paymentSource = response.result.payment_source;
            
            await db.paypalIntegration.upsert({
                where: { userId },
                update: {
                payerId: payerInfo.payer_id,
                email: payerInfo.email_address,
                enabled: true,
                details: JSON.stringify(payerInfo)
                },
                create: {
                userId,
                payerId: payerInfo.payer_id,
                email: payerInfo.email_address,
                enabled: true,
                details: JSON.stringify(payerInfo)
                }
            });
            
            // Redirect back to the payment options page with success message
            res.redirect('/payment-options?paypal=success');
            } else {
            console.error('PayPal capture failed:', response);
            res.redirect('/payment-options?paypal=error');
            }
        } catch (error) {
            console.error('Error capturing PayPal payment:', error);
            res.redirect('/payment-options?paypal=error');
        }

    });

    static getPaypalAuthUrl = catchAsyncErrors(async (req, res, next) =>{
        const session = await getServerSession(req, res, authOptions);
    
    if (!session) {
        return res.status(401).json({ error: 'Unauthorized' });
    }
    
    if (req.method === 'GET') {
        try {
        // Create a request to get the auth URL
        const request = new paypal.orders.OrdersCreateRequest();
        request.requestBody({
            intent: 'CAPTURE',
            purchase_units: [{
            amount: {
                currency_code: 'USD',
                value: '0.01' // Minimal amount for setup
            }
            }],
            application_context: {
            return_url: `${process.env.NEXTAUTH_URL}/api/payment/paypal-callback?userId=${session.user.id}`,
            cancel_url: `${process.env.NEXTAUTH_URL}/payment-options`,
            brand_name: process.env.APP_NAME || 'Your App Name',
            user_action: 'PAY_NOW',
            shipping_preference: 'NO_SHIPPING'
            }
        });
        
        const response = await client.execute(request);
        
        // Extract the approval URL from the response
        const approvalUrl = response.result.links.find(link => link.rel === 'approve').href;
        
        res.status(200).json({ authUrl: approvalUrl });
        } catch (error) {
        console.error('Error creating PayPal auth URL:', error);
        res.status(500).json({ error: 'Failed to create PayPal authentication URL' });
        }
    } else {
        res.setHeader('Allow', ['GET']);
        res.status(405).end(`Method ${req.method} Not Allowed`);
    }
        
    })

    static getPaypalStatus = catchAsyncErrors(async (req, res, next) =>{
    const session = await getServerSession(req, res, authOptions);
    
    if (!session) {
        return res.status(401).json({ error: 'Unauthorized' });
    }
    
    if (req.method === 'GET') {
        try {
        // Get the user's PayPal status from your database
        const userId = session.user.id;
        
        // Example database query - adjust based on your DB structure
        const paypalStatus = await db.paypalIntegration.findUnique({
            where: { userId }
        });
        
        res.status(200).json({
            isSetup: !!paypalStatus,
            isEnabled: paypalStatus?.enabled || false
        });
        } catch (error) {
        console.error('Error fetching PayPal status:', error);
        res.status(500).json({ error: 'Internal server error' });
        }
    } else {
        res.setHeader('Allow', ['GET']);
        res.status(405).end(`Method ${req.method} Not Allowed`);
    }
    })
}

module.exports = paypalController;