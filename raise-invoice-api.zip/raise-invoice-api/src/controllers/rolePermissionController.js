const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/errorHandler");
const RequestHandler = require("../utils/RequestHandler");
const { Op } = require("sequelize");
const requestHandler = new RequestHandler();
const db = require("../models");
const rolesPermissionModel = db.RolesPermissions;
const permissionModel = db.Permissions;
const userModel = db.Users;
const roleModel = db.Roles;
const modulesModel = db.Modules;
const {
  slugify
} = require("../utils/utilities");

class RolePermissionController extends BaseController {
  constructor() {
    super();
  }
  static saveRole = catchAsyncErrors(async (req, res, next) => {
    const { id, roleName } = req.body;
    if (!roleName) {
      return res.status(422).json({
        status: false,
        message: "Role name is required.",
        data: {},
      });
    }
    let condition = {
      deletedAt: null,
      roleName: roleName
    };
    if (id && id != "" && id != null && id != 'null') {
      condition.id = `{
            [Op.ne]: id
        }`;
    }
    let checkExist = await roleModel.findOne({
      attributes: ["id"],
      where: condition,
    });
    if (checkExist) {
      return res.status(400).json({
        status: false,
        message: "Role name already exists!",
        data: checkExist,
      });
    }
    let updated = null;
    let message = "";
    if(id && id != "" && id != null && id != 'null'){
      updated = await super.updateById(roleModel, id, {roleName: roleName});
      message = "Role updated successfully";
    }else{
      updated = await super.create(res, roleModel, {roleName: roleName, roleSlug: slugify(roleName), uuid: crypto.randomUUID()});
      message = "Role added successfully";
    }
    if(updated){
      return res.status(200).json({
        status: true,
        message: message,
        data: {errors: {}}
      });
    }else{
      return requestHandler.customError(res, 500, "Something went wrong.");
    }

  });
  
  static deleteRole = catchAsyncErrors(async (req, res, next) => {
    const { uuid } = req.body;
    if (!uuid) {
      return next(new ErrorHandler("Role is required", 400));
    }
    // =================== soft delete ===================
    let roleDeleted = await super.deleteByCondition(
      roleModel, 
      {
        uuid: uuid,
      }
    );
    // =================== soft delete ===================
    if(roleDeleted){
      return res.status(200).json({
        status: true,
        message: "Role deleted successfully"
      });
    }else{
      return requestHandler.customError(res, 500, "Something went wrong.");
    }
  });
  static getRoleList = catchAsyncErrors(async (req, res, next) => {
    let { searchText, excludedRoleSlug } = req.body;
    let roles = [];
    let queryConditions = {};
    let excludedRoleSlugs = ["super-admin"];
    if(excludedRoleSlug){
      excludedRoleSlugs.push(excludedRoleSlug);
    }
    let whereClause = {
      deletedAt: null,
      roleSlug: {
        [Op.notIn]: excludedRoleSlugs,
      }
    };

    if(searchText){
      // let searchId = searchText.toLowerCase().replace('invoice-usr-','').replace(/^0+/, '');
      whereClause[Op.or] = [
        {
          id: 
          {
              [Op.like]: `%${searchText}%`
          }
        }, 
        {
          roleName: 
          {
              [Op.like]: `%${searchText}%`
          }
        }, 
        {
          roleSlug: 
          {
              [Op.like]: `%${searchText}%`
          }
        }
      ] ;
    }

    queryConditions = {
      where: whereClause,
      order: [["order", "DESC"]],
    };

    roles = await roleModel.findAll(queryConditions);
  
    if(roles){
      return res.status(200).json({
        status: true,
        message: "Success",
        data: roles
      });
    } else{
      return res.status(200).json({
        status: false,
        message: "No records found.",
        data: {}
      });
    }
  });
  static getAdminRoleList = catchAsyncErrors(async (req, res, next) => {
    let { searchText, excludedRoleSlug } = req.body;
    let roles = [];
    let queryConditions = {};
    let excludedRoleSlugs = ["super-admin"];
    if(excludedRoleSlug){
      excludedRoleSlugs.push(excludedRoleSlug);
    }
    let whereClause = {
      deletedAt: null,
      roleSlug: {
        [Op.notIn]: excludedRoleSlugs,
      }
    };

    if(searchText){
      // let searchId = searchText.toLowerCase().replace('invoice-usr-','').replace(/^0+/, '');
      whereClause[Op.or] = [
        {
          id: 
          {
              [Op.like]: `%${searchText}%`
          }
        }, 
        {
          roleName: 
          {
              [Op.like]: `%${searchText}%`
          }
        }, 
        {
          roleSlug: 
          {
              [Op.like]: `%${searchText}%`
          }
        }
      ] ;
    }

    queryConditions = {
      attributes: [
        ["roleSlug", "value"],
        ["roleName", "label"]
      ],
      where: whereClause,
      order: [["roleName", "asc"]],
    };

    roles = await roleModel.findAll(queryConditions);
  
    if(roles){
      return res.status(200).json({
        status: true,
        message: "Success",
        data: roles
      });
    } else{
      return res.status(200).json({
        status: false,
        message: "No records found.",
        data: {}
      });
    }
  });
  static getRoleDetails = catchAsyncErrors(async (req, res, next) => {
    const { id, uuid, slug } = req.body;
    let queryConditions = {};

    if(id){
      queryConditions.id = id
    }
    if(uuid){
      queryConditions.uuid = uuid
    }
    if(slug){
      queryConditions.roleSlug = slug
    }

    let roleDetails = await super.getByCustomOptionsSingle(req, roleModel, {
      where: queryConditions,
    });
  
    if(roleDetails){
      return res.status(200).json({
        status: true,
        message: "Success",
        data: roleDetails
      });
    } else{
      return res.status(200).json({
        status: false,
        message: "No records found.",
        data: {}
      });
    }
  });

  static getModuleList = catchAsyncErrors(async (req, res, next) => {
    let { searchText } = req.body;
    let modules = [];
    let whereClause = {
      deletedAt: null,
    };
    if(searchText){
      whereClause[Op.or] = [
        {
          id: 
          {
              [Op.like]: `%${searchText}%`
          }
        }, 
        {
          moduleName: 
          {
              [Op.like]: `%${searchText}%`
          }
        }, 
        {
          moduleSlug: 
          {
              [Op.like]: `%${searchText}%`
          }
        }
      ] ;
    }
    const queryConditions = {
      where: whereClause,      
      include: [
        {
          model: permissionModel, // including associated model
          attributes: ["id", "name", "slug"], // Attributes to select from the included model
          required: false
        },
      ],
      order: [["order", "DESC"]],
    };

    modules = await modulesModel.findAll(queryConditions);
    // console.log(modules)
  
    // let userWithModules = [];
    // let moduleAccessIdArr = [];
    let filteredModules = modules;
    // if(req.user.id != 1){
    //   userWithModules = await userModel.findByPk(req.user.id, {
    //     include: modulesModel
    //   });
    //   userWithModules.modules.forEach((item)=>{
    //     moduleAccessIdArr.push(item.id);
    //   });
    //   filteredModules = modules.filter((item)=>{
    //     if(moduleAccessIdArr.includes(item.id)){
    //       return item;
    //     }
    //   });
    // }

    if(filteredModules){
      return res.status(200).json({
        status: true,
        message: "Success",
        data: filteredModules
      });
    } else{
      return res.status(200).json({
        status: false,
        message: "No records found.",
        data: {}
      });
    }
  });
  static getModuleDetails = catchAsyncErrors(async (req, res, next) => {
    const { uuid } = req.body;
    let queryConditions = {uuid: uuid};

    let moduleDetails = await super.getByCustomOptionsSingle(req, modulesModel, {
      where: queryConditions,
    });
  
    if(moduleDetails){
      return res.status(200).json({
        status: true,
        message: "Success",
        data: moduleDetails
      });
    } else{
      return res.status(200).json({
        status: false,
        message: "No records found.",
        data: {}
      });
    }
  });
  static saveModule = catchAsyncErrors(async (req, res, next) => {
    const { id, moduleName, parentModuleId } = req.body;
    if (!moduleName) {
      return res.status(422).json({
        status: false,
        message: "Module name is required.",
        data: {},
      });
    }
    let condition = {
      deletedAt: null,
      moduleName: moduleName
    };
    if (id && id != "" && id != null && id != 'null') {
      condition.id = `{
            [Op.ne]: id
        }`;
    }
    let checkExist = await modulesModel.findOne({
      attributes: ["id"],
      where: condition,
    });
    if (checkExist) {
      return res.status(400).json({
        status: false,
        message: "Module name already exist!",
        data: checkExist,
      });
    }
    let updated = null;
    let message = "";
    if(id && id != "" && id != null && id != 'null'){
      updated = await super.updateById(modulesModel, id, {moduleName: moduleName, parentModuleId: parentModuleId});
      message = "Module updated successfully";
    }else{
      updated = await super.create(res, modulesModel, {moduleName: moduleName, moduleSlug: slugify(moduleName), parentModuleId: parentModuleId, uuid: crypto.randomUUID()});
      let permissionData = [
        {
          moduleId: parseInt(updated.id), name: "View " + updated.moduleName, slug: 'view-' + updated.moduleSlug
        },
        {
          moduleId: parseInt(updated.id), name: "Add " + updated.moduleName, slug: 'add-' + updated.moduleSlug
        },
        {
          moduleId: parseInt(updated.id), name: "Edit " + updated.moduleName, slug: 'edit-' + updated.moduleSlug
        },
        {
          moduleId: parseInt(updated.id), name: "Delete " + updated.moduleName, slug: 'delete-' + updated.moduleSlug
        }
      ];
      await permissionModel.bulkCreate(permissionData, {returning: true});
      message = "Module added successfully";
    }
    if(updated){
      return res.status(200).json({
        status: true,
        message: message,
        data: {errors: {}}
      });
    }else{
      return requestHandler.customError(res, 500, "Something went wrong.");
    }

  });
  
  static deleteModule = catchAsyncErrors(async (req, res, next) => {
    const { uuid } = req.body;
    if (!uuid) {
      return next(new ErrorHandler("Module is required", 400));
    }
    let moduleDetails = await super.getByCustomOptionsSingle(req, modulesModel, {
      where: {uuid: uuid},
    });
    // =================== soft delete ===================
    let moduleDeleted = await super.deleteByCondition(
      modulesModel, 
      {
        id: moduleDetails.id,
      }
    );
    // =================== soft delete ===================
    if(moduleDeleted){
      await super.deleteByCondition(
        permissionModel, 
        {
          moduleId: moduleDetails.id,
        }
      );
      return res.status(200).json({
        status: true,
        message: "Module deleted successfully"
      });
    }else{
      return requestHandler.customError(res, 500, "Something went wrong.");
    }
  });

  static permissionList = catchAsyncErrors(async (req, res, next) => {
    const { moduleId } = req.body;
    let permissions = [];
    let queryConditions = {
      deletedAt: null
    };

    if (moduleId) {
      queryConditions.moduleId = moduleId;
    }

    permissions = await permissionModel.findAll({
      where: queryConditions
    });
  
    if(permissions){
      return res.status(200).json({
        status: true,
        message: "Success",
        data: permissions
      });
    } else{
      return res.status(200).json({
        status: false,
        message: "No records found.",
        data: {}
      });
    }
  });

  static updateRolePermission = catchAsyncErrors(async (req, res, next) => {
    const { roleId, rolePermissions } = req.body;
    // if (!rolePermissions.length) {
    //   return res.status(422).json({
    //     status: false,
    //     message: "Role wise permissions are required.",
    //     data: {},
    //   });
    // }
    await super.deleteByCondition(
      rolesPermissionModel, 
      {
        roleId: roleId,
      }
    );
    
    let created = await rolesPermissionModel.bulkCreate(rolePermissions, {returning: true});
    
    if(created){
      return res.status(200).json({
        status: true,
        message: "Role wise permissions are updated.",
      });
    }else{
      return requestHandler.customError(res, 500, "Something went wrong.");
    }   

  });
  static getRolePermissions = catchAsyncErrors(async (req, res, next) => {
    const { roleId } = req.body;
    let rolePermissions = [];
    if (!roleId) {
      return res.status(422).json({
        status: false,
        message: "Role id is required.",
        data: {},
      });
    }
    rolePermissions = await rolesPermissionModel.findAll({
      attributes: ["roleId", "permissionId"],
      where: {
        roleId: roleId
      }
    });
  
    if(rolePermissions){
      return res.status(200).json({
        status: true,
        message: "Success",
        data: rolePermissions
      });
    } else{
      return res.status(200).json({
        status: false,
        message: "No records found.",
        data: {}
      });
    }
  });
  // static roleWiseModuleList = catchAsyncErrors(async (req, res, next) => {
  //   let { roleId } = req.body;
  //   let modules = [];
  //   const queryConditions = {
  //     where: {
  //       deletedAt: null,
  //     }
  //   };

  //   modules = await modulesModel.findAll(queryConditions);
  
  //   let userWithModules = [];
  //   let moduleAccessIdArr = [];
  //   let filteredModules = modules;
  //   if(req.user.id != 1){
  //     userWithModules = await userModel.findByPk(req.user.id, {
  //       include: modulesModel
  //     });
  //     userWithModules.modules.forEach((item)=>{
  //       moduleAccessIdArr.push(item.id);
  //     });
  //     filteredModules = modules.filter((item)=>{
  //       if(moduleAccessIdArr.includes(item.id)){
  //         return item;
  //       }
  //     });
  //   }

  //   if(filteredModules){
  //     return res.status(200).json({
  //       status: true,
  //       message: "Success",
  //       data: filteredModules
  //     });
  //   } else{
  //     return res.status(200).json({
  //       status: false,
  //       message: "No records found.",
  //       data: {}
  //     });
  //   }
  // });

  // static rolePermissionList = catchAsyncErrors(async (req, res, next) => {
  //   let modules = []
  //   let rolePermissions = []
  //   const { roleId, text } = req.body;
  //   if(req.method == "POST"){
  //       const super_admin = await rollModel.findOne({ name: "Super Admin" });
  //       let match = {
  //         isActive: true,
  //         isDeleted: false,
  //         roleId: {
  //           $ne: super_admin._id,
  //         },
  //       //   $and:[
  //       //     {
  //       //         $or: [
  //       //           {
  //       //             moduleName: {
  //       //               $regex: ".*" + text + ".*",
  //       //               $options: "i",
  //       //             },
  //       //           },
  //       //         ],
  //       //     }
  //       //   ]
  //       };
  //       if (roleId != "") {
  //           const role = await rollModel.findOne({ _id: roleId });
  //           match["roleId"] = role._id;
  //       }
  //       const aggregatorOpts = [
  //         {
  //           $addFields: {
  //               roleId: "$roleId",
  //           },
  //         },
  //         {
  //           $match: match,
  //         },
  //       ];
  //       rolePermissions = await rolePermissionModel.aggregate(aggregatorOpts).exec();
  //       await rolePermissionModel.populate(
  //           rolePermissions,
  //           [
  //               {
  //                   path: 'roleId',
  //                   model: 'roleCollection',
  //               },
  //               {
  //                   path: 'moduleId', // array if objIds
  //                   model: 'moduleCollection',
  //                   populate: {
  //                       path: 'parentModuleId', 
  //                       model: 'moduleCollection',
  //                   }
  //               },
  //           ]
  //       );
  //   } else {
  //       // ======= for dropdown ===========
  //       // modules = await super.getList(req, rolePermissionModel, "");
  //   }

  //   return requestHandler.sendSuccess(
  //     res,
  //     "Successful"
  //   )({
  //     data: getPermissionDetails(rolePermissions),
  //   });
  // });

  // static rolePermissionAddUpdate = catchAsyncErrors(async (req, res, next) => {
  //   const { roleId, moduleId, _id } = req.body;
  //   let data = {
  //       roleId: roleId,
  //       moduleId: moduleId,

  //       updatedBy: req.user._id,
  //   };
  //   const updated =
  //     _id && _id != null && _id != ""
  //       ? await super.updateById(rolePermissionModel, _id.toString(), data)
  //       : await super.create(res, rolePermissionModel, data);

  //   return requestHandler.sendSuccess(
  //     res,
  //     "Successful"
  //   )({
  //     data: updated,
  //   });
  // });

  // static getRolePermissionDetail = catchAsyncErrors(async (req, res, next) => {
  //   const { id } = req.body;
  //   const rolePermissionDetail = await rolePermissionModel.findOne({ _id: id });
  //   return requestHandler.sendSuccess(
  //     res,
  //     "Successful"
  //   )({
  //     data: rolePermissionDetail,
  //   });
  // });

  // static deleteRolePermission = catchAsyncErrors(async (req, res, next) => {
  //   const { id } = req.body;
  //   let updated = [];
  //   // =================== soft delete ===================
  //   updated = await super.updateById(rolePermissionModel, id, {
  //       isDeleted: true
  //   });
  //   // =================== soft delete ===================
  //   return requestHandler.sendSuccess(
  //     res,
  //     "Successful"
  //   )({
  //     data: updated,
  //   });
  // });


  // =========== App APIs ================

  // =========== App APIs ================
}

module.exports = RolePermissionController;
