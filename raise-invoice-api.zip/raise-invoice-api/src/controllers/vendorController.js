const axios = require("axios");
const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/errorHandler");
const RequestHandler = require("../utils/RequestHandler");
const fileUploaderSingle = require("../utils/fileUpload").fileUploaderSingle;
const bcrypt = require("bcryptjs");
const JWTAuth = require("../utils/jwtToken");
const jwt = require("jsonwebtoken");
const jwtConfig = require("../config").JWT;
const { Op } = require("sequelize");

const {
  calculateDistance,
  calculateDistanceInsTentApi,
  calculateTimeInKilometers,
  getRateChartCategory,
} = require("../utils/utilities");
const {
  MSG_RECORD_STATUS_SUCCESS,
  MSG_RECORD_FETCH_SUCCESS,
} = require("../config/constants");
const requestHandler = new RequestHandler();

const db = require("../models");
const userModel = db.Users;
const roleModel = db.Roles;
const vendorModel = db.Vendors;
const modulePermissionsModel = db.ModulePermissions;

class VendorController extends BaseController {
  constructor() {
    super();
  }

  static vendorAddUpdate = catchAsyncErrors(async (req, res, next) => {
    let { name, initials, email, dialCode, phone, address, isOnsiteChargeApplicable, id, } = req.body;

    if (!id) {
      // vendor ADD happening ===
      if (!name) {
        return res.status(422).json({
          status: false,
          message: "Name is required.",
          data: {},
        });
      }
      if (!initials) {
        return res.status(422).json({
          status: false,
          message: "Vendor initials is required.",
          data: {},
        });
      }
      if (!email) {
        return res.status(422).json({
          status: false,
          message: "Email is required.",
          data: {},
        });
      }
      if (!phone) {
        return res.status(422).json({
          status: false,
          message: "Phone is required.",
          data: {},
        });
      }
    }

    let condition = {
      deletedAt: null,
    };
    if (id) {
      // during edit -> should not check self ===
      condition.id = `{
        [Op.ne]: id
      }`;
    }

    let checkExist = await userModel.findOne({
      attributes: ["firstName", "lastName"],
      where: {
        ...condition,
        [Op.or]: [{ phone: phone }, { email: email }],
      },
    });

    if (checkExist) {
      return res.status(400).json({
        status: false,
        message: "This phone or email is already registered with us..!! Please try with another credentials.",
        data: checkExist,
      });
    }

    // =========== single file upload ================
    let fileName = "";
    if (req.files.profileImage) {
      let image = await fileUploaderSingle(
        "src/public/uploads/userImages/",
        req.files.profileImage
      );
      fileName = image.newfileName;
    }
    // =========== single file upload ================
    
    let role = await roleModel.findOne({
      where: {
        roleName: "Vendor"
      }
    });
    let updateFields = {
      roleId: role.id,
    };
    if (name) {
      updateFields.firstName = name;
      updateFields.lastName = "";
    }
    if (email) {
      updateFields.email = email;
    }
    if (dialCode) {
      updateFields.dialCode = dialCode;
    }
    if (phone) {
      updateFields.phone = phone;
    }
    // === default password for vendors ===
    let defaultPass = "vendorPass@123";
    if (defaultPass) {
      updateFields.password = await bcrypt.hash(defaultPass, 10);
    }
    // === default password for vendors ===
    // if (dob) {
    //   updateFields.dob = dob;
    // }
    // if (gender) {
    //   updateFields.gender = gender;
    // }
    if (address) {
      updateFields.address = address;
    }
    if (fileName != "") {
      updateFields.profileImage = fileName;
    }
    
    let vendorExists = {};
    if(id && id != "" && id != null){
      vendorExists = await vendorModel.findOne({
        where: {
          userId: id
        }
      });
    }
    // ---- user add/update ----
    let updated =
      vendorExists && vendorExists.userId != "" && vendorExists.userId != null
        ? await super.updateById(userModel, vendorExists.userId, updateFields)
        : await super.create(res, userModel, updateFields);
    // ---- user add/update ----

    if (updated) {
      let updatedVendor = {};
      if(id && id != "" && id != null){
        updatedVendor = await super.getByCustomOptionsSingle(req, userModel, {
          where: { 
            id: id 
          },
        });
      } else {
        updatedVendor = await super.getByCustomOptionsSingle(req, userModel, {
          where: { 
            id: updated.id 
          },
        });
      }
      // ==== user successfully added : CREATING VENDOR DATA =====
      let vendorUpdateFields = {
        userId: updatedVendor.id,
        initials: initials,
        isOnsiteChargeApplicable: (isOnsiteChargeApplicable == "1") ? true : false,
      };
      let vendor = {};
      if(id && id != "" && id != null){
        vendor = await super.getByCustomOptionsSingle(req, vendorModel, {
          where: {
            userId: id,
          }
        });
      } else {
        vendor = await super.getByCustomOptionsSingle(req, vendorModel, {
          where: {
            userId: updatedVendor.id,
          }
        });
      }
      let vendorUpdated = 
        id && id != "" && id != null
          ? await super.updateById(vendorModel, vendor.id, vendorUpdateFields)
          : await super.create(res, vendorModel, vendorUpdateFields);
      // ==== user successfully added : CREATING VENDOR DATA =====

      let vendorDetails = {};
      if(vendorUpdated){
        if(id && id != "" && id != null){
          vendorDetails = await vendorModel.findOne({
            where: {
              userId: id,
            }
          });
        } else {
          vendorDetails = await vendorModel.findOne({
            where: {
              userId: vendorUpdated.userId,
            }
          });
        }
      }

      let userDetails = {};
      userDetails = await userModel.findOne({
        where: {
          id: vendorDetails.userId,
        },
        include: [
          {
            model: vendorModel,
            // attributes: ["id", "userId", "initials", "isOnsiteChargeApplicable", "isActive", "isVerified", ],
          }
        ]
      });

      // ====== create permissions START ======
      // let moduleAccessArr = JSON.parse(moduleAccess);
      // if (Array.isArray(moduleAccessArr)) {
      //   // moduleAccess should always be array ========
      //   moduleAccessArr.forEach(async (moduleId) => {
      //     let dataToBeUpdated = {
      //       userId: userDetails.id,
      //       moduleId: moduleId,
      //     };
      //     let checkPermissionExists = await modulePermissionsModel.findOne({
      //       where: {
      //         userId: userDetails.id,
      //         moduleId: moduleId,
      //       },
      //     });
      //     let modulePermissionUpdate =
      //       checkPermissionExists &&
      //       checkPermissionExists != "" &&
      //       checkPermissionExists != null
      //         ? await super.updateById(
      //             modulePermissionsModel,
      //             checkPermissionExists.id,
      //             dataToBeUpdated
      //           )
      //         : await modulePermissionsModel.create(dataToBeUpdated);

      //     if (modulePermissionUpdate) {
      //       console.log("Module permissions created/updated.");
      //     } else {
      //       console.log("Module permissions not affected.");
      //     }
      //   });
      // } else {
      //   return res.status(422).json({
      //     status: false,
      //     message: "moduleAccess variable in payload must be an array.",
      //     data: moduleAccess,
      //   });
      // }
      // ====== create permissions END ======

      if(vendorUpdated){
        return res.status(200).json({
          status: true,
          message: "Successful.",
          data: userDetails,
        });
      } else {
        return res.status(400).json({
          status: false,
          message: "Oops..!! Something wrong happened while creating vendor profile.",
          data: {},
        });
      }

    } else {
      return res.status(400).json({
        status: false,
        message: "Oops..!! Something wrong happened while creating user profile for this vendor.",
        data: {},
      });
    }
  });

  static vendorList = catchAsyncErrors(async (req, res, next) => {
    let options = {
      where: {
        // "$role.roleName$": "Vendor",
        isActive: true,
        deletedAt: null,
      },
      order: [["createdAt", "DESC"]],
      include: [
        // {
        //   model: roleModel, // including associated model
        //   attributes: ["roleName"], // Attributes to select from the included model
        // },
        {
          model: userModel,
          attributes: {
            exclude: [
              "password",
              "webLogin",
              "appLogin",
              "fcmToken",
              "OTP",
              "macAddress",
            ],
          },
        },
      ],
    };
    // let userList = await super.getList(req, userModel, options);
    let vendorList = await super.getList(req, vendorModel, options);
    
    let userImageUrl = process.env.API_URL + "uploads/userImages/";

    if (vendorList.length > 0) {
      return res.status(200).json({
        status: true,
        message: "Data found.",
        data: {
          vendorList: vendorList,
          userImageUrl: userImageUrl,
        },
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No data found.",
        data: {},
      });
    }
  });

  static vendorDetails = catchAsyncErrors(async (req, res, next) => {
    let { id } = req.body;
    let vendorDetail = await super.getByCustomOptionsSingle(req, vendorModel, {
      include: [
        {
          model: userModel, // including associated model
        },
      ],
      where: { 
        id: id 
      },
    });
    if(vendorDetail){
      return res.status(200).json({
        status: true,
        message: "Details found.",
        data: vendorDetail
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No details found.",
        data: {}
      });
    }
  });
}

module.exports = VendorController;
