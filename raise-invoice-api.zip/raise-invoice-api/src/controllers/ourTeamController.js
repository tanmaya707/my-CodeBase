const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const fileUploaderSingle = require("../utils/fileUpload.js").fileUploaderSingle;
const db = require("../models");
const ourTeamModel = db.OurTeamModel;
const { Sequelize, Op } = require("sequelize");
const crypto = require("crypto");
const APPURL = require("../config").APPURL;

class ourTeamModelController extends BaseController {
  constructor() {
    super();
  }

  static getOurTeamList = catchAsyncErrors(async (req, res, next) => {
    let { searchText, page = 1, limit = 5 } = req.body;
    let whereClause = {
      status: true,
      deletedAt: null,
    };
    if (searchText) {
      whereClause[Op.or] = [
        {
          id:
          {
            [Op.like]: `%${searchText}%`
          }
        },
        {
          name:
          {
            [Op.like]: `%${searchText}%`
          }
        }
      ];
    }
    let options = {
      where: whereClause,
      order: [['id', 'DESC']],
      limit: limit,
      offset: (page - 1) * limit

    };

    let testimonialLists = await super.getList(req, ourTeamModel, options);
    const totalCount = await ourTeamModel.count({ where: whereClause });

    if (testimonialLists.length > 0) {
      return res.status(200).json({
        status: true,
        imageUrl: `${APPURL}/uploads/`,
        message: "Data found.",
        data: testimonialLists,
        totalPages: Math.ceil(totalCount / limit),
        currentPage: page
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No data found.",
        data: [],
        totalPages: 0,
        currentPage: page
      });
    }
  });
  static saveOurTeam = catchAsyncErrors(async (req, res, next) => {
    let { id, name, designation, facebook_link, twitter_link, linkedin_link, status } = req.body;
    // =========== single file upload ================
    let fileName = "";
    if (req.files.image) {
      let image = await fileUploaderSingle(
        "src/public/uploads/",
        req.files.image
      );
      fileName = image.newfileName;
    }
    // =========== single file upload ================
    let updateFields = {
      name: name,
      designation: designation,
      facebook_link: facebook_link,
      twitter_link: twitter_link,
      linkedin_link: linkedin_link,
      status: status
    };
    if (fileName) {
      updateFields.image = fileName;
    }

    let updated = null;
    if (id && id != "" && id != null) {
      updated = await super.updateById(ourTeamModel, id, updateFields)
    } else {
      updateFields.uuid = crypto.randomUUID();
      updated = await super.create(res, ourTeamModel, updateFields);
    }
    let message = "";
    if (updated) {
      message = (id && id != "" && id != null) ? "Our Team updated successfully." : "Our Team added successfully.";
    } else {
      message = "Our Team addition failed.";
    }

    if (updated) {
      return res.status(200).json({
        status: true,
        message: message,
        data: updated,
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Oops.. Something wrong happened!",
        data: {},
      });
    }
  });
  static getOurTeamDetails = catchAsyncErrors(async (req, res, next) => {
    const { id, uuid } = req.body;
    let queryConditions = {
      deletedAt: null,
      status: true,
    };

    if (id) {
      queryConditions.id = id
    }
    if (uuid) {
      queryConditions.uuid = uuid
    }

    let testimonialDetails = await super.getByCustomOptionsSingle(req, ourTeamModel, {
      where: queryConditions,
    });

    if (testimonialDetails) {
      return res.status(200).json({
        status: true,
        imageUrl: `${APPURL}/uploads/`,
        message: "Success",
        data: testimonialDetails
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No records found.",
        data: {}
      });
    }
  });
  static deleteOurTeam = catchAsyncErrors(async (req, res, next) => {
    let { uuid } = req.body;

    let ourTeamDetail = await super.getByCustomOptionsSingle(req, ourTeamModel, {
      where: {
        uuid: uuid
      },
      attributes: ["id"],
    });

    if (!ourTeamDetail) {
      return res.status(403).json({
        status: false,
        message: "Not found!",
        data: {},
      });
    }
    let deleted = await super.deleteByCondition(
      ourTeamModel,
      {
        id: ourTeamDetail.id,
      }
    );

    if (deleted) {
      return res.status(200).json({
        status: true,
        message: "Testimonial successfully deleted.",
        data: {}
      });
    } else {
      return res.status(500).json({
        status: false,
        message: "Oops.. something went terribly wrong!",
        data: {}
      });
    }
  });

}

module.exports = ourTeamModelController;
