const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const _ = require('lodash');

const db = require("../models");
const MenuModel = db.MenuModel;
const pageModel = db.PageModel;
const { Sequelize, Op } = require("sequelize");
const crypto = require("crypto");

class menuController extends BaseController {
  constructor() {
    super();
  }

  static getMenuList = catchAsyncErrors(async (req, res, next) => {
    let { searchText, parent_menu, page = 1, limit = 0 } = req.body;
    let whereClause = {
      deletedAt: null,
    };

    if (searchText) {
      whereClause[Op.or] = [
        {
          id:
          {
            [Op.like]: `%${searchText}%`
          }
        },
        {
          menu_title:
          {
            [Op.like]: `%${searchText}%`
          }
        }
      ];
    }

    if (parent_menu) {
      // Set the condition to find records where parent_id is NULL
      whereClause.parent_id = {
        [Op.is]: null // This checks for records where parent_id is NULL
      };
    }

    let options = {
      where: whereClause,
      order: [['order_number', 'ASC']],
      include: [
        {
          model: pageModel,
          attributes: ["id", "page_title"],
          where: {
            deletedAt: null,
            // status: true,
          },
          required: false
        },
        {
          model: MenuModel,
          attributes: ["id", "menu_title"],
          where: {
            deletedAt: null,
            // status: true,
          },
          required: false
        },
      ],

      // limit: limit,
      // offset: (page - 1) * limit
    };

    if(page && limit){
      options.limit = limit;
      options.offset = (page - 1) * limit;
    }

    let menuLists = await super.getList(req, MenuModel, options);
    const totalCount = await MenuModel.count({ where: whereClause });

    if (menuLists.length > 0) {
      return res.status(200).json({
        status: true,
        message: "Data found.",
        data: menuLists,
        totalPages: Math.ceil(totalCount / limit),
        currentPage: page
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No data found.",
        data: [],
        totalPages: 0,
        currentPage: page
      });
    }
  });
  static saveMenu = catchAsyncErrors(async (req, res, next) => {
    const { id, parent_id, page_id, menu_type, menu_group, menu_title,menu_slug, link_type, menu_link, status, order_number } = req.body;

    const slug = menu_title.toLowerCase().replace(/\s+/g, '-').replace(/[^\w-]+/g, '');

    let condition = {
      deletedAt: null,
      menu_title: menu_title
    };
    if (id) {
      condition.id = `{
          [Op.ne]: ${id}
      }`;
    }
    condition.menu_group = menu_group;
    console.log(condition);
    let existMenuCheck = await super.getByCustomOptionsSingle(req, MenuModel, {
      where: {
        ...condition,
      },
    });

    if (existMenuCheck) {
      return res.status(200).json({
        status: false,
        message: "This menu title already exists.",
        data: {}
      });
    }

    const updateFields = {
      menu_type,
      menu_group,
      slug: menu_slug ?? slug,
      menu_title,
      link_type,
      menu_link,
      status,
      order_number
    };

    let updated;
    if (!_.isEmpty(page_id) && (link_type == 1)) {
      updateFields.page_id = page_id;
      updateFields.menu_link = '';
    }
    if (!_.isEmpty(parent_id)) {
      updateFields.parent_id = parent_id;
    }
    // console.log(updateFields);
    if (id) {
      updated = await super.updateById(MenuModel, id, updateFields);
    } else {
      updateFields.uuid = crypto.randomUUID();
      updated = await super.create(res, MenuModel, updateFields);
    }

    const msg = updated
      ? (id ? "Menu updated successfully." : "Menu added successfully.")
      : "Menu addition failed.";

    return res.status(updated ? 200 : 400).json({
      status: !!updated,
      message: updated ? msg : "Oops.. Something wrong happened!",
      data: updated || {},
    });
  });
  static getMenuDetails = catchAsyncErrors(async (req, res, next) => {
    const { id, uuid } = req.body;
    let queryConditions = {
      deletedAt: null,
    };

    if (id) {
      queryConditions.id = id
    }
    if (uuid) {
      queryConditions.uuid = uuid
    }

    let menuDetails = await super.getByCustomOptionsSingle(req, MenuModel, {
      where: queryConditions,
    });

    if (menuDetails) {
      return res.status(200).json({
        status: true,
        message: "Success",
        data: menuDetails
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No records found.",
        data: {}
      });
    }
  });
  static deleteMenu = catchAsyncErrors(async (req, res, next) => {
    let { uuid } = req.body;

    let menuDetail = await super.getByCustomOptionsSingle(req, MenuModel, {
      where: {
        uuid: uuid
      },
      attributes: ["id"],
    });

    if (!menuDetail) {
      return res.status(403).json({
        status: false,
        message: "menu not found!",
        data: {},
      });
    }
    let deleted = await super.deleteByCondition(
      MenuModel,
      {
        id: menuDetail.id,
      }
    );

    if (deleted) {
      return res.status(200).json({
        status: true,
        message: "Page successfully deleted.",
        data: {}
      });
    } else {
      return res.status(500).json({
        status: false,
        message: "Oops.. something went terribly wrong!",
        data: {}
      });
    }
  });

}

module.exports = menuController;
