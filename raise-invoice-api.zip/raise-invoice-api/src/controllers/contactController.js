const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");

const db = require("../models");
const userEnquiryModel = db.UserEnquiries;
const newsletterSubscriptionModel = db.NewsletterSubscriptions;
const { Op } = require("sequelize");
const countryModel = db.Countries;

class contactController extends BaseController {
  constructor() {
    super();
  }
  static getEnquiryList = catchAsyncErrors(async (req, res, next) => {
    let { searchText } = req.body;
    let whereClause = {
      deletedAt: null,
    };
    if(searchText){
      whereClause[Op.or] = [
        {
          id: 
          {
              [Op.like]: `%${searchText}%`
          }
        }, 
        {
          name: 
          {
              [Op.like]: `%${searchText}%`
          }
        }, 
        {
          email: 
          {
              [Op.like]: `%${searchText}%`
          }
        }, 
        {
          phone: 
          {
              [Op.like]: `%${searchText}%`
          }
        }, 
        {
          message: 
          {
              [Op.like]: `%${searchText}%`
          }
        }, 
        {
          companyName: 
          {
              [Op.like]: `%${searchText}%`
          }
        }
      ] ;
    }
    let options = {
      where: whereClause,
      include: [
        {
          model: countryModel,
          attributes: ["name"], 
        },
      ],
      order: [["id", "ASC"]],
    };

    let enquiryList = await super.getList(req, userEnquiryModel, options);

    if (enquiryList.length > 0) {
      return res.status(200).json({
        status: true,
        message: "Data found.",
        data: enquiryList,
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No data found.",
        data: [],
      });
    }
  });
  static getEnquiryDetails = catchAsyncErrors(async (req, res, next) => {
    const { id, uuid } = req.body;
    let queryConditions = {
      deletedAt: null,
    };

    if(id){
      queryConditions.id = id
    }
    if(uuid){
      queryConditions.uuid = uuid
    }

    let enquiryDetails = await super.getByCustomOptionsSingle(req, userEnquiryModel, {
      where: queryConditions,
      include: [
        {
          model: countryModel,
          attributes: ["name"], 
        },
      ],
    });
  
    if(enquiryDetails){
      return res.status(200).json({
        status: true,
        message: "Success",
        data: enquiryDetails
      });
    } else{
      return res.status(200).json({
        status: false,
        message: "No records found.",
        data: {}
      });
    }
  });
  static markEnquiryRead = catchAsyncErrors(async (req, res, next) => {
    let { enquiryIds } = req.body;

    let updated = null;
    if(enquiryIds){
      updated = await userEnquiryModel.update({isSeen: 1}, {
        where: {
          id: {
            [Op.in]: enquiryIds
          }
        },
      });
    }
    if (updated) {
      return res.status(200).json({
        status: true,
        message: 'Enquiries marked as read successfully.',
        data: [],
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Oops.. Something wrong happened!",
        data: {},
      });
    }
  });
  static deleteEnquiry = catchAsyncErrors(async (req, res, next) => {
    let { uuid } = req.body;

    let enquiryDetail = await super.getByCustomOptionsSingle(req, userEnquiryModel, {
      where: { 
        uuid: uuid 
      },
      attributes: ["id"],
    });
    
    if(!enquiryDetail){
      return res.status(403).json({
        status: false,
        message: "Enquiry not found!",
        data: {},
      });
    } 
    let deleted = await super.deleteByCondition(
      userEnquiryModel, 
      {
        id: enquiryDetail.id,
      }
    );

    if(deleted){
      return res.status(200).json({
        status: true,
        message: "Enquiry successfully deleted.",
        data: {}
      });
    } else {
      return res.status(500).json({
        status: false,
        message: "Oops.. something went terribly wrong!",
        data: {}
      });
    }
  });

  static getNewsletterSubscriptions = catchAsyncErrors(async (req, res, next) => {
    let { searchText, subscriptionStatus, page = 1, limit = 0 } = req.body;
    let whereClause = {
      deletedAt: null,
    };
    if(subscriptionStatus != "" && subscriptionStatus != null && subscriptionStatus != 'null'){
      whereClause.subscriptionStatus = subscriptionStatus;
    }
    if(searchText){
      whereClause[Op.or] = [
        {
          id: 
          {
              [Op.like]: `%${searchText}%`
          }
        },
        {
          email: 
          {
              [Op.like]: `%${searchText}%`
          }
        },
      ] ;
    }
    let options = {
      where: whereClause,
      order: [["id", "ASC"]],
    };
    if(page && limit){
      options.limit = limit;
      options.offset = (page - 1) * limit;
    }

    let subscriptionList = await super.getList(req, newsletterSubscriptionModel, options);
    const totalCount = await newsletterSubscriptionModel.count({ where: whereClause });

    if (subscriptionList.length > 0) {
      return res.status(200).json({
        status: true,
        message: "Data found.",
        data: subscriptionList,
        totalPages: Math.ceil(totalCount / limit),
        totalCount: totalCount,
        currentPage: page
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No data found.",
        data: [],
        totalPages: 0,
        totalCount: 0,
        currentPage: page
      });
    }
  });
  static getNewsletterSubscriptionDetails = catchAsyncErrors(async (req, res, next) => {
    const { id, uuid } = req.body;
    let queryConditions = {
      deletedAt: null,
    };

    if(id){
      queryConditions.id = id
    }
    if(uuid){
      queryConditions.uuid = uuid
    }

    let subscriptionDetails = await super.getByCustomOptionsSingle(req, newsletterSubscriptionModel, {
      where: queryConditions,
    });
  
    if(subscriptionDetails){
      return res.status(200).json({
        status: true,
        message: "Success",
        data: subscriptionDetails
      });
    } else{
      return res.status(200).json({
        status: false,
        message: "No records found.",
        data: {}
      });
    }
  });
  static deleteNewsletterSubscription = catchAsyncErrors(async (req, res, next) => {
    let { uuid } = req.body;

    let subscriptionDetail = await super.getByCustomOptionsSingle(req, newsletterSubscriptionModel, {
      where: { 
        uuid: uuid 
      },
      attributes: ["id"],
    });
    
    if(!subscriptionDetail){
      return res.status(403).json({
        status: false,
        message: "Subscription not found!",
        data: {},
      });
    } 
    let deleted = await super.deleteByCondition(
      newsletterSubscriptionModel, 
      {
        id: subscriptionDetail.id,
      }
    );

    if(deleted){
      return res.status(200).json({
        status: true,
        message: "Subscription successfully deleted.",
        data: {}
      });
    } else {
      return res.status(500).json({
        status: false,
        message: "Oops.. something went terribly wrong!",
        data: {}
      });
    }
  });
  static saveNewsletterSubscriptionDetails = catchAsyncErrors(async (req, res, next) => {
    let { uuid, subscriptionStatus } = req.body;

    let updateFields = {
      subscriptionStatus: subscriptionStatus
    };
    let updated = null;
    let message = '';
    if(uuid && uuid != "" && uuid != null && uuid != 'null'){
      updated = await super.updateByCustomOptions(newsletterSubscriptionModel, {uuid: uuid}, updateFields)
      message = 'Subscription status successfully updated.'
    }

    if (updated) {
      return res.status(200).json({
        status: true,
        message: message,
        data: [],
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Oops.. Something wrong happened!",
        data: {},
      });
    }
  });
}

module.exports = contactController;
