const BaseController = require("../BaseController");
const catchAsyncErrors = require("../../middleware/catchAsyncErrors");

const db = require("../../models");
const NewsLetterModel = db.NewsLetterModel;
const FeedbackHomeModel = db.FeedbackHomeModel;
const NavMenuModel = db.MenuModel;
const { Op } = require("sequelize");
const crypto = require("crypto");
const { slugify } = require("../../utils/utilities");

class homeController extends BaseController {
  constructor() {
    super();
  }

  static saveNewletterUser = catchAsyncErrors(async (req, res, next) => {
    const { id, email_address } = req.body;

    if (!email_address) {
      return res.status(422).json({
        status: false,
        message: "Email address is required.",
        data: {},
      });
    }

    const condition = {
      deletedAt: null,
      email_address: email_address,
    };

    if (id) {
      condition.id = {
        [Op.ne]: id, // Use Sequelize operator correctly
      };
    }

    const checkExist = await NewsLetterModel.findOne({
      attributes: ["email_address"],
      where: condition,
    });

    if (checkExist) {
      return res.status(400).json({
        status: false,
        message: "This email address already exists!",
        data: checkExist,
      });
    }

    const updateFields = { email_address };
    let message = '';
    let updated;

    if (id) {
      updated = await super.updateById(NewsLetterModel, id, updateFields);
      message = 'Newsletter updated successfully';
    } else {
      updateFields.uuid = crypto.randomUUID();
      updated = await super.create(res, NewsLetterModel, updateFields);
      message = 'Newsletter added successfully';
    }

    const newsLetterId = id || updated.id;
    const newsLetterDetails = await NewsLetterModel.findOne({
      where: { id: newsLetterId }
    });

    return res.status(200).json({
      status: true,
      message,
      data: newsLetterDetails,
    });
  });

  static getHomeFeedbackList = catchAsyncErrors(async (req, res, next) => {
    let { searchText } = req.body;
    let whereClause = {
      status: true,
      deletedAt: null,
    };
    if (searchText) {
      whereClause[Op.or] = [
        {
          id:
          {
            [Op.like]: `%${searchText}%`
          }
        },
        {
          name:
          {
            [Op.like]: `%${searchText}%`
          }
        }
      ];
    }
    let options = {
      where: whereClause,
      order: [["title", "ASC"]],
    };

    let feeadBackLists = await super.getList(req, FeedbackHomeModel, options);

    if (feeadBackLists.length > 0) {
      return res.status(200).json({
        status: true,
        message: "Data found.",
        data: feeadBackLists,
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No data found.",
        data: [],
      });
    }
  });

  static navMenuList = catchAsyncErrors(async (req, res, next) => {
    const { menu_type, page = 1, limit = 10 } = req.body;
    let whereClause = {
      status: true,
      menu_type: menu_type,
      deletedAt: null,
    };
    let options = {
      where: whereClause,
      order: [['order_number', 'ASC']],
      limit: limit,
      offset: (page - 1) * limit,
      attributes: ['id', 'uuid', 'menu_type', 'menu_title', 'menu_group', 'slug', 'link_type', 'menu_link']
    };

    let navMenuLists = await super.getList(req, NavMenuModel, options);

    // Get the total count of records for pagination
    const totalCount = await NavMenuModel.count({ where: whereClause });

    if (navMenuLists.length > 0) {
      return res.status(200).json({
        status: true,
        message: "Menu List Data found.",
        data: navMenuLists,
        totalPages: Math.ceil(totalCount / limit),
        currentPage: page
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No data found.",
        data: [],
        totalPages: 0,
        currentPage: page
      });
    }
  });

  static navMenuList = catchAsyncErrors(async (req, res, next) => {
    const { menu_type, page = 1, limit = 10 } = req.body;
    let whereClause = {
      status: true,
      menu_type: menu_type,
      deletedAt: null,
    };
    let options = {
      where: whereClause,
      order: [['order_number', 'ASC']],
      limit: limit,
      offset: (page - 1) * limit,
      attributes: ['id', 'uuid', 'menu_type', 'menu_title', 'menu_group', 'slug', 'link_type', 'menu_link']
    };

    let navMenuLists = await super.getList(req, NavMenuModel, options);

    // Get the total count of records for pagination
    const totalCount = await NavMenuModel.count({ where: whereClause });

    if (navMenuLists.length > 0) {
      return res.status(200).json({
        status: true,
        message: "Menu List Data found.",
        data: navMenuLists,
        totalPages: Math.ceil(totalCount / limit),
        currentPage: page
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No data found.",
        data: [],
        totalPages: 0,
        currentPage: page
      });
    }
  });

  static navMenuDetails = catchAsyncErrors(async (req, res, next) => {
    const { menu_uuid } = req.body;
    let queryConditions = {
      uuid: menu_uuid,
      deletedAt: null,
      status: true,
    };

    let navMenuDetails = await super.getByCustomOptionsSingle(req, NavMenuModel, {
      where: queryConditions
    });

    if (navMenuDetails) {
      return res.status(200).json({
        status: true,
        message: "Success",
        data: navMenuDetails
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No records found.",
        data: {}
      });
    }
  });

}

module.exports = homeController;
