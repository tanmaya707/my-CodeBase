const BaseController = require("../BaseController");
const catchAsyncErrors = require("../../middleware/catchAsyncErrors");

const db = require("../../models");
const itemsModel = db.Items;
const { Op } = require("sequelize");
const crypto = require("crypto");
const mysqlConfig = require("../../config/index").Mysql;
const Currency = db.Currency;
const Units = db.Units;
const Times = db.Times;
const clientModel = db.Clients;

const { connectSpecificToDatabase } = require("../../config/specificConnect");
const fileUploaderSingle = require("../../utils/fileUpload").fileUploaderSingle;

class itemController extends BaseController {
    constructor() {
        super();
    }

    // Create Item API
    static createItem = catchAsyncErrors(async (req, res, next) => {
        const { item_name, item_Description, rate, currency, qty, unit_code, tax, time, time_units } = req.body;

        if (!item_name || !item_Description) {
            return res.status(404).json({ status: false, message: 'item_name or item_Description not found' });
        }

        const userId = req.user.id;
        const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);

        if (error) {
            return res.status(404).json({ status: false, message: error });
        }

        const transaction = await connection.sequelize.transaction();

        try {
            let itemFields = {};
            let fileName = "";

            if (req.files && req.files.document) {
                let image = await fileUploaderSingle("src/public/uploads/", req.files.document);
                fileName = image.newfileName;
            }

            const uuid = crypto.randomUUID();
            itemFields = {
                uuid,
                item_name,
                item_Description,
                rate,
                currency,
                qty,
                unit_code,
                tax,
                time,
                time_units,
                profileImage: fileName || null
            };

            const itemCreated = await super.create(res, connection.Items, itemFields, { transaction });

            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Items Added successfully.",
                data: itemCreated
            });
        } catch (error) {
            await transaction.rollback();
            console.error('Error creating Items:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });

    //Update Items
    static updateItems = catchAsyncErrors(async (req, res, next) => {
        const { id, item_name, item_Description, rate, currency, qty, unit_code, tax, time, time_units } = req.body;

        if (!item_name || !item_Description) {
            return res.status(400).json({
                status: false,
                message: "item_name or item_Description are missing.",
                data: {}
            });
        }

        const userId = req.user.id;
        const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);

        if (error) {
            return res.status(404).json({ status: false, message: error });
        }

        const transaction = await connection.sequelize.transaction();

        try {
            const updateFields = {
                item_name,
                item_Description,
                rate,
                currency,
                qty,
                unit_code,
                tax,
                time,
                time_units,
            };

            const [updatedItemsCount] = await connection.Items.update(updateFields, {
                where: { id: id },
                transaction
            });

            const updatedItem = await connection.Items.findOne({
                where: { id: id },
                transaction
            });

            if (updatedItemsCount === 0) {
                return res.status(404).json({ status: false, message: "Item not found or no changes made." });
            }

            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Item updated successfully.",
                data: updatedItem
            });
        } catch (error) {
            await transaction.rollback();
            console.error("Error updating Items:", error);
            return res.status(500).json({
                status: false,
                message: "An error occurred while updating the item.",
                data: {}
            });
        }
    });

    // List All Items API
    static listAllItems = catchAsyncErrors(async (req, res, next) => {
        const userId = req.user.id;
        const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);

        if (error) {
            return res.status(404).json({ status: false, message: error });
        }

        try {
            const items = await connection.Items.findAll({
                order: [['created_at', 'DESC']]
            });

            // Add full image URL to the response
            const itemsWithImageURL = items.map(item => ({
                ...item.toJSON(),
                profileImage: item.profileImage ? `${req.protocol}://${req.get('host')}/uploads/${item.profileImage}` : null
            }));

            return res.status(200).json({
                status: true,
                message: "Items retrieved successfully.",
                data: itemsWithImageURL,
            });
        } catch (error) {
            console.error("Error fetching Items:", error);
            return res.status(500).json({
                status: false,
                message: "Oops... something went terribly wrong!",
                data: {}
            });
        }
    });

    //Fetch Single Item Data
    static itemDetails = catchAsyncErrors(async (req, res, next) => {
        const { id } = req.body;

        const userId = req.user.id;
        const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);

        if (error) {
            return res.status(404).json({ status: false, message: error });
        }

        try {
            const item = await connection.Items.findOne({ where: { id: id } });

            if (!item) {
                return res.status(404).json({ status: false, message: "Item not found." });
            }

            return res.status(200).json({
                status: true,
                message: "Item details retrieved successfully.",
                data: item
            });
        } catch (error) {
            console.error("Error fetching item details:", error);
            return res.status(500).json({
                status: false,
                message: "An error occurred while retrieving item details.",
                data: {}
            });
        }
    });

    //Delet items
    static deletItems = catchAsyncErrors(async (req, res, next) => {
        const { uuid } = req.body;

        const userId = req.user.id;
        const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);

        if (error) {
            return res.status(404).json({ status: false, message: error });
        }

        const transaction = await connection.sequelize.transaction();

        try {
            const deletedItemCount = await connection.Items.destroy({
                where: { uuid: uuid },
                transaction
            });

            if (!deletedItemCount) {
                return res.status(404).json({ status: false, message: "Item not found." });
            }

            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Item deleted successfully."
            });
        } catch (error) {
            await transaction.rollback();
            console.error("Error deleting Item:", error);
            return res.status(500).json({
                status: false,
                message: "An error occurred while deleting the item.",
                data: {}
            });
        }
    });

    static getConnectionForClient = async (userId, mysqlConfig) => {
        try {
            // Fetch user and their database name
            const user = await clientModel.findOne({
                attributes: ['id', 'database_name'],
                where: { id: userId }
            });

            if (!user) {
                return { error: 'User not found', connection: null };
            }

            const db_name = user.database_name;
            if (!db_name) {
                return { error: 'Please create your company first before accessing this resource.', connection: null };
            }

            // Establish connection
            const connection = await connectSpecificToDatabase(
                db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
            );

            return { error: null, connection };
        } catch (err) {
            console.error("Error in getConnectionForClient:", err);
            return { error: 'Failed to establish a connection.', connection: null };
        }
    };

    //currency Management
    static currencyList = catchAsyncErrors(async (req, res, next) => {

        try {
            const currencyList = await Currency.findAll({
                where: {
                    status: 1
                }
            });

            return res.status(200).json({
                status: true,
                message: "Currency list retrieved successfully.",
                data: currencyList,
            });
        } catch (error) {
            console.error("Error fetching currency list:", error);
            return res.status(500).json({
                status: false,
                message: "An error occurred while retrieving the currency list.",
                data: {}
            });
        }
    });

    static createCurrency = catchAsyncErrors(async (req, res, next) => {
        const { currency_name, currency_code, symbol } = req.body;

        if (!currency_name || !currency_code || !symbol) {
            return res.status(400).json({
                status: false,
                message: "currency_name, currency_code or symbol are missing.",
                data: {}
            });
        }

        try {
            const currencyFields = {
                currency_name,
                currency_code,
                symbol
            };

            const currencyCreated = await super.create(res, Currency, currencyFields);

            return res.status(200).json({
                status: true,
                message: "Currency created successfully.",
                data: currencyCreated
            });
        } catch (error) {
            console.error('Error creating Currency:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });

    //Units Management
    static unitList = catchAsyncErrors(async (req, res, next) => {

        try {
            const unitList = await Units.findAll({
                where: {
                    status: 1
                }
            });

            return res.status(200).json({
                status: true,
                message: "Unit list retrieved successfully.",
                data: unitList,
            });
        } catch (error) {
            console.error("Error fetching unit list:", error);
            return res.status(500).json({
                status: false,
                message: "An error occurred while retrieving the unit list.",
                data: {}
            });
        }
    });

    static createUnit = catchAsyncErrors(async (req, res, next) => {
        const { unit_name, unit_code, symbol } = req.body;

        if (!unit_name || !unit_code) {
            return res.status(400).json({
                status: false,
                message: "unit_name or unit_code are missing.",
                data: {}
            });
        }

        try {
            const unitFields = {
                unit_name,
                unit_code,
                symbol
            };

            const unitCreated = await super.create(res, Units, unitFields);

            return res.status(200).json({
                status: true,
                message: "Unit created successfully.",
                data: unitCreated
            });
        } catch (error) {
            console.error('Error creating Unit:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });

    //Times Management
    static timeList = catchAsyncErrors(async (req, res, next) => {

        try {
            const timeList = await Times.findAll({
                where: {
                    status: 1
                }
            });

            return res.status(200).json({
                status: true,
                message: "Time list retrieved successfully.",
                data: timeList,
            });
        } catch (error) {
            console.error("Error fetching time list:", error);
            return res.status(500).json({
                status: false,
                message: "An error occurred while retrieving the time list.",
                data: {}
            });
        }
    });

    static createTime = catchAsyncErrors(async (req, res, next) => {
        const { time_units } = req.body;

        if (!time_units) {
            return res.status(400).json({
                status: false,
                message: "time_units are missing.",
                data: {}
            });
        }

        try {
            const timeFields = {
                time_units
            };

            const timeCreated = await super.create(res, Times, timeFields);

            return res.status(200).json({
                status: true,
                message: "Time created successfully.",
                data: timeCreated
            });
        } catch (error) {
            console.error('Error creating Time:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });
}

module.exports = itemController;
