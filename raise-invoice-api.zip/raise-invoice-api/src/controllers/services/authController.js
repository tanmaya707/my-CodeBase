const BaseController = require("../BaseController");
const catchAsyncErrors = require("../../middleware/catchAsyncErrors");
const bcrypt = require('bcryptjs')
const db = require("../../models");
const clientModel = db.Clients;
const userCompanyModel = db.UserCompanies;
const planModel = db.Plans;
const planPriceModel = db.PlanPrices;
const userModel = db.Users;
const currencyModel = db.Currency;
const sendMail = require("../../helpers/email.js");
const { Op } = require("sequelize");
const crypto = require("crypto");
const { createDatabase, updateDatabase, getConnectedSpecificDB, generateUniqueAccountId } = require("../../utils/utilities");
const JWTAuth = require("../../utils/jwtToken");
const mysqlConfig = require("../../config/index").Mysql;
const fileUploaderSingle = require("../../utils/fileUpload.js").fileUploaderSingle;
const { connectSpecificToDatabase } = require("../../config/specificConnect");
const { log, time } = require("console");

class authController extends BaseController {
    constructor() {
        super();
    }
    /****
     **** Client Management Section
     ****/
    static clientSignUp = catchAsyncErrors(async (req, res, next) => {
        var {
            deviceType,
            name,
            email,
            password
        } = req.body;

        let condition = {
            deletedAt: null,
        };

        let checkExist = await clientModel.findOne({
            attributes: ["name"],
            where: {
                ...condition,
                [Op.or]: [{ email: email }],
            },
        });

        if (checkExist) {
            return res.status(200).json({
                status: false,
                message: "Client already exist!",
                data: checkExist,
            });
        }


        if (!name) {
            return res.status(422).json({
                status: false,
                message: "Name is required.",
                data: {},
            });
        }
        if (!email) {
            return res.status(422).json({
                status: false,
                message: "Email is required.",
                data: {},
            });
        }
        // if (!phone) {
        //     return res.status(422).json({
        //         status: false,
        //         message: "Phone number is required.",
        //         data: {},
        //     });
        // }

        if (!password) {
            return res.status(422).json({
                status: false,
                message: "Password is required.",
                data: {},
            });
        }

        let updateFields = {};

        if (name) {
            updateFields.name = name;
        }
        if (email) {
            updateFields.email = email;
        }
        // if (phone) {
        //     updateFields.phone = phone;
        // }
        if (password) {
            updateFields.password = await bcrypt.hash(password, 10);
        }

        updateFields.account_id = await generateUniqueAccountId();
        updateFields.uuid = crypto.randomUUID();

        var updated = await super.create(res, clientModel, updateFields);

        var token = JWTAuth.ClientSign({
            id: updated?.id,
            uuid: updateFields.uuid,
            name: name,
            email: email,
            deviceType: deviceType,
            isVerified: false,
            isSubscribed: false
        });
        let clientpUdateFields = {};
        if (Number(deviceType) == 2) {
            clientpUdateFields.webLogin = token;
        } else {
            clientpUdateFields.appLogin = token;
        }

        var clientpUdate = await super.updateById(clientModel, updated?.id, clientpUdateFields);

        let userDetails = await clientModel.findOne({
            attributes: ["id", "uuid", "name", "email", "isActive", "isVerified", "profileImage"],
            where: {
                id: updated?.id,
            }
        });

        const to = userDetails?.email;
        const subject = "Registration Confirmation";

        const body = `Dear ${userDetails?.name},<br><br>
            I hope this message finds you well.<br><br>
            We are pleased to confirm your registration with Raise Invoice. Below are the details we have on file:<br><br>
            <strong>Name:</strong> ${userDetails?.name}<br>
            <strong>Email Address:</strong> ${userDetails?.email}<br><br>
            If any of the above information is incorrect or needs updating, please let us know at your earliest convenience.<br><br>
            We look forward to working with you and providing the best possible service. Should you have any questions or require assistance, feel free to reach out to us.<br><br>
            Warm regards,<br>
            Raise Invoice<br>
            Customer Support Team
        `;

        if (userDetails) {
            try {
                await sendMail(to, null, null, subject, null, body, false);
            } catch (error) {
                console.log("Email sending error:", error);
            }
            return res.status(200).json({
                status: true,
                message: "Successful.",
                data: { userDetails, deviceType, deviceToken: token },
            });
        } else {
            return res.status(400).json({
                status: false,
                message: "Oops.. Something wrong happened!",
                data: {},
            });
        }
    });

    static clientCreateProfile = catchAsyncErrors(async (req, res, next) => {
        var {
            comapnyId,
            companyName,
            companyAddress,
            companyPhone,
            companyEmail,
            companyWebsite,
            companyInfo,
            legalBusinessName,
            businessAddress,
            businessPhone,
            noOfEmployee
        } = req.body;

        let condition = {
            deletedAt: null,
        };

        // var userDetailCheck = await super.getByCustomOptionsSingle(req, userCompanyModel, {
        //     where: {
        //         companyName: companyName
        //     }
        // });

        // if (!comapnyId && userDetailCheck) {
        //     return res.status(200).json({
        //         status: false,
        //         message: "Company name already exists!",
        //         data: {}
        //     });
        // }

        if (!companyName) {
            return res.status(422).json({
                status: false,
                message: "Company name is required.",
                data: {},
            });
        }
        if (!companyAddress) {
            return res.status(422).json({
                status: false,
                message: "Company address is required.",
                data: {},
            });
        }
        if (!companyPhone) {
            return res.status(422).json({
                status: false,
                message: "Company phone number is required.",
                data: {},
            });
        }
        if (!companyEmail) {
            return res.status(422).json({
                status: false,
                message: "Company email is required.",
                data: {},
            });
        }

        let companyNameSlug = '';
        let userId = req.user.id;
        let updateCompanyFields = {};

        if(!comapnyId){
            // Convert company name to a slug format
            companyNameSlug = companyName.toLowerCase()
                .replace(/\s+/g, '_')
                .replace(/[^\w_]+/g, '');
            // Append unique ID to the slug
            const uniqueId = Date.now();
            companyNameSlug = companyNameSlug + '_' + uniqueId;
            // Prepare fields for database update
            let updateFields = {};
            if (companyNameSlug) {
                updateFields.database_name = companyNameSlug;
                updateFields.isVerified = true;
            }
            if (userId) {
                await super.updateById(clientModel, userId, updateFields);
            }
        }else{
            let clientAdmin = await clientModel.findOne({
                attributes: ["database_name"],
                where: {
                    id: userId
                },
            });            
            companyNameSlug = clientAdmin?.database_name;
        }   

        let companyData = await userCompanyModel.findOne({
            attributes: ["id"],
            where: {
                userId: userId
            },
        });

        updateCompanyFields.userId = userId;
        if (companyName) {
            updateCompanyFields.companyName = companyName
        }
        if (companyAddress) {
            updateCompanyFields.companyAddress = companyAddress
        }
        if (companyPhone) {
            updateCompanyFields.companyPhone = companyPhone
        }
        if (companyEmail) {
            updateCompanyFields.companyEmail = companyEmail
        }
        if (companyWebsite) {
            updateCompanyFields.companyWebsite = companyWebsite
        }
        if (companyInfo) {
            updateCompanyFields.companyInfo = companyInfo
        }
        if (legalBusinessName) {
            updateCompanyFields.legalBusinessName = legalBusinessName
        }
        if (businessAddress) {
            updateCompanyFields.businessAddress = businessAddress
        }
        if (businessPhone) {
            updateCompanyFields.businessPhone = businessPhone
        }
        if (noOfEmployee) {
            updateCompanyFields.noOfEmployee = noOfEmployee
        }
        if (companyData) {
            await super.updateById(userCompanyModel, companyData.id, updateCompanyFields)
        } else {
            updateCompanyFields.uuid = crypto.randomUUID();
            await super.create(res, userCompanyModel, updateCompanyFields);
        }

        
        let clientCompanyData = await userCompanyModel.findOne({
            where: {
                userId: userId
            },
        });
        let clientUserData = await clientModel.findOne({
            where: {
                id: userId
            },
        });
        let defaultCurrencyData = await currencyModel.findOne({
            where: {
                isDefault: 1
            },
        });
        if (!comapnyId) {
            console.log("db creation");
            await createDatabase(companyNameSlug, clientUserData, clientCompanyData, defaultCurrencyData);
        }else{
            // console.log('clientCompanyData', clientCompanyData);
            await updateDatabase(companyNameSlug, clientUserData, clientCompanyData);
        }

        if (clientCompanyData) {
            return res.status(200).json({
                status: true,
                message: "Successful.",
                data: { clientCompanyData, defaultCurrencyData }
            });
        } else {
            return res.status(400).json({
                status: false,
                message: "Oops.. Something wrong happened!",
                data: {},
            });
        }
    });

    static clientUpdateProfile = catchAsyncErrors(async (req, res, next) => {
        let userId = req.user.id;

        let user = await clientModel.findOne({
            attributes: ['id', 'uuid', 'name', 'password', 'isVerified', 'database_name', 'email'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({
                status: false,
                message: "Client not found!",
                data: null,
            });
        }
        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        // const { sequelize2, ClientSubscriptionModel } = await connectSpecificToDatabase(user.database_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306');
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );
        let languageAddUpdate = null;
        let taxSecurutyAddUpdate = null;
        const clientAdmin = await connection.ClientAdmin.findOne({
            where: { email: user.email }
        });

        // userId = req.user.id;
        userId = clientAdmin.id;
        if (req.body.languageId) {
            const existingLanguageDetail = await connection.UserLanguage.findOne({
                where: {
                    userId: userId
                }
            });

            if (existingLanguageDetail) {
                await connection.UserLanguage.update(
                    { languageId: req.body.languageId },
                    { where: { userId: userId } }
                );
                languageAddUpdate = await connection.UserLanguage.findOne({ where: { userId: userId } });
            } else {
                languageAddUpdate = await connection.UserLanguage.create({
                    userId: userId,
                    languageId: req.body.languageId
                });
            }
        }

        if (req.body.countryId && req.body.currency) {
            const existingTaxSecurityDetail = await connection.CompanyTaxSecurity.findOne({ where: { userId: userId } });
            let addUpdate = {
                countryId: req.body.countryId,
                currency: req.body.currency,
                gst_no: req.body.gst_no,
                co_reg_no: req.body.co_reg_no,
                pan_no: req.body.pan_no,
                tax_year_month: req.body.tax_year_month,
                tax_year_day: req.body.tax_year_day,
                gst_rate: req.body.gst_rate,
                enable_withholding_tax: req.body.enable_withholding_tax
            };

            if (!existingTaxSecurityDetail) {
                addUpdate = { ...addUpdate, userId: userId };
                taxSecurutyAddUpdate = await connection.CompanyTaxSecurity.create(addUpdate);
            } else {
                await connection.CompanyTaxSecurity.update(addUpdate, { where: { userId: userId } });
                taxSecurutyAddUpdate = await connection.CompanyTaxSecurity.findOne({ where: { userId: userId } });
            }
        }

        return res.status(200).json({
            status: true,
            message: "Updated Successfuly!",
            data: { languageAddUpdate, taxSecurutyAddUpdate }
        });
    });

    static clientSignIn = catchAsyncErrors(async (req, res, next) => {
        const { email, password, deviceType } = req.body;

        const user = await clientModel.findOne({ attributes: ['id', 'uuid', 'name', 'password', 'isVerified', 'database_name', 'profileImage'], where: { email } });

        if (!user) {
            return res.status(200).json({
                status: false,
                message: "Client not found!",
                data: null,
            });
        }

        const passwordMatch = await bcrypt.compare(password, user.password);
        if (!passwordMatch) {
            return res.status(200).json({
                status: false,
                message: "Authentication failed!",
                data: null,
            });
        }

        var token = JWTAuth.ClientSign({
            id: user?.id,
            uuid: user.uuid,
            name: user.name,
            email: email,
            deviceType: deviceType,
            isVerified: user.isVerified
        });
        let clientpUdateFields = {};
        if (Number(deviceType) == 2) {
            clientpUdateFields.webLogin = token;
        } else {
            clientpUdateFields.appLogin = token;
        }
        var clientpUdate = await super.updateById(clientModel, user?.id, clientpUdateFields);
        let userSubscription = {}
        let companyTaxDetails = {}

        //////////////////////////////////////////////////////////////////////////////////////////////////

        /******************************* Specific DB Connected Start ************************************/
        if (user?.database_name) {
            const db_name = user.database_name;
            if (!db_name) {
                return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
            }
            const sequelize = await getConnectedSpecificDB(db_name);
            const connection = await connectSpecificToDatabase(
                db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
            );
            userSubscription = await connection.UserCompany.findAll({});
            companyTaxDetails = await connection.CompanyTaxSecurity.findOne();

            /******************************* Specific DB Connected End ************************************/

            const asasasa = await clientModel.findAll({ attributes: ['id', 'uuid', 'name'] });
            const [results, metadata] = await sequelize.query("SELECT id, uuid, name FROM clientadmins");

            if (sequelize) {
                await sequelize.close();
            }
        }
        //////////////////////////////////////////////////////////////////////////////////////////////////

        return res.status(200).json({
            status: true,
            message: "Login successful.",
            data: {
                user: {
                    "id": user.id,
                    "uuid": user.uuid,
                    "name": user.name,
                    "isVerified": false,
                    "isSubscribed": false,
                    "isCompanyCreated": userSubscription.length > 0 ? true : false,
                    "database_name": user?.database_name ?? null,
                    "profileImage": user?.profileImage ?? '',
                    "companyTaxDetails": companyTaxDetails
                }, deviceToken: token
            },
        });
    });

    static clientProfile = catchAsyncErrors(async (req, res, next) => {
        let userId = req.user.id;
        // console.log("userIduserId", userId);
        let user = await clientModel.findOne({
            attributes: ['id', 'uuid', 'account_id', 'name', 'phone', 'email', 'password', 'isVerified', 'database_name', 'dialCode', 'phone', 'profileImage'],
            where: { id: userId }
        });

        const profileImage = user.profileImage ? `${req.protocol}://${req.get('host')}/uploads/user/${user.profileImage}` : null

        let userCompany = null;
        const str = user.database_name;
        if (str) {
            const companyNameCheck = str.split("_").join(" ");

            userCompany = await userCompanyModel.findOne({
                where: { userId: userId }
            });
        }

        if (!user) {
            return res.status(404).json({
                status: false,
                message: "Client not found!",
                data: null,
            });
        }
        const db_name = user.database_name;
        // if (!db_name) {
        //     return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.' ,data:{}});
        // }
        // const { sequelize2, ClientSubscriptionModel } = await connectSpecificToDatabase(user.database_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306');

        let userSubscription = {};
        let companyLanguageDetails = {};
        let companyTaxDetails = {};
        let isSecurity = false;
        let clientCreation = false;
        let invoiceCreation = false;
        let plan = null;
        let daysLeft = null;
        if (db_name) {
            const connection = await connectSpecificToDatabase(
                db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
            );

            const clientAdmin = await connection.ClientAdmin.findOne({
                where: { email: user.email }
            });

            if (clientAdmin) {
                // console.log(db_name, clientAdmin);
                // userId = req.user.id;
                userId = clientAdmin.id;

                // console.log("userIduserIduserId", userId);

                userSubscription = await connection.Subscription.findOne({
                    where: { userId: userId }
                });
                // console.log(userSubscription);

                companyLanguageDetails = await connection.UserLanguage.findOne({
                    where: { userId: userId }
                });
                companyTaxDetails = await connection.CompanyTaxSecurity.findOne({
                    where: { userId: userId }
                });

                if (userSubscription) {
                    plan = await planModel.findOne({
                        where: { id: userSubscription.subscriptionId },
                        attributes: ['id', 'uuid', 'name']
                    });

                    const startDate = new Date(userSubscription.startDate);
                    const endDate = new Date(userSubscription.endDate);
                    const currentDate = new Date();
                    // Calculate the difference in milliseconds
                    const differenceInMilliseconds = endDate - currentDate;
                    // console.log(differenceInMilliseconds);

                    // Convert milliseconds to days
                    daysLeft = Math.ceil(differenceInMilliseconds / (1000 * 60 * 60 * 24));
                }

                user.isSubscribed = userSubscription ? true : false;

                isSecurity = false;

                clientCreation = await connection.Client.findOne({
                    where: { created_by: userId }
                }) ? true : false;

                invoiceCreation = await connection.Invoice.findOne({
                    where: { client_id: userId }
                }) ? true : false;
            }
        }

        const { password, ...userData } = user.get({ plain: true });
        // console.log(user);
        return res.status(200).json({
            status: true,
            message: "Client found!",
            data: { ...userData, isSubscribed: user.isSubscribed, planDetails: plan, planType: userSubscription?.planType, dayLeft: daysLeft, companyLanguageDetails, userCompany, companyTaxDetails, isSecurity, clientCreation, invoiceCreation, profileImage },
        });
    });

    static updateProfileImage = catchAsyncErrors(async (req, res, next) => {
        const userId = req.user.id;
        const { id } = req.body;

        const user = await clientModel.findOne({
            attributes: ['id', 'uuid', 'database_name', 'profileImage', 'email'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }

        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        let fileName = null;

        if (req.files && req.files.profileImage) {
            let image = await fileUploaderSingle("src/public/uploads/", req.files.profileImage);
            fileName = image.newfileName;
        }

        try {
            if (id) {
                if (fileName) {
                    await super.updateById(clientModel, userId, { profileImage: fileName });

                    await connection.ClientAdmin.update(
                        { profileImage: fileName },
                        { where: { email : user.email } }
                    );
                }

                // fetch the (possibly updated) clientadmin to get final filename
                const clientAdmin = await connection.ClientAdmin.findOne({ where: { email : user.email } });
                const profileImageUrl = clientAdmin && clientAdmin.profileImage
                    ? `${req.protocol}://${req.get('host')}/uploads/${clientAdmin.profileImage}`
                    : null;

                return res.status(200).json({
                    status: true,
                    message: "Profile image updated successfully.",
                    data: { id, profileImage: profileImageUrl }
                });
            }

            // if (fileName) {
            //     await super.updateById(clientModel, userId, { profileImage: fileName });

            //     await connection.ClientAdmin.update(
            //         { profileImage: fileName },
            //         { where: { id : id } }
            //     );
            // }

            // // fetch specific DB clientadmin to attach full URL
            // const clientAdmin = await connection.ClientAdmin.findOne({ where: { id : id } });
            // const profileImageUrl = clientAdmin && clientAdmin.profileImage
            //     ? `${req.protocol}://${req.get('host')}/uploads/user/${clientAdmin.profileImage}`
            //     : null;

            return res.status(200).json({
                status: false,
                message: "Provide a id for updating profile image.",
                data: {}
            });
        } catch (error) {
            console.log("Error updating profile image:", error);
            return res.status(500).json({
                status: false,
                message: "An error occurred while updating the profile image.",
                data: {}
            });
        }

    });

    static sendVerificationCode = catchAsyncErrors(async (req, res, next) => {
        const { email, subject = "Verification Code" } = req.body;

        const user = await clientModel.findOne({ attributes: ['id', 'uuid', 'name', 'OTP', 'password', 'isVerified', 'database_name'], where: { email } });

        if (!user) {
            return res.status(404).json({ error: 'Client not found' });
        }

        let clientpUdateFields = {};
        let OTP = crypto.randomInt(1000, 10000);
        clientpUdateFields.OTP = OTP;
        clientpUdateFields.expiresAt = new Date(Date.now() + 3600000), // 1 hour from now
        clientpUdateFields.used = false
        const name = user.name || '';
        const body = `Hi ${name},<br><br>
            We received a request to reset the password for your account associated with this email address.<br><br>
            To proceed, please use the One-Time Password (OTP) below:<br><br>
            🔐 Your OTP: ${OTP}<br><br>
            This OTP is valid for the next 1 hour. If you did not request a password reset, please ignore this email or contact our support team immediately.<br><br>
            Thanks,<br>
            Raise Invoice<br>
            Customer Support Team
        `;
        await sendMail(email, null, null, subject, null, body, false);
        var clientpUdate = await super.updateById(clientModel, user?.id, clientpUdateFields);

        //////////////////////////////////////////////////////////////////////////////////////////////////

        return res.status(200).json({
            status: true,
            message: "Otp generate successfully.",
            data: { email },
        });
    });

    static clientVerifyOtp = catchAsyncErrors(async (req, res, next) => {
        const { email, otp } = req.body;
        const user = await clientModel.findOne({ attributes: ['id', 'uuid', 'name', 'password', 'isVerified', 'database_name'], where: { email, OTP: otp } });
        if (!user) {
            return res.status(200).json({
                status: false,
                message: "Verification failed!",
                data: null,
            });
        }
        let updateFields = {};
        updateFields.isVerified = true;
        var updated = await super.updateById(clientModel, user.id, updateFields);
        return res.status(200).json({
            status: true,
            message: "Verification successful.",
            data: { user: updated },
        });
    });

    static clientResetPassword = catchAsyncErrors(async (req, res, next) => {
        const { email, otp, password, confirm_password, deviceType } = req.body;

        const user = await clientModel.findOne({ attributes: ['id', 'uuid', 'name', 'password', 'isVerified', 'database_name','used', 'expiresAt'], where: { email, OTP: otp } });

        if (!user) {
            return res.status(200).json({
                status: false,
                message: "Client Not found!",
                data: null,
            });
        }

        // Check if Link is already used
        if (user.used === true) {
            return res.status(200).json({
                status: false,
                message: "This password reset link has already been used. Please request a new one.",
                data: null,
            });
        }

        // Check if Link is expired
        if (user.expiresAt && user.expiresAt < Date.now()) {
            return res.status(200).json({
                status: false,
                message: "This password reset link has expired. Please request a new one.",
                data: null,
            });
        }

        var results = null;
        let updateFields = {};
        if (password) {
            if (password !== confirm_password) {
                return res.status(200).json({
                    status: false,
                    message: "Passwords do not match.",
                    data: null,
                });
            }
            updateFields.password = await bcrypt.hash(password, 10);
            var updated = await super.updateById(clientModel, user.id, updateFields);

            var token = JWTAuth.ClientSign({
                id: user?.id,
                uuid: user.uuid,
                name: user.name,
                email: email,
                deviceType: deviceType,
                isVerified: user.isVerified,
                isSubscribed: false
            });
            let clientpUdateFields = {};
            if (Number(deviceType) == 2) {
                clientpUdateFields.webLogin = token;
            } else {
                clientpUdateFields.appLogin = token;
            }
            var clientpUdate = await super.updateById(clientModel, user?.id, clientpUdateFields);


            //////////////////////////////////////////////////////////////////////////////////////////////////

            /******************************* Specific DB Connected Start ************************************/
            const db_name = user.database_name;
            if (!db_name) {
                return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
            }
            const sequelize = await getConnectedSpecificDB(db_name);
            /******************************* Specific DB Connected End ************************************/

            var newPassword = updateFields.password;
            var uuid = user.uuid;

            var [results, metadata] = await sequelize.query(
                "UPDATE clientadmins SET password = :newPassword WHERE uuid = :uuid",
                {
                    replacements: { newPassword, uuid: uuid },
                }
            );

            // const asasasa = await clientModel.findAll({ attributes: ['id', 'uuid', 'name'] });
            var [results, metadata] = await sequelize.query("SELECT id, uuid, name FROM clientadmins");

            if (sequelize) {
                await sequelize.close();
            }
        }
        //////////////////////////////////////////////////////////////////////////////////////////////////

        return res.status(200).json({
            status: true,
            message: "Password reset successfully.",
            data: { user, deviceToken: token, clientAdmins: results },
        });
    });

    static clientChangePassword = catchAsyncErrors(async (req, res, next) => {
        const { old_password, password } = req.body;
        if (!old_password) {
            return res.status(400).json({ status: false, message: "Old password required" });
        }
        if (!password) {
            return res.status(400).json({ status: false, message: "New password required" });
        }

        const userId = req.user.id;
        const user = await clientModel.findOne({ where: { id: userId } });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const isPasswordMatched = await bcrypt.compare(old_password, user.password);
        if (!isPasswordMatched) {
            return res.status(400).json({
                status: false,
                message: "Old password does not match!",
                data: {},
            });
        } else {
            let pass = await bcrypt.hash(password, 10);
            let updated = await super.updateById(clientModel, userId, {
                password: pass,
            });
            if (updated) {
                return res.status(200).json({
                    status: true,
                    message: "Password changed successfully",
                });
            } else {
                return res.status(500).json({
                    status: false,
                    message: "Something went wrong",
                });
            }
        }
    });

    /****
    **** Role & Permission Management Section
    *****/
    static getPermissionList = catchAsyncErrors(async (req, res, next) => {
        //////////////////////////////////////////////////////////////////////////////////////////////////
        const user = await clientModel.findOne({ attributes: ['id', 'database_name'], where: { id: req.user.id } });
        /******************************* Specific DB Connected Start ************************************/

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const sequelize = await getConnectedSpecificDB(db_name);
        /******************************* Specific DB Connected End ************************************/
        try {
            // Query to get all modules and their permissions
            const [results] = await sequelize.query(`
            SELECT m.moduleName, p.id AS permissionId, p.name
            FROM modules m
            LEFT JOIN permissions p ON m.id = p.moduleId
        `);

            const response = results.reduce((acc, curr) => {
                let moduleEntry = acc.find(item => item.module === curr.moduleName);
                if (!moduleEntry) {
                    moduleEntry = {
                        module: curr.moduleName,
                        permissions: []
                    };
                    acc.push(moduleEntry);
                }
                if (curr.permissionId) {
                    moduleEntry.permissions.push({
                        id: curr.permissionId,
                        permissionName: curr.name
                    });
                }
                return acc;
            }, []);

            return res.status(200).json({
                status: true,
                message: "Get permissions successfully.",
                data: response
            });

        } finally {
            // Ensure the connection is closed
            if (sequelize) {
                await sequelize.close();
            }
        }
        //////////////////////////////////////////////////////////////////////////////////////////////////
    });

    static createRoleAdmin = catchAsyncErrors(async (req, res, next) => {
        const { role_name, permissions } = req.body;

        //////////////////////////////////////////////////////////////////////////////////////////////////
        const user = await clientModel.findOne({ attributes: ['id', 'database_name'], where: { id: req.user.id } });
        /******************************* Specific DB Connected Start ************************************/
        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const sequelize = await getConnectedSpecificDB(db_name);
        /******************************* Specific DB Connected End ************************************/

        try {
            // Start a transaction
            const transaction = await sequelize.transaction();
            const uuid = crypto.randomUUID();
            const [roleResult] = await sequelize.query(
                "INSERT INTO roles (uuid, roleName, roleSlug) VALUES (:uuid, :roleName, :roleSlug)",
                {
                    replacements: {
                        uuid: uuid,
                        roleName: role_name,
                        roleSlug: role_name.toLowerCase().replace(/\s+/g, '_')
                    },
                    transaction
                }
            );

            const newRoleId = roleResult;

            const permissionInsertPromises = permissions.map(permissionId => {
                return sequelize.query(
                    "INSERT INTO rolespermissions (roleId, permissionId) VALUES (:roleId, :permissionId)",
                    {
                        replacements: {
                            roleId: newRoleId,
                            permissionId: permissionId
                        },
                        transaction
                    }
                );
            });
            await Promise.all(permissionInsertPromises);

            // Commit the transaction
            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: `Role "${role_name}" added with permissions successfully.`,
                data: { id: newRoleId, role_name },
            });
        } catch (error) {
            console.error('Error adding role with permissions:', error);
            // Rollback the transaction in case of error
            await transaction.rollback();
        } finally {
            // Close the connection
            await sequelize.close();
        }
        //////////////////////////////////////////////////////////////////////////////////////////////////
    });

    static getRoleList = catchAsyncErrors(async (req, res, next) => {
        //////////////////////////////////////////////////////////////////////////////////////////////////
        const user = await clientModel.findOne({ attributes: ['id', 'database_name'], where: { id: req.user.id } });
        /******************************* Specific DB Connected Start ************************************/
        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const sequelize = await getConnectedSpecificDB(db_name);
        /******************************* Specific DB Connected End ************************************/
        try {
            var [results, metadata] = await sequelize.query("SELECT id, uuid, roleName FROM roles");
            return res.status(200).json({
                status: true,
                message: "Get roles successfully.",
                data: results
            });
        } finally {
            // Ensure the connection is closed
            if (sequelize) {
                await sequelize.close();
            }
        }
        //////////////////////////////////////////////////////////////////////////////////////////////////
    });

    static getRoleDetails = catchAsyncErrors(async (req, res, next) => {
        const { id } = req.body;

        // Fetch user details to get the database name
        const user = await clientModel.findOne({ attributes: ['id', 'database_name'], where: { id: req.user.id } });

        // Connect to the specific database
        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const sequelize = await getConnectedSpecificDB(db_name);

        try {
            // Use parameterized query to prevent SQL injection
            const [results] = await sequelize.query("SELECT id,uuid, roleName, roleSlug FROM roles WHERE id = :role_id", {
                replacements: { role_id }
            });

            // Check if the role was found
            if (results.length === 0) {
                return res.status(404).json({
                    status: false,
                    message: "Role not found."
                });
            }

            // Return the role details
            return res.status(200).json({
                status: true,
                message: "Get role successfully.",
                data: results[0] // Return the first result
            });
        } catch (error) {
            console.error('Error fetching role details:', error);
            return res.status(500).json({
                status: false,
                message: "An error occurred while fetching role details."
            });
        } finally {
            // Ensure the connection is closed
            if (sequelize) {
                await sequelize.close();
            }
        }
    });

    //--------------------------------------------------------------------------------------------
    static updateClientRole = catchAsyncErrors(async (req, res, next) => {
        // const { role_name, permissions } = req.body;

        // // Fetch user details to get the database name
        // const user = await clientModel.findOne({ attributes: ['id', 'database_name'], where: { id: req.user.id } });

        // // Connect to the specific database
        // const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        // const sequelize = await getConnectedSpecificDB(db_name);

        // try {
        //     // Start a transaction
        //     const transaction = await sequelize.transaction();
        //     const uuid = crypto.randomUUID();
        //     const [roleResult] = await sequelize.query(
        //         "INSERT INTO roles (uuid, roleName, roleSlug) VALUES (:uuid, :roleName, :roleSlug)",
        //         {
        //             replacements: {
        //                 uuid: uuid,
        //                 roleName: role_name,
        //                 roleSlug: role_name.toLowerCase().replace(/\s+/g, '_')
        //             },
        //             transaction
        //         }
        //     );

        //     const newRoleId = roleResult;

        //     const permissionInsertPromises = permissions.map(permissionId => {
        //         return sequelize.query(
        //             "INSERT INTO rolespermissions (roleId, permissionId) VALUES (:roleId, :permissionId)",
        //             {
        //                 replacements: {
        //                     roleId: newRoleId,
        //                     permissionId: permissionId
        //                 },
        //                 transaction
        //             }
        //         );
        //     });
        //     await Promise.all(permissionInsertPromises);

        //     // Commit the transaction
        //     await transaction.commit();

        //     return res.status(200).json({
        //         status: true,
        //         message: `Role "${role_name}" updated with permissions successfully.`,
        //         data: { id: newRoleId, role_name },
        //     });
        // } catch (error) {
        //     console.error('Error fetching role details:', error);
        //     return res.status(500).json({
        //         status: false,
        //         message: "An error occurred while fetching role details."
        //     });
        // } finally {
        //     // Ensure the connection is closed
        //     if (sequelize) {
        //         await sequelize.close();
        //     }
        // }
    });

    static deleteClientRole = catchAsyncErrors(async (req, res, next) => {
        const { id } = req.params;
        const userId = req.user.id;
        const user = await clientModel.findOne({ attributes: ['id', 'database_name'], where: { id: userId } });

        if (!user) {
            throw new Error('User not found');
        }
        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        // const { sequelize2, RoleModelClient } = await connectSpecificToDatabase(db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306');
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );


        let roleDetail = await super.getByCustomOptionsSingle(req, connection.UserRole, {
            where: {
                id: id
            },
            attributes: ["id"],
        });

        if (!roleDetail) {
            return res.status(403).json({
                status: false,
                message: "Role not found!",
                data: {},
            });
        }
        let deleted = await super.deleteByCondition(
            connection.UserRole,
            {
                id: roleDetail.id,
            }
        );

        if (deleted) {
            return res.status(200).json({
                status: true,
                message: "Role successfully deleted.",
                data: {}
            });
        } else {
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }

    });
    //--------------------------------------------------------------------------------------------

    /****
    *** Team Member Management Section
    ****/
    static createTeamMember = catchAsyncErrors(async (req, res, next) => {
        //////////////////////////////////////////////////////////////////////////////////////////////////
        const { name, email, password, roleId } = req.body;
        const userId = req.user.id;

        const user = await clientModel.findOne({ attributes: ['id', 'database_name'], where: { id: userId } });

        if (!user) {
            throw new Error('User  not found');
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const sequelize = await getConnectedSpecificDB(db_name);

        try {
            let updateFields = {};
            updateFields.uuid = crypto.randomUUID();
            if (password) {
                updateFields.password = await bcrypt.hash(password, 10);
            }
            const [newUser] = await sequelize.query(
                "INSERT INTO clientadmins (uuid,name, email, password) VALUES (:uuid, :name, :email, :password)",
                {
                    replacements: {
                        uuid: updateFields.uuid,
                        name,
                        email,
                        password: updateFields.password
                    }
                }
            );

            const newUserId = newUser;

            await sequelize.query(
                "INSERT INTO usersroles (userId, roleId) VALUES (:userId, :roleId)",
                {
                    replacements: {
                        userId: newUserId,
                        roleId: roleId
                    }
                }
            );
            console.log(`User  ${name} added successfully with role ID ${roleId}.`);

            // Step 5: Retrieve the user's name, email, and role
            const [userData] = await sequelize.query(`
            SELECT c.name, c.email, r.roleName AS role
            FROM clientadmins c
            JOIN usersroles ur ON c.id = ur.userId
            JOIN roles r ON ur.roleId = r.id
            WHERE c.id = :userId
        `, {
                replacements: { userId: newUserId }
            });

            return res.status(200).json({
                status: true,
                message: "Team memeber added successfully.",
                data: userData
            });
        } catch (error) {
            console.error('Error adding user:', error);
            throw error;
        } finally {
            await sequelize.close();
        }
    });

    static getAllUsersWithRoles = catchAsyncErrors(async (req, res, next) => {
        const user = await clientModel.findOne({ attributes: ['id', 'database_name'], where: { id: req.user.id } });

        if (!user) {
            throw new Error('User  not found');
        }
        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const sequelize = await getConnectedSpecificDB(db_name);

        try {
            const [usersData] = await sequelize.query(`
                SELECT c.name, c.email, r.roleName AS role
                FROM clientadmins c
                LEFT JOIN usersroles ur ON c.id = ur.userId
                LEFT JOIN roles r ON ur.roleId = r.id
            `);
            return res.status(200).json({
                status: true,
                message: "Team memeber lists.",
                data: usersData
            });
        } catch (error) {
            console.error('Error fetching users:', error);
            throw error; // Rethrow the error for further handling
        } finally {
            // Step 7: Close the connection
            await sequelize.close();
        }
    });

    //--------------------------------------------------------------------------------------------
    static detailsClientAdmin = catchAsyncErrors(async (req, res, next) => {
        const { id } = req.params;

        // Fetch user details to get the database name
        const user = await clientModel.findOne({ attributes: ['id', 'database_name'], where: { id: req.user.id } });

        // Connect to the specific database
        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const sequelize = await getConnectedSpecificDB(db_name);

        try {
            // Use parameterized query to prevent SQL injection
            const [results] = await sequelize.query("SELECT id, uuid, name, email FROM clientadmins WHERE id = :id", {
                replacements: { id }
            });

            // Check if the role was found
            if (results.length === 0) {
                return res.status(404).json({
                    status: false,
                    message: "User not found."
                });
            }

            return res.status(200).json({
                status: true,
                message: "Get user successfully.",
                data: results[0]
            });
        } catch (error) {
            console.error('Error fetching user details:', error);
            return res.status(500).json({
                status: false,
                message: "An error occurred while fetching user details."
            });
        } finally {
            // Ensure the connection is closed
            if (sequelize) {
                await sequelize.close();
            }
        }
    });
    //--------------------------------------------------------------------------------------------

    static editClientAdmin = catchAsyncErrors(async (req, res, next) => {
        const { id } = req.params;
        const { name, email, roleId } = req.body;
        const userId = req.user.id;

        try {
            const user = await clientModel.findOne({ attributes: ['id', 'database_name'], where: { id: userId } });

            if (!user) {
                throw new Error('User  not found');
            }
            const password = await bcrypt.hash(req.body.password, 10);
            const db_name = user.database_name;
            if (!db_name) {
                return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
            }
            const sequelize = await getConnectedSpecificDB(db_name);

            await sequelize.query(
                "UPDATE clientadmins SET name = :name, email = :email, password = :password WHERE id = :id",
                {
                    replacements: {
                        name,
                        email,
                        password,
                        id
                    }
                }
            );

            if (roleId) {
                await sequelize.query(
                    "UPDATE usersroles SET roleId = :roleId WHERE userId = :userId",
                    {
                        replacements: {
                            roleId,
                            userId: id
                        }
                    }
                );
            }

            // Step 5: Retrieve the user's name, email, and role
            const [userData] = await sequelize.query(`
                SELECT c.name, c.email, r.roleName AS role
                FROM clientadmins c
                JOIN usersroles ur ON c.id = ur.userId
                JOIN roles r ON ur.roleId = r.id
                WHERE c.id = :userId
            `, {
                replacements: { userId: id }
            });

            return res.status(200).json({
                status: true,
                message: "Client admin updated successfully",
                data: userData
            });
        } catch (error) {
            console.error('Error updating client admin:', error);
            return res.status(500).json({ message: 'Internal server error' });
        }
    });

    static deleteClientAdmin = catchAsyncErrors(async (req, res, next) => {
        const { id } = req.params;
        const userId = req.user.id;
        const user = await clientModel.findOne({ attributes: ['id', 'database_name'], where: { id: userId } });

        if (!user) {
            throw new Error('User  not found');
        }
        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const sequelize = await getConnectedSpecificDB(db_name);

        try {
            await sequelize.query(
                "DELETE FROM usersroles WHERE userId = :userId",
                {
                    replacements: { userId: id }
                }
            );

            const result = await sequelize.query(
                "DELETE FROM clientadmins WHERE id = :id",
                {
                    replacements: { id }
                }
            );

            if (result[0].affectedRows === 0) {
                return res.status(404).json({ message: 'Client admin not found' });
            }

            return res.status(200).json({
                status: true,
                message: "Client admin deleted successfully.",
                data: null
            });
        } catch (error) {
            console.error('Error deleting client admin:', error);
            return res.status(500).json({ message: 'Internal server error' });
        }
    });

    /****
    *** Team Member Management Section
    ****/
    static clientLogout = catchAsyncErrors(async (req, res, next) => {
        const { deviceType } = req.body;
        // console.log(req.user);
        // let conditions = { userId: req.user.id };
        // console.log(conditions);

        let clientpUdateFields = {};
        if (Number(deviceType) == 2) {
            clientpUdateFields.webLogin = '';
        } else {
            clientpUdateFields.appLogin = '';
        }
        var clientpUdate = await super.updateById(clientModel, req.user.id, clientpUdateFields);
        if (clientpUdate) {
            return res.status(200).json({
                status: true,
                message: "Logged out successfully",
                data: {}
            });
        }
    });

    static updateClientAdminProfile = catchAsyncErrors(async (req, res, next) => {
        let userId = req.user.id;

        let user = await clientModel.findOne({
            attributes: ['id', 'uuid', 'name', 'password', 'isVerified', 'database_name', 'email'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({
                status: false,
                message: "Client not found!",
                data: null,
            });
        }

        let updateFields = {};
        if (req.body.name) {
            updateFields.name = req.body.name;
        }
        if (req.body.email) {
            updateFields.email = req.body.email;
        }
        if (req.body.phone) {
            updateFields.phone = req.body.phone;
        }
        if (req.body.password) {
            if (!bcrypt.compareSync(req.body.current_password, user.password)) {
                return res.status(200).json({
                    status: false,
                    message: "Password does not match.",
                    data: {},
                });
            }
            updateFields.password = await bcrypt.hash(req.body.password, 10);
        }

        // =========== single file upload ================
        if (req.files.profileImage) {
            let imageData = await fileUploaderSingle(
                "src/public/uploads/user/",
                req.files.profileImage
            );
            updateFields.profileImage = imageData.newfileName;
        }

        if (user.database_name) {
            const updated = await super.updateById(clientModel, userId, updateFields);
        } else {
            user = await clientModel.findOne({});
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );
        const clientAdmin = await connection.ClientAdmin.update(updateFields, {
            where: { uuid: user.uuid }
        });

        return res.status(200).json({
            status: true,
            message: "Updated Successfuly!",
            data: updateFields
        });

    })

}

module.exports = authController;