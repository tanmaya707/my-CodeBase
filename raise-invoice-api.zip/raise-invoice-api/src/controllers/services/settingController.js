const BaseController = require("../BaseController");
const catchAsyncErrors = require("../../middleware/catchAsyncErrors");
const bcrypt = require("bcryptjs");
const db = require("../../models");
const clientModel = db.Clients;
const userCompanyModel = db.UserCompanies;
const userModel = db.Users;
const { Op } = require("sequelize");
const crypto = require("crypto");
const { createDatabase, getConnectedSpecificDB } = require("../../utils/utilities");
const JWTAuth = require("../../utils/jwtToken");
const mysqlConfig = require("../../config/index").Mysql;
const { connectSpecificToDatabase } = require("../../config/specificConnect");

class settingController extends BaseController {
    constructor() {
        super();
    }

    static addSettingsClientCompany = catchAsyncErrors(async (req, res, next) => {
        const { id } = req.params;
        const userId = req.user.id;
        const user = await clientModel.findOne({ attributes: ['id', 'database_name'], where: { id: userId } });

        if (!user) {
            throw new Error('User not found');
        }
        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }

        // const { sequelize, ClientAdmin } = await connectSpecificToDatabase(db_name, 'root', '', 'localhost', '3306');
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        const options = {};
        let clientData = await super.getList(req, connection.ClientAdmin, options);

        return res.status(200).json({ data: clientData });

        try {
            await sequelize.query(
                "DELETE FROM usersroles WHERE userId = :userId",
                {
                    replacements: { userId: id }
                }
            );

            const result = await sequelize.query(
                "DELETE FROM clientadmins WHERE id = :id",
                {
                    replacements: { id }
                }
            );

            if (result[0].affectedRows === 0) {
                return res.status(404).json({ message: 'Client admin not found' });
            }

            return res.status(200).json({
                status: true,
                message: "Client admin deleted successfully.",
                data: null
            });
        } catch (error) {
            console.error('Error deleting client admin:', error);
            return res.status(500).json({ message: 'Internal server error' });
        }
    });

    //Language settings
    static addLanguageSetting = catchAsyncErrors(async (req, res, next) => {
        const userId = req.user.id;
        const {

        } = req.body;
        const user = await clientModel.findOne({ attributes: ['id', 'database_name'], where: { id: userId } });

        if (!user) {
            throw new Error('User not found');
        }
        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }

        // const { sequelize, ClientAdmin } = await connectSpecificToDatabase(db_name, 'root', '', 'localhost', '3306');
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        const options = {};
        let clientData = await super.getList(req, connection.ClientAdmin, options);

        return res.status(200).json({ data: clientData });
    });

    static detailsLanguageSetting = catchAsyncErrors(async (req, res, next) => {
        const { id } = req.params;
        const userId = req.user.id;
        const user = await clientModel.findOne({ attributes: ['id', 'database_name'], where: { id: userId } });

    });

    //Currency settings
    static addCurrencySetting = catchAsyncErrors(async (req, res, next) => {
        const { id } = req.params;
        const userId = req.user.id;
        const user = await clientModel.findOne({ attributes: ['id', 'database_name'], where: { id: userId } });

        if (!user) {
            throw new Error('User not found');
        }
        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }

        // const { sequelize, ClientAdmin } = await connectSpecificToDatabase(db_name, 'root', '', 'localhost', '3306');
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        const options = {};
        let clientData = await super.getList(req, connection.ClientAdmin, options);

        return res.status(200).json({ data: clientData });
    });

    static detailCurrencySetting = catchAsyncErrors(async (req, res, next) => {
        const { id } = req.params;
        const userId = req.user.id;
        const user = await clientModel.findOne({ attributes: ['id', 'database_name'], where: { id: userId } });

    });

    //project settings
    static updateProjectSettings = catchAsyncErrors(async (req, res, next) => {
        const { id, addNewClient, newEstimate, newInvoice, prefix } = req.body;
        const userId = req.user.id;


        const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);

        if (error) {
            return res.status(404).json({ status: false, message: error });
        }

        const transaction = await connection.sequelize.transaction();

        const updateData = {
            addNewClient,
            newEstimate,
            newInvoice,
            prefix
        };

        try {
            const update = await connection.ProjectSetting.update(updateData, {
                where: { id },
                transaction
            });
            if (!update) {
                return res.status(404).json({ status: false, message: 'Project setting not found', data: {} });
            }

            const updatedProjectSetting = await connection.ProjectSetting.findOne({ where: { id }, transaction });

            if (!updatedProjectSetting) {
                return res.status(404).json({ status: false, message: 'Project setting not found', data: {} });
            }

            await transaction.commit();

            return res.status(200).json({ status: true, message: 'Project setting updated successfully', data: updatedProjectSetting });
        } catch (error) {
            await transaction.rollback();
            console.error("Error fetching Project Setting:", error);
            return res.status(500).json({
                status: false,
                message: "Oops... something went terribly wrong!",
                data: {}
            });
        }

    });

    static detailProjectSetting = catchAsyncErrors(async (req, res, next) => {
        const userId = req.user.id;
        const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);

        if (error) {
            return res.status(404).json({ status: false, message: error });
        }

        try {
            // Fetch the latest project settings
            const projectSetting = await connection.ProjectSetting.findOne();

            if (!projectSetting) {
                return res.status(404).json({ status: false, message: 'Project setting not found', data: {} });
            }

            return res.status(200).json({ status: true, message: 'Project setting details retrieved successfully', data: projectSetting });

        } catch (error) {
            console.error("Error fetching project details:", error);
            return res.status(500).json({
                status: false,
                message: "An error occurred while retrieving project details.",
                data: {}
            });
        }
    });

    //Communication settings
    static updateCommunicationSettings = catchAsyncErrors(async (req, res, next) => {
        const { id, sameEmail, message, cc, bcc, paymentReminder, day3BeforeDueDate, dueDate, day3AfterDueDate, day7AfterDueDate, paymentNotification, paymentReceipt, email, businessResource, invoice2go, productUpdate, specialOffer } = req.body;
        const userId = req.user.id;
        const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);

        if (error) {
            return res.status(404).json({ status: false, message: error });
        }

        const transaction = await connection.sequelize.transaction();

        const updateData = {
            sameEmail,
            message,
            cc,
            bcc,
            paymentReminder,
            day3BeforeDueDate,
            dueDate,
            day3AfterDueDate,
            day7AfterDueDate,
            paymentNotification,
            paymentReceipt,
            email,
            businessResource,
            invoice2go,
            productUpdate,
            specialOffer
        };

        try {
            const update = await connection.CommunicationSetting.update(updateData, {
                where: { id },
                transaction
            });

            if (!update) {
                return res.status(404).json({ status: false, message: 'Communication setting not found', data: {} });
            }

            const updatedCommunicationSetting = await connection.CommunicationSetting.findOne({ where: { id }, transaction });

            if (!updatedCommunicationSetting) {
                return res.status(404).json({ status: false, message: 'Communication setting not found', data: {} });
            }

            await transaction.commit();

            return res.status(200).json({ status: true, message: 'Communication setting updated successfully', data: updatedCommunicationSetting });
        } catch (error) {
            await transaction.rollback();
            console.error("Error updating CommunicationSetting:", error);
            return res.status(500).json({
                status: false,
                message: "Oops... something went terribly wrong!",
                data: {}
            });
        }
    });

    static detailCommunicationSetting = catchAsyncErrors(async (req, res, next) => {
        const userId = req.user.id;
        const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);

        if (error) {
            return res.status(404).json({ status: false, message: error });
        }

        try {
            // Fetch the latest communication settings
            const communicationSetting = await connection.CommunicationSetting.findOne();

            if (!communicationSetting) {
                return res.status(404).json({ status: false, message: 'Communication setting not found', data: {} });
            }

            return res.status(200).json({ status: true, message: 'Communication setting details retrieved successfully', data: communicationSetting });

        } catch (error) {
            console.error("Error fetching communication details:", error);
            return res.status(500).json({
                status: false,
                message: "An error occurred while retrieving communication details.",
                data: {}
            });
        }
    });

    static getConnectionForClient = async (userId, mysqlConfig) => {
        try {
            // Fetch user and their database name
            const user = await clientModel.findOne({
                attributes: ['id', 'database_name'],
                where: { id: userId }
            });

            if (!user) {
                return { error: 'User not found', connection: null };
            }

            const db_name = user.database_name;
            if (!db_name) {
                return { error: 'Please create your company first before accessing this resource.', connection: null };
            }

            // Establish connection
            const connection = await connectSpecificToDatabase(
                db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
            );

            return { error: null, connection };
        } catch (err) {
            console.error("Error in getConnectionForClient:", err);
            return { error: 'Failed to establish a connection.', connection: null };
        }
    };

}

module.exports = settingController;