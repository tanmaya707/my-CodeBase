const BaseController = require("../BaseController");
const catchAsyncErrors = require("../../middleware/catchAsyncErrors");
const bcrypt = require("bcryptjs");
const db = require("../../models");
const clientModel = db.Clients;
const userCompanyModel = db.UserCompanies;
const clientApp = db.clientApp;
const planModel = db.Plans;
const planPriceModel = db.PlanPrices;
const userModel = db.Users;
const { Op } = require("sequelize");
const crypto = require("crypto");
const { createDatabase, getConnectedSpecificDB, getWeekRange, getAllWeekRanges } = require("../../utils/utilities");
const JWTAuth = require("../../utils/jwtToken");
const mysqlConfig = require("../../config/index").Mysql;
const fileUploaderSingle = require("../../utils/fileUpload").fileUploaderSingle;

const { connectSpecificToDatabase } = require("../../config/specificConnect");
const { addAbortListener } = require("events");

class appointmentController extends BaseController {
    constructor() {
        super();
    }

    static createAppointment = catchAsyncErrors(async (req, res) => {
        let {
            client_id,
            contact_ids,
            location,
            latitude,
            longitude,
            start_date,
            start_time,
            end_date,
            end_time,
            notes,
            status
        } = req.body;

        if (!client_id) {
            client_id = 0;
        }

        // Handle different formats of contact_ids
        if (contact_ids && typeof contact_ids === 'object' && contact_ids['']) {
            if(Array.isArray(contact_ids[''])){
                contact_ids = contact_ids[''].map(id => parseInt(id));
            }else{
                contact_ids = [parseInt(contact_ids[''])];
            }
        } else if (typeof contact_ids === 'string') {
            contact_ids = contact_ids.split(',').map(id => parseInt(id.trim()));
        } else if (Array.isArray(contact_ids)) {
            contact_ids = contact_ids.map(id => parseInt(id));
        }

        const userId = req.user.id;
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        // Start a transaction
        const transaction = await connection.sequelize.transaction();

        try {
            let appointmentFields = {};
            let fileName = "";

            // Handle file upload
            if (req.files && req.files.document) {
                let image = await fileUploaderSingle("src/public/uploads/", req.files.document);
                fileName = image.newfileName;
            }
            const uuid = crypto.randomUUID();
            appointmentFields = {
                uuid,
                client_id,
                contact_ids: contact_ids || null,
                client_admin_id: userId,
                location,
                latitude,
                longitude,
                start_date,
                start_time,
                end_date,
                end_time,
                notes,
                status,
                document: fileName || null
            };

            // Create Appointment
            const addAppointment = await super.create(res, connection.CompanyAppointment, appointmentFields, { transaction });

            // Commit the transaction
            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Appointment created successfully.",
                data: addAppointment
            });
        } catch (error) {
            // Rollback the transaction in case of error
            await transaction.rollback();
            console.error('Error creating client:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });
    //--------------------------------------------------------------------------------------------
    static getAllAppointments = catchAsyncErrors(async (req, res) => {
        try {
            const { month, year } = req.body;
            const userId = req.user.id;

            // Fetch user and database details
            const user = await clientModel.findOne({
                attributes: ['id', 'database_name'],
                where: { id: userId }
            });

            if (!user) {
                return res.status(404).json({ status: false, message: 'User not found' });
            }

            const db_name = user.database_name;
            if (!db_name) {
                return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
            }

            // Connect to the specific database
            const connection = await connectSpecificToDatabase(db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306');

            // Fetch all appointments
            const appointments = await connection.CompanyAppointment.findAll();

            let filteredAppointments = appointments;

            // If month and year are provided, filter appointments
            if (month && year) {
                const selectedYear = parseInt(year);
                const selectedMonth = parseInt(month);
                filteredAppointments = appointments.filter(app => {
                    const startDate = new Date(app.start_date);
                    return startDate.getFullYear() === selectedYear && startDate.getMonth() + 1 === selectedMonth;
                });
            }

            // Get unique client_ids from filtered appointments
            const clientIds = [...new Set(filteredAppointments.map(app => app.client_id))];

            // Fetch client data for these client_ids
            const clients = await connection.Client.findAll({
                where: { id: { [Op.in]: clientIds } }
            });

            // Map client id to client data for quick lookup
            const clientMap = {};
            clients.forEach(client => {
                clientMap[client.id] = client;
            });

            // Collect all unique contact_ids from all appointments (flattened)
            let allContactIds = [];
            filteredAppointments.forEach(app => {
                let contactIds = [];
                if (app.contact_ids) {
                    if (typeof app.contact_ids === "string") {
                        try {
                            contactIds = JSON.parse(app.contact_ids);
                        } catch (e) {
                            // fallback: treat as comma-separated string
                            contactIds = app.contact_ids.split(",").map(id => id.trim()).filter(Boolean);
                        }
                    } else if (Array.isArray(app.contact_ids)) {
                        contactIds = app.contact_ids;
                    }
                }
                // Ensure all contact IDs are numbers
                contactIds = contactIds.map(id => Number(id)).filter(Boolean);
                allContactIds = allContactIds.concat(contactIds);
            });
            allContactIds = [...new Set(allContactIds)];

            // Fetch all contacts in one go
            let contactsMap = {};
            if (allContactIds.length > 0) {
                const contacts = await connection.ProjectContacts.findAll({
                    where: { id: { [Op.in]: allContactIds } }
                });
                contacts.forEach(contact => {
                    contactsMap[contact.id] = contact;
                });
            }

            // Attach client and contacts data to each appointment
            const appointmentsWithClient = filteredAppointments.map(app => {
                const appObj = app.toJSON ? app.toJSON() : { ...app };
                let contactIds = [];
                if (appObj.contact_ids) {
                    if (typeof appObj.contact_ids === "string") {
                        try {
                            contactIds = JSON.parse(appObj.contact_ids);
                        } catch (e) {
                            contactIds = appObj.contact_ids.split(",").map(id => id.trim()).filter(Boolean);
                        }
                    } else if (Array.isArray(appObj.contact_ids)) {
                        contactIds = appObj.contact_ids;
                    }
                }
                contactIds = contactIds.map(id => Number(id)).filter(Boolean);

                // Attach contacts
                const contacts = contactIds.length
                    ? contactIds
                        .map(id => contactsMap[id])
                        .filter(Boolean)
                        .map(c => (c.toJSON ? c.toJSON() : c))
                    : [];

                return {
                    ...appObj,
                    client: clientMap[app.client_id] || null,
                    contacts
                };
            });

            // If month and year are provided, group by week ranges
            if (month && year) {
                const dateObj = new Date(parseInt(year), parseInt(month) - 1);
                const monthName = dateObj.toLocaleString('default', { month: 'short' });

                // Initialize all expected week ranges for the requested month
                const weekRanges = getAllWeekRanges(monthName);
                const groupedAppointments = {};
                weekRanges.forEach(range => {
                    groupedAppointments[range] = [];
                });

                // Group appointments into week ranges
                appointmentsWithClient.forEach(app => {
                    const startDate = new Date(app.start_date);
                    const weekRange = getWeekRange(startDate);

                    if (groupedAppointments[weekRange]) {
                        groupedAppointments[weekRange].push(app);
                    }
                });

                // Convert object to array format
                const formattedResponse = Object.keys(groupedAppointments).map(range => ({
                    range,
                    appointments: groupedAppointments[range]
                }));

                return res.status(200).json({
                    status: true,
                    message: "Appointments retrieved successfully.",
                    data: formattedResponse
                });
            } else {
                // If no month/year, return all appointments with client and contacts info
                return res.status(200).json({
                    status: true,
                    message: "All appointments retrieved successfully.",
                    data: appointmentsWithClient
                });
            }
        } catch (error) {
            console.error('Error fetching appointments:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });
    static getAppointments = catchAsyncErrors(async (req, res, next) => {
        const { id } = req.body;
        const userId = req.user.id;

        // Fetch user and database details
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }

        // Connect to the specific database
        const connection = await connectSpecificToDatabase(db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306');

        try {
            const appointment = await connection.CompanyAppointment.findOne({
                where: { id: id },
            });

            if (!appointment) {
                return res.status(404).json({ status: false, message: 'Appointment not found' });
            }

            // Fetch client details
            let client = null;
            if (appointment.client_id) {
                client = await connection.Client.findOne({
                    where: { id: appointment.client_id }
                });
            }
            // Fetch contacts if contact_ids is present and is an array or comma-separated string
            let contacts = [];
            if (appointment.contact_ids) {
                let contactIds = appointment.contact_ids;
                // if (typeof contactIds === "string") {
                //     console.log(contactIds, "contactIds");
                //     // If comma-separated string, split into array
                //     contactIds = contactIds.split(",").map(id => id.trim()).filter(Boolean);
                // }

                // Normalize contactIds to array of numbers
                if (typeof contactIds === "string") {
                    try {
                        contactIds = JSON.parse(contactIds);
                    } catch (e) {
                        contactIds = contactIds.split(",").map(id => id.trim()).filter(Boolean);
                    }
                }
                if (Array.isArray(contactIds)) {
                    contactIds = contactIds.map(id => Number(id)).filter(Boolean);
                } else if (typeof contactIds === "number") {
                    contactIds = [contactIds];
                } else {
                    contactIds = [];
                }

                if (Array.isArray(contactIds) && contactIds.length > 0) {
                    contacts = await connection.ProjectContacts.findAll({
                        where: { id: { [Op.in]: contactIds } }
                    });
                }
            }

            // Attach client and contacts details to appointment
            const appointmentObj = appointment.toJSON ? appointment.toJSON() : { ...appointment };
            appointmentObj.client = client ? (client.toJSON ? client.toJSON() : client) : null;
            appointmentObj.contacts = contacts.map(c => (c.toJSON ? c.toJSON() : c));

            return res.status(200).json({
                status: true,
                message: "Appointment details retrieved successfully.",
                data: appointmentObj
            });
        } catch (error) {
            console.error('Error fetching appointment details:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });
         
    // Update Appointment
    static updateAppointment = catchAsyncErrors(async (req, res, next) => {
        const { id } = req.body;
        const userId = req.user.id;
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }

        const connection = await connectSpecificToDatabase(db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306');
        const transaction = await connection.sequelize.transaction();

        try {
            let updateFields = { ...req.body };
            let fileName = "";

            // Handle file upload
            if (req.files && req.files.document) {
                let image = await fileUploaderSingle("src/public/uploads/", req.files.document);
                fileName = image.newfileName;
                updateFields.document = fileName;
            }

            const appointment = await connection.CompanyAppointment.findOne({ where: { id } });
            if (!appointment) {
                await transaction.rollback();
                return res.status(404).json({ status: false, message: "Appointment not found", data: {} });
            }

            await appointment.update(updateFields, { transaction });
            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Appointment updated successfully.",
                data: appointment
            });
        } catch (error) {
            await transaction.rollback();
            console.error('Error updating appointment:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });

    // Delete Appointment
    static deleteAppointment = catchAsyncErrors(async (req, res, next) => {
        const { id } = req.body;
        const userId = req.user.id;
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }

        const connection = await connectSpecificToDatabase(db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306');
        const transaction = await connection.sequelize.transaction();

        try {
            const appointment = await connection.CompanyAppointment.findOne({ where: { id } });
            if (!appointment) {
                await transaction.rollback();
                return res.status(404).json({ status: false, message: "Appointment not found", data: {} });
            }

            await appointment.destroy({ transaction });
            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Appointment deleted successfully.",
                data: {}
            });
        } catch (error) {
            await transaction.rollback();
            console.error('Error deleting appointment:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });
}

module.exports = appointmentController;