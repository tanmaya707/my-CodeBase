const BaseController = require("../BaseController");
const catchAsyncErrors = require("../../middleware/catchAsyncErrors");
const bcrypt = require("bcryptjs");
const db = require("../../models");
const clientModel = db.Clients;
const userCompanyModel = db.UserCompanies;
const planModel = db.Plans;
const planPriceModel = db.PlanPrices;
const userModel = db.Users;
const { Op } = require("sequelize");
const crypto = require("crypto");
const { createDatabase, getConnectedSpecificDB } = require("../../utils/utilities");
const JWTAuth = require("../../utils/jwtToken");
const mysqlConfig = require("../../config/index").Mysql;
const fileUploaderSingle = require("../../utils/fileUpload").fileUploaderSingle;

const { connectSpecificToDatabase } = require("../../config/specificConnect");

class projectController extends BaseController {
    constructor() {
        super();
    }

    static createClient = catchAsyncErrors(async (req, res, next) => {
        const {
            name,
            email,
            alt_email,
            dialCode,
            phone,
            contact_name,
            contactdialCode,
            contactPhone,
            contactWebsite,
            payment_term,
            tax_no,
            notes
        } = req.body;

        const userId = req.user.id;
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User  not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.' ,data:{}});
        }
        // const { sequelize2, ClientRaiseModel, ClientRaiseContactModel, ClientRaiseOtherModel } = await connectSpecificToDatabase(db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306');
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        // Start a transaction
        const transaction = await connection.sequelize.transaction();

        try {
            let clientFields = {};
            let clientContactFields = {};
            let clientOtherFields = {};
            let fileName = "";

            // Handle file upload
            if (req.files && req.files.profileImage) {
                let image = await fileUploaderSingle("src/public/uploads/", req.files.profileImage);
                fileName = image.newfileName;
            }
            const uuid = crypto.randomUUID();
            clientFields = {
                uuid,
                name,
                email,
                alt_email,
                dialCode,
                phone,
                created_by: userId,
                profileImage: fileName || null
            };

            // Create client
            const addClient = await super.create(res, connection.Client, clientFields, { transaction });

            // Prepare contact fields
            clientContactFields = {
                uuid: uuid,
                clientId: addClient.id,
                contact_name,
                dialCode: contactdialCode,
                phone: contactPhone,
                website: contactWebsite
            };

            // Create client contact
            await super.create(res, connection.ClientContact, clientContactFields, { transaction });

            // Prepare other fields
            clientOtherFields = {
                uuid: uuid,
                clientId: addClient.id,
                payment_term,
                tax_no,
                notes
            };

            // Create client other details
            await super.create(res, connection.ClientOther, clientOtherFields, { transaction });

            // Commit the transaction
            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Client added successfully.",
                data: addClient
            });
        } catch (error) {
            // Rollback the transaction in case of error
            await transaction.rollback();
            console.error('Error creating client:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });
    //--------------------------------------------------------------------------------------------
    static getAllClients = catchAsyncErrors(async (req, res, next) => {
        const userId = req.body.uuid;
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User  not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.' ,data:{}});
        }
        // const { sequelize2, ClientRaiseModel } = await connectSpecificToDatabase(db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306');
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        try {
            const clients = await connection.Client.findAll({
            });

            return res.status(200).json({
                status: true,
                message: "Clients retrieved successfully.",
                data: clients
            });
        } catch (error) {
            console.error('Error fetching clients:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });

    static detailsClient = catchAsyncErrors(async (req, res, next) => {
        const { clientId } = req.params; // Assuming clientId is passed as a URL parameter
        const userId = req.user.id;
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User  not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.' ,data:{}});
        }
        // const { sequelize2, ClientRaiseModel, ClientRaiseContactModel, ClientRaiseOtherModel } = await connectSpecificToDatabase(db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306');

        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );


        try {
            // Fetch client details
            const client = await connection.Client.findOne({
                where: { id: clientId },
                include: [
                    {
                        model: connection.ClientContact,
                        as: 'contacts'
                    },
                    {
                        model: connection.ClientOther,
                        as: 'otherDetails'
                    }
                ]
            });

            if (!client) {
                return res.status(404).json({ status: false, message: 'Client not found' });
            }

            return res.status(200).json({
                status: true,
                message: "Client details retrieved successfully.",
                data: client
            });
        } catch (error) {
            console.error('Error fetching client details:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });

    static updateClient = catchAsyncErrors(async (req, res, next) => {
        const { clientId } = req.params;
        const {
            name,
            email,
            alt_email,
            dialCode,
            phone,
            contact_name,
            contactdialCode,
            contactPhone,
            contactWebsite,
            payment_term,
            tax_no,
            notes
        } = req.body;

        const userId = req.user.id;
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.' ,data:{}});
        }
        // const { sequelize2, ClientRaiseModel, ClientRaiseContactModel, ClientRaiseOtherModel } = await connectSpecificToDatabase(db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306');
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        // Start a transaction
        const transaction = await connection.sequelize.transaction();

        try {
            const clientUpdateFields = {
                name,
                email,
                alt_email,
                dialCode,
                phone,
                updated_by: userId
            };

            const [updatedClientCount, updatedClient] = await connection.Client.update(clientUpdateFields, {
                where: { id: clientId },
                returning: true,
                transaction
            });

            if (updatedClientCount === 0) {
                return res.status(404).json({ status: false, message: 'Client not found' });
            }

            // Update client contact information
            const clientContactUpdateFields = {
                contact_name,
                dialCode: contactdialCode,
                phone: contactPhone,
                website: contactWebsite
            };

            await connection.ClientContact.update(clientContactUpdateFields, {
                where: { clientId: clientId },
                transaction
            });

            // Update other client details
            const clientOtherUpdateFields = {
                payment_term,
                tax_no,
                notes
            };

            await connection.ClientOther.update(clientOtherUpdateFields, {
                where: { clientId: clientId },
                transaction
            });

            // Commit the transaction
            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Client updated successfully.",
                data: updatedClient[0]
            });
        } catch (error) {
            await transaction.rollback();
            console.error('Error updating client:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });

    static clientDeleteAPI = catchAsyncErrors(async (req, res, next) => {
        const { clientId } = req.params; // Assuming clientId is passed as a URL parameter
        const userId = req.user.id;

        // Find the user to get the database name
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User  not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.' ,data:{}});
        }
        // const { sequelize2, ClientRaiseModel, ClientRaiseContactModel, ClientRaiseOtherModel } = await connectSpecificToDatabase(db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306');
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        // Start a transaction
        const transaction = await connection.sequelize.transaction();

        try {
            // Delete associated contacts
            await connection.ClientContact.destroy({
                where: { clientId: clientId },
                transaction
            });

            // Delete associated other details
            await connection.ClientOther.destroy({
                where: { clientId: clientId },
                transaction
            });

            // Delete the client
            const deletedClientCount = await connection.Client.destroy({
                where: { id: clientId },
                transaction
            });

            if (deletedClientCount === 0) {
                return res.status(404).json({ status: false, message: 'Client not found' });
            }

            // Commit the transaction
            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Client deleted successfully."
            });
        } catch (error) {
            // Rollback the transaction in case of error
            await transaction.rollback();
            console.error('Error deleting client:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });

    static clientSubscription = catchAsyncErrors(async (req, res, next) => {
        const {
            planId,
            price,
            startDate,
            planType
        } = req.body;

        const userId = req.user.id;
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User  not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.' ,data:{}});
        }
        // const { sequelize2, ClientPlanModel, ClientPlanPriceModel, ClientSubscriptionModel } = await connectSpecificToDatabase(db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306');
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        const plans = await planModel.findAll({
            include: [
                {
                    model: planPriceModel,
                    where: {
                        deletedAt: null,
                        status: true,
                    }
                },
            ],
            order: [['createdAt', 'DESC']]
        });

        // await sequelize2.query('SET FOREIGN_KEY_CHECKS = 0;');
        // await sequelize2.query('TRUNCATE TABLE plan_prices;');
        // await sequelize2.query('TRUNCATE TABLE plans;');
        // await sequelize2.query('SET FOREIGN_KEY_CHECKS = 1;');

        // for (const planData of plans) {
        //     const clientPlan = await ClientPlanModel.create({
        //         id: planData.id,
        //         uuid: planData.uuid,
        //         name: planData.name,
        //         slug: planData.slug,
        //         short_description: planData.short_description,
        //         description: planData.description,
        //         is_trial_available: planData.is_trial_available,
        //         trial_duration: planData.trial_duration,
        //         is_recommended: planData.is_recommended,
        //         status: planData.status,
        //         createdAt: planData.createdAt,
        //         updatedAt: planData.updatedAt,
        //         deletedAt: planData.deletedAt
        //     });

        //     for (const price of planData.plan_prices) {
        //         await ClientPlanPriceModel.create({
        //             id: price.id,
        //             plan_id: clientPlan.id,
        //             country_id: price.country_id,
        //             name: price.name,
        //             interval: price.interval,
        //             price: price.price,
        //             discount: price.discount,
        //             status: price.status,
        //             createdAt: price.createdAt,
        //             updatedAt: price.updatedAt,
        //             deletedAt: price.deletedAt
        //         });
        //     }
        // }

        // Start a transaction
        const transaction = await connection.sequelize.transaction();

        const startDateCal = new Date(startDate);
        let endDate;

        if (planType === 'monthly') {
            endDate = new Date(startDateCal);
            endDate.setDate(startDateCal.getDate() + 30);
        } else if (planType === 'yearly') {
            endDate = new Date(startDateCal);
            endDate.setFullYear(startDateCal.getFullYear() + 1);
        }

        try {
            let buyPlanFields = {};

            buyPlanFields = {
                userId: userId,
                subscriptionId: planId,
                startDate,
                endDate,
                price,
                planType,
                isPaid: true
            };

            // Create client
            const addClient = await super.create(res, connection.Subscription, buyPlanFields, { transaction });

            // Commit the transaction
            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Subscribed successfully.",
                data: addClient
            });
        } catch (error) {
            // Rollback the transaction in case of error
            await transaction.rollback();
            console.error('Error creating client:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });
}

module.exports = projectController;