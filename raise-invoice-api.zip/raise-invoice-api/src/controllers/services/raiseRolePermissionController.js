const BaseController = require("../BaseController");
const catchAsyncErrors = require("../../middleware/catchAsyncErrors");
const db = require("../../models");
const clientModel = db.Clients;
const crypto = require("crypto");
const mysqlConfig = require("../../config/index").Mysql;

const { connectSpecificToDatabase } = require("../../config/specificConnect");

class rolePermissionController extends BaseController {
    constructor() {
        super();
    }
    
        // Create Role API
        static createRole = catchAsyncErrors(async (req, res, next) => {
            const { roleName, accessStatus } = req.body;
            
            if (!roleName) {
                return res.status(404).json({ status: false, message: 'roleName not found' });
            }
            
            const userId = req.user.id;
            const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);
            
            if (error) {
                return res.status(404).json({ status: false, message: error });
            }
            
            const transaction = await connection.sequelize.transaction();
            
            try {
                const uuid = crypto.randomUUID();
                const Fields = {
                    uuid,
                    roleName,
                    roleSlug: roleName.toLowerCase().replace(/\s+/g, '_'),
                    accessStatus
                };
            
                const rolesCreated = await super.create(res, connection.Roles, Fields, { transaction });
            
                await transaction.commit();
            
                return res.status(200).json({
                status: true,
                message: "Roles Added successfully.",
                data: rolesCreated
                });
            } catch (error) {
                await transaction.rollback();
                console.error('Error creating Roles:', error);
                return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
                });
            }
        });

        // Update Role API
        static updateRole = catchAsyncErrors(async (req, res, next) => {
          const { id, roleName, accessStatus } = req.body;

          if (!roleName) {
              return res.status(400).json({
              status: false,
              message: "roleName is missing."
              });
          }

          const userId = req.user.id;
          const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);

          if (error) {
              return res.status(404).json({ status: false, message: error });
          }

          const transaction = await connection.sequelize.transaction();

          try {
              const updateFields = {
                roleName,
                roleSlug: roleName.toLowerCase().replace(/\s+/g, '_'),
                accessStatus: accessStatus
              };

              const [updatedRolesCount] = await connection.Roles.update(updateFields, {
              where: { id: id },
              transaction
              });

              if (updatedRolesCount === 0) {
              return res.status(404).json({ status: false, message: "Role not found or no changes made." });
              }

              const updatedRole = await connection.Roles.findOne({
              where: { id: id },
              transaction
              });

              await transaction.commit();

              return res.status(200).json({
                status: true,
                message: "Role updated successfully.",
                data: updatedRole
              });
          } catch (error) {
              await transaction.rollback();
                console.error("Error updating Role:", error);
                return res.status(500).json({
                status: false,
                message: "An error occurred while updating the role.",
                data: {}
              });
          }
        });

        // List All Roles API
        static listAllRoles = catchAsyncErrors(async (req, res, next) => {
          const userId = req.user.id;
          const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);

          if (error) {
              return res.status(404).json({ status: false, message: error });
          }

          try {
              const roles = await connection.Roles.findAll();

              return res.status(200).json({
              status: true,
              message: "Roles retrieved successfully.",
              data: roles
              });
          } catch (error) {
              console.error("Error fetching Roles:", error);
              return res.status(500).json({
              status: false,
              message: "Oops... something went terribly wrong!",
              data: {}
              });
          }
        });

        // Fetch Single Role Data API
        static roleDetails = catchAsyncErrors(async (req, res, next) => {
          const { id } = req.body;

          const userId = req.user.id;
          const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);

          if (error) {
              return res.status(404).json({ status: false, message: error });
          }

          try {
              const role = await connection.Roles.findOne({ where: { id: id } });

              if (!role) {
              return res.status(404).json({ status: false, message: "Role not found." });
              }

              return res.status(200).json({
              status: true,
              message: "Role details retrieved successfully.",
              data: role
              });
          } catch (error) {
              console.error("Error fetching role details:", error);
              return res.status(500).json({
              status: false,
              message: "An error occurred while retrieving role details.",
              data: {}
              });
          }
        });

        // Delete Role API
        static deleteRole = catchAsyncErrors(async (req, res, next) => {
          const { uuid } = req.body;

          const userId = req.user.id;
          const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);

          if (error) {
              return res.status(404).json({ status: false, message: error });
          }

          const transaction = await connection.sequelize.transaction();

          try {
              const deletedRoleCount = await connection.Roles.destroy({
              where: { uuid: uuid },
              transaction
              });

              if (!deletedRoleCount) {
              return res.status(404).json({ status: false, message: "Role not found." });
              }

              await transaction.commit();

              return res.status(200).json({
              status: true,
              message: "Role deleted successfully."
              });
          } catch (error) {
              await transaction.rollback();
              console.error("Error deleting Role:", error);
              return res.status(500).json({
              status: false,
              message: "An error occurred while deleting the role.",
              data: {}
              });
          }
        });

        static getConnectionForClient = async (userId, mysqlConfig) => {
            try {
                // Fetch user and their database name
                const user = await clientModel.findOne({
                    attributes: ['id', 'database_name'],
                    where: { id: userId }
                });
        
                if (!user) {
                    return { error: 'User not found', connection: null };
                }
        
                const db_name = user.database_name;
                if (!db_name) {
                    return { error: 'Please create your company first before accessing this resource.', connection: null };
                }
        
                // Establish connection
                const connection = await connectSpecificToDatabase(
                    db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
                );
        
                return { error: null, connection };
            } catch (err) {
                console.error("Error in getConnectionForClient:", err);
                return { error: 'Failed to establish a connection.', connection: null };
            }
        };
}

module.exports = rolePermissionController;