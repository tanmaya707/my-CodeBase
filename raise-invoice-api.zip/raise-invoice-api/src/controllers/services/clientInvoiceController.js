const BaseController = require("../BaseController");
const catchAsyncErrors = require("../../middleware/catchAsyncErrors");
const bcrypt = require("bcryptjs");
const db = require("../../models");
const clientModel = db.Clients;
const userCompanyModel = db.UserCompanies;
const planModel = db.Plans;
const planPriceModel = db.PlanPrices;
const userModel = db.Users;
const { Op } = require("sequelize");
const crypto = require("crypto");
const { createDatabase, getConnectedSpecificDB } = require("../../utils/utilities");
const JWTAuth = require("../../utils/jwtToken");
const mysqlConfig = require("../../config/index").Mysql;
const fileUploaderSingle = require("../../utils/fileUpload").fileUploaderSingle;


const { connectSpecificToDatabase } = require("../../config/specificConnect");
const taxModel = require("../../models/client/taxRatesModel");
const { template } = require("lodash");

class clientInvoiceController extends BaseController {
    constructor() {
        super();
    }

    //Invoice Operations 
    static createInvoice = catchAsyncErrors(async (req, res) => {
        const { autosaveEnabled, invoiceNumber, client_id, items, date, term, dueDate, subTotal, discount, gstTotal, total, paid, balance, paymentStatus, sentStatus, logo, paymentInstruction, comment, deposit,attachments, customInvoice, customInvoiceOption } = req.body;
        const userId = req.user.id;

        const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);
        if (error) {
            return res.status(404).json({ status: false, message: error });
        }

        const transaction = await connection.sequelize.transaction();
        try {
            const uuid = crypto.randomUUID();

            let client = {};
            if (client_id?.id) {
                client = await connection.Client.findOne({ where: { id: client_id.id } });
                if (client && !client.id) {
                    client = { ...client.toJSON(), id: client_id.id };
                }
            } else {
                client = await connection.Client.create({
                    uuid: crypto.randomUUID(),
                    name: client_id.name,
                    email: client_id.email,
                    phone: client_id.phone
                });
                if (client) {
                    await connection.ProjectContacts.create({
                        uuid: crypto.randomUUID(),
                        client_id : client.id,
                        client_admin_id: userId,
                        contact_name: client_id.name,
                        contact_email: client_id.email,
                        contact_phone: client_id.phone,
                        is_primary: true
                    });
                }
                client = client.toJSON ? client.toJSON() : client;
            }

            let filteredAttachments = [];
            if (attachments && typeof attachments === 'object' && attachments['']) {
                if (Array.isArray(attachments[''])) {
                    filteredAttachments = attachments[''].filter(att => typeof att !== 'undefined' && att !== null && att !== '');
                } else {
                    filteredAttachments = [attachments['']].filter(att => typeof att !== 'undefined' && att !== null && att !== '');
                }
            } else if (typeof attachments === 'string') {
                filteredAttachments = attachments.split(',').map(att => att.trim()).filter(att => att !== '');
            } else if (Array.isArray(attachments)) {
                filteredAttachments = attachments.filter(att => typeof att !== 'undefined' && att !== null && att !== '');
            } else if (attachments && typeof attachments === 'object') {
                filteredAttachments = Object.values(attachments).filter(att => typeof att !== 'undefined' && att !== null && att !== '');
            }
            let invoiceCreated = null;
            let itemDetails = [];
            if (autosaveEnabled && (autosaveEnabled === true || autosaveEnabled === "true")) {
                itemDetails = await Promise.all(
                    items.map(async (d) => {

                        let item;
                        // Update existing item
                        //     await connection.Items.update(
                        //         {
                        //             item_name: d.name,
                        //             item_Description: d.description,
                        //             rate: d.rate,
                        //             qty: d.quantity,
                        //             status: 1,
                        //         },
                        //         { where: { id: d.id }, transaction }
                        //     );
                        //     item = await connection.Items.findOne({ where: { id: d.id }, transaction });
                        // } else 
                        if (!d?.id){
                            // Create new item
                            item = await connection.Items.create({
                                uuid: crypto.randomUUID(),
                                item_name: d.name,
                                item_Description: d.description,
                                rate: d?.unitTypes ? d.rate / d.quantity : d.rate,
                                qty: 1,
                                // unit_code : d.unitTypes ?? '',
                                status: 1,
                            }, { transaction });
                        }

                        return {
                            id: item?.id ? item.id : d.id,
                            code : d.code ?? '',
                            name: item?.item_name ? item.item_name : d.name,
                            description: item?.item_Description ? item.item_Description : d.description,
                            rate: item?.rate ? item.rate : d.rate,
                            quantity: item?.qty ? item.qty : d.quantity,
                            unitTypes : item?.unit_code ? item.unit_code : d.unitTypes,
                            gstChecked: d.gstChecked ?? false,
                            gstValue: d.gstValue ?? '',
                            discountChecked: d.discountChecked ?? false,
                            discountType: d.discountType ?? 'flat',
                            discountValue: d.discountValue ?? ''
                        };
                    })
                );

                let invoiceFields = {
                    uuid,
                    invoiceNumber,
                    client_id: client,
                    items: itemDetails,
                    date,
                    term,
                    dueDate,
                    subTotal,
                    discount,
                    gstTotal,
                    total,
                    paid,
                    balance,
                    paymentStatus,
                    sentStatus,
                    logo,
                    paymentInstruction,
                    comment,
                    deposit,
                    customInvoice,
                    customInvoiceOption,
                    attachments: filteredAttachments
                };

                invoiceCreated = await super.create(res, connection.Invoice, invoiceFields, { transaction });
            } else {
                itemDetails = items;
                let invoiceFields = {
                    uuid,
                    invoiceNumber,
                    client_id: client,
                    items: items,
                    date,
                    term,
                    dueDate,
                    subTotal,
                    discount,
                    gstTotal,
                    total,
                    paid,
                    balance,
                    paymentStatus,
                    sentStatus,
                    logo,
                    paymentInstruction,
                    comment,
                    deposit,
                    customInvoice,
                    customInvoiceOption,
                    attachments: filteredAttachments
                };
                invoiceCreated = await super.create(res, connection.Invoice, invoiceFields, { transaction });
            }

            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Invoice created successfully.",
                data: {
                    invoice: invoiceCreated,
                    client,
                    items: itemDetails
                }
            });
        } catch (error) {
            await transaction.rollback();
            console.error('Error creating Invoice:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });

    static getAllInvoices = catchAsyncErrors(async (req, res) => {
        const userId = req.user.id;
        const { paymentStatus } = req.body;
        const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);
        if (error) {
            return res.status(404).json({ status: false, message: error });
        }

        try {
            const filter = {};
            if (paymentStatus && paymentStatus !== "") {
                filter.paymentStatus = paymentStatus;
            }

            let invoices = await connection.Invoice.findAll({
                where: filter,
                order: [['created_at', 'DESC']]
            });

            const enrichedInvoices = await Promise.all(
                invoices.map(async (inv) => {
                    let client;
                    if (typeof inv?.client_id === "string") {
                        try {
                            client = JSON.parse(inv.client_id);
                        } catch (err) {
                            console.error("Error parsing client JSON:", err);
                            client = {};
                        }
                    } else {
                        client = inv?.client_id || {};
                    }

                    let parsedItems;
                    if (typeof inv?.items === "string") {
                        try {
                            parsedItems = JSON.parse(inv.items);
                        } catch (err) {
                            console.error("Error parsing items JSON:", err);
                            parsedItems = [];
                        }
                    } else {
                        parsedItems = inv?.items || [];
                    }

                    let deposit;
                    if (typeof inv?.deposit === "string") {
                        try {
                            deposit = JSON.parse(inv.deposit);
                        } catch (err) {
                            console.error("Error parsing deposit JSON:", err);
                            deposit = {};
                        }
                    } else {
                        deposit = inv?.deposit || {};
                    }

                    return { ...inv.toJSON(), client, items: parsedItems, deposit };
                })
            );

            return res.status(200).json({
                status: true,
                message: "Invoices retrieved successfully.",
                data: enrichedInvoices
            });
        } catch (error) {
            console.error('Error fetching invoices:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });

    static fetchNextInvoiceNumber = catchAsyncErrors(async (req, res) => {
        const userId = req.user.id;
        const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);
        if (error) {
            return res.status(404).json({ status: false, message: error });
        }

        try {
            let invoices = await connection.Invoice.findAll({});

            const nextInvoiceNumber = invoices.length > 0 ? invoices[invoices.length - 1].id + 1 : 1;

            return res.status(200).json({
                status: true,
                message: "Next invoice number retrieved successfully.",
                data: { nextInvoiceNumber }
            });
        } catch (error) {
            console.error('Error fetching invoices:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });

    static getInvoiceDetails = catchAsyncErrors(async (req, res, next) => {
        const { id } = req.body;
        const userId = req.user.id;

        const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);
        if (error) {
            return res.status(404).json({ status: false, message: error });
        }

        try {
            const invoice = await connection.Invoice.findOne({
                where: { id: id },
            });

            if (!invoice) {
                return res.status(404).json({ status: false, message: 'Invoice not found' });
            }

            let client;
            if (typeof invoice?.client_id === "string") {
                try {
                    client = JSON.parse(invoice.client_id);
                } catch (err) {
                    console.error("Error parsing client JSON:", err);
                    client = {};
                }
            } else {
                client = invoice?.client_id || {};
            }

            // Add profileImage URL if present
            if (client && client.profileImage) {
                client.profileImage = `${req.protocol}://${req.get('host')}/uploads/${client.profileImage}`;
            }

            let items;
            if (typeof invoice?.items === "string") {
                try {
                    items = JSON.parse(invoice.items);
                } catch (err) {
                    console.error("Error parsing items JSON:", err);
                    items = [];
                }
            } else {
                items = invoice?.items || [];
            }

            let deposit;
            if (typeof invoice?.deposit === "string") {
                try {
                    deposit = JSON.parse(invoice.deposit);
                } catch (err) {
                    console.error("Error parsing deposit JSON:", err);
                    deposit = {};
                }
            } else {
                deposit = invoice?.deposit || {};
            }

            // Populate header, waterMark, colour, and logo details if present
            let settingData = invoice.customInvoice;

            if(!settingData || Object.keys(settingData).length === 0){
                // If no custom settings exist, use default values
                settingData = {
                    headerDetails: { headerImg: '', headerText: '' },
                    waterMarkDetails: { waterMarkImg: '' },
                    colourDetails: { colourCode: '' },
                    logoDetails: { logoImage: '' }
                };
            }
            else {
                // Populate header details
                if (settingData.headerImg) {
                    settingData.headerDetails = settingData.headerImg;
                }

                // Populate waterMark details
                if (settingData.waterMarkImg) {
                    settingData.waterMarkDetails = settingData.waterMarkImg;
                }

                // Populate colour details
                if (settingData.colourCode) {
                    settingData.colourDetails = settingData.colourCode;
                }

                // Populate logo details
                if (settingData.logoImage) {
                    settingData.logoDetails = settingData.logoImage;
                }
            }

            return res.status(200).json({
                status: true,
                message: "Invoice details retrieved successfully.",
                data: {
                    invoice,
                    client,
                    items,
                    deposit,
                    attachments: typeof invoice?.attachments === 'string' ? JSON.parse(invoice.attachments) : invoice?.attachments,
                    customInvoiceOption : typeof invoice?.customInvoiceOption === 'string' ? JSON.parse(invoice.customInvoiceOption) : invoice?.customInvoiceOption,
                    customInvoice: typeof settingData === 'string' ? JSON.parse(settingData) : settingData
                }
            });
        } catch (error) {
            console.error('Error fetching invoice details:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });

    static updateInvoice = catchAsyncErrors(async (req, res) => {
        const { id } = req.body;
        const { autosaveEnabled,invoiceNumber, client_id, items, date, term, dueDate, subTotal, discount, gstTotal, total, paid, balance, paymentStatus, sentStatus, attachments, logo, paymentInstruction, comment, deposit } = req.body;
        const userId = req.user.id;

        const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);
        if (error) {
            return res.status(404).json({ status: false, message: error });
        }

        const transaction = await connection.sequelize.transaction();

        let client = {};
        if (client_id?.id) {
            client = await connection.Client.findOne({ where: { id: client_id.id } });
            if (client && !client.id) {
                client = { ...client.toJSON(), id: client_id.id };
            }
        } else {
            client = await connection.Client.create({
                uuid: crypto.randomUUID(),
                name: client_id.name,
                email: client_id.email,
                phone: client_id.phone
            });
            if (client) {
                    await connection.ProjectContacts.create({
                        uuid: crypto.randomUUID(),
                        client_id : client.id,
                        client_admin_id: userId,
                        contact_name: client_id.name,
                        contact_email: client_id.email,
                        contact_phone: client_id.phone,
                        is_primary: true
                    });
                }
            client = client.toJSON ? client.toJSON() : client;
        }

        let filteredAttachments = [];
        if (attachments && typeof attachments === 'object' && attachments['']) {
            if (Array.isArray(attachments[''])) {
                filteredAttachments = attachments[''].filter(att => typeof att !== 'undefined' && att !== null && att !== '');
            } else {
                filteredAttachments = [attachments['']].filter(att => typeof att !== 'undefined' && att !== null && att !== '');
            }
        } else if (typeof attachments === 'string') {
            filteredAttachments = attachments.split(',').map(att => att.trim()).filter(att => att !== '');
        } else if (Array.isArray(attachments)) {
            filteredAttachments = attachments.filter(att => typeof att !== 'undefined' && att !== null && att !== '');
        } else if (attachments && typeof attachments === 'object') {
            filteredAttachments = Object.values(attachments).filter(att => typeof att !== 'undefined' && att !== null && att !== '');
        }

        let invoiceUpdateFields = {};
        let itemDetails = [];

        if (autosaveEnabled && (autosaveEnabled === true || autosaveEnabled === "true")) {
            try {
                itemDetails = (await Promise.all(
                    items.map(async (d) => {
                        let item;
                        // if (d.id) {
                        //     // Update existing item
                        //     await connection.Items.update(
                        //         {
                        //             item_name: d.name,
                        //             item_Description: d.description,
                        //             rate: d.rate,
                        //             qty: d.quantity,
                        //             status: 1,
                        //         },
                        //         { where: { id: d.id }, transaction }
                        //     );
                        //     item = await connection.Items.findOne({ where: { id: d.id } , transaction });

                        // } else {
                        //     // Create new item
                        //     item = await connection.Items.create({
                        //         uuid: crypto.randomUUID(),
                        //         item_name: d.name,
                        //         item_Description: d.description,
                        //         rate: d.rate,
                        //         qty: d.quantity,
                        //         status: 1,
                        //     }, { transaction });
                        // }

                        if (!d?.id){
                            // Create new item
                            item = await connection.Items.create({
                                uuid: crypto.randomUUID(),
                                item_name: d.name,
                                item_Description: d.description,
                                rate: d?.unitTypes ? d.rate / d.quantity : d.rate,
                                qty: 1,
                                // unit_code : d.unitTypes ?? '',
                                status: 1,
                            }, { transaction });
                        }

                        // if (item != null) {
                        return {
                            id: item?.id ? item.id : d.id,
                            code : d.code ?? '',
                            name: item?.item_name ? item.item_name : d.name,
                            description: item?.item_Description ? item.item_Description : d.description,
                            rate: item?.rate ? item.rate : d.rate,
                            quantity: item?.qty ? item.qty : d.quantity,
                            unitTypes : item?.unit_code ? item.unit_code : d.unitTypes,
                            gstChecked: d.gstChecked ?? false,
                            gstValue: d.gstValue ?? '',
                            discountChecked: d.discountChecked ?? false,
                            discountType: d.discountType ?? 'flat',
                            discountValue: d.discountValue ?? ''
                        };
                        // }
                    })
                )).filter(Boolean);
            } catch (error) {
                console.log("Error parsing items JSON:", error);
                return res.status(500).json({ status: false, message: "Error processing items data.", data: {} });
            }
            invoiceUpdateFields = {
                invoiceNumber,
                client_id: client,
                items: itemDetails,
                date,
                term,
                dueDate,
                subTotal,
                discount,
                gstTotal,
                total,
                paid,
                balance,
                paymentStatus,
                sentStatus,
                logo,
                paymentInstruction,
                comment,
                deposit,
                attachments : filteredAttachments
            };
        } else {
            itemDetails = items;
            let invoiceFields = {
                uuid,
                invoiceNumber,
                client_id: client,
                items: items,
                date,
                term,
                dueDate,
                subTotal,
                discount,
                gstTotal,
                total,
                paid,
                balance,
                paymentStatus,
                sentStatus,
                logo,
                paymentInstruction,
                comment,
                deposit,
                customInvoice,
                customInvoiceOption,
                attachments: filteredAttachments
            };
            invoiceCreated = await super.create(res, connection.Invoice, invoiceFields, { transaction });
        }

        const [updatedInvoiceCount, updatedInvoice] = await connection.Invoice.update(invoiceUpdateFields, {
            where: { id: id },
            returning: true,
            transaction
        });

        if (updatedInvoiceCount === 0) {
            return res.status(404).json({ status: false, message: 'Invoice not found' });
        }

        await transaction.commit();

        return res.status(200).json({
            status: true,
            message: "Invoice updated successfully.",
            data: {
                invoice: updatedInvoice[0],
                client,
                items: itemDetails,
            }
        });
    })

    static deleteInvoice = catchAsyncErrors(async (req, res, next) => {
        const { id } = req.body;
        const userId = req.user.id;

        const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);
        if (error) {
            return res.status(404).json({ status: false, message: error });
        }

        const transaction = await connection.sequelize.transaction();
        try {
            const deletedInvoiceCount = await connection.Invoice.destroy({
                where: { id: id },
                transaction
            });

            if (deletedInvoiceCount === 0) {
                return res.status(404).json({ status: false, message: 'Invoice not found' });
            }

            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Invoice deleted successfully."
            });
        } catch (error) {
            await transaction.rollback();
            console.error('Error deleting invoice:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });

    //For Mobile HTML Preview
    static previewInvoice = catchAsyncErrors(async (req, res) => {
        try {
            const { templateName, invoiceId, poId, cnId, esId } = req.body;
            const userId = req.user.id;

            // Get DB connection
            const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);
            if (error) {
                return res.status(404).json({ status: false, message: error });
            }

            // Fetch invoice/order
            let invoice = {};
            if (invoiceId) {
                invoice = await connection.Invoice.findOne({ where: { id: invoiceId } });
            } else if (poId) {
                invoice = await connection.PurchaseOrder.findOne({ where: { id: poId } });
            } else if (cnId) {
                invoice = await connection.CreditNote.findOne({ where: { id: cnId } });
            } else if (esId) {
                invoice = await connection.Estimate.findOne({ where: { id: esId } });
            }

            // Fetch settings
            const invoiceSetting = await connection.InvoiceSetting.findOne();
            const optionSetting = await connection.InvoiceOptionSetting.findOne();

            // Prepare settings data
            let settingData = invoiceSetting ? invoiceSetting.toJSON() : {};
            // Populate header, watermark, colour, and logo details if present
            if (settingData && Object.keys(settingData).length !== 0) {
                // Header
                if (settingData.header) {
                    const headerRecord = await connection.InvoiceHeader.findOne({ where: { id: settingData.header } });
                    if (headerRecord) {
                        const headerObj = headerRecord.toJSON();
                        if (headerObj.headerImg) {
                            headerObj.headerImg = `${req.protocol}://${req.get('host')}/uploads/${headerObj.headerImg}`;
                        }
                        settingData.headerDetails = headerObj;
                    }
                }
                // Watermark
                if (settingData.waterMark) {
                    const waterMarkRecord = await connection.InvoiceWaterMark.findOne({ where: { id: settingData.waterMark } });
                    if (waterMarkRecord) {
                        const wmObj = waterMarkRecord.toJSON();
                        if (wmObj.waterMarkImg) {
                            wmObj.waterMarkImg = `${req.protocol}://${req.get('host')}/uploads/${wmObj.waterMarkImg}`;
                        }
                        settingData.waterMarkDetails = wmObj;
                    }
                }
                // Colour
                if (settingData.colour) {
                    const colourRecord = await connection.InvoiceColour.findOne({ where: { id: settingData.colour } });
                    if (colourRecord) {
                        settingData.colourDetails = colourRecord.toJSON();
                    }
                }
                // Logo
                if (settingData.logo) {
                    const logoRecord = await connection.InvoiceLogo.findOne({ where: { id: settingData.logo } });
                    if (logoRecord) {
                        const logoObj = logoRecord.toJSON();
                        if (logoObj.logoImage) {
                            logoObj.logoImage = `${req.protocol}://${req.get('host')}/uploads/${logoObj.logoImage}`;
                        }
                        settingData.logoDetails = logoObj;
                    }
                }
            }

            // Fallbacks for settings
            const selectedLogo = (settingData.logoDetails && settingData.logoDetails.logoImage) || "";
            const selectedHeader = (settingData.headerDetails && settingData.headerDetails.headerImg) || "";
            const selectedHeaderText = (settingData.headerDetails && settingData.headerDetails.headerText) || "";
            const selectedWatermark = (settingData.waterMarkDetails && settingData.waterMarkDetails.waterMarkImg) || "";
            const customColour = (settingData.colourDetails && settingData.colourDetails.colourCode) || "#ecf0f1";
            const selectedSize = (settingData.logoDetails && settingData.logoDetails.size) || "medium";
            const alignPos = (settingData.logoDetails && settingData.logoDetails.align) || "center";

            // Parse invoice fields
            let client = {};
            let items = [];
            let deposit = {};
            try {
                if(invoice?.client_id){
                    client = typeof invoice.client_id === "string" ? JSON.parse(invoice.client_id) : invoice.client_id || {};
                } else {
                    client = typeof invoice.client === "string" ? JSON.parse(invoice.client) : invoice.client || {};
                }
               
            } catch { client = {}; }
            try {
                items = typeof invoice.items === "string" ? JSON.parse(invoice.items) : invoice.items || [{ quantity: 2, description: "Consulting Services", rate: 150, taxPercent: 18 }];
            } catch { items = []; }
            try {
                deposit = typeof invoice.deposit === "string" ? JSON.parse(invoice.deposit) : invoice.deposit || {};
            } catch { deposit = {}; }

            // Option settings
            const {
                due_date,
                payment_terms,
                itemCode,
                quantityAndRate,
                pTax,
                tax_amounts,
                includeSignatureLine,
                invoicePrifix
            } = optionSetting || {};

            // Currency
            const currencySymbols = {
                INR: "₹", USD: "$", EUR: "€", GBP: "£", JPY: "¥", AUD: "A$", CAD: "C$", SGD: "S$", CNY: "¥"
            };
            const symbol = currencySymbols[invoice.currency] || "$";

            // Helper: format date as dd-mm-yyyy
            function formatDate(dateStr) {
                if (!dateStr) return '';
                const date = new Date(dateStr);
                const dd = String(date.getDate()).padStart(2, '0');
                const mm = String(date.getMonth() + 1).padStart(2, '0');
                const yyyy = date.getFullYear();
                return `${dd}-${mm}-${yyyy}`;
            }

            // Invoice fields
            const subtotal = typeof invoice.subtotal === "number"
                ? invoice.subtotal
                : items.reduce((sum, item) => sum + ((Number(item.quantity) || 0) * (Number(item.rate) || 0)), 0);
            const discount = typeof invoice.discountTotal === "number"
                ? invoice.discountTotal
                : Number(invoice.discount) || 0;
            const tax = typeof invoice.gstTotal === "number"
                ? invoice.gstTotal
                : ((subtotal - discount) * (items[0]?.taxPercent || 0)) / 100;
            const total = typeof invoice.total === "number"
                ? invoice.total
                : subtotal - discount + tax;

            const todayFormatted = formatDate(new Date().toISOString());
            const invoiceDate = formatDate(invoice.invoiceDate);
            const dueDate = formatDate(invoice.dueDate);

            // Settings from parameters or DB
            const headerColor = customColour;
            const logoUrl = invoice.logo || selectedLogo;
            const headerImg = selectedHeader;
            const logoAlign = alignPos;
            const watermarkImg = selectedWatermark;

            let logoFontSize;
            switch (selectedSize) {
                case "small": logoFontSize = "80px"; break;
                case "large": logoFontSize = "140px"; break;
                default: logoFontSize = "110px";
            }

            // Invoice number with prefix
            const invoiceNumber = `${invoicePrifix || ""}${invoice.invoiceNumber || invoice.creditMemoNumber || invoice.poNumber || "0000"}`;

            // Table columns logic
            const showItemCode = !!itemCode;
            const showQuantityAndRate = !!quantityAndRate;
            const showPTax = !!pTax;

            // Table header columns
            const tableHeaders = [];
            if (showItemCode) tableHeaders.push({ label: "Item Code", style: { width: '10%' } });
            if (showQuantityAndRate) tableHeaders.push({ label: "Quantity", style: { width: '15%' } });
            tableHeaders.push({ label: "Description", style: { width: '35%' } });
            if (showQuantityAndRate) tableHeaders.push({ label: "Unit Price", style: { width: '15%' } });
            if (showPTax) tableHeaders.push({ label: "Tax", style: { width: '10%' } });
            tableHeaders.push({ label: "Amount", style: { width: '15%' } });

            // Compose HTML
            let html = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Invoice Preview</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
 <style>
                    .middle-area-note {
                        padding: 65px 0px;
                        margin: 0;
                    }
                    .addNote .contentArea-inner {
                        width: 100%;
                        margin: auto;
                    }
                    .cross-icon {
                        margin-bottom: auto;
                    }
                    .preview-card {
                        background-color: #f2fafe;
                    }
                    .addnote-nav {
                        display: flex;
                        align-items: flex-end;
                        list-style: none;
                        gap: 50px;
                        margin-top: 16px;
                        cursor: pointer;
                    }
                    .addNote .nav-item {
                        font-family: Rubik;
                        font-weight: 400;
                        font-size: 16px;
                        line-height: 100%;
                        letter-spacing: -1.5%;
                        color: #FFFFFFBF;
                    }
                    .addNote .nav-item-active {
                        font-family: Rubik;
                        font-weight: 600;
                        font-size: 16px;
                        line-height: 100%;
                        letter-spacing: -1.5%;
                        color: #FFFFFF;
                    }
                    .addNote .navbar-tab {
                        width: 100%;
                        display: flex;
                        align-items: center;
                        justify-content: space-between;
                        overflow: hidden;
                        background-color: #047FFF;
                        height: 55px;
                        margin: 20px 0;
                        padding: 0 40px 0 80px;
                    }
                    .initials {
                        /* font-family: Rubik; */
                        display: inline-block;
                        font-size: 24px;
                        font-weight: 500;
                        line-height: 24px;
                        text-align: left;
                        background-color: #44BBFE;
                        color: #ffff;
                        border-radius: 50%;
                        /* padding: 22px 18px; */
                        width: 60px;
                        height: 60px;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                    }
                    .cross-icon {
                        margin-bottom: auto;
                    }
                    .image-card {
                        border: 1px dotted #047FFF40;
                        border-radius: 11px;
                    }
                    .image-card .card-body {
                        display: flex;
                        flex-direction: column;
                        align-items: center;
                        justify-content: center;
                        height: 120px;
                    }
                    .image-card .card-body button{ 
                        margin-top: 10px;
                    
                    }
                    .bill-section {
                    max-width: 900px;
                    margin: 40px auto;
                    padding: 40px 50px;
                    background: #fff;
                    border-radius: 14px;
                    border: 1px solid #e0e7ef;
                    box-shadow: 0 8px 32px 0 rgba(4,127,255,0.08), 0 1.5px 6px 0 rgba(52,64,84,0.06);
                    font-size: 17px;
                    line-height: 28px;
                    font-family: 'Rubik', 'Helvetica Neue', Helvetica, Arial, sans-serif;
                    color: #344054;
                    position: relative;
                    transition: box-shadow 0.3s;
                    }

                    .bill-section:hover {
                    box-shadow: 0 12px 40px 0 rgba(4,127,255,0.13), 0 2px 8px 0 rgba(52,64,84,0.09);
                    }

                    .bill-section h2, .bill-section h3 {
                    color: #047FFF;
                    margin-bottom: 18px;
                    font-weight: 600;
                    letter-spacing: 0.5px;
                    }

                    .bill-section .template-preview {
                    border: 1px solid #e5e7eb;
                    border-radius: 8px;
                    padding: 24px;
                    background: #f8fbff;
                    margin-bottom: 24px;
                    box-shadow: 0 2px 8px 0 #047FFF0A;
                    }

                    .bill-section .template-actions {
                    display: flex;
                    justify-content: flex-end;
                    gap: 16px;
                    margin-top: 20px;
                    }

                    .bill-section .template-actions button {
                    background: #047FFF;
                    color: #fff;
                    border: none;
                    border-radius: 6px;
                    padding: 10px 22px;
                    font-size: 15px;
                    font-weight: 500;
                    cursor: pointer;
                    transition: background 0.2s;
                    }

                    .bill-section .template-actions button:hover {
                    background: #025bb5;
                    }
                    .add-photo {
                        font: Rubik;
                        border: none;
                        background-color: #ffff;
                        font-size: 14px;
                        font-weight: 400;
                        line-height: 100%;
                        color: #047FFF;
                    }
                    .go_back {
                        /* font-family: Rubik; */
                        font-size: 20px;
                        font-weight: 500;
                        line-height: 24px;
                        text-align: left;
                        text-decoration: none;
                        color: #344054;
                        margin: 70px;
                    }
                    .addnote-items p {
                        font-size: 14px;
                        font-weight: 400;
                        line-height: 16px;
                        color: #344054;
                        text-align: left;
                    }
                    .bill p {
                        text-align: right;
                    }
                    .bill {
                        text-align: right;
                    }
                    .gst {
                        font-size: 12px;
                        font-weight: 300;
                        line-height: 24px;
                        text-align: right;
                    }
                    .invoice-tabs {
                        display: flex;
                        align-items: center;
                        justify-content: end;
                        gap: 10px;
                    }
                    .invoice-tabs span {
                        border: 1px solid #047FFF;
                        border-radius: 35px;
                        color: #047FFF;
                        padding: 5px 15px;
                        font-family: Roboto;
                        font-size: 14px;
                        font-weight: 500;
                        line-height: 30.5px;
                        text-align: center;
                    }
                    .preview-invoice {
                        margin-bottom: 6rem;
                    }
                    .preview-invoice th, td {
                        text-align: right;
                        border: none;
                    }
                    .preview-invoice .left-column {
                        font-family: Inter;
                        font-weight: 700;
                        font-size: 14.9px;
                        line-height: 100%;
                        letter-spacing: 0%;
                        text-align: left;
                        color: #121722;
                    }
                    .preview-invoice th {
                        font-family: Inter;
                        font-weight: 400;
                        font-size: 11.46px;
                        line-height: 100%;
                        letter-spacing: 0%;
                        text-align: right;
                        color: #60737D;
                    }
                    .preview-invoice td {
                        font-family: Inter;
                        font-weight: 400;
                        font-size: 12.61px;
                        line-height: 100%;
                        letter-spacing: 0%;
                        text-align: left;
                        color: #60737D;
                    }
                    .total {
                        color: #121722;
                    }
                    .table-data {
                        text-align: right !important;
                    }
                    .card-upper {
                        display: flex;
                        align-items: flex-start;
                        justify-content: space-between;
                        background-color: #E6F2FF;
                        border-radius: 14px;
                        padding: 20px;
                    }
                    .card-upper div:nth-of-type(1) {
                        text-align: left;
                    }
                    .card-upper div:nth-of-type(2) {
                        text-align: right;
                    }
                    .card-upper p {
                        margin-bottom: 2px;
                    }
                    .preview-card {
                        background-color: #f2fafe;
                        padding: 35px 50px 0;
                        border-radius: 14px;
                        margin-top: 35px;
                    }
                    .preview-card .card {
                        border-radius: 20px;
                        border: none;
                        box-shadow: none;
                    }
                    .card-upper h4 {
                        /* font-family: Inter; */
                        font-size: 22.92px;
                        font-weight: 700;
                        line-height: 27.74px;
                        text-align: left;
                        color: #047FFF;
                        margin-bottom: 35px;
                    }
                    .card-upper div p:nth-of-type(odd) {
                        /* font-family: Inter; */
                        font-size: 11.46px;
                        font-weight: 400;
                        line-height: 13.87px;
                        color: #60737D;
                    }
                    .card-upper div p:nth-of-type(even) {
                        font-family: Inter;
                        font-size: 11.46px;
                        font-weight: 400;
                        line-height: 13.87px;
                        color: #121722;
                        margin-bottom: 15px;
                    }
                    .card-upper h6, .invoice-num {
                        /* font-family: Inter; */
                        font-size: 16.05px !important;
                        font-weight: 600 !important;
                        line-height: 19.42px !important;
                        color: #121722;
                    }
                    .invoice-num {
                        margin-bottom: 30px !important;
                    }
                    .email-setup {
                        display: flex;
                        align-items: baseline;
                        justify-content: flex-start;
                        gap: 30px;
                    }
                    .email-setup p {
                        font-family: Rubik;
                        font-weight: 500;
                        font-size: 14px;
                        line-height: 100%;
                        letter-spacing: 0%;
                        color: #047FFF;
                    }
                    .add-invoice-form {
                        width: 85%;
                        margin: auto;
                    }
                    .seperator-text {
                        display: flex;
                        align-items: baseline;
                        justify-content: center;
                        gap: 10px;
                    }
                    .horizontal-line {
                        border: 1px solid #047FFF40;
                        width: 7%;
                        box-shadow: 0px 0px 20px 0px #047FFF1A;
                    }
                    .multiple-btn {
                        width: 60%;
                        margin: auto;
                    }
                    .without-icon {
                        padding: 0px 15px !important;
                    }


                    .invoiceSection h5 {
                        font-family: Rubik;
                        font-weight: 500;
                        font-size: 16px;
                        line-height: 24px;
                        color: #344054;
                    }

                    .invoiceSectionInner {
                        display: flex;
                        align-items: center;
                        gap: 10px;
                    }


                    li.gstSection span {
                        display: flex;
                        align-items: center;
                        gap: 10px;
                        color: #047FFF !important;
                    }

                    .react-calendar {
                        max-width: 100%;
                        background: white;
                        border: 1px solid #a0a096;
                        font-family: 'Arial', 'Helvetica', sans-serif;
                        line-height: 1.125em;
                        position: absolute;
                        right: -6px;
                        min-width: 243px;
                        z-index: 9;
                    }


                    .accordion-button:not(.collapsed)::after, .accordion-button::after {
                        background-size: cover;
                        border-radius: 0px;
                        border-width: 0 2px 2px 0;
                        display: inline-block;
                        padding: 6px;
                        width: 7px;
                        height: 0px;
                        filter: invert(39%) sepia(89%) saturate(3670%) hue-rotate(197deg) brightness(100%) contrast(109%) !important;
                    }

                    .contactDetails{
                        border-radius: 11px !important;
                    }


                    span.edit {
                        border-bottom: 1px solid #00000021;
                        margin-bottom: 6px;
                        padding: 0px 13px 8px 13px;
                    }

                    .editDelete {
                        position: absolute;
                        right: -26px;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        flex-direction: column;
                        border: 1px solid #047FFF1A;
                        box-shadow: 0px 0px 20px 0px #047FFF1A;
                        padding: 8px 0;
                        border-radius: 10px;
                        background: #fff;
                    }
                    /* DELETE THIS ENTIRE BLOCK FROM YOUR CSS FILE */

                    /* .search-input-retains-placeholder:focus::placeholder {
                    color: #a9a9a9;
                    opacity: 1;
                    }

                    .search-input-retains-placeholder:focus::-webkit-input-placeholder {
                    color: #a9a9a9;
                    opacity: 1;
                    }

                    .search-input-retains-placeholder:focus::-moz-placeholder {
                    color: #a9a9a9;
                    opacity: 1; 
                    } */

                    /* etc... */


                    .search-input-retains-placeholder::placeholder,.form-control::placeholder {
                        visibility: visible !important;
                    }

                    .form-control {
                        font-size: 14px;
                    }


                    .searchCustom .search-input-retains-placeholder {
                        width: 100% !important;
                        padding: 10px 20px;
                    }

                    .listingSearchMain .list-group {
                        overflow-y: auto;
                        max-height: 300px;
                    }


                    .listingDetails span {
                        display: block;
                        margin-left: 22px !important;
                        width: -webkit-fill-available;
                        word-break: break-all;
                        font-size: 13px;
                        line-height: 17px;
                    }


                    .list-group::-webkit-scrollbar {
                        width: 8px; /* Width of the scrollbar */
                        height: 12px; /* Height of the scrollbar */
                    }
                    .list-group::-webkit-scrollbar-track {
                        background: #f1f1f1; /* Background of the scrollbar track */
                        border-radius: 10px; /* Rounded corners for the track */
                    }
                    .list-group::-webkit-scrollbar-thumb {
                        background: #6ab2ff; /* Color of the scrollbar thumb */
                        border-radius: 10px; /* Rounded corners for the thumb */
                    }
                    .list-group::-webkit-scrollbar-thumb:hover {
                        background: #2386f0; /* Color of the thumb on hover */
                    }


                    .invoiveListLeftTop {
                        display: flex;
                        align-items: center;
                        justify-content: space-between;
                        box-shadow: 0px 0px 20px 0px #047FFF1A;
                        border-radius: 10px;
                        padding: 10px;
                        margin: 20px 0;
                    }
                    .imgTxt{
                        display: flex;
                        align-items: center;
                        gap: 10px;
                    }

                    .invoiveListLeftImg {
                        border: 1px solid #FFFFFF4D;
                        background: #e6f2ff;
                        padding: 6px;
                        border-radius: 6px;
                    }

                    .invoiveListLeftText img {
                        color: #344054;
                        font-family: Rubik;
                        font-weight: 500;
                        font-size: 14px;
                        line-height: 28px;
                        letter-spacing: 0px;
                    }
                    .paymentRemainder .checkbox-previewmail.borderBottom {
                        display: flex;
                        align-items: center;
                        gap: 20px;
                    }

                    .checkbox-previewmail.borderBottom .preview-mail{
                    font-family: Rubik;
                    font-weight: 400;
                    font-style: Regular;
                    font-size: 14px;
                    line-height: 100%;
                    letter-spacing: -1.5%;
                    color: #344054;

                    }

                    a.preview-mail {
                        color: #047FFF !important;
                    }

                    .recInvoice{
                        padding: 10px 0;
                    }

                    .deposit-footer{
                        display: flex;
                        align-items: center;
                        gap: 19px;
                    }

                    .deposit-footer-container {
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        .cancel-button {
                            border: none;
                            border-radius: 35px;
                            padding: 2px 20px;
                            font-size: 16px;
                            font-weight: 500;
                            text-align: center;
                            color: #ffff;
                        }
                    }
                            .addClientFormTopLeft ul {
                        display: flex;
                        align-items: center;
                        justify-content: space-between;
                        width: 100%;
                    }
                    .clientPadding {
                        padding: 80px 0 30px 0px;
                        width: 100%;
                    }
                    button.clientFormBackBtn {
                        font-family: Rubik;
                        font-weight: 500;
                        font-size: 17px;
                        line-height: 24px;
                        color: #344054;
                        background: unset;
                        border: 0;
                        text-transform: capitalize;
                        display: flex;
                        align-items: center;
                        gap: 10px;
                        padding: 0px 20px 0 41px;
                    }
                    .addClientFormTop {
                        display: flex;
                        align-items: center;
                        justify-content: space-between;
                        background: #047FFF;
                        width: 100%;
                        padding: 0px 41px;
                        margin-top: 10px;
                        margin-bottom: 30px;
                    }
                    .addClientFormTopLeft ul {
                        margin: 0;
                        display: flex;
                        align-items: center;
                        gap: 31px;
                        list-style: none;
                        padding: 0;
                    }
                    .addClientFormTopLeft ul li {
                        color: #ffffffc9;
                        font-family: Rubik;
                        font-weight: 400;
                        font-size: 16px;
                        line-height: 100%;
                        padding: 14px 8px;
                    }

                    .addClientFormTopLeft ul li.active {
                        color: #fff;
                    }

                    .addClientFormTopRight button {
                        color: #047FFF;
                        background: #fff;
                        border: 0;
                        padding: 2px 18px;
                        border-radius: 17px;
                    }

                    .contactDetails {
                        box-shadow: 0px 0px 20px 0px #047FFF1A;
                        width: 315px;
                        border: 1px solid #047FFF40;
                        padding: 20px;
                        border-radius: 20px;
                        display: flex;
                        align-items: center;
                        position: relative;
                        gap: 20px;
                    }
                    .contactDetailsLeft h3 {
                        color: #FFFFFF;
                        background: #44BBFE;
                        width: 56px;
                        height: 56px;
                        border-radius: 50%;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        font-size: 21px;
                    }


                    .contactDetailsRight h4 {
                        color: #344054;
                        font-family: Rubik;
                        font-weight: 500;
                        font-size: 16px;
                        line-height: 1;
                        margin: 0;
                    }
                    .contactDetailsRight ul {
                        list-style: none;
                        padding: 10px 0 0 0px;
                        margin: 0;
                    }
                    .contactDetailsRight ul li {
                        display: flex;
                        align-items: center;
                        gap: 9px;
                    }

                    .contactDetailsRight ul li {
                        font-size: 13px;
                        color: #344054;
                        font-family: Rubik;
                        font-weight: 300;
                        font-size: 12px;
                        line-height: 20px;
                    }

                    .crossBtn {
                        position: absolute;
                        right: 11px;
                        top: 11px;
                        color: #8990A1;
                        cursor: pointer;
                    }


                    .image-card {
                        border: 1px dotted #047FFF40;
                        border-radius: 11px;
                    }
                    .image-card .card-body {
                        display: flex;
                        flex-direction: column;
                        align-items: center;
                        justify-content: center;
                        height: 120px;
                    }
                    .image-card .card-body button{ 
                        margin-top: 10px;
                    }
                    .add-photo {
                        font: Rubik;
                        border: none;
                        background-color: #ffff;
                        font-size: 14px;
                        font-weight: 400;
                        line-height: 100%;
                        color: #047FFF;
                    }

                    .invoiceSectionInner {
                        display: flex;
                        align-items: center;
                        gap: 10px;
                    }

                    .invoiceSectionInner h6 {
                        font-family: Rubik;
                        font-weight: 500;
                        font-size: 20px;
                        line-height: 24px;
                        color: #344054;
                        margin: 0;
                    }
                    .invoiceSectionInner span {
                        color: #047FFF;
                        cursor: pointer;
                    }

                    p.unsent {
                        color: #F25022;
                        font-family: Rubik;
                        font-weight: 400;
                        font-size: 14px;
                        line-height: 1;
                        letter-spacing: 0px;
                        margin: 9px 0;
                    }
                    .invoiceBox {
                        border: 1px solid #E5E7EB;
                        box-shadow: 0px 0px 4px 0px #0000001A;
                        border-radius: 20px;
                        padding: 10px;
                        width: -moz-fit-content;
                        width: 100%;
                        /* min-width: 300px; */
                    }
                    .invoiceBox ul {
                        padding: 0;
                        border-bottom: 1px solid #E5E7EB;
                    }
                    .invoiceBox ul li {
                        display: flex;
                        align-items: center;
                        gap: 10px;
                        justify-content: space-between;
                        padding-bottom: 9px;
                    }

                    .invoiceBox ul li p {
                        margin: 0;
                        color: #344054;
                        font-family: Rubik;
                        font-weight: 400;
                        font-size: 12px;
                        line-height: 20px;
                    }

                    .invoiceBox ul li span {
                        font-family: Rubik;
                        font-weight: 500;
                        font-size: 14px;
                        line-height: 24px;
                        text-align: right;
                        color: #344054;
                        min-width: 108px;
                    }



                    .invoiceBox select.form-select {
                        padding: 0 29px 0 0;
                        border: 0;
                        text-align: right;
                    }

                    .addClientFormInner {
                        padding: 0px 43px;
                    }

                    .listBorder {
                        border-bottom: 1px solid #047FFF;
                        min-width: 108px;
                    }
                    .invoiceBox .borderBottom:last-child{
                        border-bottom: 0;
                        margin-bottom: 0;
                    }

                    span.editGST {
                        color: #047FFF !important;
                        display: flex;
                        align-items: center;
                        gap: 7px;
                        justify-content: flex-end;
                    }

                    .addClientFormTopLeft ul li.active {
                        border-bottom: 2px solid #fff;
                    }
                    .invoiceHeaderLeft {
                        padding-left: 20px;
                    }

                    select#cars {
                        appearance: none;
                    }

                    p.dropdownIcon {
                        cursor: pointer;
                    }

                    .productName {
                        box-shadow: 0px 0px 20px 0px #047FFF1A;
                        border-radius: 11px;
                        display: flex;
                        align-items: center;
                        gap: 10px;
                        position: relative;
                        margin-bottom: 20px;
                        cursor: grab;
                        min-height: 96px;
                        padding-right: 30px;
                    }

                    .productNameLeftDot {
                        border-right: 1px solid #D9D9D940;
                        height: -webkit-fill-available;
                        padding: 10px;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                    }

                    .productNameLeft h6 {
                        font-family: Rubik;
                        font-weight: 500;
                        font-size: 14px;
                        line-height: 15px;
                        color: #047FFF;
                    }

                    .productNameLeft p {
                        color: #344054;
                        font-family: Rubik;
                        font-weight: 400;
                        font-size: 14px;
                        line-height: 16px;
                        letter-spacing: 0px;
                        margin: 0;
                    }
                    .productNameRight h6 {
                        font-family: Rubik;
                        font-weight: 500;
                        font-size: 20px;
                        line-height: 24px;
                        text-align: right;
                        color: #344054;
                    }
                    .productNameRight p {
                        color: #344054;
                        font-family: Rubik;
                        font-weight: 400;
                        font-size: 14px;
                        line-height: 100%;
                        text-align: right;
                        margin: 0;
                    }

                    .productNameRight span {
                        color: #344054;
                        font-family: Rubik;
                        font-weight: 300;
                        font-size: 12px;
                        line-height: 24px;
                        text-align: right;
                        display: block;
                    }

                    .editDelete {
                        position: absolute;
                        right: -14px;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        flex-direction: column;
                        border: 1px solid #047FFF1A;
                        box-shadow: 0px 0px 20px 0px #047FFF1A;
                        padding: 8px 0;
                        border-radius: 10px;
                        background: #fff;
                    }
                    .editDelete svg {
                        color: #047FFF;
                    }

                    .productNameLeft {
                        width: 70%;
                    }
                    .productNameRight {
                        width: 20%;
                        padding: 10px 0;
                    }

                    span.edit {
                        border-bottom: 1px solid #00000021;
                        margin-bottom: 6px;
                        padding: 0 6px;
                    }

                    .checkboxLeft {
                        min-width: 97px;
                    }

                    .checkboxRight input {
                        min-width: 126px;
                    }

                    .accordion-body {
                        padding: 20px 8px;
                    }

                    .invoiceSectionInner .input-form-control{
                            max-height: 31px;
                    }

                    .tag {
                        padding: 0 !important;
                        margin: 0 !important;
                    }

                    /* .modal-body {
                        margin-top: 0 !important;
                    } */

                    .gst-modal h4 {
                        padding: 8px 30px;
                    }

                    .tab-heading span{
                        padding: 7px 10px 4px 10px !important;
                        position: relative;
                    }

                    .tab-heading span.active::after{   
                        position: absolute;
                        content: "";
                        background-color: #fff;
                        width: 100%;
                        height: 2px;
                        left: 0;
                        right: 0;
                        bottom: -9px;
                    }

                    .rate-chart {
                        padding: 20px 32px 0 32px;
                    }

                    .rate-chart h6 {
                        padding: 0;
                    }

                    .rate-chart .modal-btn.addBtnn {
                        margin-bottom: 0;
                    }


                    .taxRatModal .modal-body .modal-btn.addBtnn {
                        margin-bottom: 0;
                        margin: 44px auto 0px auto !important;
                    }

                    .taxRatModal .modal-body {
                        padding: 20px !important;
                        margin: 0;
                        width: 100%;
                    }

                    .invoiceHeaderLeft .invoiceBox{
                        border-radius: 4px;
                    }   

                    .communication-inner .accordion-header {
                        border: none;
                        box-shadow: unset;
                    }
                </style>
</head>
<body>
    <div class="row" style="margin:0;padding:0;height:100%;min-height:100vh;">
        <div class="col-md-12" style="margin:0;padding:0;height:100%;">
            <div class="preview-card" style="padding:0;margin:0;position:relative;overflow:hidden;height:100%;min-height:100vh;box-sizing:border-box;background:#f5f5f5;">
                <div class="tableTopContainer" style="margin:0;padding:0;font-family:Arial,sans-serif;background-color:#f5f5f5;position:relative;z-index:3;min-height:calc(100vh - 80px);">
                    <table width="100%" cellpadding="0" cellspacing="0" style="background-color:#f5f5f5;padding:0;margin:0;height:100%;border-collapse:separate;">
                        <tbody>
                            <tr>
                                <td align="center" style="padding:0;margin:0;">
                                    <table width="100%" cellpadding="0" cellspacing="0" style="background-color:#ffffff;border-radius:8px;box-shadow:0 2px 10px rgba(0,0,0,0.1);position:relative;margin:0;padding:0;height:100%;">
                                        <tbody>
                                            ${watermarkImg ? `<img src="${watermarkImg}" alt="Watermark" style="position:absolute;top:50%;left:50%;transform:translate(-50%, -50%);opacity:0.12;z-index:1;pointer-events:none;width:60%;max-width:400px;" />` : ""}
                                            ${headerImg ? `<img src="${headerImg}" alt="Header Image" style="width:100%;height:80px;background:url(${headerImg}) center center / cover no-repeat;margin:0;padding:0;border-top-left-radius:8px;border-top-right-radius:8px;" />` : ""}
                                            <tr>
                                                <td style="padding:10px 40px 0 40px;">
                                                    <table width="100%" cellpadding="0" cellspacing="0">
                                                        <tbody>
                                                            <tr>
                                                                <td style="font-size:16px;font-weight:bold;color:#2c3e50;text-align:left;vertical-align:middle;width:33%;padding-right:10px;">
                                                                    ${invoice.name || "Invoice"} #${invoiceNumber}
                                                                </td>
                                                                <td style="text-align:${logoAlign};width:33%;vertical-align:middle;padding:0;">
                                                                    ${logoUrl ? `<img src="${logoUrl}" alt="Logo" style="width:${logoFontSize};object-fit:contain;border-radius:8px;border:1px solid #e2e8f0;display:inline-block;vertical-align:middle;" />` : ""}
                                                                </td>
                                                                <td style="text-align:right;width:33%;vertical-align:middle;padding-left:10px;">
                                                                    <div style="font-size:13px;font-weight:bold;color:#2c3e50;">
                                                                        ${(client && client.name) || 'Client Name'}
                                                                    </div>
                                                                    <div style="font-size:10px;color:#7f8c8d;">
                                                                        ${(client && client.email) || 'Email'}
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td colspan="3" style="padding-top:8px;padding-bottom:8px;">
                                                                    <div style="text-align:end;display:flex;flex-direction:column;font-size:12px;color:#34495e;font-weight:500;line-height:18px;">
                                                                        <div><strong>Date:</strong> ${todayFormatted}</div>
                                                                        ${(invoice.name === "Invoice") ? `
                                                                            ${payment_terms ? `<div><strong>Terms:</strong> ${invoice.paymentTerms || '0'}</div>` : ""}
                                                                            ${due_date ? `<div><strong>Due Date:</strong> ${dueDate || todayFormatted}</div>` : ""}
                                                                        ` : ""}
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="padding:10px 40px;">
                                                    <hr style="border:none;border-top:2px solid ${headerColor};margin:0;" />
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="padding:10px 40px;">
                                                    <div style="font-size:13px;font-weight:bold;color:#2c3e50;margin-bottom:15px;text-align:left;">
                                                        Bill to: ${(client && client.name) || 'Client Name'}
                                                    </div>
                                                    <table width="100%" cellpadding="0" cellspacing="0">
                                                        <tbody>
                                                            <tr>
                                                                <td width="25%" style="font-size:10px;color:#2c3e50;padding-bottom:5px;text-align:left;">
                                                                    <strong>Client Name</strong><br />
                                                                    ${(client && client.name) || '-'}
                                                                </td>
                                                                <td width="25%" style="font-size:10px;color:#2c3e50;padding-bottom:5px;text-align:left;">
                                                                    <strong>Email</strong><br />
                                                                    ${(client && client.email) || '-'}
                                                                </td>
                                                                <td width="25%" style="font-size:10px;color:#2c3e50;padding-bottom:5px;text-align:left;">
                                                                    <strong>Client Address</strong><br />
                                                                    ${(client && client.address) || '-'}
                                                                </td>
                                                                <td width="25%" style="font-size:10px;color:#2c3e50;padding-bottom:5px;text-align:left;">
                                                                    <strong>Phone Number</strong><br />
                                                                    ${(client && client.phone) || '-'}
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="padding:20px 40px;">
                                                    <table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;">
                                                        <thead>
                                                            <tr style="background-color:${headerColor};">
                                                                ${tableHeaders.map(th => `<td style="border:1px solid #bdc3c7;padding:5px;font-weight:bold;text-align:center;font-size:12px;${tableHeaders.length === 2 ? 'width:50%;' : (th.style ? Object.entries(th.style).map(([k, v]) => `${k}:${v}`).join(';') : '')}">${th.label}</td>`).join('')}
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            ${items.map(item => `
                                                                <tr>
                                                                    ${showItemCode ? `<td style="border:1px solid #bdc3c7;padding:5px;text-align:center;font-size:10px;">${item.code || ''}</td>` : ""}
                                                                    ${showQuantityAndRate ? `<td style="border:1px solid #bdc3c7;padding:5px;text-align:center;font-size:10px;">${item.quantity || 0}</td>` : ""}
                                                                    <td style="border:1px solid #bdc3c7;padding:5px;text-align:center;font-size:10px;">${item.description || item.name || '-'}</td>
                                                                    ${showQuantityAndRate ? `<td style="border:1px solid #bdc3c7;padding:5px;text-align:center;font-size:10px;">${symbol}${(Number(item.rate) || 0).toFixed(2)}</td>` : ""}
                                                                    ${showPTax ? `<td style="border:1px solid #bdc3c7;padding:5px;text-align:center;font-size:10px;">${item.gstValue || 0}%</td>` : ""}
                                                                    <td style="border:1px solid #bdc3c7;padding:5px;text-align:center;font-size:10px;">
                                                                        ${symbol}${((Number(item.quantity) || 0) * (Number(item.rate) || 0) - (Number(item.discountValue) || 0)).toFixed(2)}
                                                                        ${item.discountValue ? `<span style="color:#e74c3c;font-size:9px;">&nbsp;(-${symbol}${(Number(item.discountValue) || 0).toFixed(2)})</span>` : ""}
                                                                    </td>
                                                                </tr>
                                                            `).join('')}
                                                            ${
                                                                (() => {
                                                                    if (tableHeaders.length === 2) {
                                                                        return `
                                                                            <tr>
                                                                                <td style="padding:5px;text-align:right;font-size:10px;">&nbsp; Subtotal:</td>
                                                                                <td style="padding:5px;text-align:left;font-size:10px;">${symbol}${subtotal ? subtotal.toFixed(2) : '0.00'}</td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td style="padding:5px;text-align:right;font-size:10px;">&nbsp; Discount:</td>
                                                                                <td style="padding:5px;text-align:left;font-size:10px;">-${symbol}${discount ? discount.toFixed(2) : '0.00'}</td>
                                                                            </tr>
                                                                            ${tax_amounts ? `
                                                                                <tr>
                                                                                    <td style="padding:5px;text-align:right;font-size:10px;border-bottom:1px solid #2c3e50;">&nbsp; Tax</td>
                                                                                    <td style="padding:5px;text-align:left;font-size:10px;border-bottom:1px solid #2c3e50;">${symbol}${tax ? tax.toFixed(2) : '0.00'}</td>
                                                                                </tr>
                                                                            ` : `
                                                                                <tr>
                                                                                    <td style="padding:5px;text-align:right;font-size:10px;border-bottom:1px solid #2c3e50;"></td>
                                                                                    <td style="padding:5px;text-align:left;font-size:10px;border-bottom:1px solid #2c3e50;"></td>
                                                                                </tr>
                                                                            `}
                                                                            <tr>
                                                                                <td style="padding:5px;text-align:right;font-size:10px;">&nbsp; Total:</td>
                                                                                <td style="padding:5px;text-align:left;font-size:10px;">${symbol}${total ? total.toFixed(2) : '0.00'}</td>
                                                                            </tr>
                                                                        `;
                                                                    }
                                                                    return `
                                                                        <tr>
                                                                            <td colspan="${tableHeaders.length - 2}" style="padding:5px;text-align:center;font-size:10px;border:0;">&nbsp;</td>
                                                                            <td style="padding:5px;text-align:end;font-size:10px;">&nbsp; Subtotal:</td>
                                                                            <td style="padding:5px;text-align:center;font-size:10px;">${symbol}${subtotal ? subtotal.toFixed(2) : '0.00'}</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td colspan="${tableHeaders.length - 2}" style="padding:5px;text-align:center;font-size:10px;border:0;">&nbsp;</td>
                                                                            <td style="padding:5px;text-align:end;font-size:10px;">&nbsp; Discount:</td>
                                                                            <td style="padding:5px;text-align:center;font-size:10px;">-${symbol}${discount ? discount.toFixed(2) : '0.00'}</td>
                                                                        </tr>
                                                                        ${tax_amounts ? `
                                                                            <tr>
                                                                                <td colspan="${tableHeaders.length - 2}" style="padding:5px;text-align:center;font-size:10px;border:0;">&nbsp;</td>
                                                                                <td style="padding:5px;text-align:end;font-size:10px;border-bottom:1px solid #2c3e50;">&nbsp; Tax:</td>
                                                                                <td style="padding:5px;text-align:center;font-size:10px;border-bottom:1px solid #2c3e50;">${symbol}${tax ? tax.toFixed(2) : '0.00'}</td>
                                                                            </tr>
                                                                        ` : `
                                                                            <tr>
                                                                                <td colspan="${tableHeaders.length - 2}" style="padding:5px;text-align:center;font-size:10px;border:0;"></td>
                                                                                <td style="padding:5px;text-align:end;font-size:10px;border-bottom:1px solid #2c3e50;"></td>
                                                                                <td style="padding:5px;text-align:center;font-size:10px;border-bottom:1px solid #2c3e50;"></td>
                                                                            </tr>
                                                                        `}
                                                                        <tr>
                                                                            <td colspan="${tableHeaders.length - 2}" style="padding:5px;text-align:center;font-size:10px;border:0;">&nbsp;</td>
                                                                            <td style="padding:5px;text-align:end;font-size:10px;">&nbsp; Total:</td>
                                                                            <td style="padding:5px;text-align:center;font-size:10px;">${symbol}${total ? total.toFixed(2) : '0.00'}</td>
                                                                        </tr>
                                                                    `;
                                                                })()
                                                            }
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                            ${invoice.depositAmount ? `
                                                <tr>
                                                    <td colspan="${tableHeaders.length}" style="padding:5px 40px;text-align:center;font-size:10px;">
                                                        Deposit Due ${formatDate(invoice.depositAmount?.dueDate)} &nbsp;&nbsp; ${symbol}${invoice.depositAmount?.amount ? Number(invoice.depositAmount.amount).toFixed(2) : '0.00'}
                                                    </td>
                                                </tr>
                                            ` : ""}
                                            <tr>
                                                <td style="padding:10px 40px;">
                                                    <table width="100%" cellpadding="0" cellspacing="0">
                                                        <tbody>
                                                            <tr>
                                                                <td width="20%" style="padding-right:20px;">
                                                                    ${includeSignatureLine ? `
                                                                        <div style="border-bottom:1px solid #2c3e50;margin-bottom:5px;height:16px;"></div>
                                                                        <div style="font-size:10px;color:#7f8c8d;">Raise Invoice</div>
                                                                        <br />
                                                                    ` : ""}
                                                                    <div style="font-size:10px;color:#34495e;">${todayFormatted}</div>
                                                                    <div style="border-bottom:1px solid #2c3e50;margin-bottom:5px;height:16px;"></div>
                                                                    <div style="font-size:10px;color:#7f8c8d;">Date</div>
                                                                </td>
                                                                <td width="20%" style="padding-left:20px;">
                                                                    ${includeSignatureLine ? `
                                                                        <div style="border-bottom:1px solid #2c3e50;margin-bottom:5px;height:16px;"></div>
                                                                        <div style="font-size:10px;color:#7f8c8d;">Client's Signature</div>
                                                                        <br />
                                                                    ` : ""}
                                                                    <div style="border-bottom:1px solid #2c3e50;margin-bottom:5px;height:16px;"></div>
                                                                    <div style="font-size:10px;color:#7f8c8d;">Payment method</div>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="padding:20px 40px 0 40px;">
                                                    <hr style="border:none;border-top:2px solid ${headerColor};margin:0;" />
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="padding:20px 40px 20px 40px;">
                                                    <div style="font-size:12px;font-weight:bold;color:#2c3e50;margin-bottom:10px;text-align:left;">Notes</div>
                                                    <div style="font-size:9px;color:#7f8c8d;line-height:1.4;text-align:left;">
                                                        ${invoice.comment || 'No additional notes.'}
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
            `;

            res.setHeader('Content-Type', 'text/html');
            return res.status(200).send(html);
        } catch (error) {
            console.error('Error generating invoice preview:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                html: ""
            });
        }
    });

    //tax rates 
    static createTaxRate = catchAsyncErrors(async (req, res, next) => {
          const { rate, percentage, client_id } = req.body;
    
          if ((!rate && rate == "") && (!percentage && percentage == "")) {
            return res.status(404).json({ status: false, message: 'rate or percentage not found' });
         }

        const userId = req.user.id;
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });
        
        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }
        
        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.' ,data:{}});
        }
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        // Start a transaction
        const transaction = await connection.sequelize.transaction();

        try {
            let taxFields = {};

            const uuid = crypto.randomUUID();
            taxFields = {
                uuid : uuid,
                rate : rate,
                percentage : percentage,
                client_id : client_id,
                client_admin_id : userId
            };

            // Create Appointment
            const taxCreated = await super.create(res, connection.TaxRates, taxFields, { transaction });

            // Commit the transaction
            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Tax rate created successfully.",
                data: taxCreated
            });
        } catch (error) {
            // Rollback the transaction in case of error
            await transaction.rollback();
            console.error('Error creating Tax rate:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    
    });

    static getAllRates = catchAsyncErrors(async (req, res, next) => {
        const userId = req.user.id ?? req.body.uuid;
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User  not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.' ,data:{}});
        }

        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        try {
            const allRates = await connection.TaxRates.findAll({
            });

            return res.status(200).json({
                status: true,
                message: "Tax rates retrieved successfully.",
                data: allRates
            });
        } catch (error) {
            console.error('Error fetching clients:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });

    static deleteTaxRate = catchAsyncErrors(async (req, res, next) => {
        const userId = req.user.id;
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User  not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.' ,data:{}});
        }

        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        try {
            const { id } = req.body;
            const deletedRate = await connection.TaxRates.destroy({
                where: { id }
            });

            if (!deletedRate) {
                return res.status(404).json({
                    status: false,
                    message: "Tax rate not found.",
                    data: {}
                });
            }

            return res.status(200).json({
                status: true,
                message: "Tax rate deleted successfully.",
                data: {}
            });
        } catch (error) {
            console.error('Error deleting tax rate:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });

    static getConnectionForClient = async (userId, mysqlConfig) => {
        try {
            // Fetch user and their database name
            const user = await clientModel.findOne({
                attributes: ['id', 'database_name'],
                where: { id: userId }
            });
    
            if (!user) {
                return { error: 'User not found', connection: null };
            }
    
            const db_name = user.database_name;
            if (!db_name) {
                return { error: 'Please create your company first before accessing this resource.', connection: null };
            }
    
            // Establish connection
            const connection = await connectSpecificToDatabase(
                db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
            );
    
            return { error: null, connection };
        } catch (err) {
            console.error("Error in getConnectionForClient:", err);
            return { error: 'Failed to establish a connection.', connection: null };
        }
    };

}

module.exports = clientInvoiceController;