const BaseController = require("../BaseController");
const catchAsyncErrors = require("../../middleware/catchAsyncErrors");
const bcrypt = require("bcryptjs");
const db = require("../../models");
const clientModel = db.Clients;
const { Op } = require("sequelize");
const crypto = require("crypto");
const { createDatabase, getConnectedSpecificDB } = require("../../utils/utilities");
const JWTAuth = require("../../utils/jwtToken");
const mysqlConfig = require("../../config/index").Mysql;
const fileUploaderSingle = require("../../utils/fileUpload").fileUploaderSingle;

const { connectSpecificToDatabase } = require("../../config/specificConnect");

class ProjectController extends BaseController {
    constructor() {
        super();
    }

    // Create Project
    static createProject = catchAsyncErrors(async (req, res, next) => {
        const {
            client_id,
            project_name,
            project_location,
            latitude,
            longitude,
            project_desc,
            start_date,
            end_date,
            status,
        } = req.body;

        const userId = req.user.id;
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        // const { sequelize2, ClientRaiseModel, ClientRaiseContactModel, ClientRaiseOtherModel } = await connectSpecificToDatabase(db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306');
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        // Start a transaction
        const transaction = await connection.sequelize.transaction();

        try {
            let projectFields = {};

            const uuid = crypto.randomUUID();
            projectFields = {
                uuid,
                client_id,
                client_admin_id: userId,
                project_name,
                project_location,
                latitude,
                longitude,
                project_desc,
                start_date,
                end_date,
                status
            };

            // Create Project
            const addProject = await super.create(res, connection.CompanyProject, projectFields, { transaction });

            // const clientDetails = await connection.Client.findOne({
            //     where: { id: addProject.dataValues.client_id },
            // });

            // if (clientDetails) {
            //     await connection.ProjectContacts.create({
            //         uuid,
            //         project_id: addProject.dataValues.id,
            //         client_id,
            //         client_admin_id: userId,
            //         contact_name: clientDetails.name,
            //         contact_email: clientDetails.email,
            //         contact_phone: clientDetails.phone,
            //         address: clientDetails.address,
            //         is_primary: true
            //     }, { transaction });
            // }

            // Commit the transaction
            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Projects created successfully.",
                data: addProject
            });
        } catch (error) {
            // Rollback the transaction in case of error
            await transaction.rollback();
            console.error('Error creating project:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });

    // Get All Projects
    static getAllProjects = catchAsyncErrors(async (req, res, next) => {
        const userId = req.user.id;
        const { status } = req.body;

        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        try {
            let filter = {};
            if (status === 1) {
                filter.status = 1; // Filter active projects
            } else if (status === 3) {
                filter.status = 3; // Filter completed projects
            }

            const projects = await connection.CompanyProject.findAll({
                where: filter,
            });

            const enrichedProjects = await Promise.all(
                projects.map(async (project) => {
                    const client = await connection.Client.findOne({
                        where: { id: project.client_id },
                    });

                    return {
                        ...project.dataValues,
                        client: client ? client.dataValues : null,
                    };
                })
            );

            return res.status(200).json({
                status: true,
                message: "Projects retrieved successfully.",
                data: enrichedProjects,
            });
        } catch (error) {
            console.error('Error fetching projects:', error);
            return res.status(500).json({
                status: false,
                message: "Oops... something went terribly wrong!",
                data: {},
            });
        }
    });

    //client specific projects
    static getClientProjects = catchAsyncErrors(async (req, res, next) => {
        const { client_id } = req.body;
        const userId = req.user.id;
        if (!client_id) {
            return res.status(404).json({ status: false, message: 'client_id not found' });
        }
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });
        if (!user) {
            return res.status(404).json({ status: false, message: 'User  not found' });
        }
        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );
        try {
            const projects = await connection.CompanyProject.findAll({
                where: { client_id: client_id },
            });
            return res.status(200).json({
                status: true,
                message: "Projects retrieved successfully.",
                data: projects,
            });
        } catch (error) {
            console.error('Error fetching client projects:', error);
            return res.status(500).json({
                status: false,
                message: "Oops... something went terribly wrong!",
                data: {},
            });
        }
    });

    // Get Project Details
    static getProjectDetails = catchAsyncErrors(async (req, res, next) => {

        const { client_id, projectId } = req.body;
        if (!client_id && !projectId) {
            return res.status(404).json({ status: false, message: 'client_id or projectId not found' });
        }

        const userId = req.user.id;
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User  not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        // const { sequelize2, ClientRaiseModel, ClientRaiseContactModel, ClientRaiseOtherModel } = await connectSpecificToDatabase(db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306');

        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        try {
            // Fetch project details
            const project = await connection.CompanyProject.findOne({
                where: { id: projectId },
            });

            if (!project) {
                return res.status(404).json({ status: false, message: "Project not found." });
            }

            // Fetch client details
            const client = await connection.Client.findOne({
                where: { id: project.client_id },
            });

            const enrichedProject = {
                ...project.dataValues,
                client: client ? client.dataValues : null,
            };

            return res.status(200).json({
                status: true,
                message: "Project details retrieved successfully.",
                data: {
                    enrichedProject
                },
            });
        } catch (error) {
            console.error("Error fetching project details:", error);
            return res.status(500).json({
                status: false,
                message: "An error occurred while retrieving project details.",
                data: {},
            });
        }
    });

    // Update Project
    static updateProject = catchAsyncErrors(async (req, res, next) => {
        const updatedData = req.body;

        if (!updatedData.client_id && !updatedData.projectId) {
            return res.status(404).json({ status: false, message: 'client_id or projectId not found' });
        }
        const userId = req.user.id;
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        // const { sequelize2, ClientRaiseModel, ClientRaiseContactModel, ClientRaiseOtherModel } = await connectSpecificToDatabase(db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306');
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        // Start a transaction
        const transaction = await connection.sequelize.transaction();

        const updateFields = {};

        // Only include fields in the `updateFields` object if they have a value
        if (updatedData.client_id) updateFields.client_id = updatedData.client_id;
        if (updatedData.project_name) updateFields.project_name = updatedData.project_name;
        if (updatedData.project_location) updateFields.project_location = updatedData.project_location;
        if (updatedData.latitude) updateFields.latitude = updatedData.latitude;
        if (updatedData.longitude) updateFields.longitude = updatedData.longitude;
        if (updatedData.project_desc) updateFields.project_desc = updatedData.project_desc;
        if (updatedData.start_date) updateFields.start_date = updatedData.start_date;
        if (updatedData.end_date) updateFields.end_date = updatedData.end_date;
        if (updatedData.status) updateFields.status = updatedData.status;
        if (updatedData.notes) updateFields.notes = updatedData.notes;
        if (updatedData.taskName) updateFields.taskName = updatedData.taskName;
        if (updatedData.taskDescription) updateFields.taskDescription = updatedData.taskDescription;
        if (updatedData.taskStartDate) updateFields.taskStartDate = updatedData.taskStartDate;
        if (updatedData.taskEndDate) updateFields.taskEndDate = updatedData.taskEndDate;
        if (updatedData.taskPriority) updateFields.taskPriority = updatedData.taskPriority;


        try {
            const [updatedProjectCount, updatedProject] = await connection.CompanyProject.update(updateFields, {
                where: { id: updatedData.projectId },
                returning: true,
                transaction
            });

            if (updatedProjectCount === 0) {
                return res.status(404).json({ status: false, message: "Project not found or no changes made." });
            }

            // Commit the transaction
            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Project updated successfully.",
                data: updatedProject[0],
            });
        } catch (error) {
            await transaction.rollback();
            console.error("Error updating project:", error);
            return res.status(500).json({
                status: false,
                message: "An error occurred while updating the project.",
                data: {},
            });
        }
    });

    // Delete Project
    static deleteProject = catchAsyncErrors(async (req, res, next) => {
        const { client_id, projectId } = req.body;

        if (!client_id && !projectId) {
            return res.status(404).json({ status: false, message: 'client_id or projectId not found' });
        }
        const userId = req.user.id;

        // Find the user to get the database name
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User  not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        // const { sequelize2, ClientRaiseModel, ClientRaiseContactModel, ClientRaiseOtherModel } = await connectSpecificToDatabase(db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306');
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        // Start a transaction
        const transaction = await connection.sequelize.transaction();

        try {
            const deletedProject = await connection.CompanyProject.destroy({
                where: { id: projectId },
                transaction
            });
            if (!deletedProject) {
                return res.status(404).json({ status: false, message: "Project not found." });
            }

            // Commit the transaction
            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Project deleted successfully.",
            });
        } catch (error) {
            // Rollback the transaction in case of error
            await transaction.rollback();
            console.error("Error deleting project:", error);
            return res.status(500).json({
                status: false,
                message: "An error occurred while deleting the project.",
                data: {},
            });
        }
    });

    // Project Contacts
    static saveContacts = catchAsyncErrors(async (req, res, next) => {
        const { contact_name, contact_email, contact_phone, address, client_id, projectId } = req.body;
        const userId = req.user.id;

        if (!client_id && !projectId) {
            return res.status(404).json({ status: false, message: 'client_id or projectId not found' });
        }

        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        const transaction = await connection.sequelize.transaction();

        try {
            const uuid = crypto.randomUUID();
            const newContact = await connection.ProjectContacts.create({
                uuid: uuid,
                project_id: projectId,
                client_id: client_id,
                client_admin_id: userId,
                contact_name,
                contact_email,
                contact_phone,
                address,
                is_primary: false
            }, { transaction });

            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Contact added successfully.",
                data: newContact,
            });
        } catch (error) {
            await transaction.rollback();
            console.error("Error saving contact:", error);
            return res.status(500).json({
                status: false,
                message: "An error occurred while saving the contact.",
            });
        }
    });

    static updateContact = catchAsyncErrors(async (req, res, next) => {
        const { id, contact_name, contact_email, contact_phone, address } = req.body;
        const userId = req.user.id;

        if (!id) {
            return res.status(400).json({ status: false, message: 'Contact id is required' });
        }

        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        const transaction = await connection.sequelize.transaction();

        try {
            const updateFields = {};
            if (contact_name !== undefined) updateFields.contact_name = contact_name;
            if (contact_email !== undefined) updateFields.contact_email = contact_email;
            if (contact_phone !== undefined) updateFields.contact_phone = contact_phone;
            if (address !== undefined) updateFields.address = address;

            const [updatedCount, updatedRows] = await connection.ProjectContacts.update(
                updateFields,
                { where: { id }, returning: true, transaction }
            );

            if (updatedCount === 0) {
                await transaction.rollback();
                return res.status(404).json({ status: false, message: "Contact not found or no changes made." });
            }

            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Contact updated successfully.",
                data: updatedRows[0],
            });
        } catch (error) {
            await transaction.rollback();
            console.error("Error updating contact:", error);
            return res.status(500).json({
                status: false,
                message: "An error occurred while updating the contact.",
            });
        }
    });

    static deleteContact = catchAsyncErrors(async (req, res, next) => {
        const { id } = req.body;
        const userId = req.user.id;

        if (!id) {
            return res.status(400).json({ status: false, message: 'Contact id is required' });
        }

        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        const transaction = await connection.sequelize.transaction();

        try {
            const deletedCount = await connection.ProjectContacts.destroy({
                where: { id },
                transaction
            });

            if (!deletedCount) {
                await transaction.rollback();
                return res.status(404).json({ status: false, message: "Contact not found." });
            }

            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Contact deleted successfully."
            });
        } catch (error) {
            await transaction.rollback();
            console.error("Error deleting contact:", error);
            return res.status(500).json({
                status: false,
                message: "An error occurred while deleting the contact.",
            });
        }
    });

    static getContacts = catchAsyncErrors(async (req, res, next) => {
        const { client_id } = req.body;
        const userId = req.user.id;


        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        try {
            let contacts = [];
                if(client_id){
                    contacts = await connection.ProjectContacts.findAll({
                        where: {
                            client_id: client_id,
                        },
                });

            }

            return res.status(200).json({
                status: true,
                message: "Contacts retrieved successfully.",
                data: contacts,
            });
        } catch (error) {
            console.error("Error fetching contacts:", error);
            return res.status(500).json({
                status: false,
                message: "An error occurred while fetching contacts.",
            });
        }
    });

    static getContactsForAppointment = catchAsyncErrors(async (req, res, next) => {
        const userId = req.user.id;

        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        try {
            let contacts = await connection.ProjectContacts.findAll();

            // Group contacts into primary and secondary
            let primary = [];
            let secondary = [];
            contacts.forEach(contact => {
                if (contact.is_primary) {
                    primary.push(contact);
                } else {
                    secondary.push(contact);
                }
            });

            // Remove duplicates by email and phone within each group
            function validContactArray(arr) {
                const seen = [];
                return arr.filter(contact => {
                    if(contact?.contact_name && contact.contact_phone){
                        return seen.push(contact)
                    }else{
                        return false;
                    }
                });
            }

            primary = validContactArray(primary);
            secondary = validContactArray(secondary);

            return res.status(200).json({
                status: true,
                message: "Contacts retrieved successfully.",
                data: {
                    primary,
                    secondary
                },
            });
        } catch (error) {
            console.error("Error fetching contacts:", error);
            return res.status(500).json({
                status: false,
                message: "An error occurred while fetching contacts.",
            });
        }
    });

    //Project Tasks
    static saveTask = catchAsyncErrors(async (req, res, next) => {
        const { projectId, client_id, taskName, taskDescription, taskStartDate, taskEndDate, taskPriority } = req.body;
        const userId = req.user.id;

        if (!client_id && !projectId) {
            return res.status(404).json({ status: false, message: 'client_id or projectId not found' });
        }

        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        const transaction = await connection.sequelize.transaction();

        try {
            const uuid = crypto.randomUUID();
            const newTask = await connection.ProjectTasks.create({
                uuid: uuid,
                project_id: projectId,
                client_id: client_id,
                taskName,
                taskDescription,
                taskStartDate,
                taskEndDate,
                taskPriority
            }, { transaction });

            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Task added successfully.",
                data: newTask,
            });
        } catch (error) {
            await transaction.rollback();
            console.error("Error saving task:", error);
            return res.status(500).json({
                status: false,
                message: "An error occurred while saving the task.",
            });
        }
    });

    static updateTask = catchAsyncErrors(async (req, res, next) => {
        const { id, taskName, taskDescription, taskStartDate, taskEndDate, taskPriority } = req.body;
        const userId = req.user.id;

        if (!id) {
            return res.status(400).json({ status: false, message: 'Task id is required' });
        }

        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        const transaction = await connection.sequelize.transaction();

        try {
            const updateFields = {};
            if (taskName !== undefined) updateFields.taskName = taskName;
            if (taskDescription !== undefined) updateFields.taskDescription = taskDescription;
            if (taskStartDate !== undefined) updateFields.taskStartDate = taskStartDate;
            if (taskEndDate !== undefined) updateFields.taskEndDate = taskEndDate;
            if (taskPriority !== undefined) updateFields.taskPriority = taskPriority;

            const [updatedCount, updatedRows] = await connection.ProjectTasks.update(
                updateFields,
                { where: { id }, returning: true, transaction }
            );

            if (updatedCount === 0) {
                await transaction.rollback();
                return res.status(404).json({ status: false, message: "Task not found or no changes made." });
            }

            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Task updated successfully.",
                data: updatedRows[0],
            });
        } catch (error) {
            await transaction.rollback();
            console.error("Error updating task:", error);
            return res.status(500).json({
                status: false,
                message: "An error occurred while updating the task.",
            });
        }
    });

    static deleteTask = catchAsyncErrors(async (req, res, next) => {
        const { id } = req.body;
        const userId = req.user.id;

        if (!id) {
            return res.status(400).json({ status: false, message: 'Task id is required' });
        }

        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        const transaction = await connection.sequelize.transaction();

        try {
            // Delete all logs (ProjectTimes) related to this task
            await connection.ProjectTimes.destroy({
                where: { task_id: id },
                transaction
            });

            // Delete the task itself
            const deletedCount = await connection.ProjectTasks.destroy({
                where: { id },
                transaction
            });

            if (!deletedCount) {
                await transaction.rollback();
                return res.status(404).json({ status: false, message: "Task not found." });
            }

            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Task and related logs deleted successfully."
            });
        } catch (error) {
            await transaction.rollback();
            console.error("Error deleting task:", error);
            return res.status(500).json({
                status: false,
                message: "An error occurred while deleting the task.",
            });
        }
    });

    static getTask = catchAsyncErrors(async (req, res, next) => {
        const { projectId } = req.body;
        const userId = req.user.id;

        if (!projectId) {
            return res.status(404).json({ status: false, message: 'projectId not found' });
        }

        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        try {
            // Get all tasks for the project
            const tasks = await connection.ProjectTasks.findAll({
                where: {
                    project_id: projectId,
                },
                raw: true
            });

            // Get all ProjectTimes for this project
            const projectTimes = await connection.ProjectTimes.findAll({
                where: {
                    project_id: projectId
                },
                raw: true
            });


            function msToHHMMSS(ms) {
                let totalSeconds = Math.floor(ms / 1000);
                let hours = Math.floor(totalSeconds / 3600);
                let minutes = Math.floor((totalSeconds % 3600) / 60);
                let seconds = totalSeconds % 60;
                return [
                    hours.toString().padStart(2, '0'),
                    minutes.toString().padStart(2, '0'),
                    seconds.toString().padStart(2, '0')
                ].join(':');
            }

            // Add timeDifference to each projectTime
            const projectTimesWithDiff = projectTimes.map((record) => {
                let diff = null;
                if (record.start_time) {
                    let startDate = record.createdAt;
                    let endDate = record.end_time ? record.updatedAt : new Date();

                    if (record.start_time.length > 8) {
                        startDate = new Date(record.start_time);
                    }
                    if (record.end_time && record.end_time.length > 8) {
                        endDate = new Date(record.end_time);
                    }

                    diff = msToHHMMSS(Math.abs(endDate - startDate));
                }
                return {
                    ...record,
                    timeDifference: diff
                };
            });

            // Attach matched ProjectTimes (with timeDifference) to each task
            const tasksWithTimes = tasks.map(task => {
                const matchedTimes = projectTimesWithDiff.filter(time => time.task_id === task.id);
                return {
                    ...task,
                    projectTimes: matchedTimes
                };
            });

            return res.status(200).json({
                status: true,
                message: "Tasks retrieved successfully.",
                data: tasksWithTimes,
            });
        } catch (error) {
            console.error("Error fetching tasks:", error);
            return res.status(500).json({
                status: false,
                message: "An error occurred while fetching tasks.",
            });
        }
    });

    static getGroupingTask = catchAsyncErrors(async (req, res, next) => {
        const { projectId } = req.body;
        const userId = req.user.id;

        if (!projectId) {
            return res.status(404).json({ status: false, message: 'projectId not found' });
        }

        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        try {
            // Get all tasks for the project
            const tasks = await connection.ProjectTasks.findAll({
                where: {
                    project_id: projectId,
                },
                raw: true
            });

            // Get all ProjectTimes for this project
            const projectTimes = await connection.ProjectTimes.findAll({
                where: {
                    project_id: projectId
                },
                raw: true
            });

            function msToHHMMSS(ms) {
                let totalSeconds = Math.floor(ms / 1000);
                let hours = Math.floor(totalSeconds / 3600);
                let minutes = Math.floor((totalSeconds % 3600) / 60);
                let seconds = totalSeconds % 60;
                return [
                    hours.toString().padStart(2, '0'),
                    minutes.toString().padStart(2, '0'),
                    seconds.toString().padStart(2, '0')
                ].join(':');
            }

            // Add timeDifference to each projectTime
            const projectTimesWithDiff = projectTimes.map((record) => {
                let diff = null;
                if (record.start_time) {
                    let startDate = record.createdAt;
                    let endDate = record.end_time ? record.updatedAt : new Date();

                    if (record.start_time.length > 8) {
                        startDate = new Date(record.start_time);
                    }
                    if (record.end_time && record.end_time.length > 8) {
                        endDate = new Date(record.end_time);
                    }

                    diff = msToHHMMSS(Math.abs(endDate - startDate));
                }
                return {
                    ...record,
                    timeDifference: diff
                };
            });

            // Attach matched ProjectTimes (with timeDifference) to each task
            const tasksWithTimes = tasks.map(task => {
                const matchedTimes = projectTimesWithDiff.filter(time => time.task_id === task.id);
                return {
                    ...task,
                    projectTimes: matchedTimes
                };
            });

            // Group tasks by priority
            const high = [];
            const medium = [];
            const low = [];
            tasksWithTimes.forEach(task => {
                if (task.taskPriority === 'high') high.push(task);
                else if (task.taskPriority === 'medium') medium.push(task);
                else low.push(task);
            });

            // Helper to move completed tasks to end
            function moveCompletedToEnd(arr) {
                const notCompleted = [];
                const completed = [];
                arr.forEach(task => {
                    if (task.status === 3 || task.status === '3' || task.status === 'completed') completed.push(task);
                    else notCompleted.push(task);
                });
                return [...notCompleted, ...completed];
            }

            // Helper to move tasks with startDate <= today to end (priority-wise)
            function moveOldStartDateToEnd(arr) {
                const today = new Date();
                const future = [];
                const old = [];
                arr.forEach(task => {
                    if (task.taskStartDate) {
                        const startDate = new Date(task.taskStartDate);
                        if (startDate <= today) old.push(task);
                        else future.push(task);
                    } else {
                        future.push(task);
                    }
                });
                return [...future, ...old];
            }

            // Process each group
            let highArr = moveCompletedToEnd(high);
            highArr = moveOldStartDateToEnd(highArr);

            let mediumArr = moveCompletedToEnd(medium);
            mediumArr = moveOldStartDateToEnd(mediumArr);

            let lowArr = moveCompletedToEnd(low);
            lowArr = moveOldStartDateToEnd(lowArr);

            return res.status(200).json({
                status: true,
                message: "Tasks grouped and sorted successfully.",
                data: {
                    high: highArr,
                    medium: mediumArr,
                    low: lowArr
                },
            });
        } catch (error) {
            console.error("Error fetching tasks:", error);
            return res.status(500).json({
                status: false,
                message: "An error occurred while fetching tasks.",
            });
        }
    });


    // Save Files
    // Save Project File (supports PDF and photo uploads)
    static saveProjectFile = catchAsyncErrors(async (req, res) => {
        const { projectId, client_id } = req.body;
        const userId = req.user.id;

        if (!projectId || !client_id) {
            return res.status(400).json({ status: false, message: "Missing required fields: projectId, client_id." });
        }

        if (!req.files || !req.files.document) {
            return res.status(400).json({ status: false, message: "No file uploaded." });
        }

        const uploadedFile = await fileUploaderSingle("./src/public/uploads/", req.files.document);
        const fileContent = uploadedFile.newfileName;
        const fileType = req.files.document.mimetype;

        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: "User not found." });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }

        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        const transaction = await connection.sequelize.transaction();

        try {
            const newFile = await connection.ProjectFiles.create({
                uuid: crypto.randomUUID(),
                project_id: projectId,
                client_id,
                client_admin_id: userId,
                fileContent: fileContent || null,
                fileType: fileType || null
            }, { transaction });

            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "File uploaded successfully.",
                data: newFile
            });
        } catch (error) {
            await transaction.rollback();
            console.error("Error saving file:", error);
            return res.status(500).json({
                status: false,
                message: "An error occurred while saving the file."
            });
        }
    });

    static getProjectFile = catchAsyncErrors(async (req, res) => {
        const { projectId } = req.body;
        const userId = req.user.id;

        if (!projectId) {
            return res.status(400).json({ status: false, message: "Project ID is required." });
        }

        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: "User not found." });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }

        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        try {
            const files = await connection.ProjectFiles.findAll({ where: { project_id: projectId } });

            if (!files || files.length === 0) {
                return res.status(200).json({ 
                    status: false, 
                    message: "No files found.",
                    data: {}
                });
            }

            const fileData = files.map(file => {
                const formatDate = (date) => {
                    if (!date) return null;
                    const d = new Date(date);
                    return d.toLocaleDateString('en-US', {
                        year: 'numeric',
                        month: 'short',
                        day: '2-digit'
                    });
                };
                return {
                    id: file.id,
                    uuid: file.uuid,
                    fileType: file.fileType,
                    fileName: file.fileContent,
                    url: `${req.protocol}://${req.get('host')}/uploads/${file.fileContent}`,
                    createdAt: formatDate(file.createdAt),
                    updatedAt: formatDate(file.updatedAt)
                };
            });

            return res.status(200).json({
                status: true,
                message: "Files retrieved successfully.",
                data: fileData
            });
        } catch (error) {
            console.error("Error retrieving files:", error);
            return res.status(500).json({
                status: false,
                message: "An error occurred while retrieving the files."
            });
        }
    });

    static removeProjectFile = catchAsyncErrors(async (req, res) => {
        const { fileId } = req.body;
        const userId = req.user.id;

        if (!fileId) {
            return res.status(400).json({ status: false, message: "File ID is required." });
        }

        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: "User not found." });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }

        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        try {
            const deletedFileCount = await connection.ProjectFiles.destroy({ 
                where: { 
                    id: fileId
                } });

              if (!deletedFileCount) {
                return res.status(404).json({ status: false, message: "Files not deleted." });
            }

            return res.status(200).json({
                status: true,
                message: "File deleted successfully."
            });
     
        } catch (error) {
            console.error("Error deleting the files:", error);
            return res.status(500).json({
                status: false,
                message: "An error occurred while deleting the files."
            });
        }
    });
    
    //Time Tracking
    static saveProjectTime = catchAsyncErrors(async (req, res) => {
        const { id, project_id, client_id, task_id, start_time, end_time, notes } = req.body;
        const userId = req.user.id;

        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        const transaction = await connection.sequelize.transaction();

        try {
            let result;
            if (id) {
                const updateData = {};
                if (project_id !== undefined) updateData.project_id = project_id;
                if (client_id !== undefined) updateData.client_id = client_id;
                if (task_id !== undefined) updateData.task_id = task_id;
                if (notes !== undefined) updateData.notes = notes;
                if (start_time !== undefined) updateData.start_time = start_time;
                if (end_time !== undefined) updateData.end_time = end_time;

                const [updatedCount, updatedRows] = await connection.ProjectTimes.update(
                    updateData,
                    { where: { id }, returning: true, transaction }
                );

                if (updatedCount === 0) {
                    await transaction.rollback();
                    return res.status(404).json({ status: false, message: "Time record not found." });
                }
                result = updatedRows[0];
            } else {
                const createData = {
                    uuid: crypto.randomUUID(),
                    project_id,
                    client_id,
                    task_id,
                    notes,
                    start_time,
                    end_time
                };
                result = await connection.ProjectTimes.create(createData, { transaction });
            }

            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Time saved successfully.",
                data: result,
            });
        } catch (error) {
            await transaction.rollback();
            console.error("Error saving time:", error);
            return res.status(500).json({
                status: false,
                message: "An error occurred while saving the time.",
            });
        }
    })
    static getALLProjectTime = catchAsyncErrors(async (req, res) => {
        const { client_id } = req.body;
        const userId = req.user.id;

        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        try {
            const whereClause = client_id ? { client_id: client_id } : {};
            const time = await connection.ProjectTimes.findAll({
                where: whereClause,
                order: [['id', 'DESC']]
            });

            if (!time || time.length === 0) {
                return res.status(200).json({
                    status: false,
                    message: "No time records found.",
                    data: []
                });
            }

            function msToHHMMSS(ms) {
                let totalSeconds = Math.floor(ms / 1000);
                let hours = Math.floor(totalSeconds / 3600);
                let minutes = Math.floor((totalSeconds % 3600) / 60);
                let seconds = totalSeconds % 60;
                return [
                    hours.toString().padStart(2, '0'),
                    minutes.toString().padStart(2, '0'),
                    seconds.toString().padStart(2, '0')
                ].join(':');
            }

            // Fetch all related tasks for mapping task_name and task_description
            const taskIds = time.map(t => t.task_id).filter(id => !!id);
            let tasksMap = {};
            if (taskIds.length > 0) {
                const tasks = await connection.ProjectTasks.findAll({
                    where: { id: { [Op.in]: taskIds } },
                    attributes: ['id', 'taskName', 'taskDescription'],
                    raw: true
                });
                tasksMap = tasks.reduce((acc, curr) => {
                    acc[curr.id] = {
                        taskName: curr.taskName,
                        taskDescription: curr.taskDescription
                    };
                    return acc;
                }, {});
            }

            // Fetch all related clients for mapping client_name
            const clientIds = time.map(t => t.client_id).filter(id => !!id);
            let clientsMap = {};
            if (clientIds.length > 0) {
                const clients = await connection.Client.findAll({
                    where: { id: { [Op.in]: clientIds } },
                    attributes: ['id', 'name'],
                    raw: true
                });
                clientsMap = clients.reduce((acc, curr) => {
                    acc[curr.id] = curr.name;
                    return acc;
                }, {});
            }

            // Fetch all related projects for mapping project_name
            const projectIds = time.map(t => t.project_id).filter(id => !!id);
            let projectsMap = {};
            if (projectIds.length > 0) {
                const projects = await connection.CompanyProject.findAll({
                    where: { id: { [Op.in]: projectIds } },
                    attributes: ['id', 'project_name'],
                    raw: true
                });
                projectsMap = projects.reduce((acc, curr) => {
                    acc[curr.id] = curr.project_name;
                    return acc;
                }, {});
            }

            const timeWithDiff = time.map((record) => {
                let diff = null;
                let startDate, endDate;

                // Helper to parse "hh:mm" format into a Date using a reference date
                function parseHHMMToDate(hhmm, referenceDate) {
                    if (!hhmm || hhmm.length > 5) return null;
                    const [hours, minutes] = hhmm.split(':').map(Number);
                    const date = new Date(referenceDate);
                    date.setHours(hours);
                    date.setMinutes(minutes);
                    date.setSeconds(0);
                    date.setMilliseconds(0);
                    return date;
                }

                if (record.start_time) {
                    if (record.start_time.length > 8) {
                        startDate = new Date(record.start_time);
                    } else if (record.start_time.length === 5) {
                        startDate = parseHHMMToDate(record.start_time, record.createdAt);
                    } else {
                        startDate = record.createdAt;
                    }
                }

                if (record.end_time) {
                    if (record.end_time.length > 8) {
                        endDate = new Date(record.end_time);
                    } else if (record.end_time.length === 5) {
                        endDate = parseHHMMToDate(record.end_time, record.updatedAt);
                    } else {
                        endDate = record.updatedAt;
                    }
                } else {
                    endDate = new Date();
                }

                if (startDate && endDate) {
                    diff = msToHHMMSS(Math.abs(endDate - startDate));
                }

                return {
                    ...record.dataValues,
                    timeDifference: diff,
                    task_name: record.task_id ? (tasksMap[record.task_id]?.taskName || null) : null,
                    task_description: record.task_id ? (tasksMap[record.task_id]?.taskDescription || null) : null,
                    client_name: record.client_id ? (clientsMap[record.client_id] || null) : null,
                    project_name: record.project_id ? (projectsMap[record.project_id] || null) : null
                };
            });

            return res.status(200).json({
                status: true,
                message: "Time retrieved successfully.",
                data: timeWithDiff,
            });
        } catch (error) {
            console.error("Error fetching time:", error);
            return res.status(500).json({
                status: false,
                message: "An error occurred while fetching time.",
            });
        }
    })

    // Delete a single time record
    static deleteProjectTime = catchAsyncErrors(async (req, res) => {
        const { id } = req.body;
        const userId = req.user.id;

        if (!id) {
            return res.status(400).json({ status: false, message: "Time record ID is required." });
        }

        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        const transaction = await connection.sequelize.transaction();

        try {
            const deletedCount = await connection.ProjectTimes.destroy({
                where: { id },
                transaction
            });

            if (!deletedCount) {
                await transaction.rollback();
                return res.status(404).json({ status: false, message: "Time record not found." });
            }

            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Time record deleted successfully."
            });
        } catch (error) {
            await transaction.rollback();
            console.error("Error deleting time record:", error);
            return res.status(500).json({
                status: false,
                message: "An error occurred while deleting the time record.",
            });
        }
    })

    // Get details of a single time record
    static getProjectTimeDetails = catchAsyncErrors(async (req, res) => {
        const { id } = req.body;
        const userId = req.user.id;

        if (!id) {
            return res.status(400).json({ status: false, message: "Time record ID is required." });
        }

        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        try {
            const record = await connection.ProjectTimes.findOne({
                where: { id }
            });

            if (!record) {
                return res.status(404).json({ status: false, message: "Time record not found." });
            }

            function msToHHMMSS(ms) {
                let totalSeconds = Math.floor(ms / 1000);
                let hours = Math.floor(totalSeconds / 3600);
                let minutes = Math.floor((totalSeconds % 3600) / 60);
                let seconds = totalSeconds % 60;
                return [
                    hours.toString().padStart(2, '0'),
                    minutes.toString().padStart(2, '0'),
                    seconds.toString().padStart(2, '0')
                ].join(':');
            }

            let diff = null;
            if (record.start_time) {
                let startDate = record.createdAt;
                let endDate = record.end_time ? record.updatedAt : new Date();

                if (record.start_time.length > 8) {
                    startDate = new Date(record.start_time);
                }
                if (record.end_time && record.end_time.length > 8) {
                    endDate = new Date(record.end_time);
                }

                diff = msToHHMMSS(Math.abs(endDate - startDate));
            }

            return res.status(200).json({
                status: true,
                message: "Time record details retrieved successfully.",
                data: {
                    ...record.dataValues,
                    timeDifference: diff
                }
            });
        } catch (error) {
            console.error("Error fetching time record details:", error);
            return res.status(500).json({
                status: false,
                message: "An error occurred while fetching time record details.",
            });
        }
    })
    
}

module.exports = ProjectController;