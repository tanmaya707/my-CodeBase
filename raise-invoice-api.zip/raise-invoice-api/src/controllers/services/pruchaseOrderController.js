const BaseController = require("../BaseController");
const catchAsyncErrors = require("../../middleware/catchAsyncErrors");
const db = require("../../models");
const clientModel = db.Clients;
const { Op } = require("sequelize");
const crypto = require("crypto");
const mysqlConfig = require("../../config/index").Mysql;
const fileUploaderSingle = require("../../utils/fileUpload").fileUploaderSingle;


const { connectSpecificToDatabase } = require("../../config/specificConnect");
const taxModel = require("../../models/client/taxRatesModel");

class purchaseOrderController extends BaseController {
    constructor() {
        super();
    }

    // Purchase Order Operations
    static createPurchaseOrder = catchAsyncErrors(async (req, res) => {
        const { autosaveEnabled, poNumber, clients, items, subTotal, total, paymentStatus, sentStatus, logo, attachments, comment, customInvoice, customInvoiceOption } = req.body;
        const userId = req.user.id;

        const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);
        if (error) {
            return res.status(404).json({ status: false, message: error });
        }

        const transaction = await connection.sequelize.transaction();
        try {
            const uuid = crypto.randomUUID();

            let client = {};
            if (clients?.id) {
                client = await connection.Client.findOne({ where: { id: clients.id } });
                if (client && client.toJSON) {
                    client = client.toJSON();
                }
            } else {
                client = await connection.Client.create({
                    uuid: crypto.randomUUID(),
                    name: clients.name,
                    email: clients.email,
                    phone: clients.phone
                }, { transaction });
                if (client) {
                    await connection.ProjectContacts.create({
                        uuid: crypto.randomUUID(),
                        client_id : client.id,
                        client_admin_id: userId,
                        contact_name: clients.name,
                        contact_email: clients.email,
                        contact_phone: clients.phone,
                        is_primary: true
                    });
                }
                client = client.toJSON ? client.toJSON() : clients;
            }

            let filteredAttachments = [];
            if (attachments && typeof attachments === 'object' && attachments['']) {
                if (Array.isArray(attachments[''])) {
                    filteredAttachments = attachments[''].filter(att => typeof att !== 'undefined' && att !== null && att !== '');
                } else {
                    filteredAttachments = [attachments['']].filter(att => typeof att !== 'undefined' && att !== null && att !== '');
                }
            } else if (typeof attachments === 'string') {
                filteredAttachments = attachments.split(',').map(att => att.trim()).filter(att => att !== '');
            } else if (Array.isArray(attachments)) {
                filteredAttachments = attachments.filter(att => typeof att !== 'undefined' && att !== null && att !== '');
            } else if (attachments && typeof attachments === 'object') {
                filteredAttachments = Object.values(attachments).filter(att => typeof att !== 'undefined' && att !== null && att !== '');
            }

            let purchaseOrderCreated = null;
            let itemDetails = [];
            if (autosaveEnabled && (autosaveEnabled === true || autosaveEnabled === "true")) {
                itemDetails = await Promise.all(
                    items.map(async (d) => {
                        let item;
                        // if (d?.id) {
                        //     await connection.Items.update({
                        //         item_name: d.name,
                        //         item_Description: d.description,
                        //         rate: d.rate,
                        //         qty: d.quantity,
                        //         status: d.status ?? 1
                        //     }, { where: { id: d.id }, transaction });

                        //     item = await connection.Items.findOne({ where: { id: d.id }, transaction });
                        // } else {
                        if(!d?.id){
                           item = await connection.Items.create({
                                uuid: crypto.randomUUID(),
                                item_name: d.name,
                                item_Description: d.description,
                                rate: d?.unitTypes ? d.rate / d.quantity : d.rate,
                                qty: 1,
                                // unit_code : d.unitTypes ?? '',
                                status: 1,
                            }, { transaction });
                        }

                        return {
                            id: item?.id ? item.id : d.id,
                            code : d.code ?? '',
                            name: item?.item_name ? item.item_name : d.name,
                            description: item?.item_Description ? item.item_Description : d.description,
                            rate: item?.rate ? item.rate : d.rate,
                            quantity: item?.qty ? item.qty : d.quantity,
                            unitTypes : item?.unit_code ? item.unit_code : d.unitTypes,
                            gstChecked: d.gstChecked ?? false,
                            gstValue: d.gstValue ?? '',
                            discountChecked: d.discountChecked ?? false,
                            discountType: d.discountType ?? 'flat',
                            discountValue: d.discountValue ?? ''
                        };
                        
                    })
                );
                let PurchaseOrderFields = {
                    uuid,
                    poNumber,
                    client: client,
                    items: itemDetails,
                    subTotal,
                    total,
                    paymentStatus,
                    sentStatus,
                    logo,
                    comment,
                    customInvoice,
                    customInvoiceOption,
                    attachments: filteredAttachments
                };

                purchaseOrderCreated = await super.create(res, connection.PurchaseOrder, PurchaseOrderFields, { transaction });
            } else {
                itemDetails = items;
                let PurchaseOrderFields = {
                    uuid,
                    poNumber,
                    client: client,
                    items: itemDetails,
                    subTotal,
                    total,
                    paymentStatus,
                    sentStatus,
                    logo,
                    comment,
                    customInvoice,
                    customInvoiceOption,
                    attachments: filteredAttachments
                };

                purchaseOrderCreated = await super.create(res, connection.PurchaseOrder, PurchaseOrderFields, { transaction });
            }

            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Purchase Order created successfully.",
                data: {
                    purchaseOrder: purchaseOrderCreated,
                    client,
                    items: itemDetails
                }
            });
        } catch (error) {
            await transaction.rollback();
            console.error('Error creating Purchase Order:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });

    static fetchNextPurchaseOrderNumber = catchAsyncErrors(async (req, res) => {
        const userId = req.user.id;
        const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);
        if (error) {
            return res.status(404).json({ status: false, message: error });
        }

        try {
            let purchaseOrders = await connection.PurchaseOrder.findAll({});

            const nextPurchaseOrderNumber = purchaseOrders.length > 0 ? purchaseOrders[purchaseOrders.length - 1].id + 1 : 1;

            return res.status(200).json({
                status: true,
                message: "Next purchase order number retrieved successfully.",
                data: { nextPurchaseOrderNumber }
            });
        } catch (error) {
            console.error('Error fetching purchase orders:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });

    static getAllPurchaseOrders = catchAsyncErrors(async (req, res) => {
        const userId = req.user.id;
        const { paymentStatus } = req.body;
        const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);
        if (error) {
            return res.status(404).json({ status: false, message: error });
        }

        try {
            const filter = {};
            if (paymentStatus && paymentStatus !== "") {
                filter.payment_status = paymentStatus;
            }

            let purchaseOrders = await connection.PurchaseOrder.findAll({
                where: filter
            });

            const enrichedPurchaseOrders = await Promise.all(
                purchaseOrders.map(async (est) => {
                    let client;
                    if (typeof est?.client === "string") {
                        try {
                            client = JSON.parse(est.client);
                        } catch (err) {
                            console.error("Error parsing client JSON:", err);
                            client = {};
                        }
                    } else {
                        client = est?.client || {};
                    }

                    let parsedItems;
                    if (typeof est?.items === "string") {
                        try {
                            parsedItems = JSON.parse(est.items);
                        } catch (err) {
                            console.error("Error parsing items JSON:", err);
                            parsedItems = [];
                        }
                    } else {
                        parsedItems = est?.items || [];
                    }

                    return { ...est.toJSON(), client, items: parsedItems };
                })
            );

            return res.status(200).json({
                status: true,
                message: "Purchase orders retrieved successfully.",
                data: enrichedPurchaseOrders
            });
        } catch (error) {
            console.error('Error fetching purchase orders:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });

    static getPurchaseOrderDetails = catchAsyncErrors(async (req, res, next) => {
        const { id } = req.body;
        const userId = req.user.id;

        const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);
        if (error) {
            return res.status(404).json({ status: false, message: error });
        }

        try {
            const purchaseOrder = await connection.PurchaseOrder.findOne({
                where: { id: id },
                order: [['created_at', 'DESC']]
            });

            if (!purchaseOrder) {
                return res.status(404).json({ status: false, message: 'Purchase Order not found' });
            }

            let client;
            if (typeof purchaseOrder?.client === "string") {
                try {
                    client = JSON.parse(purchaseOrder.client);
                } catch (err) {
                    console.error("Error parsing client JSON:", err);
                    client = {};
                }
            } else {
                client = purchaseOrder?.client || {};
            }

            // Add profileImage URL if present
            if (client && client.profileImage) {
                client.profileImage = `${req.protocol}://${req.get('host')}/uploads/${client.profileImage}`;
            }

            let items;
            if (typeof purchaseOrder?.items === "string") {
                try {
                    items = JSON.parse(purchaseOrder.items);
                } catch (err) {
                    console.error("Error parsing items JSON:", err);
                    items = [];
                }
            } else {
                items = purchaseOrder?.items || [];
            }
             // Populate header, waterMark, colour, and logo details if present
            let settingData = purchaseOrder.customInvoice;

            if(!settingData || Object.keys(settingData).length === 0){
                // If no custom settings exist, use default values
                settingData = {
                    headerDetails: { headerImg: '', headerText: '' },
                    waterMarkDetails: { waterMarkImg: '' },
                    colourDetails: { colourCode: '' },
                    logoDetails: { logoImage: '' }
                };
            }
            else {
                // Populate header details
                if (settingData.headerImg) {
                    settingData.headerDetails = settingData.headerImg;
                }

                // Populate waterMark details
                if (settingData.waterMarkImg) {
                    settingData.waterMarkDetails = settingData.waterMarkImg;
                }

                // Populate colour details
                if (settingData.colourCode) {
                    settingData.colourDetails = settingData.colourCode;
                }

                // Populate logo details
                if (settingData.logoImage) {
                    settingData.logoDetails = settingData.logoImage;
                }

            }

            return res.status(200).json({
                status: true,
                message: "Purchase Order details retrieved successfully.",
                data: {
                    purchaseOrder,
                    client,
                    items,
                    attachments: typeof purchaseOrder?.attachments === 'string' ? JSON.parse(purchaseOrder.attachments) : purchaseOrder?.attachments,
                    customInvoiceOption: typeof purchaseOrder?.customInvoiceOption === 'string' ? JSON.parse(purchaseOrder.customInvoiceOption) : purchaseOrder?.customInvoiceOption,
                    customInvoice: typeof settingData === 'string' ? JSON.parse(settingData) : settingData
                }
            });
        } catch (error) {
            console.error('Error fetching purchase order details:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });

    static updatePurchaseOrder = catchAsyncErrors(async (req, res) => {
        const { id } = req.body;
        const { autosaveEnabled, poNumber, clients, items, subTotal, total, paymentStatus, sentStatus, logo, attachments, comment } = req.body;
        const userId = req.user.id;

        const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);
        if (error) {
            return res.status(404).json({ status: false, message: error });
        }

        const transaction = await connection.sequelize.transaction();

        let client = {};
        if (clients?.id) {
            client = await connection.Client.findOne({ where: { id: clients.id } });
            if (client && !client.id) {
                client = { ...client.toJSON(), id: clients.id };
            }
        } else {
            client = await connection.Client.create({
                uuid: crypto.randomUUID(),
                name: clients.name,
                email: clients.email,
                phone: clients.phone
            });
            if (client) {
                    await connection.ProjectContacts.create({
                        uuid: crypto.randomUUID(),
                        client_id : client.id,
                        client_admin_id: userId,
                        contact_name: clients.name,
                        contact_email: clients.email,
                        contact_phone: clients.phone,
                        is_primary: true
                    });
                }
            client = client.toJSON ? client.toJSON() : clients;
        }

        let filteredAttachments = [];
        if (attachments && typeof attachments === 'object' && attachments['']) {
            if (Array.isArray(attachments[''])) {
                filteredAttachments = attachments[''].filter(att => typeof att !== 'undefined' && att !== null && att !== '');
            } else {
                filteredAttachments = [attachments['']].filter(att => typeof att !== 'undefined' && att !== null && att !== '');
            }
        } else if (typeof attachments === 'string') {
            filteredAttachments = attachments.split(',').map(att => att.trim()).filter(att => att !== '');
        } else if (Array.isArray(attachments)) {
            filteredAttachments = attachments.filter(att => typeof att !== 'undefined' && att !== null && att !== '');
        } else if (attachments && typeof attachments === 'object') {
            filteredAttachments = Object.values(attachments).filter(att => typeof att !== 'undefined' && att !== null && att !== '');
        }

        try {
            let purchaseOrderUpdateFields = {};
            let itemDetails = [];

            if (autosaveEnabled && (autosaveEnabled === true || autosaveEnabled === "true")) {
                try {
                    itemDetails = await Promise.all(
                        items.map(async (d) => {
                            let item;
                           if (!d?.id){
                                // Create new item
                                item = await connection.Items.create({
                                    uuid: crypto.randomUUID(),
                                    item_name: d.name,
                                    item_Description: d.description,
                                    rate: d?.unitTypes ? d.rate / d.quantity : d.rate,
                                    qty: 1,
                                    // unit_code : d.unitTypes ?? '',
                                    status: 1,
                                }, { transaction });
                            }
                            return {
                                id: item?.id ? item.id : d.id,
                                code : d.code ?? '',
                                name: item?.item_name ? item.item_name : d.name,
                                description: item?.item_Description ? item.item_Description : d.description,
                                rate: item?.rate ? item.rate : d.rate,
                                quantity: item?.qty ? item.qty : d.quantity,
                                unitTypes : item?.unit_code ? item.unit_code : d.unitTypes,
                                gstChecked: d.gstChecked ?? false,
                                gstValue: d.gstValue ?? '',
                                discountChecked: d.discountChecked ?? false,
                                discountType: d.discountType ?? 'flat',
                                discountValue: d.discountValue ?? ''
                            };
                        })
                    );
                } catch (error) {
                    console.log("Error parsing items JSON:", error);
                    return res.status(500).json({ status: false, message: "Error processing items data.", data: {} });
                }

                purchaseOrderUpdateFields = {
                    poNumber,
                    client: client,
                    items : itemDetails,
                    subTotal,
                    total,
                    paymentStatus,
                    sentStatus,
                    logo,
                    comment,
                    attachments : filteredAttachments
                };

            } else {
                itemDetails = items;
                purchaseOrderUpdateFields = {
                    poNumber,
                    client: client,
                    items : itemDetails,
                    subTotal,
                    total,
                    paymentStatus,
                    sentStatus,
                    logo,
                    comment,
                    attachments : filteredAttachments
                };
            }
           

            const [updatedPurchaseOrderCount, updatedPurchaseOrder] = await connection.PurchaseOrder.update(purchaseOrderUpdateFields, {
                where: { id: id },
                returning: true,
                transaction
            });

            if (updatedPurchaseOrderCount === 0) {
                return res.status(404).json({ status: false, message: 'Purchase Order not found' });
            }

            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Purchase Order updated successfully.",
                data: {
                    purchaseOrder: updatedPurchaseOrder[0],
                    client,
                    items: itemDetails,
                }
            });
        } catch (error) {
            await transaction.rollback();
            console.error('Error updating purchase order:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });

    static deletePurchaseOrder = catchAsyncErrors(async (req, res, next) => {
        const { id } = req.body;
        const userId = req.user.id;

        const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);
        if (error) {
            return res.status(404).json({ status: false, message: error });
        }

        const transaction = await connection.sequelize.transaction();
        try {
            const deletedPurchaseOrderCount = await connection.PurchaseOrder.destroy({
                where: { id: id },
                transaction
            });

            if (deletedPurchaseOrderCount === 0) {
                return res.status(404).json({ status: false, message: 'Purchase Order not found' });
            }

            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Purchase Order deleted successfully."
            });
        } catch (error) {
            await transaction.rollback();
            console.error('Error deleting purchase order:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });

    static getConnectionForClient = async (userId, mysqlConfig) => {
        try {
            const user = await clientModel.findOne({
                attributes: ['id', 'database_name'],
                where: { id: userId }
            });

            if (!user) {
                return { error: 'User not found', connection: null };
            }

            const db_name = user.database_name;
            if (!db_name) {
                return { error: 'Please create your company first before accessing this resource.', connection: null };
            }

            const connection = await connectSpecificToDatabase(
                db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
            );

            return { error: null, connection };
        } catch (err) {
            console.error("Error in getConnectionForClient:", err);
            return { error: 'Failed to establish a connection.', connection: null };
        }
    };

}

module.exports = purchaseOrderController;