const axios = require("axios");
const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/errorHandler");
const RequestHandler = require("../utils/RequestHandler");
const fileUploaderSingle = require("../utils/fileUpload").fileUploaderSingle;
const bcrypt = require("bcryptjs");
const JWTAuth = require("../utils/jwtToken");
const jwt = require("jsonwebtoken");
const jwtConfig = require("../config").JWT;
const { Op } = require("sequelize");

const timeZone = require("../config/index.js").Timezone;
const moment = require('moment-timezone');

const {
  calculateDistance,
  calculateDistanceInsTentApi,
  calculateTimeInKilometers,
  getRateChartCategory,
} = require("../utils/utilities");
const {
  MSG_RECORD_STATUS_SUCCESS,
  MSG_RECORD_FETCH_SUCCESS,
} = require("../config/constants");
const requestHandler = new RequestHandler();

const db = require("../models");
const modulesModel = db.Modules;
const modulePermissionsModel = db.ModulePermissions;
const userModel = db.Users;
const roleModel = db.Roles;
const agentModel = db.Agents;
const agentBookingMappingsModel = db.AgentBookingMappings;

class AgentController extends BaseController {
  constructor() {
    super();
  }

  static generateEmployeeCode(businessNameInitials, groundNameInitials, employeeType) {
    let employeeTypeInitials = "";

    if(employeeType == "agent"){
      employeeTypeInitials = "AG";
    } else if (employeeType == "supervisor"){
      employeeTypeInitials = "SV";
    } else if (employeeType == "manager"){
      employeeTypeInitials = "MG";
    } else if (employeeType == "corporate"){
      employeeTypeInitials = "CR";
    }

		let momentZone = moment().tz(timeZone);
		// format today's date as dd-mm-yy without spaces or hyphens
		let todayDate = momentZone.format('DDMMYY'); // "280924" for 28-09-2024
		
		// format current time in 24 (hh:mm) format without spaces or hyphens
		let currentTime = momentZone.format('HHmm'); // "2230" for 22:30

		// -------- generate employeeCode --------
		let employeeCode = `${businessNameInitials}-${groundNameInitials}-${employeeTypeInitials}-${todayDate}-${currentTime}`;
		// -------- generate employeeCode --------
		
		return employeeCode;
	}

  static agentAddUpdate = catchAsyncErrors(async (req, res, next) => {
    let { firstName, lastName, email, dialCode, phone, gender, address, parkingGroundId, id, } = req.body;

    if (!id) {
      // agent ADD happening ===
      if (!firstName || !lastName) {
        return res.status(422).json({
          status: false,
          message: "First name and last name is required.",
          data: {},
        });
      }
      if (!email) {
        return res.status(422).json({
          status: false,
          message: "Email is required.",
          data: {},
        });
      }
      if (!phone) {
        return res.status(422).json({
          status: false,
          message: "Phone is required.",
          data: {},
        });
      }
      if (!gender) {
        return res.status(422).json({
          status: false,
          message: "Gender is required.",
          data: {},
        });
      }
      if (!parkingGroundId) {
        return res.status(422).json({
          status: false,
          message: "Parking ground id is required.",
          data: {},
        });
      }
    }

    let condition = {
      deletedAt: null,
    };
    if (id) {
      // during edit -> should not check self ===
      condition.id = `{
        [Op.ne]: ${id}
      }`;
    }

    let checkExist = await userModel.findOne({
      attributes: ["firstName", "lastName"],
      where: {
        ...condition,
        [Op.or]: [{ phone: phone }, { email: email }],
      },
    });

    if (checkExist) {
      return res.status(400).json({
        status: false,
        message: "This phone or email is already registered with us..!! Please try with another credentials.",
        data: checkExist,
      });
    }

    // =========== single file upload ================
    let fileName = "";
    if (req.files.profileImage) {
      let image = await fileUploaderSingle(
        "src/public/uploads/userImages/",
        req.files.profileImage
      );
      fileName = image.newfileName;
    }
    // =========== single file upload ================
    
    let role = await roleModel.findOne({
      where: {
        roleName: "Agent"
      }
    });
    let updateFields = {
      roleId: role.id,
    };
    if (firstName) {
      updateFields.firstName = firstName;
    }
    if (lastName) {
      updateFields.lastName = lastName;
    }
    if (email) {
      updateFields.email = email;
    }
    if (dialCode) {
      updateFields.dialCode = dialCode;
    }
    if (phone) {
      updateFields.phone = phone;
    }
    if (gender) {
      updateFields.gender = gender;
    }
    
    // === default password for agents ===
    let defaultPass = "agentPass@123";
    if (defaultPass) {
      updateFields.password = await bcrypt.hash(defaultPass, 10);
    }
    // === default password for agents ===
    if (address) {
      updateFields.address = address;
    }
    if (fileName != "") {
      updateFields.profileImage = fileName;
    }
    
    let agentExists = {};
    if(id && id != "" && id != null){
      agentExists = await agentModel.findOne({
        where: {
          userId: id
        }
      });
    }
    // ---- user add/update ----
    let updated =
      agentExists && agentExists.userId != "" && agentExists.userId != null
        ? await super.updateById(userModel, id, updateFields)
        : await super.create(res, userModel, updateFields);
    // ---- user add/update ----

    if (updated) {
      let updatedUser = {};
      if(id && id != "" && id != null){
        updatedUser = await super.getByCustomOptionsSingle(req, userModel, {
          where: { 
            id: id 
          },
        });
      } else {
        updatedUser = await super.getByCustomOptionsSingle(req, userModel, {
          where: { 
            id: updated.id 
          },
        });
      }
      // ==== user successfully added : CREATING AGENT DATA =====
      let agentUpdateFields = {
        userId: updatedUser.id,
        parkingGroundId: parkingGroundId,
      };
      agentUpdateFields.employeeCode = AgentController.generateEmployeeCode("PP", "JFKA", "agent");
      let agent = {};
      if(id && id != "" && id != null){
        agent = await super.getByCustomOptionsSingle(req, agentModel, {
          where: {
            userId: id,
          }
        });
      }
      let agentUpdated = 
        id && id != "" && id != null
          ? await super.updateById(agentModel, agent.id, agentUpdateFields)
          : await super.create(res, agentModel, agentUpdateFields);
      // ==== user successfully added : CREATING AGENT DATA =====

      let agentDetails = {};
      if(agentUpdated){
        if(id && id != "" && id != null){
          agentDetails = await agentModel.findOne({
            where: {
              userId: id,
            }
          });
        } else {
          agentDetails = await agentModel.findOne({
            where: {
              userId: agentUpdated.userId,
            }
          });
        }
      }

      let userDetails = {};
      if(id && id != "" && id != null){
        userDetails = await userModel.findOne({
          where: {
            id: id,
          },
          include: [
            {
              model: agentModel,
            }
          ]
        });
      } else {
        userDetails = await userModel.findOne({
          where: {
            id: updatedUser.id,
          },
          include: [
            {
              model: agentModel,
            }
          ]
        });
      }

      // ====== create permissions START ======
      let accessArr = ["Bookings"];
      let modulesWithAccess = await modulesModel.findAll({
        where: {
          moduleName: {
            [Op.in]: accessArr,
          },
        },
      });
      let moduleAccessArr = [];
      modulesWithAccess.forEach((item) => {
        moduleAccessArr.push(item.id);
      });

      if (Array.isArray(moduleAccessArr)) {
        // moduleAccess should always be array ========
        moduleAccessArr.forEach(async (moduleId) => {
          let dataToBeUpdated = {
            userId: updatedUser.id,
            moduleId: moduleId,
          };
          let checkPermissionExists = {};
          if(id && id != "" && id != null){
            checkPermissionExists = await modulePermissionsModel.findOne({
              where: {
                userId: id,
                moduleId: moduleId,
              },
            });
          } else {
            checkPermissionExists = await modulePermissionsModel.findOne({
              where: {
                userId: updatedUser.id,
                moduleId: moduleId,
              },
            });
          }
          
          let modulePermissionUpdate = 
            checkPermissionExists && checkPermissionExists != "" && checkPermissionExists != null
              ? await super.updateByCustomOptions(
                  modulePermissionsModel, 
                  {
                    userId: id,
                    moduleId: moduleId,
                  }, 
                  dataToBeUpdated
                )
              : await modulePermissionsModel.create(dataToBeUpdated);

          if (modulePermissionUpdate) {
            console.log("Module permissions created/updated.");
          } else {
            console.log("Module permissions not affected.");
          }
        });
      } else {
        return res.status(422).json({
          status: false,
          message: "Oopss..!! Something wrong happened while creating permissions..!!",
          data: {},
        });
      }
      // ====== create permissions END ======

      if(agentUpdated){
        return res.status(200).json({
          status: true,
          message: "Successful.",
          data: userDetails,
        });
      } else {
        return res.status(400).json({
          status: false,
          message: "Oops..!! Something wrong happened while creating agent profile.",
          data: {},
        });
      }

    } else {
      return res.status(400).json({
        status: false,
        message: "Oops..!! Something wrong happened while creating user profile for this agent.",
        data: {},
      });
    }
  });

  static agentList = catchAsyncErrors(async (req, res, next) => {
    let options = {
      where: {
        // "$role.roleName$": "Vendor",
        isActive: true,
        deletedAt: null,
      },
      order: [["createdAt", "DESC"]],
      include: [
        // {
        //   model: roleModel, // including associated model
        //   attributes: ["roleName"], // Attributes to select from the included model
        // },
        {
          model: userModel,
          attributes: {
            exclude: [
              "password",
              "webLogin",
              "appLogin",
              "fcmToken",
              "OTP",
              "macAddress",
            ],
          },
        },
      ],
    };
    // let userList = await super.getList(req, userModel, options);
    let agentList = await super.getList(req, agentModel, options);
    
    let userImageUrl = process.env.API_URL + "uploads/userImages/";

    if (agentList.length > 0) {
      return res.status(200).json({
        status: true,
        message: "Data found.",
        data: {
          agentList: agentList,
          userImageUrl: userImageUrl,
        },
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No data found.",
        data: {},
      });
    }
  });

  static agentDetails = catchAsyncErrors(async (req, res, next) => {
    let { id } = req.body;
    let agentDetail = await super.getByCustomOptionsSingle(req, agentModel, {
      include: [
        {
          model: userModel, // including associated model
        },
      ],
      where: { 
        id: id 
      },
    });
    if(agentDetail){
      return res.status(200).json({
        status: true,
        message: "Details found.",
        data: agentDetail
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No details found.",
        data: {}
      });
    }
  });

  static agentDelete = catchAsyncErrors(async (req, res, next) => {
    let { agentId } = req.body;

    let checkAgentBookingExist = await super.getByCustomOptionsSingle(req, agentBookingMappingsModel, {
      where: { agentId: agentId },
    });

    if(checkAgentBookingExist){
      return res.status(422).json({
        status: false,
        message: "You can not delete this agent. This agent is assigned in a booking.",
        data: {},
      });
    }

    let checkExist = await super.getByCustomOptionsSingle(req, agentModel, {
      where: {
        id: agentId,
      }
    });

    if(checkExist){
      let userIdOfAgent = checkExist?.userId;
      
      let agentDelete = super.deleteById(agentModel, agentId);

      let agentUserProfileDelete = super.deleteById(userModel, userIdOfAgent);

      if(agentDelete && agentUserProfileDelete){
        return res.status(200).json({
          status: true,
          message: "Agent deleted successfully.",
          data: {},
        });
      } else {
        return res.status(400).json({
          status: false,
          message: "Ooppss..!! Something went wrong while deleting agent.",
          data: {},
        });
      }
    } else {
      return res.status(400).json({
        status: false,
        message: "No agent found with this id, please make sure you are sending correct id of agent.",
        data: {}
      });
    }
  });
}

module.exports = AgentController;
