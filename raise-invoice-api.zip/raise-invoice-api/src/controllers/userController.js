const axios = require("axios");
const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/errorHandler");
const RequestHandler = require("../utils/RequestHandler");
const fileUploaderSingle = require("../utils/fileUpload").fileUploaderSingle;
const bcrypt = require("bcryptjs");
const JWTAuth = require("../utils/jwtToken");
const jwt = require("jsonwebtoken");
const jwtConfig = require("../config").JWT;
const { Op } = require("sequelize");
const crypto = require("crypto");
const moment = require('moment-timezone');
const mysqlConfig = require("../config/index").Mysql;
const { connectSpecificToDatabase } = require("../config/specificConnect");
const XLSX = require('xlsx');

const {
  createDatabase,
  updateDatabase,
  generateUniqueAccountId
} = require("../utils/utilities");
const {
  MSG_RECORD_STATUS_SUCCESS,
  MSG_RECORD_FETCH_SUCCESS,
} = require("../config/constants");
const requestHandler = new RequestHandler();

const db = require("../models");
const { random } = require("lodash");
const vendorModel = db.Vendors;
const userModel = db.Users;
const clientModel = db.Clients;
const roleModel = db.Roles;
const usersrolesModel = db.UsersRoles;
const modulePermissionsModel = db.ModulePermissions;
const bookingRequestsModel = db.BookingRequests;
const slotsModel = db.Slots;
const vehicleTypesModel = db.VehicleTypes;
const notificationModel = db.Notifications;
const countryModel = db.Countries;
const userLocationModel = db.UserLocations;
const userCompanyModel = db.UserCompanies;
const permissionModel = db.Permissions;
const clientSubscriptionsModel = db.ClientSubscriptions;
const plansModel = db.Plans;
const newsletterSubscriptionModel = db.NewsletterSubscriptions;
const userEnquiryModel = db.UserEnquiries;

class UserController extends BaseController {
  constructor() {
    super();
  }

  static saveUser = catchAsyncErrors(async (req, res, next) => {
    let {
      id,
      role,
      firstName,
      lastName,
      email,
      phone,
      password,
      // address, 
      // country, 
      // state, 
      // city, 
      // zipcode, 
      // latitude, 
      // longitude, 
      // dob, 
      // gender,
      companyName,
      companyAddress,
      companyPhone,
      companyEmail,
      companyWebsite,
      companyInfo,
    } = req.body;

    if (role == 'client') {
      var userDetailCheck = await super.getByCustomOptionsSingle(req, userCompanyModel, {
        where: {
          companyName: companyName
        }
      });
      if (!id && userDetailCheck) {
        return res.status(500).json({
          status: false,
          message: "Company name already exists!",
          data: {}
        });
      }
    }


    // user add happening ===

    if (!firstName) {
      return res.status(422).json({
        status: false,
        message: "First name is required.",
        data: {},
      });
    }
    if (role != 'client' && !lastName) {
      return res.status(422).json({
        status: false,
        message: "Last name is required.",
        data: {},
      });
    }
    if (!email) {
      return res.status(422).json({
        status: false,
        message: "Email is required.",
        data: {},
      });
    }
    if (!phone) {
      return res.status(422).json({
        status: false,
        message: "Phone number is required.",
        data: {},
      });
    }
    if (!id && !password) {
      return res.status(422).json({
        status: false,
        message: "Password is required.",
        data: {},
      });
    }
    // if (!address) {
    //   return res.status(422).json({
    //     status: false,
    //     message: "Address is required.",
    //     data: {},
    //   });
    // }
    // if (!country) {
    //   return res.status(422).json({
    //     status: false,
    //     message: "Country is required.",
    //     data: {},
    //   });
    // }
    if (!role) {
      return res.status(422).json({
        status: false,
        message: "Role is required.",
        data: {},
      });
    }
    let roleDetails = await roleModel.findOne({
      where: {
        roleSlug: role,
        deletedAt: null,
      }
    });
    if (!roleDetails) {
      return res.status(422).json({
        status: false,
        message: "Role is invalid.",
        data: {},
      });
    }

    if (role == 'client') {
      if (!companyName) {
        return res.status(422).json({
          status: false,
          message: "Company name is required.",
          data: {},
        });
      }
      if (!companyAddress) {
        return res.status(422).json({
          status: false,
          message: "Company address is required.",
          data: {},
        });
      }
      if (!companyAddress) {
        return res.status(422).json({
          status: false,
          message: "Company address is required.",
          data: {},
        });
      }
      if (!companyPhone) {
        return res.status(422).json({
          status: false,
          message: "Company phone number is required.",
          data: {},
        });
      }
      if (!companyEmail) {
        return res.status(422).json({
          status: false,
          message: "Company email is required.",
          data: {},
        });
      }
    }

    let condition = {
      deletedAt: null,
    };
    if (id) {
      // during edit -> should not check self ===
      condition.id = `{
            [Op.ne]: id
        }`;
    }

    let checkExist = await userModel.findOne({
      attributes: ["firstName", "lastName"],
      where: {
        ...condition,
        [Op.or]: [{ phone: phone }, { email: email }],
      },
    });

    if (checkExist) {
      return res.status(400).json({
        status: false,
        message: "User with this phone or email already exist!",
        data: checkExist,
      });
    }

    // const companyNameSlug = companyName ? companyName.toLowerCase().replace(/\s+/g, '_').replace(/[^\w_]+/g, '') : '';


    let updateFields = {};

    if (firstName) {
      updateFields.firstName = firstName;
    }
    if (lastName) {
      updateFields.lastName = lastName;
    }
    if (role == 'client') {
      updateFields.name = firstName;
    }
    if (email) {
      updateFields.email = email;
    }
    if (phone) {
      updateFields.phone = phone;
    }
    if (password) {
      updateFields.password = await bcrypt.hash(password, 10);
    }

    let companyNameSlug = '';
    if(role == 'client'){
   // if (!id || id == "" || id == null || id == 'null' && companyNameSlug) {
     if(!id || id == "" || id == null || id == 'null') {
      companyNameSlug = companyName.toLowerCase().replace(/\s+/g, '_').replace(/[^\w_]+/g, '') + '_' + Date.now();
      updateFields.database_name = companyNameSlug;
      updateFields.isVerified = true;
      }else{
      const clientAdmin = await clientModel.findOne({ attributes: ['database_name'], where: { id } });
      companyNameSlug = clientAdmin.database_name;
      }
    }
    // if (dob) {
    //   updateFields.dob = dob;
    // }
    // if (gender) {
    //   updateFields.gender = gender;
    // }

    // =========== single file upload ================
    if (req.files.profileImage) {
      let imageData = await fileUploaderSingle(
        "src/public/uploads/user/",
        req.files.profileImage
      );
      updateFields.profileImage = imageData.newfileName;
    }
    // console.log(updateFields);
    // =========== single file upload ================
    // console.log('updateFields', updateFields);
    let updated = null;
    if (id && id != "" && id != null && id != 'null') {
      if (role == 'client') {
        updated = await super.updateById(clientModel, id, updateFields);

        // let clientUserData = await clientModel.findOne({
        //   where: {
        //     id: id
        //   },
        // });
        // await createDatabase(companyNameSlug, clientUserData);

      } else {
        updated = await super.updateById(userModel, id, updateFields)
      }

    } else {
      updateFields.account_id = await generateUniqueAccountId();
      updateFields.uuid = crypto.randomUUID();
      if (role == 'client') {
        updated = await super.create(res, clientModel, updateFields);
        // await createDatabase(companyNameSlug, updated);
      } else {
        updated = await super.create(res, userModel, updateFields);
      }
    }
    if (updated) {

      let userId = (id && id != "" && id != null && id != 'null') ? id : updated.id;

      // let updateLocationFields = {};

      // let locationData = await userLocationModel.findOne({
      //   attributes: ["id"],
      //   where: {
      //     userId: userId
      //   },
      // });
      // updateLocationFields.userId = userId;
      // if(country){
      //   updateLocationFields.countryId = country
      // }
      // if(state){
      //   updateLocationFields.stateId = state
      // }
      // if(city){
      //   updateLocationFields.cityId = city
      // }
      // if(address){
      //   updateLocationFields.streetAddess = address
      // } 
      // if(zipcode){
      //   updateLocationFields.zipcode = zipcode
      // }
      // if(latitude){
      //   updateLocationFields.latitude = latitude
      // }    
      // if(longitude){
      //   updateLocationFields.longitude = longitude
      // }

      // let locationUpdated = null
      // if(locationData){
      //   locationUpdated = await super.updateById(userLocationModel, locationData.id, updateLocationFields)
      // }else{
      //   updateLocationFields.uuid = crypto.randomUUID();
      //   locationUpdated = await super.create(res, userLocationModel, updateLocationFields);
      // }

      if (role == 'client') {
        let updateCompanyFields = {};

        let companyData = await userCompanyModel.findOne({
          attributes: ["id"],
          where: {
            userId: userId
          },
        });
        updateCompanyFields.userId = userId;
        if (companyName) {
          updateCompanyFields.companyName = companyName
        }
        if (companyAddress) {
          updateCompanyFields.companyAddress = companyAddress
        }
        if (companyPhone) {
          updateCompanyFields.companyPhone = companyPhone
        }
        if (companyEmail) {
          updateCompanyFields.companyEmail = companyEmail
        }
        if (companyWebsite) {
          updateCompanyFields.companyWebsite = companyWebsite
        }
        if (companyInfo) {
          updateCompanyFields.companyInfo = companyInfo
        }
        // console.log('Company Fields', updateCompanyFields);
        if (companyData) {
          await super.updateById(userCompanyModel, companyData.id, updateCompanyFields)
        } else {
          updateCompanyFields.uuid = crypto.randomUUID();
          await super.create(res, userCompanyModel, updateCompanyFields);
        }


        let clientCompanyData = await userCompanyModel.findOne({
          where: {
            userId: userId
          },
        });

        let clientUserData = await clientModel.findOne({
          where: {
            id: userId
          },
        });
        if (!id || id == "" || id == null || id == 'null') {
          await createDatabase(companyNameSlug, clientUserData, clientCompanyData);
        } else {
          await updateDatabase(companyNameSlug, clientUserData, clientCompanyData);
        }
      }

      let userDetails = await userModel.findOne({
        where: {
          id: userId,
        }
      });

      if (role != 'client') {
        if (!id || id == "" || id == null || id == 'null') {
          await usersrolesModel.create({ userId: parseInt(userId), roleId: roleDetails.id });
        } else {
          await super.updateByCustomOptions(
            usersrolesModel,
            {
              userId: parseInt(userId)
            },
            { roleId: roleDetails.id }
          )
        }
      }
      return res.status(200).json({
        status: true,
        message: "Successful.",
        data: userDetails,
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Oops.. Something wrong happened!",
        data: {},
      });
    }
  });

  static getUserDetails = catchAsyncErrors(async (req, res, next) => {
    let { id, uuid, role } = req.body;

    let whereClause = {};
    if (id) {
      whereClause = { id: id }
    }
    if (uuid) {
      whereClause = { uuid: uuid }
    }

    let options = {
      where: whereClause,
      attributes: {
        exclude: [
          "password",
          "webLogin",
          "appLogin",
          "fcmToken",
          "OTP",
          "macAddress",
        ],
      }
    };
    if (role !== 'client') {
      options.include = [
        {
          model: userLocationModel, // including associated model
          attributes: ["countryId", "streetAddess"], // Attributes to select from the included model
          as: 'userLocation',
          required: false
        },
        // {
        //   model: userCompanyModel, // including associated model
        //   attributes: ["companyName", "companyAddress", "companyPhone", "companyEmail", "companyWebsite", "companyInfo"], // Attributes to select from the included model
        //   as: 'userCompany',
        //   required: false
        // },
        {
          model: roleModel, // including associated model
          attributes: ["id", "roleName", "roleSlug"], // Attributes to select from the included model
          as: 'userRole',
          include: [
            {
              model: permissionModel,
              attributes: ["slug"],
              required: false,
            },
          ],
          // where: {
          //   roleSlug: {
          //     [Op.notIn]: ["super-admin"],
          //   },
          // },
        },
      ];
    } else {
      options.include = [
        {
          model: userCompanyModel, // including associated model
          attributes: ["companyName", "companyAddress", "companyPhone", "companyEmail", "companyWebsite", "companyInfo"], // Attributes to select from the included model
          as: 'userCompany',
          required: false
        }
      ];
    }

    if (role == 'client') {
      var userDetail = await super.getByCustomOptionsSingle(req, clientModel, options);
    } else {
      var userDetail = await super.getByCustomOptionsSingle(req, userModel, options);
    }

    // userDetail = userDetail.get({ plain: true });
    // console.log(userDetail);

    // Remove the password before sending the response
    // delete userDetail.password;

    /*let modulePermissions = await modulePermissionsModel.findAll({
      where:{
        userId: Number(id),
      }
    });
    // console.log("modulePermissions ===>");
    // console.log(modulePermissions);
    if(modulePermissions){
      let moduleAccess = [];
      modulePermissions.forEach((modulePermission)=>{
        moduleAccess.push(modulePermission.moduleId);
      });
      // console.log("moduleAccess ===>");
      // console.log(moduleAccess);
      userDetail["moduleAccess"] = moduleAccess;
    } else {
      userDetail["moduleAccess"] = [];
    }*/

    if (userDetail) {
      return res.status(200).json({
        status: true,
        message: "Details found.",
        data: userDetail
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No details found.",
        data: {}
      });
    }
  });

  static getUserList = catchAsyncErrors(async (req, res, next) => {
    let { roleSlug, searchText, advancedSearch, page = 1, limit = 0 } = req.body;
    let whereClause = {
      // isActive: true,
      deletedAt: null,
    };

    // if(dateRange && dateRange.length){
    //   whereClause['createdAt'] = {
    //     [Op.between]: [moment(dateRange[0]).startOf('day'), moment(dateRange[1]).endOf('day')]
    //   }
    // }
    if (searchText) {
      let searchId = searchText.toLowerCase().replace('usr-', '').replace(/^0+/, '');
      whereClause = {
        // isActive: true,
        deletedAt: null,
        [Op.or]: [
          {
            id:
            {
              [Op.like]: `%${searchId}%`
            }
          },
          {
            name:
            {
              [Op.like]: `%${searchText}%`
            }
          },
          {
            email:
            {
              [Op.like]: `%${searchText}%`
            }
          },
          {
            phone:
            {
              [Op.like]: `%${searchText}%`
            }
          },
          {
            '$userCompany.companyName$':
            {
              [Op.like]: `%${searchText}%`
            }
          },
          {
            '$userCompany.companyPhone$':
            {
              [Op.like]: `%${searchText}%`
            }
          },
          {
            '$userCompany.companyEmail$':
            {
              [Op.like]: `%${searchText}%`
            }
          },
          {
            '$userCompany.companyAddress$':
            {
              [Op.like]: `%${searchText}%`
            }
          },
          {
            '$userCompany.companyWebsite$':
            {
              [Op.like]: `%${searchText}%`
            }
          },
          {
            '$userCompany.companyInfo$':
            {
              [Op.like]: `%${searchText}%`
            }
          }
        ]
      };
    }

    if (advancedSearch && Object.keys(advancedSearch).length) {
      whereClause = {
        deletedAt: null,
      };
      if (advancedSearch.userId) {
        let userId = advancedSearch.userId.toLowerCase().replace('usr-', '').replace(/^0+/, '');
        if (userId) {
          whereClause['id'] = {
            [Op.like]: `%${userId}%`
          }
        }
      }
      if (advancedSearch.userName) {
        whereClause['name'] = {
          [Op.like]: `%${advancedSearch.userName}%`
        }
      }
      if (advancedSearch.userEmail) {
        whereClause['email'] = {
          [Op.like]: `%${advancedSearch.userEmail}%`
        }
      }
      if (advancedSearch.userPhone) {
        whereClause['phone'] = {
          [Op.like]: `%${advancedSearch.userPhone}%`
        }
      }
      if (advancedSearch.dateRange && advancedSearch.dateRange.length) {
        whereClause['createdAt'] = {
          [Op.between]: [moment(advancedSearch.dateRange[0]).startOf('day'), moment(advancedSearch.dateRange[1]).endOf('day')]
        }
      }
      if (advancedSearch.companyName) {
        whereClause['$userCompany.companyName$'] = {
          [Op.like]: `%${advancedSearch.companyName}%`
        }
      }
      if (advancedSearch.companyPhone) {
        whereClause['$userCompany.companyPhone$'] = {
          [Op.like]: `%${advancedSearch.companyPhone}%`
        }
      }
      if (advancedSearch.companyEmail) {
        whereClause['$userCompany.companyEmail$'] = {
          [Op.like]: `%${advancedSearch.companyEmail}%`
        }
      }
      if (advancedSearch.companyAddress) {
        whereClause['$userCompany.companyAddress$'] = {
          [Op.like]: `%${advancedSearch.companyAddress}%`
        }
      }
      if (advancedSearch.companyWebsite) {
        whereClause['$userCompany.companyWebsite$'] = {
          [Op.like]: `%${advancedSearch.companyWebsite}%`
        }
      }
    }
    let options = {
      // where: {
      //   // '$userRole.roleSlug$': {
      //   //   [Op.notIn]: ["super-admin", "vendor", "guest", "agent"],
      //   // },
      //   isActive: true,
      //   deletedAt: null,
      // },
      where: whereClause,
      order: [["createdAt", "DESC"]],
      attributes: {
        exclude: [
          "password",
          "webLogin",
          "appLogin",
          "fcmToken",
          "OTP",
          "macAddress",
        ],
      }
      // raw: true
    };

    if (roleSlug !== 'client') {
      options.include = [
        {
          model: roleModel,
          attributes: ["id", "roleName", "roleSlug"],
          as: 'userRole',
          where: {
            roleSlug: {
              [Op.in]: [roleSlug],
            },
          },
        }
      ];
    } else {
      options.include = [
        {
          model: userCompanyModel,
          as: 'userCompany',
          where: {
            deletedAt: null,
          },
          required: false,
        },
      ];
    }
    if (page && limit) {
      options.limit = limit;
      options.offset = (page - 1) * limit;
    }
    // console.log(roleSlug);
    var totalCount = 0;
    if (roleSlug == 'client') {
      var userList = await super.getList(req, clientModel, options);
      var totalCount = await clientModel.count(options);
    } else {
      var userList = await super.getList(req, userModel, options);
      var totalCount = await userModel.count(options);
    }
    let userImageUrl = process.env.API_URL + "uploads/userImages/";
    // console.log(userList.length);
    if (userList.length > 0) {
      return res.status(200).json({
        status: true,
        message: "Data found.",
        data: {
          userList: userList,
          userImageUrl: userImageUrl,
          totalPages: Math.ceil(totalCount / limit),
          totalCount: totalCount,
          currentPage: page
        },
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No data found.",
        data: {},
      });
    }
  });
  static getAdminUserList = catchAsyncErrors(async (req, res, next) => {
    let { roleSlug, searchText } = req.body;
    let whereClause = {
      // isActive: true,
      deletedAt: null,
    };
    if (searchText) {
      let searchId = searchText.toLowerCase().replace('usr-', '').replace(/^0+/, '');
      whereClause = {
        // isActive: true,
        deletedAt: null,
        [Op.or]: [
          {
            id:
            {
              [Op.like]: `%${searchId}%`
            }
          },
          {
            firstName:
            {
              [Op.like]: `%${searchText}%`
            }
          },
          {
            lastName:
            {
              [Op.like]: `%${searchText}%`
            }
          },
          {
            email:
            {
              [Op.like]: `%${searchText}%`
            }
          },
          {
            phone:
            {
              [Op.like]: `%${searchText}%`
            }
          }
        ]
      };
    }
    let options = {
      // where: {
      //   // '$userRole.roleSlug$': {
      //   //   [Op.notIn]: ["super-admin", "vendor", "guest", "agent"],
      //   // },
      //   isActive: true,
      //   deletedAt: null,
      // },
      where: whereClause,
      order: [["createdAt", "DESC"]],
      attributes: {
        exclude: [
          "password",
          "webLogin",
          "appLogin",
          "fcmToken",
          "OTP",
          "macAddress",
        ],
      }
      // raw: true
    };

    if (roleSlug !== 'client') {
      options.include = [
        {
          model: roleModel,
          attributes: ["id", "roleName", "roleSlug"],
          as: 'userRole',
          where: {
            roleSlug: {
              [Op.notIn]: ['client'],
            },
          },
        }
      ];
    } else {
      options.include = [
        {
          model: userCompanyModel,
          as: 'userCompany'
        },
      ];
    }

    // console.log(roleSlug);
    if (roleSlug == 'client') {
      var userList = await super.getList(req, clientModel, options);
    } else {
      var userList = await super.getList(req, userModel, options);
    }

    let userImageUrl = process.env.API_URL + "uploads/userImages/";

    if (userList.length > 0) {
      return res.status(200).json({
        status: true,
        message: "Data found.",
        data: {
          userList: userList,
          userImageUrl: userImageUrl,
        },
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No data found.",
        data: {},
      });
    }
  });

  static userSoftDelete = catchAsyncErrors(async (req, res, next) => {
    let { uuid } = req.body;

    let userDetail = await super.getByCustomOptionsSingle(req, userModel, {
      where: {
        uuid: uuid
      },
      attributes: ["id"],
      include: [
        {
          model: roleModel,
          attributes: ["id", "roleName", "roleSlug"],
          as: 'userRole',
          where: {
            roleSlug: {
              [Op.notIn]: ["super-admin"],
            },
          }
        },
      ],
    });

    if (!userDetail) {
      return res.status(403).json({
        status: false,
        message: "User not found!",
        data: {},
      });
    }
    // userDetail = userDetail.get({ plain: true });

    // let userCheckExist = await super.getByCustomOptions(req, userModel, {uuid: uuid});
    // let role = await super.getById(req, roleModel, userCheckExist.roleId);

    // if(
    //   (userDetail.id == 1)
    //   || (userDetail.userRole.roleSlug == "super-admin")
    // ){
    //   // ---- prevent Super Admin deletion by mistake or ill-intent ----
    //   return res.status(403).json({
    //     status: false,
    //     message: "You can't delete superadmin.",
    //     data: {},
    //   });
    // } 
    // if (role.roleSlug == "vendor"){
    //   let vendorDelete = await super.softDeleteByCondition(
    //     vendorModel, 
    //     {
    //       userId: id,
    //     },
    //     req.user.id,
    //   );
    // }

    let deleted = await super.softDeleteByCondition(
      userModel,
      {
        id: userDetail.id,
      },
      req.user.id,
    );

    if (deleted) {
      return res.status(200).json({
        status: true,
        message: "Soft deletion successful.",
        data: {}
      });
    } else {
      return res.status(500).json({
        status: false,
        message: "Oops.. something went wrong!",
        data: {}
      });
    }
  });
  // ========================= CLIENT SUBSCRIPTION STARTS ===========================

  static getClientSubscriptionList = catchAsyncErrors(async (req, res, next) => {
    let { uuid, searchText } = req.body;

    // user add happening ===
    if (!uuid) {
      return res.status(422).json({
        status: false,
        message: "Client id is required.",
        data: {},
      });
    }

    let clientDetails = await clientModel.findOne({
      attributes: ["id"],
      where: {
        uuid: uuid,
        deletedAt: null
      },
    });
    if (!clientDetails) {
      return res.status(422).json({
        status: false,
        message: "Client is invalid.",
        data: {},
      });
    }
    let whereClause = {
      // isActive: true,
      deletedAt: null,
      clientId: clientDetails.id
    };
    if (searchText) {
      let searchId = searchText.toLowerCase().replace('subs-', '').replace(/^0+/, '');
      whereClause = {
        isActive: true,
        deletedAt: null,
        [Op.or]: [
          {
            id:
            {
              [Op.like]: `%${searchId}%`
            }
          },
          {
            trialStartDate:
            {
              [Op.like]: `%${searchText}%`
            }
          },
          {
            trialEndDate:
            {
              [Op.like]: `%${searchText}%`
            }
          },
          {
            startDate:
            {
              [Op.like]: `%${searchText}%`
            }
          },
          {
            endDate:
            {
              [Op.like]: `%${searchText}%`
            }
          },
          {
            price:
            {
              [Op.like]: `%${searchText}%`
            }
          },
          {
            paymentMode:
            {
              [Op.like]: `%${searchText}%`
            }
          },
          {
            transactionId:
            {
              [Op.like]: `%${searchText}%`
            }
          }
        ]
      };
    }
    let options = {
      where: whereClause,
      order: [
        ['isExpired', 'ASC'],
        ['createdAt', 'ASC']
      ],
      include: [
        {
          model: plansModel,
        }
      ],
      // raw: true
    };

    var subscriptionList = await super.getList(req, clientSubscriptionsModel, options);
    if (subscriptionList) {
      return res.status(200).json({
        status: true,
        message: "Successful.",
        data: subscriptionList,
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Oops.. Something wrong happened!",
        data: {},
      });
    }
  });
  static getClientSubscriptionDetails = catchAsyncErrors(async (req, res, next) => {
    let { id, uuid } = req.body;

    let whereClause = {};
    if (id) {
      whereClause = { id: id }
    }
    if (uuid) {
      whereClause = { uuid: uuid }
    }

    let options = {
      where: whereClause,
      include: [
        {
          model: plansModel,
        }
      ],
    };

    let subscriptionDetail = await super.getByCustomOptionsSingle(req, clientSubscriptionsModel, options);

    if (subscriptionDetail) {
      return res.status(200).json({
        status: true,
        message: "Details found.",
        data: subscriptionDetail
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No details found.",
        data: {}
      });
    }
  });
  static saveClientSubscription = catchAsyncErrors(async (req, res, next) => {
    let {
      id,
      clientId,
      planId,
      duration,
      isTrial,
      trialDuration,
      startDate,
      price,
      paymentMode,
      isPaid,
    } = req.body;

    // var clientSubscriptionCheck = await super.getByCustomOptionsSingle(req, clientSubscriptionsModel, {
    //   where: {
    //     clientId: clientId,
    //     planId: planId,
    //     duration: duration,
    //     isExpired: 0
    //   }
    // });
    // // console.log(clientSubscriptionCheck)
    // if ((!id || id == "" || id == null || id == 'null') && clientSubscriptionCheck) {
    //   return res.status(500).json({
    //     status: false,
    //     message: "Subscription has already been taken!",
    //     data: {}
    //   });
    // }

    // Mark all previous subscriptions for this client as completed (isExpired: 1)
    await clientSubscriptionsModel.update(
      { isExpired: 1 },
      {
        where: {
          clientId: clientId,
          isExpired: 0,
          deletedAt: null
        }
      }
    );

    if (!clientId) {
      return res.status(422).json({
        status: false,
        message: "Client is required.",
        data: {},
      });
    }
    if (!planId) {
      return res.status(422).json({
        status: false,
        message: "Plan is required.",
        data: {},
      });
    }
    if (!duration) {
      return res.status(422).json({
        status: false,
        message: "Duration is required.",
        data: {},
      });
    }
    if (!price) {
      return res.status(422).json({
        status: false,
        message: "Price is required.",
        data: {},
      });
    }
    if (!startDate) {
      return res.status(422).json({
        status: false,
        message: "Start date is required.",
        data: {},
      });
    }

    // let condition = {
    //   deletedAt: null,
    // };
    // if (id) {
    //   // during edit -> should not check self ===
    //   condition.id = `{
    //         [Op.ne]: id
    //     }`;
    // }

    let updateFields = {
      clientId: clientId,
      planId: planId,
      duration: duration,
      isTrial: isTrial,
      trialDuration: trialDuration,
      price: price,
      paymentMode: paymentMode,
      isPaid: isPaid,
    };
    let durationMonth = 1;
    switch (duration) {
      case 'monthly':
        durationMonth = 1;
        break;
      case 'yearly':
        durationMonth = 12;
        break;
    }
    if (isTrial == 'true') {
      let endDate = moment(startDate).add(trialDuration, 'd').format('YYYY-MM-DD');
      updateFields.trialStartDate = startDate;
      updateFields.trialEndDate = endDate;
      let subscriptionStartDate = moment(endDate).add(1, 'd').format('YYYY-MM-DD');
      let subscriptionEndDate = moment(subscriptionStartDate).add(durationMonth, 'M').format('YYYY-MM-DD');
      updateFields.startDate = subscriptionStartDate;
      updateFields.endDate = subscriptionEndDate;
      updateFields.nextBillingDate = moment(subscriptionEndDate).add(1, 'd').format('YYYY-MM-DD');
    } else {
      let endDate = moment(startDate).add(durationMonth, 'M').format('YYYY-MM-DD');
      updateFields.trialStartDate = null;
      updateFields.trialEndDate = null;
      updateFields.startDate = startDate;
      updateFields.endDate = endDate;
      updateFields.nextBillingDate = moment(endDate).add(1, 'd').format('YYYY-MM-DD');
    }
    let updated = null;
    if (id && id != "" && id != null && id != 'null') {
      updated = await super.updateById(clientSubscriptionsModel, id, updateFields)
    } else {
      updateFields.uuid = crypto.randomUUID();
      updated = await super.create(res, clientSubscriptionsModel, updateFields);
    }
    if (updated) {
      let subscriptionId = (id && id != "" && id != null && id != 'null') ? id : updated.id;

      let subscriptionDetails = await clientSubscriptionsModel.findOne({
        where: {
          id: subscriptionId,
        }
      });
      let message = (id && id != "" && id != null && id != 'null') ? "Subscription successfully added." : "Subscription successfully updated.";
      return res.status(200).json({
        status: true,
        message: message,
        data: subscriptionDetails,
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Oops.. Something wrong happened!",
        data: {},
      });
    }
  });
  static deleteClientSubscription = catchAsyncErrors(async (req, res, next) => {
    let { uuid } = req.body;

    let subscriptionDetail = await super.getByCustomOptionsSingle(req, clientSubscriptionsModel, {
      where: {
        uuid: uuid
      },
      attributes: ["id"],
    });

    if (!subscriptionDetail) {
      return res.status(403).json({
        status: false,
        message: "Subscription not found!",
        data: {},
      });
    }
    let deleted = await super.deleteByCondition(
      clientSubscriptionsModel,
      {
        id: subscriptionDetail.id,
      }
    );

    if (deleted) {
      return res.status(200).json({
        status: true,
        message: "Subscription successfully deleted.",
        data: {}
      });
    } else {
      return res.status(500).json({
        status: false,
        message: "Oops.. something went wrong!",
        data: {}
      });
    }
  });

  // ========================= CLIENT SUBSCRIPTION ENDS ===========================


  // ========================= CUSTOMER ===========================
  static customerRegister = catchAsyncErrors(async (req, res, next) => {
    let { firstName, lastName, email, password, dialCode, phone, dob, gender, address, id } = req.body;

    if (!id) {
      if (!firstName || !lastName) {
        return res.status(422).json({
          status: false,
          message: "First name or Last name is required.",
          data: {},
        });
      }
      if (!email) {
        return res.status(422).json({
          status: false,
          message: "Email is required.",
          data: {},
        });
      }
      if (!password) {
        return res.status(422).json({
          status: false,
          message: "Password is required.",
          data: {},
        });
      }
      if (!phone) {
        return res.status(422).json({
          status: false,
          message: "Phone is required.",
          data: {},
        });
      }
    }

    let customerRole = await roleModel.findOne({
      where: {
        roleName: "Customer",
        deletedAt: null,
      }
    });
    let guestRole = await roleModel.findOne({
      where: {
        roleName: "Guest",
        deletedAt: null,
      }
    });

    // =========== single file upload ================
    let fileName = "";
    if (req.files.profileImage) {
      let image = await fileUploaderSingle(
        "src/public/uploads/userImages/",
        req.files.profileImage
      );
      fileName = image.newfileName;
    }
    // =========== single file upload ================

    let updateFields = {
      roleId: customerRole.id,
    };
    if (firstName) {
      updateFields.firstName = firstName;
    }
    if (lastName) {
      updateFields.lastName = lastName;
    }
    if (email) {
      updateFields.email = email;
    }
    if (dialCode) {
      updateFields.dialCode = dialCode;
    }
    if (phone) {
      updateFields.phone = phone;
    }
    if (password) {
      updateFields.password = await bcrypt.hash(password, 10);
    }
    if (dob) {
      updateFields.dob = dob;
    }
    if (gender) {
      updateFields.gender = gender;
    }
    if (address) {
      updateFields.address = address;
    }
    if (fileName != "") {
      updateFields.profileImage = fileName;
    }

    let condition = {
      deletedAt: null,
      roleId: customerRole.id,
    };
    if (id) {
      // during edit -> should not check self ===
      condition.id = `{
            [Op.ne]: id
        }`;
    }

    let checkCustomerExist = await userModel.findOne({
      attributes: ["firstName", "lastName"],
      where: {
        ...condition,
        [Op.or]: [{ phone: phone }, { email: email }],
      },
    });

    let checkGuestExist = await userModel.findOne({
      where: {
        roleId: guestRole.id,
        [Op.or]: [{ phone: phone }, { email: email }],
      },
    });

    if (checkCustomerExist) {
      return res.status(400).json({
        status: false,
        message: "Customer with this phone or email already registered..!!",
        data: checkCustomerExist,
      });
    } else {
      console.log("Not registered as a customer yet.");
    }

    let updated = {};
    updated =
      id && id != "" && id != null
        ? await super.updateById(userModel, id, updateFields)
        : (checkGuestExist && checkGuestExist?.id != "" && checkGuestExist?.id != null)
          ? await super.updateByCustomOptions(
            userModel,
            {
              id: checkGuestExist?.id
            },
            updateFields
          )
          : await super.create(res, userModel, updateFields);

    if (updated) {
      let userDetails = {};
      if (id && id != "" && id != null) {
        userDetails = await userModel.findOne({
          where: {
            id: id,
          }
        });
      } else {
        if (checkGuestExist && checkGuestExist?.id != "" && checkGuestExist?.id != null) {
          userDetails = await userModel.findOne({
            where: {
              id: checkGuestExist?.id
            }
          });
        } else {
          userDetails = await userModel.findOne({
            where: {
              id: updated.id
            }
          });
        }
      }

      return res.status(200).json({
        status: true,
        message: "Successful.",
        data: userDetails,
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Oops..!! Something wrong happened.",
        data: {},
      });
    }
  });

  static customerBookingHistory = catchAsyncErrors(async (req, res, next) => {
    let searchOptions = {
      where: {
        customerId: req.user.id,
        isActive: true,
        deletedAt: null,
      },
      order: [["createdAt", "DESC"]],
      include: [
        {
          model: slotsModel,
        },
        {
          model: vehicleTypesModel
        },
        {
          model: userModel,
          attributes: {
            exclude: [
              "password",
              "webLogin",
              "appLogin",
              "fcmToken",
              "OTP",
              "macAddress",
            ],
          },
        },
      ],
    };
    let bookingHistory = await super.getList(req, bookingRequestsModel, searchOptions);

    if (bookingHistory.length > 0) {
      return res.status(200).json({
        status: true,
        message: "Booking history found..!!",
        data: bookingHistory,
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "No booking history found..!!",
        data: [],
      });
    }
  });

  static requestToMarkReady = catchAsyncErrors(async (req, res, next) => {
    let { bookingRequestId } = req.body;

    let roleOfSuperAdmin = await super.getByCustomOptionsSingle(req, roleModel, {
      where: {
        roleName: "Super Admin",
      },
    });

    let superUser = await super.getByCustomOptionsSingle(req, userModel, {
      where: {
        roleId: roleOfSuperAdmin?.id,
      },
    });

    let bookingRequest = await super.getByCustomOptionsSingle(req, bookingRequestsModel, {
      where: {
        id: bookingRequestId,
      },
    });
    if (!bookingRequest) {
      return res.status(400).json({
        status: false,
        message: "No booking request found with this id.",
        data: {},
      });
    }

    if (
      (bookingRequest.bookingStatus == "Failed")
      || (bookingRequest.bookingStatus == "Checked Out")
      || (bookingRequest.bookingStatus == "Booked")
    ) {
      return res.status(422).json({
        status: false,
        message: "Can't process further. This booking request is either has not been checked in yet or already checked out or failed.",
        data: {},
      });
    }

    let conditions = {
      id: bookingRequestId,
      isCancelled: false,
    };
    let updateFields = {
      readyStatus: "Requested"
    };
    let bookingRequestUpdate = {};
    bookingRequestUpdate = await super.updateByCustomOptions(
      bookingRequestsModel,
      conditions,
      updateFields
    );

    if (bookingRequestUpdate) {
      let updatedBookingRequest = await super.getByCustomOptionsSingle(req, bookingRequestsModel, {
        where: {
          id: bookingRequestId,
        },
      });

      let checkSlot = await super.getByCustomOptionsSingle(req, slotsModel, {
        where: {
          id: updatedBookingRequest?.slotId,
        },
      });

      // ================================
      // ----- Handle Notifications -----
      // ================================
      // ----- send successful booking notification -----

      // ----- 1. to customer -----
      let notiDataForCustomer = {
        userId: updatedBookingRequest?.customerId ?? updatedBookingRequest?.customerId,
        bookingRequestId: bookingRequestId,

        notiTitle: `Request to make car ready is received..!!`,

        notiBody: `Roger that captain..!! We got your request..!! We will assign an agent and your car will be ready in a short while. Please keep this booking ticket: ${updatedBookingRequest?.bookingTicketNo} handy to make your check-out as hassle free as possible.`
      }
      let createNotificationForCustomer = await super.create(res, notificationModel, notiDataForCustomer);
      // ----- 1. to customer -----

      // ----- 2. to super admin -----
      let notiDataForSuperAdmin = {
        userId: superUser.id ?? superUser.id,
        bookingRequestId: bookingRequestId,

        notiTitle: `Ahoy..!! New Car Ready Request Arrived..!!`,

        notiBody: `Dear Admin, customer wih car plate no.: ${updatedBookingRequest?.plateNumber} has requested to mark car as ready. Parking slot no.: ${checkSlot?.slotName}; Slot location: [Bay-no.: ${checkSlot?.slotBayNumber}, Row-no.: ${checkSlot?.slotRowNumber}]. For more details, please refer to ticket: ${updatedBookingRequest?.bookingTicketNo}.`
      }
      let createNotificationForSuperAdmin = await super.create(res, notificationModel, notiDataForSuperAdmin);
      // ----- 2. to super admin -----

      // ----- send successful booking notification -----
      // ================================
      // ----- Handle Notifications -----
      // ================================

      return res.status(200).json({
        status: true,
        message: "Requested",
        data: updatedBookingRequest,
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Oopps..!! Something went wrong while requesting to mark ready..!! You can still go to the site and collect your car. Sorry for the inconvenience.",
        data: {},
      });
    }
  });

  static carReadyStatusChange = catchAsyncErrors(async (req, res, next) => {
    let { bookingRequestId, readyStatus } = req.body;

    let bookingRequest = await super.getByCustomOptionsSingle(req, bookingRequestsModel, {
      where: {
        id: bookingRequestId,
        isCancelled: false,
      },
    });

    if (!bookingRequest) {
      return res.status(400).json({
        status: false,
        message: "Ooppss..!! No booking request found.",
        data: {},
      });
    }

    if (bookingRequest.readyStatus == "Not Requested") {
      return res.status(400).json({
        status: false,
        message: "Client has not requested to mark ready yet.",
        data: {},
      });
    }

    let conditions = {
      id: bookingRequestId,
    };
    let updateFields = {
      readyStatus: readyStatus,
    };

    let bookingRequestUpdate = await super.updateByCustomOptions(
      bookingRequestsModel,
      conditions,
      updateFields
    );

    if (bookingRequestUpdate) {
      let bookingRequestDetail = await super.getByCustomOptionsSingle(req, bookingRequestsModel, {
        where: {
          id: bookingRequestId
        },
      });

      return res.status(200).json({
        status: true,
        message: "Status updated.",
        data: bookingRequestDetail,
      });

    } else {
      return res.status(400).json({
        status: false,
        message: "Problem updating status.",
        data: {}
      });
    }
  });
  // ========================= CUSTOMER ===========================


  static getSubscriptionDetails = catchAsyncErrors(async (req, res, next) => {
    let { uuid } = req.body;

    // user add happening ===
    if (!uuid) {
      return res.status(422).json({
        status: false,
        message: "Subscription id is required.",
        data: {},
      });
    }

    let subscriptionDetails = await userModel.findOne({
      //attributes: ["firstName", "lastName"],
      where: {
        uuid: uuid,
        deletedAt: null
      },
    });
    if (subscriptionDetails) {
      return res.status(200).json({
        status: true,
        message: "Successful.",
        data: subscriptionDetails,
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Oops.. Something wrong happened!",
        data: {},
      });
    }
  });
  static updateSubscription = catchAsyncErrors(async (req, res, next) => {
    let { uuid } = req.body;

    // user add happening ===
    if (!uuid) {
      return res.status(422).json({
        status: false,
        message: "Subscription id is required.",
        data: {},
      });
    }

    let subscriptionDetails = await userModel.findOne({
      //attributes: ["firstName", "lastName"],
      where: {
        uuid: uuid,
        deletedAt: null
      },
    });
    if (subscriptionDetails) {
      return res.status(200).json({
        status: true,
        message: "Successful.",
        data: subscriptionDetails,
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Oops.. Something wrong happened!",
        data: {},
      });
    }
  });
  static deleteSubscription = catchAsyncErrors(async (req, res, next) => {
    let { uuid } = req.body;

    // user add happening ===
    if (!uuid) {
      return res.status(422).json({
        status: false,
        message: "Subscription id is required.",
        data: {},
      });
    }

    let subscriptionDetails = await userModel.findOne({
      //attributes: ["firstName", "lastName"],
      where: {
        uuid: uuid,
        deletedAt: null
      },
    });
    if (subscriptionDetails) {
      return res.status(200).json({
        status: true,
        message: "Successful.",
        data: subscriptionDetails,
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Oops.. Something wrong happened!",
        data: {},
      });
    }
  });
  static getCountryList = catchAsyncErrors(async (req, res, next) => {
    let options = {
      attributes: [
        ["id", "value"],
        ["name", "label"],
        ["currency", "currency"]
      ],
      order: [["name", "asc"]],
    };
    let countries = await countryModel.findAll(options);
    if (countries) {
      return res.status(200).json({
        status: true,
        message: "Country found...",
        data: countries
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Country does not exist.",
        data: {},
      });
    }
  });

  static allUserClientList = catchAsyncErrors(async (req, res, next) => {
    const userId = req.params.id;
    const user = await clientModel.findOne({
      attributes: ['id', 'database_name'],
      where: { id: userId }
    });

    if (!user) {
      return res.status(404).json({ status: false, message: 'User not found' });
    }

    const db_name = user.database_name;
    if (!db_name) {
      return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
    }

    const connection = await connectSpecificToDatabase(
      db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
    );

    const allClientUsers = await connection.Client.findAll({
    });

    if (allClientUsers) {
      return res.status(200).json({
        status: true,
        message: "Client list found...",
        data: allClientUsers
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Clients does not exist.",
        data: {},
      });
    }
  });
  static exportData = catchAsyncErrors(async (req, res, next) => {
    let { type, searchText, advancedSearch } = req.body;
    // console.log(type);
    var data = null;
    switch (type) {
      case 'client-admin':
        let whereClause = {
          deletedAt: null,
        };
        if (searchText) {
          let searchId = searchText.toLowerCase().replace('usr-', '').replace(/^0+/, '');
          whereClause = {
            deletedAt: null,
            [Op.or]: [
              {
                id:
                {
                  [Op.like]: `%${searchId}%`
                }
              },
              {
                name:
                {
                  [Op.like]: `%${searchText}%`
                }
              },
              {
                email:
                {
                  [Op.like]: `%${searchText}%`
                }
              },
              {
                phone:
                {
                  [Op.like]: `%${searchText}%`
                }
              },
              {
                '$userCompany.companyName$':
                {
                  [Op.like]: `%${searchText}%`
                }
              },
              {
                '$userCompany.companyPhone$':
                {
                  [Op.like]: `%${searchText}%`
                }
              },
              {
                '$userCompany.companyEmail$':
                {
                  [Op.like]: `%${searchText}%`
                }
              },
              {
                '$userCompany.companyAddress$':
                {
                  [Op.like]: `%${searchText}%`
                }
              },
              {
                '$userCompany.companyWebsite$':
                {
                  [Op.like]: `%${searchText}%`
                }
              },
              {
                '$userCompany.companyInfo$':
                {
                  [Op.like]: `%${searchText}%`
                }
              }
            ]
          };
        }
        if (advancedSearch && Object.keys(advancedSearch).length) {
          whereClause = {
            deletedAt: null,
          };
          if (advancedSearch.userId) {
            let userId = advancedSearch.userId.toLowerCase().replace('usr-', '').replace(/^0+/, '');
            if (userId) {
              whereClause['id'] = {
                [Op.like]: `%${userId}%`
              }
            }
          }
          if (advancedSearch.userName) {
            whereClause['name'] = {
              [Op.like]: `%${advancedSearch.userName}%`
            }
          }
          if (advancedSearch.userEmail) {
            whereClause['email'] = {
              [Op.like]: `%${advancedSearch.userEmail}%`
            }
          }
          if (advancedSearch.userPhone) {
            whereClause['phone'] = {
              [Op.like]: `%${advancedSearch.userPhone}%`
            }
          }
          if (advancedSearch.dateRange && advancedSearch.dateRange.length) {
            whereClause['createdAt'] = {
              [Op.between]: [moment(advancedSearch.dateRange[0]).startOf('day'), moment(advancedSearch.dateRange[1]).endOf('day')]
            }
          }
          if (advancedSearch.companyName) {
            whereClause['$userCompany.companyName$'] = {
              [Op.like]: `%${advancedSearch.companyName}%`
            }
          }
          if (advancedSearch.companyPhone) {
            whereClause['$userCompany.companyPhone$'] = {
              [Op.like]: `%${advancedSearch.companyPhone}%`
            }
          }
          if (advancedSearch.companyEmail) {
            whereClause['$userCompany.companyEmail$'] = {
              [Op.like]: `%${advancedSearch.companyEmail}%`
            }
          }
          if (advancedSearch.companyAddress) {
            whereClause['$userCompany.companyAddress$'] = {
              [Op.like]: `%${advancedSearch.companyAddress}%`
            }
          }
          if (advancedSearch.companyWebsite) {
            whereClause['$userCompany.companyWebsite$'] = {
              [Op.like]: `%${advancedSearch.companyWebsite}%`
            }
          }
        }
        let options = {
          where: whereClause,
          order: [["createdAt", "DESC"]],
          attributes: {
            exclude: [
              "password",
              "webLogin",
              "appLogin",
              "fcmToken",
              "OTP",
              "macAddress",
            ],
          }
        };

        options.include = [
          {
            model: clientSubscriptionsModel,
            where: {
              deletedAt: null,
              isExpired: 0
            },
            required: false,
            include: [
              {
                model: plansModel,
              }
            ],
          },
        ];
        options.include = [
          {
            model: userCompanyModel,
            as: 'userCompany',
            where: {
              deletedAt: null,
            },
            required: false,
          },
        ];

        let clientList = await super.getList(req, clientModel, options);
        if (clientList && Array.isArray(clientList)) {
          data = clientList.map((value) => ({
            id: `USR-${value?.id.toString().padStart(4, '0')}`,
            name: value.name,
            email: value.email,
            phone: value.phone,
            profile_image: value.profileImage ? `${process.env.API_URL}uploads/user/${value.profileImage}` : ``,
            company_name: value.userCompany?.companyName,
            company_address: value.userCompany?.companyAddress,
            company_phone: value.userCompany?.companyPhone,
            company_email: value.userCompany?.companyEmail,
            company_website: value.userCompany?.companyWebsite,
            company_info: value.userCompany?.companyInfo,
            subscription_id: value.client_subscriptions?.length ? `SUBS-${value.client_subscriptions[0].id.toString().padStart(4, '0')}` : '',
            plan_name: value.client_subscriptions?.length ? value.client_subscriptions[0].plan.name : '',
            duration: value.client_subscriptions?.length ? value.client_subscriptions[0].duration : '',
            price: value.client_subscriptions?.length ? value.client_subscriptions[0].price : '',
            trial_period: value.client_subscriptions?.length ? (value.client_subscriptions[0].isTrial ? `${moment(value.client_subscriptions[0].trialStartDate).format('DD-MM-YYYY')} - ${moment(value.client_subscriptions[0].trialEndDate).format('DD-MM-YYYY')}` : `NA`) : '',
            start_date: value.client_subscriptions?.length ? moment(value.client_subscriptions[0].startDate).format('DD-MM-YYYY') : '',
            end_date: value.client_subscriptions?.length ? moment(value.client_subscriptions[0].endDate).format('DD-MM-YYYY') : '',
            next_billing_date: value.client_subscriptions?.length ? moment(value.client_subscriptions[0].nextBillingDate).format('DD-MM-YYYY') : '',
            payment_mode: value.client_subscriptions?.length ? value.client_subscriptions[0].paymentMode : '',
            payment_status: value.client_subscriptions?.length ? (value.client_subscriptions[0].isPaid ? 'Paid' : 'Unpaid') : '',
          }),);
        }
        // console.log(data);
        break;
      case 'newsletter-subscribers':
        let subscribersList = await super.getList(req, newsletterSubscriptionModel, {
          where: {
            deletedAt: null,
          },
          order: [["id", "ASC"]],
        });
        if (subscribersList && Array.isArray(subscribersList)) {
          data = subscribersList.map((value) => ({
            email: value.email,
            subscription_status: value.subscriptionStatus ? 'Yes' : 'No',
          }),);
        }
        break;
      case 'contact-enquiries':
        let enquiriesList = await super.getList(req, userEnquiryModel, {
          where: {
            deletedAt: null,
          },
          include: [
            {
              model: countryModel,
              attributes: ["name"],
            },
          ],
          order: [["id", "ASC"]],
        });
        if (enquiriesList && Array.isArray(enquiriesList)) {
          data = enquiriesList.map((value) => ({
            name: value.name,
            email: value.email,
            location: value.country?.name,
            company: value.companyName,
            message: value.message,
            date: moment(value.createdAt).format('DD-MM-YYYY hh:mm A'),
          }),);
        }
        break;
    }
    if (data) {
      const workbook = XLSX.utils.book_new();
      const worksheet = XLSX.utils.json_to_sheet(data);
      XLSX.utils.book_append_sheet(workbook, worksheet, 'Sheet1');
      const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
      const blob = new Blob([excelBuffer], { type: 'application/octet-stream' });

      res.setHeader('Content-Type', 'application/octet-stream');
      res.setHeader('Content-Disposition', 'attachment; filename="export-data.xlsx"');
      res.send(Buffer.from(excelBuffer));
      // return res.status(200).json({
      //   status: true,
      //   message: "Successful.",
      //   data: data,
      // });
    } else {
      return res.status(400).json({
        status: false,
        message: "Oops.. Something went wrong!",
        data: {},
      });
    }
  });

}

module.exports = UserController;
