const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const db = require("../models");
const sendMail = require("../helpers/email");
let pdf = require('html-pdf');
const fs = require('fs');
const path = require('path');
const { error } = require("console");
const crypto = require('crypto');
const bcrypt = require("bcryptjs");
const clientModel = db.Clients;

class sendMailController extends BaseController {
    constructor() {
        super();
    }

//send mail
static sendMail = catchAsyncErrors(async (req, res) => {
    const {
        to,
        cc,
        bcc,
        invoiceNumber,
        name,
        subject = "Invoice from RaiseInvoice",
        notes = "",
        html,
        content,
        filename,
        attachments = []
    } = req.body;

    try {
        let mailAttachments = [];

        // Generate PDF from HTML and attach if provided
        if (html) {
            const options = {
                format: 'Letter',
                childProcessOptions: { env: { OPENSSL_CONF: '/dev/null' } }
            };
            const fileName = `${name || 'invoice'}-${invoiceNumber || Date.now()}.pdf`;
            const pdfPath = path.join(__dirname, '../public/attachments', fileName);

            await new Promise((resolve, reject) => {
                pdf.create(html, options).toFile(pdfPath, (err) => {
                    if (err) return reject(err);
                    resolve();
                });
            });

            mailAttachments.push({ filename: fileName, path: pdfPath });
        }

        // Decode and save the file temporarily
        if(filename && content){
            try {
                const buffer = Buffer.from(content, 'base64');
                const uploadDir = path.join(__dirname, '../public/uploads');
                if (!fs.existsSync(uploadDir)) {
                    fs.mkdirSync(uploadDir, { recursive: true });
                }
                const filePath = path.join(uploadDir, filename);
                fs.writeFileSync(filePath, buffer);
                mailAttachments.push({
                    filename: filename,
                    path: filePath,
                });
                
            } catch (error) {
                console.log("Error processing attachment:", error);
            }
        }

        // Normalize and process attachments (base64 images)
        let filteredAttachments = [];
        if (Array.isArray(attachments)) {
            filteredAttachments = attachments.filter(att => typeof att === 'string' && att.trim());
        } else if (typeof attachments === 'string') {
            filteredAttachments = attachments.split(',').map(att => att.trim()).filter(Boolean);
        } else if (attachments && typeof attachments === 'object') {
            filteredAttachments = Object.values(attachments).filter(att => typeof att === 'string' && att.trim());
        }

        if (filteredAttachments.length > 0) {
            mailAttachments = mailAttachments.concat(
                filteredAttachments.map(att => {
                    const base64Data = att.replace(/^data:.*;base64,/, '');
                    const match = att.match(/^data:(image\/[a-zA-Z0-9+.-]+);base64,/);
                    const ext = match && match[1] ? match[1].split('/')[1] : 'png';
                    return {
                        filename: `attachment.${ext}`,
                        content: base64Data,
                        encoding: 'base64'
                    };
                }).filter(att => att.content && att.content !== 'data:image/png;base64')
            );
        }

        await sendMail(
            to,
            cc,
            bcc,
            subject,
            null,
            notes,
            mailAttachments.length ? mailAttachments : false
        );

        return res.status(200).json({ status: true, message: "Email sent successfully" });
    } catch (error) {
        console.error("Error sending email:", error);
        return res.status(500).json({ status: false, message: "Email not sent successfully" });
    }
});

static resetPasswordMail = catchAsyncErrors(async (req, res) => {
    const { to, subject = "Reset Your Password", link } = req.body;
    if (!to) {
        return res.status(200).json({ error: "Please enter email" });
    }
    const user = await clientModel.findOne({ where: { email: to } });
    if (!user) {
      return res.status(200).json({ error: 'Client not found' });
    }

    try {
    // Generate a secure 4-digit OTP using crypto
    const otpcode = crypto.randomInt(1000, 10000);
    await super.updateById(clientModel, user.id, 
        { OTP: otpcode,
            expiresAt: new Date(Date.now() + 3600000), // 1 hour from now
            used: false
        });

    const name = user.name || '';
    const resetLink = `${link}?token=${otpcode}`;
    const body = `Hi ${name},<br><br>
        We received a request to reset the password for your account associated with this email address.<br><br>
        To reset your password, please click the link below:<br><br>
        👉 <a href="${resetLink}">Reset Password</a><br><br>
        This link will expire in 1 hour for your security. If you didn’t request a password reset, you can safely ignore this email—no changes will be made to your account.<br><br>
        If you have any questions or need further assistance, feel free to contact our support team.<br><br>
        Thanks,<br>
        Raise Invoice<br>
        Customer Support Team
    `;
    await sendMail(to, null, null, subject, null, body, false);

    return res.status(200).json({ status: true, message: "Email sent successfully" });

    } catch (error) {
         return res.status(500).json({ status: false, message: "Email not sent successfully" }); 
    }
});

static clientResetPassword = catchAsyncErrors(async (req, res, next) => {
    const { otp, password, confirm_password } = req.body;

    const user = await clientModel.findOne({
        attributes: ['id', 'uuid', 'name', 'password', 'isVerified', 'database_name', 'OTP', 'used', 'expiresAt'],
        where: { OTP: otp }
    });

    if (!user) {
        return res.status(200).json({
            status: false,
            message: "Client Not found!",
            data: null,
        });
    }

    // Check if Link is already used
    if (user.used === true) {
        return res.status(200).json({
            status: false,
            message: "This password reset link has already been used. Please request a new one.",
            data: null,
        });
    }

    // Check if Link is expired
    if (user.expiresAt && user.expiresAt < Date.now()) {
        return res.status(200).json({
            status: false,
            message: "This password reset link has expired. Please request a new one.",
            data: null,
        });
    }

    if(password && confirm_password){
        // Check if passwords match
        if (password !== confirm_password) {
            return res.status(200).json({
                status: false,
                message: "Passwords do not match.",
                data: null,
            });
        }

        let updateFields = {
            password: await bcrypt.hash(password, 10),
            used: true
        };

        await super.updateById(clientModel, user.id, updateFields);

        return res.status(200).json({
            status: true,
            message: "Password reset successfully.",
            data: { user },
        });
    } else {
        return res.status(200).json({
            status: true,
            message: "Please provide password and confirm_password.",
            data: null,
        });
    }

});

}

module.exports = sendMailController;