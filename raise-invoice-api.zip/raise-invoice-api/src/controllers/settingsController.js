const axios = require("axios");
const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/errorHandler");
const RequestHandler = require("../utils/RequestHandler");
const fileUploaderSingle = require("../utils/fileUpload").fileUploaderSingle;
const bcrypt = require("bcryptjs");
const JWTAuth = require("../utils/jwtToken");
const jwt = require("jsonwebtoken");
const jwtConfig = require("../config").JWT;
const { Op } = require("sequelize");
const crypto = require("crypto");
const moment = require('moment-timezone');

const mailer = require("nodemailer");

const {
  createDatabase
} = require("../utils/utilities");
const {
  MSG_RECORD_STATUS_SUCCESS,
  MSG_RECORD_FETCH_SUCCESS,
} = require("../config/constants");
const requestHandler = new RequestHandler();

const db = require("../models");
const { random } = require("lodash");
const vendorModel = db.Vendors;
const userModel = db.Users;
const clientModel = db.Clients;
const roleModel = db.Roles;
const usersrolesModel = db.UsersRoles;
const modulePermissionsModel = db.ModulePermissions;
const bookingRequestsModel = db.BookingRequests;
const slotsModel = db.Slots;
const vehicleTypesModel = db.VehicleTypes;
const notificationModel = db.Notifications;
const countryModel = db.Countries;
const userLocationModel = db.UserLocations;
const userCompanyModel = db.UserCompanies;
const permissionModel = db.Permissions;
const clientSubscriptionsModel = db.ClientSubscriptions;
const paymentGatewayModel = db.PaymentGateways;
const paymentGatewayFieldsModel = db.PaymentGatewayFields;

class SettingsController extends BaseController {
  constructor() {
    super();
  }

  // ========================= PAYMENT GATEWAY SETTING STARTS ===========================

  static importPaymentGateway = catchAsyncErrors(async (req, res, next) => {
    let {
      paymentGateways,
    } = req.body;
    try {
      if(paymentGateways && paymentGateways.length){
        paymentGateways.forEach(async (val, i) => {
          var paymentGatewayData = await super.getByCustomOptionsSingle(req, paymentGatewayModel, {
            where: {
              name: val.name,
            }
          });
          let updateFields = {
            name: val.name,
            fields: JSON.stringify(val.fields),
          };
          let paymentGatewayUpdate = null;
          if(paymentGatewayData && paymentGatewayData != "" && paymentGatewayData != null && paymentGatewayData != 'null'){
            paymentGatewayUpdate = await super.updateById(paymentGatewayModel, paymentGatewayData.id, updateFields);
          }else{
            updateFields.uuid = crypto.randomUUID();
            paymentGatewayUpdate = await super.create(res, paymentGatewayModel, updateFields);
          }
          if (paymentGatewayUpdate) {
            console.log("Payment gateway created/updated.");
          } else {
            console.log("Payment gateway not affected.");
          }
          if(i == (paymentGateways.length - 1)){
            let options = {
              where: {
                deletedAt: null,
              },
              order: [["createdAt", "ASC"]],
            }; 
            var paymentGatewayList = await super.getList(req, paymentGatewayModel, options);
            if(paymentGatewayList){
              return res.status(200).json({
                status: true,
                message: "Payment gateway successfully imported.",
                data: paymentGatewayList,
              });
            } else {
              return res.status(400).json({
                status: false,
                message: "Oops.. Something wrong happened!",
                data: {},
              });
            }
          }
        });      
      } else {
        return res.status(200).json({
          status: false,
          message: "No payment gateways are available!",
          data: {},
        });
      }
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  static getPaymentGatewayList = catchAsyncErrors(async (req, res, next) => {
    let { searchText } = req.body;

    let whereClause = {
      deletedAt: null,
    };
    if (searchText) {
      let searchId = searchText.toLowerCase().replace('pmgt-', '').replace(/^0+/, '');
      whereClause = {
        deletedAt: null,
        [Op.or]: [
          {
            id:
            {
              [Op.like]: `%${searchId}%`
            }
          },
          {
            name:
            {
              [Op.like]: `%${searchText}%`
            }
          }
        ]
      };
    }
    let options = {
      where: whereClause,
      order: [["createdAt", "ASC"]],
    };
    var paymentGatewayList = await super.getList(req, paymentGatewayModel, options);
    if (paymentGatewayList) {
      return res.status(200).json({
        status: true,
        message: "Successful.",
        data: paymentGatewayList,
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Oops.. Something wrong happened!",
        data: {},
      });
    }
  });
  static getPaymentGatewayDetails = catchAsyncErrors(async (req, res, next) => {
    let { id, uuid } = req.body;

    let whereClause = {};
    if (id) {
      whereClause = { id: id }
    }
    if (uuid) {
      whereClause = { uuid: uuid }
    }

    let options = {
      where: whereClause,
    };
    
    let paymentGatewayDetails = await super.getByCustomOptionsSingle(req, paymentGatewayModel, options);

    if (paymentGatewayDetails) {
      return res.status(200).json({
        status: true,
        message: "Details found.",
        data: paymentGatewayDetails
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No details found.",
        data: {}
      });
    }
  });
  static savePaymentGateway = catchAsyncErrors(async (req, res, next) => {
    let {
      id,
      name,
      fields,
      paymentMode, 
      isActive,
    } = req.body;

    let updateFields = {};
    if(name){
      updateFields.name = name;
    }
    if(fields){
      updateFields.fields = fields;
    }
    if(paymentMode){
      updateFields.paymentMode = paymentMode;
    }
    updateFields.isActive = isActive;
    console.log(updateFields)
    let updated = null;
    if (id && id != "" && id != null && id != 'null') {
      updated = await super.updateById(paymentGatewayModel, id, updateFields);
    } else {
      updateFields.uuid = crypto.randomUUID();
      updated = await super.create(res, paymentGatewayModel, updateFields);
    }
    if (updated) {
      let options = {
        where: {
          deletedAt: null,
        },
        order: [["createdAt", "ASC"]],
      };
      var paymentGatewayList = await super.getList(req, paymentGatewayModel, options);
      return res.status(200).json({
        status: true,
        message: "Payment gateway successfully saved",
        data: paymentGatewayList,
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Oops.. Something wrong happened!",
        data: {},
      });
    }
  });
  static getPaymentGatewayFieldValues = catchAsyncErrors(async (req, res, next) => {
    let { paymentGatewayId } = req.body;
    if (!paymentGatewayId) {
      return res.status(422).json({
        status: false,
        message: "Payment gateway is required.",
        data: {},
      });
    }
    let whereClause = {
      paymentGatewayId: paymentGatewayId,
      deletedAt: null,
    };
    let options = {
      where: whereClause,
      order: [["createdAt", "ASC"]],
    };
    var paymentGatewayFieldList = await super.getList(req, paymentGatewayFieldsModel, options);
    if (paymentGatewayFieldList) {
      return res.status(200).json({
        status: true,
        message: "Successful.",
        data: paymentGatewayFieldList,
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Oops.. Something wrong happened!",
        data: {},
      });
    }
  });
  static savePaymentGatewayFields = catchAsyncErrors(async (req, res, next) => {
    let {
      paymentGatewayId,
      formData,
      isActive,
    } = req.body;

    let _updateById = super.updateById;
    let _create = super.create;   
    let _getByCustomOptionsSingle = super.getByCustomOptionsSingle;   
    if (!formData) {
      return res.status(422).json({
        status: false,
        message: "Payment gateway field values are required.",
        data: {},
      });
    }
    
    var updatedIds = [];
    for (const [key, value] of Object.entries(formData)) {
      let updateFields = {};
      updateFields.paymentGatewayId = paymentGatewayId;
      updateFields.fieldKey = key;
      updateFields.fieldValue = value;
      updateFields.isActive = isActive;

      var isExists = await _getByCustomOptionsSingle(req, paymentGatewayFieldsModel, {
        where: {
          paymentGatewayId: paymentGatewayId,
          fieldKey: key,
        }
      });
      
      if (isExists && isExists != "" && isExists != null && isExists != 'null') {
        await _updateById(paymentGatewayFieldsModel, isExists.id, updateFields);
      } else {
        isExists = await _create(res, paymentGatewayFieldsModel, updateFields);
      }
      updatedIds.push(isExists.id);
    }
    // console.log(updatedIds?.length, Object.keys(formData).length)
    if (updatedIds.length == Object.keys(formData).length) {
      return res.status(200).json({
        status: true,
        message: "Credentials successfully saved",
        data: {},
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Oops.. Something went wrong!",
        data: {},
      });
    }
  });

  // ========================= PAYMENT GATEWAY SETTING ENDS ===========================

  static testMail = ((req, res, next) => {
    // var smtpTransport = mailer.createTransport({
		// 	host:"smtp.gmail.com",
		//   domain:'gmail.com',
		// 	port:587,
		// 	secure: false, // true for 465, false for other ports
		// 	logger: true,
		// 	debug: true,
		// 	secureConnection: false,
		// 	auth: { user: 'booking.primepark@gmail.com', pass: 'wyjxuq-vItnoc-6vocri' },
    //   // authentication:'plain',
		// 	tls:{
		// 		rejectUnAuthorized:true
		// 	}
		// });
    var smtpTransport = mailer.createTransport({
			service: 'gmail',
      auth: { user: 'booking.primepark@gmail.com', pass: 'nygxmeibhurwvekn' }
		});
		var mailContent = {
			from: {
				name: "Suraj Samanta",
				address: "booking.primepark@gmail.com",
			},
			to: 'suraj.samanta@gmail.com',
			subject: 'Test mail',
			text: 'Test mail content',
		};
		smtpTransport.sendMail(mailContent, function (error, response) {
			if (error) {
				console.log(error);
				return res.status(200).json({
					status: false,
					message: "Mail Not Sent.",
					data: error
				});
			} else {
				console.log(response.response);
				console.log("---------- Mail sent. ----------");
				return res.status(200).json({
					status: true,
					message: "Mail Sent.",
					data: response.response
				});
			}
		});
	});

}

module.exports = SettingsController;
