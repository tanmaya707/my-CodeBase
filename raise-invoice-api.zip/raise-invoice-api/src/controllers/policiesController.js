const axios = require("axios");
const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/errorHandler");
const RequestHandler = require("../utils/RequestHandler");
const bcrypt = require("bcryptjs");
const JWTAuth = require("../utils/jwtToken");
const jwt = require("jsonwebtoken");
const jwtConfig = require("../config").JWT;
const { Op } = require("sequelize");

const {
  calculateDistance,
  calculateDistanceInsTentApi,
  calculateTimeInKilometers,
  getRateChartCategory,
} = require("../utils/utilities");
const {
  MSG_RECORD_STATUS_SUCCESS,
  MSG_RECORD_FETCH_SUCCESS,
} = require("../config/constants");
const requestHandler = new RequestHandler();

const db = require("../models");
const policiesModel = db.Policies;

class PoliciesController extends BaseController {
  constructor() {
    super();
  }

  static policiesAddUpdate = catchAsyncErrors(async (req, res, next) => {
    let { policies } = req.body;

    let checkExist = await policiesModel.findOne({
        where: {
            policies: {
                [Op.ne]: null 
            }
        }
    });
    
    let conditions = {};
    if(checkExist){
        conditions = {
            id: checkExist.id
        };
    }
    let updateFields = {
        policies: policies
    };

    let updated = checkExist && checkExist != '' && checkExist != null
        ? await super.updateByCustomOptions(policiesModel, conditions, updateFields)
        : await super.create(res, policiesModel, updateFields);

    if(updated){
        return res.status(200).json({
            status: true,
            message: "Success.",
            data: updated
        });
    } else {
        return res.status(400).json({
            status: false,
            message: "Something wrong happened.",
            data: {}
        });
    }
  });

  static getPolicies = catchAsyncErrors(async (req, res, next) => {
    let policies = await policiesModel.findOne({
        where: {
            deletedAt: null,
            policies: {
                [Op.ne]: null 
            },
        },
    });

    if(policies){
        return res.status(200).json({
            status: true,
            message: "Success.",
            data: policies,
        });
    } else {
        return res.status(200).json({
            status: false,
            message: "No data found.",
            data: {},
        });
    }
  });

}

module.exports = PoliciesController;
