const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");

const db = require("../models");
const currencyModel = db.Currency;
const planModel = db.Plans;
const planPriceModel = db.PlanPrices;
const exchangeRateModel = db.ExchangeRate;
const freatuecategoriesModel = db.Categories;
const featuresModel = db.Features;
const planFeaturesModel = db.PlanFeatures;
const { Sequelize, Op } = require("sequelize");
const crypto = require("crypto");
const { slugify } = require("../utils/utilities");

class pricingPlanController extends BaseController {
  constructor() {
    super();
  }

  // static getCurrencyList = catchAsyncErrors(async (req, res, next) => {
  //   let options = {
  //     attributes: [["id", "value"], [
  //       Sequelize.fn('CONCAT',
  //         Sequelize.col('currency'), ' - ',
  //         Sequelize.col('name')
  //       ),
  //       'label'
  //     ]],
  //     where: {
  //       status: true,
  //       deletedAt: null,
  //       // currency: {
  //       //   [Op.ne]: null
  //       // }
  //     },
  //     order: [["currency", "ASC"]],
  //   };

  //   // let currencyLists = await super.getList(req, countriesModel, options);
  //   let currencyLists = await countriesModel.findAll(options);

  //   if (currencyLists.length > 0) {
  //     return res.status(200).json({
  //       status: true,
  //       message: "Data found.",
  //       data: currencyLists,
  //     });
  //   } else {
  //     return res.status(200).json({
  //       status: false,
  //       message: "No data found.",
  //       data: [],
  //     });
  //   }
  // });
  static getPlanList = catchAsyncErrors(async (req, res, next) => {
    let { searchText, defaultCurrencyId, status } = req.body;
    let whereClause = {
      deletedAt: null,
    };
    if(status){
      whereClause.status = status;
    }
    if (searchText) {
      whereClause[Op.or] = [
        {
          id:
          {
            [Op.like]: `%${searchText}%`
          }
        },
        {
          name:
          {
            [Op.like]: `%${searchText}%`
          }
        },
        {
          slug:
          {
            [Op.like]: `%${searchText}%`
          }
        },
        {
          short_description:
          {
            [Op.like]: `%${searchText}%`
          }
        },
        {
          description:
          {
            [Op.like]: `%${searchText}%`
          }
        }
      ];
    }
    let pricdeWhereClause = {
      deletedAt: null,
      status: true,
    };
    if(defaultCurrencyId){
      pricdeWhereClause.currency_id = defaultCurrencyId;
    }
    let options = {
      where: whereClause,
      include: [
        {
          model: planPriceModel,
          attributes: ["name", "price", "discount"],
          where: pricdeWhereClause
        },
      ],
      // include: [
      //   {
      //     model: featuresModel, 
      //     where: {
      //       deletedAt: null,
      //       status: true,
      //     },
      //     required:false
      //   },
      // ],
      order: [["order", "ASC"]],
    };

    console.log(options);

    let planLists = await super.getList(req, planModel, options);
    // let planLists = await planModel.findAll(options);
    if (planLists.length > 0) {
      return res.status(200).json({
        status: true,
        message: "Data found.",
        data: planLists,
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No data found.",
        data: [],
      });
    }
  });
  static getPlans = catchAsyncErrors(async (req, res, next) => {
      let options = {
        attributes: [["id", "value"], ["name", "label"]],
        where: {
          status: true,
          deletedAt: null,
        },
        order: [["order", "ASC"]],
      };
  
      let planList = await planModel.findAll(options);
  
      if (planList.length > 0) {
        return res.status(200).json({
          status: true,
          message: "Data found.",
          data: planList,
        });
      } else {
        return res.status(200).json({
          status: false,
          message: "No data found.",
          data: [],
        });
      }
  });
  static savePlan = catchAsyncErrors(async (req, res, next) => {
    let { id, name, short_description, description, isRecommended, currency_code, prices, isTrialAvailable, trialDuration, order, priceInterval, status } = req.body;
    
    if (!name) {
      return res.status(422).json({
        status: false,
        message: "Plan name is required.",
        data: {},
      });
    }
    if (!short_description) {
      return res.status(422).json({
        status: false,
        message: "Short description is required.",
        data: {},
      });
    }
    if (!description) {
      return res.status(422).json({
        status: false,
        message: "Description is required.",
        data: {},
      });
    }
    if (!currency_code) {
      return res.status(422).json({
        status: false,
        message: "Currency is required.",
        data: {},
      });
    }
    if (!order) {      
      return res.status(422).json({
        status: false,
        message: "Order is required.",
        data: {},
      });
    }
    // console.log(prices);
    if (!prices?.yearly?.price) {
      return res.status(422).json({
        status: false,
        message: "Yearly price is required.",
        data: {},
      });
    }
    if (!prices?.monthly?.price) {
      return res.status(422).json({
        status: false,
        message: "Monthly price is required.",
        data: {},
      });
    }
    let condition = {
      deletedAt: null,
      name: name
    };
    if (id) {
      // during edit -> should not check self ===
      condition.id = `{
            [Op.ne]: id
        }`;
    }

    let checkExist = await planModel.findOne({
      attributes: ["name"],
      where: {
        ...condition,
      },
    });

    if (checkExist) {
      return res.status(400).json({
        status: false,
        message: "Plan with this same name already exist!",
        data: checkExist,
      });
    }
    let currencyDetails = await super.getByCustomOptionsSingle(req, currencyModel, {
      where: {currency_code: currency_code},
    });
    let updateFields = {
      name: name,
      slug: slugify(name),
      short_description: short_description,
      description: description,
      is_recommended: isRecommended,
      is_trial_available: isTrialAvailable,
      trial_duration: trialDuration,
      order: order,
      default_currency: currencyDetails?.id,
      status: status
    };
    let updated = null;
    let message = '';
    if (id && id != "" && id != null && id != 'null') {
      updated = await super.updateById(planModel, id, updateFields)
      if (updated) {
        message = "Plan updated successfully.";
      } else {
        message = "Plan updation failed.";
      }
    } else {
      updateFields.uuid = crypto.randomUUID();
      updated = await super.create(res, planModel, updateFields);
      if (updated) {
        message = "Plan added successfully.";
      } else {
        message = "Plan addition failed.";
      }
    }

    if (updated) {      
      let planId = (id && id != "" && id != null && id != 'null') ? id : updated.id;
      let planDetails = await planModel.findOne({
        where: {
          id: planId,
        }
      });

      if(!id || id == "" || id == null || id == 'null'){
        // ====== plan features START ======
        const queryConditions = {
          where: {
            deletedAt: null,
            status: true,
          }, 
        };
        let features = await featuresModel.findAll(queryConditions);
        var planFeatures = [];
        for (var key in features) {
          planFeatures.push({
            plan_id: planId,
            feature_id: features[key].id,
            value: (features[key].type != 'text') ? 0 : ''
          });
        }
        let created = await planFeaturesModel.bulkCreate(planFeatures, {returning: true});
        // console.log(created);
        // ====== plan features END ======
    
      }
      
      // ====== plan pricing START ======
      if(priceInterval && priceInterval.length){
        let options = {
          where: {
            status: 1
          },
          include: [
            {
              model: exchangeRateModel, 
              required:false
            },
          ],
          order: [['currency_name', 'ASC']],
        };
        let currencyList = await super.getList(req, currencyModel, options);
        if (currencyList.length > 0) {
          // let planPrices = [];
          for (var k in currencyList) {          
            for (var key in prices) {
              if(priceInterval.includes(key)){
                var priceData = prices[key];
                let priceval = (priceData.price != '') ? priceData.price : 0;
                let discountval = (priceData.discount != '') ? priceData.discount : 0;
                let interval = 0;
                switch(key){
                  case 'yearly': 
                    interval = 12; 
                    break;
                  case 'monthly':
                    interval = 1;
                    break;
                }
                if(currencyList[k].id != currencyDetails?.id){
                  let exchangeRateData = currencyList[k].exchange_rates.find((rate) => rate.currency_from === currencyDetails?.id && rate.currency_to === currencyList[k].id);
                  let exchangeRate = exchangeRateData ? exchangeRateData.exchange_rate : 0;
                  priceval = priceval * exchangeRate;
                }

                //console.log('priceData', priceData);
                let planPriceData = {
                  plan_id: planId,
                  currency_id: currencyList[k].id,
                  name: key,
                  interval: interval,
                  price: Number(priceval).toFixed(2),
                  discount: discountval,
                };
                // planPrices.push(planPriceData);
                let cond = {
                  plan_id: planId,
                  currency_id: currencyList[k].id,
                  name: key,
                };
                updated = await super.upsert(planPriceModel, planPriceData, cond);
              }
            }
          }
          // updated = await planPriceModel.bulkCreate(planPrices, {returning: true});
        }
      }else{
        if(prices){
          for (var key in prices) {
            var priceData = prices[key];
            let priceval = (priceData.price != '') ? priceData.price : 0;
            let discountval = (priceData.discount != '') ? priceData.discount : 0;
            let interval = 0;
            switch(key){
              case 'yearly': 
                interval = 12; 
                break;
              case 'monthly':
                interval = 1;
                break;
            }
            let planPriceData = {
              plan_id: planId,
              currency_id: currencyDetails?.id,
              name: key,
              interval: interval,
              price: Number(priceval).toFixed(2),
              discount: discountval,
            };
            let condition = {
              plan_id: planId,
              currency_id: currencyDetails?.id,
              name: key,
            };
            updated = await super.updateByCustomOptions(planPriceModel, condition, planPriceData);
          }
        }
      }
      // ====== plan pricing END ======

      return res.status(200).json({
        status: true,
        message: message,
        data: planDetails,
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Oops.. Something wrong happened!",
        data: {},
      });
    }
  });
  static savePlanPrices = catchAsyncErrors(async (req, res, next) => {
    let { planPrices } = req.body;
    
    if (!planPrices) {
      return res.status(422).json({
        status: false,
        message: "Plan prices are required.",
        data: {},
      });
    }

    var i = 0;
    let updated = null;
    for (var key in planPrices) {
      updated = await super.updateByCustomOptions(
        planPriceModel, 
        {
          id: planPrices[key].yearly.id
        }, 
        {
          price: planPrices[key].yearly.price,
          discount: planPrices[key].yearly.discount,
        }
      );
      if(updated){
        i++;
      }
      updated = await super.updateByCustomOptions(
        planPriceModel, 
        {
          id: planPrices[key].monthly.id
        }, 
        {
          price: planPrices[key].monthly.price,
          discount: planPrices[key].monthly.discount,
        }
      );
      if(updated){
        i++;
      }
    } 
    // console.log(planPrices.length, i)      
    if(planPrices.length * 2 == i){
      return res.status(200).json({
        status: true,
        message: "Plan prices are updated successfully.",
      });
    }else{
      return res.status(500).json({
        status: false,
        message: "Oops.. something went wrong!",
        data: {}
      });
    }
  });
  static getFeaturesCategories = catchAsyncErrors(async (req, res, next) => {
    let { plan_id } = req.body;
    let featuresCategories = [];
    let whereClause = {
      deletedAt: null,
      status: true,
      type: 'plan-features',
    };
    let planFeatureIncludeObj = {
      model: planFeaturesModel,
      attributes: ["id", "plan_id", "value"],
      required: false,
    };
    if(plan_id){
      planFeatureIncludeObj.where = {
        plan_id: plan_id
      }
    }
    const queryConditions = {
      where: whereClause,
      include: [
        {
          model: featuresModel,
          attributes: ["id", "uuid", "name", "slug", "type"], 
          include: [
            planFeatureIncludeObj,
          ],
          required: false,
          // as: 'features'
        },
      ],
      // order: [[Sequelize.literal('`features->plans`.`order`'), 'ASC']]
    };

    featuresCategories = await freatuecategoriesModel.findAll(queryConditions);
    // console.log(featuresCategories);
    if(featuresCategories){
      return res.status(200).json({
        status: true,
        message: "Success",
        data: featuresCategories
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No records found.",
        data: {}
      });
    }
  });
  static getPlanFeaturesCategories = catchAsyncErrors(async (req, res, next) => {
    let featuresCategories = [];
    let whereClause = {
      deletedAt: null,
      status: true,
      type: 'plan-features',
    };
    const queryConditions = {
      where: whereClause,
      include: [
        {
          model: featuresModel,
          attributes: ["id", "uuid", "name", "slug", "type"],
          include: [
            {
              model: planModel,
              attributes: ["id", "uuid", "name", "slug"],
              where: {
                status: 1
              }
            },
          ],
        },
      ],
      order: [[Sequelize.literal('`features->plans`.`order`'), 'ASC']],
      required: false,
    };

    featuresCategories = await freatuecategoriesModel.findAll(queryConditions);

    if (featuresCategories) {
      return res.status(200).json({
        status: true,
        message: "Success",
        data: featuresCategories
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No records found.",
        data: {}
      });
    }
  });
  static getPlanDetails = catchAsyncErrors(async (req, res, next) => {
    const { id, uuid } = req.body;
    let queryConditions = {
      deletedAt: null,
      // status: true,
    };

    if (id) {
      queryConditions.id = id
    }
    if (uuid) {
      queryConditions.uuid = uuid
    }

    let planDetails = await super.getByCustomOptionsSingle(req, planModel, {
      where: queryConditions,
      include: [
        {
          model: planPriceModel,
          attributes: ["id", "name", "price", "discount", "currency_id"],
          where: {
            deletedAt: null,
            status: true,
          },
          required: false,
        },
        {
          model: currencyModel,
          attributes: ["id", "currency_name", "currency_code", "symbol"],
          where: {
            deletedAt: null,
            status: true,
          },
          required: false,
        },
      ],
    });

    if (planDetails) {
      return res.status(200).json({
        status: true,
        message: "Success",
        data: planDetails
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No records found.",
        data: {}
      });
    }
  });
  static getPlanFeatures = catchAsyncErrors(async (req, res, next) => {
    const { planId } = req.body;
    let planFeatures = [];
    if (!planId) {
      return res.status(422).json({
        status: false,
        message: "Plan id is required.",
        data: {},
      });
    }
    planFeatures = await planFeaturesModel.findAll({
      attributes: ["plan_id", "feature_id", "value"],
      where: {
        plan_id: planId
      }
    });

    if (planFeatures) {
      return res.status(200).json({
        status: true,
        message: "Success",
        data: planFeatures
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No records found.",
        data: {}
      });
    }
  });
  static savePlanFeatures = catchAsyncErrors(async (req, res, next) => {
    const { planFeatures } = req.body;
    // await super.deleteByCondition(
    //   planFeaturesModel, 
    //   {
    //     plan_id: planId,
    //   }
    // );
    
    let created = await planFeaturesModel.bulkCreate(planFeatures, {returning: true});
    
    if(created){
      return res.status(200).json({
        status: true,
        message: "Plan features are added successfully.",
      });
    }else{
      return res.status(500).json({
        status: false,
        message: "Oops.. something went wrong!",
        data: {}
      });
    }  
  });
  static updatePlanFeatures = catchAsyncErrors(async (req, res, next) => {
    const { planId, planFeatures } = req.body;
    var i = 0;
    for (var key in planFeatures) {
      let updated = await super.updateByCustomOptions(planFeaturesModel, {plan_id: planId, feature_id: planFeatures[key].feature_id}, planFeatures[key]);
      if(updated){
        i++;
      }
    } 
    // console.log(planFeatures.length, i)      
    if(planFeatures.length == i){
      return res.status(200).json({
        status: true,
        message: "Plan features are updated successfully.",
      });
    }else{
      return res.status(500).json({
        status: false,
        message: "Oops.. something went wrong!",
        data: {}
      });
    }  
  });
  static deletePlan = catchAsyncErrors(async (req, res, next) => {
    let { uuid } = req.body;

    let planDetail = await super.getByCustomOptionsSingle(req, planModel, {
      where: {
        uuid: uuid
      },
      attributes: ["id"],
    });

    if (!planDetail) {
      return res.status(403).json({
        status: false,
        message: "Plan not found!",
        data: {},
      });
    } 
    try {
      let deleted = await super.deleteByCondition(
        planModel, 
        {
          id: planDetail.id,
        }
      );
  
      if(deleted){
        return res.status(200).json({
          status: true,
          message: "Plan successfully deleted.",
          data: {}
        });
      } else {
        return res.status(500).json({
          status: false,
          message: "Oops.. something went terribly wrong!",
          data: {}
        });
      }
    } catch (error) {
      res.status(500).json({
        status: false,
        message: error.message,
        data: {}
      });
    }
    
  });
  static getCurrencyInfo = catchAsyncErrors(async (req, res, next) => {
    const { id, isDefault, currency_code } = req.body;
    let queryConditions = {
      deletedAt: null,
      status: true,
    };

    if (id) {
      queryConditions.id = id
    }
    if (isDefault) {
      queryConditions.isDefault = isDefault
    }
    if (currency_code) {
      queryConditions.currency_code = currency_code
    }

    let currencyDetails = await super.getByCustomOptionsSingle(req, currencyModel, {
      where: queryConditions,
    });

    if (currencyDetails) {
      return res.status(200).json({
        status: true,
        message: "Success",
        data: currencyDetails
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No records found.",
        data: {}
      });
    }
  });
  static updatePlanStatus = catchAsyncErrors(async (req, res, next) => {
    let { id, status } = req.body;
    
    let condition = {
      deletedAt: null,
      id: id
    };

    let checkExist = await planModel.findOne({
      attributes: ["name"],
      where: {
        ...condition,
      },
    });

    if (!checkExist) {
      return res.status(400).json({
        status: false,
        message: "Plan doesn't exist!",
        data: checkExist,
      });
    }
    let updateFields = {
      status: status
    };
    let updated = await super.updateById(planModel, id, updateFields);
    if (updated) {
      return res.status(200).json({
        status: true,
        message: "Plan status updated successfully.",
        data: updated,
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Oops.. Something went wrong!",
        data: {},
      });
    }
  });
}

module.exports = pricingPlanController;
