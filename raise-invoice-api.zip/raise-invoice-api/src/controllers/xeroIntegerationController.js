const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const { XeroClient } = require('xero-node');
require('dotenv').config();
const app = express();

app.use(cookieParser());
const BaseController = require("../controllers/BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const db = require("../models");
const clientModel = db.Clients;
const userCompanyModel = db.UserCompanies;
const planModel = db.Plans;
const mysqlConfig = require("../config/index").Mysql;
const config = require("../config/index")
const { connectSpecificToDatabase } = require("../config/specificConnect");
const { createXeroClient } = require('../config/xeroConfig');
const XeroTokenService = require('../utils/xeroTokenServics');
const { findXeroUserByClientId } = require('../utils/utilities');

// You need to require your pool/DB connection here
const connectMySqlDatabase = require('../config/connect');

class xeroIntegrationController extends BaseController {
    static xeroConnect = catchAsyncErrors(async (req, res) => {
        try {
            const userId = req.user.id;
            const xero = createXeroClient(userId);

            console.log("Initiating Xero connect for userId:", xero);
            const consentUrl = await xero.buildConsentUrl();

            console.log("Xero consent URL:", consentUrl + `&state=${userId}`);

            res.json({
                success: true,
                consentUrl: consentUrl + `&state=${userId}`
            });
        } catch (error) {
            console.error("Xero connect error:", error);
            res.status(500).json({ error: 'Failed to connect to Xero' });
        }
    })

    static xeroCallback = catchAsyncErrors(async (req, res, next) => {
        try {

            const userId = req.query.state;
            console.log("Xero callback for userId:", userId);
            const xero = createXeroClient(userId);
            console.log("Processing callback with URL:", req.url);
            
            const tokenSet = await xero.apiCallback(req.url);

            // Set the token set on the xero client
            xero.setTokenSet(tokenSet);
            
            // Get all connected tenants/organizations
            const tenants = await xero.updateTenants();

            console.log("Xero tenants for userId", userId, ":", tenants);
            tokenSet.tenants = tenants;

             const user = await clientModel.findOne({
                attributes: ['id', 'database_name'],
                where: { id: userId }
            });

            if (!user) {
                return res.status(404).json({ status: false, message: 'User not found' });
            }

            const db_name = user.database_name;
            if (!db_name) {
                return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
            }

            const connection = await connectSpecificToDatabase(
                db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
            );

            // Store tokens for this specific user
            const tokenService = new XeroTokenService(userId);
            await tokenService.setTokens(tokenSet, connection);

            const redirectUrl = config.REDIRECT_DASHBOARD;
            console.log("Redirecting to:", redirectUrl);
            res.redirect(redirectUrl);
        } catch (error) {
            console.error("Xero callback error:", error);
            
            if (error.name === 'JsonWebTokenError') {
                res.redirect(config.REDIRECT_INVALID_JWT);
            } else if (error.name === 'TokenExpiredError') {
                res.redirect(config.REDIRECT_JWT_EXPIRED);
            } else {
                res.redirect(config.REDIRECT_CONNECTION_FAILED);
            }
        }
    })

    static xeroSyncInvoice = catchAsyncErrors(async (req, res, next) => {
        try {
            // Get userId from cookie
            const userId = req.cookies.xeroUserId;
            const { invoices } = req.body;
            const user = await clientModel.findOne({
                attributes: ['id', 'database_name'],
                where: { id: userId }
            });

            if (!user) {
                return res.status(404).json({ status: false, message: 'User not found' });
            }

            const db_name = user.database_name;
            if (!db_name) {
                return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
            }

            const connection = await connectSpecificToDatabase(
                db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
            );

            const tokenService = new XeroTokenService(userId);
            await tokenService.refreshTokensIfNeeded(connection);

            const tokens = await tokenService.getTokens(connection);
            const response = await tokenService.xero.accountingApi.createInvoices(
                tokens.tenantId,
                { invoices }
            );

            await tokenService.updateLastSync(connection);

            res.json({ success: true, data: response.body });
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    })

    static xeroConnectionStatus = catchAsyncErrors(async (req, res, next) => {
        try {
            
            const userId = req.user.id;
            const user = await clientModel.findOne({
                attributes: ['id', 'database_name'],
                where: { id: userId }
            });
            const state = `${userId}-${Date.now()}`;

            if (!user) {
                return res.status(404).json({ status: false, message: 'User not found' });
            }

            const db_name = user.database_name;
            if (!db_name) {
                return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
            }

            const connection = await connectSpecificToDatabase(
                db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
            );
            const tokenService = new XeroTokenService(userId);
            const isConnected = await tokenService.isConnected(connection)
            console.log(isConnected, "isConnected status for user:", userId);
            const tokens = await tokenService.getTokens(connection);

            console.log('Xero connection status for user:', userId, 'isConnected:', isConnected);
            
            res.json({ 
                connected: isConnected,
                tenantId: tokens?.tenantId,
                tenantName: tokens?.tenantName,
                // connectedAt: tokens?.connectedAt
            });
        } catch (error) {
            res.json({ connected: false });
        }
    })

    static xeroFetchInvoiceFromXero = catchAsyncErrors(async (req, res) => {
        try {
            const userId = req.user.id;
            const user = await clientModel.findOne({
                attributes: ['id', 'database_name'],
                where: { id: userId }
            });

            if (!user) {
                return res.status(404).json({ status: false, message: 'User not found' });
            }

            const db_name = user.database_name;
            if (!db_name) {
                return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
            }

            const connection = await connectSpecificToDatabase(
                db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
            );
            const tokenService = new XeroTokenService(userId);
            await tokenService.refreshTokensIfNeeded(connection);

            const tokens = await tokenService.getTokens(connection);
            
            const invoices = await tokenService.xero.accountingApi.getInvoices(tokens.tenantId);
            const detailedInvoices = [];

            for (const invoice of invoices.body.invoices) {
                const fullInvoice = await tokenService.xero.accountingApi.getInvoice(tokens.tenantId, invoice.invoiceID);
                detailedInvoices.push(fullInvoice.body.invoices[0]);
            }

            const lastSync = await tokenService.updateLastSync(connection);

            res.json({ success: true, invoices: detailedInvoices, lastSync });
        } catch (error) {
            console.error('Sync from Xero error:', error);
            res.status(500).json({ error: error.message });
        }
    })

    static xeroFetchCustomers = catchAsyncErrors(async (req, res, next) => {
        try {
            const userId = req.user.id;
            const user = await clientModel.findOne({
                attributes: ['id', 'database_name'],
                where: { id: userId }
            });
            const state = `${userId}-${Date.now()}`;
            if (!user) {
                return res.status(404).json({ status: false, message: 'User not found' });
            }
            const db_name = user.database_name;
            if (!db_name) {

                return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
            }

            const connection = await connectSpecificToDatabase(
                db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
            );
            const tokenService = new XeroTokenService(userId);
            await tokenService.refreshTokensIfNeeded(connection);
            const tokens = await tokenService.getTokens(connection);
            const response = await tokenService.xero.accountingApi.getContacts(
                tokens.tenantId
            );
            res.json({ contacts: response.body.contacts });
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    });

    static xeroTenants = catchAsyncErrors(async (req, res, next) => {
        try {
            const userId = req.user.id;
            const user = await clientModel.findOne({
                attributes: ['id', 'database_name'],
                where: { id: userId }
            });
            const state = `${userId}-${Date.now()}`;

            if (!user) {
                return res.status(404).json({ status: false, message: 'User not found' });
            }

            const db_name = user.database_name;
            if (!db_name) {
                return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
            }

            const connection = await connectSpecificToDatabase(
                db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
            );
            const tokenService = new XeroTokenService(userId);
            await tokenService.refreshTokensIfNeeded(connection);
            
            const tenants = await tokenService.xero.updateTenants();
            res.json({ tenants });
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    })

    static xeroLastSync = catchAsyncErrors(async (req, res, next) => {
        try {
            const userId = req.user.id;
            const user = await clientModel.findOne({
                attributes: ['id', 'database_name'],
                where: { id: userId }
            });
            const state = `${userId}-${Date.now()}`;
            if (!user) {
                return res.status(404).json({ status: false, message: 'User not found' });
            }
            const db_name = user.database_name;
            if (!db_name) {
                return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
            }
            const connection = await connectSpecificToDatabase(
                db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
            );
            const tokenService = new XeroTokenService(userId);
            const lastSync = await tokenService.getLastSync(connection);
            res.json({ lastSync });
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    })

    static xeroDisconnect = catchAsyncErrors(async (req, res, next) => {
        try {
            const userId = req.user.id;
            const user = await clientModel.findOne({
                attributes: ['id', 'database_name'],
                where: { id: userId }
            });
            const state = `${userId}-${Date.now()}`;

            if (!user) {
                return res.status(404).json({ status: false, message: 'User not found' });
            }

            const db_name = user.database_name;
            if (!db_name) {
                return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
            }

            const connection = await connectSpecificToDatabase(
                db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
            );
            const tokenService = new XeroTokenService(userId);
            await tokenService.disconnect(connection);
            
            res.json({ success: true, message: 'Xero disconnected successfully' });
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    })

    static xeroConnectedUser = catchAsyncErrors(async (req, res, next) => {
        try {
            const userId = req.user.id;
            const user = await clientModel.findOne({
                attributes: ['id', 'database_name'],
                where: { id: userId }
            });
            const state = `${userId}-${Date.now()}`;

            if (!user) {
                return res.status(404).json({ status: false, message: 'User not found' });
            }

            const db_name = user.database_name;
            if (!db_name) {
                return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
            }

            const connection = await connectSpecificToDatabase(
                db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
            );
            const connections = await connection.XeroToken.findAll({
                attributes: ['user_id', 'tenant_name', 'connected_at', 'last_sync'],
                where: { connected: true },
                include: [{
                    model: connection.User,
                    attributes: ['id', 'email']
                }]
            });
            
            res.json({ connections });
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    })
    
}

module.exports = xeroIntegrationController;