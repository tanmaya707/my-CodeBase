const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const mustache = require('mustache');

const db = require("../models");
const { where } = require("sequelize");
const clientModel = db.Clients;
const mysqlConfig = require("../config/index").Mysql;
const invoiceModel = db.InvoiceTemplate
const logoModel = db.InvoiceLogo
const invoiceHeaderModel = db.InvoiceHeader
const InvoiceWaterMarkModel = db.InvoiceWaterMark
const colourList = db.InvoiceColour

const fileUploaderSingle = require("../utils/fileUpload").fileUploaderSingle;
const { connectSpecificToDatabase } = require("../config/specificConnect");
const { create } = require("html-pdf");

class invoiceController extends BaseController {
  constructor() {
    super();
  }

//For Invoice Template Setting
static getTemplateList = catchAsyncErrors(async (req, res, next) => {
    try {
        const { templateName, logoId, logoSize = "100px", logoPosition = "center", colourId, headerId, waterMarkId } = req.body;

        // Fetch the invoice template
        let result = await invoiceModel.findOne({
            where: { name: templateName }
        });

        if (!result) {
            return res.status(404).json({
                status: false,
                message: "No templates found.",
                data: []
            });
        }

        let template = result.dataValues.text;

        // Fetch header image as base64 if headerId is provided
        let headerBase64 = null;
        if (headerId) {
            const headerRecord = await invoiceHeaderModel.findOne({ where: { id: headerId } });
            if (headerRecord && headerRecord.headerImg && Buffer.isBuffer(headerRecord.headerImg)) {
                headerBase64 = headerRecord.headerImg.toString('base64');
            }
        }

        // Fetch watermark image as base64 if waterMarkId is provided
        let waterMarkBase64 = null;
        if (waterMarkId) {
            const waterMarkRecord = await InvoiceWaterMarkModel.findOne({ where: { id: waterMarkId } });
            if (waterMarkRecord && waterMarkRecord.waterMarkImg && Buffer.isBuffer(waterMarkRecord.waterMarkImg)) {
                waterMarkBase64 = waterMarkRecord.waterMarkImg.toString('base64');
            }
        }


        const userId = req.user.id;
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }

        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        const uuid = crypto.randomUUID();
        // Start a transaction
        const transaction = await connection.sequelize.transaction();

        const invoiceField = {
            client_admin_id : req.user.id,
            uuid: uuid,
            name: templateName,
            logoPosition: logoPosition,
            logoSize: logoSize,
            logo: logoId ? `${logoId}` : null,
            colour: colourId ? `${colourId}` : null,
            header : headerId,
            waterMark: waterMarkId
        }

        // Create the invoice template
        await super.create(res, connection.InvoiceSetting, invoiceField, { transaction });

        // Define invoice data
        const invoiceData = {
            logoPosition: logoPosition,
            logoSize: logoSize,
            logo: logoId ? `${logoId}` : null,
            colour: colourId ? `${colourId}` : null,
            header: headerBase64,
            waterMark: waterMarkBase64,
            invoice_number: 1,
            created_date: new Date().toISOString().split('T')[0],
            due_date: new Date(new Date().setMonth(new Date().getMonth() + 1)).toISOString().split('T')[0],
            company_name: "Raise Invoice",
            company_address: "5678 Innovation Blvd, Tech City, TX 75001",
            client_name: "Alice Doe",
            client_email: "alice@example.com",
            client_phone: "1232456765",
            items: [
                { name: "Web Development Package", price: "$500.00" }
            ],
            subtotal_amount: "$500.00",
            total_amount: "$500.00",
            discount_amount: "$0.00",
            tax: "GST 18% ($500.00)",
            tax_amounts: "$90.00",
            paid_amount: "$100.00",
            balance_due: "$425.00"
        };

        // Render final invoice template with dynamic data
        const renderedInvoice = mustache.render(template, invoiceData);

        if (renderedInvoice) {
            // res.setHeader("Content-Type", "text/html");
            // return res.status(200).send(renderedInvoice);
            return res.status(200).json({
                status: true,
                message: "Template saved successfully.",
                data: {
                    logoPosition: logoPosition,
                    logoSize: logoSize,
                    logo: logoId ? `${logoId}` : null,
                    colour: colourId ? `${colourId}` : null,
                    header: headerId,
                    waterMark: waterMarkId
                }
            });
        } else {
            return res.status(500).send({});
        }
    } catch (error) {
        console.error("Error fetching invoice templates:", error);
        return res.status(500).json({
            status: false,
            message: "Internal server error.",
            data: []
        });
    }
});

static createTemplateList = catchAsyncErrors(async (req, res, next) => {
    try {
        const { id, templateName, logoId, logoSize = "100px", logoPosition = "center", colourId, customColour, colourCode, headerId, waterMarkId } = req.body;
        const uuid = crypto.randomUUID();

        const userId = req.user.id;
        const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);

        if (error) {
            return res.status(404).json({ status: false, message: error });
        }

        // Start a transaction
        let colourCreated = null;
        if (customColour || colourCode) {
            let colourFields = {
                uuid,
                colourCode: colourCode || customColour,
            };

            colourCreated = await super.create(res, connection.InvoiceColour, colourFields);
        }

        if ((customColour || colourCode) && !colourCreated) {
            return res.status(500).json({ status: false, message: 'Failed to create colour.', data: {} });
        }

        const invoiceField = {
            client_admin_id: req.user.id,
            uuid: uuid,
            name: templateName,
            logoPosition: logoPosition,
            logoSize: logoSize,
            logo: logoId ? `${logoId}` : null,
            colour: colourId ? `${colourId}` : colourCreated ? `${colourCreated.id}` : null,
            header: headerId,
            waterMark: waterMarkId
        };

        let createdInvoice = {};
        if (!id) {
            createdInvoice = await super.create(res, connection.InvoiceSetting, invoiceField);
        } else {
            // Prepare update fields for update
            const updateFields = {
                name: templateName,
                logoPosition: logoPosition,
                logoSize: logoSize,
                logo: logoId ? `${logoId}` : null,
                colour: colourId ? `${colourId}` : colourCreated ? `${colourCreated.id}` : null,
                header: headerId,
                waterMark: waterMarkId
            };
            await connection.InvoiceSetting.update(updateFields, {
                where: { id: id }
            });
            createdInvoice = await connection.InvoiceSetting.findOne({ where: { id: id } });
        }

        if (createdInvoice) {
            return res.status(200).json({
                status: true,
                message: "Template saved successfully.",
                data: createdInvoice
            });
        } else {
            return res.status(500).send({});
        }
    } catch (error) {
        console.error("Error fetching invoice templates:", error);
        return res.status(500).json({
            status: false,
            message: "Internal server error.",
            data: []
        });
    }
});

static getInvoiceSetting = catchAsyncErrors(async (req, res, next) => {
    try{
        const userId = req.user.id;
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }

        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        const invoiceSetting = await connection.InvoiceSetting.findOne({
            where: { client_admin_id: req.user.id}
        });

        if (!invoiceSetting) {
            return res.status(404).json({
                status: false,
                message: "Invoice setting not found.",
                data: {}
            });
        }

        // Populate header, waterMark, colour, and logo details if present
        let settingData = invoiceSetting.toJSON();

        // Populate header details
        if (settingData.header) {
            const headerRecord = await connection.InvoiceHeader.findOne({ where: { id: settingData.header } });
            if (headerRecord) {
                const headerObj = headerRecord.toJSON();
                if (headerObj.headerImg) {
                     headerObj.headerImg = `${req.protocol}://${req.get('host')}/uploads/${headerObj.headerImg}`;
                }
                settingData.headerDetails = headerObj;
            }
        }

        // Populate waterMark details
        if (settingData.waterMark) {
            const waterMarkRecord = await connection.InvoiceWaterMark.findOne({ where: { id: settingData.waterMark } });
            if (waterMarkRecord) {
                const wmObj = waterMarkRecord.toJSON();
               if (wmObj.waterMarkImg) {
                    wmObj.waterMarkImg = `${req.protocol}://${req.get('host')}/uploads/${wmObj.waterMarkImg}`;
                }
                settingData.waterMarkDetails = wmObj;
            }
        }

        // Populate colour details
        if (settingData.colour) {
            const colourRecord = await connection.InvoiceColour.findOne({ where: { id: settingData.colour } });
            if (colourRecord) {
                settingData.colourDetails = colourRecord.toJSON();
            }
        }

        // Populate logo details
        if (settingData.logo) {
            const logoRecord = await connection.InvoiceLogo.findOne({ where: { id: settingData.logo } });
            if (logoRecord) {
                const logoObj = logoRecord.toJSON();
                if (logoObj.logoImage) {
                    logoObj.logoImage = `${req.protocol}://${req.get('host')}/uploads/${logoObj.logoImage}`;
                }
                settingData.logoDetails = logoObj;
            }
        }

        return res.status(200).json({
            status: true,
            message: "Invoice setting retrieved successfully.",
            data: settingData
        });
    }
    catch (error) {
        console.error("Error fetching invoice setting:", error);
        return res.status(500).json({
            status: false,
            message: "Internal server error.",
            data: {}
        });
    }
});

static updateInvoiceSetting = catchAsyncErrors(async (req, res, next) => {
    const { templateName, logoPosition, logoSize, logoId, colourId, headerId, waterMarkId } = req.body;
    const userId = req.user.id;
    const user = await clientModel.findOne({
        attributes: ['id', 'database_name'],
        where: { id: userId }
    });
    if (!user) {
        return res.status(404).json({ status: false, message: 'User not found' });
    }
    const db_name = user.database_name;
    if (!db_name) {
        return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
    }
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );
    try {
        // Find the existing invoice setting
        const existingSetting = await connection.InvoiceSetting.findOne({
            where: { client_admin_id: req.user.id }
        });
        if (!existingSetting) {
            return res.status(404).json({
                status: false,
                message: "Invoice setting not found.",
                data: {}
            });

        }
        // Update the invoice setting
        const updatedSetting = await existingSetting.update({
            name: templateName || existingSetting.name,
            logoPosition: logoPosition || existingSetting.logoPosition,
            logoSize: logoSize || existingSetting.logoSize,
            logo: logoId || existingSetting.logo,
            colour: colourId || existingSetting.colour,
            header: headerId || existingSetting.headerId,
            waterMark: waterMarkId || existingSetting.waterMarkId
        });
        return res.status(200).json({
            status: true,
            message: "Invoice setting updated successfully.",
            data: updatedSetting
        });
    } catch (error) {
        console.error("Error updating invoice setting:", error);
        return res.status(500).json({
            status: false,
            message: "Internal server error.",
            data: {}
        });
    }
});


//For Invoice Option Setting
static getInvoiceOptionSetting = catchAsyncErrors(async (req, res, next) => {
    try{
        const userId = req.user.id;
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }

        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        const invoiceOptionSetting = await connection.InvoiceOptionSetting.findOne({
            where: { client_admin_id: req.user.id}
        });

        if (!invoiceOptionSetting) {
            return res.status(404).json({
                status: false,
                message: "Invoice option setting not found.",
                data: {}
            });
        }

        return res.status(200).json({
            status: true,
            message: "Invoice option setting retrieved successfully.",
            data: invoiceOptionSetting
        });
    }
    catch (error) {
        console.error("Error fetching invoice setting:", error);
        return res.status(500).json({
            status: false,
            message: "Internal server error.",
            data: {}
        });
    }
});

static invoiceOptionSetting = catchAsyncErrors(async (req, res, next) => {
    try {
        const userId = req.user.id;
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }

        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        const {
            id,
            shippingDetails,
            due_date,
            payment_terms,
            itemCode,
            quantityAndRate,
            pTax,
            tax_amounts,
            includeSignatureLine,
            invoicePrifix
        } = req.body;

        // Prepare data for upsert
        const invoiceOptionSettingData = {
            client_admin_id: userId,
            shippingDetails: shippingDetails ?? null,
            due_date: due_date ?? null,
            payment_terms: payment_terms ?? null,
            itemCode: itemCode ?? null,
            quantityAndRate: quantityAndRate ?? null,
            pTax: pTax ?? null,
            tax_amounts: tax_amounts ?? null,
            includeSignatureLine: includeSignatureLine ?? null,
            invoicePrifix: invoicePrifix || null
        };

        let savedSetting = {};
        if (id) {
            // Update existing setting
            await connection.InvoiceOptionSetting.update(invoiceOptionSettingData, { where: { id: id } });
            savedSetting = await connection.InvoiceOptionSetting.findOne({
                where: { id: id }
            });
        } else {
            // Create new setting
            savedSetting = await connection.InvoiceOptionSetting.create(invoiceOptionSettingData);
        }

        return res.status(200).json({
            status: true,
            message: "Invoice option setting saved successfully.",
            data: savedSetting
        });
    } catch (error) {
        console.error("Error saving invoice option setting:", error);
        return res.status(500).json({
            status: false,
            message: "Internal server error.",
            data: {}
        });
    }
})

//For Invoice Template Preview
static previewTemplate = catchAsyncErrors(async (req, res, next) => {
    try {
        const { templateName } = req.body;
        // Fetch template
        const result = await invoiceModel.findOne({
            where: { name: templateName }
        });

        if (!result) {
            return res.status(404).json({
                status: false,
                message: "No templates found.",
                data: []
            });
        }

        let templateData = result.dataValues.text;

        // Get user and DB info
        const userId = req.user.id;
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }

        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        // Fetch settings
        const optionSetting = await connection.InvoiceOptionSetting.findOne({
            where: { client_admin_id: userId }
        });
        const invoiceSetting = await connection.InvoiceSetting.findOne({
            where: { client_admin_id: userId }
        });

        // Prepare preview data based on settings
        let previewData = {
            invoice_number: 1,
            created_date: new Date().toISOString().split('T')[0],
            due_date: optionSetting?.due_date ? new Date(new Date().setMonth(new Date().getMonth() + 1)).toISOString().split('T')[0] : undefined,
            company_name: "Raise Invoice",
            company_address: "5678 Innovation Blvd, Tech City, TX 75001",
            client_name: "Alice Doe",
            client_email: "alice@example.com",
            client_phone: "1232456765",
            items: [
                { name: "Web Development Package", price: "$500.00" }
            ],
            subtotal_amount: "$500.00",
            total_amount: "$500.00",
            discount_amount: "$0.00",
            tax: optionSetting?.tax_amounts ? "GST 18% ($500.00)" : undefined,
            tax_amounts: optionSetting?.tax_amounts ? "$90.00" : undefined,
            paid_amount: "$100.00",
            balance_due: "$425.00",
            shippingDetails: optionSetting?.shippingDetails ? "1234 Shipping Lane, Ship City, ST 12345" : undefined,
            payment_terms: optionSetting?.payment_terms ? "Net 30" : undefined,
            itemCode: optionSetting?.itemCode ? "ITEM-001" : undefined,
            quantityAndRate: optionSetting?.quantityAndRate ? "Qty: 1, Rate: $500.00" : undefined,
            pTax: optionSetting?.pTax ? "18%" : undefined,
            includeSignatureLine: optionSetting?.includeSignatureLine ? true : undefined,
            invoicePrifix: optionSetting?.invoicePrifix || ""
        };

        // Add logo, header, watermark, colour if present in invoiceSetting
        if (invoiceSetting) {
            previewData.logoPosition = invoiceSetting.logoPosition;
            // Set logoSize based on value
            if (invoiceSetting.logoSize === 'small') {
                previewData.logoSize = '100px';
            } else if (invoiceSetting.logoSize === 'middium') {
                previewData.logoSize = '150px';
            } else if (invoiceSetting.logoSize === 'large') {
                previewData.logoSize = '200px';
            } else {
                previewData.logoSize = invoiceSetting.logoSize;
            }

            // Populate logo details
            if (invoiceSetting.logo) {
                const logoRecord = await logoModel.findOne({ where: { id: invoiceSetting.logo } });
                if (logoRecord) {
                    const logoObj = logoRecord.toJSON();
                    if (logoObj.logoImage) {
                        logoObj.logoImage = `${req.protocol}://${req.get('host')}/uploads/${logoObj.logoImage}`;
                    }
                    previewData.logo = logoObj.logoImage;
                }
            }

            // Populate colour details
            if (invoiceSetting.colour) {
                const colourRecord = await colourList.findOne({ where: { id: invoiceSetting.colour } });
                if (colourRecord) {
                    const colourObj = colourRecord.toJSON();
                    previewData.colour = colourObj.colourCode;
                    
                }
            }

            // Fetch header image as base64 if header is present
            if (invoiceSetting.header) {
                const headerRecord = await invoiceHeaderModel.findOne({ where: { id: invoiceSetting.header } });
                if (headerRecord && headerRecord.headerImg && Buffer.isBuffer(headerRecord.headerImg)) {
                    previewData.header = headerRecord.headerImg.toString('base64');
                }
            }

            // Fetch watermark image as base64 if waterMark is present
            if (invoiceSetting.waterMark) {
                const waterMarkRecord = await InvoiceWaterMarkModel.findOne({ where: { id: invoiceSetting.waterMark } });
                if (waterMarkRecord && waterMarkRecord.waterMarkImg && Buffer.isBuffer(waterMarkRecord.waterMarkImg)) {
                    previewData.waterMark = waterMarkRecord.waterMarkImg.toString('base64');
                }
            }
        }

        // Remove undefined fields
        Object.keys(previewData).forEach(key => previewData[key] === undefined && delete previewData[key]);

        // Render template
        const renderedInvoice = mustache.render(templateData, previewData);

        if (renderedInvoice) {
            res.setHeader('Content-Type', 'text/html');
            return res.status(200).send(renderedInvoice);
        } else {
            return res.status(500).send({});
        }
    } catch (error) {
        console.error("Error Rendering Invoice:", error);
        return res.status(500).send({});
    }
});


//For All the Logo, Image, Colour, Header and Watermark related operations
static addLogo = catchAsyncErrors(async (req, res, next) => {
    const userId = req.user.id;
    const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);

    if (error) {
        return res.status(404).json({ status: false, message: error });
    }

    // Start a transaction
    const transaction = await connection.sequelize.transaction();

    try {
        let fileName = "";

        if (req.files && req.files.logoImage) {
            let image = await fileUploaderSingle("src/public/uploads/", req.files.logoImage);
            fileName = image.newfileName;
        }

        const uuid = crypto.randomUUID();
        let logoFields = {
            uuid,
            logoImage: fileName || null
        };

        const logoCreated = await super.create(res, connection.InvoiceLogo, logoFields, { transaction });

        const logoWithImageURL = {
            ...logoCreated.toJSON(),
            logoImage: logoCreated.logoImage ? `${req.protocol}://${req.get('host')}/uploads/${logoCreated.logoImage}` : null
        };

        return res.status(200).json({
            status: true,
            message: "Logo Added successfully.",
            data: logoWithImageURL
        });
    } catch (error) {
        console.error('Error creating Logo:', error);
        return res.status(500).json({
            status: false,
            message: "Oops.. something went terribly wrong!",
            data: {}
        });
    }
});

static logoList = catchAsyncErrors(async (req, res, next) => {
    try {

        const userId = req.user.id;
        const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);

        if (error) {
            return res.status(404).json({ status: false, message: error });
        }

        const invoiceLogo = await connection.InvoiceLogo.findAll();
        const logoWithImageURL = invoiceLogo.map(logo => ({
            ...logo.toJSON(),
            logoImage: logo.logoImage ? `${req.protocol}://${req.get('host')}/uploads/${logo.logoImage}` : null
        }));

        return res.status(200).json({
            status: true,
            message: "Logo retrieved successfully.",
            data: logoWithImageURL,
        });
    } catch (error) {
        console.error("Error fetching Logo:", error);
        return res.status(500).json({
            status: false,
            message: "Oops... something went terribly wrong!",
            data: {}
        });
    }
});

static deleteLogo = catchAsyncErrors(async (req, res, next) => {
    try {
        const { id } = req.body;
        const userId = req.user.id;
        const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);

        if (error) {
            return res.status(404).json({ status: false, message: error });
        }

        const deletedCount = await connection.InvoiceLogo.destroy({ where: { id } });
        if (deletedCount === 0) {
            return res.status(404).json({
                status: false,
                message: "Logo not found.",
                data: {}
            });
        }
        return res.status(200).json({
            status: true,
            message: "Logo deleted successfully.",
            data: {}
        });
    } catch (error) {
        console.error("Error deleting Logo:", error);
        return res.status(500).json({
            status: false,
            message: "Oops... something went terribly wrong!",
            data: {}
        });
    }
});


static uploadImage = catchAsyncErrors(async (req, res, next) =>{
    try {
        let fileName = "";

        if (req.files && req.files.uploadImage) {
            let image = await fileUploaderSingle("src/public/uploads/", req.files.uploadImage);
            fileName = image.newfileName;
        }
        
        const uuid = crypto.randomUUID();
        let uploadFields = {
            uuid,
            uploadImage : fileName || null
        };

        const imageCreated = await super.create(res, uploadImage , uploadFields);

        return res.status(200).json({
            status: true,
            message: "Image Added successfully.",
            data: imageCreated
        });
    } catch (error) {
        console.error('Error creating Items:', error);
        return res.status(500).json({
            status: false,
            message: "Oops.. something went terribly wrong!",
            data: {}
        });
    }
})

static addHeader = catchAsyncErrors(async (req, res, next) => {
    const userId = req.user.id;
    const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);

    if (error) {
        return res.status(404).json({ status: false, message: error });
    }

    // Start a transaction
    const transaction = await connection.sequelize.transaction();

    try {
        let fileName = "";

        if (req.files && req.files.headerImg) {
            let image = await fileUploaderSingle("src/public/uploads/", req.files.headerImg);
            fileName = image.newfileName;
        }

        const uuid = crypto.randomUUID();
        let headerFields = {
            uuid,
            headerImg: fileName || null
        };

        const headerCreated = await super.create(res, connection.InvoiceHeader, headerFields, { transaction });

        const headerWithImageURL = {
            ...headerCreated.toJSON(),
            headerImg: headerCreated.headerImg ? `${req.protocol}://${req.get('host')}/uploads/${headerCreated.headerImg}` : null
        };

        return res.status(200).json({
            status: true,
            message: "Header Added successfully.",
            data: headerWithImageURL
        });
    } catch (error) {
        console.error('Error creating Header:', error);
        return res.status(500).json({
            status: false,
            message: "Oops.. something went terribly wrong!",
            data: {}
        });
    }
});

static headerList = catchAsyncErrors(async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);
        if (error) {
            return res.status(404).json({ status: false, message: error });
        }
        
        const HeaderList = await connection.InvoiceHeader.findAll();
        const headersWithImageURL = HeaderList.map(header => ({
            ...header.toJSON(),
            headerImg: header.headerImg ? `${req.protocol}://${req.get('host')}/uploads/${header.headerImg}` : null
        }));

        return res.status(200).json({
            status: true,
            message: "Headers retrieved successfully.",
            data: headersWithImageURL,
        });
    } catch (error) {
        console.error("Error fetching Headers:", error);
        return res.status(500).json({
            status: false,
            message: "Oops... something went terribly wrong!",
            data: {}
        });
    }
});

static deleteHeader = catchAsyncErrors(async (req, res, next) => {
    try {
        const { id } = req.body;
        const userId = req.user.id;
        const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);

        if (error) {
            return res.status(404).json({ status: false, message: error });
        }

        const deletedCount = await connection.InvoiceHeader.destroy({ where: { id } });
        if (deletedCount === 0) {
            return res.status(404).json({
                status: false,
                message: "Header not found.",
                data: {}
            });
        }
        return res.status(200).json({
            status: true,
            message: "Header deleted successfully.",
            data: {}
        });
    } catch (error) {
        console.error("Error deleting Header:", error);
        return res.status(500).json({
            status: false,
            message: "Oops... something went terribly wrong!",
            data: {}
        });
    }
});

static addWaterMark = catchAsyncErrors(async (req, res, next) => {
    const userId = req.user.id;
    const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);

    if (error) {
        return res.status(404).json({ status: false, message: error });
    }

    // Start a transaction
    const transaction = await connection.sequelize.transaction();

    try {
        let fileName = "";

        if (req.files && req.files.waterMarkImg) {
            let image = await fileUploaderSingle("src/public/uploads/", req.files.waterMarkImg);
            fileName = image.newfileName;
        }

        const uuid = crypto.randomUUID();
        let waterMarkFields = {
            uuid,
            waterMarkImg: fileName || null
        };

        const waterMarkCreated = await super.create(res, connection.InvoiceWaterMark, waterMarkFields, { transaction });

        const waterMarkWithImageURL = {
            ...waterMarkCreated.toJSON(),
            waterMarkImg: waterMarkCreated.waterMarkImg ? `${req.protocol}://${req.get('host')}/uploads/${waterMarkCreated.waterMarkImg}` : null
        };

        return res.status(200).json({
            status: true,
            message: "WaterMark Added successfully.",
            data: waterMarkWithImageURL
        });
    } catch (error) {
        console.error('Error creating WaterMark:', error);
        return res.status(500).json({
            status: false,
            message: "Oops.. something went terribly wrong!",
            data: {}
        });
    }
});

static waterMarkList = catchAsyncErrors(async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);
        if (error) {
            return res.status(404).json({ status: false, message: error });
        }
        
        const InvoiceWaterMarks = await connection.InvoiceWaterMark.findAll();
        const waterMarkWithImageURL = InvoiceWaterMarks.map(wm => ({
            ...wm.toJSON(),
            waterMarkImg: wm.waterMarkImg ? `${req.protocol}://${req.get('host')}/uploads/${wm.waterMarkImg}` : null
        }));

        return res.status(200).json({
            status: true,
            message: "WaterMarks retrieved successfully.",
            data: waterMarkWithImageURL,
        });
    } catch (error) {
        console.error("Error fetching WaterMarks:", error);
        return res.status(500).json({
            status: false,
            message: "Oops... something went terribly wrong!",
            data: {}
        });
    }
});

static deleteWaterMark = catchAsyncErrors(async (req, res, next) => {
    try {
        const { id } = req.body;
        const userId = req.user.id;
        const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);

        if (error) {
            return res.status(404).json({ status: false, message: error });
        }
        const deletedCount = await connection.InvoiceWaterMark.destroy({ where: { id } });
        if (deletedCount === 0) {
            return res.status(404).json({
                status: false,
                message: "WaterMark not found.",
                data: {}
            });
        }
        return res.status(200).json({
            status: true,
            message: "WaterMark deleted successfully.",
            data: {}
        });
    } catch (error) {
        console.error("Error deleting WaterMark:", error);
        return res.status(500).json({
            status: false,
            message: "Oops... something went terribly wrong!",
            data: {}
        });
    }
});


static colourList = catchAsyncErrors(async (req, res, next) => {
    try {
        const colourlist = await colourList.findAll();

        return res.status(200).json({
            status: true,
            message: "ColourList retrieved successfully.",
            data: colourlist,
        });
    } catch (error) {
        console.error("Error fetching ColourList:", error);
        return res.status(500).json({
            status: false,
            message: "Oops... something went terribly wrong!",
            data: {}
        });
    }
});

static getInvoiceSignature = catchAsyncErrors(async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);

        if (error) {
            return res.status(404).json({ status: false, message: error });
        }

        const signature = await connection.InvoiceSignature.findOne({
            where: { client_admin_id: req.user.id }
        });
     if (!signature) {
        return res.status(404).json({
                status: false,
                message: "Signature not found.",
                data: {}
            });
        }
        return res.status(200).json({
            status: true,
            message: "Signature retrieved successfully.",
            data: signature
        });
    } catch (error) {
        console.error("Error fetching signature:", error);
        return res.status(500).json({
            status: false,
            message: "Internal server error.",
            data: {}
        });
    }
});

static invoiceSignatureSetting = catchAsyncErrors(async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);
        if (error) {

            return res.status(404).json({ status: false, message: error });
        }
        const {id, invoice, estimate, purchaseOrder, creditNote, signature, signatureData, signatureText, signatureType } = req.body;
        // let fileName = "";
        // if (req.files && req.files.signatureImage) {
        //     let image = await fileUploaderSingle("src/public/uploads/", req.files.signatureImage);
        //     fileName = image.newfileName;
        // }
        // console.log(signature, "11111111")
        let savedSignature = {};
        if (id) {
            // Update existing signature
            const updateFields = {
                invoice: invoice || null,
                estimate: estimate || null,
                purchaseOrder: purchaseOrder || null,
                creditNote: creditNote || null,
                signature: signature || null,
                signatureData: signatureData || null,
                signatureText: signatureText || null,
                signatureType: signatureType || null,
                // signatureImage: fileName || null
            };
            await connection.InvoiceSignature.update(updateFields, { where: { id: id } });
            savedSignature = await connection.InvoiceSignature.findOne({
                where: { id: id }
            });
        } else {
            // Create new signature
            const uuid = crypto.randomUUID();
            const createData = {
                client_admin_id: userId,
                uuid,
                invoice: invoice || null,
                estimate: estimate || null,
                purchaseOrder: purchaseOrder || null,
                creditNote: creditNote || null,
                signature: signature || null,
                signatureData: signatureData || null,
                signatureText: signatureText || null,
                signatureType: signatureType || null,
                // signatureImage: fileName || null
            };
            savedSignature = await connection.InvoiceSignature.create(createData);
        }

        return res.status(200).json({
            status: true,
            message: "signature setting saved successfully.",
            data: savedSignature
        });
    }
    catch (error) {
        console.error("Error saving signature setting:", error);
        return res.status(500).json({
            status: false,
            message: "Internal server error.",
            data: {}
        });
    }
});

static getConnectionForClient = async (userId, mysqlConfig) => {
    try {
        // Fetch user and their database name
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return { error: 'User not found', connection: null };
        }

        const db_name = user.database_name;
        if (!db_name) {
            return { error: 'Please create your company first before accessing this resource.', connection: null };
        }

        // Establish connection
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        return { error: null, connection };
    } catch (err) {
        console.error("Error in getConnectionForClient:", err);
        return { error: 'Failed to establish a connection.', connection: null };
    }
};
}
module.exports = invoiceController;






