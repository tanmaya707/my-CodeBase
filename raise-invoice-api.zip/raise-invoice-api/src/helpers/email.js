const mailer = require("nodemailer");
const mailConfig = require("../config").Mail;

var smtpTransport = mailer.createTransport({
  host: mailConfig.host,
  port: mailConfig.port,
  secure: false,
  auth: mailConfig.auth,
});

const sendMail = async (email, cc, bcc, subject, filename, content, attachments = false) => {
  if (attachments) {
    // If attachments is an array, use it directly
    let att = [];
    if (Array.isArray(attachments) && attachments.length > 0) {
      att = attachments;
    } else {
      att = [
        {
          filename: filename,
          path: attachments,
        },
      ];
    }
    var mailContent = {
      from: {
        name: mailConfig.fromName,
        address: mailConfig.fromMail,
      },
      to: email,
      cc: cc,
      bcc: bcc,
      subject: subject,
      html: content,
      attachments: att,
    };
  } else {
    var mailContent = {
      from: {
        name: mailConfig.fromName,
        address: mailConfig.fromMail,
      },
      to: email,
      cc: cc,
      bcc: bcc,
      subject: subject,
      html: content,
    };
  }

  smtpTransport.sendMail(mailContent, function (error, response) {
    if (error) {
      console.log(error);
    } else {
      console.log(response.response);
      console.log("---------- Mail sent. ----------");
    }
  });

};

module.exports = sendMail;
