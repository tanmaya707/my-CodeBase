module.exports = (sequelize, DataTypes) => {
  const clientGaymentGatewaySchema = sequelize.define("client_gateways", {
    uuid: {
      type: DataTypes.STRING,
      allowNull: false,
    }, 
    name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    // fields: {
    //   type: DataTypes.TEXT("long"),
    //   allowNull: true,
    // },
    // paymentMode: {
    //   type: DataTypes.ENUM("sandbox", "live"), 
    //   allowNull: false, 
    //   defaultValue: "sandbox"
    // },
    apiKey : {
        type : DataTypes.STRING,
        allowNull : true
    },
    apiValue :{
        type : DataTypes.STRING,
        allowNull : true
    },
    isActive: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true, // true for Active, false for Inactive
      comment: "false-Inactive, true-Active",
    },
    createdAt: {
      field: "created_at",
      type: DataTypes.DATE,
    },
    updatedAt: {
      field: "updated_at",
      type: DataTypes.DATE,
    },
    deletedAt: {
      field: "deleted_at",
      type: DataTypes.DATE,
    },
  });
  return clientGaymentGatewaySchema;
};
