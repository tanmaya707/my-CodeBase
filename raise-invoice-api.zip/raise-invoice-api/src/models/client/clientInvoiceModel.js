module.exports = (sequelize, DataTypes) => {
    const clientInvoiceSchema = sequelize.define("invoices", {
        invoiceNumber : {
            type: DataTypes.STRING,
            allowNull: false,
        },
        client_id: {
            type: DataTypes.JSON,
            allowNull: false,
        },
        items: {
            type: DataTypes.JSON,
            allowNull: false,
        },        
        date: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        term: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        dueDate: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        subTotal: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        discount: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        gstTotal: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        total: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        paid: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        balance: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        paymentStatus: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        sentStatus: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        logo: {
            type: DataTypes.TEXT('long'),
            allowNull: true,
        },
        paymentInstruction : {
             type: DataTypes.STRING,
            allowNull: true,
        },
        comment : {
            type: DataTypes.STRING, 
            allowNull: true,
        },
        deposit :{
            type: DataTypes.JSON,
            allowNull: true,
        },
        attachments :{
            type: DataTypes.JSON,
            allowNull: true,
        },
        customInvoice :{
            type: DataTypes.JSON,
            allowNull: false,
        },
        customInvoiceOption : {
            type: DataTypes.JSON,
            allowNull: false,
        },
        createdAt: {
            field: "created_at",
            type: DataTypes.DATE,
        },
        updatedAt: {
            field: "updated_at",
            type: DataTypes.DATE,
        },
        deletedAt: {
            field: "deleted_at",
            type: DataTypes.DATE,
        },
    });

    return clientInvoiceSchema;
};
