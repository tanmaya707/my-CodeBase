module.exports = (sequelize, DataTypes) => {
    const expenseSchema = sequelize.define("expense", {
        uuid: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        clientId: {
            type: DataTypes.INTEGER,
            allowNull: true,
            defaultValue: null,
        },
        projectId: {
            type: DataTypes.INTEGER,
            allowNull: true,
            defaultValue: null,
          },
        date : {
            type: DataTypes.DATE,
            allowNull: true,
        },
        merchant : {
            type: DataTypes.STRING,
            allowNull: true,
        },
        catagory : {
            type: DataTypes.STRING,
            allowNull: true,
        },
        rate : {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        tax : {
            type: DataTypes.INTEGER,
            allowNull: true,
        },  
        tip : {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        description : {
            type: DataTypes.TEXT("long"),
            allowNull: true,
        },
        type : {
            type: DataTypes.STRING,
            allowNull: true,
        },
        SAC : {
            type: DataTypes.STRING,
            allowNull: true,
        },
        HSN : {
            type: DataTypes.STRING,
            allowNull: true,
        },
        status: {
            type: DataTypes.TINYINT,
            allowNull: true,
            defaultValue: 1,
            comment: '0 => in-active, 1 => active'
        },
        profileImage: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        createdAt: {
            field: "created_at",
            type: DataTypes.DATE,
        },
        updatedAt: {
            field: "updated_at",
            type: DataTypes.DATE,
        },
        deletedAt: {
            field: "deleted_at",
            type: DataTypes.DATE,
        }
    });

    // expenseSchema.associate = (models) => {
    //     expenseSchema.belongsTo(models.CompanyProject, {
    //       foreignKey: 'projectId',
    //       as: 'client_projects'
    //     });
    //   };
      return expenseSchema;
};
