module.exports = (sequelize, DataTypes) => {
  const planPricesSchema = sequelize.define("plan_prices", {
    plan_id: {
      type: DataTypes.INTEGER,
      references: {
        model: 'plans',
        key: 'id'
      },
      allowNull: false,
      unique: false
    },
    currency_id: {
      type: DataTypes.INTEGER,
      // references: {
      //   model: 'currencies',
      //   key: 'id'
      // },
      allowNull: false,
      unique: false
    },
    name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    interval: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    price: {
      type: DataTypes.DOUBLE,
      allowNull: false,
      defaultValue: 0
    },
    discount: {
      type: DataTypes.FLOAT,
      allowNull: false,
      defaultValue: 0
    },
    status: {
      type: DataTypes.TINYINT,
      allowNull: false,
      defaultValue: 1,
      comment: '0 => in-active, 1 => active'
    },
    createdAt: {
      field: "created_at",
      type: DataTypes.DATE,
    },
    updatedAt: {
      field: "updated_at",
      type: DataTypes.DATE,
    },
    deletedAt: {
      field: "deleted_at",
      type: DataTypes.DATE,
    },
  });
  return planPricesSchema;
};

