module.exports = (sequelize, DataTypes) => {
    const estimateSchema = sequelize.define("purchase_order", {
        poNumber : {
            type: DataTypes.STRING, 
            allowNull: true,
        },
        client: {
            type: DataTypes.JSON,
            allowNull: false,
        },
        items: {
            type: DataTypes.JSON,
            allowNull: false,
        },        
        subTotal: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        total: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        paymentStatus: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        sentStatus: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        status: {
            type: DataTypes.TINYINT,
            allowNull: false,
            defaultValue: 1,
            comment: '1: Pending, 2: Completed'
        },
        logo: {
            type: DataTypes.TEXT('long'),
            allowNull: true,
        },
        attachments :{
            type: DataTypes.JSON,
            allowNull: true,
        },
        comment : {
            type: DataTypes.STRING, 
            allowNull: true,
        },
        customInvoiceOption : {
            type: DataTypes.JSON,
            allowNull: false,   
        },
        customInvoice : {
            type: DataTypes.JSON,
            allowNull: false,
        },
        createdAt: {
            field: "created_at",
            type: DataTypes.DATE,
        },
        updatedAt: {
            field: "updated_at",
            type: DataTypes.DATE,
        },
        deletedAt: {
            field: "deleted_at",
            type: DataTypes.DATE,
        },
    });

    return estimateSchema;
};
