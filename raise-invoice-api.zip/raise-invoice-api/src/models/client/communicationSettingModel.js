
module.exports = (sequelize, DataTypes) => {
  const communicationsettingSchema = sequelize.define("communicationsetting", {
      sameEmail: {
        type: DataTypes.BOOLEAN,
        allowNull: true,
        defaultValue: true,
      },
      message : {
        type: DataTypes.TEXT('long'),
        allowNull: true,
      },
      cc : {
        type: DataTypes.STRING,
        allowNull: true,
      },
      bcc : {
        type: DataTypes.STRING,
        allowNull: true,
      },
      paymentReminder: {
          type: DataTypes.BOOLEAN,
          allowNull: true,
          defaultValue: true,
      },
      day3BeforeDueDate :{
          type: DataTypes.BOOLEAN,
          allowNull: true,
          defaultValue: true,
      },
      dueDate: {
          type: DataTypes.BOOLEAN,
          allowNull: true,
          defaultValue: true,
      },
      day3AfterDueDate :{
        type: DataTypes.BOOLEAN,
        allowNull: true,
        defaultValue: true,
      },
      day7AfterDueDate :{
        type: DataTypes.BOOLEAN,
        allowNull: true,
        defaultValue: true,
      },
      paymentNotification :{
        type: DataTypes.BOOLEAN,
        allowNull: true,
        defaultValue: true,
      },
      paymentReceipt :{
        type: DataTypes.BOOLEAN,
        allowNull: true,
        defaultValue: true,
      },
      email :{
        type: DataTypes.BOOLEAN,
        allowNull: true,
        defaultValue: true,
      },
      businessResource :{
        type: DataTypes.BOOLEAN,
        allowNull: true,
        defaultValue: true,
      },
      invoice2go :{
        type: DataTypes.BOOLEAN,
        allowNull: true,
        defaultValue: true,
      },
      productUpdate :{
        type: DataTypes.BOOLEAN,
        allowNull: true,
        defaultValue: true,
      },
      specialOffer :{
        type: DataTypes.BOOLEAN,
        allowNull: true,
        defaultValue: true,
      },
      createdAt: {
          field: "created_at",
          type: DataTypes.DATE,
      },
      updatedAt: {
          field: "updated_at",
          type: DataTypes.DATE,
      },
      deletedAt: {
          field: "deleted_at",
          type: DataTypes.DATE,
      },
  });
  return communicationsettingSchema;
};

