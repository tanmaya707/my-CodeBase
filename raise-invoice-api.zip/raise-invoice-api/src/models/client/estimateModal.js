module.exports = (sequelize, DataTypes) => {
    const estimateSchema = sequelize.define("estimate", {
        estimateNumber : {
            type: DataTypes.STRING, 
            allowNull: true,
        },
        client: {
            type: DataTypes.JSON,
            allowNull: false,
        },
        items: {
            type: DataTypes.JSON,
            allowNull: false,
        },        
        subTotal: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        discount: {
            type: DataTypes.JSON,
            allowNull: true,
        },
        total: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        paid: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        balance: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        paymentStatus: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        attachments :{
            type: DataTypes.JSON,
            allowNull: true,
        },
        sentStatus: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        status: {
            type: DataTypes.TINYINT,
            allowNull: false,
            defaultValue: 1,
            comment: '1: Pending, 2: Completed'
        },
        logo: {
            type: DataTypes.TEXT('long'),
            allowNull: true,
        },
        paymentInstruction : {
             type: DataTypes.STRING,
            allowNull: true,
        },
        note : {
            type: DataTypes.STRING, 
            allowNull: true,
        },
        customInvoice:{
            type: DataTypes.JSON,
            allowNull: true,
        },
        customInvoiceOption:{
            type: DataTypes.JSON,
            allowNull: true,
        },
        createdAt: {
            field: "created_at",
            type: DataTypes.DATE,
        },
        updatedAt: {
            field: "updated_at",
            type: DataTypes.DATE,
        },
        deletedAt: {
            field: "deleted_at",
            type: DataTypes.DATE,
        },
    });

    return estimateSchema;
};
