module.exports = (sequelize, DataTypes) => {
    const invoiceOptionSetting = sequelize.define("invoice_option_setting", {
        client_admin_id: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        shippingDetails: {
            type: DataTypes.BOOLEAN,
            allowNull: true,
        },
        due_date: {
            type: DataTypes.BOOLEAN,
            allowNull: true,
        },
        payment_terms: {
            type: DataTypes.BOOLEAN,
            allowNull: true,
        },
        itemCode: {
            type: DataTypes.BOOLEAN,
            allowNull: true,
        },
        quantityAndRate: {
            type: DataTypes.BOOLEAN,
            allowNull: true,
        },
        pTax: {
            type: DataTypes.BOOLEAN,
            allowNull: true,
        },
        tax_amounts: {
            type: DataTypes.BOOLEAN,
            allowNull: true,
        },
        includeSignatureLine: {
            type: DataTypes.BOOLEAN,
            allowNull: true,
        },
        invoicePrifix: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        createdAt: {
            field: "created_at",
            type: DataTypes.DATE,
        },
        updatedAt: {
            field: "updated_at",
            type: DataTypes.DATE,
        },
        deletedAt: {
            field: "deleted_at",
            type: DataTypes.DATE,
        }
    });

    return invoiceOptionSetting;
};
