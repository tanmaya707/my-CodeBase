module.exports = (sequelize, DataTypes) => {
  const projectTime = sequelize.define("project_time", {
     uuid: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    project_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    client_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    task_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    notes: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    // start_date: {
    //     type: DataTypes.DATE,
    //     allowNull: true,
    // },
    // end_date: {
    //     type: DataTypes.DATE,
    //     allowNull: true,
    // },
    start_time : {
        type : DataTypes.STRING,
        allowNull : true
    },
    end_time : {
        type : DataTypes.STRING,
        allowNull : true
    },
    createdAt: {
        field: "created_at",
        type: DataTypes.DATE,
    },
    updatedAt: {
        field: "updated_at",
        type: DataTypes.DATE,
    },
    deletedAt: {
        field: "deleted_at",
        type: DataTypes.DATE,
    }
  });

  return projectTime;
};


