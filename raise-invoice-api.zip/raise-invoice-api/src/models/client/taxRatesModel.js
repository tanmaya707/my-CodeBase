module.exports = (sequelize, DataTypes) => {
    const taxSchema = sequelize.define("tax", {
        uuid: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        client_id: {
            type: DataTypes.INTEGER,
            allowNull: true
        },
        client_admin_id: {
            type: DataTypes.INTEGER,
            allowNull: true
        },
        rate: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        percentage: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        createdAt: {
            field: "created_at",
            type: DataTypes.DATE,
        },
        updatedAt: {
            field: "updated_at",
            type: DataTypes.DATE,
        },
        deletedAt: {
            field: "deleted_at",
            type: DataTypes.DATE,
        }
    })

    return taxSchema;
};