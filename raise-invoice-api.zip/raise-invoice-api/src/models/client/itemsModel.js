module.exports = (sequelize, DataTypes) => {
    const itemsSchema = sequelize.define("items", {
        uuid: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        item_name: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        item_Description: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        rate: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        currency: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        qty: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        unit_code: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        tax: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        status: {
            type: DataTypes.TINYINT,
            allowNull: false,
            defaultValue: 1,
            comment: '0 => in-active, 1 => active'
        },
        createdAt: {
            field: "created_at",
            type: DataTypes.DATE,
        },
        updatedAt: {
            field: "updated_at",
            type: DataTypes.DATE,
        },
        deletedAt: {
            field: "deleted_at",
            type: DataTypes.DATE,
        }
    });

    return itemsSchema;
};
