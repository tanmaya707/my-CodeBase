module.exports = (sequelize, DataTypes) => {
  const userCompanySchema = sequelize.define("user_companies", {
    uuid: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    userId: {
      type: DataTypes.INTEGER,
      references: {
        model: 'clientadmins',
        key: 'id'
      },
      allowNull: false,
    },

    companyName: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    companyPhone: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    companyEmail: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    companyAddress: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    companyAddressInfo: {
      type: DataTypes.TEXT('long'),
      allowNull: true,
    },
    companyWebsite: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    companyInfo: {
      type: DataTypes.TEXT('long'),
      allowNull: true,
    },
    status: {
      type: DataTypes.TINYINT(4),
      allowNull: true,
    },
    legalBusinessName: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    businessAddress: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    businessPhone: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    noOfEmployee : {
      type: DataTypes.STRING,
      allowNull: true,
    },
    createdAt: {
      field: "created_at",
      type: DataTypes.DATE,
    },
    updatedAt: {
      field: "updated_at",
      type: DataTypes.DATE,
    },
    deletedAt: {
      field: "deleted_at",
      type: DataTypes.DATE,
    },
  });
  return userCompanySchema;
};
