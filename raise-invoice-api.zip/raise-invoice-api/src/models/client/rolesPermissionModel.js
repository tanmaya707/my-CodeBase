module.exports = (sequelize, DataTypes) => {
  const rolesPermissionsSchema = sequelize.define("rolespermissions", {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    roleId: {
      type: DataTypes.INTEGER,
      references: {
        model: 'roles',
        key: 'id'
      },
      allowNull: false,
      primaryKey: true, // Part of the composite primary key
    },
    permissionId: {
      type: DataTypes.INTEGER,
      references: {
        model: 'permissions',
        key: 'id'
      },
      allowNull: false,
      primaryKey: true, // Part of the composite primary key
    }
  });

  return rolesPermissionsSchema;
};