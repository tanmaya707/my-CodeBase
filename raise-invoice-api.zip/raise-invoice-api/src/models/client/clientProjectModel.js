module.exports = (sequelize, DataTypes) => {
    const clientProjectSchema = sequelize.define("client_projects", {
        uuid: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        client_id: {
            type: DataTypes.INTEGER,
            // references: {
            //     model: 'clients',
            //     key: 'id'
            // },
            allowNull: false
        },
        client_admin_id: {
            type: DataTypes.INTEGER,
            // references: {
            //     model: 'clientadmins',
            //     key: 'id'
            // },
            allowNull: true
        },
        project_name: {
            type: DataTypes.TEXT("long"),
            allowNull: true,
        },
        project_location: {
            type: DataTypes.TEXT("long"),
            allowNull: true,
        },
        latitude: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        longitude: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        project_desc: {
            type: DataTypes.TEXT("long"),
            allowNull: true,
        },
        start_date: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        end_date: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        status: {
            type: DataTypes.TINYINT,
            allowNull: false,
            defaultValue: 1,
            comment: '1: Pending, 2: In Progress, 3: Completed'
        },
        notes: {
            type: DataTypes.TEXT("long"),
            allowNull: true,
        },
        taskName: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        taskDescription: {
            type: DataTypes.TEXT("long"),
            allowNull: true,
        },
        taskStartDate: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        taskEndDate: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        taskPriority: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        createdAt: {
            field: "created_at",
            type: DataTypes.DATE,
        },
        updatedAt: {
            field: "updated_at",
            type: DataTypes.DATE,
        },
        deletedAt: {
            field: "deleted_at",
            type: DataTypes.DATE,
        },
    });

    clientProjectSchema.associate = (models) => {
        clientProjectSchema.hasOne(models.Expense, {
          foreignKey: 'projectId',
          as: 'project'
        });
      };

    return clientProjectSchema;
};