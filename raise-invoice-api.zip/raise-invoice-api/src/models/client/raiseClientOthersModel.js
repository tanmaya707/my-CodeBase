module.exports = (sequelize, DataTypes) => {
  const ClientOther = sequelize.define("clientotherdetails", {
    uuid: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    clientId: {
      type: DataTypes.INTEGER,
      references: {
        model: "clients",
        key: "id",
      },
      allowNull: true,
      defaultValue: null,
    },
    payment_term: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    tax_no: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    notes: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    createdAt: {
      field: "created_at",
      type: DataTypes.DATE,
    },
    updatedAt: {
      field: "updated_at",
      type: DataTypes.DATE,
    },
    deletedAt: {
      field: "deleted_at",
      type: DataTypes.DATE,
    },
  });

  ClientOther.associate = (models) => {
    ClientOther.belongsTo(models.Client, {
      foreignKey: 'clientId',
      as: 'client'
    });
  };

  return ClientOther;
};

