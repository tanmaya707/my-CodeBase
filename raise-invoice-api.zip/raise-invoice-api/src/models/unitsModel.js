module.exports = (sequelize, DataTypes) => {
    const unitsSchema = sequelize.define("units", {
        unit_name: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        unit_code: {
            type: DataTypes.STRING,
            allowNull: false,
            // unique: true,
        },
        symbol: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        status: {
            type: DataTypes.TINYINT,
            allowNull: false,
            defaultValue: 1,
            comment: '0 => in-active, 1 => active'
        },
        createdAt: {
            field: "created_at",
            type: DataTypes.DATE,
        },
        updatedAt: {
            field: "updated_at",
            type: DataTypes.DATE,
        },
        deletedAt: {
            field: "deleted_at",
            type: DataTypes.DATE,
        },
    });
    return unitsSchema;
};