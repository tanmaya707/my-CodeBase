module.exports = (sequelize, DataTypes) => {
  // ========================================================================
  // ---- this schema is intended to be used for PAYMENT GATEWAYS ONLY ----
  // ========================================================================
  const paymentGatewayFieldSchema = sequelize.define("payment_gateway_fields", {
    paymentGatewayId: {
      type: DataTypes.INTEGER,
      references: {
        model: "payment_gateways",
        key: "id",
      },
      allowNull: false,
    },
    fieldKey: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    fieldValue: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    isActive: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true, // true for Active, false for Inactive
      comment: "false-Inactive, true-Active",
    },
    createdAt: {
      field: "created_at",
      type: DataTypes.DATE,
    },
    updatedAt: {
      field: "updated_at",
      type: DataTypes.DATE,
    },
    deletedAt: {
      field: "deleted_at",
      type: DataTypes.DATE,
    },
  });
  return paymentGatewayFieldSchema;
};
