module.exports = (sequelize, DataTypes) => {
  const jobCategorySchema = sequelize.define("job_categories", {
    job_id: {
      type: DataTypes.INTEGER,
      references: {
        model: 'jobs',
        key: 'id'
      },
      allowNull: false, 
    },
    category_id: {
      type: DataTypes.INTEGER,
      references: {
        model: 'categories',
        key: 'id'
      },
      allowNull: false, 
    },
    createdAt: {
      field: "created_at",
      type: DataTypes.DATE,
    },
    updatedAt: {
      field: "updated_at",
      type: DataTypes.DATE,
    },
    deletedAt: {
      field: "deleted_at",
      type: DataTypes.DATE,
    },
  });
  return jobCategorySchema;
};

