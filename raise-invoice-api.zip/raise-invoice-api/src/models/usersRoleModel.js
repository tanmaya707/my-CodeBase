module.exports = (sequelize, DataTypes) => {
  const usersRolesSchema = sequelize.define("usersroles", {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    userId: {
      type: DataTypes.INTEGER,
      references: {
        model: 'users',
        key: 'id'
      },
      allowNull: false,
      primaryKey: true, // Part of the composite primary key
    },
    roleId: {
      type: DataTypes.INTEGER,
      references: {
        model: 'roles',
        key: 'id'
      },
      allowNull: false,
      primaryKey: true, // Part of the composite primary key
    }
  });

  return usersRolesSchema;
};
