const { TEXT } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
    const invoiceTemplateSchema = sequelize.define("invoicetemplate", {
      name : {
        type: DataTypes.STRING,
        allowNull: false,
      },
      text: {
        type: TEXT,
        allowNull: false,
      },
      createdAt: {
        field: "created_at",
        type: DataTypes.DATE,
      },
      updatedAt: {
        field: "updated_at",
        type: DataTypes.DATE,
      },
      deletedAt: {
        field: "deleted_at",
        type: DataTypes.DATE,
      },
    });
    return invoiceTemplateSchema;
  };
