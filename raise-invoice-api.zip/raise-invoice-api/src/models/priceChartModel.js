module.exports = (sequelize, DataTypes) => {
  const priceChartSchema = sequelize.define("pricechart", {
    vehicleTypeId: {
      type: DataTypes.INTEGER,
      // references: {
      //   model: 'vehicletypes',
      //   key: 'id'
      // },
      allowNull: false,
      // unique: true,
    },
    dailyParkingRate: { type: DataTypes.DOUBLE, required: true, defaultValue: 0 },
    overSizeRate: { type: DataTypes.DOUBLE, required: true, defaultValue: 0 },
    lateFees: { type: DataTypes.DOUBLE, required: true, defaultValue: 0 },

    createdAt: { field: "created_at", type: DataTypes.DATE, },
    updatedAt: { field: "updated_at", type: DataTypes.DATE, },

    isActive: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true, // true for Active, false for Inactive
      comment: "false-Inactive, true-Active",
    },
    deletedAt: { field: "deleted_at", type: DataTypes.DATE, },
  }, {
    indexes: [
      {unique:true, fields:['vehicleTypeId']}
    ]
  });

  return priceChartSchema;
};
