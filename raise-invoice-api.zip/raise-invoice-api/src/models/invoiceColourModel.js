module.exports = (sequelize, DataTypes) => {
    const colourSchema = sequelize.define("invoicecolour", {
        colourCode : {
            type: DataTypes.STRING,
            allowNull: true
        },
        createdAt: {
            field: "created_at",
            type: DataTypes.DATE,
        },
        updatedAt: {
            field: "updated_at",
            type: DataTypes.DATE,
        },
        deletedAt: {
            field: "deleted_at",
            type: DataTypes.DATE,
        }
    });

    return colourSchema;
};


