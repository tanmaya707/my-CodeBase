module.exports = (sequelize, DataTypes) => {
    const currencySchema = sequelize.define("exchange_rates", {
        currency_from: {
            type: DataTypes.INTEGER,
            references: {
                model: "currencies",
                key: "id",
            },
            allowNull: false,
        },
        currency_to: {
            type: DataTypes.INTEGER,
            references: {
                model: "currencies",
                key: "id",
            },
            allowNull: false,
        },
        converter_amount: { 
            type: DataTypes.DOUBLE, 
            allowNull: false, 
            defaultValue: 1 
        },
        exchange_rate: { 
            type: DataTypes.DOUBLE, 
            allowNull: false, 
            defaultValue: 0 
        },
        createdAt: {
            field: "created_at",
            type: DataTypes.DATE,
        },
        updatedAt: {
            field: "updated_at",
            type: DataTypes.DATE,
        },
        deletedAt: {
            field: "deleted_at",
            type: DataTypes.DATE,
        },
    });
    return currencySchema;
};