module.exports = (sequelize, DataTypes) => {
    const unitsSchema = sequelize.define("timeunits", {
        time_units: {
            type: DataTypes.STRING,
            allowNull: false,
            // unique: true,
        },
        status: {
            type: DataTypes.TINYINT,
            allowNull: false,
            defaultValue: 1,
            comment: '0 => in-active, 1 => active'
        },
        createdAt: {
            field: "created_at",
            type: DataTypes.DATE,
        },
        updatedAt: {
            field: "updated_at",
            type: DataTypes.DATE,
        },
        deletedAt: {
            field: "deleted_at",
            type: DataTypes.DATE,
        },
    });
    return unitsSchema;
};