// Project Setting Model
module.exports = (sequelize, DataTypes) => {
const projectSettingSchema = sequelize.define("signaturesetting", {
    client_admin_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    uuid: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    invoice: {
        type: DataTypes.BOOLEAN,
        allowNull: true,
        defaultValue: true,
    },
    estimate: {
        type: DataTypes.BOOLEAN,
        allowNull: true,
        defaultValue: true,
    },
    purchaseOrder: {
        type: DataTypes.BOOLEAN,
        allowNull: true,
        defaultValue: true,
    },
    creditNote: {
        type: DataTypes.BOOLEAN,
        allowNull: true,
        defaultValue: true,
    },
    signature: { 
        type: DataTypes.TEXT('long'),
        allowNull: true,
    },
    signatureData: { 
        type: DataTypes.TEXT('long'),
        allowNull: true, 
    },
    signatureText : { type: DataTypes.STRING, allowNull: true },
    signatureType : { type: DataTypes.STRING, allowNull: true },
    createdAt: {
        field: "created_at",
        type: DataTypes.DATE,
    },
    updatedAt: {
        field: "updated_at",
        type: DataTypes.DATE,
    },
    deletedAt: {
        field: "deleted_at",
        type: DataTypes.DATE,
    },
});
  return projectSettingSchema;
};

