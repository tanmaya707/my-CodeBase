module.exports = (sequelize, DataTypes) => {
const xeroOauthState = sequelize.define("xero_oauth_state", {
    state: {
        type: DataTypes.STRING,
        primaryKey: true,
        allowNull: false,
    },
    user_id: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    redirect_url: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
});
return xeroOauthState;
};
