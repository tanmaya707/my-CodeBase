module.exports = (sequelize, DataTypes) => {
    const headerSchema = sequelize.define("invoiceheader", {
        headerImg : {
            type: DataTypes.STRING,
            allowNull: true,
        },
        createdAt: {
            field: "created_at",
            type: DataTypes.DATE,
        },
        updatedAt: {
            field: "updated_at",
            type: DataTypes.DATE,
        },
        deletedAt: {
            field: "deleted_at",
            type: DataTypes.DATE,
        }
    });

    return headerSchema;
};
