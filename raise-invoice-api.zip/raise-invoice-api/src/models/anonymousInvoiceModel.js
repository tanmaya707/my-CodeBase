module.exports = (sequelize, DataTypes) => {
  const anonymous_invoice = sequelize.define("anonymous_invoice", {
    uuid: { type: DataTypes.STRING, allowNull: false },
    ip: { type: DataTypes.STRING, allowNull: true },
    logo: { type: DataTypes.JSON, defaultValue: {}, allowNull: true },
    from: { type: DataTypes.JSON, allowNull: true },
    billTo: { type: DataTypes.JSON, allowNull: true },
    number: { type: DataTypes.STRING, allowNull: true },
    date: { type: DataTypes.STRING, allowNull: true },
    due: { type: DataTypes.STRING, allowNull: true },
    items: { type: DataTypes.JSON, allowNull: true },
    notes: { type: DataTypes.STRING, allowNull: true },
    signature: { type: DataTypes.STRING, allowNull: true },
    signatureData: { type: DataTypes.JSON, allowNull: true },
    signatureText : { type: DataTypes.STRING, allowNull: true },
    signatureType : { type: DataTypes.STRING, allowNull: true },
    taxRate: { type: DataTypes.FLOAT, allowNull: true },
    taxInclusive: { type: DataTypes.BOOLEAN, allowNull: true },
    discountType: { type: DataTypes.STRING, allowNull: true },
    discountValue: { type: DataTypes.FLOAT, allowNull: true },
    currency: { type: DataTypes.STRING, allowNull: true },
    color: { type: DataTypes.STRING, allowNull: true },
    taxLabel: { type: DataTypes.STRING, allowNull: true },
    createdAt: { field: "created_at", type: DataTypes.DATE },
    updatedAt: { field: "updated_at", type: DataTypes.DATE },
    deletedAt: { field: "deleted_at", type: DataTypes.DATE },
  }, {
    paranoid: true,
    underscored: true,
    tableName: "anonymous_invoice"
  });
  return anonymous_invoice;
};
