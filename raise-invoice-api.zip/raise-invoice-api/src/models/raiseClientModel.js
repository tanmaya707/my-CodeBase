module.exports = (sequelize, DataTypes) => {
  const Client = sequelize.define("clients", {
    uuid: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    email: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    address : {
      type: DataTypes.STRING,
      allowNull: true,

    },
    alt_email: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    dialCode: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    phone: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    profileImage: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    isActive: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true, // true for Active, false for Inactive
      comment: "false-Inactive, true-Active",
    },
    isVerified: {
      type: DataTypes.BOOLEAN,
      allowNull: true,
      defaultValue: true, // false for No, true for Yes
      comment: "false-No, true-Yes",
    },
    createdAt: {
      field: "created_at",
      type: DataTypes.DATE,
    },
    updatedAt: {
      field: "updated_at",
      type: DataTypes.DATE,
    },
    created_by: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    deleted_by: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    deletedAt: {
      field: "deleted_at",
      type: DataTypes.DATE,
    },
  });

  Client.associate = (models) => {
    Client.hasOne(models.ClientContact, {
      foreignKey: 'clientId',
      as: 'contacts'
    });
    Client.hasOne(models.ClientOther, {
      foreignKey: 'clientId',
      as: 'otherDetails'
    });
  };
  return Client;
};

