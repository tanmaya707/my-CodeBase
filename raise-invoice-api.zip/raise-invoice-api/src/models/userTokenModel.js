module.exports = (sequelize, DataTypes) => {
  const userTokensSchema = sequelize.define("usertokens", {
    userId: {
      type: DataTypes.INTEGER,
      references: {
        model: "users",
        key: "id",
      },
      allowNull: false,
    },
    webLogin: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    appLogin: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    fcmToken: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    macAddress: {
      type: DataTypes.STRING,
      allowNull: true,
      defaultValue: null,
      comment: "MAC Address of Currently Logged In Device",
    },
    deviceId: {
      type: DataTypes.TEXT,
      allowNull: true,
      defaultValue: null,
      comment: "Device ID of device being used."
    },

    loginFlag: {
      type: DataTypes.BOOLEAN,
      allowNull: true,
      defaultValue: false, // false for Offline, true for Online
      comment: "false-Off, true-On",
    },
    createdAt: {
      field: "created_at",
      type: DataTypes.DATE,
    },
    updatedAt: {
      field: "updated_at",
      type: DataTypes.DATE,
    },
    deletedAt: {
      field: "deleted_at",
      type: DataTypes.DATE,
    },
  });
  return userTokensSchema;
};
