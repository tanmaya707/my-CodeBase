module.exports = (sequelize, DataTypes) => {
const xeroToken = sequelize.define("xero_tokens", {
        user_id: {
            type: DataTypes.INTEGER,
            allowNull: true
        },
        access_token: {
            type: DataTypes.TEXT,
            allowNull: true
        },
        refresh_token: {
            type: DataTypes.TEXT,
            allowNull: true
        },
        expires_at: {
            type: DataTypes.DATE,
            allowNull: true
        },
        tenant_id: {
            type: DataTypes.STRING,
            allowNull: false
        },
        tenant_name: {
            type: DataTypes.STRING,
            allowNull: true
        },
        connected: {
            type: DataTypes.BOOLEAN,
            defaultValue: true
        },
        connected_at: {
            type: DataTypes.DATE,
            defaultValue: DataTypes.NOW
        },
        last_sync: {
            type: DataTypes.DATE,
            allowNull: true
        },
        created_at: {
            type: DataTypes.DATE,
            defaultValue: DataTypes.NOW
        },
        updated_at: {
            type: DataTypes.DATE,
            defaultValue: DataTypes.NOW
        }
});
return xeroToken;
};

