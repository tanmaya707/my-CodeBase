module.exports = (sequelize, DataTypes) => {
    const XeroUser = sequelize.define("xero_user", {
        client_id: {
            type: DataTypes.STRING,
            allowNull: false
        },
        userId: {
            type: DataTypes.STRING,
            allowNull: false
        },
        redirect_uri: {
            type: DataTypes.TEXT,
            allowNull: false
        },
        created_at :{
            type: DataTypes.DATE,
            defaultValue: DataTypes.NOW
        },
        updated_at :{
            type: DataTypes.DATE,
            defaultValue: DataTypes.NOW
        }

    });
    return XeroUser;
};