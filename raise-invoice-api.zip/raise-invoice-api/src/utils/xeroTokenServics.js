const { createXeroClient } = require('../config/xeroConfig');

class XeroTokenService {
    constructor(userId) {
        this.userId = userId;
        this.xero = createXeroClient();
    }

    async setTokens(tokenSet, connection = null) {
        console.log('Setting tokens for user:', tokenSet);
        try {

            // Get the first tenant if multiple tenants exist
            const tenantId = tokenSet.tenants?.[0]?.tenantId || 'Unknown';
            const tenantName = tokenSet.tenants?.[0]?.tenantName || 'Unknown';

            // Convert expires_at to JS Date
            const expiresAt = new Date(tokenSet.expires_at * 1000);

            // Upsert emulation: update if exists, otherwise create
            const existing = await connection.XeroToken.findOne({
                where: { user_id: this.userId }
            });

            if (existing) {
                await connection.XeroToken.update({
                    access_token: tokenSet.access_token,
                    refresh_token: tokenSet.refresh_token,
                    expires_at: expiresAt,
                    tenant_id: tenantId,
                    tenant_name: tenantName,
                    connected: true,
                    updated_at: new Date(),
                    // preserve original connected_at if present
                    connected_at: existing.connected_at || new Date()
                }, {
                    where: { user_id: this.userId }
                });
            } else {
                await connection.XeroToken.create({
                    user_id: this.userId,
                    access_token: tokenSet.access_token,
                    refresh_token: tokenSet.refresh_token,
                    expires_at: expiresAt,
                    tenant_id: tenantId,
                    tenant_name: tenantName,
                    connected: true,
                    connected_at: new Date(),
                    updated_at: new Date()
                });
            }

            return {
                access_token: tokenSet.access_token,
                refresh_token: tokenSet.refresh_token,
                expires_at: expiresAt,
                tenantId: tenantId,
                connected: true
            };
        } catch (error) {
            console.log('Error setting Xero tokens:', error);
            // console.error('Error setting Xero tokens:', error);
            throw error;
        }
    }

    async getTokens(connection) {

        try {
            const token = await connection.XeroToken.findOne({
                where: {
                    user_id: this.userId,
                    connected: true
                }
            });

            console.log('Fetching tokens for user:', token);

            if (!token) {
                return null;
            }

            return {
                access_token: token.access_token,
                refresh_token: token.refresh_token,
                expires_at: token.expires_at,
                tenantId: token.tenant_id,
                tenantName: token.tenant_name,
                connected: token.connected
            };
        } catch (error) {
            console.error('Error getting Xero tokens:', error);
            throw error;
        }
    }

    async isConnected(connection) {
        const tokens = await this.getTokens(connection);
        console.log("tokens in isConnected:", tokens);
        return tokens?.connected && tokens.access_token;
    }

    async refreshTokensIfNeeded(connection) {
        let tokens = await this.getTokens(connection);

        if (!tokens) {
            throw new Error('Xero not connected');
        }

        // Check if token needs refresh (5 minute buffer)
        const shouldRefresh = Date.now() > (new Date(tokens.expires_at).getTime() - 300000);

        console.log('Token refresh needed:', shouldRefresh);

        if (shouldRefresh) {
            try {
                console.log('Refreshing Xero tokens for user:', this.userId);

                console.log(this.xero, "Xero client before refresh");

                // Use the Xero client to refresh tokens
                const newTokenSet = await this.xero.refreshWithRefreshToken(
                    process.env.CLIENT_ID,
                    process.env.CLIENT_SECRET,
                    tokens.refresh_token
                );

                console.log('New token set received:', newTokenSet);

                // Update tokens in database
                tokens = await this.setTokens(newTokenSet, connection);

                console.log('Tokens refreshed successfully');
            } catch (refreshError) {
                console.error('Token refresh failed:', refreshError);

                // Mark as disconnected if refresh fails
                await this.disconnect();
                throw new Error('Token refresh failed. Please reconnect Xero.');
            }
        }

        // Set the tokens on the Xero client instance
        this.xero.setTokenSet({
            access_token: tokens.access_token,
            refresh_token: tokens.refresh_token,
            expires_at: Math.floor(new Date(tokens.expires_at).getTime() / 1000),
            tenantId: tokens.tenantId
        });

        return tokens;
    }
    

    async disconnect(connection) {
        try {
            await connection.XeroToken.update(
                { connected: false, updated_at: new Date() },
                { where: { user_id: this.userId } }
            );
        } catch (error) {
            console.error('Error disconnecting Xero:', error);
            throw error;
        }
    }

    async getLastSync(connection) {
        try {
            const token = await connection.XeroToken.findOne({
                where: { user_id: this.userId }
            });
            return token ? token.last_sync : null;
        } catch (error) {
            console.error('Error getting last sync:', error);
            return null;
        }
    }

    async updateLastSync(connection) {
        try {
            const now = new Date();
            await connection.XeroToken.update(
                { last_sync: now },
                { where: { user_id: this.userId } }
            );

            const token = await connection.XeroToken.findOne({
                where: { user_id: this.userId },
                attributes: ['last_sync']
            });

            return token ? token.last_sync : null;
        } catch (error) {
            console.error('Error updating last sync:', error);
            return null;
        }
    }
}

module.exports = XeroTokenService;
