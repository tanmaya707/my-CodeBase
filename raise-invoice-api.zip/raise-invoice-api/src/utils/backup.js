async function createDatabase(db_name, updateFields, updateCompanyFields) {
    // const sequelize = new Sequelize('mysql://root:@localhost:3306', {
    //     dialect: 'mysql',
    //     logging: false
    // });
    console.log(db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host);

    const sequelize = new Sequelize(`mysql://${mysqlConfig.user}:${mysqlConfig.pwd}@${mysqlConfig.host}:3306`, {
        dialect: 'mysql',
        logging: false
    });

    // console.log(sequelize);

    // await sequelize.authenticate();
    // console.log("Connected!");


    try {
        await sequelize.authenticate();
        console.log("Connected!");

        // await sequelize.query(`CREATE DATABASE \`${db_name}\``);
        // Step 1: Check if the database exists
        const dbExists = await sequelize.query(`SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '${db_name}'`);

        if (dbExists[0].length > 0) {
            // Step 2: If it exists, drop the database
            await sequelize.query(`DROP DATABASE \`${db_name}\`;`);
        }

        // Step 3: Create the new database
        await sequelize.query(`CREATE DATABASE \`${db_name}\`;`);
        console.log("Database created");

        // Connect to the new database
        const sequelize2 = new Sequelize(db_name, mysqlConfig.user, mysqlConfig.pwd, {
            host: process.env.DB_HOST || 'localhost',
            port: 3306,
            dialect: 'mysql',
            logging: false
        });

        // Define some tables (e.g., Users, Orders)
        const User = sequelize2.define('clientadmins', {
            uuid: { type: DataTypes.STRING, allowNull: false },
            name: { type: DataTypes.STRING, allowNull: false },
            email: {
                type: DataTypes.STRING,
                allowNull: false,
            },
            dialCode: {
                type: DataTypes.STRING,
                allowNull: true,
            },
            phone: {
                type: DataTypes.STRING,
                allowNull: true,
            },
            password: {
                type: DataTypes.STRING,
                allowNull: true,
            },
            dob: {
                type: DataTypes.DATEONLY,
                allowNull: true,
            },
            gender: {
                type: DataTypes.ENUM("Male", "Female", "Others"),
                allowNull: true,
                defaultValue: "Others",
            },
            profileImage: {
                type: DataTypes.STRING,
                allowNull: true,
            },
            address: {
                type: DataTypes.TEXT("medium"),
                allowNull: true,
            },

            webLogin: {
                type: DataTypes.TEXT,
                allowNull: true,
            },
            appLogin: {
                type: DataTypes.TEXT,
                allowNull: true,
            },
            fcmToken: {
                type: DataTypes.STRING,
                allowNull: true,
            },
            OTP: {
                type: DataTypes.INTEGER,
                allowNull: true,
            },
            resetToken: {
                type: DataTypes.STRING,
                allowNull: true,
            },
            macAddress: {
                type: DataTypes.STRING,
                allowNull: true,
                defaultValue: null,
                comment: "MAC Address of Currently Logged In Device",
            },
            deviceId: {
                type: DataTypes.STRING,
                allowNull: true,
                defaultValue: null,
                comment: "Device ID of device being used; For mobile devices only."
            },
            database_name: {
                type: DataTypes.STRING,
                allowNull: false
            },
            loginFlag: {
                type: DataTypes.BOOLEAN,
                allowNull: true,
                defaultValue: false, // false for Offline, true for Online
                comment: "false-Off, true-On",
            },
            isActive: {
                type: DataTypes.BOOLEAN,
                allowNull: false,
                defaultValue: true, // true for Active, false for Inactive
                comment: "false-Inactive, true-Active",
            },
            isVerified: {
                type: DataTypes.BOOLEAN,
                allowNull: false,
                defaultValue: false, // false for No, true for Yes
                comment: "false-No, true-Yes",
            },
            createdAt: {
                field: "created_at",
                type: DataTypes.DATE,
            },
            updatedAt: {
                field: "updated_at",
                type: DataTypes.DATE,
            },

            deleted_by: {
                type: DataTypes.INTEGER,
                allowNull: true,
            },
            deletedAt: {
                field: "deleted_at",
                type: DataTypes.DATE,
            }
        });

        /*******************************************************************************************************/
        const rolesSchema = sequelize2.define("roles", {
            uuid: {
                type: DataTypes.STRING,
                allowNull: false,
            },
            roleName: {
                type: DataTypes.STRING,
                allowNull: false,
            },
            roleSlug: {
                type: DataTypes.STRING,
                allowNull: false,
            },
            status: {
                type: DataTypes.TINYINT,
                allowNull: false,
                defaultValue: 1,
                comment: '0 => in-active, 1 => active'
            },
            order: {
                type: DataTypes.INTEGER,
                allowNull: true,
                defaultValue: 0,
            },
            createdAt: {
                field: "created_at",
                type: DataTypes.DATE,
            },
            updatedAt: {
                field: "updated_at",
                type: DataTypes.DATE,
            },
            deletedAt: {
                field: "deleted_at",
                type: DataTypes.DATE,
            },
        });

        const modulesSchema = sequelize2.define("modules", {
            uuid: {
                type: DataTypes.STRING,
                allowNull: true,
            },
            parentModuleId: {
                type: DataTypes.INTEGER,
                references: {
                    model: 'modules',
                    key: 'id'
                },
                allowNull: true,  // Allow null if a module has no parent
            },
            moduleName: {
                type: DataTypes.STRING,
                allowNull: false,
            },
            moduleSlug: {
                type: DataTypes.STRING,
                allowNull: false,
            },
            moduleIcon: {
                type: DataTypes.STRING,
                allowNull: true,
            },
            status: {
                type: DataTypes.TINYINT,
                allowNull: false,
                defaultValue: 1,
                comment: '0 => in-active, 1 => active'
            },
            order: {
                type: DataTypes.INTEGER,
                allowNull: true,
                defaultValue: 0,
            },
            createdAt: {
                field: "created_at",
                type: DataTypes.DATE,
            },
            updatedAt: {
                field: "updated_at",
                type: DataTypes.DATE,
            },

            deletedAt: {
                field: "deleted_at",
                type: DataTypes.DATE,
            },
        });

        const permissionsSchema = sequelize2.define("permissions", {
            moduleId: {
                type: DataTypes.INTEGER,
                references: {
                    model: 'modules',
                    key: 'id'
                },
                allowNull: false,
            },
            name: {
                type: DataTypes.STRING,
                allowNull: false,
            },
            slug: {
                type: DataTypes.STRING,
                allowNull: false,
            },
            createdAt: {
                field: "created_at",
                type: DataTypes.DATE,
            },
            updatedAt: {
                field: "updated_at",
                type: DataTypes.DATE,
            },
            deletedAt: {
                field: "deleted_at",
                type: DataTypes.DATE,
            },
        });

        const rolesPermissionsSchema = sequelize2.define("rolespermissions", {
            id: {
                type: DataTypes.INTEGER,
                primaryKey: true,
                autoIncrement: true,
            },
            roleId: {
                type: DataTypes.INTEGER,
                references: {
                    model: 'roles',
                    key: 'id'
                },
                allowNull: false,
                primaryKey: true, // Part of the composite primary key
            },
            permissionId: {
                type: DataTypes.INTEGER,
                references: {
                    model: 'permissions',
                    key: 'id'
                },
                allowNull: false,
                primaryKey: true, // Part of the composite primary key
            }
        });

        const usersRolesSchema = sequelize2.define("usersroles", {
            id: {
                type: DataTypes.INTEGER,
                primaryKey: true,
                autoIncrement: true,
            },
            userId: {
                type: DataTypes.INTEGER,
                references: {
                    model: 'clientadmins',
                    key: 'id'
                },
                allowNull: false,
                primaryKey: true, // Part of the composite primary key
            },
            roleId: {
                type: DataTypes.INTEGER,
                references: {
                    model: 'roles',
                    key: 'id'
                },
                allowNull: false,
                primaryKey: true, // Part of the composite primary key
            }
        });

        const usersPermissionsSchema = sequelize2.define("userspermissions", {
            id: {
                type: DataTypes.INTEGER,
                primaryKey: true,
                autoIncrement: true,
            },
            userId: {
                type: DataTypes.INTEGER,
                references: {
                    model: 'clientadmins',
                    key: 'id'
                },
                allowNull: false,
                primaryKey: true, // Part of the composite primary key
            },
            permissionId: {
                type: DataTypes.INTEGER,
                references: {
                    model: 'permissions',
                    key: 'id'
                },
                allowNull: false,
                primaryKey: true, // Part of the composite primary key
            }
        });

        /*******************************************************************************************************/

        const UserCompany = sequelize2.define("user_companies", {
            uuid: {
                type: DataTypes.STRING,
                allowNull: false,
            },
            userId: {
                type: DataTypes.INTEGER,
                references: {
                    model: 'clientadmins',
                    key: 'id'
                },
                allowNull: false,
            },
            companyName: {
                type: DataTypes.STRING,
                allowNull: false,
            },
            companyPhone: {
                type: DataTypes.STRING,
                allowNull: true,
            },
            companyEmail: {
                type: DataTypes.STRING,
                allowNull: false,
            },
            companyAddress: {
                type: DataTypes.STRING,
                allowNull: true,
            },
            companyAddressInfo: {
                type: DataTypes.TEXT('long'),
                allowNull: true,
            },
            companyWebsite: {
                type: DataTypes.STRING,
                allowNull: true,
            },
            companyInfo: {
                type: DataTypes.TEXT('long'),
                allowNull: true,
            },
            status: {
                type: DataTypes.TINYINT(4),
                allowNull: true,
            },
            createdAt: {
                field: "created_at",
                type: DataTypes.DATE,
            },
            updatedAt: {
                field: "updated_at",
                type: DataTypes.DATE,
            },
            deletedAt: {
                field: "deleted_at",
                type: DataTypes.DATE,
            },
        });

        await sequelize2.sync();

        var uuid = crypto.randomUUID();
        const role = await rolesSchema.create({
            uuid: uuid,
            roleName: "Super Admin",
            roleSlug: "super-admin"
        });
        // var uuid2 = crypto.randomUUID();
        const module = await modulesSchema.create({
            uuid: uuid,
            moduleName: 'User',
            moduleSlug: 'user'
        });
        // const permission = await permissionsSchema.create({
        //     uuid: updateFields.uuid,
        //     name: updateFields.name ?? updateFields.firstName
        // });

        // Insert data into the User table
        const user = await User.create({
            uuid: updateFields.uuid,
            name: updateFields.name ?? updateFields.firstName,
            email: updateFields.email,
            phone: updateFields.phone,
            password: updateFields.password,
            database_name: db_name,
            isVerified: true
        });
        const userCompany = await UserCompany.create({
            uuid: updateCompanyFields.uuid,
            userId: user.id,
            companyName: updateCompanyFields.companyName,
            companyAddress: updateCompanyFields.companyAddress,
            companyPhone: updateCompanyFields.companyPhone,
            companyEmail: updateCompanyFields.companyEmail,
            companyWebsite: updateCompanyFields.companyWebsite,
            companyInfo: updateCompanyFields.companyInfo,
        });

        let roleDetails = await roleModel.findOne({
            where: {
                roleSlug: "super-admin",
                deletedAt: null,
            }
        });
        await usersRolesSchema.create({ userId: parseInt(user.id), roleId: roleDetails.id });
        // console.log('User  created:', user.toJSON());
        // console.log(`Tables created in database ${db_name}`);

    } catch (err) {
        console.error("Error: ", err);
    } finally {
        await sequelize.close();
    }
}

async function getConnectedSpecificDB(dbName) {
    // const sequelize = new Sequelize(`mysql://root:@localhost:3306/${dbName}`, {
    //     dialect: 'mysql',
    //     logging: false
    // });
    console.log(dbName, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host);

    const sequelize = new Sequelize(dbName, mysqlConfig.user, mysqlConfig.pwd, {
        dialect: 'mysql',
        host: mysqlConfig.host,
        port: 3306
    });

    try {
        // Test the connection
        await sequelize.authenticate();
        console.log(`Connection to the database ${dbName} has been established successfully.`);
        return sequelize;
    } catch (error) {
        console.error('Unable to connect to the database:', error);
        throw error; // Rethrow the error for further handling
    }
}