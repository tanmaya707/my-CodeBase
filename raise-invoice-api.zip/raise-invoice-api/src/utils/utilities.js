const crypto = require('crypto');
const axios = require('axios');
const FirebaseAdmin = require('firebase-admin');

const mysqlConfig = require("../config/index").Mysql;

const RequestHandler = require("../utils/RequestHandler");
const requestHandler = new RequestHandler();

const mysql = require('mysql2/promise');
const { Sequelize, DataTypes } = require('sequelize');

const db = require("../models");
const userModel = db.Users;
const clientAdminModel = db.Clients;
// const clientAdminModel = db.clientAdminModel;
const roleModel = db.Roles;


const { connectSpecificToDatabase } = require("../config/specificConnect");
const { response } = require('express');

// var FCMServiceAccount = require('../config/serviceAccountKey.json');

// const FCM = FirebaseAdmin.initializeApp({
//     credential: FirebaseAdmin.credential.cert(FCMServiceAccount),
// });

const dateFormat = (date) => {
    return new Date(date).getFullYear() + '-' + (new Date(date).getMonth() + 1).toString().padStart(2, '0') + '-' + new Date(date).getDate().toString().padStart(2, '0')
}
const dateFormatDDMMYYYY = (dateToBeFormatted) => {
    let date =
        new Date().getDate().toString().padStart(2, "0") +
        "-" +
        (new Date().getMonth() + 1).toString().padStart(2, "0") +
        "-" +
        new Date().getFullYear();

    if (dateToBeFormatted != "") {
        date =
            new Date(dateToBeFormatted).getDate().toString().padStart(2, "0") +
            "-" +
            (new Date(dateToBeFormatted).getMonth() + 1).toString().padStart(2, "0") +
            "-" +
            new Date(dateToBeFormatted).getFullYear();
    }
    return date;
};
const dateFormatYYYYMMDD = (dateToBeFormatted) => {
    let date =
        new Date().getFullYear() +
        "-" +
        (new Date().getMonth() + 1).toString().padStart(2, "0") +
        "-" +
        new Date().getDate().toString().padStart(2, "0");

    if (dateToBeFormatted != "") {
        date =
            new Date(dateToBeFormatted).getFullYear() +
            "-" +
            (new Date(dateToBeFormatted).getMonth() + 1).toString().padStart(2, "0") +
            "-" +
            new Date(dateToBeFormatted).getDate().toString().padStart(2, "0");
    }
    return date;
};
const fullDatetimeFormat = (dateToBeFormatted) => {
    var date =
        new Date().getFullYear() +
        "-" +
        (new Date().getMonth() + 1).toString().padStart(2, "0") +
        "-" +
        new Date().getDate().toString().padStart(2, "0") +
        " " +
        new Date().getHours().toString().padStart(2, "0") +
        ":" +
        new Date().getMinutes().toString().padStart(2, "0") +
        ":" +
        new Date().getSeconds().toString().padStart(2, "0");

    if (dateToBeFormatted != "") {
        date =
            new Date(dateToBeFormatted).getFullYear() +
            "-" +
            (new Date(dateToBeFormatted).getMonth() + 1).toString().padStart(2, "0") +
            "-" +
            new Date(dateToBeFormatted).getDate().toString().padStart(2, "0") +
            " " +
            new Date(dateToBeFormatted).getHours().toString().padStart(2, "0") +
            ":" +
            new Date(dateToBeFormatted).getMinutes().toString().padStart(2, "0") +
            ":" +
            new Date(dateToBeFormatted).getSeconds().toString().padStart(2, "0");
    }
    return date;
};
const fullDatetimeFormatYYYYMMDDHHMMSS = (dateToBeFormatted) => {
    var date =
        new Date().getFullYear() +
        "-" +
        (new Date().getMonth() + 1).toString().padStart(2, "0") +
        "-" +
        new Date().getDate().toString().padStart(2, "0") +
        " " +
        new Date().getHours().toString().padStart(2, "0") +
        ":" +
        new Date().getMinutes().toString().padStart(2, "0") +
        ":" +
        new Date().getSeconds().toString().padStart(2, "0");

    if (dateToBeFormatted != "") {
        date =
            new Date().getFullYear() +
            "-" +
            (new Date().getMonth() + 1).toString().padStart(2, "0") +
            "-" +
            new Date().getDate().toString().padStart(2, "0") +
            " " +
            new Date().getHours().toString().padStart(2, "0") +
            ":" +
            new Date().getMinutes().toString().padStart(2, "0") +
            ":" +
            new Date().getSeconds().toString().padStart(2, "0");
    }
    return date;
};
const fullDatetimeFormatDDMMYYYYHHIIAA = (dateToBeFormatted) => {
    var date =
        new Date().getFullYear() +
        "-" +
        (new Date().getMonth() + 1).toString().padStart(2, "0") +
        "-" +
        new Date().getDate().toString().padStart(2, "0") +
        " " +
        new Date().getHours().toString().padStart(2, "0") +
        ":" +
        new Date().getMinutes().toString().padStart(2, "0") +
        ":" +
        new Date().getSeconds().toString().padStart(2, "0");

    if (dateToBeFormatted != "") {
        date =
            new Date(dateToBeFormatted).getDate().toString().padStart(2, "0") +
            "-" +
            (new Date(dateToBeFormatted).getMonth() + 1).toString().padStart(2, "0") +
            "-" +
            new Date(dateToBeFormatted).getFullYear() +
            " " +
            convertTime24To12(
                new Date(dateToBeFormatted).getHours().toString().padStart(2, "0") +
                ":" +
                new Date(dateToBeFormatted).getMinutes().toString().padStart(2, "0") +
                ":" +
                new Date(dateToBeFormatted).getSeconds().toString().padStart(2, "0")
            );
    }
    return date;
};
const convertTime24To12 = (time) => {
    time = time.toString().match(/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [
        time,
    ];

    if (time.length > 1) {
        // If time format correct
        time = time.slice(1); // Remove full string match value
        time[5] = +time[0] < 12 ? " AM" : " PM"; // Set AM/PM
        time[0] = +time[0] % 12 || 12; // Adjust hours
    }
    return time.join(""); // return adjusted time or original string
};
const convertTime12To24 = (time12h) => {
    var [time, modifier] = time12h.split(" ");

    var [hours, minutes] = time.split(":");

    if (hours === "12") {
        hours = "00";
    }

    if (modifier === "PM") {
        hours = parseInt(hours, 10) + 12;
    }
    return hours + ":" + minutes;
};

const convertDateToIst12Time = (dateformet) => {
    const utcTimestamp = dateformet; // Replace with your UTC timestamp

    // Create a Date object from the UTC timestamp
    const date = new Date(utcTimestamp);

    // Define options for formatting
    const options = {
        timeZone: "Asia/Kolkata", // IST timezone
        hour12: true, // Use 12-hour format
        hour: "numeric", // Display hours
        minute: "numeric", // Display minutes
    };

    // Format the date in IST 12-hour format
    const istTime = date.toLocaleString("en-IN", options);

    return istTime;
}

const generateOTP = (length) => {
    const digits = '0123456789';
    let otp = '';

    for (let i = 0; i < length; i++) {
        const randomIndex = Math.floor(Math.random() * digits.length);
        otp += digits[randomIndex];
    }

    return otp;
}

const isTimeBefore = (time1, time2) => {
    const [hours1, minutes1] = time1.split(':').map(Number);
    const [hours2, minutes2] = time2.split(':').map(Number);

    const date1 = new Date();
    date1.setHours(hours1);
    date1.setMinutes(minutes1);

    const date2 = new Date();
    date2.setHours(hours2);
    date2.setMinutes(minutes2);

    return date1.getTime() < date2.getTime();
}
/****
 * calculateDistance(pickup.lat, pickup.lng, dropOff.lat, dropOff.lng);
 * distance.toFixed(2), 'km'
 */
const calculateDistance = (lat1, lon1, lat2, lon2) => {
    const R = 6371;
    const dLat = (lat2 - lat1) * (Math.PI / 180);
    const dLon = (lon2 - lon1) * (Math.PI / 180);

    const a =
        Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos(lat1 * (Math.PI / 180)) * Math.cos(lat2 * (Math.PI / 180)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);

    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    const distance = R * c;
    return distance;
}

function calculateTimeInKilometers(distanceInKm, speedInMph) {
    // Convert speed from mph to km/h (1 mph is approximately 1.60934 km/h)
    const speedInKmh = speedInMph * 1.60934;
    // Calculate the duration in hours
    const durationHours = distanceInKm / speedInKmh;
    const durationMinutes = durationHours * 60;
    return durationMinutes;
}

// function convertMinutesToHours(minutes) {
//     const hours = minutes / 60;
//     const roundedHours = hours.toFixed(1);
//     return roundedHours;
// }

function convertMinutesToHours(minutes) {
    if (minutes < 60) {
        minutes = Math.round(minutes);
        return `${minutes} min`;

    } else {
        const hours = Math.floor(minutes / 60);
        const remainingMinutes = minutes % 60;

        if (remainingMinutes === 0) {
            return `${Math.round(hours)} hrs`;
        } else {
            return `${hours} hrs ${Math.round(remainingMinutes)} min`;
        }
    }
}

function getDateRangeForWeeks(weeksAgo) {
    const currentDate = new Date();
    const currentDayOfWeek = currentDate.getDay(); // 0 for Sunday, 1 for Monday, etc.

    // Calculate the start date of the current week (Sunday)
    const startDate = new Date(currentDate);
    startDate.setDate(currentDate.getDate() - currentDayOfWeek);

    // Calculate the end date of the current week (today)
    const endDate = new Date(currentDate);

    // Adjust the start date and end date for the specified number of weeks ago
    startDate.setDate(startDate.getDate() - (weeksAgo * 7));
    endDate.setDate(endDate.getDate() - (weeksAgo * 7));

    // Format the dates as strings in "YYYY-MM-DD" format
    const startDateString = startDate.toISOString().split('T')[0];
    const endDateString = endDate.toISOString().split('T')[0];

    return { startDate: startDateString, endDate: endDateString };
}

function getDateRangeForPreviousDays(endDate, daysAgo) {
    const startDate = new Date(endDate);
    startDate.setDate(startDate.getDate() - daysAgo);

    // Format the dates as strings in "YYYY-MM-DD" format
    const startDateString = startDate.toISOString().split('T')[0];
    const endDateString = endDate.toISOString().split('T')[0];

    return { startDate: startDateString, endDate: endDateString };
}

function calculateTimeDifferenceInMinutes(givenDateStr) {
    // The given date
    const givenDate = new Date(givenDateStr);

    // Current date and time
    const currentDate = new Date();

    // Calculate the time difference in milliseconds
    const timeDifferenceMs = currentDate - givenDate;

    // Convert milliseconds to minutes
    const timeDifferenceMinutes = Math.floor(timeDifferenceMs / (1000 * 60));

    return timeDifferenceMinutes;
}

function sumArray(arr) {
    let sum = 0;
    for (let i = 0; i < arr.length; i++) {
        sum += arr[i];
    }
    return sum;
}

const pointInPolygonWithRadius = (point, polygon, radius) => {
    const x = point.lat;
    const y = point.lng;

    for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
        const xi = polygon[i].lat;
        const yi = polygon[i].lng;
        const xj = polygon[j].lat;
        const yj = polygon[j].lng;

        // Check if the point is within the bounding box of the polygon with a radius
        const withinBoundingBox = x >= Math.min(xi, xj) - radius &&
            x <= Math.max(xi, xj) + radius &&
            y >= Math.min(yi, yj) - radius &&
            y <= Math.max(yi, yj) + radius;

        if (withinBoundingBox) {
            // Check if the point is within the radius of any line segment of the polygon
            const distance = Math.abs(
                (yj - yi) * x - (xj - xi) * y + xj * yi - yj * xi
            ) / Math.sqrt((yj - yi) ** 2 + (xj - xi) ** 2);

            if (distance <= radius) {
                return true;
            }
        }
    }

    return false;
};

// Function to calculate the central point
function calculateCentralPoint(coordinates) {
    if (coordinates.length === 0) {
        return null; // No coordinates to calculate
    }

    // Calculate average latitude and longitude
    const avgLat = coordinates.reduce((sum, coord) => sum + coord.lat, 0) / coordinates.length;
    const avgLng = coordinates.reduce((sum, coord) => sum + coord.lng, 0) / coordinates.length;

    return { lat: avgLat, lng: avgLng };
}

function getTimeLabel(timeDifferenceHours) {
    if (timeDifferenceHours < 24) {
        return "Today";
    } else if (timeDifferenceHours < 48) {
        return "Yesterday";
    } else {
        return `${Math.ceil(timeDifferenceHours)} hours ago`;
    }
}

/****
 * Travel Pay
 */
async function getRateChartCategory(myDistance) {

    const travelPay = await TravelPayModel.find({});
    const distance = parseFloat(myDistance);

    for (const value of travelPay) {
        const fromRate = parseFloat(value.firstMile);
        const toRate = parseFloat(value.lastMile);
        const paytype = value.payType;

        if (distance >= fromRate && distance <= toRate) {
            if (paytype === 'km') {
                const kmRate = parseFloat(value.amount);
                return kmRate * distance;
            } else if (paytype === 'rs') {
                return parseFloat(value.amount);
            }
        }
    }
    return 0;
}

/****
 * Delivery incentives
 */
async function getDeliveryIncentives(deliveryCount) {
    const deliveryIncentives = await DeliveryIncentivesModel.find({});
    const totalDeliveryCount = parseFloat(deliveryCount);
    var incentive = parseFloat(0);

    for (let incentiveModel of deliveryIncentives) {
        if (
            parseInt(totalDeliveryCount) >= parseInt(incentiveModel.deliveries)
        ) {
            incentive = parseFloat(incentiveModel.incentives);
        } else {
            incentive = parseFloat(incentive);
        }
    }

    return incentive;
}

/****
 * Surge Charge -- raining/holiday/late_night
 */
async function getAmountByCondition(condition) {
    try {
        const record = await SurgeOrderModel.findOne({ slug: condition });
        if (record) {
            return record.amount;
        } else {
            return 0;
        }
    } catch (error) {
        console.error('Error fetching data from the database:', error);
        throw error;
    }
}
/*****
 * Waiting charge from Resturant -- (Reach pickup location -- Pickup complete)
 */
async function getWaitingChargeFromResturant(waitingTimeMinute) {
    try {
        const waitingPayRest = await WaitingPayRestModel.find({});
        const distance = parseFloat(waitingTimeMinute);
        for (const value of waitingPayRest) {
            const fromRate = parseFloat(value.fromMin);
            const toRate = parseFloat(value.toMin);

            if (distance >= fromRate && distance <= toRate) {
                return value.amount;
            }
        }
        return 0.00;
    } catch (error) {
        console.error(error);
        throw error;
    }
}
/*****
 * Distance Calculation using 3rd party Api
 */
async function calculateDistanceInsTentApi(origin, destination) {
    try {
        const response = await axios.get(process.env.INSTENT_API_URL, {
            params: {
                origins: origin,
                destinations: destination,
            },
            headers: {
                'x-api-key': `${process.env.INSTENT_API_KEY}`,
            }
        });
        if (response.status === 200) {
            const { distances } = response.data;
            return distances / 1000;
        } else {
            throw new Error('Error fetching distance data.');
        }
    } catch (error) {
        throw new Error(`Error: ${error.message}`);
    }
}

// Create a function to send FCM notifications
async function sendNotification(req, res) {
    // const deviceToken = req.body.fcm_token;

    // if (!deviceToken || typeof deviceToken !== 'string') {
    //     return res.status(400).json({
    //         success: false,
    //         error: 'Invalid device token'
    //     });
    // }

    const deviceTokens = req.body.fcm_tokens;

    if (!deviceTokens || !Array.isArray(deviceTokens)) {
        return res.status(400).json({
            success: false,
            error: 'Invalid device tokens'
        });
    }

    const notification = {
        notification: {
            title: req.body.title,
            body: req.body.body,
            message_id: req.body.messageData ? req.body.messageData._id.toString() : "",
            created_by: req.body.messageData ? req.body.messageData.created_by : "",
            notify_date: req.body.messageData ? calculateTimeDifferenceInMinutes(req.body.messageData.notify_date) + "" + 'mins' : ""
        }
    };

    const responses = [];

    try {
        for (const deviceToken of deviceTokens) {
            const response = await FirebaseAdmin.messaging().sendToDevice(deviceToken, notification);
            responses.push(response);
        }

        // return requestHandler.sendSuccess(res, 'Successfully.')({
        //     responses
        // });
    } catch (error) {
        return res.status(500).json({
            success: false,
            error: 'Failed to send notification'
        });
    }
}

// Function to calculate login time for each object and total login time
async function calculateTotalLoginTime() {
    try {
        // Retrieve all login time ranges from the collection
        // const loginTimeRanges = await LoginTimeRange.find();

        // Example usage
        const loginTimeRanges = [
            {
                startTime: '10:00',
                endTime: '10:30',
            },
            {
                startTime: '11:00',
                endTime: '12:00',
            }
        ];

        const shiftDate = '2023-01-01';

        // Calculate login time for each object and total login time
        let totalLoginTime = 0;

        for (const { startTime, endTime } of loginTimeRanges) {
            const start = new Date(`${shiftDate}T${startTime}`);
            const end = new Date(`${shiftDate}T${endTime}`);
            const loginTime = (end - start) / (1000 * 60); // in minutes

            totalLoginTime += loginTime;
        }
        return totalLoginTime;
    } catch (error) {
        console.error('Error calculating login time:', error);
    } finally {
        console.log("running");
    }
}
// Function to slugify a string
function slugify(str) {
    str = str.replace(/^\s+|\s+$/g, ''); // trim leading/trailing white space
    str = str.toLowerCase(); // convert string to lowercase
    str = str.replace(/[^a-z0-9 -]/g, '') // remove any non-alphanumeric characters
        .replace(/\s+/g, '-') // replace spaces with hyphens
        .replace(/-+/g, '-'); // remove consecutive hyphens
    return str;
}

async function generateUniqueAccountId() {
    let accountId;
    let isUnique = false;

    while (!isUnique) {
        // Generate a random 12-digit number
        accountId = Math.floor(100000000000 + Math.random() * 900000000000).toString();

        // Check if the account_id is unique
        const existingUser = await clientAdminModel.findOne({ where: { account_id: accountId } });
        if (!existingUser) {
            isUnique = true; // Found a unique account_id
        }
    }

    return accountId;
}

async function findXeroUserByClientId(clientId) {
    try {
        console.log("Searching for client_id:", clientId);
        
        // Get all client databases
        const clients = await clientModel.findAll({
            attributes: ['id', 'database_name'],
            where: {
                database_name: {
                    [Sequelize.Op.ne]: null
                }
            }
        });

        console.log(`Searching across ${clients.length} databases`);

        let latestRecord = null;
        let latestTimestamp = null;

        // Search through each database for the XeroUser record
        for (const client of clients) {
            try {
                console.log(`Searching database: ${client.database_name}`);
                
                const connection = await connectSpecificToDatabase(
                    client.database_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
                );
                
                const xeroUser = await connection.XeroUser.findOne({
                    where: { client_id: clientId }
                });
                
                if (xeroUser) {
                    const userData = xeroUser.toJSON();
                    console.log(`Found record in database ${client.database_name}:`, userData);
                    
                    // Get the timestamp (use updatedAt or createdAT or last_used)
                    const recordTimestamp = userData.updatedAt || userData.createdAt || userData.last_used;
                    
                    // Keep the most recent record
                    if (!latestRecord || (recordTimestamp && recordTimestamp > latestTimestamp)) {
                        latestRecord = {
                            ...userData,
                            db_name: client.database_name,
                            clientUserId: client.id
                        };
                        latestTimestamp = recordTimestamp;
                    }
                }
            } catch (error) {
                console.error(`Error searching database ${client.database_name}:`, error.message);
                continue;
            }
        }
        
        if (latestRecord) {
            console.log("Selected latest record:", latestRecord);
        } else {
            console.log("No record found for client_id:", clientId);
        }
        
        return latestRecord;
    } catch (error) {
        console.error("Error finding Xero user by client ID:", error);
        return null;
    }
}

async function createDatabase(db_name, updateFields, updateCompanyFields, defaultCurrencyData) {

    // console.log(db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host);
    // db_name = `raiseinvoice_${db_name}`;
    const sequelize = new Sequelize(mysqlConfig.dbName, mysqlConfig.user, mysqlConfig.pwd, {
        host: mysqlConfig.host,
        dialect: mysqlConfig.dialect,
        logging: mysqlConfig.debug,
        // logging: console.log,
    });

    sequelize
        .authenticate()
        .then(() => {
            console.log('Mysql connection has been established successfully.')
        })
        .catch(err => {
            console.error('Unable to connect to the Mysql database:', err)
        })

    try {
        // await sequelize.authenticate();
        console.log("Connected!");

        // await sequelize.query(`CREATE DATABASE \`${db_name}\``);
        // Step 1: Check if the database exists
        const dbExists = await sequelize.query(`SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '${db_name}'`);

        if (dbExists[0].length > 0) {
            // Step 2: If it exists, drop the database
            await sequelize.query(`DROP DATABASE \`${db_name}\`;`);
        }

        // Step 3: Create the new database
        await sequelize.query(`CREATE DATABASE \`${db_name}\`;`);
        console.log("Database created");

        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );
        // Assuming connection contains the sequelize instance
        const sequelize2 = connection.sequelize;
        // await sequelize2.sync({ alter: true });

        var uuid = crypto.randomUUID();

        const User = require("../models/client/clientAdminModel")(sequelize2, Sequelize);
        const Role = require("../models/client/roleModel")(sequelize2, Sequelize);
        const Module = require("../models/client/modulesModel")(sequelize2, Sequelize);
        const UserCompany = require("../models/client/userCompanyModel")(sequelize2, Sequelize);
        const UsersRole = require("../models/client/usersRoleModel")(sequelize2, Sequelize);
        const UserLanguage = require("../models/client/userLanguageModel")(sequelize2, Sequelize);
        const ProjectSetting = require("../models/client/projectSettingModel")(sequelize2, Sequelize);
        const CommunicationSetting = require("../models/client/communicationSettingModel")(sequelize2, Sequelize);
        const UserTaxSecurity = require("../models/client/companyTaxSecurityModel")(sequelize2, Sequelize);

        const role = await Role.create({
            uuid: uuid,
            roleName: "Super Admin",
            roleSlug: "super-admin"
        });
        // var uuid2 = crypto.randomUUID();
        const module = await Module.create({
            uuid: uuid,
            moduleName: 'User',
            moduleSlug: 'user'
        });
        // const permission = await permissionsSchema.create({
        //     uuid: updateFields.uuid,
        //     name: updateFields.name ?? updateFields.firstName
        // });

        // Insert data into the User table
        let roleDetails = await Role.findOne({
            where: {
                roleSlug: "super-admin",
                deletedAt: null,
            }
        });

        var userData = {
            roleId: roleDetails.id,
            account_id: updateFields.account_id,
            uuid: updateFields.uuid,
            name: updateFields.name ?? updateFields.firstName,
            email: updateFields.email,
            phone: updateFields.phone,
            password: updateFields.password,
            database_name: db_name,
            isVerified: true
        }
        if(updateFields.profileImage){
            userData.profileImage = updateFields.profileImage; 
        }
        const user = await User.create(userData);
        
        const userCompany = await UserCompany.create({
            uuid: updateCompanyFields.uuid,
            userId: user.id,
            companyName: updateCompanyFields.companyName,
            companyAddress: updateCompanyFields.companyAddress,
            companyPhone: updateCompanyFields.companyPhone,
            companyEmail: updateCompanyFields.companyEmail,
            companyWebsite: updateCompanyFields.companyWebsite,
            companyInfo: updateCompanyFields.companyInfo,
            legalBusinessName: updateCompanyFields.legalBusinessName,
            businessAddress: updateCompanyFields.businessAddress,
            businessPhone: updateCompanyFields.businessPhone,
            noOfEmployee: updateCompanyFields.noOfEmployee
        });

        await UsersRole.create({ userId: parseInt(user.id), roleId: roleDetails.id });
        await UserLanguage.create({ userId: parseInt(user.id), languageId: 1 });

        await ProjectSetting.create({
            addNewClient: true,
            newEstimate: true,
            newInvoice: true
        });

        await CommunicationSetting.create({
            sameEmail: true,
            paymentReminder: true,
            day3BeforeDueDate: true,
            dueDate: true,
            day3AfterDueDate: true,
            day7AfterDueDate: true,
            paymentNotification: true,
            paymentReceipt: true,
            email: true,
            businessResource: false,
            invoice2go: true,
            productUpdate: true,
            specialOffer: true
        });

        await UserTaxSecurity.create({
            userId: parseInt(user.id),
            countryId: 233, // Default to USA
            currency: defaultCurrencyData ? defaultCurrencyData.currency_code : "USD",
            symbol: defaultCurrencyData ? defaultCurrencyData.symbol : "$",
        });

        // console.log('User  created:', user.toJSON());
        // console.log(`Tables created in database ${db_name}`);

    } catch (err) {
        console.error("Error: ", err);
    } finally {
        await sequelize.close();
    }
}
async function updateDatabase(db_name, updateFields, updateCompanyFields) {

    const sequelize = new Sequelize(mysqlConfig.dbName, mysqlConfig.user, mysqlConfig.pwd, {
        host: mysqlConfig.host,
        dialect: mysqlConfig.dialect,
        logging: mysqlConfig.debug,
    });

    sequelize
        .authenticate()
        .then(() => {
            console.log('Mysql connection has been established successfully.')
        })
        .catch(err => {
            console.error('Unable to connect to the Mysql database:', err)
        })

    try {
        console.log("Connected!");
        const dbExists = await sequelize.query(`SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '${db_name}'`);

        if (dbExists[0].length > 0) {
            const connection = await connectSpecificToDatabase(
                db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
            );
            // Assuming connection contains the sequelize instance
            const sequelize2 = connection.sequelize;
            // await sequelize2.sync({ alter: true });

            const User = require("../models/client/clientAdminModel")(sequelize2, Sequelize);
            const UserCompany = require("../models/client/userCompanyModel")(sequelize2, Sequelize);

            let connectedUser = await User.findOne({
                attributes: ["id"],
                where: { database_name: db_name },
            });
            var userData = {
                name: updateFields.name ?? updateFields.firstName,
                email: updateFields.email,
                phone: updateFields.phone,
            };
            if(updateFields.password){
                userData.password = updateFields.password;
            }
            if(updateFields.profileImage){
                userData.profileImage = updateFields.profileImage;
            }
            await connectedUser.update(userData);

            var companyData = {
                companyAddress: updateCompanyFields.companyAddress,
                companyPhone: updateCompanyFields.companyPhone,
                companyEmail: updateCompanyFields.companyEmail,
                companyWebsite: updateCompanyFields.companyWebsite,
                companyInfo: updateCompanyFields.companyInfo,
                legalBusinessName: updateCompanyFields.legalBusinessName,
                businessAddress: updateCompanyFields.businessAddress,
                businessPhone: updateCompanyFields.businessPhone,
                noOfEmployee: updateCompanyFields.noOfEmployee
            };

            await UserCompany.update(companyData, {
                where: { userId: connectedUser.id },
            });
        }

    } catch (err) {
        console.error("Error: ", err);
    } finally {
        await sequelize.close();
    }
}

async function getConnectedSpecificDB(dbName) {
    // const sequelize = new Sequelize(`mysql://root:@localhost:3306/${dbName}`, {
    //     dialect: 'mysql',
    //     logging: false
    // });
    console.log(dbName, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host);

    const sequelize = new Sequelize(dbName, mysqlConfig.user, mysqlConfig.pwd, {
        dialect: 'mysql',
        host: mysqlConfig.host,
        port: 3306
    });

    try {
        // Test the connection
        await sequelize.authenticate();
        console.log(`Connection to the database ${dbName} has been established successfully.`);
        return sequelize;
    } catch (error) {
        console.error('Unable to connect to the database:', error);
        throw error;
    }
}

// Helper function to generate week ranges for a given month
function getAllWeekRanges(month) {
    return [
        `1${month} - 7${month}`,
        `8${month} - 14${month}`,
        `15${month} - 22${month}`,
        `23${month} - 30${month}`
    ];
}

// Function to determine week range for a given start date
function getWeekRange(date) {
    const day = date.getDate();
    const month = date.toLocaleString('default', { month: 'short' });

    if (day <= 7) return `1${month} - 7${month}`;
    if (day <= 14) return `8${month} - 14${month}`;
    if (day <= 22) return `15${month} - 22${month}`;
    return `23${month} - 30${month}`;
}

module.exports = {
    generateUniqueAccountId,
    createDatabase,
    updateDatabase,
    getConnectedSpecificDB,
    dateFormat,
    dateFormatDDMMYYYY,
    fullDatetimeFormat,
    convertTime24To12,
    convertTime12To24,
    fullDatetimeFormatDDMMYYYYHHIIAA,
    fullDatetimeFormatYYYYMMDDHHMMSS,
    dateFormatYYYYMMDD,
    convertDateToIst12Time,
    generateOTP,
    getTimeLabel,
    isTimeBefore,
    calculateDistance,
    calculateTimeInKilometers,
    calculateTimeDifferenceInMinutes,
    sumArray,
    calculateCentralPoint,
    pointInPolygonWithRadius,
    getRateChartCategory,
    getAmountByCondition,
    getWaitingChargeFromResturant,
    calculateDistanceInsTentApi,
    getDateRangeForWeeks,
    getDateRangeForPreviousDays,
    getDeliveryIncentives,
    convertMinutesToHours,
    sendNotification,
    calculateTotalLoginTime,
    slugify,
    getAllWeekRanges,
    getWeekRange,
    findXeroUserByClientId
};
