const express = require('express');
const router = express.Router();
const agentBookingMappingController = require('../controllers/agentBookingMappingController');
const {
  isAuthenticated,
} = require('../middleware/auth');

router.route('/assign-agent-to-booking-request').post(isAuthenticated, agentBookingMappingController.assignAgentToBookingRequest);

module.exports = router;