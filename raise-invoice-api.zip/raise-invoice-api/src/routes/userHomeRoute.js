const express = require('express');
const router = express.Router();
const userHomeController = require('../controllers/userHomeController');
const {
  isAuthenticated,
} = require('../middleware/auth')


router.route('/get-newsletter-list').get(isAuthenticated, userHomeController.getNewsletterUsrList);

router.route('/get-feedback-list').get(isAuthenticated, userHomeController.getFeedBackList);
router.route('/save-feedback').post(isAuthenticated, userHomeController.saveFeedBack);
router.route('/delete-feedback').post(isAuthenticated, userHomeController.deleteFeedBack);

module.exports = router;