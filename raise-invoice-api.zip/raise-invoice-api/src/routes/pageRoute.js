const express = require('express');
const router = express.Router();
const pageController = require('../controllers/pageController');
const {
  isAuthenticated,
} = require('../middleware/auth')


router.route('/get-all-page-list').post(isAuthenticated, pageController.getAllPageList);
router.route('/get-page-list').post(isAuthenticated, pageController.getPageList);
router.route('/save-page').post(isAuthenticated, pageController.savePage);
router.route('/delete-page').post(isAuthenticated, pageController.deletePage);
router.route('/get-page-details').post(isAuthenticated, pageController.getPageDetails);

module.exports = router;