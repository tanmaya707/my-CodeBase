const express = require('express');
const router = express.Router();
const notificationController = require('../controllers/notificationController')
const {
    isAuthenticated,
  } = require('../middleware/auth')


router.route('/notification-list').post(isAuthenticated, notificationController.notificationList);
router.route('/notification-status-change').post(isAuthenticated, notificationController.notiReadStatusChange);
router.route('/notification-delete').post(isAuthenticated, notificationController.deleteNotification);

module.exports = router;