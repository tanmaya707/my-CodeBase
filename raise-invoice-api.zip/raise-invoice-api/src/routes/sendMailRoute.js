const express = require('express');
const router = express.Router();
const sendMailController = require('../controllers/sendMail');
const {
  isAuthenticated,
} = require('../middleware/auth')


router.route('/send-mail').post(isAuthenticated, sendMailController.sendMail);
router.route('/reset-password-mail').post(sendMailController.resetPasswordMail);
router.route('/client-reset-password').post(sendMailController.clientResetPassword);

module.exports = router;