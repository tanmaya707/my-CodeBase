const express = require('express');
const router = express.Router();
const jobController = require('../controllers/jobController');
const {
  isAuthenticated,
} = require('../middleware/auth')


router.route('/get-job-categories').post(isAuthenticated, jobController.getJobCategories);
router.route('/get-job-category-details').post(isAuthenticated, jobController.getJobCategoryDetails);
router.route('/save-job-category').post(isAuthenticated, jobController.saveJobCategory);
router.route('/delete-job-category').post(isAuthenticated, jobController.deleteJobCategory);
router.route('/get-job-list').post(isAuthenticated, jobController.getJobList);
router.route('/get-job-details').post(isAuthenticated, jobController.getJobDetails);
router.route('/get-job-category-list').get(isAuthenticated, jobController.getJobCategoryList);
router.route('/save-job').post(isAuthenticated, jobController.saveJob);
router.route('/delete-job').post(isAuthenticated, jobController.deleteJob);

module.exports = router;