const express = require('express');
const router = express.Router();
const blockController = require('../controllers/blockController');
const {
  isAuthenticated,
} = require('../middleware/auth')

router.route('/get-block-list').post(isAuthenticated, blockController.getBlockList);
router.route('/save-block').post(isAuthenticated, blockController.saveBlock);
router.route('/delete-block').post(isAuthenticated, blockController.deleteBlock);
router.route('/get-block-details').post(isAuthenticated, blockController.getBlockDetails);

module.exports = router;