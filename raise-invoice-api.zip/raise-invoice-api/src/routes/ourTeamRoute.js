const express = require('express');
const router = express.Router();
const ourTeamController = require('../controllers/ourTeamController');
const {
  isAuthenticated,
} = require('../middleware/auth')


router.route('/get-our-team-list').post(isAuthenticated, ourTeamController.getOurTeamList);
router.route('/save-our-team').post(isAuthenticated, ourTeamController.saveOurTeam);
router.route('/delete-our-team').post(isAuthenticated, ourTeamController.deleteOurTeam);
router.route('/get-our-team-details').post(isAuthenticated, ourTeamController.getOurTeamDetails);

module.exports = router;