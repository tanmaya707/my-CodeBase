const express = require('express');
const router = express.Router();
const menuController = require('../controllers/menuController');
const {
  isAuthenticated,
} = require('../middleware/auth')


router.route('/get-menu-list').post(isAuthenticated, menuController.getMenuList);
router.route('/save-menu').post(isAuthenticated, menuController.saveMenu);
router.route('/delete-menu').post(isAuthenticated, menuController.deleteMenu);
router.route('/get-menu-details').post(isAuthenticated, menuController.getMenuDetails);

module.exports = router;