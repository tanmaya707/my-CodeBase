const express = require('express');
const router = express.Router();
const faqController = require('../controllers/faqController');
const pricingPlanController = require('../controllers/pricingPlanController');
const jobController = require('../controllers/jobController');
const testimonialController = require('../controllers/testimonialController');
const pageController = require('../controllers/pageController');
const userController = require('../controllers/userController');
const commonController = require('../controllers/common/commonController');
const authController = require('../controllers/services/authController');
const { isAuthenticatedClient } = require('../middleware/auth');
// const {
//   isAuthenticated,
// } = require('../middleware/auth')

router.route('/api/get-menu-list').post(commonController.getMenuList);
router.route('/api/get-menu-details').post(commonController.getMenuDetails);

router.route('/api/get-faq-categories').post(faqController.getFaqCategories);
router.route('/api/get-faq-category-details').post(faqController.getFaqCategoryDetails);
router.route('/api/get-faq-list').post(faqController.getFaqList);
router.route('/api/get-faq-by-category').post(faqController.getFaqListByCategory);
router.route('/api/get-faq-details').post(faqController.getFaqDetails);

router.route('/api/get-features-categories').post(pricingPlanController.getPlanFeaturesCategories);
router.route('/api/get-plan-list').post(pricingPlanController.getPlanList);
router.route('/api/get-currency-info').post(pricingPlanController.getCurrencyInfo);

router.route('/api/get-job-categories').post(jobController.getJobCategories);
router.route('/api/get-job-category-details').post(jobController.getJobCategoryDetails);
router.route('/api/get-job-list').post(jobController.getJobList);
router.route('/api/get-job-details').post(jobController.getJobDetails);

router.route('/api/get-testimonial-list').post(testimonialController.getTestimonialList);

router.route('/api/get-pagecontent-by-slug').post(pageController.getPagecontentBySlug);

router.route('/api/get-country-list').get(userController.getCountryList);
router.route('/api/submit-enquiry').post(commonController.submitEnquiry);
router.route('/api/subscribe-newletter').post(commonController.subscribeNewletter);

router.route('/api/client-logout').post(isAuthenticatedClient, authController.clientLogout);

module.exports = router;