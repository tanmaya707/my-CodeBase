const express = require('express');
const router = express.Router();
const raiseRolePermissionController = require('../../../controllers/services/raiseRolePermissionController');
const { isAuthenticatedClient } = require('../../../middleware/auth');

router.route('/create-role').post(isAuthenticatedClient, raiseRolePermissionController.createRole);
router.route('/role-list').post(isAuthenticatedClient, raiseRolePermissionController.listAllRoles);
router.route('/role-update').post(isAuthenticatedClient, raiseRolePermissionController.updateRole);
router.route('/role-details').post(isAuthenticatedClient, raiseRolePermissionController.roleDetails);
router.route('/role-delete').post(isAuthenticatedClient, raiseRolePermissionController.deleteRole);

module.exports = router;