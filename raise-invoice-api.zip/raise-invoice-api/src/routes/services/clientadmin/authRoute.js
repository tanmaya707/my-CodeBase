const express = require('express');
const router = express.Router();
const authController = require('../../../controllers/services/authController');
const settingController = require('../../../controllers/services/settingController');
const { isAuthenticatedClient } = require('../../../middleware/auth');

/***************************** Authentication Route Start  *********************************/
router.route('/client-register').post(authController.clientSignUp);
router.route('/create-profile').post(isAuthenticatedClient, authController.clientCreateProfile);
router.route('/client-login').post(authController.clientSignIn);
router.route('/client-logout').post(isAuthenticatedClient, authController.clientLogout);
router.route('/client-profile').post(isAuthenticatedClient, authController.clientProfile);
router.route('/update-profile-image').post(isAuthenticatedClient, authController.updateProfileImage);
router.route('/verification-code-generate').post(authController.sendVerificationCode);
router.route('/verify-otp').post(authController.clientVerifyOtp);
router.route('/reset-password').post(authController.clientResetPassword);

router.route('/update-profile').post(isAuthenticatedClient, authController.clientUpdateProfile);
router.route('/update-client-profile').post(isAuthenticatedClient, authController.updateClientAdminProfile);
/***************************** Authentication Route End  *********************************/

/***************************** Role Permission Management Start  *********************************/
router.route('/permissions').get(isAuthenticatedClient, authController.getPermissionList);
router.route('/create-role').post(isAuthenticatedClient, authController.createRoleAdmin);
router.route('/role-list').post(isAuthenticatedClient, authController.getRoleList);

router.route('/role-details/:id')
    .post(isAuthenticatedClient, authController.getRoleDetails)
    .put(isAuthenticatedClient, authController.updateClientRole)
    .delete(isAuthenticatedClient, authController.deleteClientRole);
/***************************** Role Permission Management End *********************************/

/***************************** Team Memeber Management Start  *********************************/
router.route('/add-team-member').post(isAuthenticatedClient, authController.createTeamMember);
router.route('/team-members').post(isAuthenticatedClient, authController.getAllUsersWithRoles);
router.route('/team-member/:id')
    .get(isAuthenticatedClient, authController.detailsClientAdmin)
    .put(isAuthenticatedClient, authController.editClientAdmin)
    .delete(isAuthenticatedClient, authController.deleteClientAdmin);
/***************************** Team Memeber Management End  *********************************/

/***************************** Settings Data Management Start  *********************************/
router.route('/add-settings-data').post(isAuthenticatedClient, settingController.addSettingsClientCompany);
router.route('/update-project-settings').post(isAuthenticatedClient, settingController.updateProjectSettings);
router.route('/details-project-settings').post(isAuthenticatedClient, settingController.detailProjectSetting);

router.route('/update-communication-settings').post(isAuthenticatedClient, settingController.updateCommunicationSettings);
router.route('/details-communication-settings').post(isAuthenticatedClient, settingController.detailCommunicationSetting);
/***************************** Settings Data Management Start  *********************************/

module.exports = router;