const express = require('express');
const router = express.Router();
const creditnoteController = require('../../../controllers/services/creditNoteController');
const { isAuthenticatedClient } = require('../../../middleware/auth');


/***************************** Clients Credit Note *********************************/

router.route('/create-credit-note').post(isAuthenticatedClient, creditnoteController.createCreditnote);
router.route('/next-credit-note-number').post(isAuthenticatedClient, creditnoteController.fetchNextCreditNoteNumber);
router.route('/update-credit-note').post(isAuthenticatedClient, creditnoteController.updateCreditnote);
router.route('/credit-note-list').post(isAuthenticatedClient, creditnoteController.getAllCreditnote)
router.route('/credit-note-details').post(isAuthenticatedClient, creditnoteController.getCreditnoteDetails)
router.route('/delete-credit-note').post(isAuthenticatedClient, creditnoteController.deleteCreditnote);

/***************************** Clients Credit Note ***********************/

module.exports = router;