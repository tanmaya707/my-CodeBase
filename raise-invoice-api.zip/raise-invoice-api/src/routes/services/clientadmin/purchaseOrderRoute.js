const express = require('express');
const router = express.Router();
const pruchaseOrderController = require('../../../controllers/services/pruchaseOrderController');
const { isAuthenticatedClient } = require('../../../middleware/auth');


/***************************** Clients Purchase Order *********************************/

router.route('/create-purchase-order').post(isAuthenticatedClient, pruchaseOrderController.createPurchaseOrder);
router.route('/next-purchase-order-number').post(isAuthenticatedClient, pruchaseOrderController.fetchNextPurchaseOrderNumber);
router.route('/update-purchase-order').post(isAuthenticatedClient, pruchaseOrderController.updatePurchaseOrder);
router.route('/purchase-order-list').post(isAuthenticatedClient, pruchaseOrderController.getAllPurchaseOrders);
router.route('/purchase-order-details').post(isAuthenticatedClient, pruchaseOrderController.getPurchaseOrderDetails);
router.route('/delete-purchase-order').post(isAuthenticatedClient, pruchaseOrderController.deletePurchaseOrder);

/***************************** Clients Purchase Order ***********************/

module.exports = router;

