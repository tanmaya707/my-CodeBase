const express = require('express');
const router = express.Router();
const estimateController = require('../../../controllers/services/estimateController');
const { isAuthenticatedClient } = require('../../../middleware/auth');


/***************************** Clients Estimate *********************************/

router.route('/create-estimate').post(isAuthenticatedClient, estimateController.createEstimate);
router.route('/next-estimate-number').post(isAuthenticatedClient, estimateController.fetchNextEstimateNumber);
router.route('/update-estimate').post(isAuthenticatedClient, estimateController.updateEstimate);
router.route('/estimate-list').post(isAuthenticatedClient, estimateController.getAllEstimate)
router.route('/estimate-details').post(isAuthenticatedClient, estimateController.getEstimateDetails)
router.route('/delete-estimate').post(isAuthenticatedClient, estimateController.deleteEstimate);

/***************************** Clients Estimate Controller ***********************/

module.exports = router;