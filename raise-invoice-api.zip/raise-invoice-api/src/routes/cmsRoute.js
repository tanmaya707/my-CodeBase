const express = require('express');
const router = express.Router();
const cmsController = require('../controllers/cmsController')
const {
  isAuthenticated,
} = require('../middleware/auth')

router.route('/page-add-update').post(isAuthenticated, cmsController.pageAddUpdate);
router.route('/page-details').post(isAuthenticated, cmsController.pageDetails);
router.route('/page-list').post(isAuthenticated, cmsController.pageList);
router.route('/page-soft-delete').post(isAuthenticated, cmsController.pageSoftDelete);
// router.route('/page-status-change').post(isAuthenticated, cmsController.pageStatusChange);

module.exports = router;