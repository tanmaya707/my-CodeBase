const express = require('express');
const router = express.Router();
const xeroIntegerationController = require('../controllers/xeroIntegerationController');
const {
  isAuthenticated,
} = require('../middleware/auth')


router.route('/connect').post(isAuthenticated, xeroIntegerationController.xeroConnect);
router.route('/callback').get(xeroIntegerationController.xeroCallback);
router.route('/connection-status').get(isAuthenticated, xeroIntegerationController.xeroConnectionStatus);
// router.route('/sync/invoices').post(isAuthenticated, xeroIntegerationController.xeroSyncInvoice);
router.route('/sync/invoices-from-xero').get(isAuthenticated, xeroIntegerationController.xeroFetchInvoiceFromXero);
router.route('/sync/customer-from-xero').get(isAuthenticated, xeroIntegerationController.xeroFetchCustomers);
router.route('/tenants').get(isAuthenticated, xeroIntegerationController.xeroTenants);
router.route('/disconnect').post(isAuthenticated, xeroIntegerationController.xeroDisconnect);
router.route('/connected-user').get(isAuthenticated, xeroIntegerationController.xeroConnectedUser);
router.route('/last-sync').get(isAuthenticated, xeroIntegerationController.xeroLastSync);


module.exports = router;

