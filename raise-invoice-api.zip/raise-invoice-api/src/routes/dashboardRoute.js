const express = require('express');
const router = express.Router();
const dashboardController = require('../controllers/dashboardController');
const {
  isAuthenticated,
} = require('../middleware/auth')

router.route('/dashboard').post(isAuthenticated, dashboardController.dashboard);

module.exports = router;