const express = require('express');
const router = express.Router();
const paypalController = require('../controllers/paypalController')

// Toggle PayPal integration status
router.route('/paypal/toggle').post(paypalController.);

// PayPal callback to capture payment and setup
router.route('/paypal/callback').get(paypalController.paypalCallback);

// Get PayPal authentication URL
router.route('/paypal/auth-url').get(paypalController.getPaypalAuthUrl);

// Get PayPal setup/status for user
router.route('/paypal/status').get(paypalController.getPaypalStatus);

module.exports = router;