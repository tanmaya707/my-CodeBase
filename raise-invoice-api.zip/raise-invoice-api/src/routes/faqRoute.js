const express = require('express');
const router = express.Router();
const faqController = require('../controllers/faqController');
const {
  isAuthenticated,
} = require('../middleware/auth')


router.route('/get-faq-categories').post(isAuthenticated, faqController.getFaqCategories);
router.route('/get-faq-category-details').post(isAuthenticated, faqController.getFaqCategoryDetails);
router.route('/save-faq-category').post(isAuthenticated, faqController.saveFaqCategory);
router.route('/delete-faq-category').post(isAuthenticated, faqController.deleteFaqCategory);
router.route('/get-faq-list').post(isAuthenticated, faqController.getFaqList);
router.route('/get-faq-details').post(isAuthenticated, faqController.getFaqDetails);
router.route('/get-faq-category-list').get(isAuthenticated, faqController.getFaqCategoryList);
router.route('/save-faq').post(isAuthenticated, faqController.saveFaq);
router.route('/delete-faq').post(isAuthenticated, faqController.deleteFaq);

module.exports = router;