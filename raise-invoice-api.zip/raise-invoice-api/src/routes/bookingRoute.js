const express = require('express');
const router = express.Router();
const bookingController = require('../controllers/bookingController')
const {
  isAuthenticated,
} = require('../middleware/auth')


router.route('/check-slot-validity').post(bookingController.checkSlotValidity);
router.route('/decide-slot').post(bookingController.slotDecider);
router.route('/customer-exist-check').post(bookingController.customerExistCheck);

router.route('/booking-request-list').post(isAuthenticated, bookingController.bookingRequestList);

router.route('/booking-request-detail').post(isAuthenticated, bookingController.bookingRequestDetail);

router.route('/booking-request-create').post(bookingController.bookingRequestCreate);
router.route('/check-slot-validity').post(bookingController.checkSlotValidity);

// ======================================================================================
// ====================================== INVOICE ======================================
// ======================================================================================

router.route('/invoice-detail').post(isAuthenticated, bookingController.invoiceDetail);

router.route('/pre-booking-charge-summary').post(bookingController.preBookingChargeSummary);


// ---------------------------------- INITIAL INVOICE -----------------------------------
// ----- creates a invoice with booking request data received while booking -----
// ----- invoice data needs to be updated after check-in and before final check-out -----
// --------------------------------------------------------------------------------------
router.route('/calculate-booking-charges-before-booking').post(bookingController.calculateBookingChargesBeforeBooking);
// ---------------------------------- INITIAL INVOICE -----------------------------------
// ----- creates a invoice with booking request data received while booking -----
// ----- invoice data needs to be updated after check-in and before final check-out -----
// --------------------------------------------------------------------------------------

router.route('/calculate-booking-charges-after-check-in').post(isAuthenticated, bookingController.calculateBookingChargesAfterCheckIn);

router.route('/calculate-booking-charges-after-check-out').post(isAuthenticated, bookingController.calculateBookingChargesAfterCheckOut);

// ====================================== INVOICE ======================================
// ======================================================================================
// ======================================================================================

// router.route('/pay-booking-charges').post(bookingController.payBookingCharges);

router.route('/mark-check-in').post(isAuthenticated, bookingController.markCheckIn);

router.route('/mark-check-out').post(isAuthenticated, bookingController.markCheckOut);

module.exports = router;