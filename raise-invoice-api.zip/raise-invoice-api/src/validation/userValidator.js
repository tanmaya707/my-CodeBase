// const { check, validationResult } = require('express-validator');

// exports.validateUser = [
//   check('firstName')
//     .trim()
//     .escape()
//     .not()
//     .isEmpty()
//     .withMessage('First name can not be empty!')
//     .bail()
//     .isLength({ min: 3 })
//     .withMessage('Minimum 3 characters required!')
//     .bail(),
//   //  check('lastName')
//   //   .trim()
//   //   .escape()
//   //   .not()
//   //   .isEmpty()
//   //   .withMessage('Last name can not be empty!')
//   //   .bail()
//   //   .isLength({min: 3})
//   //   .withMessage('Minimum 3 characters required!')
//   //   .bail(),
//   check('email')
//     .trim()
//     .normalizeEmail()
//     .not()
//     .isEmpty()
//     .withMessage('Invalid email address!')
//     .bail(),
//   //  check('phone')
//   //   .trim()
//   //   .escape()
//   //   .not()
//   //   .isEmpty()
//   //   .withMessage('Phone can not be empty!')
//   //   .bail()
//   //   .isLength({min: 10})
//   //   .withMessage('Minimum 10 digits required!')
//   //   .bail()
//   //   .isInt()
//   //   .withMessage('Only digits allowed!')
//   //   .bail(),
//   (req, res, next) => {
//     const errors = validationResult(req);
//     if (!errors.isEmpty())
//       return res.status(422).json({ errors: errors.array() });
//     next();
//   },
// ];