const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;
const validator = require("validator");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const crypto = require("crypto");

// the term "User" defines anybody ( living or inert matter ) ( i.e.: human or any organization ) that have login access to the system 

// Every user that can access the system must have a predefined role =====
// roleId cannot be blank for any user =====
// user with (roleId == null) have no use/login access/privilage in the system === equal to a deleted user ======

const userSchema = new mongoose.Schema(
  {
    roleId: { type: ObjectId, ref: "roleCollection", required: true },

    firstName: {
      type: String,
      required: [true, "Please Enter Your First Name"],
      maxLength: [30, "First Name cannot exceed 30 charecters"],
      minLength: [2, "First Name should have more then 2 charecters"],
    },
    lastName: {
      type: String,
      required: [true, "Please Enter Your Last Name"],
      maxLength: [30, "Last Name cannot exceed 30 charecters"],
      minLength: [1, "Last Name should have more then 1 charecters"],
    },
    address: {
      type: String,
      // required: true,
      required: false,
      default: null,
    },
    location: {
      type: {
        type: String,
        enum: ["Point"],
        // required: true,
        required: false,
        default: "Point",
      },
      coordinates: {
        type: [Number],
        required: true,
        default: [0.0, 0.0],
      },
    },
    city: {
      type: String,
      // required: [true, "Please Enter City"],
      required: false,
      default: null
    },
    state: {
      type: String,
      // required: [true, "Please Enter State"],
      required: false,
      default: null
    },
    zipcode: {
      type: Number,
      required: false,
      default: null,
    },
    profileImage: {
      type: String,
      // required: [true, "Please upload profile image"],
      required: false,
    },
    dob: {
      type: Date,
      default: Date.now,
    },
    gender: {
      type: String,
      enum: ["Male", "Female", "Others"],
      required: false,
      default: null
    },
    dialcode: {
      type: String,
      required: false,
      default: null,
    },
    phone: {
      type: Number,
      // unique: true, 
      required: false,
      default: null,
    },
    email: {
      type: String,
      required: [true, "Please Enter Your Email"],
      // unique: true,
      validate: [validator.isEmail, "Please Enter a valid Email"],
    },
    password: {
      type: String,
      required: [true, "Please Enter Your Password"],
      // minLength: [8, "Password should be greater then 8 charecters"],
      select: false,
    },
    otp: {
      code: {
        type: Number,
        default: null,
      },
      expiration: {
        type: Date,
        default: null,
      },
    },
    webLogin: {
        accessToken: {
            type: String,
            default: null,
        },
        refreshToken: {
            type: String,
            default: null,
        },
    },
    appLogin: {
      provider: {
        type: String,
        default: null,
      },
      accessToken: {
        type: String,
        default: null,
      },
    },
    fcmToken: { type:String, required: false, default: null},

    isActive: { type: Boolean, default: true },
    isVerified: { type: Boolean, default: false },
    isVerifiedEmail: { type: Boolean, default: false },
    isVerifiedPhone: { type: Boolean, default: false },

    isDeleted: { type: Boolean, default: false },
  },
  { timestamps: true }
);

userSchema.pre("save", async function (next) {
  if (!this.isModified("password")) {
    next();
  }
  this.password = await bcrypt.hash(this.password, 10);
});

// userSchema.pre("update", async function (next) {
//   if (!this.isModified("password")) {
//     next();
//   }
//   this.password = await bcrypt.hash(this.password, 10);
// });

userSchema.methods.comparePassword = async function (enteredPassword) {
  return await bcrypt.compare(enteredPassword, this.password);
};

// userSchema.methods.getResetPasswordToken = function () {
//     const resetToken = crypto.randomBytes(20).toString("hex");

//     this.resetPasswordToken = crypto.createHash("sha256")
//         .update(resetToken)
//         .digest("hex");

//     this.resetPasswordExpire = Date.now() + 15 * 60 * 1000;

//     return resetToken;
// }

module.exports = mongoose.model("usersCollection", userSchema);
