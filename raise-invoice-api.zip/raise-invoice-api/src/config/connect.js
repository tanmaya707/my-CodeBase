const mysql = require('mysql');
const mysqlConfig = require("./index").Mysql;
const mysqldb = require('../models');

// ============== MySql connection ==============
const mysqlConnection = mysql.createConnection({
    host: mysqlConfig.host,
    user: mysqlConfig.user,
    password: mysqlConfig.pwd,
    database: mysqlConfig.dbName
});

const connectMySqlDatabase = async () => {
    try {
        await mysqlConnection.connect((err) => {
            if (err) {
                console.error('Error connecting to the database: ' + err.stack);
                return;
            }
            console.log('Connected to the database as ID ' + connection.threadId);
        });
    } catch (error) {
        console.error('Error connecting to MongoDB:', error.message);
        // process.exit(1);
    }
};
// ============== MySql connection ENDs ==============

// ============== mySql Sequilize connection is being done from index of Model folder ==============
mysqldb.sequelizeConnectionInstance.sync({
    alter: true,
    force: false,
    // logging: console.log
});
// ============== mySql Sequilize connection is being done from index of Model folder ENDs ==============

module.exports = {
    connectMySqlDatabase,
};
