require('dotenv').config();
const app = require('./app');
const connectDatabase = require('./src/config/connect');

const Emitter = require('events');
const db = require('./src/models');

// Function to start the server
function startServer() {
  app.listen(process.env.PORT, () => {
    if (process.env.APP_ENV == "production") {
      console.log(`server is listening on ${process.env.APP_URL}`);
    } else {
      console.log(`server is listening on http://localhost:` + process.env.PORT + "/");
    }
  });
}

process.on("uncaughtException", (err) => {
  console.log(`Error: ${err.message}`);
  console.log(`Shutting down the server due to unhandled Uncaught Rejection`);

  server.close(() => {
    startServer();
  });
});

// ===== calls the connection variable of MongoDB from here =====
// connectDatabase.connectMongoDatabase();
// ===== calls the connection variable of MongoDB from here =====

// ===== Sequelize gets called from within the index of model folder =====
// ===== Sequelize gets called from within the index of model folder =====

// Event emitter
const eventEmitter = new Emitter();
app.set('eventEmitter', eventEmitter);

// process.env.TZ = 'Asia/Kolkata';
process.env.TZ = (process.env.APP_ENV == "production") ? process.env.PROD_TZ : process.env.DEV_TZ;

const server = app.listen(process.env.PORT, () => {
  if (process.env.APP_ENV == "production") {
    console.log(`server is working on ${process.env.APP_URL}`);
  } else {
    console.log(`server is working on http://localhost:` + process.env.PORT + "/");
  }
});

process.on("unhandledRejection", (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
  // You can also log the stack trace if the reason is an Error object
  if (reason instanceof Error) {
    console.error('Stack Trace:', reason.stack);
  }

  // Close the server gracefully
  server.close(() => {
    console.log('Server closed. Restarting...');

    // Restart the server after it's closed
    startServer();
  });
});
