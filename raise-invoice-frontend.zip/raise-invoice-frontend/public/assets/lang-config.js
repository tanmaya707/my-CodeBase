// window.__GOOGLE_TRANSLATION_CONFIG__ = {
//     languages: [
//         { title: 'English', name: 'en' },
//         { title: 'Deutsch', name: 'de' },
//         { title: 'Español', name: 'es' },
//         { title: 'Français', name: 'fr' },
//     ],
//     defaultLanguage: 'en',
// };