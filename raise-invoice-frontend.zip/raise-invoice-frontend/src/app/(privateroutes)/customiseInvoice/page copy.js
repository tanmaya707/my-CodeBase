"use client";
import React, { useEffect, useState, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import { IMAGE } from "@/utils/Theme";
import Accordion from "react-bootstrap/Accordion";
import Pageheader from "@/utils/pageheader";
import Form from "react-bootstrap/Form";
import { ToastContainer, toast } from "react-toastify";
import { useRouter } from "next/navigation";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faSquarePlus } from "@fortawesome/free-solid-svg-icons";
import {
  listLogosData,
  listColorsData,
  listWaterMarksData,
  listHeadersData,
  createCustomInvoiceData,
  getCustomInvoiceData,
} from "@/redux/slices/dataSlice";
import "./customise.css";
import "../client-communication/communication.css";
import "../../general.css";
import CustomInvoiceImpact from "@/Components/customInvoice/impact";
import CustomInvoiceModern from "@/Components/customInvoice/modern";
import CustomInvoiceClassic from "@/Components/customInvoice/classic";

const CustomiseInvoice = () => {
  const dispatch = useDispatch();
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [selectedTemp, setSelectedTemp] = useState("impact");
  const [selectedId, setSelectedId] = useState(null);
  const [selectedSize, setSelectedSize] = useState("medium");
  const [alignPos, setAlignPos] = useState("left");
  const [selectedColour, setSelectedColour] = useState(null);
  const [customColour, setCustomColour] = useState("");
  const [selectedHeader, setSelectedHeader] = useState(null);
  const [selectedWatermark, setSelectedWatermark] = useState(null);

  const { logos, colors, headers, waterMarks } = useSelector(
    (state) => state.dataReducer
  );

  const logoInputRef = useRef(null);
  const headerInputRef = useRef(null);
  const watermarkInputRef = useRef(null);

  useEffect(() => {
    dispatch(listLogosData());
    dispatch(listColorsData());
    dispatch(listWaterMarksData());
    dispatch(listHeadersData());
    dispatch(getCustomInvoiceData());
  }, [dispatch]);

  const handleSave = async () => {
    if (!validateForm()) return;
    const payload = {
      templateName: selectedTemp,
      logoId: selectedId ? selectedId.id : "",
      logoSize: selectedSize,
      logoPosition: alignPos,
      colourId: selectedColour?.id || "",
      customColour: customColour || "",
      headerId: selectedHeader ? selectedHeader.id : "",
      waterMarkId: selectedWatermark ? selectedWatermark.id : "",
    };

    try {
      const response = await dispatch(
        createCustomInvoiceData(payload)
      ).unwrap();

      response.status
        ? toast.success(response.message)
        : toast.error(response.message);
      router.refresh();
      router.push(`/customiseInvoice`);
    } catch (error) {
      console.error("Error saving invoice:", error);
    } finally {
      setLoading(false);
    }
  };

  const validateForm = () => {
    if (!selectedTemp) {
      alert("Please select a template.");
      return false;
    }
    if (!selectedId) {
      alert("Please select a logo.");
      return false;
    }
    if (!alignPos) {
      alert("Please select an alignment position.");
      return false;
    }
    if (!selectedColour && !customColour) {
      alert("Please select or enter a color.");
      return false;
    }
    if (!selectedHeader) {
      alert("Please select a header.");
      return false;
    }
    if (!selectedWatermark) {
      alert("Please select a watermark.");
      return false;
    }
    return true;
  };

  // Logo upload
  const handleLogoUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const newLogo = {
        id: "custom-logo-" + Date.now(),
        logoImage: URL.createObjectURL(file),
        name: file.name,
      };
      setSelectedId(newLogo);
    }
  };

  // Header upload
  const handleHeaderUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const newHeader = {
        id: "custom-header-" + Date.now(),
        headerImage: URL.createObjectURL(file),
        name: file.name,
      };
      setSelectedHeader(newHeader);
    }
  };

  // Watermark upload
  const handleWatermarkUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const newWatermark = {
        id: "custom-watermark-" + Date.now(),
        watermarkImage: URL.createObjectURL(file),
        name: file.name,
      };
      setSelectedWatermark(newWatermark);
    }
  };

  // Color selection
  const handleColourSelect = (item) => {
    setSelectedColour(item);
    setCustomColour("");
  };

  // Custom color input
  const handleCustomColourChange = (e) => {
    setCustomColour(e.target.value);
    setSelectedColour(null);
  };

  return (
    <>
      <div className="col-lg-4">
        <div className="communication-container customise">
          <Pageheader
            label="Customize invoice"
            handleSave={handleSave}
            loading={loading}
          />
          <Accordion>
            {/* Template */}
            <Accordion.Item eventKey="0">
              <Accordion.Header>
                <p className="accorheading">Template</p>
              </Accordion.Header>
              <Accordion.Body>
                <div className="row">
                  {["impact", "classic", "modern"].map((temp) => (
                    <div className="col-lg-4" key={temp}>
                      <div
                        className={`selectImage ${
                          selectedTemp === temp ? "active" : ""
                        }`}
                      >
                        <img
                          className="bill-img"
                          src={IMAGE.logo1}
                          alt={temp}
                        />
                        <Form.Check
                          className="checkbox-form"
                          type="radio"
                          name="templateSelection"
                          checked={selectedTemp === temp}
                          onChange={() => setSelectedTemp(temp)}
                        />
                      </div>
                      <p className="title">
                        {temp.charAt(0).toUpperCase() + temp.slice(1)}
                      </p>
                    </div>
                  ))}
                </div>
              </Accordion.Body>
            </Accordion.Item>

            {/* Logo */}
              <Accordion.Item eventKey="1">
              <Accordion.Header>
                <p className="accorheading">Logo</p>
              </Accordion.Header>
              <Accordion.Body>
                <div className="logoHeader">
                  <ul>
                    {tabList.map((item, index) => (
                      <li
                        key={index}
                        onClick={() => setTab(item.id)}
                        className={tab === item.id ? "active" : ""}
                      >
                        {item.title}
                      </li>
                    ))}
                  </ul>
                  {!tab ? (
                    <div className="row">
                      {logos?.data?.map((item, index) => (
                        <div className="col-lg-3" key={index}>
                          <div
                            className={`selectImage ${
                              selectedId?.id === item.id ? "active" : ""
                            }`}
                          >
                            <img
                              className="bill-img"
                              src={item.logoImage}
                              alt="bill1"
                              width={"95"}
                              height={"80"}
                              onClick={() => setSelectedId(item)}
                            />
                            <Form.Check
                              type="radio"
                              name="logoSelection"
                              checked={selectedId?.id === item.id}
                              onChange={() => setSelectedId(item)}
                            />
                          </div>
                        </div>
                      ))}
                      <div className="col-lg-4">
                        <div
                          className={`card image-card ${
                            !selectedId ? "active" : ""
                          }`}
                        >
                          <div className="card-body">
                            <img src={IMAGE.image} alt="None" />
                            <button
                              className="add-photo"
                              onClick={() => setSelectedId(null)}
                            >
                              None
                            </button>
                            <Form.Check
                              className="checkbox-form"
                              type="radio"
                              name="logoSelection"
                              checked={!selectedId}
                              onChange={() => setSelectedId(null)}
                            />
                          </div>
                        </div>
                      </div>
                      <div className="col-lg-4">
                        <div className="card image-card pdfParaMargin">
                          <div className="card-body">
                            <FontAwesomeIcon icon={faSquarePlus} />
                            <button
                              className="add-photo"
                              onClick={handleAddPhotoClick}
                            >
                              Add Photo
                            </button>
                            <input
                              type="file"
                              ref={fileInputRef}
                              style={{ display: "none" }}
                              accept="image/*"
                              onChange={handleFileUpload}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="positionInner">
                      <div className="positionInnerList">
                        <p>Alignment</p>
                        <ul>
                          {["left", "center", "right"].map((option) => (
                            <li key={option}>
                              <label>
                                <Form.Check
                                  type="radio"
                                  name="alignment"
                                  value={option}
                                  checked={alignPos === option}
                                  onChange={() => setAlignPos(option)}
                                  label={
                                    option.charAt(0).toUpperCase() +
                                    option.slice(1)
                                  }
                                />
                              </label>
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div className="positionInnerList">
                        <p>Size</p>
                        <ul>
                          {["small", "medium", "large"].map((size) => (
                            <li key={size}>
                              <label>
                                <Form.Check
                                  type="radio"
                                  name="size"
                                  value={size}
                                  checked={selectedSize === size}
                                  onChange={() => setSelectedSize(size)}
                                  label={
                                    size.charAt(0).toUpperCase() + size.slice(1)
                                  }
                                />
                              </label>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  )}
                </div>
              </Accordion.Body>
            </Accordion.Item>

            {/* Color */}
            <Accordion.Item eventKey="2">
              <Accordion.Header>
                <p className="accorheading">Color</p>
              </Accordion.Header>
              <Accordion.Body>
                <div className="row">
                  {colors?.data?.map((item, index) => (
                    <div className="col-lg-12 m-2" key={index}>
                      <div
                        className={`color-option ${
                          selectedColour?.id === item.id ? "active" : ""
                        }`}
                      >
                        <div
                          className="color-box"
                          style={{ backgroundColor: item.colourCode }}
                          onClick={() => handleColourSelect(item)}
                        ></div>
                          {selectedColour?.id === item.id && (
                            <div className="color-selection-check">
                              <span>✓</span>
                            </div>
                          )}
                        </div>
                        <div className="color-radio">
                          <Form.Check
                            type="radio"
                            name="colorSelection"
                            id={`color-${item.id}`}
                            checked={selectedColour?.id === item.id}
                            onChange={() => handleColourSelect(item)}
                            label={item.colourName || item.colourCode}
                          />
                        </div>
                      </div>
                  ))}
                </div>
                <div className="row mt-3">
                  <div className="col-lg-12">
                    <label>Pick a color:</label>
                    <input
                      type="color"
                      value={customColour || "#000000"}
                      onChange={(e) => handleCustomColourChange({ target: { value: e.target.value } })}
                      style={{ marginLeft: "10px", marginRight: "10px" }}
                    />
                    <label>Or enter hex code:</label>
                    <input
                      type="text"
                      placeholder="#000000"
                      value={customColour}
                      onChange={handleCustomColourChange}
                      style={{ marginLeft: "10px" }}
                    />
                  </div>
                </div>
              </Accordion.Body>
            </Accordion.Item>

            {/* Header */}
            <Accordion.Item eventKey="3">
              <Accordion.Header>
                <p className="accorheading">Header</p>
              </Accordion.Header>
              <Accordion.Body>
                <div className="row">
                  {headers?.data?.map((item, index) => (
                    <div className="col-lg-4" key={index}>
                      <div
                        className={`header-option ${
                          selectedHeader?.id === item.id ? "active" : ""
                        }`}
                      >
                        <img
                          src={item.headerImage}
                          alt="Header"
                          className="header-image"
                          style={{ maxWidth: "200px", maxHeight: "100px" }}
                          onClick={() => setSelectedHeader(item)}
                        />
                        <div className="header-radio">
                          <Form.Check
                            type="radio"
                            name="headerSelection"
                            id={`header-${item.id}`}
                            checked={selectedHeader?.id === item.id}
                            onChange={() => setSelectedHeader(item)}
                            label={`Header ${index + 1}`}
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                  {/* None */}
                  <div className="col-lg-4">
                    <div
                      className={`card image-card ${
                        !selectedHeader ? "active" : ""
                      }`}
                    >
                      <div className="card-body"></div>
                        <img src={IMAGE.image} alt="None" />
                        <button
                          className="add-photo"
                          onClick={() => setSelectedHeader(null)}
                        >
                          None
                        </button>
                        <Form.Check
                          className="checkbox-form"
                          type="radio"
                          name="headerSelection"
                          checked={!selectedHeader}
                          onChange={() => setSelectedHeader(null)}
                        />
                      </div>
                    </div>
                  </div>
                  {/* Upload */}
                  <div className="col-lg-4">
                    <div className="card image-card pdfParaMargin">
                      <div className="card-body">
                        <FontAwesomeIcon icon={faSquarePlus} />
                        <button
                          className="add-photo"
                          onClick={() => headerInputRef.current.click()}
                        >
                          Add Photo
                        </button>
                        <input
                          type="file"
                          ref={headerInputRef}
                          style={{ display: "none" }}
                          accept="image/*"
                          onChange={handleHeaderUpload}
                        />
                      </div>
                    </div>
                  </div>
              </Accordion.Body>
            </Accordion.Item>

            {/* Watermark */}
            <Accordion.Item eventKey="4">
              <Accordion.Header>
                <p className="accorheading">Watermark</p>
              </Accordion.Header>
              <Accordion.Body>
                <div className="row">
                  {waterMarks?.data?.map((item, index) => (
                    <div className="col-lg-4" key={index}>
                      <div
                        className={`watermark-option ${
                          selectedWatermark?.id === item.id ? "active" : ""
                        }`}
                      >
                        <img
                          src={item.watermarkImage}
                          alt="Watermark"
                          className="watermark-image"
                          style={{ maxWidth: "200px", maxHeight: "100px" }}
                          onClick={() => setSelectedWatermark(item)}
                        />
                        <div className="watermark-radio">
                          <Form.Check
                            type="radio"
                            name="watermarkSelection"
                            id={`watermark-${item.id}`}
                            checked={selectedWatermark?.id === item.id}
                            onChange={() => setSelectedWatermark(item)}
                            label={`Watermark ${index + 1}`}
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                  {/* None */}
                  <div className="col-lg-4">
                    <div
                      className={`card image-card ${
                        !selectedWatermark ? "active" : ""
                      }`}
                    >
                      <div className="card-body">
                        <img src={IMAGE.image} alt="None" />
                        <button
                          className="add-photo"
                          onClick={() => setSelectedWatermark(null)}
                        >
                          None
                        </button>
                        <Form.Check
                          className="checkbox-form"
                          type="radio"
                          name="watermarkSelection"
                          checked={!selectedWatermark}
                          onChange={() => setSelectedWatermark(null)}
                        />
                      </div>
                    </div>
                  </div>
                  {/* Upload */}
                  <div className="col-lg-4">
                    <div className="card image-card pdfParaMargin">
                      <div className="card-body">
                        <FontAwesomeIcon icon={faSquarePlus} />
                        <button
                          className="add-photo"
                          onClick={() => watermarkInputRef.current.click()}
                        >
                          Add Photo
                        </button>
                        <input
                          type="file"
                          ref={watermarkInputRef}
                          style={{ display: "none" }}
                          accept="image/*"
                          onChange={handleWatermarkUpload}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </Accordion.Body>
            </Accordion.Item>
          </Accordion>
        </div>
      </div>

      <div className="col-lg-8 billMargin">
        <div className="bill-section">
          {selectedTemp == "impact" && (
            <CustomInvoiceImpact
              selectedTemp={selectedTemp}
              selectedId={selectedId}
              selectedSize={selectedSize}
              alignPos={alignPos}
              selectedColour={selectedColour}
              customColour={customColour}
              selectedHeader={selectedHeader}
              selectedWatermark={selectedWatermark}
            />
          )}
          {selectedTemp == "modern" && (
            <CustomInvoiceModern
              selectedTemp={selectedTemp}
              selectedId={selectedId}
              selectedSize={selectedSize}
              alignPos={alignPos}
              selectedColour={selectedColour}
              customColour={customColour}
              selectedHeader={selectedHeader}
              selectedWatermark={selectedWatermark}
            />
          )}
          {selectedTemp == "classic" && (
            <CustomInvoiceClassic
              selectedTemp={selectedTemp}
              selectedId={selectedId}
              selectedSize={selectedSize}
              alignPos={alignPos}
              selectedColour={selectedColour}
              customColour={customColour}
              selectedHeader={selectedHeader}
              selectedWatermark={selectedWatermark}
            />
          )}
        </div>
      </div>
    </>
  );
};

export default CustomiseInvoice;
