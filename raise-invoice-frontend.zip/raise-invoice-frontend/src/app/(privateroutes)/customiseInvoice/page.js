/* eslint-disable @next/next/no-img-element */
"use client";
import React, { useEffect, useState, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import { IMAGE } from "@/utils/Theme";
import Accordion from "react-bootstrap/Accordion";
import Pageheader from "@/utils/pageheader";
import Form from "react-bootstrap/Form";
import { ToastContainer, toast } from "react-toastify";
import { useRouter } from "next/navigation";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faSquarePlus } from "@fortawesome/free-solid-svg-icons";
import {
  listColorsData,
  createCustomInvoiceData,
  getCustomInvoiceData,
  createCustomInvoiceOptionData,
  getCustomInvoiceOptionData,
  createLogosData,
  listLogosData,
  deleteLogosData,
  uploadHeader,
  listHeadersData,
  deleteHeaderData,
  uploadWatermark,
  listWaterMarksData,
  deleteWaterMarksData,
} from "@/redux/slices/dataSlice";
import "./customise.css";
import "../client-communication/communication.css";
import "../../general.css";
import CustomInvoiceImpact from "@/Components/customInvoice/impact";
import CustomInvoiceModern from "@/Components/customInvoice/modern";
import CustomInvoiceClassic from "@/Components/customInvoice/classic";

const THUMB_W = 105 ;
const THUMB_H = 85;

const CustomiseInvoice = () => {
  const dispatch = useDispatch();
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  // State for all fields
  const [formData, setFormData] = useState({
    id: null, // for update
    templateName: "impact",
    logoId: "",
    logoImage: "",
    logoSize: "medium",
    logoPosition: "center",
    colourId: "",
    colourCode: "",
    customColour: "",
    headerId: "",
    headerImg: "",
    waterMarkId: "",
    waterMarkImg: "",
  });

  const { logos, colors, headers, waterMarks, customTemplates } = useSelector(
    (state) => state.dataReducer
  );

  const [tab, setTab] = useState(0);
  const logoInputRef = useRef(null);
  const headerInputRef = useRef(null);
  const watermarkInputRef = useRef(null);

  // Option data state
  const [optionData, setOptionData] = useState({
          id: null,
          shippingDetails: false,
          due_date: false,
          payment_terms: false,
          itemCode: false,
          quantityAndRate: false,
          pTax: false,
          tax_amounts: false,
          includeSignatureLine: false,
          invoicePrifix: "",
      });

  useEffect(() => {
    const init = async () => {
      // setLoading(true);
      try {
        await dispatch(listLogosData()).unwrap();
        await dispatch(listColorsData()).unwrap();
        await dispatch(listWaterMarksData()).unwrap();
        await dispatch(listHeadersData()).unwrap();

        const customRes = await dispatch(getCustomInvoiceData()).unwrap();
        const data = customRes?.payload?.data;
        if (data) {
          setFormData({
            id: data.id || null,
            templateName: data.name || "impact",
            logoId: data.logoDetails?.id || "",
            logoImage: data.logoDetails?.logoImage || "",
            logoSize: data.logoSize || "medium",
            logoPosition: data.logoPosition || "center",
            colourId: data.colourDetails?.id || "",
            colourCode: data.colourDetails?.colourCode || "",
            customColour: data.colourDetails?.customColour || "",
            headerId: data.headerDetails?.id || "",
            headerImg: data.headerDetails?.headerImg || "",
            waterMarkId: data.waterMarkDetails?.id || "",
            waterMarkImg: data.waterMarkDetails?.waterMarkImg || "",
          });
        } else if (customTemplates) {
          setFormData({
            id: customTemplates.data?.id || null,
            templateName: customTemplates.data?.name || "impact",
            logoId: customTemplates.logoDetails?.id || "",
            logoImage: customTemplates.data?.logoDetails?.logoImage || "",
            logoSize: customTemplates.data?.logoSize || "medium",
            logoPosition: customTemplates.data?.logoPosition || "center",
            colourId: customTemplates.data?.colourDetails?.id || "",
            colourCode: customTemplates.data?.colourDetails?.colourCode || "",
            customColour: customTemplates.data?.colourDetails?.customColour || "",
            headerId: customTemplates.data?.headerDetails?.id || "",
            headerImg: customTemplates.data?.headerDetails?.headerImg || "",
            waterMarkId: customTemplates.data?.waterMarkDetails?.id || "",
            waterMarkImg:
              customTemplates.data?.waterMarkDetails?.waterMarkImg || "",
          });
        }

        const optRes = await dispatch(getCustomInvoiceOptionData()).unwrap();
        setOptionData(
          optRes?.payload?.data || {
            id: null,
            shippingDetails: false,
            due_date: false,
            payment_terms: false,
            itemCode: false,
            quantityAndRate: false,
            pTax: false,
            tax_amounts: false,
            includeSignatureLine: false,
            invoicePrifix: "",
          }
        );
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    init();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dispatch]);

  const refreshLogos = async () => {
    try {
      await dispatch(listLogosData()).unwrap();
    } catch (err) {
      console.error(err);
    }
  };
  const refreshHeaders = async () => {
    try {
      await dispatch(listHeadersData()).unwrap();
    } catch (err) {
      console.error(err);
    }
  };
  const refreshWatermarks = async () => {
    try {
      await dispatch(listWaterMarksData()).unwrap();
    } catch (err) {
      console.error(err);
    }
  };

  const handleLogoUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const form = new FormData();
    form.append("logoImage", file);
    // setLoading(true);
    try {
      const res = await dispatch(createLogosData(form)).unwrap();
      if (res.status) {
        // refresh list so uploaded image appears in list cards (we render list before None)
        await refreshLogos();
        setFormData((prev) => ({
          ...prev,
          logoId: res.data.id,
          logoImage: res.data.logoImage,
        }));
        toast.success(res.message || "Logo uploaded");
      } else {
        toast.error(res.message || "Logo upload failed");
      }
    } catch (err) {
      console.error(err);
      toast.error("Logo upload error");
    } finally {
      setLoading(false);
      // reset input value so same file can be selected again
      if (logoInputRef.current) logoInputRef.current.value = "";
    }
  };

  const handleHeaderUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const form = new FormData();
    form.append("headerImg", file);
    // setLoading(true);
    try {
      const res = await dispatch(uploadHeader(form)).unwrap();
      if (res.status) {
        await refreshHeaders();
        setFormData((prev) => ({
          ...prev,
          headerId: res.data.id,
          headerImg: res.data.headerImg,
        }));
        toast.success(res.message || "Header uploaded");
      } else {
        toast.error(res.message || "Header upload failed");
      }
    } catch (err) {
      console.error(err);
      toast.error("Header upload error");
    } finally {
      setLoading(false);
      if (headerInputRef.current) headerInputRef.current.value = "";
    }
  };

  const handleWatermarkUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const form = new FormData();
    form.append("waterMarkImg", file);
    // setLoading(true);
    try {
      const res = await dispatch(uploadWatermark(form)).unwrap();
      if (res.status) {
        await refreshWatermarks();
        setFormData((prev) => ({
          ...prev,
          waterMarkId: res.data.id,
          waterMarkImg: res.data.waterMarkImg,
        }));
        toast.success(res.message || "Watermark uploaded");
      } else {
        toast.error(res.message || "Watermark upload failed");
      }
    } catch (err) {
      console.error(err);
      toast.error("Watermark upload error");
    } finally {
      setLoading(false);
      if (watermarkInputRef.current) watermarkInputRef.current.value = "";
    }
  };

  const handleDeleteLogo = async (id) => {
    if (!id) return;
    // setLoading(true);
    try {
      const res = await dispatch(deleteLogosData({"id": id})).unwrap();
      if (res.status) {
        await refreshLogos();
        if (formData.logoId === id) {
          setFormData((prev) => ({ ...prev, logoId: "", logoImage: "" }));
        }
        toast.success(res.message || "Logo deleted");
      } else {
        toast.error(res.message || "Delete failed");
      }
    } catch (err) {
      console.error(err);
      toast.error("Delete error");
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteHeader = async (id) => {
    if (!id) return;
    // setLoading(true);
    try {
      const res = await dispatch(deleteHeaderData({"id": id})).unwrap();
      if (res.status) {
        await refreshHeaders();
        if (formData.headerId === id) {
          setFormData((prev) => ({ ...prev, headerId: "", headerImg: "" }));
        }
        toast.success(res.message || "Header deleted");
      } else {
        toast.error(res.message || "Delete failed");
      }
    } catch (err) {
      console.error(err);
      toast.error("Delete error");
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteWatermark = async (id) => {
    if (!id) return;
    // setLoading(true);
    try {
      const res = await dispatch(deleteWaterMarksData({"id": id})).unwrap();
      if (res.status) {
        await refreshWatermarks();
        if (formData.waterMarkId === id) {
          setFormData((prev) => ({ ...prev, waterMarkId: "", waterMarkImg: "" }));
        }
        toast.success(res.message || "Watermark deleted");
      } else {
        toast.error(res.message || "Delete failed");
      }
    } catch (err) {
      console.error(err);
      toast.error("Delete error");
    } finally {
      setLoading(false);
    }
  };

  const handleColourSelect = (item) => {
    setFormData((prev) => ({
      ...prev,
      colourId: item.id,
      colourCode: item.colourCode,
      customColour: "",
    }));
  };

  // Custom color input
  const handleCustomColourChange = (e) => {
    setFormData((prev) => ({
      ...prev,
      customColour: e.target.value,
      colourId: "",
      colourCode: "",
    }));
  };

  // Save handler
  const handleSave = async () => {
    setLoading(true);
    const payload = { ...formData };
    try {
      const response = await dispatch(createCustomInvoiceData(payload)).unwrap();
      response.status ? toast.success(response.message) : toast.error(response.message);
      router.refresh();
      router.push(`/profile`);
    } catch (error) {
      toast.error("Error saving invoice");
    } finally {
      setLoading(false);
    }
  };

  const tabList = [
    { title: "Image", id: 0 },
    { title: "Position", id: 1 },
  ];

  const thumbStyle = { width: THUMB_W, height: THUMB_H, objectFit: "contain" };
  const crossStyle = {
    position: "absolute",
    top: 2,
    right: 3,
    background: "rgba(248, 7, 7, 0.6)",
    color: "#fff",
    border: "none",
    borderRadius: "50%",
    width: 16,
    height: 16,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    cursor: "pointer",
    zIndex: 5,
  };

 return (
  <>
    <ToastContainer />
    <div className="col-lg-4 fixedHeader">
      <div className="communication-container customise">
        <Pageheader label="Customize invoice" handleSave={handleSave} loading={loading} />
        <Accordion  defaultActiveKey="0" alwaysOpen>
          <Accordion.Item className="templateImageCss" eventKey="0">
            <Accordion.Header>
              <p className="accorheading">Template</p>
            </Accordion.Header>
            <Accordion.Body>
              <div className="row">
                {["impact", "classic", "modern"].map((temp) => (
                  <div className="col-lg-4" key={temp}>
                    <div
                      className={`selectImage ${formData.templateName === temp ? "active" : ""}`}
                      onClick={() => setFormData((prev) => ({ ...prev, templateName: temp }))}
                      style={{ cursor: "pointer" }}
                    >
                      <img
                        className="bill-img"
                        src={IMAGE.logo1}
                        alt={temp}
                      />
                      <div className="image-radio">
                        <Form.Check
                          className="checkbox-form"
                          type="radio"
                          name="templateSelection"
                          checked={formData.templateName === temp}
                          onChange={() =>
                            setFormData((prev) => ({
                              ...prev,
                              templateName: temp,
                            }))
                          }
                        />
                      </div>
                    </div>
                    <p className="title">{temp.charAt(0).toUpperCase() + temp.slice(1)}</p>
                  </div>
                ))}
              </div>
            </Accordion.Body>
          </Accordion.Item>

          <Accordion.Item eventKey="1">
            <Accordion.Header>
              <p className="accorheading">Logo</p>
            </Accordion.Header>
            <Accordion.Body>
              <div className="logoHeader logoSectionlisting">
                <ul>
                  {tabList.map((item) => (
                    <li key={item.id} onClick={() => setTab(item.id)} className={tab === item.id ? "active" : ""}>
                      {item.title}
                    </li>
                  ))}
                </ul>
                {!tab ? (
                  <div className="topLOgosection">
                    <div className={`card image-card logoHeaderImages ${!formData.logoId ? "active" : ""}`} style={{ position: "relative" }} onClick={() => setFormData((prev) => ({ ...prev, logoId: "", logoImage: "" }))}>
                      <div className="card-body">
                        <img src={IMAGE.image} alt="None" />
                        <button
                          className="add-photo"
                          onClick={(e) => {
                            e.stopPropagation();
                            setFormData((prev) => ({
                              ...prev,
                              logoId: "",
                              logoImage: "",
                            }));
                          }}
                        >
                          None
                        </button>
                      </div>
                    </div>

                    <div className="card image-card logoHeaderImages" style={{ cursor: "pointer" }} onClick={() => logoInputRef.current.click()}>
                      <div className="card-body">
                        <FontAwesomeIcon icon={faSquarePlus} />
                        <button
                          className="add-photo"
                          onClick={(e) => {
                            e.stopPropagation();
                            logoInputRef.current.click();
                          }}
                        >
                          Add Photo
                        </button>
                        <input type="file" ref={logoInputRef} style={{ display: "none" }} accept="image/*" onChange={handleLogoUpload} />
                      </div>
                    </div>

                    {logos?.data?.map((item, index) => (
                      <div className="customLogo" key={item.id ?? index}>
                        <div
                          className={`selectImage ${formData.logoId === item.id ? "active" : ""}`}
                          style={{ position: "relative", cursor: "pointer" }}
                          onClick={() =>
                            setFormData((prev) => ({
                              ...prev,
                              logoId: item.id,
                              logoImage: item.logoImage,
                            }))
                          }
                        >
                          <button
                            type="button"
                            style={crossStyle}
                            title="Delete"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDeleteLogo(item.id);
                            }}
                          >
                            ×
                          </button>

                          <img
                            className="bill-img"
                            src={item.logoImage}
                            alt={`logo-${item.id}`}
                            style={thumbStyle}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="positionInner">
                    <div className="positionInnerList" style={{ padding: "20px 0px" }}>
                      <p>Alignment</p>
                      <ul>
                        {["left", "center", "right"].map((option) => (
                          <li key={option}>
                            <label>
                              <Form.Check
                                type="radio"
                                name="alignment"
                                value={option}
                                checked={formData.logoPosition === option}
                                onChange={() =>
                                  setFormData((prev) => ({
                                    ...prev,
                                    logoPosition: option,
                                  }))
                                }
                                label={option.charAt(0).toUpperCase() + option.slice(1)}
                              />
                            </label>
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div className="positionInnerList">
                      <p>Size</p>
                      <ul>
                        {["small", "medium", "large"].map((size) => (
                          <li key={size}>
                            <label>
                              <Form.Check
                                type="radio"
                                name="size"
                                value={size}
                                checked={formData.logoSize === size}
                                onChange={() =>
                                  setFormData((prev) => ({
                                    ...prev,
                                    logoSize: size,
                                  }))
                                }
                                label={size.charAt(0).toUpperCase() + size.slice(1)}
                              />
                            </label>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                )}
              </div>
            </Accordion.Body>
          </Accordion.Item>

          {/* Color */}
          <Accordion.Item eventKey="2">
            <Accordion.Header>
              <p className="accorheading">Color</p>
            </Accordion.Header>
            <Accordion.Body>
              <div className="row">
                {colors?.data?.map((item, index) => (
                  <div className="col-lg-12" key={item.id || index}>
                    <div className={`color-option ${formData.colourId === item.id ? "active" : ""}`}>
                      <div className="color-box" style={{ backgroundColor: item.colourCode }} onClick={() => handleColourSelect(item)} />
                      <div className="color-radio">
                        <Form.Check
                          type="radio"
                          name="colorSelection"
                          id={`color-${item.id}`}
                          checked={formData.colourId === item.id}
                          onChange={() => handleColourSelect(item)}
                          label={item.colourName || item.colourCode}
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="row ">
                <div className="col-lg-12">
                  <div className="pickHederColor">
                    <div className="pickHederColorLeft">
                      <label>Pick a color: </label>
                      <input type="color" value={formData.customColour || "#000000"} onChange={handleCustomColourChange} style={{ marginLeft: "10px", marginRight: "10px" }} />
                    </div>
                    <div className="pickHederColorRight">
                      <label>Or enter hex code:</label>
                      <input type="text" value={formData.customColour} onChange={handleCustomColourChange} style={{ marginLeft: "10px" }} />
                    </div>
                  </div>
                </div>
              </div>
            </Accordion.Body>
          </Accordion.Item>

          {/* Header */}
          <Accordion.Item eventKey="3">
            <Accordion.Header>
              <p className="accorheading">Header</p>
            </Accordion.Header>
            <Accordion.Body>
              <div className="positionInner topLOgosection">
                <div className={`card image-card logoHeaderImages ${!formData.headerId ? "active" : ""}`}
                  style={{ position: "relative", cursor: "pointer" }}
                  onClick={() =>
                    setFormData((prev) => ({
                      ...prev,
                      headerId: "",
                      headerImg: "",
                    }))
                  }
                >
                  <div className="card-body">
                    <img src={IMAGE.image} alt="None" />
                    <button
                      className="add-photo"
                      onClick={(e) => {
                        e.stopPropagation();
                        setFormData((prev) => ({
                          ...prev,
                          headerId: "",
                          headerImg: "",
                        }));
                      }}
                    >
                      None
                    </button>
                  </div>
                </div>

                <div className="card image-card logoHeaderImages" onClick={() => headerInputRef.current.click()} style={{ cursor: "pointer" }}>
                  <div className="card-body">
                    <FontAwesomeIcon icon={faSquarePlus} />
                    <button
                      className="add-photo"
                      onClick={(e) => {
                        e.stopPropagation();
                        headerInputRef.current.click();
                      }}
                    >
                      Add Photo
                    </button>
                    <input type="file" ref={headerInputRef} style={{ display: "none" }} accept="image/*" onChange={handleHeaderUpload} />
                  </div>
                </div>

                {headers?.data?.map((item, index) => (
                  <div className="customLogo" key={item.id || index}>
                    <div className={`selectImage imageBgselect ${formData.headerId === item.id ? "active" : ""}`} style={{ position: "relative", cursor: "pointer" }}
                      onClick={() =>
                        setFormData((prev) => ({
                          ...prev,
                          headerId: item.id,
                          headerImg: item.headerImg,
                        }))
                      }
                    >
                      <button
                        className="crosBtn"
                        type="button"
                        style={crossStyle}
                        title="Delete"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDeleteHeader(item.id);
                        }}
                      >
                        ×
                      </button>
                      <img
                        className="bill-img"
                        src={item.headerImg}
                        alt="Header"
                        style={thumbStyle}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </Accordion.Body>
          </Accordion.Item>

          <Accordion.Item eventKey="4">
            <Accordion.Header>
              <p className="accorheading">Watermark</p>
            </Accordion.Header>
            <Accordion.Body>
              <div className="topLOgosection">
                <div className={`card image-card logoHeaderImages ${!formData.waterMarkId ? "active" : ""}`} style={{ position: "relative", cursor: "pointer" }}
                  onClick={() =>
                    setFormData((prev) => ({
                      ...prev,
                      waterMarkId: "",
                      waterMarkImg: "",
                    }))
                  }
                >
                  <div className="card-body">
                    <img src={IMAGE.image} alt="None" />
                    <button
                      className="add-photo"
                      onClick={(e) => {
                        e.stopPropagation();
                        setFormData((prev) => ({
                          ...prev,
                          waterMarkId: "",
                          waterMarkImg: "",
                        }));
                      }}
                    >
                      None
                    </button>
                  </div>
                </div>

                <div className="card image-card logoHeaderImages" onClick={() => watermarkInputRef.current.click()} style={{ cursor: "pointer" }}>
                  <div className="card-body">
                    <FontAwesomeIcon icon={faSquarePlus} />
                    <button
                      className="add-photo"
                      onClick={(e) => {
                        e.stopPropagation();
                        watermarkInputRef.current.click();
                      }}
                    >
                      Add Photo
                    </button>
                    <input type="file" ref={watermarkInputRef} style={{ display: "none" }} accept="image/*" onChange={handleWatermarkUpload} />
                  </div>
                </div>

                {waterMarks?.data?.map((item, index) => (
                  <div className="customLogo" key={item.id || index}>
                    <div
                      className={`selectImage imageBgselect ${formData.waterMarkId === item.id ? "active" : ""}`}
                      style={{ position: "relative", cursor: "pointer" }}
                      onClick={() =>
                        setFormData((prev) => ({
                          ...prev,
                          waterMarkId: item.id,
                          waterMarkImg: item.waterMarkImg,
                        }))
                      }
                    >
                      <button className="crosBtn"
                        type="button"
                        style={crossStyle}
                        title="Delete"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDeleteWatermark(item.id);
                        }}
                      >
                        ×
                      </button>
                      <img
                        src={item.waterMarkImg}
                        alt="Watermark"
                        className="bill-img"
                        style={thumbStyle}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </Accordion.Body>
          </Accordion.Item>
        </Accordion>
      </div>
    </div>

    <div className="col-lg-8 billMargin">
      <div className="bill-section-uppersection">
        <div className="bill-section">
          {formData.templateName === "impact" && (
            <CustomInvoiceImpact
              selectedTemp={formData.templateName}
              selectedId={
                formData.logoId ? { id: formData.logoId, logoImage: formData.logoImage } : null
              }
              selectedSize={formData.logoSize}
              alignPos={formData.logoPosition}
              selectedColour={formData.colourId ? { id: formData.colourId, colourCode: formData.colourCode } : null}
              customColour={formData.customColour}
              selectedHeader={formData.headerId ? { id: formData.headerId, headerImg: formData.headerImg } : null}
              selectedWatermark={formData.waterMarkId ? { id: formData.waterMarkId, waterMarkImg: formData.waterMarkImg } : null}
              customTemplates={customTemplates}
              customOption={optionData}
            />
          )}
          {formData.templateName === "modern" && (
            <CustomInvoiceModern
              selectedTemp={formData.templateName}
              selectedId={
                formData.logoId ? { id: formData.logoId, logoImage: formData.logoImage } : null
              }
              selectedSize={formData.logoSize}
              alignPos={formData.logoPosition}
              selectedColour={formData.colourId ? { id: formData.colourId, colourCode: formData.colourCode } : null}
              customColour={formData.customColour}
              selectedHeader={formData.headerId ? { id: formData.headerId, headerImg: formData.headerImg } : null}
              selectedWatermark={formData.waterMarkId ? { id: formData.waterMarkId, waterMarkImg: formData.waterMarkImg } : null}
              customOption={optionData}
            />
          )}
          {formData.templateName === "classic" && (
            <CustomInvoiceClassic
              selectedTemp={formData.templateName}
              selectedId={
                formData.logoId ? { id: formData.logoId, logoImage: formData.logoImage } : null
              }
              selectedSize={formData.logoSize}
              alignPos={formData.logoPosition}
              selectedColour={formData.colourId ? { id: formData.colourId, colourCode: formData.colourCode } : null}
              customColour={formData.customColour}
              selectedHeader={formData.headerId ? { id: formData.headerId, headerImg: formData.headerImg } : null}
              selectedWatermark={formData.waterMarkId ? { id: formData.waterMarkId, waterMarkImg: formData.waterMarkImg } : null}
              customOption={optionData}
            />
          )}
        </div>
      </div>
    </div>
  </>
);

};

export default CustomiseInvoice;