import React from 'react'
import { IMAGE } from '@/utils/Theme';
import Link from 'next/link';
import './landing.css';

const Landing = () => {
  return (
    <div className='landing-page'>
      <div className='message'>
        <h2 className='welcome'>Hi Nehal! Welcome to <br/><span>RaiseInvoice</span></h2>
        <p className='mt-3'>Thank you for choosing us. Your free 30 days trial has started </p>
        <img className='underarrow' src={IMAGE.underarrow}/>
        <div>
          <Link className='invoice my-5' href={{}}>Create Your First Invoice <img className='bluearrow' src={IMAGE.blue_arrow}/></Link>
        </div>
        <img className='quote' src={IMAGE.quoteimg}/>
      </div>
      <div>
        <img className='hand' src={IMAGE.hand}/>
      </div>
    </div>
  )
}

export default Landing
