"use client";
import React, { useState, useEffect, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import Accordion from "react-bootstrap/Accordion";
import Pageheader from "@/utils/pageheader";
import { toast } from "react-toastify";
import "./details.css";
import Loader from "@/Components/loader/Loader";
import { clientCompanyCreate } from "@/redux/slices/authSlice";
import { useRouter } from "next/navigation";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faLocationDot, faAngleDown } from "@fortawesome/free-solid-svg-icons";
import { clientProfileDetails } from "@/redux/slices/authSlice";

import { IMAGE } from "../../../utils/Theme";
import PhoneExtensionDropdown from "@/Components/phoneExtension";
import CustomDropDown from "@/Components/ui/DropDown";
import { useClickOutside } from "@/hooks/use-click-outside";
import { employeeCounts } from "@/Components/dropDownConstant";


const CompanyDetails = () => {
  const dispatch = useDispatch();
  const dropdownRef = useRef(null);
  const [open, setOpen] =useState(false)
  const router = useRouter();
  const { isLoading, error } = useSelector((state) => state.auth);
  const [loading, setLoading] = useState(false); // Loading state
  const [comapnyId, setComapnyId] = useState("");
  const [companyName, setCompanyName] = useState("");
  const [companyAddress, setCompanyAddress] = useState("");
  const [companyPhone, setCompanyPhone] = useState("");
  const [companyEmail, setCompanyEmail] = useState("");
  const [companyWebsite, setCompanyWebsite] = useState("");
  const [companyInfo, setCompanyInfo] = useState("");

  const [legalBusinessName, setLegalBusinessName] = useState("");
  const [businessAddress, setBusinessAddress] = useState("");
  const [businessPhone, setBusinessPhone] = useState("");
  const [noOfEmployee, setNoOfEmployee] = useState("");

  const [formErrors, setFormErrors] = useState({});
  const [openCountryCodes, setOpenCountryCodes] = useState(false);
  const [countryCode, setCountryCode] = useState("+91")

  const { user } = useSelector((state) => state.auth);
  useClickOutside(dropdownRef, () => setOpen(false), false);

  const validateForm = () => {
    const errors = {};
    if (!companyName) {
      errors.companyName = "Company name is required.";
    }
    if (!companyAddress) {
      errors.companyAddress = "Address is required.";
    }
    if (!companyPhone) {
      errors.companyPhone = "Phone number is required.";
    }
    return errors;
  };

  const handleNoOfEmployeeChange = (event) => {
    setNoOfEmployee(event.target.value);
    // setError('');
  };
  const countryCodeRef = useRef(null);

  // Close the country code dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      const target = event.target;
      if (openCountryCodes && countryCodeRef.current && !countryCodeRef.current.contains(target)) {
        setOpenCountryCodes(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [openCountryCodes]);

  const [isScrollable, setIsScrollable] = useState(false);
  const infoRef = React.useRef(null);

  useEffect(() => {
    if (infoRef.current) {
      setIsScrollable(
        infoRef.current.scrollHeight > infoRef.current.clientHeight
      );
    }
  }, [companyInfo]);

  const handleSave = async (e) => {
    e.preventDefault();
    // console.log("ASDFGHJKL;'");

    const errors = validateForm();
    setFormErrors(errors);

    if (Object.keys(errors).length === 0) {
      const companyData = {
        comapnyId,
        companyName,
        companyAddress,
        companyPhone,
        companyEmail,
        companyWebsite,
        companyInfo,
        legalBusinessName,
        businessAddress,
        businessPhone,
        noOfEmployee,
      };
      let successMessage;
      setLoading(true);
      try {
        const createCompany = await dispatch(
          clientCompanyCreate(companyData)
        ).unwrap();

        if (createCompany.status) {
          successMessage = !comapnyId
            ? "Client profile created successfully."
            : "Client profile updated successfully.";
          // toast.success(successMessage);
          if (!comapnyId) {
            // window.location.href = `/dashboard`;
          }
        } else {
          toast.error(createCompany.message);
        }
        return;
      } catch (err) {
        console.error("Profile error:", err);
        toast.error("Failed to create profile.");
      } finally {
        setTimeout(() => {
          setLoading(false);
          if (successMessage) {
            toast.success(successMessage);
          }
        }, 3000);
      }
    }
  };

  useEffect(() => {
    const fetchProfileDetails = async () => {
      await dispatch(clientProfileDetails());
    };
    fetchProfileDetails();
  }, [dispatch]);

  useEffect(() => {
    if (user?.data?.userCompany) {
      setComapnyId(user.data.userCompany.id || "");
      setCompanyName(user.data.userCompany.companyName || "");
      setCompanyAddress(user.data.userCompany.companyAddress || "");
      setCompanyPhone(user.data.userCompany.companyPhone || "");
      setCompanyEmail(user.data.userCompany.companyEmail || "");
      setCompanyWebsite(user.data.userCompany.companyWebsite || "");
      setCompanyInfo(user.data.userCompany.companyInfo || "");

      setLegalBusinessName(user.data.userCompany.legalBusinessName || "");
      setBusinessAddress(user.data.userCompany.businessAddress || "");
      setBusinessPhone(user.data.userCompany.businessPhone || "");
      setNoOfEmployee(user.data.userCompany.noOfEmployee || "");
    }
  }, [user]);

  const maxInfoLength = 1000;
  const infoLength = companyInfo.length;

  const handleAction = (e, item) => {
    setNoOfEmployee(item?.value);
    // setOpen(false)
  }

  return (
    <div className="company-info-container companyAccordianStyle">
      {!comapnyId && loading && <Loader />}
      <Pageheader
        label="Company Info"
        handleSave={handleSave}
        user={user}
        loading={loading}
      />
      <div className="company-container form-input-label">
        <Accordion defaultActiveKey="0">
          <Accordion.Item eventKey="0">
            <Accordion.Header>
              <p className="accorheading">Company Details</p>
            </Accordion.Header>
            <Accordion.Body>
              <div className="floating-label-group mb-3">
                <input
                  type="text"
                  id="business"
                  className={`${formErrors.companyName ? "input-error" : ""
                    } input-form-control`}
                  required
                  value={companyName}
                  onChange={(e) => setCompanyName(e.target.value)}
                  readOnly={!!comapnyId}
                />
                <label className="floating-label">Doing business as</label>
              </div>
              <div className="floating-label-group mb-3">
                <input
                  type="text"
                  id="address"
                  className={`${formErrors.companyAddress ? "input-error" : ""
                    } input-form-control`}
                  required
                  value={companyAddress}
                  onChange={(e) => setCompanyAddress(e.target.value)}
                />
                <label className="floating-label">Business address</label>
                <FontAwesomeIcon className="point-img" icon={faLocationDot} />
              </div>
              <div className="row">
                <div className="col-lg-6 col-md-6 col-sm-12">
                  <div
                    className={`${formErrors.companyPhone ? "input-error" : ""
                      } phone-input mb-3`}
                  >
                    <div className="country-code"
                      ref={countryCodeRef}
                      onClick={() => setOpenCountryCodes(prev => !prev)}
                    >
                      {countryCode}{" "}
                      <FontAwesomeIcon
                        icon={faAngleDown}
                        className="phone-angle"
                      />
                      {openCountryCodes && <div className="phone-extension">
                        <PhoneExtensionDropdown handleCountryCode={setCountryCode} />
                      </div>}
                    </div>
                    <div className="divider"></div>
                    <div className="floating-label-group">
                      <input
                        type="text"
                        className="phone-number"
                        value={companyPhone}
                        onChange={(e) => {
                          const value = e.target.value.replace(/\D/g, "");
                          if (value.length <= 10) {
                            setCompanyPhone(value);
                          }
                        }}
                        required
                        maxLength={10}
                        title="Please enter a valid 10-digit phone number"
                      />
                      <label className="phone-floating-label">Phone No.</label>
                    </div>
                  </div>
                </div>
                <div className="col-lg-6 col-md-6 col-sm-12 mb-3">
                  <div className="floating-label-group">
                    <input
                      type="text"
                      id="email"
                      className={`${formErrors.companyEmail ? "input-error" : ""
                        } input-form-control`}
                      value={companyEmail}
                      onChange={(e) => setCompanyEmail(e.target.value)}
                      required
                    />
                    <label className="floating-label">Email Address</label>
                  </div>
                </div>
              </div>
              <div className="floating-label-group mb-3">
                <input
                  type="text"
                  id="website"
                  className={`${formErrors.companyWebsite ? "input-error" : ""
                    } input-form-control`}
                  value={companyWebsite}
                  onChange={(e) => setCompanyWebsite(e.target.value)}
                  required
                />
                <label className="floating-label">Website</label>
              </div>
              <div className="floating-label-group mb-3">
                <textarea
                  type="text"
                  id="info"
                  value={companyInfo}
                  onChange={(e) => {
                    if (e.target.value.length <= maxInfoLength) {
                      setCompanyInfo(e.target.value);
                    }
                  }}
                  className={`${formErrors.companyInfo ? "input-error" : ""
                    } input-form-control`}
                  required
                  maxLength={maxInfoLength}
                />
                <label className="floating-label">Business Information</label>
              </div>
              <div className="additional-info">
                <p>
                  Add additional information that you want to appear on your
                  invoices...
                </p>
                <p>
                  {infoLength}/{maxInfoLength}
                </p>
              </div>
            </Accordion.Body>
          </Accordion.Item>
        </Accordion>

        <div className="legacy-details mb-5">
          <div className="sub-head mb-4">
            <p className="subheading"> Legal entity details</p>
          </div>
          <div className="floating-label-group mb-3">
            <input
              type="text"
              id="contact"
              className={`input-form-control`}
              value={legalBusinessName}
              onChange={(e) => setLegalBusinessName(e.target.value)}
              required
            />
            <label className="floating-label">Doing legal business as</label>
          </div>
          <div className="floating-label-group mb-3">
            <input
              type="text"
              id="businessAddress"
              className="input-form-control input-logo"
              value={businessAddress}
              onChange={(e) => setBusinessAddress(e.target.value)}
              required
            />
            <label className="floating-label">
              Registered business address
            </label>
            <FontAwesomeIcon className="point-img" icon={faLocationDot} />
          </div>
          <div className="row">
            <div className="col-lg-6 col-md-6 col-sm-12">
              <div className="floating-label-group">
                <input
                  type="text"
                  id="businessPhone"
                  className="input-form-control"
                  value={businessPhone}
                  onChange={(e) => {
                    const value = e.target.value.replace(/\D/g, "");
                    if (value.length <= 10) {
                      setBusinessPhone(value);
                    }
                  }}
                  required
                  maxLength={10}
                  title="Please enter a valid 10-digit phone number"
                />
                <label className="floating-label">Legal Phone No.</label>
              </div>
            </div>
            <div className="col-lg-6 col-md-6 col-sm-12 mb-3" style={{ position: "relative" }}>
              <div className="floating-label-group w-100 h-100">
                {!!(noOfEmployee && !open) && <label className="payment-label">No of Employees</label>}
                <CustomDropDown dropDownText="-- No of Employees --" list={employeeCounts} className="" handleAction={handleAction} open={open} setOpen={setOpen} selectedItem={noOfEmployee} dropdownRef={dropdownRef} />
            </div>
              </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CompanyDetails;

{/* <select
                  className="payment-terms"
                  name="languages"
                  id="languages"
                  value={noOfEmployee}
                  onChange={handleNoOfEmployeeChange}
                >
                  <option value="">-- No of Employees --</option>
                  <option key="1" value="1">
                    1
                  </option>
                  <option key="2" value="2">
                    2
                  </option>
                  <option key="3" value="3">
                    3
                  </option>
                  <option key="4" value="4">
                    4
                  </option>
                  <option key="5" value="5">
                    5
                  </option>
                  <option key="6-10" value="6-10">
                    6-10
                  </option>
                  <option key="11-15" value="11-15">
                    11-15
                  </option>
                  <option key="16+" value="16+">
                    16+
                  </option>
                </select>
                <p className="dropdownIcon">
                  <img src={IMAGE.dropdownColor} alt="" />
                </p> */}