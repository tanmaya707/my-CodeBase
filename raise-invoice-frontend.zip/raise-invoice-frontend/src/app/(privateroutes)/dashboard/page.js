"use-client";
import React from "react";
// import Sidebar from "@/Components/sidebar/Sidebar";
import DashboardHeader from "@/Components/dashboardheader/dashboardHeader";
import Cards from "@/Components/cards/Cards";
import "./dashboard.css";

const Dashboard = () => {
  return (
    <div className="dashboard-main">
      <DashboardHeader />
      {/* <Sidebar /> */}
      <Cards />
    </div>
  );
};

export default Dashboard;
