"use client"
import { detailsCreditNoteData, detailsEstimateData } from "@/redux/slices/dataSlice";
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import "../../../invoice/invoice.css"
import InvoiceHeader from "@/Components/invoices/header";
import { dateFormater, differentOfDate } from "@/dependencies/utils/helper";
import InvoicePreview from "@/Components/invoices/preview";
import Payment from "@/Components/invoices/payment";
import MoreDetails from "@/Components/invoices/more";

const CreditNoteDetails = ({ params }) => {
    const dispatch = useDispatch();
    // const {estimateDetails, loading} = useSelector(state => state.dataReducer);
    const [crNoteDetails, setCrNoteDetails] = useState({})
    const [invoiceHeader, setInvoiceHeader] = useState(null)
    const [previewRef, setPreviewRef] = useState(null)
    const [creditNote, setCreditNote] = useState({})
    // const [selectedClient, setSelectedClient] = useState(estimate?.client || {})

    useEffect(() => {
        (async () => {
            const estimateParam = await params
            // console.log("estimateParam ::: ", estimateParam, estimateParam?.id);
            const crNote = await dispatch(detailsCreditNoteData({id : estimateParam.id})).unwrap();
            setCrNoteDetails(crNote?.data)
        })()
    }, [params]);

    useEffect(() => {
        console.log("crNoteDetails ::: ", crNoteDetails);
        if(crNoteDetails && crNoteDetails?.creditNote){
            const creditNote = crNoteDetails?.creditNote
            console.log("creditNote ::: ", creditNote);
            setCreditNote(creditNote)
            setInvoiceHeader({
                type : "Credit Note",
                paymentStatus : creditNote?.paymentStatus,
                date : dateFormater(creditNote?.createdAt),
                // dueDate : differentOfDate(creditNote?.dueDate),
                name : creditNote?.client?.name,
                amount : creditNote?.total
            })
        }   
    }, [crNoteDetails])

    return (
        <div className="invoice-details">
            {invoiceHeader !== null && <InvoiceHeader headerInfo={invoiceHeader} />}
            {crNoteDetails && creditNote && <InvoicePreview addRoute="credit-note/edit" route="credit-note" customInvoice={crNoteDetails?.customInvoice} customInvoiceOption={crNoteDetails?.customInvoiceOption} setPreviewRef={setPreviewRef} previewRef={previewRef}  invoice={{...creditNote, invoiceDate : creditNote?.createdAt, name: "Credit Note", selectedClient : crNoteDetails?.client,
                        discountTotal : creditNote?.discount || ''

            }} />}
            <Payment isNonPaid={creditNote.paymentStatus === "unpaid"} />
            <MoreDetails  previewRef={previewRef} id={creditNote.id} invoiceNumber={creditNote?.invoiceNumber} isNonPaid={creditNote.paymentStatus === "unpaid"} route="/addCreditNote" />
        </div>
    )
}
export default CreditNoteDetails;
