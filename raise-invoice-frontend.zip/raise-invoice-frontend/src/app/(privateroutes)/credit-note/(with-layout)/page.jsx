"use client"
import React, { useState, useEffect } from 'react';
import MiddleSection from '@/Components/MiddleSection/MiddleSection';
import MenuLandingPage from '@/utils/MenuLanding/MenuLandingPage';
import NewProject from '@/Components/newproject/newproject';
import { IMAGE } from '@/utils/Theme';
import { useDispatch, useSelector } from 'react-redux';
import { fetchProjectData } from '@/redux/slices/dataSlice';

const Project = () => {
  const dispatch = useDispatch();
  const { projects } = useSelector((state) => state.dataReducer);
  const {} = useSelector(state => state?.dataReducer)

  const Image = IMAGE.blank_project



  return (
    <>
        <MenuLandingPage
            Image={Image}
            // text="Create credit note"
            label='Add Credit Note'
            // handleState={setAddProjectForm}
            // datas={getFilteredProjects()}
            createRoute='/addCreditNote'
          />
    </>
  );
};

export default Project;
