"use client"
import MiddleSection from "@/Components/MiddleSection/MiddleSection";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchProjectData, getCreditNoteData, setActiveMidTab } from "@/redux/slices/dataSlice";
import "bootstrap/dist/css/bootstrap.min.css";
import "../../../general.css";
import '../../project/project.css'


const middleSectionTabs = [
    {
        id: 1,
        name: "All",
    },
    {
        id: 2,
        name: "Active",
    },
    {
        id: 3,
        name: "Completed",
    }
]

export default function authLayout({ children }) {
    const router = useRouter();
    const dispatch = useDispatch();
    const { creditNotes, loading } = useSelector(state => state?.dataReducer)
    const [activeTag, setActiveTag] = useState(0);
    const [filteredCreditNotes, setFilteredCreditNotes] = useState([]);

    useEffect(() => {
        dispatch(getCreditNoteData());
    }, [dispatch]);

    useEffect(() => {
        // console.log("activeTag ::: ", activeTag, creditNotes);

        dispatch(setActiveMidTab(activeTag === 0 ? null : activeTag === 1 ? 1 : 3))
        if (!creditNotes?.data) setFilteredCreditNotes();
        if (activeTag === 0) setFilteredCreditNotes(creditNotes.data);
        else if (activeTag === 1) setFilteredCreditNotes(creditNotes.data.filter(p => p.status !== 3));
        else if (activeTag === 2) setFilteredCreditNotes(creditNotes.data.filter(p => p.status === 3));
        else setFilteredCreditNotes(creditNotes.data);
    }, [creditNotes, activeTag]);


    return (
        <>
            <MiddleSection
            itemType={"Credit Note"}
                label="Credit Note"
                tabs={middleSectionTabs}
                activeTag={activeTag}
                setActiveTag={setActiveTag}
                list={filteredCreditNotes}
                createRoute="/addCreditNote"
            />

            <div className={"col-lg-8"}>
                <div className="add-client contentArea">
                    {children}
                </div>
            </div>
        </>
    );
}
