"use client"
import MiddleSection from "@/Components/MiddleSection/MiddleSection";
import "bootstrap/dist/css/bootstrap.min.css";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import "../../general.css";
import { useDispatch, useSelector } from "react-redux";
import { getInvoiceData, setActiveMidTab } from "@/redux/slices/dataSlice";

const middleSectionTabs = [
    { id: 1, name: "Unpaid" },
    { id: 2, name: "Paid" }
];

export default function authLayout({ children }) {
    const router = useRouter();
    const dispatch = useDispatch();
    const {invoices : invoiceData, loading} = useSelector(state => state?.dataReducer)
    const [activeTag, setActiveTag] = useState(0);
    const [filteredInvoices, setFilteredInvoices] = useState([]);
    
    // const handleCreateInvoice = () => {
    //     router.push("/addInvoice");
    // };

    useEffect(() => {
        dispatch(getInvoiceData())
    }, [dispatch]);

    useEffect(() => {
        if (activeTag === 0) {
            dispatch(setActiveMidTab("unpaid"))
            setFilteredInvoices(invoiceData.filter(inv => inv.paymentStatus === "unpaid"));
        } else if (activeTag === 1) {
            dispatch(setActiveMidTab("paid"))
            setFilteredInvoices(invoiceData.filter(inv => inv.paymentStatus === "paid"));
        } else {
            dispatch(setActiveMidTab(""))
            setFilteredInvoices(invoiceData);
        }
    }, [invoiceData, activeTag]);

    
    // useEffect(() => {
    //     console.log("filteredInvoices in outerpage::: ", filteredInvoices);
    // }, [filteredInvoices])

  return (
    <>
      <MiddleSection
        label="Create Invoice"
        itemType="Invoice"
        tabs={middleSectionTabs}
        activeTag={activeTag}
        setActiveTag={setActiveTag}
        // setAddInvoiceForm={handleCreateInvoice}
        invoices={filteredInvoices}
        onEditInvoice={() => {}}
        // handleCreate={handleCreateInvoice}
        createRoute="/addInvoice"
    />
    <div className="col-lg-8">
      {children}      
    </div>
    </>
  );
}
