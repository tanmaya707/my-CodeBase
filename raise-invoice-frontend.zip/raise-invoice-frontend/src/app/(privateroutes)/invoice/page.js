"use client";
import React, { useEffect, useState } from "react";
import { IMAGE } from "@/utils/Theme";
// import MiddleSection from "@/Components/MiddleSection/MiddleSection";
import MenuLandingPage from "@/utils/MenuLanding/MenuLandingPage";
import "../../(otherroutes)/add-invoice/addnote.css";
// import { getInvoiceData } from "@/redux/slices/dataSlice";
import { useSelector } from "react-redux";
import { useRouter } from "next/navigation";
// import route from "use-router/dist/route";
// import { number } from "zod";

const Invoice = () => {
    const router = useRouter()
    const {invoices : invoiceData, loading, currentMiddleTab} = useSelector(state => state?.dataReducer)
    // const [invoiceData, setInvoiceData] = useState([]);
    const [filteredInvoices, setFilteredInvoices] = useState([]);
    const [activeTag, setActiveTag] = useState(0);

    const invoiceTabs = [
        { name: "Purchase Order", component: "PurchaseOrder", route: "/timeEntry" },
        { name: "Credit Note", component: "CreditMemo", route: "/timeEntry" }
    ];

    useEffect(() => {
        if(typeof currentMiddleTab !== "number"){
            if(currentMiddleTab?.trim()?.length > 0){
                setFilteredInvoices(invoiceData.filter(inv => inv.paymentStatus === currentMiddleTab?.trim()));
            } else {
                setFilteredInvoices(invoiceData);
            }
        }
    }, [invoiceData, currentMiddleTab]);

    const handleCreateInvoice = () => {
        router.push("/addInvoice");
    };

    const handleTabClick = (tab) => {
    if (tab.name === "Credit Note") {
        router.push("/addCreditNote")
    }
    if (tab.name === "Purchase Order") {
        router.push("/purchaseOrder")
    }
};

    return (
        <>
            <MenuLandingPage
                Image={IMAGE.tab}
                label="Create Invoice"
                tabs={invoiceTabs}
                handleState={handleCreateInvoice}
                createRoute="/addInvoice"
                itemType="Invoice"
                activeTag={activeTag}
                invoiceToEdit={null}
                datas={filteredInvoices}
                text={
                    !filteredInvoices || filteredInvoices.length === 0
                        ? null
                        : undefined
                }
                onTabClick={handleTabClick}
            />
        </>
    );
};

export default Invoice;
