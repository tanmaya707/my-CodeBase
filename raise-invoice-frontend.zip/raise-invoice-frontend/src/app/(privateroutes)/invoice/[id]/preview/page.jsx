"use client";
import { useSelector } from "react-redux";
import CustomInvoiceImpact from "@/Components/templates/impact";
import "../../invoice.css"
import { useEffect } from "react";
import { useDispatch } from "react-redux";
import { detailsInvoiceData } from "@/redux/slices/dataSlice";

const InvoicePreview = ({params}) => {
    const dispatch = useDispatch();
    const {invoiceDetails, loading} = useSelector(state => state.dataReducer);
    useEffect(() => {
        (async () => {
            const invoiceParam = await params
            console.log("invoiceParam ::: ", invoiceParam, invoiceParam?.id);
            dispatch(detailsInvoiceData({id : invoiceParam.id}));
        })()
    }, [params]);

    useEffect(() => {
        console.log("invoiceDetails in preview ::: ", invoiceDetails?.customInvoice);
    }, [invoiceDetails])
    
    return (
        <div className="preview-container-page">
            <div className="preview-container">
                <div className='preview-content'>
                    <CustomInvoiceImpact 
                    invoice={{...invoiceDetails?.invoice,
                        invoiceDate : invoiceDetails?.invoice?.date, 
                        name: "Invoice", 
                        selectedClient : invoiceDetails?.client,
                        discountTotal : invoiceDetails?.invoice.discount || ''
                    }} 
                    // customTemplates={customTemplates} 
                    // customTemplates={[]}
                    selectedTemp={invoiceDetails?.customInvoice.templateName}
                    selectedId={
                        invoiceDetails?.customInvoice.logoId
                            ? { id: invoiceDetails?.customInvoice.logoId, logoImage: invoiceDetails?.customInvoice.logoImage }
                            : null
                    }
                    selectedSize={invoiceDetails?.customInvoice.logoSize}
                    alignPos={invoiceDetails?.customInvoice.logoPosition}
                    selectedColour={
                        invoiceDetails?.customInvoice.colourId
                            ? { id: invoiceDetails?.customInvoice.colourId, colourCode: invoiceDetails?.customInvoice.colourCode }
                            : null
                    }
                    customColour={invoiceDetails?.customInvoice.customColour}
                    selectedHeader={
                        invoiceDetails?.customInvoice.headerId
                            ? { id: invoiceDetails?.customInvoice.headerId, headerImg: invoiceDetails?.customInvoice.headerImg }
                            : null
                    }
                    selectedWatermark={
                        invoiceDetails?.customInvoice.waterMarkId
                            ? {
                                    id: invoiceDetails?.customInvoice.waterMarkId,
                                    waterMarkImg: invoiceDetails?.customInvoice.waterMarkImg,
                                }
                            : null
                    }
                    customOption={invoiceDetails?.customInvoiceOption}
                     />
                </div>
            </div>    
        </div>    
    );
}
export default InvoicePreview;


// customTemplates={customTemplates}