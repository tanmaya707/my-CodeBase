"use client"

import { detailsInvoiceData } from "@/redux/slices/dataSlice";
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import "../invoice.css"
import InvoiceHeader from "@/Components/invoices/header";
import { dateFormater, differentOfDate } from "@/dependencies/utils/helper";
import InvoicePreview from "@/Components/invoices/preview";
import Payment from "@/Components/invoices/payment";
import MoreDetails from "@/Components/invoices/more";

const InvoiceDetails = ({ params }) => {
    const dispatch = useDispatch();
    const {invoiceDetails, loading} = useSelector(state => state.dataReducer);
    const [invoiceHeader, setInvoiceHeader] = useState(null)
    const [invoice, setInvoice] = useState({})
    const [selectedClient, setSelectedClient] = useState({})
    const [previewRef, setPreviewRef] = useState(null)
    useEffect(() => {
        (async () => {
            const invoiceParam = await params
            // console.log("invoiceParam ::: ", invoiceParam, invoiceParam?.id);
            dispatch(detailsInvoiceData({id : invoiceParam.id}));
        })()
    }, [params]);

    useEffect(() => {
        if(invoiceDetails && invoiceDetails?.invoice){
            // console.log("invoiceDetails ::: ", invoiceDetails);
            const invoice = invoiceDetails?.invoice
            setInvoice(invoice)
            setSelectedClient(invoiceDetails?.client)
            setInvoiceHeader({
                paymentStatus : invoice?.paymentStatus,
                date : dateFormater(invoice?.date),
                dueDate : differentOfDate(invoice?.dueDate),
                name : invoice?.client_id?.name,
                amount : invoice?.balance,
                invoiceNumber : invoice?.invoiceNumber
            })
        }   
    }, [invoiceDetails])

    return (
        <div className="invoice-details">
            {invoiceHeader !== null && <InvoiceHeader headerInfo={invoiceHeader} />}
            {invoiceDetails && invoice && <InvoicePreview setPreviewRef={setPreviewRef} previewRef={previewRef} customInvoice={invoiceDetails?.customInvoice} customInvoiceOption={invoiceDetails?.customInvoiceOption} addRoute="/addInvoice" invoice={{...invoice, invoiceDate : invoice?.date, name: "Invoice", selectedClient : selectedClient,
                        discountTotal : invoiceDetails?.invoice.discount || ''

            }}   />}
            <Payment isNonPaid={invoice?.paymentStatus === "unpaid"} />
            <MoreDetails id={invoice.id} invoiceNumber={invoice?.invoiceNumber} isNonPaid={invoiceDetails?.invoice?.paymentStatus === "unpaid"} previewRef={previewRef} route="/addInvoice" />
        </div>
    )
}

export default InvoiceDetails;