"use client"
import EstimatePending from "@/Components/estimatePending/estimatePending";
import { detailsEstimateData, fetchNextInvoiceNumber } from "@/redux/slices/dataSlice";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { useSelector } from "react-redux";

const UpdateEstimate = ({ params }) => {
    const dispatch = useDispatch();
    const { estimates } = useSelector(state => state.dataReducer);
    const [client, setClient] = useState(null)
    const [invoiceNumber, setInvoiceNumber] =useState("")

    useEffect(() => {
        (async () => {
            // console.log("estimates ::: ", estimates);

            if (params) {
                const estimateParams = await params;
                // console.log("estimateParams : id :", estimateParams?.id);
                const filteredEstimate = await dispatch(detailsEstimateData({id : estimateParams?.id})).unwrap();
                // const filteredEstimate = estimates?.filter(item => item?.id === Number(estimateParams?.id));
                // console.log("filteredEstimate ::: ", filteredEstimate);

                const finalEstimate = filteredEstimate?.data ? filteredEstimate?.data : { clientId: estimateParams?.id }

                setClient(finalEstimate)
            }
        })()

    }, [params])

    useEffect(() => {
        dispatch(fetchNextInvoiceNumber()).then(result => {
            let nextNum = result?.payload?.data?.nextInvoiceNumber || '';
            if (typeof nextNum === 'number' || /^\d+$/.test(nextNum)) {
                nextNum = String(nextNum).padStart(3, '0');
            }
            setInvoiceNumber(nextNum);
        });
    }, [])

    return (
        <div className="col-lg-12">
            <EstimatePending invoiceNumber={invoiceNumber} estimateToEdit={client} type="Edit" />
        </div>
    )
}
export default UpdateEstimate;