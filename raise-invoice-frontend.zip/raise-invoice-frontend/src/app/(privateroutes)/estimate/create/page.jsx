"use client"
import EstimatePending from "@/Components/estimatePending/estimatePending";
import { useModal } from "@/cotexts/modalContext";
import { fetchNextEstimateNumber } from "@/redux/slices/dataSlice";
import { useSearchParams } from "next/navigation";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { useSelector } from "react-redux";

const CreateEstimate = () => {
    const dispatch = useDispatch();
    const {estimates} = useSelector(state => state.dataReducer);
    const searchedParams = useSearchParams();
    const cId = searchedParams?.get('cId');
    const copyId = searchedParams.get('copy');
    const {parameter} = useModal();
    const [estimateNumber, setEstimateNumber] =useState("")
    // console.log("cId in create estimate ::: ", cId, copyId, parameter);
    const [client, setClient] = useState(null)

    useEffect(() => {
        (async() => {            
            if(copyId && copyId !== "undefined" && estimates?.length > 0) {
                // console.log("estimateParams : id :", estimateParams?.id);
                
                const filteredEstimate = estimates?.filter(item => item?.id === Number(copyId));
                // console.log("filteredEstimate ::: ", filteredEstimate);

                const finalEstimate = filteredEstimate?.length > 0 ? filteredEstimate[0] : {clientId : estimateParams?.id}
                // console.log("finalEstimate ::: ", finalEstimate);
                const copyPayload = {
                    client : parameter?.client ? finalEstimate?.client : null,
                    items : parameter?.items ? finalEstimate?.items : [],
                    logo  : parameter?.attachment ? finalEstimate?.logo : null,
                }
                setClient(copyPayload)
            }
            
        })()

    }, [copyId, estimates])

    useEffect(() => {
        dispatch(fetchNextEstimateNumber()).then(result => {
                let nextNum = result?.payload?.data?.nextEstimateNumber || '';
                if (typeof nextNum === 'number' || /^\d+$/.test(nextNum)) {
                    nextNum = String(nextNum).padStart(3, '0');
                }
                setEstimateNumber(nextNum);
            });
    }, [])

    return(
        <div className="col-lg-12">
            <EstimatePending estimateNumber={estimateNumber} estimateToEdit={cId !== null ? { clientId: cId } : client}  type="Create" />
        </div>
    )
}
 export default CreateEstimate;