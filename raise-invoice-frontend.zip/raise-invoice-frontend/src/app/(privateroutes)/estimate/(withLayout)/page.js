"use client";
import React, { useState, useEffect } from "react";
import MiddleSection from "@/Components/MiddleSection/MiddleSection";
import { useSearchParams } from 'next/navigation';
import MenuLandingPage from "@/utils/MenuLanding/MenuLandingPage";
import "../../../(otherroutes)/add-invoice/addnote.css";
import EstimatePending from "@/Components/estimatePending/estimatePending";
import { IMAGE } from "@/utils/Theme";
import { getEstimateData, fetchClientData } from "@/redux/slices/dataSlice";
import { useDispatch, useSelector } from "react-redux";
import '../estimate.css'

const Estimate = () => {
  const dispatch = useDispatch();
  const Image = IMAGE.calculator;
  const searchParams = useSearchParams();
  const clientId = searchParams.get('cId');

  const [estimateToEdit, setEstimateToEdit] = useState(null);
  const { estimate : estimateData, currentMiddleTab } = useSelector((state) => state.dataReducer);
  const [filteredEstimates, setFilteredEstimates] = useState([])


  useEffect(() => {
    // console.log("clientId" , clientId);
    
    dispatch(getEstimateData());
    if (clientId) {
      setEstimateToEdit({ clientId });
      // setAddEstimateForm(true);
    }
  }, [dispatch, clientId]);

  

  useEffect(() => {
    if(typeof currentMiddleTab !== "string"){
      if(currentMiddleTab !== null && estimateData?.length > 0){
          setFilteredEstimates(estimateData?.filter(inv => inv.status === currentMiddleTab + 1));
      } else {
          setFilteredEstimates(estimateData);
      }
    }
  }, [estimateData, currentMiddleTab]);

  return (
    <>
        <MenuLandingPage
          itemType="Estimate"
          Image={Image}
          text={filteredEstimates?.data?.length > 0 ? "" : "There is no estimate added yet Please add an estimate"}
          label="Add Estimate"
        />
    </>
  );
};

export default Estimate;
