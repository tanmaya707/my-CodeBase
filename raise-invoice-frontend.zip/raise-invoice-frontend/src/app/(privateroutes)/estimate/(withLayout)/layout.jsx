"use client"
import MiddleSection from "@/Components/MiddleSection/MiddleSection";
import "bootstrap/dist/css/bootstrap.min.css";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import "../../../general.css";
import { useDispatch, useSelector } from "react-redux";
import { getEstimateData, setActiveMidTab } from "@/redux/slices/dataSlice";

const middleSectionTabs = [
    { id: 1, name: "Pending" },
    { id: 2, name: "Done" },
];

export default function authLayout({ children }) {
    const router = useRouter();
    const dispatch = useDispatch();
    const { estimates: estimateData, loading } = useSelector(state => state?.dataReducer)
    const [activeTag, setActiveTag] = useState(0);
    const [filteredEstimates, setFilteredEstimates] = useState([]);

    // const handleCreate = () => {
    //     router.push("/estimate/create");
    // };

    useEffect(() => {
        dispatch(getEstimateData())
    }, [dispatch]);

    useEffect(() => {
        if(estimateData ) {
            setFilteredEstimates(estimateData.filter(inv => inv?.status === activeTag + 1));
            dispatch(setActiveMidTab(activeTag))
        }
    }, [estimateData, activeTag]);


    // useEffect(() => {
    //     console.log("filteredEstimates in outerpage::: ", filteredEstimates);
    // }, [filteredEstimates])

    const btnLabel = "Add Estimate" //estimateToEdit ? (clientId ? 'Add Estimate' : 'Edit Estimate') : 'Add Estimate';

    console.log(router.pathname);

    return (
        <>
            <MiddleSection
                label="Estimate"
                itemType="Estimate"
                tabs={middleSectionTabs}
                btnlabel={btnLabel}
                // handleState={setAddEstimateForm}
                activeTag={activeTag}
                setActiveTag={setActiveTag}
                // setAddEstimateForm={handleAddEstimateFormOpen}
                // handleCreate={handleCreate}
                list={filteredEstimates}
                createRoute="/estimate/create"
            // handleEditEstimate={handleEditEstimate}
            />
            {/* <MiddleSection
        label="Create Invoice"
        itemType="Invoice"
        tabs={middleSectionTabs}
        activeTag={activeTag}
        setActiveTag={setActiveTag}
        setAddInvoiceForm={handleCreateInvoice}
        invoices={filteredInvoices}
        onEditInvoice={() => {}}
    /> */}
            <div className="col-lg-8">
                    {children}
            </div>
        </>
    );
}
