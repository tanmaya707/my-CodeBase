"use client"

import { detailsEstimateData } from "@/redux/slices/dataSlice";
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import "../../../invoice/invoice.css"
import InvoiceHeader from "@/Components/invoices/header";
import { dateFormater, differentOfDate } from "@/dependencies/utils/helper";
import InvoicePreview from "@/Components/invoices/preview";
import Payment from "@/Components/invoices/payment";
import MoreDetails from "@/Components/invoices/more";

const EstimateDetails = ({ params }) => {
    const dispatch = useDispatch();
    const {estimateDetails, loading} = useSelector(state => state.dataReducer);
    const [invoiceHeader, setInvoiceHeader] = useState(null)
    const [previewRef, setPreviewRef] = useState(null)
    const [estimate, setEstimate] = useState({})
    // const [selectedClient, setSelectedClient] = useState(estimate?.client || {})

    useEffect(() => {
        (async () => {
            const estimateParam = await params
            // console.log("estimateParam ::: ", estimateParam, estimateParam?.id);
            dispatch(detailsEstimateData({id : estimateParam.id}));
        })()
    }, [params]);

    useEffect(() => {
        console.log("estimateDetails ::: ", estimateDetails);
        if(estimateDetails && estimateDetails?.estimate){
            const estimate = estimateDetails?.estimate
            console.log("estimate ::: ", estimate);
            setEstimate(estimate)
            setInvoiceHeader({
                type : "Estimate",
                paymentStatus : estimate?.paymentStatus,
                date : dateFormater(estimate?.createdAt),
                // dueDate : differentOfDate(estimate?.dueDate),
                name : estimate?.client?.name,
                amount : estimate?.total
            })
        }   
    }, [estimateDetails])

    return (
        <div className="invoice-details">
            {invoiceHeader !== null && <InvoiceHeader headerInfo={invoiceHeader} />}
            {estimateDetails && estimate && <InvoicePreview addRoute="estimate/edit" route={"estimate"} setPreviewRef={setPreviewRef} previewRef={previewRef}  invoice={{...estimate, invoiceDate : estimate?.createdAt, name: "Estimate", selectedClient : estimateDetails?.client,
                        discountTotal : estimate?.discount || ''

            }} />}
            {/* <InvoicePreview /> */}
            <Payment isNonPaid={estimate.paymentStatus === "unpaid"} />
            <MoreDetails  previewRef={previewRef} id={estimate.id} invoiceNumber={estimate?.invoiceNumber} isNonPaid={estimate.paymentStatus === "unpaid"} route="/estimate/create" />
        </div>
    )
}

export default EstimateDetails;