"use client";
import { useSelector } from "react-redux";
import CustomInvoiceImpact from "@/Components/templates/impact";
import "../../../../invoice/invoice.css"
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { detailsEstimateData, detailsInvoiceData } from "@/redux/slices/dataSlice";

const InvoicePreview = ({params}) => {
    const dispatch = useDispatch();
    // const {invoiceDetails, loading} = useSelector(state => state.dataReducer);
    const [estimateDetails, setEstimateDetails] = useState({})
    useEffect(() => {
        (async () => {
            const invoiceParam = await params
            console.log("invoiceParam ::: ", invoiceParam, invoiceParam?.id);
            const preview = await dispatch(detailsEstimateData({id : invoiceParam.id})).unwrap();
            setEstimateDetails(preview?.data)
        })()
    }, [params]);

    // useEffect(() => {
    //     console.log("estimateDetails in preview ::: ", estimateDetails?.customInvoice);
    // }, [estimateDetails])
    
    return (
        <div className="preview-container-page">
            <div className="preview-container">
                <div className='preview-content'>
                    <CustomInvoiceImpact 
                    invoice={{...estimateDetails?.estimate,
                        invoiceDate : estimateDetails?.estimate?.date, 
                        name: "Invoice", 
                        selectedClient : estimateDetails?.client,
                        discountTotal : estimateDetails?.estimate?.discount || ''
                    }} 
                    // customTemplates={customTemplates} 
                    // customTemplates={[]}
                    selectedTemp={estimateDetails?.customInvoice?.templateName}
                    selectedId={
                        estimateDetails?.customInvoice?.logoId
                            ? { id: estimateDetails?.customInvoice?.logoId, logoImage: estimateDetails?.customInvoice?.logoImage }
                            : null
                    }
                    selectedSize={estimateDetails?.customInvoice?.logoSize}
                    alignPos={estimateDetails?.customInvoice?.logoPosition}
                    selectedColour={
                        estimateDetails?.customInvoice?.colourId
                            ? { id: estimateDetails?.customInvoice?.colourId, colourCode: estimateDetails?.customInvoice?.colourCode }
                            : null
                    }
                    customColour={estimateDetails?.customInvoice?.customColour}
                    selectedHeader={
                        estimateDetails?.customInvoice?.headerId
                            ? { id: estimateDetails?.customInvoice?.headerId, headerImg: estimateDetails?.customInvoice?.headerImg }
                            : null
                    }
                    selectedWatermark={
                        estimateDetails?.customInvoice?.waterMarkId
                            ? {
                                    id: estimateDetails?.customInvoice?.waterMarkId,
                                    waterMarkImg: estimateDetails?.customInvoice?.waterMarkImg,
                                }
                            : null
                    }
                    // customOption={estimateDetails?.customInvoiceOption || {}}
                     />
                </div>
            </div>    
        </div>    
    );
}
export default InvoicePreview;


// customTemplates={customTemplates}