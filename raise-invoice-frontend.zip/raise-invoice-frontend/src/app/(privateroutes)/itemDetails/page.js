"use client"


const ItemDetails = () =>{
    return (
        <>

        <h2>item Details</h2>
        </>
    )   
}

export default ItemDetails;