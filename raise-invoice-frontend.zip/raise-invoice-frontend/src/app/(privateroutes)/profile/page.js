'use client';
import React, { useEffect, useState, useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import ProfileMiddleSection from '@/Components/ProfileMiddleSection/ProfileMiddleSection';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCircleArrowRight } from '@fortawesome/free-solid-svg-icons';
import Link from 'next/link';
import './profile.css';
import { useRouter } from 'next/navigation';
import { clientProfileDetails } from '@/redux/slices/authSlice';

const API_BASE =
    typeof process !== 'undefined' && process.env.NEXT_PUBLIC_API_BASE
        ? process.env.NEXT_PUBLIC_API_BASE
        : 'http://localhost:4001/api/v1';

const getToken = () =>
    typeof localStorage !== 'undefined' ? localStorage.getItem('web-auth-token') : null;

const Profile = () => {
    const dispatch = useDispatch();
    const { user } = useSelector((state) => state.auth || {});
    const router = useRouter();

    const [connection, setConnection] = useState(null);
    const [lastSync, setLastSync] = useState(null);
    const [loading, setLoading] = useState({
        invoices: false,
        clients: false,
        lastSync: false,
        connect: false,
        disconnect: false,
    });
    const [message, setMessage] = useState(null);

    const fetchWithAuth = useCallback((url, options = {}) => {
        const token = getToken();
        const headers = {
            ...(options.headers || {}),
            Authorization: token ? `Bearer ${token}` : undefined,
        };
        return fetch(url, { ...options, headers });
    }, []);

    const loadProfileAndStatus = useCallback(() => {
        dispatch(clientProfileDetails());
        checkConnectionStatus();
        fetchLastSync();
    }, [dispatch]);

    useEffect(() => {
        loadProfileAndStatus();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const checkConnectionStatus = async () => {
        try {
            const res = await fetchWithAuth(`${API_BASE}/connection-status`);
            if (!res.ok) throw new Error('Failed to load connection status');
            const status = await res.json();
            setConnection(status);
        } catch (err) {
            console.error('Error checking connection:', err);
            setConnection(null);
        }
    };

    const fetchLastSync = async () => {
        setLoading((s) => ({ ...s, lastSync: true }));
        try {
            const res = await fetchWithAuth(`${API_BASE}/last-sync`);
            if (!res.ok) throw new Error('Failed to fetch last fetch');
            const payload = await res.json();
            // Accept common shapes: { lastSync }, { lastSyncAt }, { last_sync }
            const ts =
                payload?.lastSync || payload?.lastSyncAt || payload?.last_sync || payload?.timestamp || null;
            setLastSync(ts);
        } catch (err) {
            console.error('Error fetching last fetch:', err);
            setLastSync(null);
        } finally {
            setLoading((s) => ({ ...s, lastSync: false }));
        }
    };

    const handleConnect = async () => {
        setLoading((s) => ({ ...s, connect: true }));
        try {
            const res = await fetchWithAuth(`${API_BASE}/connect`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    // backend expected redirect after auth; adapt if your backend handles it
                    redirectAfterAuth: `${API_BASE}/callback`,
                }),
            });
            if (!res.ok) throw new Error('Connect initiation failed');
            const { consentUrl } = await res.json();
            if (consentUrl) router.push(consentUrl);
        } catch (err) {
            console.error(err);
            setMessage({ type: 'error', text: 'Failed to start connect flow' });
        } finally {
            setLoading((s) => ({ ...s, connect: false }));
        }
    };

    const handleDisconnect = async () => {
        setLoading((s) => ({ ...s, disconnect: true }));
        try {
            const res = await fetchWithAuth(`${API_BASE}/disconnect`, { method: 'POST' });
            if (!res.ok) throw new Error('Disconnect failed');
            setConnection({ connected: false });
            setMessage({ type: 'success', text: 'Disconnected from Xero' });
        } catch (err) {
            console.error(err);
            setMessage({ type: 'error', text: 'Failed to disconnect' });
        } finally {
            setLoading((s) => ({ ...s, disconnect: false }));
        }
    };

    const syncInvoiceFromXero = async (type) => {
        setLoading((s) => ({ ...s, [type]: true }));
        setMessage(null);
        try {
            const res = await fetchWithAuth(`${API_BASE}/sync/invoices-from-xero`, {
                method: 'GET',
            });
            if (!res.ok) {
                const txt = await res.text();
                throw new Error(txt || `Sync ${type} failed`);
            }
            const payload = await res.json();
            console.log(`Sync response:`, payload);
            // backend may return updated last sync time
            const updated = payload?.lastSync || payload?.lastSyncAt || payload?.last_sync || null;
            if (updated) setLastSync(updated);
            setMessage({ type: 'success', text: `Synced ${type} from Xero` });
        } catch (err) {
            console.error(err);
            setMessage({ type: 'error', text: `Failed to sync ${type}` });
        } finally {
            setLoading((s) => ({ ...s, [type]: false }));
        }
    };

    const syncCustomerFromXero = async (type) => {
        // type: 'invoices' | 'clients'
        setLoading((s) => ({ ...s, [type]: true }));
        setMessage(null);
        try {
            const res = await fetchWithAuth(`${API_BASE}/sync/customer-from-xero`, {
                method: 'GET',
            });
            if (!res.ok) {
                const txt = await res.text();
                throw new Error(txt || `Sync ${type} failed`);
            }
            const payload = await res.json();
            console.log(`Sync response:`, payload);
            // backend may return updated last sync time
            const updated = payload?.lastSync || payload?.lastSyncAt || payload?.last_sync || null;
            if (updated) setLastSync(updated);
            setMessage({ type: 'success', text: `Synced ${type} from Xero` });
        } catch (err) {
            console.error(err);
            setMessage({ type: 'error', text: `Failed to sync ${type}` });
        } finally {
            setLoading((s) => ({ ...s, [type]: false }));
        }
    };

    const handleSyncInvoices = async () => syncInvoiceFromXero('invoices');
    const handleSyncClients = async () => syncCustomerFromXero('clients');
    const handleResync = async () => {
        setMessage(null);
        await fetchLastSync();
        // Optionally re-run a resync operation on backend:
        // await fetchWithAuth(`${API_BASE}/resync`, { method: 'POST' });
    };

    const renderLastSync = () => {
        if (loading.lastSync) return <span>Loading...</span>;
        if (!lastSync) return <span>Never synced</span>;
        try {
            const d = new Date(lastSync);
            if (!isNaN(d)) return <span>{d.toLocaleString()}</span>;
            return <span>{String(lastSync)}</span>;
        } catch {
            return <span>{String(lastSync)}</span>;
        }
    };

    return (
        <>
            <ProfileMiddleSection />
            <div className="col-lg-8 profile-right-side">
                <div className="company-container contentArea form-input-label">
                    <div className="company-custom">
                        <p className="subheading">Company</p>
                        <div className="comapney-top">
                            <div className="company">
                                <p>Company Info</p>
                                <Link href="/company-details">
                                    <FontAwesomeIcon className="arrow" icon={faCircleArrowRight} />
                                </Link>
                            </div>
                            <div className="company">
                                <p>Details & Reviews</p>
                                <Link href="/allowreviews">
                                    <FontAwesomeIcon className="arrow" icon={faCircleArrowRight} />
                                </Link>
                            </div>
                        </div>
                    </div>

                    <div className="company-custom">
                        <p className="subheading">Client & Custom Settings</p>
                        <div className="comapney-top">
                            <div className="company">
                                <Link href="/customiseInvoice">
                                    <p>Customize Invoice</p>
                                </Link>
                            </div>
                            <div className="company">
                                <Link href="/customiseInvoiceOption">
                                    <p>Customize invoice options</p>
                                </Link>
                            </div>
                            <div className="company">
                                <Link href="/signature-settings">
                                    <p>Signature</p>
                                </Link>
                            </div>
                            <div className="company">
                                <Link href="/clientpayment-options">
                                    <p>Client payment options</p>
                                </Link>
                            </div>
                            <div className="company">
                                <Link href="/client-communication">
                                    <p>Client Communication & preferences</p>
                                </Link>
                            </div>
                            <div className="company">
                                <Link href="/project-settings">
                                    <p>Projects</p>
                                </Link>
                            </div>
                        </div>
                    </div>

                    <div className="company-custom">
                        <p className="subheading">Integrations</p>

                        <div className="comapney-top">
                            <div className="integrations company">
                                <div className="integrations-left">
                                    <h6>QuickBooks</h6>
                                    <p>
                                        Connect to automatically sync your RaiseInvoice paid invoices and client
                                        information to QuickBooks Online.
                                    </p>
                                    {/* <Link href="/">Learn more about QuickBooks Online</Link> */}
                                </div>
                                <div className="integrations-right">
                                    <h6 className="connect">Connect</h6>
                                    {/* <Link href="/">View</Link> */}
                                </div>
                            </div>

                            <div className="integrations company">
                                <div className="integrations-left">
                                    <h6>Xero</h6>
                                    <p>
                                        Connect to automatically sync your RaiseInvoice paid invoices and client
                                        information to Xero. Use the buttons to fetch invoices or clients from Xero
                                        into RaiseInvoice. Last fetch time is shown below.
                                    </p>
                                    {/* <Link href="https://www.xero.com/" target="_blank">
                                        Learn more about Xero
                                    </Link> */}
                                    {/* <div style={{ marginTop: 12 }}>
                                        <strong>Fetch actions:</strong>
                                        <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
                                            <button
                                                onClick={handleSyncInvoices}
                                                disabled={!connection?.connected || loading.invoices}
                                                aria-label="Fetch invoices from Xero"
                                            >
                                                {loading.invoices ? 'invoices...' : 'Invoices'}
                                            </button>
                                            <button
                                                onClick={handleSyncClients}
                                                disabled={!connection?.connected || loading.clients}
                                                aria-label="Fetch clients from Xero"
                                            >
                                                {loading.clients ? 'clients...' : 'Clients'}
                                            </button>
                                        </div>
                                    </div>

                                    <div style={{ marginTop: 12 }}>
                                        <strong>Last Fetch Data and time:</strong>
                                        {console.log('Last fetch timestamp:', lastSync)}
                                        <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginTop: 8 }}>
                                            <div>{renderLastSync()}</div>
                                            <button onClick={handleResync} disabled={loading.lastSync} aria-label="Resync">
                                                {loading.lastSync ? 'Refreshing...' : 'Resync'}
                                            </button>
                                        </div>
                                    </div> */}

                                    {message && (
                                        <div
                                            style={{
                                                marginTop: 10,
                                                color: message.type === 'error' ? '#b00020' : '#006400',
                                            }}
                                        >
                                            {message.text}
                                        </div>
                                    )}
                                </div>

                                <div className="integrations-right">
                                    {connection?.connected ? (
                                        <>
                                            <h6 className="connected">Connected</h6>
                                            <button onClick={handleDisconnect} disabled={loading.disconnect}>
                                                {loading.disconnect ? 'Disconnecting...' : <h6 className="disconnect">Disconnect</h6>}
                                            </button>
                                        </>
                                    ) : (
                                        <button onClick={handleConnect} disabled={loading.connect}>
                                            {loading.connect ? 'Starting...' : <h6 className="connect">Connect</h6>}
                                        </button>
                                    )}
                                </div>
                            </div>

                            <div className="integrations company">
                                <div className="integrations-left">
                                    <h6>SalesForce</h6>
                                    <p>Connect to automatically sync your RaiseInvoice paid invoices and client
                                        information to SalesForce. Use the buttons to fetch invoices or clients from SalesForce
                                        into RaiseInvoice. Last fetch time is shown below.</p>
                                    {/* <Link href="/">Learn more about SalesForce</Link> */}
                                </div>
                                <div className="integrations-right">
                                    <h6 className="connect">Connect</h6>
                                </div>
                            </div>

                            {/* <div className="integrations company">
                                <div className="integrations-left">
                                    <h6>Zapier</h6>
                                    <p>Connect to automatically sync your RaiseInvoice data with Zapier workflows.</p>
                                    <Link href="/">Learn more about Zapier</Link>
                                </div>
                                <div className="integrations-right">
                                    <h6 className="connect">Connect</h6>
                                </div>
                            </div>

                            <div className="integrations company">
                                <div className="integrations-left">
                                    <h6>Freshbooks</h6>
                                    <p>Connect to automatically sync your RaiseInvoice paid invoices and client information to Freshbooks.</p>
                                    <Link href="/">Learn more</Link>
                                </div>
                                <div className="integrations-right">
                                    <h6 className="connect">Connect</h6>
                                </div>
                            </div> */}
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
};

export default Profile;
