"use client";
import React, { useEffect, useState, useRef, forwardRef } from "react";
import Pageheader from "@/utils/pageheader";
import Accordion from "react-bootstrap/Accordion";
import { useDispatch } from "react-redux";
import { createInvoiceSignature, getInvoiceSignature } from "@/redux/slices/dataSlice";
import { toast } from "react-toastify";
import { useRouter } from "next/navigation";
import "./signature.css";
import { IMAGE } from "@/utils/Theme";
import { faTimes } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

// Helper to extract base64 from data URL
function extractBase64(dataUrl) {
    console.log(dataUrl, "2222222222");
    if (!dataUrl) return "";
    return dataUrl;
}

// Helper to get image src from value
function getImageSrc(value) {
    if (!value) return "";

    console.log(value, "1111111111");
    if (value.startsWith("data:image")) return value;
    return `data:image/png;base64,${value}`;
}

// ESign component (inline)
// eslint-disable-next-line react/display-name
const ESign = forwardRef(
    (
        {
            sigType,
            setSigType,
            sigText,
            setSigText,
            padValue,
            uploadValue,
            onChange,
            color = "#0d6efd",
            error = {},
        },
        ref
    ) => {
        const getError = (field) => error && error[field];
        return (
            <div>
                <div className="col-lg-12">
                    <SignatureField
                        padValue={padValue}
                        uploadValue={uploadValue}
                        onChange={onChange}
                        color={color}
                        error={
                            sigType === "text"
                                ? getError("signatureText")
                                : getError("signatureData")
                        }
                        type={sigType}
                        setType={setSigType}
                        textValue={sigText}
                        setTextValue={setSigText}
                    />
                </div>
            </div>
        );
    }
);

function SignatureField({
    padValue,
    uploadValue,
    onChange,
    color,
    error,
    type,
    setType,
    textValue,
    setTextValue,
}) {
    const canvasRef = useRef(null);
    const [drawing, setDrawing] = useState(false);

    // Draw pad image if padValue changes
    useEffect(() => {
        if (type === "pad" && padValue && canvasRef.current) {
            const ctx = canvasRef.current.getContext("2d");
            const img = new window.Image();
            img.onload = () => {
                ctx.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height);
                ctx.drawImage(img, 0, 0, canvasRef.current.width, canvasRef.current.height);
            };
            img.src = getImageSrc(padValue);
        } else if (type === "pad" && canvasRef.current) {
            const ctx = canvasRef.current.getContext("2d");
            ctx.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height);
        }
    }, [padValue, type]);

    const getPos = (e) => {
        const canvas = canvasRef.current;
        const rect = canvas.getBoundingClientRect();
        let x, y;
        if (e.touches && e.touches.length) {
            x = (e.touches[0].clientX - rect.left) * (canvas.width / rect.width);
            y = (e.touches[0].clientY - rect.top) * (canvas.height / rect.height);
        } else {
            x = (e.clientX - rect.left) * (canvas.width / rect.width);
            y = (e.clientY - rect.top) * (canvas.height / rect.height);
        }
        return { x, y };
    };

    const handleStart = (e) => {
        e.preventDefault();
        setDrawing(true);
        const { x, y } = getPos(e);
        const ctx = canvasRef.current.getContext("2d");
        ctx.strokeStyle = color || "#222";
        ctx.lineWidth = 1.2; // Make the signature thinner/smaller
        ctx.lineCap = "round";
        ctx.beginPath();
        ctx.moveTo(x, y);
    };

    const handleMove = (e) => {
        if (!drawing) return;
        e.preventDefault();
        const { x, y } = getPos(e);
        const ctx = canvasRef.current.getContext("2d");
        ctx.lineTo(x, y);
        ctx.stroke();
    };

    const handleEnd = () => {
        if (!drawing) return;
        setDrawing(false);
        const canvas = canvasRef.current;
        const data = canvas.toDataURL();
        onChange({ pad: data }, "pad");
    };

    const clearPad = () => {
        const canvas = canvasRef.current;
        const ctx = canvas.getContext("2d");
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        onChange({ pad: "" }, "pad");
    };

    const handleUpload = (e) => {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = () => {
                // Resize image before passing to onChange
                resizeImage(reader.result, 600, 160, (resizedDataUrl) => {
                    onChange({ upload: resizedDataUrl }, "upload");
                });
            };
            reader.readAsDataURL(file);
        }
    };

    // Helper to resize image using canvas
    function resizeImage(dataUrl, maxWidth, maxHeight, callback) {
        const img = new window.Image();
        img.onload = function () {
            let width = img.width;
            let height = img.height;
            // Maintain aspect ratio
            if (width > maxWidth) {
                height = Math.round((height * maxWidth) / width);
                width = maxWidth;
            }
            if (height > maxHeight) {
                width = Math.round((width * maxHeight) / height);
                height = maxHeight;
            }
            const canvas = document.createElement("canvas");
            canvas.width = width;
            canvas.height = height;
            const ctx = canvas.getContext("2d");
            ctx.drawImage(img, 0, 0, width, height);
            callback(canvas.toDataURL("image/png"));
        };
        img.onerror = function () {
            // fallback to original if error
            callback(dataUrl);
        };
        img.crossOrigin = "Anonymous";
        img.src = dataUrl;
    }

    const handleDeleteUpload = () => {
        onChange({ upload: "" }, "upload");
    };

    const handleTextChange = (e) => {
        setTextValue(e.target.value);
        onChange({ text: e.target.value }, "text");
    };

    return (
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            <div style={{ marginBottom: 8 }} className="DrawUploadType">
                <label>
                    <input
                        type="radio"
                        name="sigtype"
                        checked={type === "pad"}
                        onChange={() => setType("pad")}
                    />{" "}
                    Draw
                </label>
                <label style={{ marginLeft: 16 }}>
                    <input
                        type="radio"
                        name="sigtype"
                        checked={type === "upload"}
                        onChange={() => setType("upload")}
                    />{" "}
                    Upload
                </label>
                <label style={{ marginLeft: 16 }}>
                    <input
                        type="radio"
                        name="sigtype"
                        checked={type === "text"}
                        onChange={() => setType("text")}
                    />{" "}
                    Type
                </label>
            </div>
            {type === "pad" && (
                <>
                    <canvas
                        ref={canvasRef}
                        width={600}
                        height={120}
                        style={{
                            border: "1.5px solid #cbd5e1",
                            borderRadius: 8,
                            background: "#fff",
                            touchAction: "none",
                            cursor:
                                "url('https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.2/svgs/solid/pencil.svg') 0 16, pointer",
                        }}
                        onMouseDown={handleStart}
                        onMouseUp={handleEnd}
                        onMouseOut={handleEnd}
                        onMouseMove={handleMove}
                        onTouchStart={handleStart}
                        onTouchEnd={handleEnd}
                        onTouchCancel={handleEnd}
                        onTouchMove={handleMove}
                    />
                    <button
                        type="button"
                        onClick={clearPad}
                        style={{
                            background: "#edf2f7",
                            color: color,
                            border: "1px solid #cbd5e1",
                            borderRadius: 8,
                            padding: "0.3rem 1rem",
                            fontSize: "1rem",
                            fontWeight: 500,
                            cursor: "pointer",
                            width: 120,
                        }}
                    >
                        Clear
                    </button>
                </>
            )}
            {type === "upload" && (
                <div className="ImageUpload">
                    {uploadValue ? (
                        <div style={{ position: "relative", display: "inline-block" }}>
                            <img
                                src={getImageSrc(uploadValue)}
                                alt="Signature"
                                style={{
                                    maxWidth: 200,
                                    maxHeight: 60,
                                    border: "1px solid #cbd5e1",
                                    borderRadius: 6,
                                    marginTop: 8,
                                }}
                            />
                            <button
                                type="button"
                                onClick={handleDeleteUpload}
                                style={{
                                    position: "absolute",
                                    top: 0,
                                    right: 0,
                                    background: "#fff",
                                    border: "1px solid #cbd5e1",
                                    borderRadius: "50%",
                                    cursor: "pointer",
                                    padding: 2,
                                    margin: 2,
                                }}
                                title="Remove"
                            >
                                <FontAwesomeIcon icon={faTimes} />
                            </button>
                        </div>
                    ) : (
                        <>
                            <input
                                type="file"
                                accept="image/*"
                                onChange={handleUpload}
                                style={{ marginBottom: 8 }}
                            />
                            <div className="uploadImage">
                                <img src={IMAGE.upload} alt="" />
                            </div>
                        </>
                    )}
                </div>
            )}
            {type === "text" && (
                <input
                    type="text"
                    value={textValue}
                    onChange={handleTextChange}
                    placeholder="Type your signature"
                    style={{
                        border: "1.5px solid #cbd5e1",
                        borderRadius: 8,
                        padding: "0.5rem",
                        fontSize: "1.2rem",
                        width: 300,
                    }}
                />
            )}
            {error && <div className="error-msg">{error}</div>}
        </div>
    );
}

const SignatureSettings = () => {
    const dispatch = useDispatch();
    const router = useRouter();
    const [loading, setLoading] = useState(false);
    const [newId, setNewId] = useState("");
    const [invoice, setInvoice] = useState(true);
    const [estimate, setEstimate] = useState(true);
    const [purchaseOrder, setPurchaseOrder] = useState(true);
    const [creditNote, setCreditNote] = useState(true);
    const [error, setError] = useState({});

    // Signature states
    const [signatureType, setSignatureType] = useState("pad");
    const [padSignature, setPadSignature] = useState(""); // base64 string
    const [uploadSignature, setUploadSignature] = useState(""); // base64 string
    const [signatureText, setSignatureText] = useState("");

    useEffect(() => {
        const fetchSignature = async () => {
            try {
                const result = await dispatch(getInvoiceSignature()).unwrap();
                if (result && result.data) {
                    const data = result.data;
                    setNewId(data.id || "");
                    setInvoice(!!data.invoice);
                    setEstimate(!!data.estimate);
                    setPurchaseOrder(!!data.purchaseOrder);
                    setCreditNote(!!data.creditNote);
                    setSignatureType(data.signatureType || "pad");
                    setPadSignature(data.signature || "");
                    setUploadSignature(data.signatureData || "");
                    setSignatureText(data.signatureText || "");
                }
            } catch (err) {
                // No existing signature, keep defaults
            }
        };
        fetchSignature();
    }, [dispatch]);

    const handleCheckboxChange = (setter) => (event) => {
        setter(event.target.checked);
    };

    // ESign change handler
    const handleSignatureChange = (valueObj, type) => {
        setSignatureType(type);
        if (type === "pad") {
            setPadSignature(valueObj.pad.startsWith("data:image") ? valueObj.pad.split(",")[1] : valueObj.pad);
            setUploadSignature(""); // clear upload
            setSignatureText("");
        } else if (type === "upload") {
            setUploadSignature(valueObj.upload.startsWith("data:image") ? valueObj.upload.split(",")[1] : valueObj.upload);
            setPadSignature(""); // clear pad
            setSignatureText("");
        } else if (type === "text") {
            setSignatureText(valueObj.text);
            setPadSignature("");
            setUploadSignature("");
        }
    };

    const handleSave = async () => {
        setLoading(true);
        setError({});
        const formData = {
            id: newId,
            invoice: invoice ? true : false,
            estimate: estimate ? true : false,
            purchaseOrder: purchaseOrder ? true : false,
            creditNote: creditNote ? true : false,
            signatureType: signatureType,
            signatureData: signatureType === "upload" ? uploadSignature : "",
            signatureText: signatureType === "text" ? signatureText : "",
            signature: signatureType === "pad" ? padSignature : "",
        };
        try {
            const result = await dispatch(createInvoiceSignature(formData)).unwrap();
            result.status ? toast.success(result.message) : toast.error(result.message);
            router.refresh();
            router.push(`/profile`);
        } catch (err) {
            setError({ api: `Error saving settings: ${err.message}` });
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="communication-container">
            <Pageheader label="Signature Settings" handleSave={handleSave} loading={loading} />
            <div className="communication-inner">
                {/* <Accordion defaultActiveKey="0"> */}
                    {/* <Accordion.Item eventKey="0"> */}
                        {/* <Accordion.Header>
                            <p className="accorheading">Signature settings</p>
                        </Accordion.Header> */}
                        {/* <Accordion.Body> */}
                            <div style={{ marginBottom: 24 }}>
                                <ESign
                                    sigType={signatureType}
                                    setSigType={setSignatureType}
                                    sigText={signatureText}
                                    setSigText={setSignatureText}
                                    padValue={padSignature}
                                    uploadValue={uploadSignature}
                                    onChange={handleSignatureChange}
                                    color="#0d6efd"
                                    error={error}
                                />
                            </div>
                            <div className="reminders">
                                <div>
                                    <input
                                        type="checkbox"
                                        checked={invoice}
                                        onChange={handleCheckboxChange(setInvoice)}
                                    />
                                    <label>Invoice</label>
                                </div>
                                <div>
                                    <input
                                        type="checkbox"
                                        checked={estimate}
                                        onChange={handleCheckboxChange(setEstimate)}
                                    />
                                    <label>Estimate</label>
                                </div>
                                <div>
                                    <input
                                        type="checkbox"
                                        checked={purchaseOrder}
                                        onChange={handleCheckboxChange(setPurchaseOrder)}
                                    />
                                    <label>Purchase Order</label>
                                </div>
                                <div>
                                    <input
                                        type="checkbox"
                                        checked={creditNote}
                                        onChange={handleCheckboxChange(setCreditNote)}
                                    />
                                    <label>Credit Note</label>
                                </div>
                            </div>
                        {/* </Accordion.Body> */}
                    {/* </Accordion.Item> */}
                {/* </Accordion> */}
            </div>
        </div>
    );
};

export default SignatureSettings;
