'use client';
import React from 'react';
import Link from 'next/link';
import Pageheader from '@/utils/pageheader';
import ToggleButton from '@/utils/ToggleButton/toggleButton';
import '../client-communication/communication.css';
import './security.css';

const Security = () => {
  const handleChange = () => {
    console.log("test");
  }
  return (
    <div className='communication-container'>
      <Pageheader label="Security" />

      <div className='communication-inner commonPadding'>

        <p className='subheading'>Security</p>

        <div className='inner-padding'>
          <ToggleButton
            checked={true}
            onChange={handleChange}
            id="message"
            heading="Verify its you when you log in"
          />
          <div className='security-verify'>
            <p>Two-factor authentication is required for this account.
              <br />
              Other team members will also need to verify when logging in .
            </p>
            <Link href="">Learn More</Link>
          </div>
        </div>

        <p className='subheading'>Trusted Devices</p>

        <div className='trust-device inner-padding'>
          <div>
            <h6 className='trust'>Trusted Devices</h6>
            <p>You don't need to verify your identity each time you log in on a trusted device.</p>
          </div>
          <h6 className='remove'>Remove All</h6>
        </div>
      </div>
    </div>
  )
}

export default Security
