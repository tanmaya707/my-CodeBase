import NewProject from "@/Components/newproject/newproject";

const CreateProjectPage = () => {
    return (
        <div>
            <NewProject />
        </div>
    );
}

export default CreateProjectPage;