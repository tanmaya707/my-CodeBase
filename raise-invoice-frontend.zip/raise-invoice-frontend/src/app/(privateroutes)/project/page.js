"use client"
import React, { useState, useEffect } from 'react';
import MiddleSection from '@/Components/MiddleSection/MiddleSection';
import MenuLandingPage from '@/utils/MenuLanding/MenuLandingPage';
import NewProject from '@/Components/newproject/newproject';
import { IMAGE } from '@/utils/Theme';
import { useDispatch, useSelector } from 'react-redux';
import { fetchProjectData } from '@/redux/slices/dataSlice';

const Project = () => {
  const dispatch = useDispatch();
  const [activeTab, setActiveTab] = useState(0);
  const [addProjectForm, setAddProjectForm] = useState(false);
  const [projectToEdit, setProjectToEdit] = useState(null);
  const { projects } = useSelector((state) => state.dataReducer);
  const {} = useSelector(state => state?.dataReducer)

  const Image = IMAGE.blank_project

  // const middleSectionTabs = [
  //   {
  //     id: 1,
  //     name: "All",
  //     // component: "PurchaseOrder"
  //   },
  //   {
  //     id: 2,
  //     name: "Active",
  //     // component: "CreditMemo"
  //   },
  //   {
  //     id: 3,
  //     name: "Completed",
  //     // component: "CreditMemo"
  //   }
  // ]

  // useEffect(() => {
  //   dispatch(fetchProjectData());
  // }, [dispatch]);

  // const handleAddClientFormOpen = () => {
  //   setProjectToEdit(null);
  //   setAddProjectForm(true);
  // };

  // const handleProjectAdded = () => {
  //   dispatch(fetchProjectData());
  //   setAddProjectForm(false);
  // };

  // const handleEditProject = (project) => {
  //   setProjectToEdit(project);
  //   setAddProjectForm(true);
  // };

  const getFilteredProjects = () => {
    if (!projects?.data) return [];
    if (activeTab === 0) return projects.data;
    if (activeTab === 1) return projects.data.filter(p => p.status !== 3);
    if (activeTab === 2) return projects.data.filter(p => p.status === 3);
    return projects.data;
  };

  return (
    <>
      {/* <MiddleSection
        label="Project"
        tabs={middleSectionTabs}
        btnlabel={projectToEdit ? 'Edit Project' : 'Add New Project'}
        // handleState={setAddProject}
        // activeTag={activeTag}
        setActiveTag={setActiveTab}
        setAddProjectForm={handleAddClientFormOpen}
        projects={getFilteredProjects()}
        onEditProject={handleEditProject}
        activeTag={activeTab}
        handleCreate={handleAddClientFormOpen}
        
      />
      {/* <div className='add-client contentArea'> */}
        {/* {addProjectForm ? (
          <NewProject onProjectAdded={handleProjectAdded} projectToEdit={projectToEdit} />
        ) : ( */}
          <MenuLandingPage
            Image={Image}
            text="Create project"
            label={projectToEdit ? 'Edit Project' : 'Add New Project'}
            // handleState={setAddProjectForm}
            datas={getFilteredProjects()}
            createRoute='/project/create'
          />
        {/* )} */}
      {/* </div> */}
    </>
  );
};

export default Project;
