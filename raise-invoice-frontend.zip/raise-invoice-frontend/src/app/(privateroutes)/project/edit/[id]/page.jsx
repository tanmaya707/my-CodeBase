"use client";
import NewProject from "@/Components/newproject/newproject";
import { useSelector } from "react-redux";

const UpdateProjectPage = ({params}) => {
    const projectId = params.id;
    const { projects } = useSelector((state) => state.dataReducer);
    const project = projects?.data?.find(p => p.id.toString() === projectId);

    return (
        <div>
            <NewProject projectToEdit={project} />
        </div>
    );
}

export default UpdateProjectPage;