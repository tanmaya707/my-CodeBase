"use client"
import MiddleSection from "@/Components/MiddleSection/MiddleSection";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchProjectData, setActiveMidTab } from "@/redux/slices/dataSlice";
import "bootstrap/dist/css/bootstrap.min.css";
import "../../general.css";
import './project.css'


const middleSectionTabs = [
    {
        id: 1,
        name: "All",
    },
    {
        id: 2,
        name: "Active",
    },
    {
        id: 3,
        name: "Completed",
    }
]

export default function authLayout({ children }) {
    const router = useRouter();
    const dispatch = useDispatch();
    const { projects, loading } = useSelector(state => state?.dataReducer)
    const [activeTag, setActiveTag] = useState(0);
    const [filteredProjects, setFilteredProjects] = useState([]);

    useEffect(() => {
        dispatch(fetchProjectData());
    }, [dispatch]);

    // const handleCreateInvoice = () => {
    //     router.push("/addInvoice");
    // };

    useEffect(() => {
        // console.log("activeTag ::: ", activeTag);

        dispatch(setActiveMidTab(activeTag === 0 ? null : activeTag === 1 ? 1 : 3))
        if (!projects?.data) setFilteredProjects();
        if (activeTag === 0) setFilteredProjects(projects.data);
        else if (activeTag === 1) setFilteredProjects(projects.data.filter(p => p.status !== 3));
        else if (activeTag === 2) setFilteredProjects(projects.data.filter(p => p.status === 3));
        else setFilteredProjects(projects.data);
    }, [projects, activeTag]);


    return (
        <>
            <MiddleSection
                label="Project"
                tabs={middleSectionTabs}
                activeTag={activeTag}
                setActiveTag={setActiveTag}
                list={filteredProjects}
                createRoute="/project/create"
            />

            <div className={"col-lg-8"}>
                <div className="add-client contentArea">
                    {children}
                </div>
            </div>
        </>
    );
}
