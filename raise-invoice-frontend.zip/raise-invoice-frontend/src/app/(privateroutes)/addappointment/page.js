"use client";
import React, { useState, useEffect, useRef } from "react";
import { useDispatch } from "react-redux";
import { useRouter, useSearchParams } from "next/navigation";
import Modal from "react-bootstrap/Modal";
import Pageheader from "@/utils/pageheader";
import { IMAGE } from "@/utils/Theme";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faAngleDown,
  faLocationDot,
  faCircleXmark,
  faCalendarDays,
  faClock,
  faLongArrowLeft,
} from "@fortawesome/free-solid-svg-icons";
import Calendar from "react-calendar";
import "react-calendar/dist/Calendar.css";
import Link from "next/link";
import { ToastContainer, toast } from "react-toastify";
import GooglePlacesAutocomplete from "react-google-places-autocomplete";
import DropdownIndicator from "@/Components/dropdownIndicator/dropdownIndicator";
import { getContactsForAppointment } from "../../../redux/slices/projectSlice";
import {
  createAppointmentData,
  fetchClientData,
  getAppointmentData,
  updateAppointmentData,
} from "@/redux/slices/dataSlice";
import "./addappointment.css";

const AddAppointment = () => {
  const [show, setShow] = useState(false);
  const [selectedClient, setSelectedClient] = useState(null);
  const [startDate, setStartDate] = useState(new Date());
  const [endDate, setEndDate] = useState(new Date());
  const [startTime, setStartTime] = useState("");
  const [endTime, setEndTime] = useState("");
  const [showCalendarStart, setShowCalendarStart] = useState(false);
  const [showCalendarEnd, setShowCalendarEnd] = useState(false);
  const [location, setLocation] = useState(null);
  const [clients, setClients] = useState([]);
  const [loading, setLoading] = useState(false);
  const [note, setNote] = useState("");
  const [documents, setDocument] = useState(null);
  const [documentName, setDocumentName] = useState("");
  const [showContactsDropdown, setShowContactsDropdown] = useState(false);
  const [addMoreAppointment, setAddMoreAppointment] = useState({
    notes: "",
    start_date: "",
    start_time: "",
    end_date: "",
    end_time: "",
    contact_id: [],
    contacts: [],
  });
  const contactsDropdownRef = useRef();
  const toggleRef = useRef();

  const dispatch = useDispatch();
  const router = useRouter();
  const searchParams = useSearchParams();
  const appointmentId = searchParams.get("id");

  // Calendar refs for outside click
  const calendarStartRef = useRef(null);
  const calendarEndRef = useRef(null);

  useEffect(() => {
    function handleClickOutside(event) {
      if (
        showContactsDropdown &&
        contactsDropdownRef.current &&
        toggleRef.current &&
        !contactsDropdownRef.current.contains(event.target) &&
        !toggleRef.current.contains(event.target)
      ) {
        setShowContactsDropdown(false);
      }
    }
    if (showContactsDropdown) {
      document.addEventListener("mousedown", handleClickOutside);
    }
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [showContactsDropdown]);

  useEffect(() => {
    const fetchClients = async () => {
      const clientData = await dispatch(fetchClientData()).unwrap();
      setClients(clientData.data);
    };
    fetchClients();
  }, [dispatch]);

  useEffect(() => {
    async function fetchContacts() {
      try {
        const result = await dispatch(getContactsForAppointment()).unwrap();
        setAddMoreAppointment((prev) => ({
          ...prev,
          contacts: result.data || [],
        }));
      } catch (e) {
        setAddMoreAppointment((prev) => ({ ...prev, contacts: [] }));
      }
    }
    fetchContacts();
  }, [dispatch]);

    // Calendar outside click handler
    useEffect(() => {
        const handleClickOutside = (event) => {
            if (
                showCalendarStart &&
                calendarStartRef.current &&
                !calendarStartRef.current.contains(event.target)
            ) {
                setShowCalendarStart(false);
            }
            if (
                showCalendarEnd &&
                calendarEndRef.current &&
                !calendarEndRef.current.contains(event.target)
            ) {
                setShowCalendarEnd(false);
            }
        };
        if (showCalendarStart || showCalendarEnd) {
            document.addEventListener("mousedown", handleClickOutside);
        }
        return () => {
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, [showCalendarStart, showCalendarEnd]);

  useEffect(() => {
    if (appointmentId) {
      const fetchAppointment = async () => {
        setLoading(true);
        try {
          const data = await dispatch(getAppointmentData({ id: appointmentId })).unwrap();
          if (data && data.data) {
            const appt = data.data;
            setSelectedClient(
              appt.client
                ? { id: appt.client_id, name: appt.client.name }
                : null
            );
            setLocation(
              appt.location
                ? { label: appt.location, value: appt.location }
                : null
            );
            setStartDate(new Date(appt.start_date));
            setEndDate(new Date(appt.end_date));
            setStartTime(appt.start_time || "");
            setEndTime(appt.end_time || "");
            setNote(appt.notes || "");
            setDocument(null);
            setDocumentName(appt.document || "");
            setAddMoreAppointment((prev) => ({
              ...prev,
              contact_id: Array.isArray(appt.contact_ids)
              ? appt.contact_ids
              : typeof appt.contact_ids === "string"
              ? (() => {
                try {
                  // Try to parse as JSON array string
                  const parsed = JSON.parse(appt.contact_ids);
                  if (Array.isArray(parsed)) return parsed;
                } catch (e) {
                  // Fallback: split by comma if not JSON array
                  return appt.contact_ids
                  .split(",")
                  .map((id) => id.trim())
                  .filter(Boolean);
                }
                return [];
                })()
              : [],
            }));
            
          }
        } catch (err) {
          toast.error("Failed to fetch appointment data.");
        } finally {
          setLoading(false);
        }
      };
      fetchAppointment();
    }
  }, [appointmentId, dispatch]);


const [unsaved, setUnsaved] = useState(false);
const [modalType, setModalType] = useState('reload');
const [showModal, setShowModal] = useState(false);

// Store initial values for comparison
const initialValues = useRef({
  selectedClient,
  location,
  startDate,
  endDate,
  startTime,
  endTime,
  note,
  documents,
  documentName,
  contact_id: addMoreAppointment.contact_id,
});

// Update initial values on mount or appointment load
useEffect(() => {
  if (appointmentId) {
    initialValues.current = {
      selectedClient,
      location,
      startDate,
      endDate,
      startTime,
      endTime,
      note,
      documents,
      documentName,
      contact_id: addMoreAppointment.contact_id,
    };
  }
  // For new appointment, set initial as empty
}, [appointmentId]);

// Track unsaved changes
useEffect(() => {
  const dirty =
    selectedClient !== initialValues.current.selectedClient ||
    location !== initialValues.current.location ||
    startDate.toString() !== initialValues.current.startDate?.toString() ||
    endDate.toString() !== initialValues.current.endDate?.toString() ||
    startTime !== initialValues.current.startTime ||
    endTime !== initialValues.current.endTime ||
    note !== initialValues.current.note ||
    documents !== initialValues.current.documents ||
    documentName !== initialValues.current.documentName ||
    JSON.stringify(addMoreAppointment.contact_id) !== JSON.stringify(initialValues.current.contact_id);
  setUnsaved(dirty);
}, [
  selectedClient,
  location,
  startDate,
  endDate,
  startTime,
  endTime,
  note,
  documents,
  documentName,
  addMoreAppointment.contact_id,
]);

// Handle browser/tab close
useEffect(() => {
  const handleBeforeUnload = (e) => {
    if (unsaved) {
      e.preventDefault();
      e.returnValue = '';
      setModalType('close');
      setShowModal(true);
      return '';
    }
  };
  window.addEventListener('beforeunload', handleBeforeUnload);
  return () => window.removeEventListener('beforeunload', handleBeforeUnload);
}, [unsaved]);

// Intercept reload (F5 or Ctrl+R)
useEffect(() => {
  const handleKeyDown = (e) => {
    if (unsaved && (e.key === 'F5' || (e.ctrlKey && e.key === 'r'))) {
      e.preventDefault();
      setModalType('reload');
      setShowModal(true);
    }
  };
  window.addEventListener('keydown', handleKeyDown);
  return () => window.removeEventListener('keydown', handleKeyDown);
}, [unsaved]);


  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const handleClientSelect = (client) => {
    setSelectedClient(client);
    handleClose();
  };

  const validateForm = () => {
    if (addMoreAppointment.contact_id.length === 0) {
      toast.error("Please select a contact.");
      return false;
    }
    if (!location) {
      toast.error("Please select a location.");
      return false;
    }
    if (startDate >= endDate) {
      toast.error("End date must be after start date.");
      return false;
    }
    if (!startTime || !endTime) {
      toast.error("Please provide both start and end times.");
      return false;
    }
    if (!note) {
      toast.error("Please provide a note.");
      return false;
    }
    return true;
  };

  const handleSaveOrUpdate = async () => {
    if (!validateForm()) return;
    setLoading(true);
    try {
      const formDataToSubmit = new FormData();
      formDataToSubmit.append(
        "client_id",
        selectedClient ? selectedClient.id : ""
      );
      // contact_id is now always an array
      let contactIds = addMoreAppointment.contact_id || [];
      if (!Array.isArray(contactIds)) contactIds = [];
      if (contactIds.length > 0) {
        formDataToSubmit.append("contact_ids", contactIds.join(","));
      } else {
        formDataToSubmit.append("contact_ids", "");
      }
      formDataToSubmit.append(
        "location",
        location ? location.label : ""
      );
      formDataToSubmit.append(
        "start_date",
        startDate.toISOString().split("T")[0]
      );
      formDataToSubmit.append(
        "start_time",
        startTime || "00:00:00"
      );
      formDataToSubmit.append(
        "end_date",
        endDate.toISOString().split("T")[0]
      );
      formDataToSubmit.append(
        "end_time",
        endTime || "00:00:00"
      );
      formDataToSubmit.append("notes", note);

      if (documents) {
        formDataToSubmit.append("document", documents.name);
      } else if (documentName) {
        formDataToSubmit.append("document", documentName);
      }

      let result;
      if (appointmentId) {
        formDataToSubmit.append("id", appointmentId);
        result = await dispatch(updateAppointmentData(formDataToSubmit)).unwrap();
      } else {
        result = await dispatch(createAppointmentData(formDataToSubmit)).unwrap();
      }

      if (result.status) {
        toast.success(result.message);
        router.push("/appointment");
      } else {
        toast.error(result.message);
      }
    } catch (error) {
      toast.error("Error saving appointment.");
    } finally {
      setLoading(false);
    }
  };

  const formatDateDisplay = (date) => {
    if (!date) return "";
    const d = new Date(date);
    const day = String(d.getDate()).padStart(2, "0");
    const month = String(d.getMonth() + 1).padStart(2, "0");
    const year = d.getFullYear();
    return `${day}-${month}-${year}`;
  };

  const handleStartTimeChange = (e) => {
    const val = e.target.value;
    const hr = Number(val?.split(":")[0]);
    const min = Number(val?.split(":")[1]);
    const now = startDate.setHours(hr, min, 0, 0);
    const diffMs = endDate - new Date(now);
    const diffHours = diffMs / (1000 * 60 * 60);
    if (diffHours > 24) {
      toast.error("Select time with in 24 hours");
      return;
    }
    setStartTime(val.length === 5 ? val + ":00" : val);
  };

  const handleEndTimeChange = (e) => {
    const val = e.target.value;
    const hr = Number(val?.split(":")[0]);
    const min = Number(val?.split(":")[1]);
    const now = endDate.setHours(hr, min, 0, 0);
    const diffMs = new Date(now) - startDate;
    const diffHours = diffMs / (1000 * 60 * 60);
    if (diffHours > 24) {
      toast.error("Select time with in 24 hours");
      return;
    }
    setEndTime(val.length === 5 ? val + ":00" : val);
  };

  const handleNoteChange = (e) => {
    setNote(e.target.value);
  };

  const handleDocumentChange = (e) => {
    const file = e.target.files[0];
    setDocument(file);
    setDocumentName(file ? file.name : "");
  };

  const handleRemoveDocument = () => {
    setDocument(null);
    setDocumentName("");
  };

  // Contact selection logic
  const handleContactToggle = (contactId) => {
    setAddMoreAppointment((prev) => {
      let ids = Array.isArray(prev.contact_id) ? prev.contact_id : [];
      if (ids.includes(contactId)) {
        ids = ids.filter((id) => id !== contactId);
      } else {
        ids = [...ids, contactId];
      }
      return { ...prev, contact_id: ids };
    });
  };

  const handleContactRemove = (contactId) => {
    setAddMoreAppointment((prev) => {
      let ids = Array.isArray(prev.contact_id) ? prev.contact_id : [];
      ids = ids.filter((id) => id !== contactId);
      return { ...prev, contact_id: ids };
    });
  };

  return (
    <>
      <div className="add-appt contentArea">
        <Pageheader
          label={
            <span className="backButton">
              <Link
                href="/appointment"
                style={{ padding: "4px", color: "#04070aff" }}
              >
                <FontAwesomeIcon className="backButton" icon={faLongArrowLeft} />
              </Link>
              {appointmentId ? "Update Appointment" : "Add Appointment"}
            </span>
          }
          handleSave={handleSaveOrUpdate}
          loading={loading}
          saveLabel={appointmentId ? "Update" : "Save"}
        />
        <div className="contentArea-inner form-input-label">
          <div className="row">
            {/* Client selection */}
            <div className="col-lg-6 ">
              <div className="sub-head">
                <p className="subheading">Contact</p>
              </div>
              <div className="floating-label-group mb-3-group mb-2">
                {/* <label>Choose Contacts</label> */}
                <div
                  ref={toggleRef}
                  className="input-form-control"
                  style={{
                    display: "flex",
                    flexWrap: "wrap",
                    gap: 4,
                    minHeight: 46,
                    border: "1px solid #047FFF80",
                    borderRadius: 9,
                    padding: "4px 32px 4px 12px",
                    position: "relative",
                    cursor: "pointer",
                    alignItems: "center",
                    height: "auto",
                  }}
                  tabIndex={0}
                  onClick={(e) => {
                    e.stopPropagation();
                    setShowContactsDropdown((prev) => !prev);
                  }}
                >
                  {/* Placeholder */}
                  {(!addMoreAppointment.contact_id ||
                    addMoreAppointment.contact_id.length === 0) && (
                    <span style={{ color: "#888", fontSize: 15, marginLeft: 10 }}>
                      Select contact
                    </span>
                  )}

                  {/* Selected contacts */}
                  {["primary", "secondary"].map(
                    (type) =>
                      Array.isArray(addMoreAppointment.contacts[type]) &&
                      addMoreAppointment.contacts[type]
                        .filter((contact) =>
                          (addMoreAppointment.contact_id || []).includes(contact.id)
                        )
                        .map((contact) => (
                          <span
                            key={contact.id}
                            style={{
                              background: "#e6f0ff",
                              borderRadius: 12,
                              padding: "2px 8px",
                              marginRight: 4,
                              marginTop: 4,
                              display: "inline-flex",
                              fontSize: "10px",
                              alignItems: "center",
                              maxWidth: "calc(100% - 40px)",
                              whiteSpace: "nowrap",
                              textOverflow: "ellipsis",
                              overflow: "hidden",
                            }}
                          >
                            {contact.contact_name}
                            <span
                              style={{
                                marginLeft: 4,
                                cursor: "pointer",
                                color: "#047FFF",
                              }}
                              onClick={(e) => {
                                e.stopPropagation();
                                handleContactRemove(contact.id);
                              }}
                            >
                              <FontAwesomeIcon icon={faCircleXmark} />
                            </span>
                          </span>
                        ))
                  )}

                  {/* Arrow icon */}
                  <span
                    style={{
                      position: "absolute",
                      right: 8,
                      top: "50%",
                      transform: showContactsDropdown
                        ? "translateY(-50%) rotate(180deg)"
                        : "translateY(-50%) rotate(0deg)",
                      fontSize: 18,
                      color: "#888",
                      pointerEvents: "none",
                      transition: "transform 0.2s",
                    }}
                  >
                    <FontAwesomeIcon className="filterImage" icon={faAngleDown} />
                  </span>

                  {/* Dropdown for contacts */}
                  {showContactsDropdown && (
                    <div
                      ref={contactsDropdownRef}
                      style={{
                        position: "absolute",
                        top: "100%",
                        left: 0,
                        zIndex: 10,
                        background: "#fff",
                        border: "1px solid #ccc",
                        borderRadius: 4,
                        width: "100%",
                        marginTop: 2,
                        boxShadow: "0 2px 8px rgba(0,0,0,0.08)",
                      }}
                    >
                      {/* Primary Contacts */}
                      {Array.isArray(addMoreAppointment.contacts.primary) &&
                        addMoreAppointment.contacts.primary.length > 0 && (
                        <div>
                          <div
                            style={{
                              fontWeight: 600,
                              marginBottom: 4,
                              marginTop: 4,
                              marginBottom: 8,
                              textAlign: "start",
                              paddingLeft: 8,
                            }}
                          >
                            Primary Contacts
                          </div>
                          <div
                            style={{
                              display: "flex",
                              flexWrap: "wrap",
                              gap: 8,
                              padding: "0 8px 8px 8px",
                            }}
                          >
                            {Array.isArray(addMoreAppointment.contacts.primary) &&
                              addMoreAppointment.contacts.primary
                                .filter((c) => c.is_primary)
                                .map((contact) => {
                                  const selected = (addMoreAppointment.contact_id || []).includes(
                                    contact.id
                                  );
                                  return (
                                    <div
                                      key={contact.id}
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        handleContactToggle(contact.id);
                                      }}
                                      style={{
                                        padding: "6px 12px",
                                        borderRadius: 8,
                                        border: selected
                                          ? "2px solid #047FFF"
                                          : "1px solid #ccc",
                                        background: selected ? "#e6f0ff" : "#fff",
                                        cursor: "pointer",
                                        fontWeight: selected ? 600 : 400,
                                        color: selected ? "#047FFF" : "#333",
                                        marginBottom: 4,
                                      }}
                                    >
                                      {contact.contact_name}
                                    </div>
                                  );
                                })}
                          </div>
                        </div>
                      )}
                      {/* Secondary Contacts */}
                      {Array.isArray(addMoreAppointment.contacts.secondary) &&
                        addMoreAppointment.contacts.secondary.length > 0 && (
                        <div>
                          <div
                            style={{
                              marginBottom: 8,
                              fontWeight: 600,
                              marginBottom: 4,
                              marginTop: 4,
                                textAlign: "start",
                              paddingLeft: 8,
                            }}
                          >
                            Secondary Contacts
                          </div>
                          <div
                            style={{
                              display: "flex",
                              flexWrap: "wrap",
                              gap: 8,
                              padding: "0 8px 8px 8px",
                            }}
                          >
                            {Array.isArray(addMoreAppointment.contacts.secondary) &&
                              addMoreAppointment.contacts.secondary
                                .filter((c) => !c.is_primary)
                                .map((contact) => {
                                  const selected = (addMoreAppointment.contact_id || []).includes(
                                    contact.id
                                  );
                                  return (
                                    <div
                                      key={contact.id}
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        handleContactToggle(contact.id);
                                      }}
                                      style={{
                                        padding: "6px 12px",
                                        borderRadius: 8,
                                        border: selected
                                          ? "2px solid #047FFF"
                                          : "1px solid #ccc",
                                        background: selected ? "#e6f0ff" : "#fff",
                                        cursor: "pointer",
                                        fontWeight: selected ? 600 : 400,
                                        color: selected ? "#047FFF" : "#333",
                                        marginBottom: 4,
                                      }}
                                    >
                                      {contact.contact_name}
                                    </div>
                                  );
                                })}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Location */}
            <div className="col-lg-6 mb-2">
              <div className="sub-head">
                <p className="subheading">Location</p>
              </div>
              <div
                className="floating-label-group locationGroup "
                style={{
                  // border: "1px solid #047FFF",
                  borderRadius: "5px",
                }}
              >
                <GooglePlacesAutocomplete
                  apiKey={process.env.NEXT_PUBLIC_GOOGLE_MAP_KEY}
                  selectProps={{
                    value: location,
                    onChange: setLocation,
                    placeholder: "Select Location",
                    components: { DropdownIndicator },
                  }}
                />
                <FontAwesomeIcon className="point-img" icon={faLocationDot} />
              </div>
            </div>

            {/* Date & Time */}
            <div className="col-lg-6">
              <div className="sub-head pt-0 mb-2">
                <p className="subheading">Date & Time</p>
              </div>
              <div className="input-field-group">
                <div className="row">
                  {/* Start Date */}
                  <div className="col-lg-6">
                    <div
                      className="floating-label-group mb-3"
                      style={{ position: "relative" }}
                    >
                      <input
                        type="text"
                        id="start-date"
                        className="input-form-control input-logo"
                        value={formatDateDisplay(startDate)}
                        readOnly
                        onClick={() => {
                          setShowCalendarStart(true);
                          setShowCalendarEnd(false);
                        }}
                      />
                      <label className="floating-label">Start Date</label>
                      <FontAwesomeIcon
                        className="point-img"
                        icon={faCalendarDays}
                        onClick={() => {
                          setShowCalendarStart(!showCalendarStart);
                          setShowCalendarEnd(false);
                        }}
                      />
                      {showCalendarStart && (
                        <div ref={calendarStartRef}>
                        <Calendar
                          onChange={(date) => {
                            const diffMs = endDate - date;
                            const diffHours = diffMs / (1000 * 60 * 60);
                            if (endDate - date < 0) {
                              toast.error(
                                "Start date should not be greater than end date"
                              );
                              return;
                            }
                            if (diffHours > 24) {
                              toast.error(
                                "Start date should not be lesser than 24 hours"
                              );
                              return;
                            }
                            setStartDate(date);
                            setShowCalendarStart(false);
                          }}
                          value={startDate}
                        />
                        </div>
                      )}
                    </div>

                    {/* End Date */}
                    <div
                      className="floating-label-group mb-3"
                      style={{ position: "relative" }}
                    >
                      <input
                        type="text"
                        id="end-date"
                        className="input-form-control input-logo"
                        value={formatDateDisplay(endDate)}
                        readOnly
                        onClick={() => {
                          setShowCalendarEnd(true);
                          setShowCalendarStart(false);
                        }}
                      />
                      <label className="floating-label">End Date</label>
                      <FontAwesomeIcon
                        className="point-img"
                        icon={faCalendarDays}
                        onClick={() => {
                          setShowCalendarEnd(!showCalendarEnd);
                          setShowCalendarStart(false);
                        }}
                      />
                      {showCalendarEnd && (
                        <div ref={calendarEndRef}>
                        <Calendar
                          onChange={(date) => {
                            const diffMs = date - startDate;
                            const diffHours = diffMs / (1000 * 60 * 60);
                            if (diffMs < 0) {
                              toast.error(
                                "Start date should not be greater than end date"
                              );
                              return;
                            }
                            if (diffHours > 24) {
                              toast.error(
                                "End date should not be greater than 24 hours"
                              );
                              return;
                            }
                            setEndDate(date);
                            setShowCalendarEnd(false);
                          }}
                          value={endDate}
                        />
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Start and End Time */}
                  <div className="col-lg-6">
                    {/* Start Time */}
                    <div
                      className="floating-label-group mb-3"
                      style={{ position: "relative" }}
                    >
                      <input
                        type="time"
                        id="start-time"
                        className="input-form-control input-logo"
                        value={startTime}
                        onChange={handleStartTimeChange}
                      />
                      <label className="floating-label">Start Time</label>
                      <FontAwesomeIcon
                        className="point-img"
                        icon={faClock}
                        onClick={() => {
                          document.getElementById("start-time").focus();
                        }}
                      />
                    </div>

                    {/* End Time */}
                    <div
                      className="floating-label-group mb-3"
                      style={{ position: "relative" }}
                    >
                      <input
                        type="time"
                        id="end-time"
                        className="input-form-control input-logo"
                        value={endTime}
                        onChange={handleEndTimeChange}
                      />
                      <label className="floating-label">End Time</label>
                      <FontAwesomeIcon
                        className="point-img"
                        icon={faClock}
                        onClick={() => {
                          document.getElementById("end-time").focus();
                        }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Document Upload */}
            <div className="col-lg-6">
              <div className="sub-head pt-0 mb-2 ">
                <p className="subheading">Document</p>
              </div>
              <div className="form-group uploadingFile mb-3">
                <input
                  type="file"
                  accept=".pdf,.doc,.docx,.jpg,.png"
                  onChange={handleDocumentChange}
                  style={{
                    display: documents || documentName ? "none" : "block",
                  }}
                />
                {documents || documentName ? (
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: "8px",
                      position: "relative",
                    }}
                  >
                    <p style={{ margin: 0 }}>

                      {(() => {
                          const name = documents?.name || documentName
                          const maxLen = 20;
                          return name.length > maxLen
                            ? name.slice(0, maxLen) + "..."
                            : name;
                        })()}
                    </p>
                    <span
                      style={{
                        cursor: "pointer",
                        color: "#dc3545",
                        fontWeight: "bold",
                        fontSize: "18px",
                        marginLeft: "4px",
                        width: "20px",
                        height: "20px",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        fontSize: "12px",
                        position: "absolute",
                        right: "-26px",
                        top: "-10px",
                      }}
                      onClick={handleRemoveDocument}
                      aria-label="Remove document"
                      title="Remove document"
                    >
                      &#10005;
                    </span>
                  </div>
                ) : (
                  <p style={{ margin: 0 }}>
                    Upload File <img src={IMAGE.downloadTop} alt="" />
                  </p>
                )}
              </div>
            </div>

            {/* Note */}
            <div className="col-lg-12">
              <div className="sub-head">
                <p className="subheading">Note</p>
              </div>
            </div>

            <div className="col-lg-12 ">
              <div className="floating-label-group">
                <textarea
                  type="text"
                  id="description"
                  className="input-form-control"
                  value={note}
                  onChange={handleNoteChange}
                  required
                />
                <label className="floating-label">Description</label>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Client Modal */}
      <Modal show={show} centered onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Choose Client</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div className="row">
            {clients.map((client) => (
              <div className="col-lg-12" key={client.id}>
                <button
                  className="client-btn btn"
                  onClick={() => handleClientSelect(client)}
                >
                  {client.name}
                </button>
                <hr />
              </div>
            ))}
          </div>
        </Modal.Body>
      </Modal>
    </>
  );
};

export default AddAppointment;