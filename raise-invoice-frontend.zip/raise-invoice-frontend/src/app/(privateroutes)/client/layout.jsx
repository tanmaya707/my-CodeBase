"use client"
import MiddleSection from "@/Components/MiddleSection/MiddleSection";
import { fetchClientData } from "@/redux/slices/dataSlice";
import { useEffect } from "react";
import { useDispatch } from "react-redux";
import { useSelector } from "react-redux";
import "./client.css";

const ClientLayOut = ({ children }) => {
    const dispatch = useDispatch();
    const { clients } = useSelector((state) => state.dataReducer);

    useEffect(() => {
        dispatch(fetchClientData());
    }, [dispatch]);

    return (
        <> 
            <MiddleSection
                itemType="client"
                label="Client"
                list={clients?.data}
                createRoute="/client/create"
            />
            <div className="col-lg-8">
                <div className="add-client contentArea">
                    {children}
                </div>
            </div>
        </>)
}

export default ClientLayOut;