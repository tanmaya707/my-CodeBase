"use client"
import React, { useState, useEffect, useRef, use } from 'react';
import { IMAGE } from '@/utils/Theme';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import Accordion from 'react-bootstrap/Accordion';
import Link from 'next/link';
import './clientactivity.css';
import '../../../general.css';
import {
    faSquarePlus,
    faPhoneVolume,
    faEnvelope,
    faPhone,
    faMessage,
    faCircleExclamation,
    faArrowRight,
    faAngleDown,
    faXmark,
    faLocationDot,
    faGlobe,
} from '@fortawesome/free-solid-svg-icons';
import { useDispatch } from 'react-redux';
import { formatCurrency } from '@/dependencies/utils/helper';
import { deatilsClientData, fetchMasterData } from '@/redux/slices/dataSlice';

const detailsTab = [
    { id: "1", title: "Activity" },
    { id: "2", title: "Projects" }
];

const ClientDetails = ({ params }) => {
    const { id } = use(params);
    const dropdownRef = useRef(null);
    const infoPanelRef = useRef(null);
    const [show, setShow] = useState(false);
    const [plusShow, setPlusShow] = useState(false);
    const [currencyList, setCurrencyList] = useState([]);
    const [clientData, setClientData] = useState({
        name: '',
        billingName: '',
        billingEmail: '',
        billingPhone: '',
        billingAddress: '',
        contactName: '',
        contactPhone: '',
        website: '',
        taxNo: '',
        paymentTerms: '',
        outstandingBalance: '',
        statementCount: '',
        dueDate: '',
        dueAmount: '',
        dueStatus: '',
        dueDateText: ''

    });
    const [activeTab, setActiveTab] = useState("1");

    const dispatch = useDispatch();

    useEffect(() => {
    async function fetchData() {
        try {
        const data = await dispatch(fetchMasterData()).unwrap();
        setCurrencyList(data.currencyData || []);
        } catch (err) {
        console.error("Failed to fetch master data", err);
        }
    }
    fetchData();
    }, [dispatch]);

    useEffect(() => {
             dispatch(deatilsClientData(id)).then((result) => {
            if (result && result.payload) {
                const data = result.payload;
                
                setClientData({
                    name: data.name || '',
                    billingName: data.name || '',
                    billingEmail: data.email || '',
                    billingPhone: data.phone || '',
                    billingLocation: data.address || '',
                    contactName: data.contacts?.contact_name || '',
                    contactPhone: data.contacts?.phone || '',
                    website: data.contacts?.website || '',
                    taxNo: data.otherDetails?.tax_no || '',
                    paymentTerms: data.otherDetails?.payment_term || '',
                    outstandingBalance: data.outstandingBalance || '',
                    statementCount: data.statementCount || '',
                    dueDate: data.dueDate || '',
                    dueAmount: data.dueAmount || '',
                    dueStatus: data.dueStatus || '',
                    dueDateText: data.dueDate ? `${data.dueDate}, Due in ${data.dueIn || ''}` : ''
                })
            }
        }).catch((error) => {
            console.error("Error fetching client data:", error);
        });
    }, [dispatch, id]);

    // useEffect(() => {
    //     const handleClickOutside = (event) => {
    //         if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
    //             setPlusShow(false);

    //         }
    //     };
    //     document.addEventListener('mousedown', handleClickOutside);
    //     return () => {
    //         document.removeEventListener('mousedown', handleClickOutside);
    //     };
    // }, []);



const handleShow = () => {
  setShow(prev => !prev);       // Toggle info panel
  setPlusShow(false);           // Always close dropdown
};

const plusClick = () => {
  setPlusShow(prev => !prev);   // Toggle dropdown
  setShow(false);               // Always close info panel
};

const handleClose = () => {
  setShow(false);               // Close info panel manually
};

    const innerBodyRef = useRef(null);


// useEffect(() => {
//   const handleClickOutside = (event) => {
//     const isInsideDropdown = dropdownRef.current?.contains(event.target);
//     const isInsideInfoPanel = infoPanelRef.current?.contains(event.target);

//     // If clicked outside both
//     if (!isInsideDropdown && !isInsideInfoPanel) {
//       setPlusShow(false);
//       setShow(false);
//     }

//     // If clicked outside dropdown but inside info panel
//     if (!isInsideDropdown && isInsideInfoPanel) {
//       setPlusShow(false);
//     }

//     // If clicked outside info panel but inside dropdown
//     if (!isInsideInfoPanel && isInsideDropdown) {
//       setShow(false);
//     }
//   };

//   document.addEventListener('mousedown', handleClickOutside);
//   return () => {
//     document.removeEventListener('mousedown', handleClickOutside);
//   };
// }, []);


useEffect(() => {
  const handleClickOutside = (event) => {
    const isInsideDropdown = dropdownRef.current?.contains(event.target);
    const isInsideInfoPanel = infoPanelRef.current?.contains(event.target);

    if (!isInsideDropdown && !isInsideInfoPanel) {
      setPlusShow(false);
      setShow(false);
    }
  };

  document.addEventListener('click', handleClickOutside);
  return () => {
    document.removeEventListener('click', handleClickOutside);
  };
}, []);



    return (
        <div>
            {plusShow &&
                <div
                    className="clientactivity-blur-overlay"
                    style={{
                        position: 'fixed',
                        top: 0,
                        left: 0,
                        width: '100vw',
                        height: '100vh',
                        zIndex: 100,
                        // backdropFilter: 'blur(6px)',
                        background: 'rgba(255,255,255,0.2)',
                    }}
                />
            }
            <div className='clientactivity-head' ref={dropdownRef} style={plusShow ? { position: 'relative', zIndex: 101 } : {}}>
                <div>
                    <h4 className='name'><b>{clientData.name}</b></h4>
                </div>
                <div className='head-right'>
                    <div className='activityProject'>
                        {detailsTab.map((tab, index) => (
                            <h4
                                className={tab.id == activeTab ? "active1" : ""}
                                onClick={() => setActiveTab(tab.id)}
                                key={index}
                            >
                                {tab.title}
                            </h4>
                        ))}
                    </div>
                    <div className='head-right-innerBody'  ref={dropdownRef}>
                        <div className='clientActivity'  style={{ position: 'relative', zIndex: 102 }}>
                            <FontAwesomeIcon onClick={plusClick} className="add-iconn" icon={faSquarePlus} />
                            {plusShow && (
                                <ul className='clientActivityDropedown' style={{ position: 'absolute', zIndex: 103 }}>
                                    <li><Link href={`/addCreditNote?cId=${id}`}> Credit Note <img src={IMAGE.plusDrpdown} alt="" /></Link></li>
                                    <li><Link href={`/purchaseOrder/create?cId=${id}`}>Purchase Order <img src={IMAGE.plusDrpdown} alt="" /></Link></li>
                                    <li><Link href={`/estimate/create?cId=${id}`}>Estimate <img src={IMAGE.plusDrpdown} alt="" /></Link></li>
                                    <li><Link href={`/addInvoice?cId=${id}`}>Invoice <img src={IMAGE.plusDrpdown} alt="" /></Link></li>
                                    <li className='opacityLess'>
                                        <Link href={{}}>Statement <img src={IMAGE.downloadColored} alt="" /></Link>
                                    </li>
                                </ul>
                            )}
                        </div>
                        <FontAwesomeIcon className="head-icon" icon={faPhoneVolume} />
                        <FontAwesomeIcon className="head-icon" icon={faEnvelope} />
                        <FontAwesomeIcon className="head-icon" icon={faMessage} />
                        <FontAwesomeIcon onClick={handleShow} className="head-icon" icon={faCircleExclamation} />
                    </div>
                </div>
                {show && (
                    <div className='moreinfo-body moreInfoBodyScroll' ref={infoPanelRef}
                        style={{
                            // maxHeight: '80vh',
                            // overflowY: 'auto',
                        }}
                    >
                        <div className='moreinfo-content'>
                            <div className='moreinfo-heading'>
                                <h6>More Information</h6>
                                <FontAwesomeIcon onClick={handleClose} icon={faXmark} />
                            </div>
                            <Accordion defaultActiveKey="0">
                                <Accordion.Item eventKey="0">
                                    <Accordion.Header>
                                        <p className='accorheading'>Billing Details</p>
                                    </Accordion.Header>
                                    <Accordion.Body>
                                        <div className='accordianItemActivity'>
                                            <div className='moreinfo-items'>
                                                <div>
                                                    <p>Billing Name</p>
                                                    <h4>{clientData.billingName}</h4>
                                                </div>
                                            </div>
                                            <div className='moreinfo-items'>
                                                <FontAwesomeIcon icon={faPhone} />
                                                <div>
                                                    <p>Phone</p>
                                                    <h4>{clientData.billingPhone}</h4>
                                                </div>
                                            </div>
                                            <div className='moreinfo-items'>
                                                <FontAwesomeIcon icon={faEnvelope} />
                                                <div>
                                                    <p>Email Address</p>
                                                    <h4>{clientData.billingEmail}</h4>
                                                </div>
                                            </div>
                                            <div className='moreinfo-items'>
                                                <FontAwesomeIcon icon={faLocationDot} />
                                                <div>
                                                    <p>Location</p>
                                                    <h4>{clientData.billingLocation}</h4>
                                                </div>
                                            </div>
                                        </div>
                                    </Accordion.Body>
                                </Accordion.Item>
                            </Accordion>
                            <Accordion defaultActiveKey="0">
                                <Accordion.Item eventKey="0">
                                    <Accordion.Header>
                                        <p className='accorheading'>Contact Details</p>
                                    </Accordion.Header>
                                    <Accordion.Body>
                                        <div className='accordianItemActivity'>
                                            <div className='moreinfo-items'>
                                                <div>
                                                    <p>Contact Name</p>
                                                    <h4>{clientData.contactName}</h4>
                                                </div>
                                            </div>
                                            <div className='moreinfo-items'>
                                                <FontAwesomeIcon icon={faPhone} />
                                                <div>
                                                    <p>Phone No.</p>
                                                    <h4>{clientData.contactPhone}</h4>
                                                </div>
                                            </div>
                                            <div className='moreinfo-items'>
                                                <FontAwesomeIcon icon={faGlobe} />
                                                <div>
                                                    <p>Website</p>
                                                    <h4>{clientData.website}</h4>
                                                </div>
                                            </div>
                                        </div>
                                    </Accordion.Body>
                                </Accordion.Item>
                            </Accordion>
                            <Accordion defaultActiveKey="0">
                                <Accordion.Item eventKey="0">
                                    <Accordion.Header>
                                        <p className='accorheading'>Other Details</p>
                                    </Accordion.Header>
                                    <Accordion.Body>
                                        <div className='accordianItemActivity'>
                                            <div className='moreinfo-items'>
                                                <div>
                                                    <p>Tax No.</p>
                                                    <h4>{clientData.taxNo}</h4>
                                                </div>
                                            </div>
                                            <div className='moreinfo-items'>
                                                <div>
                                                    <p>Payment Terms</p>
                                                    <h4>{clientData.paymentTerms}</h4>
                                                </div>
                                            </div>
                                        </div>
                                    </Accordion.Body>
                                </Accordion.Item>
                            </Accordion>
                            <button className='add-note'><FontAwesomeIcon icon={faSquarePlus} />
                                Add note
                            </button>
                        </div>


                    </div>
                )}
            </div>
            {(activeTab == "1" || activeTab == "2") && (
                <div className='clientDetails'>
                    <div className='client-activity-details'>
                        <div className="clientActvtyLeft">
                            <h6>Outstanding Balance</h6>
                            <p>{clientData.statementCount || '1 unpaid(1 overdue)'}</p>
                        </div>
                        <div>
                            <h4>{formatCurrency(clientData.outstandingBalance || 120, currencyList)}</h4>
                        </div>
                    </div>
                    <div className='client-activity-details'>
                        <div className="clientActvtyLeft">
                            <h6>Statement</h6>
                            <p>Collect Payment</p>
                        </div>
                        <div>
                            <FontAwesomeIcon className='arrwIconRight' icon={faArrowRight} />
                        </div>
                    </div>
                    <div className='client-activity-details'>
                        <div className='sort clientActvtyLeft'>
                            <h6>2025 sorted by category</h6>
                            <FontAwesomeIcon icon={faAngleDown} />
                        </div>
                        <div>
                            <img className='sort-arrow' src={IMAGE.up_down_arrow} alt="sort-arrow" />
                        </div>
                    </div>
                    <div className="card">
                        <div className="card-body">
                            <div className='client-activity-details'>
                                <div className="clientActvtyLeft">
                                    <h6>{clientData.name}</h6>
                                    <p>{clientData.dueDateText || '23 Oct, Due in 2 days'}</p>
                                </div>
                                <div>
                                    <h6>{formatCurrency(clientData.dueAmount || 125, currencyList)}</h6>
                                    <p className='unsent'>{clientData.dueStatus || 'Unsent'}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default ClientDetails;
