"use client"
import AddClientForm from "@/Components/addClientForm/addClientForm"
import { useEffect, useState } from "react";
import { useSelector } from "react-redux";

const EditClient = ({params}) => {
  const { clients } = useSelector((state) => state.dataReducer);
  const [clientToEdit, setClientToEdit] = useState({})

  useEffect(() => {
    (async () => {
        const clientParam = await params;
        const client = clients?.data?.filter(client => client?.id === Number(clientParam?.id))
        client && !!client?.length && setClientToEdit(client[0])
    })()
  }, [params, clients])

    return (
        <div>
            <AddClientForm clientToEdit={clientToEdit} />
        </div>
    )
}

export default EditClient