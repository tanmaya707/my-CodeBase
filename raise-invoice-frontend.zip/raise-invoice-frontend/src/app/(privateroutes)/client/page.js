"use client";
import { IMAGE } from "@/utils/Theme";
import "../../../Components/addClientForm/addClientForm.css";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useSelector } from "react-redux";

const Client = () => {
  const router = useRouter();
  const { clients } = useSelector((state) => state.dataReducer);

  const setAddAppointmentForm = () => {
    router.push(`/addappointment`);
  };

  return (
    <div className={"scrollRightSide"}>
      {/* <button className='apt'>Appointments</button> */}
      <button onClick={() => router.push("/appointment")} className="apt">
        Appointments
      </button>
      <img className="worldmap" src={IMAGE.worldmap} />
      {!clients?.data && (
        <p className="client-text mt-3">No Clients Added Yet</p>
      )}
      <div className="client-btn">
        <button
          className="create-btn"
          onClick={() => router.push("/client/create")}
        >
          Add New Client
        </button>
        <button
          className="create-btn"
          onClick={(setAddAppointmentForm)}
        >
          Add Appointment
        </button>
      </div>
    </div>
  );
};

export default Client;



// import React, { useState, useEffect } from "react";
// import MiddleSection from "@/Components/MiddleSection/MiddleSection";
// import AddClientForm from "../../../Components/addClientForm/addClientForm";
// import { useDispatch, useSelector } from "react-redux";
// import { fetchClientData } from "@/redux/slices/dataSlice";
// const dispatch = useDispatch();
// const [addClientForm, setAddClientForm] = useState(false);
// const [clientToEdit, setClientToEdit] = useState(null);

// const handleAddClientFormOpen = () => {
//   setClientToEdit(null);
//   setAddClientForm(true);
// };

// const handleClientAdded = () => {
//   dispatch(fetchClientData());
//   setAddClientForm(false);
// };

// const handleEditClient = (client) => {
//   setClientToEdit(client);
//   setAddClientForm(true);
// };

{/* <div className="add-client contentArea"> */}
          {/* {addClientForm ? (
            <AddClientForm
              onClientAdded={handleClientAdded}
              clientToEdit={clientToEdit}
            />
          ) :  */}
           
          {/* } */}
        {/* </div> */}