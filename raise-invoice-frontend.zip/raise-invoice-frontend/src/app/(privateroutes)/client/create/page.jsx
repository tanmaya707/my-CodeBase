import AddClientForm from "@/Components/addClientForm/addClientForm"

const CreateClient = () => {
    return (
    <div>
        <AddClientForm clientToEdit={null} />
    </div>)
}

export default CreateClient