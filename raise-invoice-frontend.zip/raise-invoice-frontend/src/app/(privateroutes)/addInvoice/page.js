"use client";

import React, { useState, useMemo, useEffect, useRef, useCallback } from 'react';
import { useDispatch } from 'react-redux';
import { useRouter, useSearchParams } from 'next/navigation';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
    faAngleDown, faArrowLeft, faPhone, faEnvelope, faLocationDot,
    faCircleXmark, faSquarePlus, faPenToSquare, faTrash,
    faFilePdf,
    faFileImage,
    faCalendarDays
} from '@fortawesome/free-solid-svg-icons';
import CustomInvoiceImpact from "@/Components/templates/impact";
import Accordion from 'react-bootstrap/Accordion';
import html2pdf from 'html2pdf.js';
import Calendar from 'react-calendar';
import "react-calendar/dist/Calendar.css";
import { IMAGE } from '../../../utils/Theme';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import '../../../Components/payment/paymentdetails.css';
import {
    fetchClientData, fetchTaxData, createTaxData, fetchDeleteTaxData,
    createInvoiceData, detailsInvoiceData, updateInvoiceData, fetchNextInvoiceNumber,
    fetchItemData, deatilsClientData, createAppointmentData, fetchAppointmentData, getLog, sendMail,
    getCustomInvoiceData, getCustomInvoiceOptionData,
    createExpenseData,
    fetchClientProjectData,
    getExpenseData,
    getInvoiceSignature, fetchMasterData
} from "@/redux/slices/dataSlice";

import { getContactsApi, getContactsForAppointment } from "../../../redux/slices/projectSlice";
import './addInvoice.css';
import '../../general.css';
import '../../../Components/newExpense/newexpense.css';
import './invoice.css';
import '../../../Components/addItemForm/addItemForm.css';
import '../../../app/general.css';
import ToggleButton from '@/utils/ToggleButton/toggleButton';
import Link from 'next/link';

// PDF generation and download helpers
// import jsPDF from "jspdf";
// import html2canvas from "html2canvas";
import DatePicker from 'react-datepicker';
import "react-datepicker/dist/react-datepicker.css";
import { add, differenceInMinutes, format } from 'date-fns';
import { saveTimeAPI } from '@/redux/slices/projectSlice';
import DndKitList from '@/Components/dragDropList';
import { formatCurrency } from '@/dependencies/utils/helper';
import { toast } from 'react-toastify';
import { useModal } from '@/cotexts/modalContext';
import { useRouteLeaveConfirmation } from '@/hooks/useRouteLeaveConfirmation';

const categories = [
    { value: "", label: "Select Category" },
    { value: "accommodation", label: "Accommodation" },
    { value: "advertising", label: "Advertising" },
    { value: "airfare", label: "Airfare" },
    { value: "carrental", label: "Car Rental" },
    { value: "communications", label: "Communications" }
];

function formatDate(date) {
    if (!date) return '';
    const d = new Date(date);
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    return `${months[d.getMonth()]} ${d.getDate()},${d.getFullYear()}`;
}

function addDays(date, days) {
    const d = new Date(date);
    d.setDate(d.getDate() + days);
    return d;
}

function getMonthName(month) {
    return [
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    ][month - 1];
}

const TERMS_OPTIONS = [
    { value: "", label: "None", days: 0 },
    { value: "1", label: "Custom", days: 0 },
    { value: "2", label: "Next Day", days: 1 },
    { value: "3", label: "2 Days", days: 2 },
    { value: "4", label: "3 Days", days: 3 },
    { value: "5", label: "4 Days", days: 4 },
    { value: "6", label: "5 Days", days: 5 },
    { value: "7", label: "10 Days", days: 10 },
    { value: "8", label: "30 Days", days: 30 },
    { value: "9", label: "90 Days", days: 90 },
    { value: "10", label: "180 Days", days: 180 },
    { value: "11", label: "365 Days", days: 365 },
];

const DISCOUNT_TYPE_OPTIONS = [
    { value: "flat", label: "Flat" },
    { value: "percentage", label: "Percentage" }
];



const AddInvoicePage = () => {
    const [isSticky, setIsSticky] = useState(false);
    const { parameter } = useModal();
    const dispatch = useDispatch();
    const router = useRouter();
    const searchParams = useSearchParams();
    const clientId = searchParams.get('cId');
    const invoiceId = searchParams.get('id');
    const sendText = searchParams.get('send');
    const copyId = searchParams.get('copy');
    const [isFocused, setFocused] = useState(false);

    let TABS;
    if (invoiceId) {
        TABS = ['Edit', 'Preview', 'Send'];
    } else {
        TABS = ['Create', 'Preview', 'Send'];
    }

    // Tabs
    const [activeTab, setActiveTab] = useState(invoiceId ? sendText ? 'Send' : 'Preview' : 'Create');
    const [gstTab, setGstTab] = useState('Exclusive'); // Default to Exclusive


    // =============stickey top form heafer==========


    useEffect(() => {
        const handleScroll = () => {

            const element = document.querySelector('.addClientFormTop');
            if (!element) return;

            const offsetTop = element.offsetTop; // distance from top of document
            const scrollTop = window.scrollY;

            setIsSticky(scrollTop > 50);
        };

        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    // Helper to fetch a file from a URL and return a File object
    async function fetchFileFromUrl(url, filename = "attachment") {
        const response = await fetch(url);
        const blob = await response.blob();
        return new File([blob], filename, { type: blob.type });
    }

    function handleTabChange(tab) {
        setActiveTab(tab);
        if (tab === "Send") {
            // generatePreviewPdf();
        }
    }

    //custome invoice state
    const [formData, setFormData] = useState({
        id: null,
        templateName: "impact",
        logoId: "",
        logoImage: "",
        logoSize: "medium",
        logoPosition: "center",
        colourId: "",
        colourCode: "",
        customColour: "",
        headerId: "",
        headerImg: "",
        waterMarkId: "",
        waterMarkImg: "",
    });
    const [optionData, setOptionData] = useState({
        id: null,
        shippingDetails: false,
        due_date: false,
        payment_terms: false,
        itemCode: false,
        quantityAndRate: false,
        pTax: false,
        tax_amounts: false,
        includeSignatureLine: false,
        invoicePrifix: "",
    });
    const [customTemplates, setCustomTemplates] = useState(null);
    const [unitTypes, setUnitTypes] = useState([]);
    const [currencyList, setCurrencyList] = useState([]);

    // State
    const [show, setShow] = useState(false);
    const [showClientModal, setShowClientModal] = useState(false);
    const [selectedClient, setSelectedClient] = useState(null);
    const [clientList, setClientList] = useState([]);
    const [clientDropdown, setClientDropdown] = useState([]);
    const [clientForm, setClientForm] = useState({ id: null, name: '', email: '', phone: '', address: '' });
    const [showClientDropdown, setShowClientDropdown] = useState(false);
    const [clientFormErrors, setClientFormErrors] = useState({ name: '', email: '', phone: '' });
    const [items, setItems] = useState([]);
    const [gstModal, setGstModal] = useState(false);
    const [taxRates, setTaxRates] = useState([]);
    const [showAddRateModal, setShowAddRateModal] = useState(false);
    const [newRate, setNewRate] = useState({ rate: '', percentage: '' });
    const [savingRate, setSavingRate] = useState(false);
    const [editRateId, setEditRateId] = useState(null);
    const [sentStatus, setSentStatus] = useState("unsent");
    const [selectedGstRate, setSelectedGstRate] = useState(null);
    const [itemForm, setItemForm] = useState({
        id: null,
        code: '',
        name: '',
        description: '',
        rate: '',
        quantity: '',
        unitTypes: '',
        gstChecked: false,
        gstValue: '',
        discountChecked: false,
        discountType: 'flat',
        discountValue: '',
        isAppointment: false,
        appointmentId: null
    });
    const [editItemIndex, setEditItemIndex] = useState(null);

    // Dates
    const [invoiceDate, setInvoiceDate] = useState(new Date());
    const [showCalendarStart, setShowCalendarStart] = useState(false);
    const [terms, setTerms] = useState("");
    const [dueDate, setDueDate] = useState(new Date());
    const [showDueDateCalendar, setShowDueDateCalendar] = useState(false);

    // Invoice number
    const [invoiceNumber, setInvoiceNumber] = useState('');
    const [editInvoiceNumber, setEditInvoiceNumber] = useState(false);
    const [invoiceNumberInput, setInvoiceNumberInput] = useState('');

    // Discount
    const [discountModalOpen, setDiscountModalOpen] = useState(false);
    const [invoiceDiscount, setInvoiceDiscount] = useState('');
    const [invoiceDiscountEditable, setInvoiceDiscountEditable] = useState(true);
    const [showDiscountInput, setShowDiscountInput] = useState(false);
    const [discountType, setDiscountType] = useState("%");
    const [discountInputValue, setDiscountInputValue] = useState(""); // What user types in modal
    const [discountValue, setDiscountValue] = useState("0"); // Raw value from DB, string
    const [discountAmount, setDiscountAmount] = useState(0); // Always amount, for Bill Cost

    // Attachments & Logo
    const [attachments, setAttachments] = useState([]);
    const fileInputRef = useRef();
    const [logo, setLogo] = useState('');
    const logoInputRef = useRef();

    // Button state
    const [isUpdateMode, setIsUpdateMode] = useState(false);

    const [invoiceGstRate, setInvoiceGstRate] = useState(null);
    const [invoiceGstType, setInvoiceGstType] = useState("Exclusive"); // Default to Exclusive

    // Choose Item Modal
    const [showChooseItemModal, setShowChooseItemModal] = useState(false);
    const [chooseItemList, setChooseItemList] = useState([]);
    const [chooseSelectedItems, setChooseSelectedItems] = useState([]);
    const [itemSearch, setItemSearch] = useState('');

    // Payment Instruction & Comments
    const [showPaymentInstructionInput, setShowPaymentInstructionInput] = useState(false);
    const [paymentInstruction, setPaymentInstruction] = useState('');
    const [showCommentInput, setShowCommentInput] = useState(false);
    const [comment, setComment] = useState('');
    // Deposit Modal
    const [showDepositModal, setShowDepositModal] = useState(false);
    const [depositTab, setDepositTab] = useState('percent');
    const [depositPercentage, setDepositPercentage] = useState('');
    const [depositFixedAmount, setDepositFixedAmount] = useState('');
    const [depositDueDate, setDepositDueDate] = useState(format(new Date(), 'yyyy-MM-dd'));
    const [depositAddToFuture, setDepositAddToFuture] = useState(false);
    const [depositPaid, setDepositPaid] = useState(0);
    const [deposit, setDeposit] = useState(null);

    // Appointment Modal
    const [showAppointmentModal, setShowAppointmentModal] = useState(false);
    const [appointmentList, setAppointmentList] = useState([]);
    const [appointmentSearch, setAppointmentSearch] = useState('');
    const [appointmentSelected, setAppointmentSelected] = useState([]);
    const [appointmentMonth, setAppointmentMonth] = useState(new Date().getMonth() + 1);
    const [appointmentYear, setAppointmentYear] = useState(new Date().getFullYear());
    const [appointmentLabel, setAppointmentLabel] = useState('');
    const [appointmentFlatList, setAppointmentFlatList] = useState([]);
    const [value, setValue] = useState(false);
    const [value2, setValue2] = useState(false);

    // Expense Modal
    const [showExpenseModal, setShowExpenseModal] = useState(false);
    const [expenseList, setExpenseList] = useState([]);
    const [expenseSearch, setExpenseSearch] = useState('');
    const [expenseSelected, setExpenseSelected] = useState([]);
    const [expenseFlatList, setExpenseFlatList] = useState([]);
    const [form, setForm] = useState({
        clientId: "",
        projectId: "",
        date: new Date(),
        merchant: "",
        catagory: "",
        rate: "",
        type: "Goods",
        SAC: "",
        HSN: "",
        status: 1,
    });
    const [showAddMoreExpenseModal, setShowAddMoreExpenseModal] = useState(false);
    const [addMoreExpenseError, setAddMoreExpenseErrors] = useState({})
    const [showCalendarExpenseStart, setShowCalendarExpenseStart] = useState(false);
    const [projects, setProjects] = useState([]);
    const [loadingProjects, setLoadingProjects] = useState(false);

    // Time Entry Modal
    const [showTimeEntryModal, setShowTimeEntryModal] = useState(false);
    const [timeEntryList, setTimeEntryList] = useState([]);
    const [timeEntrySelected, setTimeEntrySelected] = useState([]);
    const [timeEntrySearch, setTimeEntrySearch] = useState('');
    const [timeEntryFlatList, setTimeEntryFlatList] = useState([]);
    const [allTimeEntries, setAllTimeEntries] = useState([]);
    const [addMoreLog, setAddMoreLog] = useState({
        client_id: selectedClient?.id, start_time: new Date(), end_time: new Date(), notes: ""
    })
    const [addMoretime, setAddMoreTime] = useState(false)
    // PDF preview state for Send tab
    const [previewPdfFile, setPreviewPdfFile] = useState(null);


    //Email state
    const [sendToEmails, setSendToEmails] = useState(selectedClient?.email ? [selectedClient.email] : []);
    const [sendCcEmails, setSendCcEmails] = useState([]);
    const [sendBccEmails, setSendBccEmails] = useState([]);
    const [showCc, setShowCc] = useState(false);
    const [showBcc, setShowBcc] = useState(false);
    const [sendToInput, setSendToInput] = useState('');
    const [sendCcInput, setSendCcInput] = useState('');
    const [sendBccInput, setSendBccInput] = useState('');
    const [sendNotes, setSendNotes] = useState('');
    const [saveInvoiceLoading, setSaveInvoiceLoading] = useState(false)
    // --- PDF Generation ---
    const previewRef = useRef();

    // async function generatePreviewPdf() {
    //     if (!previewRef.current) return;
    //     const element = previewRef.current;
    //     console.log(element, "element")
    //     setPreviewPdfFile(element);
    // }

    useEffect(() => {
        // if(tab === "Send" )
        if (!previewRef.current) return;
        const element = previewRef.current;
        // console.log(element, "element")
        setPreviewPdfFile(element);
    }, [previewRef, activeTab])

    useEffect(() => {
        async function fetchData() {
            try {
                const data = await dispatch(fetchMasterData()).unwrap();
                setUnitTypes(data.productUnitTypes || []);
                setCurrencyList(data.currencyData || []);
            } catch (err) {
                console.error("Failed to fetch master data", err);
            }
        }
        fetchData();
    }, [dispatch]);

    // Download PDF
    const handleDownloadPdf = () => {
        // console.log("previewRef", previewRef, previewRef?.current);
        // return;

        // if (!previewPdfFile && !previewRef.current) return;

        // const element = previewPdfFile || previewRef.current;
        const element = previewRef?.current;

        if (!element) return

        // Remove display: none if present, but remember previous state
        // let wasHidden = false;
        // if (element && element.style && element.style.display === 'none') {
        //     element.style.display = '';
        //     wasHidden = true;
        // }

        const options = {
            margin: 0,
            filename: `Invoice_${invoiceNumber || 'preview'}.pdf`,
            image: { type: 'png', quality: 1.0 },
            html2canvas: {
                scale: 3,
                useCORS: true,
                backgroundColor: '#ffffff',
            },
            jsPDF: { unit: 'pt', format: 'a4', orientation: 'portrait' },
        };

        html2pdf()
            .set(options)
            .from(element)
            .save()
            .catch((err) => {
                console.error('PDF generation failed:', err);
            })
            .finally(() => {
                // Restore display: none if it was hidden before
                // if (wasHidden && element && element.style) {
                //     element.style.display = 'none';
                // }
            });
    }

    const handleBackClick = () => {
        setShowChooseItemModal(false);
        setShow(true);
    };

    const handleTimeEntryBackClick = () => {
        setAddMoreTime(false);
        setShowTimeEntryModal(true);
    };

    const handleExpenseBackClick = () => {
        setShowAddMoreExpenseModal(false);
        setShowExpenseModal(true);
    };

    const handleAppointmentBackClick = () => {
        setShowAddMoreAppointmentModal(false);
        setShowAppointmentModal(true);
    };


    // Add/Remove email chips
    function handleAddEmail(type, value) {
        const email = value.trim();
        if (!email) return;
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return;
        if (type === 'to') {
            if (!sendToEmails.includes(email)) setSendToEmails([...sendToEmails, email]);
            setSendToInput('');
        } else if (type === 'cc') {
            if (!sendCcEmails.includes(email)) setSendCcEmails([...sendCcEmails, email]);
            setSendCcInput('');
        } else if (type === 'bcc') {
            if (!sendBccEmails.includes(email)) setSendBccEmails([...sendBccEmails, email]);
            setSendBccInput('');
        }
    }
    function handleRemoveEmail(type, idx) {
        if (type === 'to') setSendToEmails(sendToEmails.filter((_, i) => i !== idx));
        if (type === 'cc') setSendCcEmails(sendCcEmails.filter((_, i) => i !== idx));
        if (type === 'bcc') setSendBccEmails(sendBccEmails.filter((_, i) => i !== idx));
    }
    function handleEmailInputKeyDown(e, type) {
        if (e.key === 'Enter' || e.key === ',' || e.key === 'Tab') {
            e.preventDefault();
            if (type === 'to') handleAddEmail('to', sendToInput);
            if (type === 'cc') handleAddEmail('cc', sendCcInput);
            if (type === 'bcc') handleAddEmail('bcc', sendBccInput);
        }
    }


    const [unsaved, setUnsaved] = useState(false);
    const [modalType, setModalType] = useState('reload');
    const [showModal, setShowModal] = useState(false);
    // Activate confirmation only when unsaved changes exist
    useRouteLeaveConfirmation(unsaved, 'You have unsaved changes. Leave anyway?');
    // --- Unsaved Changes Protection ---
    // --- Unsaved Changes Protection ---
    useEffect(() => {
        // don't run protection for edit mode
        if (invoiceId) return;

        if (!clientId) {
            const hasUnsavedChanges =
                Boolean(clientForm.name) ||
                Boolean(clientForm.email) ||
                Boolean(clientForm.phone) ||
                Boolean(clientForm.address) ||
                items.length > 0 ||
                Boolean(comment);
            setUnsaved(hasUnsavedChanges);
        } else {
            setUnsaved(false);
        }
    }, [clientForm, items, comment, clientId, invoiceId]);

    useEffect(() => {
        if (invoiceId) return;

        const handleBeforeUnload = (e) => {
            if (!clientId && unsaved) {
                e.preventDefault();
                e.returnValue = '';
                setModalType('close');
                setShowModal(true);
                return '';
            }
        };
        window.addEventListener('beforeunload', handleBeforeUnload);
        return () => window.removeEventListener('beforeunload', handleBeforeUnload);
    }, [unsaved, clientId, invoiceId]);

    useEffect(() => {
        if (invoiceId) return;

        const handleKeyDown = (e) => {
            const key = e.key ? e.key.toLowerCase() : '';
            if (!clientId && unsaved && (key === 'f5' || (e.ctrlKey && key === 'r'))) {
                e.preventDefault();
                setModalType('reload');
                setShowModal(true);
            }
        };
        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, [unsaved, clientId, invoiceId]);

    // Update sendToEmails when selectedClient changes
    useEffect(() => {
        if (selectedClient?.email) setSendToEmails([selectedClient.email]);
    }, [selectedClient]);

    // Send PDF via email
    async function handleSendPdf() {
        if (!previewPdfFile && !previewRef.current) return;
        if (sendToEmails.length === 0) {
            toast.error("Please enter recipient email address.");
            return;
        }
        const element = previewPdfFile || previewRef.current;
        // Remove display: none if present
        // if (element && element.style && element.style.display === 'none') {
        //     element.style.display = '';
        // }
        let htmlContent = "";
        if (element && element.outerHTML) {
            htmlContent = element.outerHTML;
        } else if (element && element.current && element.current.outerHTML) {
            htmlContent = element.current.outerHTML;
        }

        htmlContent = htmlContent.replace(/<img([^>]+)src=["']data:image\/[^"']+["']([^>]*)>/gi, '');

        const body = {
            to: sendToEmails,
            cc: sendCcEmails,
            bcc: sendBccEmails,
            invoiceNumber,
            name: 'Invoice',
            filename: 'Invoice.pdf',
            subject: `Invoice from RaiseInvoice #${invoiceNumber}`,
            notes: sendNotes,
            html: htmlContent,
            attachments: attachments
        };
        if (parameter?.attachmentName) {
            await fetchBlobAsBase64(parameter?.blobUrl).then((base64Data) => {
                body.content = base64Data.replace(/^data:application\/pdf;base64,/, '')
                body.filename = parameter?.attachmentName;
            });
        }

        let formData = new FormData();
        for (let [key, val] of Object.entries(body)) {
            // If value is array, append each value
            if (Array.isArray(val)) {
                val.forEach(v => formData.append(key, v));
            } else {
                formData.append(key, val);
            }
        }
        try {
            const result = await dispatch(sendMail(formData)).unwrap();
            if (result && result.status == true) {
                setSentStatus("sent");
                toast.success("Invoice sent successfully!");
            } else {
                toast.error("Failed to send invoice.");
            }
        } catch (err) {
            toast.error("Failed to send invoice.");
        }
    }

    const [showContactsDropdown, setShowContactsDropdown] = useState(false);
    const contactsDropdownRef = useRef();
    const toggleRef = useRef();

    useEffect(() => {
        function handleClickOutside(event) {
            if (
                showContactsDropdown &&
                contactsDropdownRef.current &&
                toggleRef.current &&
                !contactsDropdownRef.current.contains(event.target) &&
                !toggleRef.current.contains(event.target)
            ) {
                setShowContactsDropdown(false);
            }
        }
        if (showContactsDropdown) {
            document.addEventListener("mousedown", handleClickOutside);
        }
        return () => {
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, [showContactsDropdown]);

    // --- Add More Appointment Modal State ---
    const [showAddMoreAppointmentModal, setShowAddMoreAppointmentModal] = useState(false);
    const [addMoreAppointment, setAddMoreAppointment] = useState({
        notes: '',
        start_date: '',
        start_time: '',
        end_date: '',
        end_time: '',
        contact_id: '',
        contacts: []
    });
    const [addMoreAppointmentLoading, setAddMoreAppointmentLoading] = useState(false);
    const [addMoreAppointmentErrors, setAddMoreAppointmentErrors] = useState({});

    // --- Add More Appointment Modal Handlers ---
    const handleAddMoreAppointmentOpen = async () => {
        setAddMoreAppointment({
            notes: '',
            start_date: '',
            start_time: '',
            end_date: '',
            end_time: '',
            contact_id: '',
            contacts: []
        });
        setShowAppointmentModal(false);
        setAddMoreAppointmentErrors({});
        setShowAddMoreAppointmentModal(true);
        // Fetch contacts
        try {
            const result = await dispatch(getContactsForAppointment()).unwrap();
            setAddMoreAppointment(prev => ({
                ...prev,
                contacts: result.data || []
            }));
        } catch (e) {
            setAddMoreAppointment(prev => ({ ...prev, contacts: [] }));
        }
    };
    const handleAddMoreAppointmentClose = () => setShowAddMoreAppointmentModal(false);

    const handleAddMoreAppointmentChange = (e) => {
        const { name, value } = e.target;
        setAddMoreAppointment(prev => ({ ...prev, [name]: value }));
        setAddMoreAppointmentErrors(prev => ({ ...prev, [name]: undefined }));
    };
    const validateAddMoreAppointment = () => {
        const errors = {};
        // if (!selectedClient?.id) {
        //     errors.client = "Please select a client.";
        // }
        if (!addMoreAppointment.notes) {
            errors.notes = "Notes are required.";
        }
        if (!addMoreAppointment.start_date) {
            errors.start_date = "Start date is required.";
        }
        if (!addMoreAppointment.start_time) {
            errors.start_time = "Start time is required.";
        }
        if (!addMoreAppointment.end_date) {
            errors.end_date = "End date is required.";
        }
        if (!addMoreAppointment.end_time) {
            errors.end_time = "End time is required.";
        }
        return errors;
    };
    const handleAddMoreAppointmentAdd = async () => {
        const { contact_id, notes, start_date, start_time, end_date, end_time } = addMoreAppointment;

        const errors = validateAddMoreAppointment();
        setAddMoreAppointmentErrors(errors);
        if (Object.keys(errors).length > 0) return;
        setAddMoreAppointmentLoading(true);
        try {
            const payload = {
                client_id: selectedClient?.id,
                contact_ids: contact_id || undefined,
                start_date,
                start_time,
                end_date,
                end_time,
                notes
            };
            const result = await dispatch(createAppointmentData(payload)).unwrap();
            if (result && result.data) {
                const getDatePart = (isoString) => isoString ? isoString.split('T')[0] : '';
                const startDate = getDatePart(result.data.start_date);
                const endDate = getDatePart(result.data.end_date);
                const start = new Date(`${startDate}T${result.data.start_time}`);
                const end = new Date(`${endDate}T${result.data.end_time}`);
                const options = { weekday: 'long', month: 'short', day: 'numeric', year: 'numeric' };
                const dateStr = start.toLocaleDateString(undefined, options);
                const startTime = start.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                const endTime = end.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                setItems(items => [
                    ...items,
                    {
                        id: null,
                        drag_id: `${items?.length + items?.length}`,
                        code: '',
                        name: `${dateStr}, ${startTime} - ${endTime}`,
                        description: '',
                        rate: '',
                        quantity: '',
                        gstChecked: false,
                        gstValue: '',
                        discountChecked: false,
                        discountType: 'flat',
                        discountValue: '',
                        isAppointment: true,
                        appointmentId: result.data.id,
                        _originalAppointment: result.data
                    }
                ]);
                setShowAddMoreAppointmentModal(false);
            } else {
                setAddMoreAppointmentErrors({ form: "Failed to add appointment." });
            }
        } catch (err) {
            setAddMoreAppointmentErrors({ form: "Failed to add appointment." });
        } finally {
            setAddMoreAppointmentLoading(false);
        }
    };

    // --- Time Entry Modal Logic ---
    const handleAddTimeEntryOpen = async () => {
        setShowTimeEntryModal(true);
        setTimeEntrySearch('');
        setTimeEntrySelected([]);
        const result = await dispatch(getLog());
        let logs = [];
        if (result && result.payload && Array.isArray(result.payload.data)) {
            logs = result.payload.data;
        }
        const grouped = {};
        const ungrouped = [];
        logs.forEach(log => {
            if (log.task_id) {
                if (!grouped[log.task_id]) grouped[log.task_id] = [];
                grouped[log.task_id].push(log);
            } else {
                ungrouped.push(log);
            }
        });
        const groupedList = Object.values(grouped).map(group => {
            let totalSeconds = 0;
            group.forEach(log => {
                let diff = log.timeDifference;
                if (diff) {
                    const [h, m, s] = diff.split(':').map(Number);
                    totalSeconds += (h || 0) * 3600 + (m || 0) * 60 + (s || 0);
                } else if (log.start_time && log.end_time) {
                    const [startH, startM] = log.start_time.split(':').map(Number);
                    const [endH, endM] = log.end_time.split(':').map(Number);
                    const start = (startH || 0) * 60 + (startM || 0);
                    const end = (endH || 0) * 60 + (endM || 0);
                    totalSeconds += Math.max(0, (end - start) * 60);
                }
            });
            const hours = Math.floor(totalSeconds / 3600);
            const minutes = Math.floor((totalSeconds % 3600) / 60);
            const totalTime = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
            const first = group[0];
            return {
                task_id: first.task_id,
                project_id: first.project_id,
                client_id: first.client_id,
                client_name: first.client_name,
                logs: group,
                totalTime,
                projectName: first.project_name || '',
                taskName: first.task_name || '',
                taskDescription: first.task_description || '',
            };
        });
        const ungroupedList = ungrouped.map(log => {
            let totalSeconds = 0;
            let diff = log.timeDifference;
            if (diff) {
                const [h, m, s] = diff.split(':').map(Number);
                totalSeconds += (h || 0) * 3600 + (m || 0) * 60 + (s || 0);
            } else if (log.start_time && log.end_time) {
                const [startH, startM] = log.start_time.split(':').map(Number);
                const [endH, endM] = log.end_time.split(':').map(Number);
                const start = (startH || 0) * 60 + (startM || 0);
                const end = (endH || 0) * 60 + (endM || 0);
                totalSeconds += Math.max(0, (end - start) * 60);
            }
            const hours = Math.floor(totalSeconds / 3600);
            const minutes = Math.floor((totalSeconds % 3600) / 60);
            const totalTime = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
            return {
                task_id: null,
                project_id: log.project_id,
                client_id: log.client_id,
                client_name: log.client_name,
                logs: [log],
                totalTime,
                projectName: log.project_name || '',
                taskName: log.task_name || '',
                taskDescription: log.task_description || '',
            };
        });
        setAllTimeEntries([...groupedList, ...ungroupedList]);
    };

    const [sigInvoice, setSignatureInvoice] = useState(true);
    const [error, setError] = useState({});

    // Signature states
    const [signatureType, setSignatureType] = useState("pad");
    const [padSignature, setPadSignature] = useState("");
    const [uploadSignature, setUploadSignature] = useState("");
    const [signatureText, setSignatureText] = useState("");

    useEffect(() => {
        const fetchSignature = async () => {
            try {
                const result = await dispatch(getInvoiceSignature()).unwrap();
                if (result && result.data) {
                    const data = result.data;
                    setSignatureInvoice(data.invoice);
                    setSignatureType(data.signatureType || "pad");
                    setPadSignature(data.signature || "");
                    setUploadSignature(data.signatureData || "");
                    setSignatureText(data.signatureText || "");
                }
            } catch (err) {
                // No existing signature, keep defaults
            }
        };
        fetchSignature();
    }, [dispatch]);

    useEffect(() => {
        setTimeEntryFlatList(
            allTimeEntries.filter(
                entry => !items.some(i => i.isTimeEntry && (
                    (i.timeEntryTaskId && i.timeEntryTaskId === entry.task_id) ||
                    (!i.timeEntryTaskId && entry.task_id === null && i._originalTimeEntry && i._originalTimeEntry.logs && entry.logs && i._originalTimeEntry.logs[0]?.id === entry.logs[0]?.id)
                ))
            )
        );
    }, [allTimeEntries, items]);

    const handleTimeEntryModalClose = () => {
        setShowTimeEntryModal(false);
        setTimeEntrySearch('');
        setTimeEntrySelected([]);
        setAddMoreTime(false);
    };

    const handleTimeEntryToggle = (entry) => {
        setTimeEntrySelected(prev => {
            const exists = prev.find(e => e.task_id === entry.task_id && e.project_id === entry.project_id && e.client_id === entry.client_id && (!entry.task_id ? (e.logs[0]?.id === entry.logs[0]?.id) : true));
            if (exists) {
                return prev.filter(e => !(e.task_id === entry.task_id && e.project_id === entry.project_id && e.client_id === entry.client_id && (!entry.task_id ? (e.logs[0]?.id === entry.logs[0]?.id) : true)));
            } else {
                return [...prev, entry];
            }
        });
    };
    const handleTimeEntryAdd = async (e) => {
        e.preventDefault();
        if (addMoretime) {
            if (!selectedClient?.id) {
                toast.error("Please Select client.");
                return;
            }
            if (addMoreLog.end_time - addMoreLog.start_time < 0) {
                toast.error("End time should not be earlier than start time.");
                return;
            }
            let payload = { ...addMoreLog };
            payload = { ...payload, start_time: format(addMoreLog?.start_time, 'HH:mm') };
            payload = { ...payload, end_time: format(addMoreLog?.end_time, 'HH:mm') };
            payload = { ...payload, client_id: selectedClient?.id };
            await dispatch(saveTimeAPI(payload)).unwrap();
            setShowTimeEntryModal(false);
            const minutes = differenceInMinutes(addMoreLog.end_time, addMoreLog.start_time);
            const hours = Math.floor(minutes / 60);
            const mins = minutes % 60;
            const diffTimeFormat = `${String(hours).padStart(2, "0")}:${String(mins).padStart(2, "0")}`;
            setItems([...items, {
                id: null,
                drag_id: `${items?.length + items?.length}`,
                name: `${selectedClient?.name}-${diffTimeFormat}`,
                description: payload.notes || '',
                rate: '',
                quantity: '',
                gstChecked: false,
                gstValue: '',
                discountChecked: false,
                discountType: 'flat',
                discountValue: '',
                isTimeEntry: true,
                timeEntryTaskId: "",
                _originalTimeEntry: {}
            }]);
            setAddMoreTime(false);
            return;
        }
        const newItems = timeEntrySelected.map((entry, indx) => ({
            id: null,
            code: '',
            drag_id: `${items?.length + indx}`,
            name: `${entry.projectName ? entry.projectName : selectedClient?.name} - ${entry.taskName ? entry.taskName + " - " : ''}  ${entry.totalTime}`,
            description: entry.taskDescription || '',
            rate: '',
            quantity: '',
            gstChecked: false,
            gstValue: '',
            discountChecked: false,
            discountType: 'flat',
            discountValue: '',
            isTimeEntry: true,
            timeEntryTaskId: entry.task_id,
            _originalTimeEntry: entry
        }));
        setItems([...items, ...newItems]);
        setShowTimeEntryModal(false);
    };

    const filteredTimeEntryList = timeEntryFlatList.filter(entry => {
        return (
            (entry.projectName || '').toLowerCase().includes(timeEntrySearch.toLowerCase()) ||
            (entry.taskName || '').toLowerCase().includes(timeEntrySearch.toLowerCase()) ||
            (entry.taskDescription || '').toLowerCase().includes(timeEntrySearch.toLowerCase()) ||
            ((entry.start_time) &&
                (entry.end_time))
        );
    });

    function handleAddDepositOpen() {
        setShowDepositModal(true);
        if (deposit) {
            setDepositTab(deposit.type);
            setDepositPercentage(deposit.percentage || '');
            setDepositFixedAmount(deposit.amount || '');
            setDepositDueDate(deposit.dueDate || format(new Date(), 'yyyy-MM-dd'));
            setDepositAddToFuture(deposit.addToFuture || false);
            setDepositPaid(deposit.paid || 0);
        } else {
            setDepositTab('percent');
            setDepositPercentage('');
            setDepositFixedAmount('');
            setDepositDueDate(format(new Date(), 'yyyy-MM-dd'));
            setDepositAddToFuture(false);
            setDepositPaid(0);
        }
    }
    function handleDepositClose() {
        setShowDepositModal(false);
    }
    function handleDepositSave() {
        let amount = depositTab === 'percent'
            ? Math.round((total * depositPercentage) / 100)
            : Number(depositFixedAmount);
        setDeposit({
            type: depositTab,
            percentage: depositTab === 'percent' ? depositPercentage : null,
            amount,
            dueDate: depositDueDate,
            addToFuture: depositAddToFuture,
            paid: depositPaid
        });
        setShowDepositModal(false);
    }
    function handleDepositCancel() {
        setDeposit(null);
        setShowDepositModal(false);
    }

    // Fetch invoice details if editing
    useEffect(() => {
        if (invoiceId || copyId) {

            setIsUpdateMode(true);
            dispatch(detailsInvoiceData({ id: invoiceId ? invoiceId : copyId })).then(result => {
                const data = result?.payload?.data;
                if (data) {
                    setInvoiceNumber(data.invoice.invoiceNumber || data.invoice.id || '');
                    setInvoiceNumberInput(data.invoice.invoiceNumber || data.invoice.id || '');
                    if (invoiceId || parameter?.client) setSelectedClient(data.client || null);
                    if (invoiceId || parameter?.client)
                        setClientForm({
                            id: data.client?.id || null,
                            name: data.client?.name || '',
                            email: data.client?.email || '',
                            phone: data.client?.phone || '',
                            address: data.client?.address || ''
                        })
                    let parsedItems = [];
                    if ((invoiceId || parameter?.items) && Array.isArray(data.items)) {
                        parsedItems = data.items.map((item, indx) => ({
                            id: item.id || null,
                            code: item.code || '',
                            name: item.name || '',
                            description: item.description || '',
                            rate: item.rate || '',
                            quantity: item.quantity || '',
                            unitTypes: item.unitTypes || '',
                            gstChecked: item.gstChecked || false,
                            gstValue: item.gstValue || '',
                            discountChecked: item.discountChecked || false,
                            discountType: item.discountType || 'flat',
                            discountValue: item.discountValue || '',
                            isAppointment: item.isAppointment || false,
                            appointmentId: item.appointmentId || null,
                            isTimeEntry: item.isTimeEntry || false,
                            timeEntryTaskId: item.timeEntryTaskId || null,
                            drag_id: item?.drag_id || `${items?.length + indx}`,
                            _originalTimeEntry: item._originalTimeEntry || {}
                        }));
                    }
                    if (data.customInvoice) {
                        setFormData({
                            id: data.customInvoice.id || null,
                            templateName: data.customInvoice?.templateName || "impact",
                            logoId: data.customInvoice?.logoId || "",
                            logoImage: data.customInvoice?.logoImage || "",
                            logoSize: data.customInvoice?.logoSize || "medium",
                            logoPosition: data.customInvoice?.logoPosition || "center",
                            colourId: data.customInvoice?.colourId || "",
                            colourCode: data.customInvoice?.colourCode || "",
                            customColour: data.customInvoice?.customColour || "",
                            headerId: data.customInvoice?.headerId || "",
                            headerImg: data.customInvoice?.headerImg || "",
                            waterMarkId: data.customInvoice?.waterMarkId || "",
                            waterMarkImg: data.customInvoice?.waterMarkImg || "",
                        });
                    }
                    if (data.customInvoiceOption) {
                        setOptionData({
                            id: data.customInvoiceOption?.id || null,
                            shippingDetails: !!data.customInvoiceOption?.shippingDetails,
                            due_date: !!data.customInvoiceOption?.due_date,
                            payment_terms: !!data.customInvoiceOption?.payment_terms,
                            itemCode: !!data.customInvoiceOption?.itemCode,
                            quantityAndRate: !!data.customInvoiceOption?.quantityAndRate,
                            pTax: !!data.customInvoiceOption?.pTax,
                            tax_amounts: !!data.customInvoiceOption?.tax_amounts,
                            includeSignatureLine: !!data.customInvoiceOption?.includeSignatureLine,
                            invoicePrifix: data.customInvoiceOption?.invoicePrifix || "",
                        });
                    }
                    setItems(parsedItems);
                    setInvoiceDate(data.invoice.date ? new Date(data.invoice.date) : new Date());
                    setTerms(data.invoice.term || "");
                    setDueDate(data.invoice.dueDate ? new Date(data.invoice.dueDate) : new Date());
                    setInvoiceGstRate(null);
                    setInvoiceGstType("Exclusive");
                    setInvoiceDiscount(data.invoice.discount || '');
                    setDiscountAmount(data.invoice.discount || '');
                    setAttachments(data.attachments || []);
                    if (invoiceId || parameter?.attachment) setLogo(data.invoice.logo || '');
                    setPaymentInstruction(data.invoice.paymentInstruction || '');
                    setComment(data.invoice.comment || '');
                    setDeposit(data.deposit?.amount ? data.deposit : null || null);
                }
            });
        } else if (clientId) {
            setIsUpdateMode(false);
            dispatch(fetchNextInvoiceNumber()).then(result => {
                let nextNum = result?.payload?.data?.nextInvoiceNumber || '';
                if (typeof nextNum === 'number' || /^\d+$/.test(nextNum)) {
                    nextNum = String(nextNum).padStart(3, '0');
                }
                setInvoiceNumber(nextNum);
                setInvoiceNumberInput(nextNum);
            });
            dispatch(deatilsClientData(clientId)).then(result => {
                const data = result?.payload;
                const profileImage = process.env.NEXT_PUBLIC_API_URL + 'uploads/' + (data.profileImage || '');
                if (data) {
                    setSelectedClient({ ...data , profileImage } || null);
                    setClientForm({
                        id: data.id || null,
                        name: data.name || '',
                        email: data.email || '',
                        phone: data.phone || '',
                        address: data.address || ''
                    });
                }
            });
            setItems([]);
            setInvoiceDate(new Date());
            setTerms("");
            setDueDate(new Date());
            setInvoiceGstRate(null);
            setInvoiceGstType("Exclusive");
            setInvoiceDiscount('');
            setAttachments([]);
            setLogo('');
            setPaymentInstruction('');
            setComment('');
            setDeposit(null);
        } else {
            setIsUpdateMode(false);
            dispatch(fetchNextInvoiceNumber()).then(result => {
                let nextNum = result?.payload?.data?.nextInvoiceNumber || '';
                if (typeof nextNum === 'number' || /^\d+$/.test(nextNum)) {
                    nextNum = String(nextNum).padStart(3, '0');
                }
                setInvoiceNumber(nextNum);
                setInvoiceNumberInput(nextNum);
            });
            setSelectedClient(null);
            setClientForm({ id: null, name: '', email: '', phone: '', address: '' });
            setItems([]);
            setInvoiceDate(new Date());
            setTerms("");
            setDueDate(new Date());
            setInvoiceGstRate(null);
            setInvoiceGstType("Exclusive");
            setInvoiceDiscount('');
            setAttachments([]);
            setLogo('');
            setPaymentInstruction('');
            setComment('');
            setDeposit(null);
        }
    }, [invoiceId]);

    useEffect(() => {
        if (invoiceId || clientId) return;
        dispatch(getCustomInvoiceData()).then((res) => {
            const data = res?.payload?.data;
            if (data) {
                setFormData({
                    id: data.id || null,
                    templateName: data.templateName || "impact",
                    logoId: data.logoDetails?.id || "",
                    logoImage: data.logoDetails?.logoImage || "",
                    logoSize: data.logoSize || "medium",
                    logoPosition: data.logoPosition || "center",
                    colourId: data.colourDetails?.id || "",
                    colourCode: data.colourDetails?.colourCode || "",
                    customColour: data.colourDetails?.customColour || "",
                    headerId: data.headerDetails?.id || "",
                    headerImg: data.headerDetails?.headerImg || "",
                    waterMarkId: data.waterMarkDetails?.id || "",
                    waterMarkImg: data.waterMarkDetails?.waterMarkImg || "",
                });
                setCustomTemplates(res?.payload);
            }
        });
        dispatch(getCustomInvoiceOptionData()).then((res) => {
            const data = res?.payload?.data;
            if (data) {
                setOptionData({
                    id: data.id || null,
                    shippingDetails: !!data.shippingDetails,
                    due_date: !!data.due_date,
                    payment_terms: !!data.payment_terms,
                    itemCode: !!data.itemCode,
                    quantityAndRate: !!data.quantityAndRate,
                    pTax: !!data.pTax,
                    tax_amounts: !!data.tax_amounts,
                    includeSignatureLine: !!data.includeSignatureLine,
                    invoicePrifix: data.invoicePrifix || "",
                });
            }
        });
    }, [dispatch]);

    useEffect(() => {
        const selectedTerm = TERMS_OPTIONS.find(opt => opt.value === terms);
        if (selectedTerm && selectedTerm.value !== "1" && selectedTerm.days > 0) {
            setDueDate(addDays(invoiceDate, selectedTerm.days));
        } else if (selectedTerm && selectedTerm.value !== "1") {
            setDueDate(invoiceDate);
        }
    }, [invoiceDate, terms]);

    useEffect(() => {
        if (items?.some(item => (item?.discountChecked == 'true' || item?.discountChecked == true))) {
            setInvoiceDiscountEditable(false);
        } else {
            setInvoiceDiscountEditable(true);
        }
    }, [items]);

    // Subtotal, GST, Discount, Total calculations
    let subtotal = 0, gstTotal = 0, discountTotal = 0, total = 0;
    const hasItemLevelGst = items.some(item => item.gstChecked == 'true' || item.gstChecked == true);

    function getItemBaseAndGst(item) {
        const itemTotal = parseFloat(item.rate || 0) * parseFloat(item.quantity || 0);

        // Calculate discount first
        let discountedTotal = itemTotal;
        if (item.discountChecked == 'true' || item.discountChecked == true) {
            if (item.discountType === "percentage") {
                discountedTotal = itemTotal - (itemTotal * (parseFloat(item.discountValue || 0) / 100));
            } else {
                discountedTotal = itemTotal - parseFloat(item.discountValue || 0);
            }
        }

        // Then calculate GST
        if (item.gstChecked == 'true' || item.gstChecked == true && item.gstValue) {
            const gstPerc = parseFloat(item.gstValue || 0);
            if (invoiceGstType === "Inclusive") {
                const base = discountedTotal / (1 + gstPerc / 100);
                const gst = discountedTotal - base;
                return { base, total: discountedTotal, gst };
            } else {
                const gst = discountedTotal * (gstPerc / 100);
                return { base: discountedTotal, gst, total: discountedTotal + gst };
            }
        } else {
            return { base: discountedTotal, gst: 0, total: discountedTotal };
        }
    }

    function getInvoiceGst(baseTotal) {
        if (!invoiceGstRate || !invoiceGstRate.percentage) return { base: baseTotal, gst: 0, total: baseTotal };
        const gstPerc = parseFloat(invoiceGstRate.percentage);
        if (invoiceGstType === "Inclusive") {
            const base = baseTotal / (1 + gstPerc / 100);
            const gst = baseTotal - base;
            return { base, gst, total: baseTotal };
        } else {
            const gst = baseTotal * (gstPerc / 100);
            return { base: baseTotal, gst, total: baseTotal + gst };
        }
    }

    if (hasItemLevelGst) {
        // Calculate item-level GST
        subtotal = items.reduce((sum, item) => {
            const { base } = getItemBaseAndGst(item);
            return sum + base;
        }, 0);

        gstTotal = items.reduce((sum, item) => {
            const { gst } = getItemBaseAndGst(item);
            return sum + gst;
        }, 0);

        discountTotal = 0;
        if (invoiceDiscountEditable || invoiceId) {
            discountTotal = parseFloat(invoiceDiscount || 0);
        }


        total = subtotal + gstTotal - discountTotal;
    } else {
        // Calculate invoice-level GST
        subtotal = items.reduce((sum, item) => {
            const itemTotal = parseFloat(item.rate || 0) * parseFloat(item.quantity || 0);

            // Apply item-level discount if any
            if (item.discountChecked == 'true' || item.discountChecked == true) {
                if (item.discountType === "percentage") {
                    return sum + (itemTotal - (itemTotal * (parseFloat(item.discountValue || 0) / 100)));
                } else {
                    return sum + (itemTotal - parseFloat(item.discountValue || 0));
                }
            }

            return sum + itemTotal;
        }, 0);

        if (invoiceDiscountEditable || invoiceId) {
            discountTotal = parseFloat(invoiceDiscount || 0);
        } else {

            discountTotal = items.reduce((sum, item) => {
                const itemTotal = parseFloat(item.rate || 0) * parseFloat(item.quantity || 0);
                if (item.discountChecked == 'false' || item.discountChecked == false) return sum;
                if (item.discountType === "percentage") {
                    return sum + (itemTotal * (parseFloat(item.discountValue || 0) / 100));
                } else {
                    return sum + parseFloat(item.discountValue || 0);
                }
            }, 0);
        }

        const gstResult = getInvoiceGst(subtotal);
        gstTotal = gstResult.gst;
        total = gstResult.total - discountTotal;
    }

    // Open Discount Modal
    const handleOpenDiscountModal = () => {
        setDiscountInputValue(discountType === "%" ? "" : discountAmount.toString());
        setDiscountModalOpen(true);
        setInvoiceDiscountEditable(true);
    };

    // Save Discount from Modal
    const handleSaveDiscount = () => {
        let discValue = parseFloat(discountInputValue) || 0;
        let discAmount = 0;
        if (discountType === "%") {
            discAmount = subtotal * (discValue / 100);
        } else {
            discAmount = discValue;
        }
        setDiscountAmount(discAmount);
        setInvoiceDiscount(discAmount.toFixed(2));
        setDiscountModalOpen(false);
    };

    // Handlers
    const handleBack = () => router.push('/invoice');

    // Client Modal
    const handleShowClientModal = async () => {
        setShowClientModal(true);
        const result = await dispatch(fetchClientData());
        if (result && result.payload && result.payload.data) {
            setClientList(result.payload.data);
            setClientDropdown(result.payload.data);
            setShowClientDropdown(true);
        }
        setClientForm({ id: null, name: '', email: '', phone: '', address: '' });
        setClientFormErrors({ name: '', email: '', phone: '' });
    };
    const handleCloseClientModal = () => {
        setShowClientModal(false);
        setShowClientDropdown(false);
        setClientDropdown([]);
        setClientForm({ id: null, name: '', email: '', phone: '', address: '' });
        setClientFormErrors({ name: '', email: '', phone: '' });
    };
    const handleClearClient = () => {
        setSelectedClient(null);
        setClientForm({ id: null, name: '', email: '', phone: '', address: '' });
        setClientFormErrors({ name: '', email: '', phone: '' });
    };

    const validateClientForm = (field, value) => {
        let error = "";
        if (field === "name") {
            if (!value.trim()) error = "Name is required";
        }
        if (field === "email") {
            if (!value.trim()) error = "Email is required";
            else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) error = "Invalid email";
        }
        if (field === "phone") {
            if (!value.trim()) error = "Phone is required";
            else if (!/^\d{10}$/.test(value.replace(/\D/g, ""))) error = "Phone must be 10 digits";
        }
        return error;
    };

    const validateItemForm = (field, value) => {
        let error = "";
        const val = (value === undefined || value === null) ? "" : String(value);
        if (field === "name") {
            if (!val.trim()) error = "Name is required";
        }
        if (field === "rate") {
            if (!val.trim()) error = "Rate is required";
            else if (isNaN(val) || parseFloat(val) <= 0) error = "Rate must be positive";
        }
        if (field === "quantity") {
            if (!val.trim()) error = "Qty is required";
            else if (!/^\d+$/.test(val) || parseInt(val) < 1) error = "Qty must be at least 1";
        }
        return error;
    };

    const handleClientFormChange = (e) => {
        const { name, value } = e.target;
        let v = value;
        if (name === "phone") {
            v = v.replace(/\D/g, "").slice(0, 10);
        }
        setClientForm((prev) => ({
            ...prev,
            [name]: v,
        }));
        setClientFormErrors((prev) => ({
            ...prev,
            [name]: validateClientForm(name, v),
        }));
        if (name === "name") {
            if (v.trim().length > 0) {
                const filtered = clientList.filter((client) =>
                    client.name?.toLowerCase().includes(v.toLowerCase())
                );
                setClientDropdown(filtered);
                setShowClientDropdown(true);
            } else {
                setShowClientDropdown(true);
                setClientDropdown(clientList);
            }
        }
    };

    const [itemFormErrors, setItemFormErrors] = useState({
        name: "",
        rate: "",
        quantity: "",
    });

    const handleClientDropdownSelect = (client) => {
        setClientForm({
            id: client.id || null,
            name: client.name || '',
            email: client.email || '',
            phone: client.phone || '',
            address: client.address || ''
        });
        setShowClientDropdown(false);
        setClientDropdown([]);
        setClientFormErrors({ name: '', email: '', phone: '' });
    };

    const handleAddClientFromModal = async (e) => {
        const errors = {
            name: validateClientForm('name', clientForm.name),
            email: validateClientForm('email', clientForm.email),
            phone: validateClientForm('phone', clientForm.phone)
        };
        setClientFormErrors(errors);
        if (errors.name || errors.email || errors.phone) return;

        const match = clientList.find(
            c => c.name?.toLowerCase() === clientForm.name.trim().toLowerCase()
        );
        if (match) {
            setSelectedClient(match);
            setShowClientModal(false);
            return;
        }
        if (clientForm) {
            setSelectedClient(clientForm);
            setShowClientModal(false);
            setClientList(prev => [...prev, clientForm]);
            setClientForm({
                id: clientForm.id || null,
                name: clientForm.name || '',
                email: clientForm.email || '',
                phone: clientForm.phone || '',
                address: clientForm.address || ''
            });
            setClientFormErrors({ name: '', email: '', phone: '' });
        }
    };

    const handleDateClick = () => setShowCalendarStart(true);
    const handleDateSelect = (date) => {
        setInvoiceDate(date);
        setShowCalendarStart(false);
    };

    const handleTermsChange = (e) => {
        setTerms(e.target.value);
        if (e.target.value !== "1") setShowDueDateCalendar(false);
    };

    const handleDueDateClick = () => {
        setShowDueDateCalendar(true);
    };
    const handleDueDateSelect = (date) => {
        setDueDate(date);
        setShowDueDateCalendar(false);
    };

    const handleShow = () => {
        setShow(true);
        setEditItemIndex(null);
        setItemFormErrors({ name: "", rate: "", quantity: "" });
        setItemForm({
            id: null,
            code: '',
            name: '',
            description: '',
            rate: '',
            quantity: '',
            // unitTypes: '',
            gstChecked: false,
            gstValue: '',
            discountChecked: false,
            discountType: 'flat',
            discountValue: '',
            isAppointment: false,
            appointmentId: null
        });
    };
    const handleClose = () => setShow(false);

    const handleItemFormChange = (e) => {
        const { name, value, type, checked } = e.target;
        setItemForm(prev => ({
            ...prev,
            [name]: type === "checkbox" ? checked : value
        }));
        let v = value;
        if (name === "quantity") {
            v = v.replace(/\D/g, "").slice(0, 10);
        }
        setItemForm((prev) => ({
            ...prev,
            [name]: v,
        }));
        setItemFormErrors((prev) => ({
            ...prev,
            [name]: validateItemForm(name, v),
        }));
    };

    const handleItemGstCheck = (e) => {
        setItemForm(prev => ({
            ...prev,
            gstChecked: e.target.checked,
            gstValue: e.target.checked ? (prev.gstValue || '') : ''
        }));
    };

    const handleItemDiscountCheck = (e) => {
        setItemForm(prev => ({
            ...prev,
            discountChecked: e.target.checked,
            discountType: prev.discountType,
            discountValue: e.target.checked ? prev.discountValue : ''
        }));
    };

    const handleSaveItem = () => {
        const errors = {
            name: validateItemForm("name", itemForm.name),
            rate: validateItemForm("rate", itemForm.rate),
            quantity: validateItemForm("quantity", itemForm.quantity),
        };
        setItemFormErrors(errors);
        if (errors.name || errors.rate || errors.quantity) return;
        const newItem = { ...itemForm };
        let updatedItems;
        if (editItemIndex !== null) {
            updatedItems = [...items];
            updatedItems[editItemIndex] = { ...newItem, drag_id: `${items?.length}` };
        } else {
            updatedItems = [...items, { ...newItem, drag_id: `${items?.length + items?.length}`, }];
        }
        setItems(updatedItems);
        setShow(false);
    };

    const handleEditItem = (idx) => {
        setEditItemIndex(idx);
        setItemForm(items[idx]);
        setItemFormErrors({
            name: "",
            rate: "",
            quantity: "",
        });
        setShow(true);
    };

    const handleDeleteItem = (idx) => {
        const deletedItem = items[idx];
        setItems(items.filter((_, i) => i !== idx));
        if (deletedItem.isAppointment && deletedItem.appointmentId) {
            setAppointmentFlatList(prev => [...prev, deletedItem._originalAppointment]);
        }
    };

    const handleChooseItemOpen = async () => {
        setShow(false);
        setShowChooseItemModal(true);
        const result = await dispatch(fetchItemData());
        if (result && result.payload && Array.isArray(result.payload.data)) {
            setChooseItemList(result.payload.data);
        } else {
            setChooseItemList([]);
        }
        setChooseSelectedItems([]);
    };
    const handleChooseItemClose = () => {
        setItemSearch("");
        setShowChooseItemModal(false);
    }

    const handleChooseItemToggle = (item) => {
        setChooseSelectedItems(prev => {
            const exists = prev.find(i => i.id === item.id);
            if (exists) {
                return prev.filter(i => i.id !== item.id);
            } else {
                return [...prev, item];
            }
        });
    };

    const handleChooseItemSave = () => {
        const mapped = chooseSelectedItems.map((item, indx) => ({
            id: item.id || null,
            drag_id: `${items?.length + indx}`,
            code: item.code || '',
            name: item.name || item.item_name || '',
            description: item.description || item.item_Description || '',
            rate: item?.rate || '',
            quantity: item.quantity || item.qty || 1,
            unitTypes: item.unitTypes || item.unit_code || '',
            gstChecked: item.gstChecked || false,
            gstValue: item.gstValue || '',
            discountChecked: item.discountChecked || false,
            discountType: item.discountType || 'flat',
            discountValue: item.discountValue || '',
            isAppointment: false,
            appointmentId: null
        }));
        const existingKeys = items.map(i => `${i.name}-${i.rate}-${i.description}`);
        const newItems = mapped.filter(i => !existingKeys.includes(`${i.name}-${i.rate}-${i.description}`));
        setItems([...items, ...newItems]);
        setShowChooseItemModal(false);
    };

    const handleChooseSelectedDelete = (itemId) => {
        setChooseSelectedItems(prev => prev.filter(i => i.id !== itemId));
    };

    // Logo logic
    // Compress image before converting to base64 and adding to attachments
    function handleLogoChange(e) {
        const files = Array.from(e.target.files);
        if (!files.length) return;

        // Helper to compress image using canvas
        function compressImage(file, maxWidth = 800, maxHeight = 800, quality = 0.7) {
            return new Promise((resolve, reject) => {
                const img = new window.Image();
                const reader = new FileReader();
                reader.onload = function (evt) {
                    img.onload = function () {
                        let width = img.width;
                        let height = img.height;

                        // Calculate new size while maintaining aspect ratio
                        if (width > maxWidth || height > maxHeight) {
                            if (width / height > maxWidth / maxHeight) {
                                height = Math.round((height * maxWidth) / width);
                                width = maxWidth;
                            } else {
                                width = Math.round((width * maxHeight) / height);
                                height = maxHeight;
                            }
                        }

                        const canvas = document.createElement('canvas');
                        canvas.width = width;
                        canvas.height = height;
                        const ctx = canvas.getContext('2d');
                        ctx.drawImage(img, 0, 0, width, height);

                        // Compress to JPEG (smaller than PNG)
                        const compressedBase64 = canvas.toDataURL('image/jpeg', quality);
                        resolve(compressedBase64);
                    };
                    img.onerror = reject;
                    img.src = evt.target.result;
                };
                reader.onerror = reject;
                reader.readAsDataURL(file);
            });
        }

        // Compress all images and add to attachments
        Promise.all(
            files.map(file => compressImage(file, 800, 800, 0.7))
        ).then(images => {
            setAttachments(prev => [...prev, ...images]);
        });
    }
    function handleRemoveAttachment(idx) {
        setAttachments(prev => prev.filter((_, i) => i !== idx));
    }

    const handleEditInvoiceNumber = () => {
        setEditInvoiceNumber(true);
        setInvoiceNumberInput(invoiceNumber);
    };

    const handleInvoiceNumberInputChange = (e) => {
        let val = e.target.value.replace(/[^0-9]/g, "");
        setInvoiceNumberInput(val);
    };

    const handleInvoiceNumberInputBlur = () => {
        let num = invoiceNumberInput;
        setInvoiceNumber(num);
        setEditInvoiceNumber(false);
    };

    const handleInvoiceNumberInputKeyDown = (e) => {
        if (e.key === "Enter" || e.key === "Escape") {
            handleInvoiceNumberInputBlur();
        }
    };

    const handleSaveInvoice = async () => {
        setSaveInvoiceLoading(true)
        const clientPayload = selectedClient
            ? { ...selectedClient }
            : { ...clientForm };
        const itemsPayload = items.map(item => ({
            ...item
        }));
        const invoicePayload = {
            autosaveEnabled: (typeof localStorage !== 'undefined') ? localStorage.getItem('autosaveEnabled') : false,
            invoiceNumber: invoiceNumber,
            client_id: clientPayload,
            items: itemsPayload,
            date: invoiceDate,
            term: terms,
            dueDate: dueDate,
            subTotal: subtotal,
            discount: discountTotal,
            total: total,
            gstTotal: gstTotal,
            paid: 0,
            balance: total,
            paymentStatus: 'unpaid',
            sentStatus: sentStatus,
            attachments,
            logo,
            paymentInstruction,
            comment,
            deposit,
            customInvoice: formData,
            customInvoiceOption: optionData
        };
        try {
            const result = await dispatch(createInvoiceData(invoicePayload));
            if (result && result.payload && result.payload.data) {
                setUnsaved(false)
                toast.success("Invoice created successfully!");
                setTimeout(() => {
                    router.push('/invoice');
                }, 100)
            } else {
                toast.error(result.message || 'Failed to create invoice');
            }
        } catch (err) {
            toast.error('Failed to create invoice');
        } finally {
            setSaveInvoiceLoading(false)
        }
    };

    const handleUpdateInvoice = async () => {
        setSaveInvoiceLoading(true)
        if (!invoiceId) return;
        const clientPayload = selectedClient
            ? { ...selectedClient }
            : { ...clientForm };
        const itemsPayload = items.map(item => ({
            ...item
        }));
        const invoicePayload = {
            id: invoiceId,
            autosaveEnabled: (typeof localStorage !== 'undefined') ? localStorage.getItem('autosaveEnabled') : false,
            invoiceNumber: invoiceNumber,
            client_id: clientPayload,
            items: itemsPayload,
            date: invoiceDate,
            term: terms,
            dueDate: dueDate,
            subTotal: subtotal,
            discount: discountTotal,
            gstTotal: gstTotal,
            total: total,
            paid: 0,
            balance: total,
            paymentStatus: 'unpaid',
            sentStatus: sentStatus,
            attachments,
            logo,
            paymentInstruction,
            comment,
            deposit
        };
        try {
            const result = await dispatch(updateInvoiceData(invoicePayload));
            if (result && result.payload && result.payload.data) {
                setUnsaved(false)
                toast.success("Invoice updated successfully!");
                setTimeout(() => {
                    router.push('/invoice');
                }, 100)
            } else {
                toast.error(result.message || 'Failed to update invoice');
            }
        } catch (err) {
            toast.error('Failed to update invoice');
        } finally {
            setSaveInvoiceLoading(false)
        }
    };

    const handleInvoiceDiscountChange = (e) => {
        setInvoiceDiscount(e.target.value);
    };

    const handleGstOpen = async () => {
        setGstModal(true);
        const result = await dispatch(fetchTaxData());
        if (result && result.payload && Array.isArray(result.payload.data)) {
            setTaxRates(result.payload.data);
        } else {
            setTaxRates([]);
        }
        setGstTab(invoiceGstType);
        setSelectedGstRate(invoiceGstRate);
    };
    const handleGstClose = () => setGstModal(false);

    function handleSelectGstRate(rate) {
        setSelectedGstRate(rate);
    }
    function handleGstTabChange(tab) {
        setGstTab(tab);
    }
    function handleGstSave() {
        setInvoiceGstRate(selectedGstRate);
        setInvoiceGstType(gstTab);
        setGstModal(false);
    }

    const handleAddRateOpen = () => {
        setNewRate({ rate: '', percentage: '' });
        setShowAddRateModal(true);
        setEditRateId(null);
    };
    const handleAddRateClose = () => {
        setShowAddRateModal(false);
        setEditRateId(null);
    };
    const handleRateChange = (e) => {
        const { name, value } = e.target;
        setNewRate(prev => ({ ...prev, [name]: value }));
    };
    const handleSaveRate = async () => {
        if (!selectedClient) {
            toast.error("Please select a client first in invoice");
            return;
        }
        if (!newRate.rate || !newRate.percentage) return;
        setSavingRate(true);
        const payload = {
            rate: newRate.rate,
            percentage: newRate.percentage,
            client_id: selectedClient.id
        };
        const result = await dispatch(createTaxData(payload));
        setSavingRate(false);
        if (result && result.payload && result.payload.data) {
            setTaxRates(prev => [...prev, result.payload.data]);
            setShowAddRateModal(false);
        }
    };
    const handleDeleteRate = async (id) => {
        setSavingRate(true);
        const payload = { id };
        const result = await dispatch(fetchDeleteTaxData(payload));
        setSavingRate(false);
        if (result && result.payload && result.payload.data) {
            setTaxRates(prev => prev.filter(rate => rate.id !== id));
            if (selectedGstRate && selectedGstRate.id === id) setSelectedGstRate(null);
        }
    };

    function calendarTileClassName({ date, view }) {
        if (view === 'month') {
            const today = new Date();
            if (
                date.getDate() === today.getDate() &&
                date.getMonth() === today.getMonth() &&
                date.getFullYear() === today.getFullYear()
            ) {
                return 'react-calendar-tile-today-highlight';
            }
        }
        return null;
    }

    const handleAddPaymentInstruction = () => setShowPaymentInstructionInput(true);
    const handleAddComment = () => setShowCommentInput(true);

    const handleAddAppointmentOpen = async () => {
        setShowAppointmentModal(true);
        const now = new Date();
        const month = appointmentMonth;
        const year = appointmentYear;
        setAppointmentLabel(`${getMonthName(month)} ${year}`);
        const result = await dispatch(fetchAppointmentData({})).unwrap();
        let flatList = [];

        if (result && Array.isArray(result)) {
            setAppointmentList(result);
            flatList = result;
        }
        // console.log("flatList before filtering usedIds: ", flatList);
        const usedIds = items.filter(i => i.isAppointment && i.appointmentId).map(i => i.appointmentId);
        flatList = flatList.filter(app => !usedIds.includes(app.id));
        // console.log("flatList after filtering usedIds: ", flatList);

        setAppointmentFlatList(flatList);
        setAppointmentSelected([]);
        setAppointmentSearch('');
    };


    // Helper to group appointments by month/year
    function groupAppointmentsByMonthYear(appointments) {
        // console.log("appointments ------------> ", appointments);

        const groups = {};
        appointments.forEach(app => {
            const date = new Date(app.start_date);
            const month = date.getMonth();
            const year = date.getFullYear();
            const key = `${year}-${month}`;
            if (!groups[key]) {
                groups[key] = {
                    label: `${date.toLocaleString('default', { month: 'long' })} ${year}`,
                    appointments: []
                };
            }
            groups[key].appointments.push(app);
        });
        // Sort by year/month descending
        return Object.values(groups).sort((a, b) => a.label.localeCompare(b.label));
    }
    const handleAppointmentModalClose = () => {
        setShowAppointmentModal(false);
        setAppointmentSearch('');
    };

    const handleAppointmentToggle = (app) => {
        setAppointmentSelected(prev => {
            const exists = prev.find(i => i.id === app.id);
            if (exists) {
                return prev.filter(i => i.id !== app.id);
            } else {
                return [...prev, app];
            }
        });
    };
    const handleAppointmentAdd = () => {
        const newItems = appointmentSelected.map((app, indx) => {
            const getDatePart = (isoString) => isoString ? isoString.split('T')[0] : '';
            const startDate = getDatePart(app.start_date);
            const endDate = getDatePart(app.end_date);
            const start = new Date(`${startDate}T${app.start_time}`);
            const end = new Date(`${endDate}T${app.end_time}`);
            const options = { weekday: 'long', month: 'short', day: 'numeric', year: 'numeric' };
            const dateStr = start.toLocaleDateString(undefined, options);
            const startTime = start.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
            const endTime = end.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
            return {
                id: null,
                code: '',
                drag_id: `${items?.length + indx}`,
                name: `${dateStr}, ${startTime} - ${endTime}`,
                description: '',
                rate: '',
                quantity: '',
                gstChecked: false,
                gstValue: '',
                discountChecked: false,
                discountType: 'flat',
                discountValue: '',
                isAppointment: true,
                appointmentId: app.id,
                _originalAppointment: app
            };
        });
        setItems([...items, ...newItems]);
        setAppointmentFlatList(prev => prev.filter(app => !appointmentSelected.some(sel => sel.id === app.id)));
        setShowAppointmentModal(false);
    };

    useEffect(() => {
        // console.log("items changed, updating appointmentFlatList", items);

        setAppointmentFlatList(prev =>
            prev.filter(app => !items.some(i => i.isAppointment && i.appointmentId === app.id))
        );
    }, [items]);

    const filteredChooseItemList = chooseItemList.filter(item =>
        (item.name || item.item_name || '').toLowerCase().includes(itemSearch.toLowerCase()) ||
        (item.description || item.item_Description || '').toLowerCase().includes(itemSearch.toLowerCase())
    );
    // useEffect(() => {
    //     console.log("appointmentFlatList :: ", appointmentFlatList);
    // }, [appointmentFlatList]);

    const filteredAppointmentList = appointmentFlatList.filter(app => {
        const clientName = app.client?.name || '';
        const notes = app.notes || '';
        const location = app.location || '';
        return (
            clientName.toLowerCase().includes(appointmentSearch.toLowerCase()) ||
            notes.toLowerCase().includes(appointmentSearch.toLowerCase()) ||
            location.toLowerCase().includes(appointmentSearch.toLowerCase())
        );
    });

    // Grouped appointment list for modal
    const groupedAppointments = useMemo(() => groupAppointmentsByMonthYear(filteredAppointmentList), [filteredAppointmentList]);

    // Format appointment row to show all contact names joined by '-'
    function getContactNames(app) {
        if (Array.isArray(app.contacts) && app.contacts.length > 0) {
            return app.contacts.map(c => c.contact_name).join('-');
        }
        // fallback to client name or string
        return app.client?.name || app.contacts || 'Unknown';
    }

    function formatAppointmentRow(app) {
        const getDatePart = (isoString) => isoString ? isoString.split('T')[0] : '';
        const clientName = getContactNames(app);
        const startDate = getDatePart(app.start_date);
        const endDate = getDatePart(app.end_date);
        const start = new Date(`${startDate}T${app.start_time}`);
        const end = new Date(`${endDate}T${app.end_time}`);
        const startTime = isNaN(start) ? '' : start.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        const endTime = isNaN(end) ? '' : end.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        const durationMs = end - start;
        const durationH = !isNaN(durationMs) ? Math.round(durationMs / (1000 * 60 * 60)) : '';
        const dateStr = isNaN(start) ? '' : start.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
        return `${clientName} ${startTime} - ${endTime} (${durationH}h) - ${dateStr}`;
    }

    // useEffect(() => {
    //     setAppointmentFlatList(prev =>
    //         prev.filter(app => !items.some(i => i.isAppointment && i.appointmentId === app.id))
    //     );
    // }, [items]);

    const calendarRef = useRef();
    const dueDateCalendarRef = useRef();
    const depositDueDateCalendarRef = useRef();
    const [showDepositDueDateCalendar, setShowDepositDueDateCalendar] = useState(false);

    useEffect(() => {
        function handleClickOutside(event) {
            if (
                showCalendarStart &&
                calendarRef.current &&
                !calendarRef.current.contains(event.target)
            ) {
                setShowCalendarStart(false);
            }
            if (
                showDueDateCalendar &&
                dueDateCalendarRef.current &&
                !dueDateCalendarRef.current.contains(event.target)
            ) {
                setShowDueDateCalendar(false);
            }
            if (
                showDepositDueDateCalendar &&
                depositDueDateCalendarRef.current &&
                !depositDueDateCalendarRef.current.contains(event.target)
            ) {
                setShowDepositDueDateCalendar(false);
            }
        }
        if (showCalendarStart || showDueDateCalendar || showDepositDueDateCalendar) {
            document.addEventListener("mousedown", handleClickOutside);
        }
        return () => {
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, [showCalendarStart, showDueDateCalendar, showDepositDueDateCalendar]);

    useEffect(() => {
        if (depositTab === 'percent') {
            setDepositFixedAmount(Math.round((total * depositPercentage) / 100));
        }
    }, [depositTab, depositPercentage, total]);

    const handleDepositPercentageChange = (e) => {
        let val = e.target.value;
        if (val.length > 1 && val.startsWith('0')) val = val.replace(/^0+/, '');
        if (val === '') {
            setDepositPercentage('');
            setDepositFixedAmount('');
            return;
        }
        val = Number(val);
        if (val > 100) val = 100;
        setDepositPercentage(val);
        setDepositFixedAmount(total ? Math.round((total * val) / 100) : '');
    };

    const handleDepositFixedAmountChange = (e) => {
        let val = e.target.value;
        if (val.length > 1 && val.startsWith('0')) val = val.replace(/^0+/, '');
        if (val === '') {
            setDepositFixedAmount('');
            setDepositPercentage('');
            return;
        }
        val = Number(val);
        if (val > total) val = total;
        setDepositFixedAmount(val);
        setDepositPercentage(total ? Math.round((val / total) * 100) : '');
    };

    // const handleDepositDueDateClick = () => setShowDepositDueDateCalendar(true);
    // const handleDepositDueDateSelect = (date) => {
    //     setDepositDueDate(format(date, 'yyyy-MM-dd'));
    //     setShowDepositDueDateCalendar(false);
    // };

    const element = previewPdfFile || previewRef.current;

    /* Expense Modal Handlers */
    const handleChange = (e) => {
        setForm(prev => ({ ...prev, [e.target.name]: e.target.value }))
    };

    const handleDateChange = (date) => {
        setForm(prev => ({ ...prev, date }));
        setShowCalendarExpenseStart(false);
    };

    const handleAddexpensesOpen = async () => {
        setShowExpenseModal(true);
        const result = await dispatch(getExpenseData({ clientId: selectedClient?.id })).unwrap();
        setExpenseList(result?.data || []);
        const filteredExpenses = result?.data
            .map(category => {

                const filteredExpenses = category.expenses.filter(exp =>
                    !items.some(item => item?.isExpense && item.ExpenseId === exp.id)
                );

                // Keep the category only if it has matching expenses
                if (filteredExpenses.length > 0) {
                    return {
                        ...category,
                        expenses: filteredExpenses
                    };
                }
                return null;
            })
            .filter(Boolean);
        setExpenseFlatList(filteredExpenses || []);
        setExpenseSelected([]);
        setExpenseSearch('');
    }

    useEffect(() => {
        const filteredExpenses = expenseFlatList
            .map(category => {
                const filteredExpenses = category.expenses.filter(exp =>
                    !items.some(item => item.ExpenseId === exp.id)
                );

                // Keep the category only if it has matching expenses
                if (filteredExpenses.length > 0) {
                    return {
                        ...category,
                        expenses: filteredExpenses
                    };
                }
                return null;
            })
            .filter(Boolean);
        // console.log("filteredExpenses :->:->: ", filteredExpenses);

        setExpenseFlatList(filteredExpenses || []);
    }, [items]);

    useEffect(() => {
        if (expenseSearch && expenseSearch?.length > 0 && expenseFlatList?.length > 0) {
            const filteredExpenses = expenseFlatList
                .map(category => {
                    const filtered = category?.expenses.filter(exp => {
                        const merchant = exp.merchant || '';
                        const hsn = exp.HSN || '';
                        const sac = exp.SAC || '';
                        const category = exp.category || '';
                        return (
                            merchant.toLowerCase().includes(expenseSearch.toLowerCase()) ||
                            hsn.toLowerCase().includes(expenseSearch.toLowerCase()) ||
                            sac.toLowerCase().includes(expenseSearch.toLowerCase()) ||
                            category.toLowerCase().includes(expenseSearch.toLowerCase())

                        );
                    });
                    console.log("filtered ::: ", filtered, {
                        ...category,
                        expenses: filtered
                    });


                    // Keep the category only if it has matching expenses
                    if (filtered.length > 0) {
                        return {
                            ...category,
                            expenses: filtered
                        };
                    }
                    return null;
                })
                .filter(Boolean);
            // console.log("filteredExpenses 222 :->:->: ", filteredExpenses);

            setExpenseFlatList(filteredExpenses);
        }
    }, [expenseSearch, expenseFlatList]);

    const handleExpenseModalClose = () => {
        setShowExpenseModal(false);
        setExpenseSearch('');
    }

    const handleAddMoreExpenseOpen = async () => {
        setShowExpenseModal(false);
        setAddMoreExpenseErrors({});
        setShowAddMoreExpenseModal(true);
        // Fetch projects
        if (selectedClient?.id) {
            setLoadingProjects(true);
            const data = { client_id: selectedClient?.id };
            dispatch(fetchClientProjectData(data))
                .unwrap()
                .then((data) => setProjects(data?.data || []))
                .catch(() => setProjects([]))
                .finally(() => setLoadingProjects(false));
        } else {
            setProjects([]);
        }
    };

    const handleAddMoreExpenseClose = () => setShowAddMoreExpenseModal(false);

    const handleAddMoreExpenseAdd = async () => {
        try {
            const tempForm = { ...form, clientId: selectedClient?.id || null };
            const formData = new FormData();
            Object.entries(tempForm).forEach(([key, value]) => {
                if (key === "date") {
                    formData.append(key, value.toISOString());
                } else {
                    formData.append(key, value);
                }
            });

            const result = await dispatch(createExpenseData(formData)).unwrap();

            if (result && result.data) {
                setItems(items => [
                    ...items,
                    {
                        id: null,
                        drag_id: `${items?.length + items?.length}`,
                        code: '',
                        name: `${result.data.HSN || result?.data.SAC || ''} - ${result.data.merchant || ''}`,
                        description: '',
                        rate: '',
                        quantity: '',
                        gstChecked: false,
                        gstValue: '',
                        discountChecked: false,
                        discountType: 'flat',
                        discountValue: '',
                        isExpense: true,
                        ExpenseId: result.data.id,
                        _originalExpense: result.data
                    }
                ]);
                setForm({ title: '', merchant: '', amount: '', date: new Date(), projectId: '', category: '', HSN: '', SAC: '' });
                setAddMoreExpenseErrors({});
                toast.success("Expense added successfully!");
                setShowAddMoreExpenseModal(false);
            }
        } catch (error) {
            toast.error(error || 'Failed to create expense');
        }
    }

    const handleExpenseAdd = () => {
        const newItems = expenseSelected.map((app, indx) => {
            return {
                id: null,
                code: '',
                drag_id: `${items?.length + indx}`,
                name: `${app.HSN || app.SAC || ''} - ${app.merchant || ''}`,
                description: '',
                rate: '',
                quantity: '',
                gstChecked: false,
                gstValue: '',
                discountChecked: false,
                discountType: 'flat',
                discountValue: '',
                isExpense: true,
                ExpenseId: app.id,
                _originalExpense: app
            };
        });
        setItems([...items, ...newItems]);
        setExpenseFlatList(prev => prev.filter(app => !expenseSelected.some(sel => sel.id === app.id)));
        setShowExpenseModal(false);
    };

    const handleExpenseToggle = (app) => {
        setExpenseSelected(prev => {
            const exists = prev.find(i => i.id === app.id);
            if (exists) {
                return prev.filter(i => i.id !== app.id);
            } else {
                return [...prev, app];
            }
        });
    };

  

    return (
        <div className='clientPadding'>
            <div className='addClientForm mb-4'>
                <button className='clientFormBackBtn' onClick={handleBack}>
                    <FontAwesomeIcon icon={faArrowLeft} /> {invoiceId ? "Edit Invoice" : "Add Invoice"}
                </button>
                <div className={`addClientFormTop ${isSticky ? 'sticky' : ''}`}>
                    <div className='addClientFormTopLeft'>
                        <ul>
                            {TABS.map(tab => (
                                <li
                                    key={tab}
                                    className={activeTab === tab ? 'active' : ''}
                                    style={{ cursor: 'pointer' }}
                                    onClick={() => handleTabChange(tab)}
                                >{tab}</li>
                            ))}
                        </ul>
                    </div>
                    <div className='addClientFormTopRight'>
                        {activeTab && (
                            invoiceId ? (
                                <button onClick={handleUpdateInvoice}>{saveInvoiceLoading ? "Updating..." : "Update"}</button>
                            ) : (
                                <button onClick={handleSaveInvoice}>{saveInvoiceLoading ? "Saving..." : "Save"}</button>
                            )
                        )}
                    </div>
                </div>
                <div className='addClientFormInner invoicePageOnly'>
                    {(activeTab === 'Create' || activeTab === 'Edit') && (

                        <div className='row'>
                            <div className='col-md-9'>
                                <div className='communication-inner invoiceAccordionOnly'>
                                    <Accordion defaultActiveKey={['0', '1', '2', '3']} alwaysOpen>
                                        <Accordion.Item eventKey="0">
                                            <Accordion.Header>
                                                <p className='accorheading'>Bill To</p>
                                            </Accordion.Header>
                                            <Accordion.Body>
                                                {!selectedClient ? (
                                                    <div className="col-lg-12">
                                                        <button className='add-note' onClick={handleShowClientModal}>
                                                            <FontAwesomeIcon icon={faSquarePlus} /> Add Client
                                                        </button>
                                                    </div>
                                                ) : (
                                                    <div className='contactDetails'>
                                                        <div className='contactDetailsLeft'>
                                                            <h3 style={{ background: selectedClient.profileImage ? '#ffffffff' : '#44BBFE' }}>
                                                                {selectedClient.profileImage
                                                                    ? <img src={selectedClient.profileImage} style={{ width: '60px', height: '60px', borderRadius: '60%' }} alt={selectedClient.name} />
                                                                    : selectedClient.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                                                            </h3>
                                                        </div>
                                                        <div className='contactDetailsRight'>
                                                            <h4>{selectedClient.name}</h4>
                                                            <ul>
                                                                <li>
                                                                    <FontAwesomeIcon icon={faEnvelope} />
                                                                    {selectedClient.email}
                                                                </li>
                                                                <li>
                                                                    <FontAwesomeIcon icon={faPhone} />
                                                                    {selectedClient.phone}
                                                                </li>
                                                                {selectedClient.address && (
                                                                    <li>
                                                                        <FontAwesomeIcon icon={faLocationDot} />
                                                                        {selectedClient.address}
                                                                    </li>
                                                                )}
                                                            </ul>
                                                        </div>
                                                        <div className='crossBtn' style={{ cursor: 'pointer' }} onClick={handleClearClient}>
                                                            <FontAwesomeIcon icon={faCircleXmark} />
                                                        </div>
                                                    </div>
                                                )}
                                            </Accordion.Body>
                                        </Accordion.Item>
                                        <Accordion.Item eventKey="1">
                                            <Accordion.Header>
                                                <p className='accorheading'>Items</p>
                                            </Accordion.Header>
                                            <Accordion.Body>
                                                <div className="row">
                                                    <div className="col-lg-12">
                                                        {items.length === 0 && (
                                                            <div style={{ color: '#888', marginBottom: 8 }}>No items added yet.</div>
                                                        )}
                                                        {/* INVOICE DRAG N DROP */}
                                                        {/* {console.log("Rendering DndKitList with items: ", items)} */}
                                                        <DndKitList handleEditItem={handleEditItem} handleDeleteItem={handleDeleteItem} items={items} setItems={setItems} currencyList={currencyList} />
                                                    </div>
                                                </div>
                                                <div className="row">
                                                    <div className="col-lg-3">
                                                        <button className='add-note' onClick={handleShow}>
                                                            <FontAwesomeIcon icon={faSquarePlus} /> Add items
                                                        </button>
                                                    </div>
                                                    <div className="col-lg-3">
                                                        <button className='add-note' onClick={handleAddexpensesOpen}>
                                                            <FontAwesomeIcon icon={faSquarePlus} />Add expenses
                                                        </button>
                                                    </div>
                                                    <div className="col-lg-3">
                                                        <button className='add-note' onClick={handleAddAppointmentOpen}>
                                                            <FontAwesomeIcon icon={faSquarePlus} />Add appointments
                                                        </button>
                                                    </div>
                                                    <div className="col-lg-3">
                                                        <button className='add-note' onClick={handleAddTimeEntryOpen}>
                                                            <FontAwesomeIcon icon={faSquarePlus} />Add time entry
                                                        </button>
                                                    </div>
                                                </div>
                                            </Accordion.Body>
                                        </Accordion.Item>
                                        <Accordion.Item eventKey="2">
                                            <Accordion.Header>
                                                <p className='accorheading'>Attachments</p>
                                            </Accordion.Header>
                                            <Accordion.Body>
                                                <div className="col-lg-12" style={{ display: "flex", flexWrap: "wrap", gap: 16 }}>
                                                    {/* {console.log(attachments, "123456789o")} */}
                                                    {attachments.map((img, idx) => (
                                                        <div key={idx} style={{ position: "relative", marginBottom: 8 }}>
                                                            <img
                                                                src={img}
                                                                alt={`Attachment ${idx + 1}`}
                                                                style={{
                                                                    width: 80,
                                                                    height: 80,
                                                                    objectFit: "cover",
                                                                    borderRadius: 6,
                                                                    border: "1px solid #eee"
                                                                }}
                                                            />
                                                            <span
                                                                style={{
                                                                    position: "absolute",
                                                                    top: 2,
                                                                    right: 2,
                                                                    background: "#fff",
                                                                    borderRadius: "50%",
                                                                    cursor: "pointer",
                                                                    padding: "2px 4px",
                                                                    color: "#047FFF"
                                                                }}
                                                                onClick={() => handleRemoveAttachment(idx)}
                                                            >
                                                                <div className="crossBtn deleteCross" style={{ cursor: "pointer" }} onClick={handleRemoveAttachment}>
                                                                    <FontAwesomeIcon icon={faCircleXmark} />
                                                                </div>
                                                            </span>
                                                        </div>
                                                    ))}

                                                    <div className='addPhotoInput addPhotoCard'>

                                                        <img src={IMAGE.imagePicker} alt="" />
                                                        <input
                                                            type="file"
                                                            accept="image/*"
                                                            ref={logoInputRef}
                                                          
                                                            multiple
                                                            onChange={handleLogoChange}
                                                        />
                                                        <div className='addPhotoInputButton'>

                                                            <button
                                                                className="add-photo"
                                                                style={{ width: 80, height: 80, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}
                                                                onClick={() => {
                                                                    if (logoInputRef.current) {
                                                                        logoInputRef.current.value = "";
                                                                        logoInputRef.current.click();
                                                                    }
                                                                }}
                                                            >
                                                                <FontAwesomeIcon icon={faSquarePlus} style={{ fontSize: 24 }} />
                                                                <span style={{ fontSize: 12 }}>Add Photo</span>
                                                            </button>

                                                        </div>
                                                    </div>

                                                </div>
                                            </Accordion.Body>
                                        </Accordion.Item>
                                        <Accordion.Item eventKey="3">
                                            <Accordion.Header>
                                                <p className='accorheading'>Comments and payment instructions</p>
                                            </Accordion.Header>
                                            <Accordion.Body>
                                                <div className="col-lg-12">
                                                    {showPaymentInstructionInput ? (
                                                        <>
                                                            <input
                                                                className="input-form-control"
                                                                type="text"
                                                                value={paymentInstruction}
                                                                onChange={e => setPaymentInstruction(e.target.value)}
                                                                placeholder="Enter payment instruction"
                                                                autoFocus
                                                            />
                                                            <div style={{ fontSize: 13, color: '#888', marginTop: 4 }}>
                                                                If you have specific comments about payments or instructions, enter them here.<br />

                                                            </div>
                                                        </>
                                                    ) : (
                                                        <button className='add-note' onClick={handleAddPaymentInstruction}>
                                                            <FontAwesomeIcon icon={faSquarePlus} />Add payment instruction
                                                        </button>
                                                    )}
                                                </div>
                                                <div className="col-lg-12" style={{ marginTop: 12 }}>
                                                    {showCommentInput ? (
                                                        <input
                                                            className="input-form-control"
                                                            type="text"
                                                            value={comment}
                                                            onChange={e => setComment(e.target.value)}
                                                            placeholder="Enter a comment for your customer..."
                                                            autoFocus
                                                        />
                                                    ) : (
                                                        <button className='add-note' onClick={handleAddComment}>
                                                            <FontAwesomeIcon icon={faSquarePlus} />Add comments
                                                        </button>
                                                    )}
                                                </div>
                                            </Accordion.Body>
                                        </Accordion.Item>
                                    </Accordion>
                                </div>
                            </div>
                            <div className='col-md-3'>
                                <div className='invoiceHeaderLeft'>
                                    <div className='invoiceSection'>
                                        <h5>Invoice</h5>
                                        <div className='invoiceSectionInner'>
                                            <h6 style={{ margin: 0, display: 'inline-block' }}>
                                                {optionData.invoicePrifix ? optionData.invoicePrifix + '-' : ''}{!invoiceId && editInvoiceNumber ? '' : invoiceNumber}
                                            </h6>
                                            {!invoiceId && (
                                                <>
                                                    {editInvoiceNumber ? (
                                                        <input className='input-form-control'
                                                            type="text"
                                                            value={invoiceNumberInput}
                                                            onChange={handleInvoiceNumberInputChange}
                                                            onBlur={handleInvoiceNumberInputBlur}
                                                            onKeyDown={handleInvoiceNumberInputKeyDown}
                                                            style={{
                                                                width: 60,
                                                                fontSize: 18,
                                                                fontWeight: 600,
                                                                border: '1px solid #047FFF',
                                                                borderRadius: 4,
                                                                padding: '2px 6px'
                                                            }}
                                                            autoFocus />
                                                    ) : (
                                                        <>
                                                            {/* <h6 style={{ margin: 0, display: 'inline-block' }}>
                                                        
                                                        {optionData.invoicePrifix ? optionData.invoicePrifix + '-' : ''}{invoiceNumber}
                                                    </h6> */}
                                                            <span style={{ marginLeft: 8, cursor: 'pointer' }} onClick={handleEditInvoiceNumber}>
                                                                <FontAwesomeIcon icon={faPenToSquare} />
                                                            </span>
                                                        </>
                                                    )}
                                                </>

                                            )}
                                            {/* {invoiceId && (
                                                <h6 style={{ margin: 0, display: 'inline-block' }}>{optionData.invoicePrifix ? optionData.invoicePrifix + '-' : ''}{invoiceNumber}</h6>
                                            )} */}
                                        </div>
                                        <p className='unsent'>{sentStatus === "sent" ? "Sent" : "Unsent"}</p>
                                    </div>
                                    <div className='invoiceBox'>
                                        <ul className='borderBottom '>
                                            <li>
                                                <p>Date</p>
                                                <span
                                                    className='listBorder'
                                                    style={{ cursor: 'pointer', position: 'relative' }}
                                                    onClick={handleDateClick}
                                                >
                                                    {formatDate(invoiceDate)}
                                                    {showCalendarStart && (
                                                        <div
                                                            ref={calendarRef}
                                                        >
                                                            <Calendar
                                                                value={invoiceDate}
                                                                onChange={handleDateSelect}
                                                                onClickDay={handleDateSelect}
                                                                tileClassName={calendarTileClassName}
                                                            />
                                                        </div>
                                                    )}
                                                </span>
                                            </li>
                                            <li>
                                                <p>Terms</p>
                                                <div className='select listBorder'>
                                                    <select
                                                        className="form-select"
                                                        aria-label="Default select example"
                                                        value={terms}
                                                        onChange={handleTermsChange}
                                                    >
                                                        {TERMS_OPTIONS.map(opt => (
                                                            <option key={opt.value} value={opt.value}>{opt.label}</option>
                                                        ))}
                                                    </select>
                                                </div>
                                            </li>
                                            <li>
                                                <p>Due-Date</p>
                                                <span
                                                    className='listBorder'
                                                    style={{
                                                        cursor: 'pointer',
                                                        pointerEvents: 'auto',
                                                        userSelect: 'auto',
                                                        position: 'relative'
                                                    }}
                                                    onClick={handleDueDateClick}
                                                >
                                                    {formatDate(dueDate)}
                                                    {showDueDateCalendar && (
                                                        <div
                                                            ref={dueDateCalendarRef}
                                                        >
                                                            <Calendar
                                                                value={dueDate}
                                                                onChange={handleDueDateSelect}
                                                                onClickDay={handleDueDateSelect}
                                                                tileClassName={calendarTileClassName}
                                                            />
                                                        </div>
                                                    )}
                                                </span>
                                            </li>
                                        </ul>
                                        <ul className='borderBottom '>
                                            <li>
                                                <p>Sub Total</p>
                                                <span>{formatCurrency(subtotal, currencyList)}</span>
                                            </li>
                                            <li>
                                                <p>Discount</p>
                                                {/* <span
                                                        className='listBorder'
                                                        style={{ cursor: 'pointer', minWidth: 100, display: 'inline-block' }}
                                                        tabIndex={0}
                                                        onClick={e => (setShowDiscountInput(true), setInvoiceDiscountEditable(true))}
                                                    >
                                                        {showDiscountInput ? (
                                                            <input
                                                                type="number"
                                                                className="form-control"
                                                                style={{
                                                                    width: 80,
                                                                    display: 'inline-block',
                                                                    height: 28,
                                                                    fontSize: 14,
                                                                    padding: '2px 6px',
                                                                    border: 'none',
                                                                    background: 'transparent',
                                                                    boxShadow: 'none'
                                                                }}
                                                                value={invoiceDiscount}
                                                                autoFocus
                                                                min="0"
                                                                onChange={e => handleInvoiceDiscountChange(e)}
                                                                onBlur={() => setShowDiscountInput(false)}
                                                                onKeyDown={e => {
                                                                    if (e.key === 'Enter' || e.key === 'Escape') setShowDiscountInput(false);
                                                                }} />
                                                        ) : (
                                                            formatCurrency(parseFloat(invoiceDiscount || 0))
                                                        )}
                                                    </span> */}

                                                <div
                                                    className="amount"
                                                    style={{ cursor: "pointer" }}
                                                    onClick={handleOpenDiscountModal}
                                                >
                                                    {/* <p>Discount</p> */}
                                                    <h4 className="listBorder" style={{

                                                        width: 80,
                                                        display: 'inline-block',
                                                        height: 28,
                                                        fontSize: 14,
                                                        padding: '2px 6px',
                                                        textAlign: 'end',
                                                        background: 'transparent',

                                                    }}>
                                                        {formatCurrency(discountAmount, currencyList)}
                                                    </h4>
                                                </div>
                                            </li>
                                        </ul>
                                        <ul className='borderBottom'>
                                            <li className='bill-card-details' style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                                                {/* {!hasItemLevelGst && ( */}
                                                <>
                                                    <p className='bold'>GST</p>
                                                    <span className='editGST' style={{ cursor: 'pointer', marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 8 }} onClick={handleGstOpen}>
                                                        Edit <FontAwesomeIcon icon={faPenToSquare} />
                                                    </span>
                                                </>
                                                {/* )} */}
                                            </li>
                                            <li>
                                                <p>GST</p>
                                                <span>{formatCurrency(gstTotal, currencyList)}</span>
                                            </li>
                                        </ul>

                                        <ul className='borderBottom'>
                                            <li>
                                                <p>Total</p>
                                                <span>{formatCurrency(total, currencyList)}</span>
                                            </li>
                                            <li>
                                                <p>Paid</p>
                                                <span>{formatCurrency(0, currencyList)}</span>
                                            </li>
                                            <li>
                                                <p>Balance</p>
                                                <span>{formatCurrency(total, currencyList)}</span>
                                            </li>
                                        </ul>
                                    </div>
                                    {!deposit && (
                                        <button className='add-note' onClick={handleAddDepositOpen}>
                                            <FontAwesomeIcon icon={faSquarePlus} /> Add deposit request
                                        </button>
                                    )}
                                    {deposit && (
                                        <div style={{ marginBottom: 12 }}>
                                            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, marginTop: 12 }}>
                                                <strong style={{ fontSize: "14px" }}>
                                                    Deposit request
                                                    {deposit.type === 'percent' ? ` (${deposit.percentage}%)` : ''}
                                                </strong>
                                                <span style={{ marginLeft: 8, fontSize: 13, }}>₹{deposit.amount}</span>
                                            </div>
                                            <div style={{ fontSize: 13, color: '#888', display: "flex", justifyContent: "center" }}>
                                                Due: {deposit.dueDate} | Paid: ₹{deposit.paid}
                                            </div>
                                            <button
                                                className='add-note'
                                                style={{ marginLeft: 8, fontSize: 13, }}
                                                onClick={handleAddDepositOpen}
                                            >
                                                View deposit request
                                            </button>

                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                    )}

                    {activeTab === 'Preview' && (

                        <div className='row'>
                            <div className='col-md-9'>
                                <div ref={previewRef}>
                                    {formData.templateName === 'impact' && (
                                        <CustomInvoiceImpact
                                            invoice={{
                                                name: "Invoice",
                                                invoiceNumber,
                                                selectedClient,
                                                invoiceDate,
                                                dueDate,
                                                items,
                                                subtotal,
                                                gstTotal,
                                                discountTotal,
                                                invoiceDiscountEditable,
                                                total,
                                                logo,
                                                attachments,
                                                paymentInstruction,
                                                comment,
                                                depositAmount: deposit,
                                                terms
                                            }}
                                            logoFile={logo}
                                            photoFiles={attachments}
                                            editInvoiceNumber={editInvoiceNumber}
                                            invoiceNumberInput={invoiceNumberInput}
                                            handleInvoiceNumberInputChange={handleInvoiceNumberInputChange}
                                            handleInvoiceNumberInputBlur={handleInvoiceNumberInputBlur}
                                            handleInvoiceNumberInputKeyDown={handleInvoiceNumberInputKeyDown}
                                            handleEditInvoiceNumber={handleEditInvoiceNumber}
                                            handleTermsChange={handleTermsChange}
                                            value2={value2}
                                            setValue2={setValue2}
                                            onBackToEdit={() => { invoiceId ? setActiveTab('Edit') : setActiveTab('Create') }}
                                            ref={null}
                                            selectedTemp={formData.templateName}
                                            selectedId={
                                                formData.logoId
                                                    ? { id: formData.logoId, logoImage: formData.logoImage }
                                                    : null
                                            }
                                            selectedSize={formData.logoSize}
                                            alignPos={formData.logoPosition}
                                            selectedColour={
                                                formData.colourId
                                                    ? { id: formData.colourId, colourCode: formData.colourCode }
                                                    : null
                                            }
                                            customColour={formData.customColour}
                                            selectedHeader={
                                                formData.headerId
                                                    ? { id: formData.headerId, headerImg: formData.headerImg }
                                                    : null
                                            }
                                            selectedWatermark={
                                                formData.waterMarkId
                                                    ? {
                                                        id: formData.waterMarkId,
                                                        waterMarkImg: formData.waterMarkImg,
                                                    }
                                                    : null
                                            }
                                            customTemplates={customTemplates}
                                            customOption={optionData}
                                            signatureName={sigInvoice}
                                            signatureType={signatureType}
                                            signature={{
                                                padSignature,
                                                uploadSignature,
                                                signatureText
                                            }}
                                            currencyList={currencyList}
                                        />
                                    )}
                                    {formData.templateName === 'classic' && (
                                        <CustomInvoiceImpact
                                            invoice={{
                                                name: "Invoice",
                                                invoiceNumber,
                                                selectedClient,
                                                invoiceDate,
                                                dueDate,
                                                items,
                                                subtotal,
                                                gstTotal,
                                                discountTotal,
                                                total,
                                                logo,
                                                attachments,
                                                paymentInstruction,
                                                comment,
                                                depositAmount: deposit,
                                                terms
                                            }}
                                            logoFile={logo}
                                            photoFiles={attachments}
                                            editInvoiceNumber={editInvoiceNumber}
                                            invoiceNumberInput={invoiceNumberInput}
                                            handleInvoiceNumberInputChange={handleInvoiceNumberInputChange}
                                            handleInvoiceNumberInputBlur={handleInvoiceNumberInputBlur}
                                            handleInvoiceNumberInputKeyDown={handleInvoiceNumberInputKeyDown}
                                            handleEditInvoiceNumber={handleEditInvoiceNumber}
                                            handleTermsChange={handleTermsChange}
                                            value2={value2}
                                            setValue2={setValue2}
                                            onBackToEdit={() => { invoiceId ? setActiveTab('Edit') : setActiveTab('Create') }}
                                            ref={null}
                                            selectedTemp={formData.templateName}
                                            selectedId={
                                                formData.logoId
                                                    ? { id: formData.logoId, logoImage: formData.logoImage }
                                                    : null
                                            }
                                            selectedSize={formData.logoSize}
                                            alignPos={formData.logoPosition}
                                            selectedColour={
                                                formData.colourId
                                                    ? { id: formData.colourId, colourCode: formData.colourCode }
                                                    : null
                                            }
                                            customColour={formData.customColour}
                                            selectedHeader={
                                                formData.headerId
                                                    ? { id: formData.headerId, headerImg: formData.headerImg }
                                                    : null
                                            }
                                            selectedWatermark={
                                                formData.waterMarkId
                                                    ? {
                                                        id: formData.waterMarkId,
                                                        waterMarkImg: formData.waterMarkImg,
                                                    }
                                                    : null
                                            }
                                            customTemplates={customTemplates}
                                            customOption={optionData}
                                            signatureName={sigInvoice}
                                            signatureType={signatureType}
                                            signature={{
                                                padSignature,
                                                uploadSignature,
                                                signatureText
                                            }}
                                            currencyList={currencyList}
                                        />
                                    )}

                                    {formData.templateName === 'modern' && (
                                        <CustomInvoiceImpact
                                            invoice={{
                                                name: "Invoice",
                                                invoiceNumber,
                                                selectedClient,
                                                invoiceDate,
                                                dueDate,
                                                items,
                                                subtotal,
                                                gstTotal,
                                                discountTotal,
                                                total,
                                                logo,
                                                attachments,
                                                paymentInstruction,
                                                comment,
                                                depositAmount: deposit,
                                                terms
                                            }}
                                            logoFile={logo}
                                            photoFiles={attachments}
                                            editInvoiceNumber={editInvoiceNumber}
                                            invoiceNumberInput={invoiceNumberInput}
                                            handleInvoiceNumberInputChange={handleInvoiceNumberInputChange}
                                            handleInvoiceNumberInputBlur={handleInvoiceNumberInputBlur}
                                            handleInvoiceNumberInputKeyDown={handleInvoiceNumberInputKeyDown}
                                            handleEditInvoiceNumber={handleEditInvoiceNumber}
                                            handleTermsChange={handleTermsChange}
                                            value2={value2}
                                            setValue2={setValue2}
                                            onBackToEdit={() => { invoiceId ? setActiveTab('Edit') : setActiveTab('Create') }}
                                            ref={null}
                                            selectedTemp={formData.templateName}
                                            selectedId={
                                                formData.logoId
                                                    ? { id: formData.logoId, logoImage: formData.logoImage }
                                                    : null
                                            }
                                            selectedSize={formData.logoSize}
                                            alignPos={formData.logoPosition}
                                            selectedColour={
                                                formData.colourId
                                                    ? { id: formData.colourId, colourCode: formData.colourCode }
                                                    : null
                                            }
                                            customColour={formData.customColour}
                                            selectedHeader={
                                                formData.headerId
                                                    ? { id: formData.headerId, headerImg: formData.headerImg }
                                                    : null
                                            }
                                            selectedWatermark={
                                                formData.waterMarkId
                                                    ? {
                                                        id: formData.waterMarkId,
                                                        waterMarkImg: formData.waterMarkImg,
                                                    }
                                                    : null
                                            }
                                            customTemplates={customTemplates}
                                            customOption={optionData}
                                            signatureName={sigInvoice}
                                            signatureType={signatureType}
                                            signature={{
                                                padSignature,
                                                uploadSignature,
                                                signatureText
                                            }}
                                            currencyList={currencyList}
                                        />
                                    )}

                                </div>
                            </div>
                            <div className='col-md-3'>
                                <div className='invoiceHeaderLeft'>
                                    <div className='invoiceSection'>
                                        <h5>Invoice</h5>
                                        <div className='invoiceSectionInner'>
                                            {!invoiceId && (
                                                <>
                                                    <h6 style={{ margin: 0, display: 'inline-block' }}>
                                                        {optionData.invoicePrifix ? optionData.invoicePrifix + '-' : ''}{!invoiceId && editInvoiceNumber ? '' : invoiceNumber}
                                                    </h6>
                                                    {editInvoiceNumber ? (
                                                        <div style={{ display: 'flex', alignItems: 'center' }}>
                                                            <input
                                                                className='input-form-control'
                                                                type="text"
                                                                value={invoiceNumberInput}
                                                                onChange={handleInvoiceNumberInputChange}
                                                                onBlur={handleInvoiceNumberInputBlur}
                                                                onKeyDown={handleInvoiceNumberInputKeyDown}
                                                                style={{
                                                                    width: 60,
                                                                    fontSize: 18,
                                                                    fontWeight: 600,
                                                                    border: '1px solid #047FFF',
                                                                    borderRadius: 4,
                                                                    padding: '2px 6px'
                                                                }}
                                                                autoFocus
                                                            />
                                                        </div>
                                                    ) : (
                                                        <>

                                                            <span style={{ marginLeft: 8, cursor: 'pointer' }} onClick={handleEditInvoiceNumber}>
                                                                <FontAwesomeIcon icon={faPenToSquare} />
                                                            </span>
                                                        </>
                                                    )}
                                                </>
                                            )}
                                            {invoiceId && (
                                                <h6 style={{ margin: 0, display: 'inline-block' }}>
                                                    {optionData.invoicePrifix ? optionData.invoicePrifix + '-' : ''}{invoiceNumber}
                                                </h6>
                                            )}
                                        </div>

                                        <p className='unsent'>{sentStatus === "sent" ? "Sent" : "Unsent"}</p>
                                    </div>

                                    <div className='invoiceBox'>
                                        <ul className='borderBottom'>
                                            <li>
                                                <p>Date</p>
                                                <span>{formatDate(invoiceDate)}</span>
                                            </li>
                                            <li>
                                                <p>Terms</p>
                                                <span>
                                                    {
                                                        TERMS_OPTIONS.find(opt => opt.value === terms)?.label || "None"
                                                    }
                                                </span>
                                            </li>
                                            <li>
                                                <p>Due-Date</p>
                                                <span>{formatDate(dueDate)}</span>
                                            </li>
                                        </ul>
                                    </div>

                                    {!deposit && (
                                        <button className='add-note' onClick={handleAddDepositOpen}>
                                            <FontAwesomeIcon icon={faSquarePlus} /> Add deposit request
                                        </button>
                                    )}
                                    {deposit && (
                                        <div style={{ marginBottom: 12 }}>
                                            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, marginTop: 12 }}>
                                                <strong style={{ fontSize: "14px" }}>
                                                    Deposit request
                                                    {deposit.type === 'percent' ? ` (${deposit.percentage}%)` : ''}
                                                </strong>
                                                <span style={{ marginLeft: 8, fontSize: 13, }}>₹{deposit.amount}</span>
                                            </div>
                                            <div style={{ fontSize: 13, color: '#888', display: "flex", justifyContent: "center" }}>
                                                Due: {deposit.dueDate} | Paid: ₹{deposit.paid}
                                            </div>
                                            <button
                                                className='add-note'
                                                style={{ marginLeft: 8, fontSize: 13, }}
                                                onClick={handleAddDepositOpen}
                                            >
                                                View deposit request
                                            </button>

                                        </div>
                                        // <div style={{ marginBottom: 12 }}>
                                        //     <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                                        //         <strong>
                                        //             Deposit request
                                        //             {deposit.type === 'percent' ? ` (${deposit.percentage}%)` : ''}
                                        //         </strong>
                                        //         <span>₹{deposit.amount}</span>
                                        //         <button
                                        //             className='add-note'
                                        //             style={{ marginLeft: 8, fontSize: 13, padding: '2px 8px' }}
                                        //             onClick={handleAddDepositOpen}
                                        //         >
                                        //             View deposit request
                                        //         </button>
                                        //     </div>
                                        //     <div style={{ fontSize: 13, color: '#888' }}>
                                        //         Due: {deposit.dueDate} | Paid: ₹{deposit.paid}
                                        //     </div>
                                        // </div>
                                    )}

                                    <div className='invoiceBox paymentMethod'>
                                        <h6>Payment Method</h6>
                                        <div className='select listBorder'>
                                            <div className='invoiveListLeft'>
                                                <div className='invoiveListLeftTop'>
                                                    <div className='imgTxt'>

                                                        <div className='invoiveListLeftImg'>
                                                            <img src={IMAGE.paypal} alt="" />
                                                        </div>
                                                        <div className='invoiveListLeftText'>
                                                            Paypal   <img src={IMAGE.exclamation_top} alt="" />
                                                        </div>
                                                    </div>

                                                    <div className='switchIcon'>
                                                        <ToggleButton
                                                            isToggled={value2}
                                                            onToggle={() => setValue2(prev => !prev)}
                                                        />
                                                    </div>
                                                </div>


                                                <div className='paymentRemainder'>
                                                    <div className='checkbox-previewmail borderBottom'>
                                                        <div className='checkbox-custom'>
                                                            <input type="checkbox" id="preview-mail" />
                                                            <label className="preview-mail">Send payment reminders</label>
                                                        </div>
                                                        <Link className='preview-mail' href="#">view</Link>
                                                    </div>

                                                    <h6 className='recInvoice'>Recurring Invoice</h6>
                                                    <ul className='borderBottom '>
                                                        <li>



                                                            <p>Due-Date</p>
                                                            <div className='select listBorder'>
                                                                <select
                                                                    className="form-select"
                                                                    aria-label="Default select example"
                                                                    value={terms}
                                                                    onChange={handleTermsChange}
                                                                >
                                                                    {TERMS_OPTIONS.map(opt => (
                                                                        <option key={opt.value} value={opt.value}>{opt.label}</option>
                                                                    ))}
                                                                </select>
                                                            </div>
                                                        </li>

                                                    </ul>
                                                </div>

                                            </div>

                                        </div>

                                    </div>

                                </div>
                            </div>
                        </div>
                    )}

                    {activeTab === 'Send' && (
                        <div className='row' style={{ position: "relative" }}>

                            <div className='col-md-9'>
                                {/* {console.log("previewRef :::", previewRef)
                                } */}
                                <div style={{ position: "absolute", left: "-9999px" }} >
                                    <div ref={previewRef}>
                                        {formData.templateName === 'impact' && (
                                            <CustomInvoiceImpact
                                                invoice={{
                                                    name: "Invoice",
                                                    invoiceNumber,
                                                    selectedClient,
                                                    invoiceDate,
                                                    dueDate,
                                                    items,
                                                    subtotal,
                                                    gstTotal,
                                                    discountTotal,
                                                    invoiceDiscountEditable,
                                                    total,
                                                    logo,
                                                    attachments,
                                                    paymentInstruction,
                                                    comment,
                                                    depositAmount: deposit,
                                                    terms
                                                }}
                                                logoFile={logo}
                                                photoFiles={attachments}
                                                editInvoiceNumber={editInvoiceNumber}
                                                invoiceNumberInput={invoiceNumberInput}
                                                handleInvoiceNumberInputChange={handleInvoiceNumberInputChange}
                                                handleInvoiceNumberInputBlur={handleInvoiceNumberInputBlur}
                                                handleInvoiceNumberInputKeyDown={handleInvoiceNumberInputKeyDown}
                                                handleEditInvoiceNumber={handleEditInvoiceNumber}
                                                handleTermsChange={handleTermsChange}
                                                value2={value2}
                                                setValue2={setValue2}
                                                onBackToEdit={() => { invoiceId ? setActiveTab('Edit') : setActiveTab('Create') }}
                                                ref={null}
                                                selectedTemp={formData.templateName}
                                                selectedId={
                                                    formData.logoId
                                                        ? { id: formData.logoId, logoImage: formData.logoImage }
                                                        : null
                                                }
                                                selectedSize={formData.logoSize}
                                                alignPos={formData.logoPosition}
                                                selectedColour={
                                                    formData.colourId
                                                        ? { id: formData.colourId, colourCode: formData.colourCode }
                                                        : null
                                                }
                                                customColour={formData.customColour}
                                                selectedHeader={
                                                    formData.headerId
                                                        ? { id: formData.headerId, headerImg: formData.headerImg }
                                                        : null
                                                }
                                                selectedWatermark={
                                                    formData.waterMarkId
                                                        ? {
                                                            id: formData.waterMarkId,
                                                            waterMarkImg: formData.waterMarkImg,
                                                        }
                                                        : null
                                                }
                                                customTemplates={customTemplates}
                                                customOption={optionData}
                                                signatureName={sigInvoice}
                                                signatureType={signatureType}
                                                signature={{
                                                    padSignature,
                                                    uploadSignature,
                                                    signatureText
                                                }}
                                                currencyList={currencyList}
                                            />
                                        )}
                                        {formData.templateName === 'classic' && (
                                            <CustomInvoiceImpact
                                                invoice={{
                                                    name: "Invoice",
                                                    invoiceNumber,
                                                    selectedClient,
                                                    invoiceDate,
                                                    dueDate,
                                                    items,
                                                    subtotal,
                                                    gstTotal,
                                                    discountTotal,
                                                    total,
                                                    logo,
                                                    attachments,
                                                    paymentInstruction,
                                                    comment,
                                                    depositAmount: deposit,
                                                    terms
                                                }}
                                                logoFile={logo}
                                                photoFiles={attachments}
                                                editInvoiceNumber={editInvoiceNumber}
                                                invoiceNumberInput={invoiceNumberInput}
                                                handleInvoiceNumberInputChange={handleInvoiceNumberInputChange}
                                                handleInvoiceNumberInputBlur={handleInvoiceNumberInputBlur}
                                                handleInvoiceNumberInputKeyDown={handleInvoiceNumberInputKeyDown}
                                                handleEditInvoiceNumber={handleEditInvoiceNumber}
                                                handleTermsChange={handleTermsChange}
                                                value2={value2}
                                                setValue2={setValue2}
                                                onBackToEdit={() => { invoiceId ? setActiveTab('Edit') : setActiveTab('Create') }}
                                                ref={null}
                                                selectedTemp={formData.templateName}
                                                selectedId={
                                                    formData.logoId
                                                        ? { id: formData.logoId, logoImage: formData.logoImage }
                                                        : null
                                                }
                                                selectedSize={formData.logoSize}
                                                alignPos={formData.logoPosition}
                                                selectedColour={
                                                    formData.colourId
                                                        ? { id: formData.colourId, colourCode: formData.colourCode }
                                                        : null
                                                }
                                                customColour={formData.customColour}
                                                selectedHeader={
                                                    formData.headerId
                                                        ? { id: formData.headerId, headerImg: formData.headerImg }
                                                        : null
                                                }
                                                selectedWatermark={
                                                    formData.waterMarkId
                                                        ? {
                                                            id: formData.waterMarkId,
                                                            waterMarkImg: formData.waterMarkImg,
                                                        }
                                                        : null
                                                }
                                                customTemplates={customTemplates}
                                                customOption={optionData}
                                                signatureName={sigInvoice}
                                                signatureType={signatureType}
                                                signature={{
                                                    padSignature,
                                                    uploadSignature,
                                                    signatureText
                                                }}
                                                currencyList={currencyList}
                                            />
                                        )}

                                        {formData.templateName === 'modern' && (
                                            <CustomInvoiceImpact
                                                invoice={{
                                                    name: "Invoice",
                                                    invoiceNumber,
                                                    selectedClient,
                                                    invoiceDate,
                                                    dueDate,
                                                    items,
                                                    subtotal,
                                                    gstTotal,
                                                    discountTotal,
                                                    total,
                                                    logo,
                                                    attachments,
                                                    paymentInstruction,
                                                    comment,
                                                    depositAmount: deposit,
                                                    terms
                                                }}
                                                logoFile={logo}
                                                photoFiles={attachments}
                                                editInvoiceNumber={editInvoiceNumber}
                                                invoiceNumberInput={invoiceNumberInput}
                                                handleInvoiceNumberInputChange={handleInvoiceNumberInputChange}
                                                handleInvoiceNumberInputBlur={handleInvoiceNumberInputBlur}
                                                handleInvoiceNumberInputKeyDown={handleInvoiceNumberInputKeyDown}
                                                handleEditInvoiceNumber={handleEditInvoiceNumber}
                                                handleTermsChange={handleTermsChange}
                                                value2={value2}
                                                setValue2={setValue2}
                                                onBackToEdit={() => { invoiceId ? setActiveTab('Edit') : setActiveTab('Create') }}
                                                ref={null}
                                                selectedTemp={formData.templateName}
                                                selectedId={
                                                    formData.logoId
                                                        ? { id: formData.logoId, logoImage: formData.logoImage }
                                                        : null
                                                }
                                                selectedSize={formData.logoSize}
                                                alignPos={formData.logoPosition}
                                                selectedColour={
                                                    formData.colourId
                                                        ? { id: formData.colourId, colourCode: formData.colourCode }
                                                        : null
                                                }
                                                customColour={formData.customColour}
                                                selectedHeader={
                                                    formData.headerId
                                                        ? { id: formData.headerId, headerImg: formData.headerImg }
                                                        : null
                                                }
                                                selectedWatermark={
                                                    formData.waterMarkId
                                                        ? {
                                                            id: formData.waterMarkId,
                                                            waterMarkImg: formData.waterMarkImg,
                                                        }
                                                        : null
                                                }
                                                customTemplates={customTemplates}
                                                customOption={optionData}
                                                signatureName={sigInvoice}
                                                signatureType={signatureType}
                                                signature={{
                                                    padSignature,
                                                    uploadSignature,
                                                    signatureText
                                                }}
                                                currencyList={currencyList}

                                            />
                                        )}

                                    </div>
                                </div>
                                <div className='mt-0 minScrollHeight'>
                                    <div className='sub-head'>
                                        <p className='subheading'>Bill To</p>
                                    </div>
                                    <div className='row ' >

                                    {/* <div className='email-setup' style={{ alignItems: 'flex-end', flexWrap: 'wrap' }}> */}
                                        <div className='col-lg-12'>
                                            
                                        <div className='email-setup-top px-2' style={{ display: 'flex', gap: 0, alignItems: 'center' }}>
                                            <div className="floating-label-group" style={{ marginBottom: 8, width: '80%', }}>
                                                <label className="floating-label">To</label>
                                                <div className='selectInputUser' style={{ display: 'flex', flexWrap: 'wrap', gap: 4, alignItems: 'center' }}>
                                                    {sendToEmails.map((email, idx) => (
                                                        <span key={idx} style={{
                                                            background: '#e6f0ff',
                                                            borderRadius: 12,
                                                            padding: '2px 8px',
                                                            marginRight: 4,
                                                            marginTop: 0,
                                                            display: 'flex',
                                                            alignItems: 'center'
                                                        }}>
                                                            {email}
                                                            <span
                                                                style={{ marginLeft: 4, cursor: 'pointer', color: '#047FFF' }}
                                                                onClick={() => handleRemoveEmail('to', idx)}
                                                            >
                                                                <FontAwesomeIcon icon={faCircleXmark} />
                                                            </span>
                                                        </span>
                                                    ))}
                                                    {/* <input type="text" id="billing-add" className="input-form-control input-logo" required /> */}
                                                    <input
                                                        type="text"
                                                        // id="billing-add"
                                                        className="input-form-control input-logo inputBorderNone"
                                                        required
                                                        style={{ minWidth: 120, flex: 1 }}
                                                        value={sendToInput}
                                                        onChange={e => setSendToInput(e.target.value)}
                                                        onKeyDown={e => handleEmailInputKeyDown(e, 'to')}
                                                        onBlur={() => handleAddEmail('to', sendToInput)}
                                                        placeholder={sendToEmails.length === 0 ? "Enter email" : ""}
                                                    />
                                                </div>
                                            </div>
                                            <div className='ccbc' style={{  width: '20%',display: 'flex', gap: 8, alignItems: 'center',paddingLeft:"20px",marginTop:"16px" }} >
                                            {/* <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginLeft: 8 }}> */}
                                            {!showCc && (
                                                <span
                                                    style={{ cursor: 'pointer', color: '#047FFF', fontWeight: 500 }}
                                                    onClick={() => setShowCc(true)}
                                                >Cc</span>
                                                )}
                                                {!showBcc && (
                                                    <span
                                                        style={{ cursor: 'pointer', color: '#047FFF', fontWeight: 500 }}
                                                        onClick={() => setShowBcc(true)}
                                                    >Bcc</span>
                                                )}
                                            </div>
                                        </div>

                                        <div className='bcccTop px-2' style={{width:"80%"}}>

                                            {showCc && (
                                                <div className="floating-label-group" style={{ marginBottom: 8 }}>
                                                    <label className="floating-label">Cc</label>
                                                    <div className="selectInputUser" style={{ display: 'flex', flexWrap: 'wrap', gap: 4,alignItems: 'center' }}>
                                                        {sendCcEmails.map((email, idx) => (
                                                            <span key={idx} style={{
                                                                background: '#e6f0ff',
                                                                borderRadius: 12,
                                                                padding: '2px 8px',
                                                                marginRight: 4,
                                                                marginTop: 0,
                                                                display: 'flex',
                                                                alignItems: 'center'
                                                            }}>
                                                                {email}
                                                                <span
                                                                    style={{ marginLeft: 4, cursor: 'pointer', color: '#047FFF' }}
                                                                    onClick={() => handleRemoveEmail('cc', idx)}
                                                                >
                                                                    <FontAwesomeIcon icon={faCircleXmark} />
                                                                </span>
                                                            </span>
                                                        ))}
                                                        <input
                                                            type="text"
                                                            className="input-form-control input-logo inputBorderNone"
                                                            style={{ minWidth: 120, flex: 1 }}
                                                            value={sendCcInput}
                                                            onChange={e => setSendCcInput(e.target.value)}
                                                            onKeyDown={e => handleEmailInputKeyDown(e, 'cc')}
                                                            onBlur={() => handleAddEmail('cc', sendCcInput)}
                                                            placeholder={sendCcEmails.length === 0 ? "Enter email" : ""}
                                                        />
                                                    </div>
                                                </div>
                                            )}
                                            {showBcc && (
                                                <div className="floating-label-group" style={{ marginBottom: 8 }}>
                                                    <label className="floating-label">Bcc</label>
                                                    <div className="selectInputUser" style={{ display: 'flex', flexWrap: 'wrap', gap: 4,alignItems: 'center' }}>
                                                        {sendBccEmails.map((email, idx) => (
                                                            <span key={idx} style={{
                                                                background: '#e6f0ff',
                                                                borderRadius: 12,
                                                                padding: '2px 8px',
                                                                marginRight: 4,
                                                                marginTop: 0,
                                                                display: 'flex',
                                                                alignItems: 'center'
                                                            }}>
                                                                {email}
                                                                <span
                                                                    style={{ marginLeft: 4, cursor: 'pointer', color: '#047FFF' }}
                                                                    onClick={() => handleRemoveEmail('bcc', idx)}
                                                                >
                                                                    <FontAwesomeIcon icon={faCircleXmark} />
                                                                </span>
                                                            </span>
                                                        ))}
                                                        <input
                                                            type="text"
                                                            className="input-form-control input-logo inputBorderNone"
                                                            style={{ minWidth: 120, flex: 1 }}
                                                            value={sendBccInput}
                                                            onChange={e => setSendBccInput(e.target.value)}
                                                            onKeyDown={e => handleEmailInputKeyDown(e, 'bcc')}
                                                            onBlur={() => handleAddEmail('bcc', sendBccInput)}
                                                            placeholder={sendBccEmails.length === 0 ? "Enter email" : ""}
                                                        />
                                                    </div>
                                                </div>
                                            )}
                                        </div>

                                        </div>
                                       
                                    </div>
                                    <div className='sub-head'>
                                        <p className='subheading'>Service</p>
                                    </div>
                                    <div className='col-lg-12 col-md-12 col-sm-12'>
                                        <div className="floating-label-group px-2">
                                            <label className="floating-label">Notes</label>
                                            <textarea
                                                type="text"
                                                id="logo"
                                                className="input-form-control"
                                                required
                                                value={sendNotes}
                                                onChange={e => setSendNotes(e.target.value)}
                                            />
                                        </div>
                                    </div>
                                    <div className='sub-head'>
                                        <p className='subheading'>Attachment</p>
                                    </div>
                                    <div className="row px-2">
                                        <div className="col-lg-3">
                                            <div className="card image-card pdfParaMargin ">
                                                <div className="card-body">
                                                    {/* Preview PDF is automatically attached */}
                                                    <div>
                                                        <p>
                                                            <FontAwesomeIcon icon={faFilePdf} style={{ fontSize: 60, color: '#d32f2f', marginBottom: 8, width: 60, height: 60 }} /><br />
                                                            invoice_<span>{invoiceNumber}</span>
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        {sendText === "true" && parameter?.attachmentName && <div className="col-lg-3">
                                            <div className="card image-card pdfParaMargin">
                                                <div className="card-body">
                                                    <div>
                                                        <p>
                                                            {
                                                                parameter?.attachmentType.includes("image") ? <FontAwesomeIcon icon={faFileImage} style={{ fontSize: 60, color: '#d32f2f', marginBottom: 8, width: 60, height: 60 }} />
                                                                    : <FontAwesomeIcon icon={faFilePdf} style={{ fontSize: 60, color: '#d32f2f', marginBottom: 8, width: 60, height: 60 }} />
                                                            }
                                                            <br />
                                                            <span>{parameter?.attachmentName}</span>
                                                        </p>
                                                    </div>

                                                    {/* {parameter?.attachmentName?.type} */}
                                                </div>
                                            </div>
                                        </div>}
                                        {attachments.map((img, idx) => (
                                            <div className="col-lg-3" key={idx}>
                                                <div className="card image-card pdfParaMargin">
                                                    <div className="card-body">
                                                        <img
                                                            src={img}
                                                            alt={`Attachment ${idx + 1}`}
                                                            style={{
                                                                width: 80,
                                                                height: 80,
                                                                objectFit: "cover",
                                                                borderRadius: 6,
                                                                border: "1px solid #eee"
                                                            }}
                                                        />
                                                    </div>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>
                            <div className='col-md-3'>
                                <div className='invoiceHeaderLeft'>
                                    <div className='invoiceSection'>
                                        <h5>Invoice</h5>
                                        <div className='invoiceSectionInner'>
                                            {!invoiceId && (
                                                <>
                                                    <h6 style={{ margin: 0, display: 'inline-block' }}>
                                                        {optionData.invoicePrifix ? optionData.invoicePrifix + '-' : ''}{!invoiceId && editInvoiceNumber ? '' : invoiceNumber}
                                                    </h6>
                                                    {editInvoiceNumber ? (
                                                        <input className='input-form-control'
                                                            type="text"
                                                            value={invoiceNumberInput}
                                                            onChange={handleInvoiceNumberInputChange}
                                                            onBlur={handleInvoiceNumberInputBlur}
                                                            onKeyDown={handleInvoiceNumberInputKeyDown}
                                                            style={{
                                                                width: 60,
                                                                fontSize: 18,
                                                                fontWeight: 600,
                                                                border: '1px solid #047FFF',
                                                                borderRadius: 4,
                                                                padding: '2px 6px'
                                                            }}
                                                            autoFocus />
                                                    ) : (
                                                        <>
                                                            <span style={{ marginLeft: 8, cursor: 'pointer' }} onClick={handleEditInvoiceNumber}>
                                                                <FontAwesomeIcon icon={faPenToSquare} />
                                                            </span>
                                                        </>
                                                    )}
                                                </>
                                            )}
                                            {invoiceId && (
                                                <h6 style={{ margin: 0, display: 'inline-block' }}>{optionData.invoicePrifix ? optionData.invoicePrifix + '-' : ''}{invoiceNumber}</h6>
                                            )}
                                        </div>
                                        <p className='unsent'>{sentStatus === "sent" ? "Sent" : "Unsent"}</p>
                                    </div>
                                    <div className='invoiceBox'>
                                        <ul className='borderBottom'>
                                            <li>
                                                <p>Date</p>
                                                <span>{formatDate(invoiceDate)}</span>
                                            </li>
                                            <li>
                                                <p>Terms</p>
                                                <span>
                                                    {
                                                        TERMS_OPTIONS.find(opt => opt.value === terms)?.label || "None"
                                                    }
                                                </span>
                                            </li>
                                            <li>
                                                <p>Due-Date</p>
                                                <span>{formatDate(dueDate)}</span>
                                            </li>
                                        </ul>
                                    </div>
                                    {!deposit && (
                                        <button className='add-note' onClick={handleAddDepositOpen}>
                                            <FontAwesomeIcon icon={faSquarePlus} /> Add deposit request
                                        </button>
                                    )}
                                    {deposit && (
                                        <div style={{ marginBottom: 12 }}>
                                            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, marginTop: 12 }}>
                                                <strong style={{ fontSize: "14px" }}>
                                                    Deposit request
                                                    {deposit.type === 'percent' ? ` (${deposit.percentage}%)` : ''}
                                                </strong>
                                                <span style={{ marginLeft: 8, fontSize: 13, }}>₹{deposit.amount}</span>
                                            </div>
                                            <div style={{ fontSize: 13, color: '#888', display: "flex", justifyContent: "center" }}>
                                                Due: {deposit.dueDate} | Paid: ₹{deposit.paid}
                                            </div>
                                            <button
                                                className='add-note'
                                                style={{ marginLeft: 8, fontSize: 13, }}
                                                onClick={handleAddDepositOpen}
                                            >
                                                View deposit request
                                            </button>
                                        </div>
                                    )}
                                    <div style={{ marginTop: 16 }}>
                                        <div className='' style={{ display: 'flex', gap: '8px' }}>
                                            <div style={{ flex: 1 }}>
                                                {/* {console.log(previewRef, "previewRef", previewPdfFile)} */}
                                                <Button className='add-note' onClick={handleSendPdf} disabled={!previewPdfFile && !previewRef.current} style={{ width: '100%' }}>
                                                    Send Invoice
                                                </Button>
                                            </div>
                                            <div style={{ flex: 1 }}>
                                                <Button className='add-note' onClick={handleDownloadPdf} disabled={!previewPdfFile && !previewRef.current} style={{ width: '100%' }}>
                                                    Download Slip
                                                </Button>
                                            </div>
                                        </div>
                                    </div>
                                    {/* Payment Method panel as before */}
                                    <div className='invoiceBox paymentMethod'>
                                        <h6>Payment Method</h6>
                                        <div className='select listBorder'>
                                            <div className='invoiveListLeft'>
                                                <div className='invoiveListLeftTop'>
                                                    <div className='imgTxt'>
                                                        <div className='invoiveListLeftImg'>
                                                            <img src={IMAGE.paypal} alt="" />
                                                        </div>
                                                        <div className='invoiveListLeftText'>
                                                            Paypal   <img src={IMAGE.exclamation_top} alt="" />
                                                        </div>
                                                    </div>
                                                    <div className='switchIcon'>
                                                        <ToggleButton
                                                            isToggled={value2}
                                                            onToggle={() => setValue2(prev => !prev)}
                                                        />
                                                    </div>
                                                </div>
                                                <div className='paymentRemainder'>
                                                    <div className='checkbox-previewmail borderBottom'>
                                                        <div className='checkbox-custom'>
                                                            <input type="checkbox" id="preview-mail" />
                                                            <label className="preview-mail">Send payment reminders</label>
                                                        </div>
                                                        <Link className='preview-mail' href="#">view</Link>
                                                    </div>
                                                    <h6 className='recInvoice'>Recurring Invoice</h6>
                                                    <ul className='borderBottom '>
                                                        <li>
                                                            <p>Due-Date</p>
                                                            <div className='select listBorder'>
                                                                <select
                                                                    className="form-select"
                                                                    aria-label="Default select example"
                                                                    value={terms}
                                                                    onChange={handleTermsChange}
                                                                >
                                                                    {TERMS_OPTIONS.map(opt => (
                                                                        <option key={opt.value} value={opt.value}>{opt.label}</option>
                                                                    ))}
                                                                </select>
                                                            </div>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}

                </div>
            </div>

    
                <Modal centered show={showClientModal} onHide={handleCloseClientModal}>
                    <Modal.Header closeButton>
                        <Modal.Title>Add Client</Modal.Title>
                    </Modal.Header>
                    <Modal.Body style={{ marginTop: '0px' }}>
                        <div className="mb-3">
                            <div className="floating-label-group mb-2" style={{ position: 'relative' }}>
                                <label className="floating-label">Name</label>
                                <input
                                    type="text"
                                    name="name"
                                    className="input-form-control"
                                    required
                                    autoComplete="off"
                                    autoFocus
                                    value={clientForm.name}
                                    onChange={handleClientFormChange}
                                    onFocus={() => {
                                        setShowClientDropdown(true);
                                        if (clientForm.name.trim().length === 0) setClientDropdown(clientList);
                                    }}
                                    onBlur={() => setTimeout(() => setShowClientDropdown(false), 200)}
                                />
                                {showClientDropdown && clientDropdown.length > 0 && (
                                    <ul className="list-group" style={{
                                        position: 'absolute',
                                        zIndex: 10,
                                        width: '100%',
                                        top: '100%',
                                        left: 0,
                                        maxHeight: 150,
                                        overflowY: 'auto'
                                    }}>
                                        {clientDropdown.map((client, idx) => (
                                            <li
                                                key={client.id || idx}
                                                className="list-group-item"
                                                style={{ cursor: 'pointer' }}
                                                onMouseDown={() => {
                                                    handleClientDropdownSelect(client);
                                                }}
                                            >
                                                <strong>{client.name}</strong>
                                                <div style={{ fontSize: '0.9em', color: '#888' }}>{client.email}</div>
                                            </li>
                                        ))}
                                    </ul>
                                )}
                                {clientFormErrors.name && (
                                    <div style={{ color: 'red', fontSize: 13, marginTop: 2 }}>{clientFormErrors.name}</div>
                                )}
                            </div>
                            <div className="floating-label-group mb-2">
                                <label className="floating-label">Email</label>
                                <input
                                    type="email"
                                    name="email"
                                    className="input-form-control"
                                    required
                                    value={clientForm.email}
                                    onChange={handleClientFormChange}
                                />
                                {clientFormErrors.email && (
                                    <div style={{ color: 'red', fontSize: 13, marginTop: 2 }}>{clientFormErrors.email}</div>
                                )}
                            </div>
                            <div className="floating-label-group mb-2">
                                <label className="floating-label">Phone</label>
                                <input
                                    type="text"
                                    name="phone"
                                    className="input-form-control"
                                    required
                                    value={clientForm.phone}
                                    onChange={handleClientFormChange}
                                    maxLength={10}
                                />
                                {clientFormErrors.phone && (
                                    <div style={{ color: 'red', fontSize: 13, marginTop: 2 }}>{clientFormErrors.phone}</div>
                                )}
                            </div>
                            <Button
                                variant="primary"
                                className='modal-btn addBtnn'
                                style={{ marginTop: 25 }}
                                onClick={handleAddClientFromModal}
                            >
                                Add
                            </Button>
                        </div>
                    </Modal.Body>
                </Modal>
    
                {/* Add Item Modal */}
                <Modal centered
                    show={show}
                    onHide={handleClose}
                    onShow={async () => {
                        const result = await dispatch(fetchTaxData());
                        if (result && result.payload && Array.isArray(result.payload.data)) {
                            setTaxRates(result.payload.data);
                        } else {
                            setTaxRates([]);
                        }
                    }}
                >
                    <Modal.Header closeButton>
                        <Modal.Title>{editItemIndex !== null ? "Edit Item" : "Add Item"}</Modal.Title>
                    </Modal.Header>
                    <Modal.Body className='mt-0 mb-0'>
                        <div style={{ textAlign: 'center' }}>
                            <button className='add-note' type="button" onClick={handleChooseItemOpen}>
                                <FontAwesomeIcon icon={faSquarePlus} />Choose Multiple
                            </button>
                        </div>
                        <div style={{ textAlign: 'center', margin: '12px 0 0px' }}>Or</div>
                        <div className="row">
                            <div className="col-lg-12">
                                {optionData.itemCode && (
                                    <div className="floating-label-group mb-3">
                                        <label className="floating-label">Item Code</label>
                                        <input
                                            type="text"
                                            name="code"
                                            className="input-form-control"
                                            required
                                            value={itemForm.code}
                                            onChange={handleItemFormChange}
                                        />
                                    </div>
                                )}
                                <div className="floating-label-group mb-3">
                                    <label className="floating-label">Item Name</label>
                                    <input
                                        type="text"
                                        name="name"
                                        className="input-form-control"
                                        required
                                        value={itemForm.name}
                                        onChange={handleItemFormChange}
                                    />
                                    {itemFormErrors.name && (
                                        <div style={{ color: "red", fontSize: 13, marginTop: 2 }}>{itemFormErrors.name}</div>
                                    )}
                                </div>
    
                                <div className="floating-label-group mb-3">
                                    <label className="floating-label">Description</label>
                                    <textarea
                                        name="description"
                                        className="input-form-control"
                                        value={itemForm.description}
                                        onChange={handleItemFormChange}
                                        rows="3"
                                    />
                                </div>
                                <div style={{ display: 'flex', gap: 16, marginBottom: 16 }}>
                                    <div style={{ flex: 1 }}>
                                        <div className="floating-label-group">
                                            <label className="floating-label">Rate</label>
                                            <input
                                                type="number"
                                                name="rate"
                                                className="small-input input-form-control"
                                                required
                                                value={itemForm.rate}
                                                onChange={handleItemFormChange}
                                                min="0"
                                            />
                                            {itemFormErrors.rate && (
                                                <div style={{ color: "red", fontSize: 13, marginTop: 2 }}>{itemFormErrors.rate}</div>
                                            )}
                                        </div>
                                    </div>
                                    <div style={{ flex: 1 }}>
                                        <div className="floating-label-group">
                                            <label className="floating-label">Qty</label>
                                            <input
                                                type="number"
                                                name="quantity"
                                                className="small-input input-form-control"
                                                required
                                                value={itemForm.quantity}
                                                onChange={handleItemFormChange}
                                                min="1"
                                                max="9999999999"
                                            />
                                            {itemFormErrors.quantity && (
                                                <div style={{ color: "red", fontSize: 13, marginTop: 2 }}>{itemFormErrors.quantity}</div>
                                            )}
                                        </div>
                                    </div>
    
                                    <div style={{ flex: 1 }}>
                                        <div className="floating-label-group payment-type-dropdown">
                                            <label className="floating-label">Unit</label>
                                            <select
                                                className="small-input input-form-control"
                                                value={itemForm.unitTypes}
                                                onChange={(e) => setItemForm({ ...itemForm, unitTypes: e.target.value })}
                                                style={{ minWidth: 120, marginLeft: 0 }}
                                            >
                                                <option value="">Select Unit</option>
                                                {unitTypes.map((unit) => (
                                                    <option key={unit.id} value={unit.value}>
                                                        {unit.value}
                                                    </option>
                                                ))}
                                            </select>
                                        <p className="dropdownIcon">
                                                <img src={IMAGE.dropdownColor}  />
                                            </p>
                                        </div>
                                    </div>
                                </div>
    
    
    
                                {/* GST Section */}
                                <Accordion defaultActiveKey="0">
                                    <Accordion.Item eventKey="0">
                                        <Accordion.Header>
                                            <p className='accorheading'>GST, Discount</p>
                                        </Accordion.Header>
                                        <Accordion.Body>
                                            <div style={{ display: 'flex', gap: 16, alignItems: 'center', marginBottom: 16 }}>
                                                <div className="col-lg-12" style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
                                                    <div className='checkboxLeft' style={{ display: 'flex', alignItems: 'center' }}>
                                                        <input
                                                            type="checkbox"
                                                            name="gstChecked"
                                                            checked={(itemForm.gstChecked == 'false' || itemForm.gstChecked == false) ? false : true}
                                                            onChange={handleItemGstCheck}
                                                            id="gstCheck"
                                                        />
                                                        <label htmlFor="gstCheck" style={{ marginLeft: 8 }}>GST</label>
                                                    </div>
                                                    {(itemForm.gstChecked == 'true' || itemForm.gstChecked == true) && (
                                                        <div className="form-group payment-type-dropdown" style={{ margin: 0 }}>
                                                            <select
                                                                className="small-input input-form-control"
                                                                value={itemForm.gstValue}
                                                                onChange={(e) => setItemForm({ ...itemForm, gstValue: e.target.value })}
                                                                style={{ minWidth: 120, marginLeft: 8 }}
                                                            >
                                                                <option value="">Select Rate</option>
                                                                {taxRates.map((rate) => (
                                                                    <option key={rate.id} value={rate.percentage}>
                                                                        {rate.percentage}%
                                                                    </option>
                                                                ))}
                                                            </select>
                                                            <p className="dropdownIcon drpdwnLable">
                                                                <img src={IMAGE.dropdownColor}  />
                                                            </p>
                                                        </div>
                                                    )}
                                                </div>
                                            </div>
    
                                            {/* Discount Section */}
                                            {/* <div className="col-lg-12 mt-3"> */}
                                            <div style={{ display: 'flex', gap: 16, alignItems: 'center', marginBottom: 16 }}>
                                                <div className='checkboxLeft'>
                                                    <input
                                                        type="checkbox"
                                                        name="discountChecked"
                                                        checked={(itemForm.discountChecked == 'false' || itemForm.discountChecked == false) ? false : true}
                                                        onChange={handleItemDiscountCheck}
                                                        id="discountCheck"
                                                    />
                                                    <label htmlFor="discountCheck" style={{ marginLeft: 8 }}>Discount</label>
                                                </div>
                                                {(itemForm.discountChecked == 'true' || itemForm.discountChecked == true) && (
                                                    <div className='checkboxRight ' style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                                                    <div className='payment-type-dropdown'> 
                                                        <select
                                                            name="discountType"
                                                            value={itemForm.discountType}
                                                            onChange={handleItemFormChange}
                                                            style={{ height: 47 }}
                                                            className='input-form-control'
                                                        >
                                                            {DISCOUNT_TYPE_OPTIONS.map(opt => (
                                                                <option key={opt.value} value={opt.value}>{opt.label}</option>
                                                            ))}
                                                        </select>
    
                                                        <p className="dropdownIcon drpdwnLable flatRate">
                                                            <img src={IMAGE.dropdownColor}  />
                                                        </p>
    
                                                        </div>
    
                                                        <input
                                                            type="number"
                                                            name="discountValue"
                                                            className="small-input input-form-control"
                                                            required
                                                            value={itemForm.discountValue}
                                                            onChange={handleItemFormChange}
                                                            min="0"
                                                            style={{ width: 70 }}
                                                        />
                                                        {itemForm.discountType === "percentage" ? <span>%</span> : <span>₹</span>}
                                                    </div>
                                                )}
                                            </div>
                                            {/* </div> */}
    
                                        </Accordion.Body>
                                    </Accordion.Item>
                                </Accordion>
                                <button className='modal-btn addBtnn' onClick={handleSaveItem}>
                                    {editItemIndex !== null ? "Update" : "Add"}
                                </button>
                            </div>
                        </div>
                    </Modal.Body>
                </Modal>
    
                {/* Choose Item Modal */}
                <Modal centered show={showChooseItemModal} onHide={handleChooseItemClose}>
    
                    <Modal.Header closeButton>
                        <span
                            style={{ cursor: 'pointer', marginRight: 12 }}
                            onClick={handleBackClick}
                        >
                            <FontAwesomeIcon icon={faArrowLeft} />
                        </span>
                        <Modal.Title>Choose Items</Modal.Title>
                    </Modal.Header>
    
                    <Modal.Body style={{ marginTop: '0px' }} className='listingSearchMain'>
                        {filteredChooseItemList.length === 0 ? (
                            <div>There are no items added yet. <span style={{ cursor: 'pointer', color: '#007bff' }} onClick={handleBackClick}>Click here</span> to add items.</div>
    
                        ) : (
                            <>
                                <div className="d-flex justify-content-end mb-3 searchCustom">
                                    <input
                                        type="text"
                                        className="search-input-retains-placeholder form-control"
                                        style={{
                                            width: '125px',
                                            borderRadius: '12px',
                                            boxShadow: '0 2px 6px rgba(0,0,0,0.1)',
                                            border: '1px solid #ccc',
                                        }}
                                        placeholder="🔍︎ Search here..."
                                        value={itemSearch}
                                        autoFocus
                                        onChange={e => setItemSearch(e.target.value)}
                                        onFocus={() => setFocused(true)}
                                        onBlur={() => setFocused(false)}
                                    />
                                </div>
                                <ul className="list-group" style={{ marginBottom: '20px' }}>
                                    {filteredChooseItemList.map((item, idx) => {
                                        const checked = !!chooseSelectedItems.find(i => i.id === item.id);
                                        return (
                                            <li
                                                key={item.id || idx}
                                                className="list-group-item"
                                                style={{ cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}
                                                // onClick={() => handleChooseItemToggle(item)}
                                            >
                                            <div className='listingDetails'>
                                                <label htmlFor={'itemOfItems' + idx} className='listingDetails' style={{ display: "flex", gap: "5px", alignItems: "center" }}>
                                                    <input
                                                        type="checkbox"
                                                        id={"itemOfItems" + idx}
                                                        checked={checked}
                                                        onChange={() => handleChooseItemToggle(item)}
                                                        style={{ marginRight: 8 }}
                                                    />
                                                    <div style={{ display: "flex", flexDirection: "column", gap: "2px", justifyContent: "center" }}>
                                                        <strong>{item.name || item.item_name}</strong>
                                                        <span className='modalDescrptn' style={{ fontSize: '0.9em', color: '#888', marginLeft: '0 !important' }}>
                                                            {(() => {
                                                                const maxLen = 40;
                                                                const description = item?.item_Description ?? item?.description ?? '';
                                                                return description.length > maxLen
                                                                    ?  description.slice(0, maxLen) + '...'
                                                                    : description;
                                                            })()}
                                                        </span>
                                                    </div>
                                                </label>
                                            </div>
                                            {checked && (
                                            <span
                                                style={{ color: '#047FFF', cursor: 'pointer', marginLeft: 8 }}
                                                onClick={e => { e.stopPropagation(); handleChooseSelectedDelete(item.id); }}
                                            >
                                            </span>
                                            )}
                                            </li>
                                        );
                                    })}
                                </ul>
                            </>
                        )}
                    </Modal.Body>
                    <Modal.Footer className='pt-0'>
                        {filteredChooseItemList.length > 0 && (
                            <Button variant="primary" className='modal-btn addBtnn mt-0 mb-0' onClick={handleChooseItemSave} disabled={chooseSelectedItems.length === 0}>
                                Add
                            </Button>
                        )}
                    </Modal.Footer>
                </Modal>
    
                {/* Appointment Modal */}
                <Modal centered show={showAppointmentModal} onHide={handleAppointmentModalClose}>
                    <Modal.Header closeButton>
                        <Modal.Title>Add appointments</Modal.Title>
                    </Modal.Header>
                    <Modal.Body style={{ marginTop: '0px' }} className='listingSearchMain'>
                        {/* <div style={{ fontWeight: 600, marginBottom: 8 }}>{appointmentLabel}</div> */}
                        {groupedAppointments.length === 0 ? (
                            <div>No Appointments Found</div>
                        ) : (
                            <>
                                <div className="d-flex justify-content-end mb-3 searchCustom">
                                    <input
                                        type="text"
                                        className="search-input-retains-placeholder form-control"
                                        style={{
                                            width: '180px',
                                            borderRadius: '12px',
                                            boxShadow: '0 2px 6px rgba(0,0,0,0.1)',
                                            border: '1px solid #ccc',
                                        }}
                                        placeholder="🔍︎ Search appointments..."
                                        value={appointmentSearch}
                                        autoFocus
                                        onChange={e => setAppointmentSearch(e.target.value)}
                                    />
                                </div>
                                {groupedAppointments.map(group => (
                                    <div key={group.label}>
                                        <div style={{ fontWeight: 600, marginBottom: 8 }}>{group.label}</div>
                                        <ul className="list-group" style={{ marginBottom: '20px' }}>
                                            {group.appointments.map((app, idx) => {
                                                const checked = !!appointmentSelected.find(i => i.id === app.id);
                                                return (
                                                    <li
                                                        key={app.id || idx}
                                                        className="list-group-item"
                                                        style={{ cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}
                                                        // onClick={() => handleAppointmentToggle(app)}
                                                    >
                                                      <div className='listingDetails'>
                                                        <label htmlFor={'itemOfAppointments' + idx} className='listingDetails' style={{ display: "flex", gap: "5px", alignItems: "center" }}>

                                                            <input
                                                                type="checkbox"
                                                                id={'itemOfAppointments' + idx}
                                                                checked={checked}
                                                                onChange={() => handleAppointmentToggle(app)}
                                                                style={{ marginRight: 8 }}
                                                            />
                                                            <div style={{ display: "flex", flexDirection: "column", gap: "2px", justifyContent: "center" }}>

                                                                <strong>{formatAppointmentRow(app)}</strong>
                                                            </div>
                                                        </label>
                                                    </div>
                                                    </li>
                                                );
                                            })}
                                        </ul>
                                    </div>
                                ))}
                            </>
                        )}
                        <div style={{ textAlign: 'center', margin: '12px 0 0px' }}>Or</div>
                        <div style={{ textAlign: 'center', margin: '12px 0 8px' }}>
                            <button className='add-note' type="button" onClick={handleAddMoreAppointmentOpen}>
                                <FontAwesomeIcon icon={faSquarePlus} /> Add More
                            </button>
                        </div>
                    </Modal.Body>
                    <Modal.Footer className='pt-0'>
                        {groupedAppointments.length > 0 && (
                            <Button variant="primary" className='modal-btn addBtnn mt-0 mb-0' onClick={handleAppointmentAdd} disabled={appointmentSelected.length === 0}>
                                Add
                            </Button>
                        )}
    
                    </Modal.Footer>
                </Modal>
    
                <Modal centered show={showAddMoreAppointmentModal} onHide={handleAddMoreAppointmentClose}>
                    <Modal.Header closeButton>
                        <span
                            style={{ cursor: 'pointer', marginRight: 12 }}
                            onClick={handleAppointmentBackClick}
                        >
                            <FontAwesomeIcon icon={faArrowLeft} />
                        </span>
                        <Modal.Title>Add appointment</Modal.Title>
                    </Modal.Header>
                    <Modal.Body className='mt-0 mb-0'>
                        {addMoreAppointmentErrors.form && (
                            <div className="alert alert-danger mb-2">{addMoreAppointmentErrors.form}</div>
                        )}
    
                        {/* Show "Select contact" placeholder if no contact selected */}
                        <div className="floating-label-group mb-3-group mb-2">
                            <label>Choose Contacts</label>
                            <div
                                ref={toggleRef}
                                className='input-form-control'
                                style={{
                                    display: 'flex',
                                    flexWrap: 'wrap',
                                    gap: 4,
                                    minHeight: 38,
                                    border: '1px solid #047FFF80',
                                    borderRadius: 9,
                                    padding: '4px 32px 4px 4px', // add right padding for arrow space
                                    position: 'relative',
                                    cursor: 'pointer',
                                    alignItems: 'center',
                                    height: 'auto' // vertically center items
                                }}
                                tabIndex={0}
                                onClick={e => {
                                    e.stopPropagation();
                                    setShowContactsDropdown(prev => !prev);
                                }}
                            >
                                {/* Placeholder: show only if no contact selected and dropdown is closed */}
                                {(!addMoreAppointment.contact_id || addMoreAppointment.contact_id.length === 0) && (
                                    <span style={{ color: '#888', fontSize: 15, marginLeft: 10 }}>Select contact</span>
                                )}
    
                                {/* Selected contacts */}
                                {['primary', 'secondary'].map(type =>
                                    Array.isArray(addMoreAppointment.contacts[type]) &&
                                    addMoreAppointment.contacts[type]
                                        .filter(contact => (addMoreAppointment.contact_id || []).includes(contact.id))
                                        .map(contact => (
                                            <span
                                                key={contact.id}
                                                style={{
                                                    background: '#e6f0ff',
                                                    borderRadius: 12,
                                                    padding: '2px 8px',
                                                    marginRight: 4,
                                                    marginTop: 4,
                                                    display: 'inline-flex', // inline-flex for wrapping nicely
                                                    fontSize: '10px',
                                                    alignItems: 'center',
                                                    maxWidth: 'calc(100% - 40px)', // prevent overflow, leave space for arrow
                                                    whiteSpace: 'nowrap',
                                                    textOverflow: 'ellipsis',
                                                    overflow: 'hidden'
                                                }}
                                            >
                                                {contact.contact_name}
                                                <span
                                                    style={{ marginLeft: 4, cursor: 'pointer', color: '#047FFF' }}
                                                    onClick={e => {
                                                        e.stopPropagation();
                                                        setAddMoreAppointment(prev => ({
                                                            ...prev,
                                                            contact_id: (prev.contact_id || []).filter(id => id !== contact.id)
                                                        }));
                                                    }}
                                                >
                                                    <FontAwesomeIcon icon={faCircleXmark} />
                                                </span>
                                            </span>
                                        ))
                                )}
    
                                {/* Arrow icon fixed at right */}
                                <span
                                    style={{
                                        position: 'absolute',
                                        right: 8,
                                        top: '50%',
                                        transform: showContactsDropdown ? 'translateY(-50%) rotate(180deg)' : 'translateY(-50%) rotate(0deg)',
                                        fontSize: 18,
                                        color: '#888',
                                        pointerEvents: 'none', // so clicks pass through to container
                                        transition: 'transform 0.2s',
    
                                    }}
                                >
                                    <FontAwesomeIcon className='filterImage' icon={faAngleDown} />
                                </span>
    
                                {/* Dropdown for primary/secondary contacts */}
                                {showContactsDropdown && (
                                    <div
                                        ref={contactsDropdownRef}
                                        style={{
                                            position: 'absolute',
                                            top: '100%',
                                            left: 0,
                                            zIndex: 10,
                                            background: '#fff',
                                            border: '1px solid #ccc',
                                            borderRadius: 4,
                                            width: '100%',
                                            marginTop: 2,
                                            boxShadow: '0 2px 8px rgba(0,0,0,0.08)'
                                        }}
                                    >
                                        {/* Primary Contacts */}
                                        <div>
                                            <div style={{ fontWeight: 600, marginBottom: 4, marginTop: 4, paddingLeft: 8 }}>Primary Contacts</div>
                                            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, padding: '0 8px 8px 8px' }}>
                                                {Array.isArray(addMoreAppointment.contacts.primary) &&
                                                    addMoreAppointment.contacts.primary
                                                        .filter(c => c.is_primary)
                                                        .map(contact => {
                                                            const selected = (addMoreAppointment.contact_id || []).includes(contact.id);
                                                            return (
                                                                <div
                                                                    key={contact.id}
                                                                    onClick={e => {
                                                                        e.stopPropagation();
                                                                        setAddMoreAppointment(prev => ({
                                                                            ...prev,
                                                                            contact_id: selected
                                                                                ? prev.contact_id.filter(id => id !== contact.id)
                                                                                : [...(prev.contact_id || []), contact.id]
                                                                        }));
                                                                    }}
                                                                    style={{
                                                                        padding: '6px 12px',
                                                                        borderRadius: 8,
                                                                        border: selected ? '2px solid #047FFF' : '1px solid #ccc',
                                                                        background: selected ? '#e6f0ff' : '#fff',
                                                                        cursor: 'pointer',
                                                                        fontWeight: selected ? 600 : 400,
                                                                        color: selected ? '#047FFF' : '#333',
                                                                        marginBottom: 4
                                                                    }}
                                                                >
                                                                    {contact.contact_name}
                                                                </div>
                                                            );
                                                        })}
                                            </div>
                                        </div>
                                        {/* Secondary Contacts */}
                                        <div>
                                            <div style={{ fontWeight: 600, marginBottom: 4, marginTop: 4, paddingLeft: 8 }}>Secondary Contacts</div>
                                            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, padding: '0 8px 8px 8px' }}>
                                                {Array.isArray(addMoreAppointment.contacts.secondary) &&
                                                    addMoreAppointment.contacts.secondary
                                                        .filter(c => !c.is_primary)
                                                        .map(contact => {
                                                            const selected = (addMoreAppointment.contact_id || []).includes(contact.id);
                                                            return (
                                                                <div
                                                                    key={contact.id}
                                                                    onClick={e => {
                                                                        e.stopPropagation();
                                                                        setAddMoreAppointment(prev => ({
                                                                            ...prev,
                                                                            contact_id: selected
                                                                                ? prev.contact_id.filter(id => id !== contact.id)
                                                                                : [...(prev.contact_id || []), contact.id]
                                                                        }));
                                                                    }}
                                                                    style={{
                                                                        padding: '6px 12px',
                                                                        borderRadius: 8,
                                                                        border: selected ? '2px solid #047FFF' : '1px solid #ccc',
                                                                        background: selected ? '#e6f0ff' : '#fff',
                                                                        cursor: 'pointer',
                                                                        fontWeight: selected ? 600 : 400,
                                                                        color: selected ? '#047FFF' : '#333',
                                                                        marginBottom: 4
                                                                    }}
                                                                >
                                                                    {contact.contact_name}
                                                                </div>
                                                            );
                                                        })}
                                            </div>
                                        </div>
                                    </div>
                                )}
                            </div>
                        </div>
    
                        <div className="floating-label-group mb-3-group mb-2">
                            <label>Notes</label>
                            <textarea
                                name="notes"
                                className={`input-form-control${addMoreAppointmentErrors.notes ? ' is-invalid' : ''}`}
                                value={addMoreAppointment.notes}
                                onChange={handleAddMoreAppointmentChange}
                            />
                            {addMoreAppointmentErrors.notes && (
                                <div className="invalid-feedback">{addMoreAppointmentErrors.notes}</div>
                            )}
                        </div>
                        <div className="row mb-2">
                            <div className="col-6">
                                <div className="floating-label-group">
                                    <label>Start Date</label>
                                    <input
                                        type="date"
                                        name="start_date"
                                        className={`input-form-control${addMoreAppointmentErrors.start_date ? ' is-invalid' : ''}`}
                                        value={addMoreAppointment.start_date}
                                        onChange={handleAddMoreAppointmentChange}
                                        min={
                                            addMoreAppointment.end_date
                                                ? (() => {
                                                    const end = new Date(addMoreAppointment.end_date + "T" + (addMoreAppointment.end_time || "00:00"));
                                                    const minStart = new Date(end.getTime() - 24 * 60 * 60 * 1000);
                                                    return minStart.toISOString().slice(0, 10);
                                                })()
                                                : ""
                                        }
                                        max={
                                            addMoreAppointment.end_date
                                                ? addMoreAppointment.end_date
                                                : ""
                                        }
                                    />
                                    {addMoreAppointmentErrors.start_date && (
                                        <div className="invalid-feedback">{addMoreAppointmentErrors.start_date}</div>
                                    )}
                                </div>
                            </div>
                            <div className="col-6">
                                <div className="floating-label-group">
                                    <label>Start Time</label>
                                    <input
                                        type="time"
                                        name="start_time"
                                        className={`input-form-control${addMoreAppointmentErrors.start_time ? ' is-invalid' : ''}`}
                                        value={addMoreAppointment.start_time}
                                        onChange={handleAddMoreAppointmentChange}
                                    />
                                    {addMoreAppointmentErrors.start_time && (
                                        <div className="invalid-feedback">{addMoreAppointmentErrors.start_time}</div>
                                    )}
                                </div>
                            </div>
                        </div>
                        <div className="row mb-2">
                            <div className="col-6">
                                <div className="floating-label-group">
                                    <label>End Date</label>
                                    <input
                                        type="date"
                                        name="end_date"
                                        className={`input-form-control${addMoreAppointmentErrors.end_date ? ' is-invalid' : ''}`}
                                        value={addMoreAppointment.end_date}
                                        onChange={handleAddMoreAppointmentChange}
                                        min={addMoreAppointment.start_date || ""}
                                        max={
                                            addMoreAppointment.start_date
                                                ? (() => {
                                                    const start = new Date(addMoreAppointment.start_date + "T" + (addMoreAppointment.start_time || "00:00"));
                                                    const maxEnd = new Date(start.getTime() + 24 * 60 * 60 * 1000);
                                                    return maxEnd.toISOString().slice(0, 10);
                                                })()
                                                : ""
                                        }
                                    />
                                    {addMoreAppointmentErrors.end_date && (
                                        <div className="invalid-feedback">{addMoreAppointmentErrors.end_date}</div>
                                    )}
                                </div>
                            </div>
                            <div className="col-6">
                                <div className="floating-label-group">
                                    <label>End Time</label>
                                    <input
                                        type="time"
                                        name="end_time"
                                        className={`input-form-control${addMoreAppointmentErrors.end_time ? ' is-invalid' : ''}`}
                                        value={addMoreAppointment.end_time}
                                        onChange={handleAddMoreAppointmentChange}
                                    />
                                    {addMoreAppointmentErrors.end_time && (
                                        <div className="invalid-feedback">{addMoreAppointmentErrors.end_time}</div>
                                    )}
                                </div>
                            </div>
                        </div>
                        {/* Validation: End must be within 24hr of start */}
                        {addMoreAppointment.start_date && addMoreAppointment.end_date && (
                            (() => {
                                const start = new Date(addMoreAppointment.start_date + "T" + (addMoreAppointment.start_time || "00:00"));
                                const end = new Date(addMoreAppointment.end_date + "T" + (addMoreAppointment.end_time || "00:00"));
                                if (start && end && (end - start > 24 * 60 * 60 * 1000)) {
                                    return (
                                        <div className="alert alert-danger mt-2">
                                            Appointment duration cannot exceed 24 hours.
                                        </div>
                                    );
                                }
                                return null;
                            })()
                        )}
                    </Modal.Body>
                    <Modal.Footer>
                        <Button
                            variant="primary"
                            className='modal-btn addBtnn'
                            onClick={() => {
                                if (
    
                                    (!addMoreAppointment.contact_id.length && !selectedClient)
                                ) {
                                    toast.error("Please select a client or contact before adding an appointment");
                                    return;
                                }
                                handleAddMoreAppointmentAdd();
                            }}
                            disabled={
                                addMoreAppointmentLoading ||
                                // Prevent add if duration > 24hr
                                (() => {
                                    if (
                                        addMoreAppointment.start_date &&
                                        addMoreAppointment.end_date &&
                                        addMoreAppointment.start_time &&
                                        addMoreAppointment.end_time
                                    ) {
                                        const start = new Date(addMoreAppointment.start_date + "T" + addMoreAppointment.start_time);
                                        const end = new Date(addMoreAppointment.end_date + "T" + addMoreAppointment.end_time);
                                        return end - start > 24 * 60 * 60 * 1000 || end - start < 0;
                                    }
                                    return false;
                                })()
                            }
    
                        >
                            {addMoreAppointmentLoading ? "Adding..." : "Add"}
                        </Button>
                    </Modal.Footer>
                </Modal>
    
                {/* Time Entry Modal */}
                <Modal centered show={showTimeEntryModal} onHide={handleTimeEntryModalClose}>
                    <Modal.Header closeButton>
                        {addMoretime && (
                            <span
                                style={{ cursor: 'pointer', marginRight: 12 }}
                                onClick={handleTimeEntryBackClick}
                            >
                                <FontAwesomeIcon icon={faArrowLeft} />
                            </span>
                        )}
                        <Modal.Title>Add time entry</Modal.Title>
                    </Modal.Header>
                    <Modal.Body style={{ marginTop: '0px' }} className='listingSearchMain'>
                        {filteredTimeEntryList.length > 0 && !addMoretime &&
                            <div className="d-flex justify-content-end mb-3 searchCustom">
                                <input
                                    type="text"
                                    className="search-input-retains-placeholder form-control"
                                    style={{
                                        width: '180px',
                                        borderRadius: '12px',
                                        boxShadow: '0 2px 6px rgba(0,0,0,0.1)',
                                        border: '1px solid #ccc',
                                    }}
                                    placeholder="🔍︎ Search time entries..."
                                    value={timeEntrySearch}
                                    autoFocus
                                    onChange={e => setTimeEntrySearch(e.target.value)}
                                />
                            </div>
                        }
                        {!addMoretime &&
                            (filteredTimeEntryList.length === 0 ? (
                                <>
                                    <div>No Time Entries Found</div>
                                    <div style={{ textAlign: 'center', margin: '12px 0 0px' }}>Or</div>
                                    <button className='add-note' type="button" onClick={() => setAddMoreTime(true)}>
                                        <FontAwesomeIcon icon={faSquarePlus} />Add More
                                    </button>
                                </>
                            ) : (
                                <div>
                                    <ul className="list-group" style={{ marginBottom: '20px' }}>
                                        {filteredTimeEntryList.map((entry, idx) => {
                                            // Use a unique key for each entry: id if present, else task_id+idx
                                            const entryKey = entry.logs && entry.logs[0] && entry.logs[0].id
                                                ? entry.logs[0].id
                                                : (entry.task_id !== null ? entry.task_id : `null-${idx}`);
                                            // Selection logic:
                                            // For entries with task_id == null, select all with same client_id and logs[0].task_id == null
                                            let checked = false;
                                            if (entry.task_id === null) {
                                                checked = timeEntrySelected.some(e =>
                                                    e.task_id === null &&
                                                    e.client_id === entry.client_id &&
                                                    e.logs &&
                                                    e.logs[0] &&
                                                    entry.logs &&
                                                    entry.logs[0] &&
                                                    e.logs[0].id === entry.logs[0].id
                                                );
                                            } else {
                                                checked = timeEntrySelected.some(e =>
                                                    e.task_id === entry.task_id &&
                                                    e.project_id === entry.project_id &&
                                                    e.client_id === entry.client_id
                                                );
                                            }
                                            return (
                                                <li
                                                    key={entryKey}
                                                    className="list-group-item"
                                                    style={{ cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}
                                                    // onClick={() => {
                                                    //     if (entry.task_id === null) {
                                                    //         // Select/deselect all entries with task_id == null and same client_id
                                                    //         const isSelected = timeEntrySelected.some(e =>
                                                    //             e.task_id === null &&
                                                    //             e.client_id === entry.client_id &&
                                                    //             e.logs &&
                                                    //             e.logs[0] &&
                                                    //             entry.logs &&
                                                    //             entry.logs[0] &&
                                                    //             e.logs[0].id === entry.logs[0].id
                                                    //         );
                                                    //         if (isSelected) {
                                                    //             setTimeEntrySelected(prev =>
                                                    //                 prev.filter(e =>
                                                    //                     !(e.task_id === null &&
                                                    //                         e.client_id === entry.client_id &&
                                                    //                         e.logs &&
                                                    //                         e.logs[0] &&
                                                    //                         entry.logs &&
                                                    //                         entry.logs[0] &&
                                                    //                         e.logs[0].id === entry.logs[0].id)
                                                    //                 )
                                                    //             );
                                                    //         } else {
                                                    //             // Only add if not already present
                                                    //             setTimeEntrySelected(prev => {
                                                    //                 const already = prev.some(e =>
                                                    //                     e.task_id === null &&
                                                    //                     e.client_id === entry.client_id &&
                                                    //                     e.logs &&
                                                    //                     e.logs[0] &&
                                                    //                     entry.logs &&
                                                    //                     entry.logs[0] &&
                                                    //                     e.logs[0].id === entry.logs[0].id
                                                    //                 );
                                                    //                 if (already) return prev;
                                                    //                 return [...prev, entry];
                                                    //             });
                                                    //         }
                                                    //     } else {
                                                    //         // Normal toggle for entries with task_id
                                                    //         handleTimeEntryToggle(entry);
                                                    //     }
                                                    // }}
                                                >
                                                   <div className='listingDetails'>
                                                    <label htmlFor={'itemOfTasks' + idx} className='listingDetails' style={{ display: "flex", gap: "5px", alignItems: "center" }}>
                                                        <input
                                                            type="checkbox"
                                                            id={'itemOfTasks' + idx}
                                                            checked={checked}
                                                            onChange={e => {
                                                                e.stopPropagation();
                                                                if (entry.task_id === null) {
                                                                    // Select/deselect all entries with task_id == null and same client_id
                                                                    const isSelected = timeEntrySelected.some(e =>
                                                                        e.task_id === null &&
                                                                        e.client_id === entry.client_id &&
                                                                        e.logs &&
                                                                        e.logs[0] &&
                                                                        entry.logs &&
                                                                        entry.logs[0] &&
                                                                        e.logs[0].id === entry.logs[0].id
                                                                    );
                                                                    if (isSelected) {
                                                                        setTimeEntrySelected(prev =>
                                                                            prev.filter(e =>
                                                                                !(e.task_id === null &&
                                                                                    e.client_id === entry.client_id &&
                                                                                    e.logs &&
                                                                                    e.logs[0] &&
                                                                                    entry.logs &&
                                                                                    entry.logs[0] &&
                                                                                    e.logs[0].id === entry.logs[0].id)
                                                                            )
                                                                        );
                                                                    } else {
                                                                        setTimeEntrySelected(prev => {
                                                                            const already = prev.some(e =>
                                                                                e.task_id === null &&
                                                                                e.client_id === entry.client_id &&
                                                                                e.logs &&
                                                                                e.logs[0] &&
                                                                                entry.logs &&
                                                                                entry.logs[0] &&
                                                                                e.logs[0].id === entry.logs[0].id
                                                                            );
                                                                            if (already) return prev;
                                                                            return [...prev, entry];
                                                                        });
                                                                    }
                                                                } else {
                                                                    handleTimeEntryToggle(entry);
                                                                }
                                                            }}
                                                            style={{ marginRight: 8 }}
                                                        />
                                                        <div style={{ display: "flex", flexDirection: "column", gap: "2px", justifyContent: "center" }}>
                                                            <strong>
                                                                {entry.taskName
                                                                    ? `${entry.projectName || entry.client_name} - ${entry.taskName} - ${entry.totalTime}`
                                                                    : `${entry.projectName || entry.client_name} - ${entry.totalTime}`}
                                                            </strong>
                                                            <span style={{ fontSize: '0.9em', color: '#888', marginLeft: 0 }}>
                                                                {entry.taskDescription}
                                                            </span>
                                                        </div>
                                                    </label>
                                                </div>
                                                </li>
                                            );
                                        })}
                                    </ul>
                                    <div style={{ textAlign: 'center', margin: '12px 0 0px' }}>Or</div>
                                    <button className='add-note' type="button" onClick={() => setAddMoreTime(true)}>
                                        <FontAwesomeIcon icon={faSquarePlus} />Add More
                                    </button>
                                </div>
                            ))}
                        {addMoretime &&
                            <div className='row'>
                                <div className='col-lg-12'>
                                    <div className="floating-label-group mb-3">
                                        <label className="floating-label">Note</label>
                                        <textarea
                                            name="notes"
                                            className="input-form-control"
                                            required
                                            value={addMoreLog.notes}
                                            onChange={(e) => setAddMoreLog(prev => ({ ...prev, notes: e.target.value }))}
                                        />
                                    </div>
                                </div>
                                <div className='col-lg-6'>
                                    <div className="flex flex-col gap-4">
                                        <div>
                                            <label>Start Time</label>
                                            <DatePicker
                                                selected={addMoreLog?.start_time}
                                                onChange={(date) => setAddMoreLog(prev => ({ ...prev, start_time: date }))}
                                                showTimeSelect
                                                showTimeSelectOnly
                                                timeIntervals={15}
                                                timeCaption="Time"
                                                dateFormat="HH:mm"
                                                className=" p-2 rounded input-form-control"
                                            />
                                        </div>
                                    </div>
                                </div>
                                <div className='col-lg-6'>
                                    <div className="flex flex-col gap-4">
                                        <div>
                                            <label>End Time</label>
                                            <DatePicker
                                                selected={addMoreLog?.end_time}
                                                onChange={(date) => setAddMoreLog(prev => ({ ...prev, end_time: date }))}
                                                showTimeSelect
                                                showTimeSelectOnly
                                                timeIntervals={15}
                                                timeCaption="Time"
                                                dateFormat="HH:mm"
                                                className=" p-2 rounded input-form-control"
                                            />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        }
                    </Modal.Body>
                    <Modal.Footer className='pt-0'>
                        {filteredTimeEntryList.length > 0 || addMoretime && (
                            <Button variant="primary" className='modal-btn addBtnn mt-0 mb-0' onClick={handleTimeEntryAdd} disabled={(!addMoretime && timeEntrySelected.length === 0) || (addMoretime && (!addMoreLog.notes || !addMoreLog.start_time || !addMoreLog.end_time || !selectedClient?.id))}>
                                Add
                            </Button>
                        )}
    
                    </Modal.Footer>
                </Modal>
    
                {/* Add More Expenses Modal */}
                <Modal centered show={showExpenseModal} onHide={handleExpenseModalClose}>
                    <Modal.Header closeButton>
                        <Modal.Title>Add expenses </Modal.Title>
                    </Modal.Header>
                    <Modal.Body style={{ marginTop: '0px' }} className='listingSearchMain'>
                        {/* <div style={{ fontWeight: 600, marginBottom: 8 }}>{appointmentLabel}</div> */}
                        {expenseFlatList.length === 0 ? (
                            <div>No expenses Found</div>
                        ) : (
                            <>
                                <div className="d-flex justify-content-end mb-3 searchCustom">
                                    <input
                                        type="text"
                                        className="search-input-retains-placeholder form-control"
                                        style={{
                                            width: '180px',
                                            borderRadius: '12px',
                                            boxShadow: '0 2px 6px rgba(0,0,0,0.1)',
                                            border: '1px solid #ccc',
                                        }}
                                        placeholder="🔍︎ Search expenses..."
                                        value={expenseSearch}
                                        autoFocus
                                        onChange={e => setExpenseSearch(e.target.value)}
                                    />
                                </div>
    
                                {expenseFlatList?.map(group => (
                                    <div key={group?.catagory}>
                                        <div style={{ fontWeight: 600, marginBottom: 8 }}>{group.catagory}</div>
                                        <ul className="list-group" style={{ marginBottom: '20px' }}>
                                            {group?.expenses.map((app, idx) => {
                                                const checked = !!expenseSelected.find(i => i.id === app.id);
                                                return (
                                                    <li
                                                        key={app.id || idx}
                                                        className="list-group-item"
                                                        style={{ cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}
                                                        // onClick={() => handleExpenseToggle(app)}
                                                    >
                                                          <div className='listingDetails'>
                                                        <label htmlFor={'itemOfExpenses' + idx} className='listingDetails' style={{ display: "flex", gap: "5px", alignItems: "center" }}>
                                                            <input
                                                                type="checkbox"
                                                                id={'itemOfExpenses' + idx}
                                                                checked={checked}
                                                                onChange={() => handleExpenseToggle(app)}
                                                                style={{ marginRight: 0 }}
                                                            />
                                                            <div style={{ display: "flex", flexDirection: "column", gap: "2px", justifyContent: "center" }}>
                                                                <strong>{`${app?.merchant}-${app?.HSN || app?.SAC} - $${app?.rate}`}</strong>
                                                            </div>
                                                        </label>
                                                    </div>
                                                    </li>
                                                );
                                            })}
                                        </ul>
                                    </div>
                                ))}
                            </>
                        )}
                        <div style={{ textAlign: 'center', margin: '12px 0 0px' }}>Or</div>
                        <div style={{ textAlign: 'center', margin: '12px 0 8px' }}>
                            <button className='add-note' type="button" onClick={handleAddMoreExpenseOpen}>
                                <FontAwesomeIcon icon={faSquarePlus} /> Add More
                            </button>
                        </div>
                    </Modal.Body>
                    <Modal.Footer className='pt-0'>
                        {expenseFlatList.length > 0 && (
                            <Button variant="primary" className='modal-btn addBtnn mt-0 mb-0' onClick={handleExpenseAdd} disabled={expenseSelected.length === 0}>
                                Add
                            </Button>
                        )}
                    </Modal.Footer>
                </Modal>
                <Modal centered show={showAddMoreExpenseModal} onHide={handleAddMoreExpenseClose}>
                    <Modal.Header closeButton>
                        <span
                            style={{ cursor: 'pointer', marginRight: 12 }}
                            onClick={handleExpenseBackClick}
                        >
                            <FontAwesomeIcon icon={faArrowLeft} />
                        </span>
                        <Modal.Title>Add expense</Modal.Title>
                    </Modal.Header>
                    <Modal.Body className='mt-0 mb-0 form-input-label'>
                        <div className='row'>
                            <div className='col-lg-12 col-md-12 col-sm-12'>
                                <div className="row mb-4">
                                    <div className="col-lg-12 col-md-12 col-sm-12">
                                        <div className="d-flex flex-wrap gap-4 align-items-center">
                                            <div className="goodsServiceLeft d-flex align-items-center">
                                                <div className='tabHeading'>Type of Expense</div>
                                            </div>
                                            <div className='goodsService d-flex align-items-center gap-4'>
                                                <label className="d-flex align-items-center cursor-pointer">
                                                    <input
                                                        type="radio"
                                                        name="tabs"
                                                        value="tab1"
                                                        checked={form?.type === 'Goods'}
                                                        onChange={() => setForm(prev => ({ ...prev, type: 'Goods' }))}
                                                        className="me-2"
                                                        style={{ cursor: 'pointer' }}
                                                    />
                                                    <span>Goods</span>
                                                </label>
                                                <label className="d-flex align-items-center cursor-pointer">
                                                    <input
                                                        type="radio"
                                                        name="tabs"
                                                        value="tab2"
                                                        checked={form?.type === 'Service'}
                                                        onChange={() => setForm(prev => ({ ...prev, type: 'Service' }))}
                                                        className="me-2"
                                                        style={{ cursor: 'pointer' }}
                                                    />
                                                    <span>Service</span>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="col-lg-12 col-md-12 col-sm-12">
    
                                        <div className="row pb-3 rounded ">
                                            {form?.type === 'Goods' &&
                                                <div className="col-lg-6 col-md-6 col-sm-12">
                                                    <div className="floating-label-group">
                                                        <input
                                                            type="text"
                                                            name="HSN"
                                                            className="input-form-control"
                                                            required
                                                            value={form.HSN}
                                                            onChange={handleChange}
                                                        />
                                                        <label className="floating-label">HSN</label>
                                                    </div>
                                                </div>
                                            }
                                            {form?.type === 'Service' &&
                                                <div className="col-lg-6 col-md-6 col-sm-12">
                                                    <div className="floating-label-group">
                                                        <input
                                                            type="text"
                                                            name="SAC"
                                                            className="input-form-control"
                                                            required
                                                            value={form.SAC}
                                                            onChange={handleChange}
                                                        />
                                                        <label className="floating-label">SAC</label>
                                                    </div>
                                                </div>
                                            }
                                            <div className='col-lg-6 col-md-6 col-sm-12'>
                                                <div className='form-group mb-3'>
                                                    <input
                                                        type="text"
                                                        name="date"
                                                        className='input-form-control date-time'
                                                        placeholder='Date'
                                                        value={form.date.toLocaleDateString()}
                                                        readOnly
                                                        onClick={() => setShowCalendarExpenseStart(!showCalendarExpenseStart)}
                                                    />
                                                    <FontAwesomeIcon
                                                        className="point-img"
                                                        icon={faCalendarDays}
                                                        onClick={() => setShowCalendarExpenseStart(!showCalendarExpenseStart)}
                                                    />
                                                    {showCalendarExpenseStart && (
                                                        <Calendar
                                                            onChange={handleDateChange}
                                                            value={form.date}
                                                        />
                                                    )}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className='col-lg-6 col-md-6 col-sm-12 text-start mb-3'>
                                <div className="floating-label-group">
                                    <input
                                        type="text"
                                        name="merchant"
                                        className="input-form-control"
                                        required
                                        value={form.merchant}
                                        onChange={handleChange}
                                    />
                                    <label className="floating-label">Merchant</label>
                                </div>
                                {addMoreExpenseError?.merchant && <small style={{ color: "red", fontSize: "12px", paddingInline: "10px", marginBlock: "5px" }}>{addMoreExpenseError?.merchant}</small>}
                            </div>
                            <div className='col-lg-6 col-md-6 col-sm-12 mb-3 text-start'>
                                <div className='payment-type-dropdown'>
                                    <select
                                        className="payment-terms"
                                        name="catagory"
                                        value={form.catagory}
                                        onChange={handleChange}
                                    >
                                        {categories.map(cat => (
                                            <option key={cat.value} value={cat.value}>
                                                {cat.label}
                                            </option>
                                        ))}
                                    </select>
                                    <p className="dropdownIcon">
                                        <img className="upload-img" src={IMAGE.dropdownColor} alt="upload" />
                                    </p>
                                </div>
                                {addMoreExpenseError?.catagory && <small style={{ color: "red", fontSize: "12px", paddingInline: "10px", marginBlock: "5px" }}>{addMoreExpenseError?.catagory}</small>}
                            </div>
                            <div className='col-lg-6 col-md-6 col-sm-12 text-start mb-3'>
                                <div className="phone-input">
                                    <div className="floating-label-group">
                                        <input
                                            type="text"
                                            name="rate"
                                            className="small-input"
                                            required
                                            value={form.rate}
                                            onChange={handleChange}
                                        />
                                        <label className="small-input-floating">Amount</label>
                                    </div>
                                    {/* <div className="smallinput-divider"></div>
                                    <div className="country-code-small">$ <FontAwesomeIcon icon={faAngleDown} className='phone-angle' /></div> */}
                                </div>
                                {addMoreExpenseError?.rate && <small style={{ color: "red", fontSize: "12px", paddingInline: "10px", marginBlock: "5px" }}>{addMoreExpenseError?.rate}</small>}
                            </div>
                            <div className='col-lg-6 col-md-6 col-sm-12'>
                                <div className="payment-type-dropdown">
                                    <select
                                        name="projectId"
                                        className="payment-terms"
                                        required
                                        value={form.projectId}
                                        onChange={handleChange}
                                        disabled={!selectedClient?.id || loadingProjects}
                                    >
                                        <option value="">Select Project</option>
                                        {loadingProjects && <option>Loading...</option>}
                                        {projects && projects.map((project) => (
    
                                            <option key={project.id || project._id} value={project.id || project._id}>
                                                {project.project_name || project.project_desc}
                                            </option>
                                        ))}
                                    </select>
                                    <p className="dropdownIcon">
                                        <img className="upload-img" src={IMAGE.dropdownColor} alt="upload" />
                                    </p>
                                </div>
                            </div>
                            {/* <div className='col-lg-4 col-md-6 col-sm-12 text-start mb-3'>
                                <div className="phone-input">
                                    <div className="floating-label-group">
                                        <input
                                            type="text"
                                            name="tax"
                                            className="small-input"
                                            required
                                            value={form.tax}
                                            onChange={handleChange}
                                        />
                                        <label className="small-input-floating">Tax</label>
                                    </div>
                                    <div className="smallinput-divider"></div>
                                    <div className="country-code-small">$ <FontAwesomeIcon icon={faAngleDown} className='phone-angle' /></div>
                                </div>
                                {addMoreExpenseError?.tax && <small style={{ color: "red", fontSize: "12px", paddingInline: "10px", marginBlock: "5px" }}>{addMoreExpenseError?.tax}</small>}
                            </div>
                            <div className='col-lg-4 col-md-6 col-sm-12 text-start mb-3'>
                                <div className="phone-input ">
                                    <div className="floating-label-group">
                                        <input
                                            type="text"
                                            name="tip"
                                            className="small-input"
                                            required
                                            value={form.tip}
                                            onChange={handleChange}
                                        />
                                        <label className="small-input-floating">Tip</label>
                                    </div>
                                    <div className="smallinput-divider"></div>
                                    <div className="country-code-small">$ <FontAwesomeIcon icon={faAngleDown} className='phone-angle' /></div>
                                </div>
                                {errors?.tip && <small style={{ color: "red", fontSize: "12px", paddingInline: "10px", marginBlock: "5px" }}>{errors?.tip}</small>}
                            </div> */}
                        </div>
                    </Modal.Body>
                    <Modal.Footer>
                        <Button
                            variant="primary"
                            className='modal-btn addBtnn'
                            onClick={() => {
    
                                handleAddMoreExpenseAdd();
                            }}
                            disabled={
                                addMoreAppointmentLoading
                                // ||
                                // // Prevent add if duration > 24hr
                                // (() => {
                                //     if (
                                //         addMoreAppointment.start_date &&
                                //         addMoreAppointment.end_date &&
                                //         addMoreAppointment.start_time &&
                                //         addMoreAppointment.end_time
                                //     ) {
                                //         const start = new Date(addMoreAppointment.start_date + "T" + addMoreAppointment.start_time);
                                //         const end = new Date(addMoreAppointment.end_date + "T" + addMoreAppointment.end_time);
                                //         return end - start > 24 * 60 * 60 * 1000 || end - start < 0;
                                //     }
                                //     return false;
                                // })()
                            }
    
                        >
                            {addMoreAppointmentLoading ? "Adding..." : "Add"}
                        </Button>
                    </Modal.Footer>
                </Modal>
    
                <Modal centered show={gstModal} onHide={handleGstClose}>
                    <Modal.Header closeButton>
                        <Modal.Title>
                            <h4 className='title-modal'>Edit GST</h4>
                        </Modal.Title>
                    </Modal.Header>
                    <Modal.Body style={{ width: "100%", marginTop: "0px" }}>
                        <div className='gst-modal'>
                            <p>Changes to this tax will be applied to all items it's currently assigned to.</p>
                            <hr className="payment-divider" />
                            <h4>Tax Calculation</h4>
                            <div className="tab-heading" style={{ display: 'flex', padding: '6px', borderBottom: '2px solid #eee', marginBottom: 16 }}>
                                {['Inclusive', 'Exclusive'].map(tab => (
                                    <span
                                        key={tab}
                                        className={`tag ${gstTab === tab ? "active" : ""}`}
                                        style={{
                                            cursor: 'pointer',
                                            borderBottom: gstTab === tab ? '3px solid #047FFF' : '3px solid transparent',
                                            fontWeight: gstTab === tab ? 'bold' : 'normal',
                                            paddingBottom: 6
                                        }}
                                        onClick={() => handleGstTabChange(tab)}
                                    >
                                        {tab}
                                    </span>
                                ))}
                            </div>
                            <p>Tax is calculated as part of the total amount (inclusive) or in addition to it (exclusive).</p>
                            <hr className="payment-divider" />
                        </div>
                        <div className='rate-chart'>
                            <h6>Tax Rates</h6>
                            {taxRates.length === 0 && <div>No Tax Rates Found</div>}
                            {taxRates.map((rate, idx) => (
                                <div
                                    className='gst-values'
                                    key={rate.id || idx}
                                    style={{
                                        width: '100%',
                                        display: 'flex',
                                        alignItems: 'center',
                                        gap: '16px',
                                        cursor: 'pointer',
                                        background: selectedGstRate && selectedGstRate.id === rate.id ? '#e6f0ff' : 'transparent',
                                        borderRadius: 6,
                                        padding: 4
                                    }}
                                    onClick={() => handleSelectGstRate(rate)}
                                >
                                    <p style={{ marginBottom: 0 }}>{rate.rate}</p>
                                    <p style={{ marginBottom: 0, minWidth: 60 }}>{rate.percentage}%</p>
                                    <span
                                        className='deleteGST'
                                        style={{ marginLeft: 8, color: '#047FFF', cursor: 'pointer' }}
                                        onClick={e => { e.stopPropagation(); handleDeleteRate(rate.id); }}
                                    >
                                        <FontAwesomeIcon icon={faTrash} />
                                    </span>
                                </div>
                            ))}
                        </div>
                        <div className='btn-grp' style={{ marginTop: 16, display: 'flex', justifyContent: 'space-between' }}>
                            <button className='add-rate' onClick={handleAddRateOpen}>
                                <FontAwesomeIcon icon={faSquarePlus} /> Add new rate
                            </button>
                            <button
                                className='modal-btn addBtnn'
                                style={{ minWidth: 100, margin: '22px auto 9px' }}
                                onClick={handleGstSave}
    
                            >
                                Save
                            </button>
                        </div>
                    </Modal.Body>
                </Modal>
    
                {/* Add/Edit New Rate Modal */}
                <Modal centered className='taxRatModal' show={showAddRateModal} onHide={handleAddRateClose}>
                    <>
                        <Modal.Header closeButton>
                            <Modal.Title>{editRateId ? "Edit Tax Rate" : "Add New Tax Rate"}</Modal.Title>
                        </Modal.Header>
                        <Modal.Body>
                            <div className="row" style={{ alignItems: 'center', gap: '8px' }}>
                                <div className="col" style={{ flex: 1 }}>
                                    <label className="floating-label">Name</label>
                                    <input
                                        type="text"
                                        name="rate"
                                        className="input-form-control"
                                        required
                                        value={newRate.rate}
                                        onChange={handleRateChange}
                                    />
                                </div>
                                <div className="col" style={{ flex: 1 }}>
                                    <label className="floating-label">Percentage</label>
                                    <input
                                        type="number"
                                        name="percentage"
                                        className="input-form-control"
                                        required
                                        value={newRate.percentage}
                                        onChange={handleRateChange}
                                        min="0"
                                        max="100"
                                    />
                                </div>
                            </div>
                            <button
                                className='modal-btn addBtnn'
                                onClick={handleSaveRate}
                                disabled={savingRate || !newRate.rate || !newRate.percentage}
                                style={{ marginTop: '16px' }}
                            >
                                {savingRate ? 'Saving...' : 'Save'}
                            </button>
                        </Modal.Body>
                    </>
                </Modal>
    
                {/* add deposit modal */}
                <Modal centered className='depositModal' show={showDepositModal} onHide={handleDepositClose}>
                    <Modal.Header closeButton>
                        <Modal.Title>Deposit request</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        <p><strong>Invoice total:</strong> {formatCurrency(total, currencyList)}</p>
                        <div className="tabs" style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
                            <button
                                className={`tab ${depositTab === 'percent' ? 'active' : ''}`}
                                style={{
                                    padding: '6px 16px',
                                    border: 'none',
                                    background: depositTab === 'percent' ? '#047FFF' : '#eee',
                                    color: depositTab === 'percent' ? '#fff' : '#333',
                                    borderRadius: 4,
                                    fontWeight: depositTab === 'percent' ? 'bold' : 'normal'
                                }}
                                onClick={() => setDepositTab('percent')}
                            >
                                Percent (%)
                            </button>
                            <button
                                className={`tab ${depositTab === 'fixed' ? 'active' : ''}`}
                                style={{
                                    padding: '6px 16px',
                                    border: 'none',
                                    background: depositTab === 'fixed' ? '#047FFF' : '#eee',
                                    color: depositTab === 'fixed' ? '#fff' : '#333',
                                    borderRadius: 4,
                                    fontWeight: depositTab === 'fixed' ? 'bold' : 'normal'
                                }}
                                onClick={() => setDepositTab('fixed')}
                            >
                                Fixed (₹)
                            </button>
                        </div>
                        {depositTab === 'percent' && (
                            <>
                                <label>Set percentage:</label>
                                <input
                                    type="number"
                                    min="1"
                                    max="100"
                                    value={depositPercentage}
                                    onChange={handleDepositPercentageChange}
                                    className="input-form-control"
                                    style={{ marginBottom: 8 }}
                                />
                            </>
                        )}
                        <label>Deposit amount:</label>
                        <input
                            type="number"
                            min="1"
                            value={depositFixedAmount}
                            onChange={handleDepositFixedAmountChange}
                            className="input-form-control"
                            style={{ marginBottom: 8 }}
                        // disabled={depositTab === 'percent'}
                        />
    
                        <label>Due date:</label>
                        <input
                            type="date"
                            value={depositDueDate}
                            onChange={e => setDepositDueDate(e.target.value)}
                            className="input-form-control"
                            style={{ marginBottom: 8 }}
                        />
                        {/* <span
                            className='listBorder'
                            style={{ cursor: 'pointer', position: 'relative', display: 'block', marginBottom: 8 }}
                            onClick={handleDepositDueDateClick}
                        >
                            {depositDueDate}
                            {showDepositDueDateCalendar && (
                                <div ref={depositDueDateCalendarRef}>
                                    <Calendar
                                        value={new Date(depositDueDate)}
                                        onChange={handleDepositDueDateSelect}
                                        onClickDay={handleDepositDueDateSelect}
                                        tileClassName={calendarTileClassName}
                                    />
                                </div>
                            )}
                        </span> */}
                        <p><strong>Deposit amount paid:</strong> ₹{depositPaid}</p>
                    </Modal.Body>
                    <Modal.Footer className='deposit-footer-container'>
                        <div className="deposit-footer">
                            <Button className="save-button modal-btn addBtnn m-0" onClick={handleDepositSave}>
                                Save
                            </Button>
                            {deposit && (
                                <Button className="cancel-button" variant="danger" onClick={handleDepositCancel}>
                                    Cancel this request
                                </Button>
                            )}
                        </div>
                    </Modal.Footer>
                </Modal>
    
                {/* Discount Modal */}
                <Modal centered show={discountModalOpen} onHide={() => setDiscountModalOpen(false)} >
                    <Modal.Header closeButton>
                        <Modal.Title>Edit discount</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        <p className="text-sm text-gray-600 mb-4">
                            The discount will be applied to the subtotal. This does not include discounts added to specific items.
                        </p>
                        <div className="flex items-center mb-4">
                            <input
                                type="number"
                                value={discountInputValue}
                                min="0"
                                onChange={(e) => {
                                    let v = e.target.value.replace(/[^0-9.]/g, "");
                                    setDiscountInputValue(v);
                                }}
                                className="border rounded-l px-4 py-2 w-full"
                            />
                            <button
                                onClick={() => setDiscountType("%")}
                                className={`px-4 py-2 border ${discountType === "%" ? "bg-primary text-white" : "bg-light"}`}
                            >
                                %
                            </button>
                            <button
                                onClick={() => setDiscountType("$")}
                                className={`px-4 py-2 border rounded-r ${discountType === "$" ? "bg-primary text-white" : "bg-light"}`}
                            >
                                {(() => {
                                    const formatted = formatCurrency(0, currencyList) || "$0.00";
                                    const symbol = (formatted.match(/^([^\d\.\s-]+)/) || [null, "$"])[1];
                                    return symbol;
                                })()}
                            </button>
                        </div>
                    </Modal.Body>
                    <Modal.Footer>
                        <Button variant="outline-primary" onClick={() => setDiscountModalOpen(false)}>Cancel</Button>
                        <Button
                            variant="primary"
                            onClick={handleSaveDiscount}
                        >
                            Save
                        </Button>
                    </Modal.Footer>
                </Modal>
    
                <style jsx global>{`
                    .react-calendar-tile-today-highlight {
                        background: #047FFF !important;
                        color: #fff !important;
                        border-radius: 50%;
                    }
                `}</style>
            </div>
        );
    };
    
    export default AddInvoicePage;