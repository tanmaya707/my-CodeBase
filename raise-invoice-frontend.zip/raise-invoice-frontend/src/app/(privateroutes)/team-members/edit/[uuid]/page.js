"use client"
import AddMemberForm from '@/Components/addMemberForm/addMemberForm';
import { useParams } from 'next/navigation';

const TeamMember = () => {
  const { uuid } = useParams();
  return (
    <>
        <AddMemberForm
          uuid={uuid}
        />
    </>    
  )
}

export default TeamMember
