"use client"
import AddMemberForm from '@/Components/addMemberForm/addMemberForm';

const TeamMember = () => {
  return (
    <>
        <AddMemberForm />
    </>    
  )
}

export default TeamMember
