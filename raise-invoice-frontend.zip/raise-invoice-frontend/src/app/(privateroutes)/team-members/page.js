"use client"
import React, {useState, useEffect} from 'react'
import './members.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { 
    faSquarePlus,
    faPenToSquare,
    faTrashCan,
    faLongArrowLeft
} from '@fortawesome/free-solid-svg-icons';
import { ToastContainer, toast } from 'react-toastify';
import { useDispatch } from 'react-redux';
import { fetchClientAdminData, deleteClientAdminData } from "@/redux/slices/dataSlice";
import Link from 'next/link';
import { confirmAlert } from 'react-confirm-alert';
import 'react-confirm-alert/src/react-confirm-alert.css';

const TeamMember = () => {
    const dispatch = useDispatch();
    const [clients, setClients] = useState([]);
    let isShowOwnerTitle = false;
    let isShowOtherTitle = false;
    const handleClientDelete = async (clientToDelete) => {
        if (clientToDelete && clientToDelete.id) {
            confirmAlert({
                title: 'Confirm to delete',
                message: 'Are you sure to do this.',
                buttons: [
                    {
                        label: 'Yes',
                        onClick: async () => {
                            try {
                                const response = await dispatch(deleteClientAdminData({ clientAdminId: clientToDelete.id })).unwrap();
                                if (response.status) {
                                    toast.success("Client deleted successfully");
                                    fetchClients();
                                }
                            } catch (error) {
                                console.error('Error deleting client data:', error);
                            }
                        }
                    },
                    {
                        label: 'No'
                    }
                ]
            });
        }
    };
    const fetchClients = async () => {
        try {
            // Fetch client details
            const clientAdminData = await dispatch(fetchClientAdminData()).unwrap(); 
            // Set form data with the fetched client details
            if(clientAdminData.status){
                // console.log('clientAdminData', clientAdminData.data)
                setClients(clientAdminData.data);
            }                
        } catch (error) {
            console.error('Error fetching client details:', error);
        }
    };
    useEffect(() => {
        fetchClients();
    }, [dispatch]);
  return (
    <>
        <div className='all-member-container'>
            <div className='navbar-tab'>
                <Link href="/profile">
                    <FontAwesomeIcon icon={faLongArrowLeft} />
                </Link>
            </div>
            <div className='member-container'>
                <div className='sub-head'>
                    <p className='heading'>Member List</p>
                    <Link className='add-members' href="/team-members/add">
                        <p>Add</p>
                        <FontAwesomeIcon icon={faSquarePlus} />
                    </Link>
                </div>
            
                {
                    clients.map(client => (
                        <div key={client.id}>
                            <div className='member-details-container'>
                                <div className='member-details'>
                                    {
                                        (client.userRole[0].roleSlug != 'super-admin') ?
                                        
                                            !isShowOtherTitle ? 
                                                <p>
                                                    Other Members
                                                    {isShowOtherTitle = true}
                                                </p> 
                                            : <p></p>
                                                                                    
                                        :
                                            !isShowOwnerTitle ? 
                                                <p>
                                                    Account Owner
                                                    {isShowOwnerTitle = true}
                                                </p> 
                                            : <p></p>
                                    }
                                    <p>{client.name}</p>
                                    <p>{client.email}</p>
                                    <p>{(client.userRole[0].roleSlug != 'super-admin') ? client.userRole[0].roleName : 'Account Owner'}</p>
                                </div>
                                    <div className='icon-group'>
                                        <Link href={`/team-members/edit/${client.uuid}`}>
                                            <FontAwesomeIcon icon={faPenToSquare} className='text-success'/>
                                        </Link>
                                        {
                                            (client.userRole[0].roleSlug != 'super-admin') ?
                                                <Link href="#" onClick={() => handleClientDelete(client)}>
                                                    <FontAwesomeIcon icon={faTrashCan} className='text-danger' />
                                                </Link>    
                                            : ''
                                        }                                               
                                    </div>                     
                            </div>
                            <hr className='seperator'/>
                        </div>
                    ))
                }
                
            </div>
        </div>
        <ToastContainer />

    </>
    
  )
}

export default TeamMember
