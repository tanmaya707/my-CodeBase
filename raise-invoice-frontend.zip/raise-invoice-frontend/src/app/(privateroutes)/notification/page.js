import React from 'react';
import { IMAGE } from '@/utils/Theme';
import '../clientpayment-options/payment.css';
const Notification = () => {
  return (
    <div className='notification-area'>
        <div className='sub-head mb-4'>
            <p className='subheading'> Notifications</p>
        </div>
        <div className='noti-subhead'>
            <p>Today</p>
            <div>
                <span className='tab-active'>All</span>
                <span>Unread (6)</span>
            </div>
        </div>
        <div className='noti-card'>

            <div className='noti-sec'>
                <div className='card-left'>
                    <img src={IMAGE.bag} alt="bag"/>
                    <div>
                        <h6>5 Items Added</h6>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                    </div>
                </div>
            </div>
            <div>
                <p>14.36</p>
            </div>
        </div>
        <hr className='noti-divide'/>

        <div className='noti-card'>

            <div className='noti-sec'>
                <div className='card-left'>
                    <img src={IMAGE.document} alt="bag"/>
                    <div>
                        <h6>Invoice for UI Kits</h6>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                    </div>
                </div>
            </div>
            <div>
                <p>14.36</p>
            </div>
        </div>
        <hr className='noti-divide'/>

        <div className='noti-card'>

            <div className='noti-sec'>
                <div className='card-left'>
                    <img src={IMAGE.dollar} alt="bag"/>
                    <div>
                        <h6>Income $10,000</h6>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                    </div>
                </div>
            </div>
            <div>
                <p>14.36</p>
            </div>
        </div>
        <hr className='noti-divide'/>

        <p className='date-stamp'>Yesterday, 8 August 2022</p>

        <div className='noti-card'>

            <div className='noti-sec'>
                <div className='card-left'>
                    <img src={IMAGE.bag} alt="bag"/>
                    <div>
                        <h6>5 Items Added</h6>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                    </div>
                </div>
            </div>
            <div>
                <p>14.36</p>
            </div>
        </div>
        <hr className='noti-divide'/>

        <div className='noti-card'>

            <div className='noti-sec'>
                <div className='card-left'>
                    <img src={IMAGE.bag} alt="bag"/>
                    <div>
                        <h6>5 Items Added</h6>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                    </div>
                </div>
            </div>
            <div>
                <p>14.36</p>
            </div>
        </div>
        <hr className='noti-divide'/>

        <div className='noti-card'>

            <div className='noti-sec'>
                <div className='card-left'>
                    <img src={IMAGE.document} alt="bag"/>
                    <div>
                        <h6>5 Items Added</h6>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                    </div>
                </div>
            </div>
            <div>
                <p>14.36</p>
            </div>
        </div>
    </div>
  )
}

export default Notification
