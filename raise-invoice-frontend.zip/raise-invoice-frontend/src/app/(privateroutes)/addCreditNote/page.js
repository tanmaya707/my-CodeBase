"use client";

import React, { useState, useEffect, useRef } from "react";
import { useDispatch } from "react-redux";
import { useRouter, useSearchParams } from "next/navigation";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
    faArrowLeft, faPhone, faEnvelope, faLocationDot,
    faCircleXmark, faSquarePlus, faPenToSquare, faTrash, faFilePdf
} from "@fortawesome/free-solid-svg-icons";
import { toast } from 'react-toastify';
import CustomInvoiceImpact from "@/Components/templates/impact";
import {
    fetchClientData, createClientData, fetchItemData,
    createCreditNoteData, detailsCreditNoteData, deatilsClientData, updateCreditNoteData, fetchNextCreditNoteNumber, sendMail,
    getCustomInvoiceData, getCustomInvoiceOptionData, fetchTaxData, getInvoiceSignature, fetchMasterData
} from "@/redux/slices/dataSlice";
import Accordion from "react-bootstrap/Accordion";
import Calendar from "react-calendar";
import html2pdf from 'html2pdf.js';
import "react-calendar/dist/Calendar.css";
import { IMAGE } from "../../../utils/Theme";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import "./addClientNotes.css";
import "../../../app/general.css";
import '../addInvoice/addInvoice.css';
import { formatCurrency } from '@/dependencies/utils/helper';
import '../../general.css';
import '../addInvoice/invoice.css';
import '../../../Components/addItemForm/addItemForm.css';
// import jsPDF from "jspdf";
// import html2canvas from "html2canvas";
import DndKitList from "@/Components/dragDropList";
import { useRouteLeaveConfirmation } from "@/hooks/useRouteLeaveConfirmation";

const TABS = ["Create", "Preview", "Send"];

function formatDate(date) {
    if (!date) return "";
    const d = new Date(date);
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    return `${months[d.getMonth()]} ${d.getDate()},${d.getFullYear()}`;
}

const AddClientNotePage = () => {
    const [isSticky, setIsSticky] = useState(false);
    const dispatch = useDispatch();
    const router = useRouter();
    const searchParams = useSearchParams();
    const clientId = searchParams.get('cId');
    const noteId = searchParams.get('id');
    const [activeTab, setActiveTab] = useState(noteId ? 'Preview' : 'Create');
    const [showClientModal, setShowClientModal] = useState(false);
    const [selectedClient, setSelectedClient] = useState(null);
    const [clientList, setClientList] = useState([]);
    const [clientDropdown, setClientDropdown] = useState([]);
    const [clientForm, setClientForm] = useState({ id: null, name: '', email: '', phone: '', address: '' });
    const [showClientDropdown, setShowClientDropdown] = useState(false);
    const [clientFormErrors, setClientFormErrors] = useState({ name: '', email: '', phone: '' });
    const [items, setItems] = useState([]);
    const [showItemModal, setShowItemModal] = useState(false);
    const [itemForm, setItemForm] = useState({ code: '', name: "", description: "", rate: "", quantity: "", unitTypes: "", gstChecked: false, gstValue: "" });
    const [editItemIndex, setEditItemIndex] = useState(null);
    const [attachments, setAttachments] = useState([]);
    const [logo, setLogo] = useState("");
    const logoInputRef = useRef();
    const [comment, setComment] = useState("");
    const [sentStatus, setSentStatus] = useState("unsent");
    const [noteDate, setNoteDate] = useState(new Date());
    const [showCalendar, setShowCalendar] = useState(false);
    const calendarRef = useRef();
    const previewRef = useRef();
    const [previewPdfFile, setPreviewPdfFile] = useState(null);

    // Credit Note Number
    const [creditMemoNumber, setCreditMemoNumber] = useState('');
    const [editCreditMemoNumber, setEditCreditMemoNumber] = useState(false);
    const [creditMemoNumberInput, setCreditMemoNumberInput] = useState('');
    const [isUpdateMode, setIsUpdateMode] = useState(false);

    const [unitTypes, setUnitTypes] = useState([]);
    const [currencyList, setCurrencyList] = useState([]);

    //custome invoice state
    const [formData, setFormData] = useState({
        id: null,
        templateName: "impact",
        logoId: "",
        logoImage: "",
        logoSize: "medium",
        logoPosition: "center",
        colourId: "",
        colourCode: "",
        customColour: "",
        headerId: "",
        headerImg: "",
        waterMarkId: "",
        waterMarkImg: "",
    });
    const [optionData, setOptionData] = useState({
        id: null,
        shippingDetails: false,
        due_date: false,
        payment_terms: false,
        itemCode: false,
        quantityAndRate: false,
        pTax: false,
        tax_amounts: false,
        includeSignatureLine: false,
        invoicePrifix: "",
    });
    const [customTemplates, setCustomTemplates] = useState(null);

    // Choose Item Modal
    const [showChooseItemModal, setShowChooseItemModal] = useState(false);
    const [chooseItemList, setChooseItemList] = useState([]);
    const [chooseSelectedItems, setChooseSelectedItems] = useState([]);
    const [itemSearch, setItemSearch] = useState('');

    // Subtotal, GST, Total
    const [taxRates, setTaxRates] = useState([]);
    const hasItemLevelGst = items.some(item => item.gstChecked && item.gstValue);
    let subtotal = items.reduce((sum, item) => sum + (parseFloat(item.rate || 0) * parseFloat(item.quantity || 0)), 0);
    let gstTotal = items.reduce((sum, item) => {
        if (item.gstChecked && item.gstValue) {
            const total = parseFloat(item.rate || 0) * parseFloat(item.quantity || 0);
            const gstPerc = parseFloat(item.gstValue || 0);
            const base = total * gstPerc / 100;
            return base;
        }
        return sum;
    }, 0);
    let total = subtotal + gstTotal;


    //Email state
    const [sendToEmails, setSendToEmails] = useState(selectedClient?.email ? [selectedClient.email] : []);
    const [sendCcEmails, setSendCcEmails] = useState([]);
    const [sendBccEmails, setSendBccEmails] = useState([]);
    const [showCc, setShowCc] = useState(false);
    const [showBcc, setShowBcc] = useState(false);
    const [sendToInput, setSendToInput] = useState('');
    const [sendCcInput, setSendCcInput] = useState('');
    const [sendBccInput, setSendBccInput] = useState('');
    const [sendNotes, setSendNotes] = useState('');

    // Add/Remove email chips
    function handleAddEmail(type, value) {
        const email = value.trim();
        if (!email) return;
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return;
        if (type === 'to') {
            if (!sendToEmails.includes(email)) setSendToEmails([...sendToEmails, email]);
            setSendToInput('');
        } else if (type === 'cc') {
            if (!sendCcEmails.includes(email)) setSendCcEmails([...sendCcEmails, email]);
            setSendCcInput('');
        } else if (type === 'bcc') {
            if (!sendBccEmails.includes(email)) setSendBccEmails([...sendBccEmails, email]);
            setSendBccInput('');
        }
    }
    function handleRemoveEmail(type, idx) {
        if (type === 'to') setSendToEmails(sendToEmails.filter((_, i) => i !== idx));
        if (type === 'cc') setSendCcEmails(sendCcEmails.filter((_, i) => i !== idx));
        if (type === 'bcc') setSendBccEmails(sendBccEmails.filter((_, i) => i !== idx));
    }
    function handleEmailInputKeyDown(e, type) {
        if (e.key === 'Enter' || e.key === ',' || e.key === 'Tab') {
            e.preventDefault();
            if (type === 'to') handleAddEmail('to', sendToInput);
            if (type === 'cc') handleAddEmail('cc', sendCcInput);
            if (type === 'bcc') handleAddEmail('bcc', sendBccInput);
        }
    }

    const [unsaved, setUnsaved] = useState(false);
    const [modalType, setModalType] = useState('reload');
    const [showModal, setShowModal] = useState(false);

    // --- Unsaved Changes Protection ---
    useRouteLeaveConfirmation(unsaved, 'You have unsaved changes. Leave anyway?');
    useEffect(() => {
        if (!clientId) {
            const hasUnsavedChanges =
                clientForm.name ||
                clientForm.email ||
                clientForm.phone ||
                clientForm.address ||
                items.length > 0 ||
                comment;
            setUnsaved(hasUnsavedChanges);
        } else {
            setUnsaved(false);
        }
    }, [clientForm, items, comment, clientId]);

    // useEffect(() => {
    //     const handleBeforeUnload = (e) => {
    //         if (!clientId && unsaved) {
    //             e.preventDefault();
    //             e.returnValue = '';
    //             setModalType('close');
    //             setShowModal(true);
    //             return '';
    //         }
    //     };
    //     window.addEventListener('beforeunload', handleBeforeUnload);
    //     return () => window.removeEventListener('beforeunload', handleBeforeUnload);
    // }, [unsaved, clientId]);

    // useEffect(() => {
    //     const handleKeyDown = (e) => {
    //         if (!clientId && unsaved && (e.key === 'F5' || (e.ctrlKey && e.key === 'r'))) {
    //             e.preventDefault();
    //             setModalType('reload');
    //             setShowModal(true);
    //         }
    //     };
    //     window.addEventListener('keydown', handleKeyDown);
    //     return () => window.removeEventListener('keydown', handleKeyDown);
    // }, [unsaved, clientId]);

    useEffect(() => {
        async function fetchData() {
            try {
                const data = await dispatch(fetchMasterData()).unwrap();
                setUnitTypes(data.productUnitTypes || []);
                setCurrencyList(data.currencyData || []);
            } catch (err) {
                console.error("Failed to fetch master data", err);
            }
        }
        fetchData();
    }, [dispatch]);

    // Update sendToEmails when selectedClient changes
    useEffect(() => {
        if (selectedClient?.email) setSendToEmails([selectedClient.email]);
    }, [selectedClient]);

    // PDF generation
    // async function generatePreviewPdf() {
    useEffect(() => {
        if (!previewRef.current) return;
        const element = previewRef.current;
        // const element = previewRef.current;
        // const canvas = await html2canvas(element, { scale: 2 });
        // const imgData = canvas.toDataURL("image/png");
        // const pdf = new jsPDF("p", "pt", "a4");
        // const pageWidth = pdf.internal.pageSize.getWidth();
        // const imgProps = pdf.getImageProperties(imgData);
        // const pdfWidth = pageWidth;
        // const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
        // pdf.addImage(imgData, "PNG", 0, 0, pdfWidth, pdfHeight);
        // const pdfBlob = pdf.output("blob");
        setPreviewPdfFile(element);
    }, [previewRef, activeTab])
    // }
    function handleDownloadPdf() {
        if (!previewPdfFile) return;

        const element = previewPdfFile;

        const options = {
            margin: 0,
            filename: `CreditNote_${creditMemoNumber || 'preview'}.pdf`,
            image: { type: 'png', quality: 1.0 },
            html2canvas: {
                scale: 3,
                useCORS: true,
                backgroundColor: '#ffffff',
            },
            jsPDF: { unit: 'pt', format: 'a4', orientation: 'portrait' },
        };

        html2pdf()
            .set(options)
            .from(element)
            .save()
            .catch((err) => {
                console.error('PDF generation failed:', err);
            });
    }
    const fetchBlobAsBase64 = async (blobUrl) => {
        const response = await fetch(blobUrl);
        const blob = await response.blob();

        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onloadend = () => resolve(reader.result);
            reader.onerror = reject;
            reader.readAsDataURL(blob);
        });
    };
    async function handleSendPdf() {
        if (!previewPdfFile) return;
        if (sendToEmails.length === 0) {
            toast.error("Please enter recipient email address.");
            return;
        }
        const element = previewPdfFile;
        let htmlContent = "";
        if (element && element.outerHTML) {
            htmlContent = element.outerHTML;
        } else if (element && element.current && element.current.outerHTML) {
            htmlContent = element.current.outerHTML;
        }

        htmlContent = htmlContent.replace(/<img([^>]+)src=["']data:image\/[^"']+["']([^>]*)>/gi, '');
        const body = {
            to: sendToEmails,
            cc: sendCcEmails,
            bcc: sendBccEmails,
            invoiceNumber: creditMemoNumber,
            name: 'Credit Note',
            filename: 'CreditNote.pdf',
            subject: `Credit Note from RaiseInvoice #${creditMemoNumber}`,
            notes: sendNotes,
            html: htmlContent,
            attachments: attachments
        };
        // if(parameter?.attachmentName) {
        //     // console.log("----------------------------------->", parameter?.attachmentName );

        //     body.attachment = parameter?.attachmentName
        // }
        // console.log("body ::: ", body);

        let formData = new FormData();
        for (let [key, val] of Object.entries(body)) {
            // console.log("key val ------------> ", key, val);
            formData.append(key, val);
        }

        try {
            const result = await dispatch(sendMail(formData)).unwrap();
            if (result && result.status == true) {
                setSentStatus("sent");
                toast.success("Credit Note sent successfully!");
            } else {
                toast.error("Failed to send Credit Note.");
            }
        } catch (err) {
            toast.error("Failed to send Credit Note.");
        }

    }


    const handleBackClick = () => {
        setShowChooseItemModal(false);
        setShowItemModal(true);
    };

    // Print (print preview only)
    const handlePrintPdf = async () => {
        if (!previewPdfFile) return;
        const printContents = previewPdfFile.innerHTML;
        const printWindow = window.open("", "", "width=900,height=900");
        printWindow.document.write(`
                <html>
                    <head>
                        <title>Invoice Print</title>
                        <link rel="stylesheet" href="/anonymousinvoice.css" />
                        <link rel="stylesheet" href="/general.css" />
                    </head>
                    <body>${printContents}</body>
                </html>
            `);
        printWindow.document.close();
        printWindow.focus();
        setTimeout(() => {
            printWindow.print();
            printWindow.close();
        }, 500);
    };

    // Fetch credit note details if editing
    useEffect(() => {
        if (noteId) {
            setIsUpdateMode(true);
            dispatch(detailsCreditNoteData({ id: noteId })).then(result => {
                const data = result?.payload?.data;
                if (data) {
                    setCreditMemoNumber(data.creditNote.cnNumber || data.id || '');
                    setCreditMemoNumberInput(data.creditNote.cnNumber || data.id || '');
                    setSelectedClient(data.clients || null);
                    setClientForm({
                        id: data.clients?.id || null,
                        name: data.clients?.name || '',
                        email: data.clients?.email || '',
                        phone: data.clients?.phone || '',
                        address: data.clients?.address || ''
                    });
                    let parsedItems = [];
                    if (Array.isArray(data.items)) {
                        parsedItems = data.items.map((item, idx) => ({
                            id: item.id || null,
                            code: item.code || '',
                            name: item.name || '',
                            description: item.description || '',
                            rate: item.rate || '',
                            quantity: item.quantity || '',
                            unitTypes: item.unitTypes || '',
                            gstChecked: item.gstChecked || false,
                            drag_id: `${items?.length + idx}`,
                            gstValue: item.gstValue || ''
                        }));
                    }
                    if (data.customInvoice) {
                        setFormData({
                            id: data.customInvoice.id || null,
                            templateName: data.customInvoice?.templateName || "impact",
                            logoId: data.customInvoice?.logoId || "",
                            logoImage: data.customInvoice?.logoImage || "",
                            logoSize: data.customInvoice?.logoSize || "medium",
                            logoPosition: data.customInvoice?.logoPosition || "center",
                            colourId: data.customInvoice?.colourId || "",
                            colourCode: data.customInvoice?.colourCode || "",
                            customColour: data.customInvoice?.customColour || "",
                            headerId: data.customInvoice?.headerId || "",
                            headerImg: data.customInvoice?.headerImg || "",
                            waterMarkId: data.customInvoice?.waterMarkId || "",
                            waterMarkImg: data.customInvoice?.waterMarkImg || "",
                        });
                    }
                    if (data.customInvoiceOption) {
                        setOptionData({
                            id: data.customInvoiceOption?.id || null,
                            shippingDetails: !!data.customInvoiceOption?.shippingDetails,
                            due_date: !!data.customInvoiceOption?.due_date,
                            payment_terms: !!data.customInvoiceOption?.payment_terms,
                            itemCode: !!data.customInvoiceOption?.itemCode,
                            quantityAndRate: !!data.customInvoiceOption?.quantityAndRate,
                            pTax: !!data.customInvoiceOption?.pTax,
                            tax_amounts: !!data.customInvoiceOption?.tax_amounts,
                            includeSignatureLine: !!data.customInvoiceOption?.includeSignatureLine,
                            invoicePrifix: data.customInvoiceOption?.invoicePrifix || "",
                        });
                    }
                    setItems(parsedItems);
                    setNoteDate(data.creditNote.date ? new Date(data.creditNote.date) : new Date());
                    setLogo(data.creditNote.logo || '');
                    setAttachments(data.attachments || []);
                    setComment(data.creditNote.comment || '');
                }
            });
        } else if (clientId) {
            setIsUpdateMode(false);
            dispatch(fetchNextCreditNoteNumber()).then(result => {
                let nextNum = result?.payload?.data?.nextCreditNoteNumber || '';
                // Pad to 3 digits
                if (typeof nextNum === 'number' || /^\d+$/.test(nextNum)) {
                    nextNum = String(nextNum).padStart(3, '0');
                }
                setCreditMemoNumber(nextNum);
                setCreditMemoNumberInput(nextNum);
            });
            dispatch(deatilsClientData(clientId)).then(result => {
                const data = result?.payload;
                const profileImage = process.env.NEXT_PUBLIC_API_URL + 'uploads/' + (data.profileImage || '');
                if (data) {
                    setSelectedClient({ ...data, profileImage } || null);
                    setClientForm({
                        id: data.id || null,
                        name: data.name || '',
                        email: data.email || '',
                        phone: data.phone || '',
                        address: data.address || ''
                    });
                }
            });
            setSelectedClient(null);
            setItems([]);
            setNoteDate(new Date());
            setLogo('');
            setAttachments([]);
            setComment('');
        } else {
            setIsUpdateMode(false);
            dispatch(fetchNextCreditNoteNumber()).then(result => {
                let nextNum = result?.payload?.data?.nextCreditNoteNumber || '';
                // Pad to 3 digits
                if (typeof nextNum === 'number' || /^\d+$/.test(nextNum)) {
                    nextNum = String(nextNum).padStart(3, '0');
                }
                setCreditMemoNumber(nextNum);
                setCreditMemoNumberInput(nextNum);
            });
            setSelectedClient(null);
            setClientForm({ id: null, name: '', email: '', phone: '', address: '' });
            setItems([]);
            setNoteDate(new Date());
            setLogo('');
            setAttachments([]);
            setComment('');
        }
    }, [noteId]);

    useEffect(() => {
        if (noteId) return;
        dispatch(getCustomInvoiceData()).then((res) => {
            const data = res?.payload?.data;
            if (data) {
                setFormData({
                    id: data.id || null,
                    templateName: data.templateName || "impact",
                    logoId: data.logoDetails?.id || "",
                    logoImage: data.logoDetails?.logoImage || "",
                    logoSize: data.logoSize || "medium",
                    logoPosition: data.logoPosition || "center",
                    colourId: data.colourDetails?.id || "",
                    colourCode: data.colourDetails?.colourCode || "",
                    customColour: data.colourDetails?.customColour || "",
                    headerId: data.headerDetails?.id || "",
                    headerImg: data.headerDetails?.headerImg || "",
                    waterMarkId: data.waterMarkDetails?.id || "",
                    waterMarkImg: data.waterMarkDetails?.waterMarkImg || "",
                });
                setCustomTemplates(res?.payload);
            }
        });
        dispatch(getCustomInvoiceOptionData()).then((res) => {
            const data = res?.payload?.data;
            if (data) {
                setOptionData({
                    id: data.id || null,
                    shippingDetails: !!data.shippingDetails,
                    due_date: !!data.due_date,
                    payment_terms: !!data.payment_terms,
                    itemCode: !!data.itemCode,
                    quantityAndRate: !!data.quantityAndRate,
                    pTax: !!data.pTax,
                    tax_amounts: !!data.tax_amounts,
                    includeSignatureLine: !!data.includeSignatureLine,
                    invoicePrifix: data.invoicePrifix || "",
                });
            }
        });
        // eslint-disable-next-line
    }, [dispatch]);

    const [sigCreditNote, setCreditnote] = useState(true);
    const [error, setError] = useState({});

    // Signature states
    const [signatureType, setSignatureType] = useState("pad");
    const [padSignature, setPadSignature] = useState("");
    const [uploadSignature, setUploadSignature] = useState("");
    const [signatureText, setSignatureText] = useState("");

    useEffect(() => {
        const fetchSignature = async () => {
            try {
                const result = await dispatch(getInvoiceSignature()).unwrap();
                if (result && result.data) {
                    const data = result.data;
                    setCreditnote(data.creditNote);
                    setSignatureType(data.signatureType || "pad");
                    setPadSignature(data.signature || "");
                    setUploadSignature(data.signatureData || "");
                    setSignatureText(data.signatureText || "");
                }
            } catch (err) {
                // No existing signature, keep defaults
            }
        };
        fetchSignature();
    }, [dispatch]);

    // Tab change
    function handleTabChange(tab) {
        setActiveTab(tab);
        if (tab === "Send") generatePreviewPdf();
    }

    // Client Modal
    const handleShowClientModal = async () => {
        setShowClientModal(true);
        const result = await dispatch(fetchClientData());
        if (result && result.payload && result.payload.data) {
            setClientList(result.payload.data);
            setClientDropdown(result.payload.data);
            setShowClientDropdown(true);
        }
        setClientForm({ id: null, name: '', email: '', phone: '', address: '' });
        setClientFormErrors({ name: '', email: '', phone: '' });
    };
    const handleCloseClientModal = () => {
        setShowClientModal(false);
        setShowClientDropdown(false);
        setClientDropdown([]);
        setClientForm({ id: null, name: '', email: '', phone: '', address: '' });
        setClientFormErrors({ name: '', email: '', phone: '' });
    };
    const handleClearClient = () => {
        setSelectedClient(null);
        setClientForm({ id: null, name: '', email: '', phone: '', address: '' });
        setClientFormErrors({ name: '', email: '', phone: '' });
    };

    // =============stickey top form heafer==========


    useEffect(() => {
        const handleScroll = () => {

            const element = document.querySelector('.addClientFormTop');
            if (!element) return;

            const offsetTop = element.offsetTop; // distance from top of document
            const scrollTop = window.scrollY;

            setIsSticky(scrollTop > 50);
        };

        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);


    // Client Form logic for dropdown and validation
    const validateClientForm = (field, value) => {
        let error = "";
        if (field === "name") {
            if (!value.trim()) error = "Name is required";
        }
        if (field === "email") {
            if (!value.trim()) error = "Email is required";
            else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) error = "Invalid email";
        }
        if (field === "phone") {
            if (!value.trim()) error = "Phone is required";
            else if (!/^\d{10}$/.test(value.replace(/\D/g, ""))) error = "Phone must be 10 digits";
        }
        return error;
    };

    const validateItemForm = (field, value) => {
        let error = "";
        const val = (value === undefined || value === null) ? "" : String(value);
        if (field === "name") {
            if (!val.trim()) error = "Name is required";
        }
        if (field === "rate") {
            if (!val.trim()) error = "Rate is required";
            else if (isNaN(val) || parseFloat(val) <= 0) error = "Rate must be positive";
        }
        if (field === "quantity") {
            if (!val.trim()) error = "Qty is required";
            else if (!/^\d+$/.test(val) || parseInt(val) < 1) error = "Qty must be at least 1";
        }
        return error;
    };

    const handleClientFormChange = (e) => {
        const { name, value } = e.target;
        let v = value;
        if (name === "phone") {
            v = v.replace(/\D/g, "").slice(0, 10);
        }
        setClientForm((prev) => ({
            ...prev,
            [name]: v,
        }));
        setClientFormErrors((prev) => ({
            ...prev,
            [name]: validateClientForm(name, v),
        }));
        if (name === "name") {
            if (v.trim().length > 0) {
                const filtered = clientList.filter((client) =>
                    client.name?.toLowerCase().includes(v.toLowerCase())
                );
                setClientDropdown(filtered);
                setShowClientDropdown(true);
            } else {
                setShowClientDropdown(true);
                setClientDropdown(clientList);
            }
        }
    };

    const [itemFormErrors, setItemFormErrors] = useState({
        name: "",
        rate: "",
        quantity: "",
    });

    const handleClientDropdownSelect = (client) => {
        setClientForm({
            id: client.id || null,
            name: client.name || '',
            email: client.email || '',
            phone: client.phone || '',
            address: client.address || ''
        });
        setShowClientDropdown(false);
        setClientDropdown([]);
        setClientFormErrors({ name: '', email: '', phone: '' });
    };

    // Add/Save client from modal
    const handleAddClientFromModal = async () => {
        const errors = {
            name: validateClientForm('name', clientForm.name),
            email: validateClientForm('email', clientForm.email),
            phone: validateClientForm('phone', clientForm.phone)
        };
        setClientFormErrors(errors);
        if (errors.name || errors.email || errors.phone) return;

        const match = clientList.find(
            c => c.name?.toLowerCase() === clientForm.name.trim().toLowerCase()
        );
        if (match) {
            setSelectedClient(match);
            setShowClientModal(false);
            return;
        }
        // Save new client
        try {
            const result = await dispatch(createClientData(clientForm));
            if (result && result.payload && result.payload.data) {
                setSelectedClient(result.payload.data);
                setShowClientModal(false);
                setClientList(prev => [...prev, result.payload.data]);
                setClientForm({
                    id: result.payload.data.id || null,
                    name: result.payload.data.name || '',
                    email: result.payload.data.email || '',
                    phone: result.payload.data.phone || '',
                    address: result.payload.data.address || ''
                });
                setClientFormErrors({ name: '', email: '', phone: '' });
            }
        } catch (err) {
            alert('Failed to add client');
        }
    };

    // Date picker logic
    const handleDateClick = () => setShowCalendar(true);
    const handleDateSelect = (date) => {
        setNoteDate(date);
        setShowCalendar(false);
    };
    useEffect(() => {
        function handleClickOutside(event) {
            if (showCalendar && calendarRef.current && !calendarRef.current.contains(event.target)) {
                setShowCalendar(false);
            }
        }
        if (showCalendar) {
            document.addEventListener("mousedown", handleClickOutside);
        }
        return () => {
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, [showCalendar]);

    // Item Modal logic
    function handleShowItemModal() {
        setShowItemModal(true);
        setEditItemIndex(null);
        setItemFormErrors({ name: "", rate: "", quantity: "" });
        setItemForm({ code: "", name: "", description: "", rate: "", quantity: "", gstChecked: false, gstValue: "" });
    }
    function handleCloseItemModal() {
        setShowItemModal(false);
    }
    function handleItemFormChange(e) {
        const { code, name, value, type, checked } = e.target;
        setItemForm(prev => ({
            ...prev,
            [name]: type === "checkbox" ? checked : value
        }));
        let v = value;
        if (name === "quantity") {
            v = v.replace(/\D/g, "").slice(0, 10);
        }
        setItemForm((prev) => ({
            ...prev,
            [name]: v,
        }));
        setItemForm((prev) => ({
            ...prev,
            [name]: code || v,
        }));
        setItemFormErrors((prev) => ({
            ...prev,
            [name]: validateItemForm(name, v),
        }));
    }
    function handleSaveItem() {
        const errors = {
            name: validateItemForm("name", itemForm.name),
            rate: validateItemForm("rate", itemForm.rate),
            quantity: validateItemForm("quantity", itemForm.quantity),
        };
        setItemFormErrors(errors);
        if (errors.name || errors.rate || errors.quantity) return;
        const newItem = { ...itemForm, drag_id: `${items?.length + items?.length}`, };
        let updatedItems;
        if (editItemIndex !== null) {
            updatedItems = [...items];
            updatedItems[editItemIndex] = newItem;
        } else {
            updatedItems = [...items, newItem];
        }
        setItems(updatedItems);
        setShowItemModal(false);
    }
    function handleEditItem(idx) {
        setEditItemIndex(idx);
        setItemForm(items[idx]);
        setItemFormErrors({
            name: "",
            rate: "",
            quantity: "",
        });
        setShowItemModal(true);
    }
    function handleDeleteItem(idx) {
        setItems(items.filter((_, i) => i !== idx));
    }

    const handleItemGstCheck = (e) => {
        setItemForm(prev => ({
            ...prev,
            gstChecked: e.target.checked,
            gstValue: e.target.checked ? prev.gstValue : ''
        }));
    };

    // Choose Item Modal logic
    const handleChooseItemOpen = async () => {
        setShowItemModal(false); // close add item modal
        setShowChooseItemModal(true);
        const result = await dispatch(fetchItemData());
        if (result && result.payload && Array.isArray(result.payload.data)) {
            setChooseItemList(result.payload.data);
        } else {
            setChooseItemList([]);
        }
        setChooseSelectedItems([]);
    };
    const handleChooseItemClose = () => {
        setItemSearch("");
        setShowChooseItemModal(false);
    }

    const handleChooseItemToggle = (item) => {
        setChooseSelectedItems(prev => {
            const exists = prev.find(i => i.id === item.id);
            if (exists) {
                return prev.filter(i => i.id !== item.id);
            } else {
                return [...prev, item];
            }
        });
    };

    const handleChooseItemSave = () => {
        const mapped = chooseSelectedItems.map(item => ({
            id: item.id || null,
            code: item.code || '',
            name: item.name || item.item_name || '',
            description: item.description || item.item_Description || '',
            rate: item?.rate || '',
            quantity: item.quantity || item.qty || 1,
            unitTypes: item.unitTypes || item.unit_code || '',
            gstChecked: item.gstChecked || false,
            gstValue: item.gstValue || ''
        }));
        // Add only new items (avoid duplicates by name+rate+desc)
        const existingKeys = items.map(i => `${i.name}-${i.rate}-${i.description}`);
        const newItems = mapped.filter(i => !existingKeys.includes(`${i.name}-${i.rate}-${i.description}`));
        setItems([...items, ...newItems]);
        setShowChooseItemModal(false);
    };

    const handleChooseSelectedDelete = (itemId) => {
        setChooseSelectedItems(prev => prev.filter(i => i.id !== itemId));
    };

    // Filtered item list
    const filteredChooseItemList = chooseItemList.filter(item =>
        (item.name || item.item_name || '').toLowerCase().includes(itemSearch.toLowerCase()) ||
        (item.description || item.item_Description || '').toLowerCase().includes(itemSearch.toLowerCase())
    );

    // Logo logic
    function handleLogoChange(e) {
        const files = Array.from(e.target.files);
        if (!files.length) return;

        // Helper to compress image using canvas
        function compressImage(file, maxWidth = 800, maxHeight = 800, quality = 0.7) {
            return new Promise((resolve, reject) => {
                const img = new window.Image();
                const reader = new FileReader();
                reader.onload = function (evt) {
                    img.onload = function () {
                        let width = img.width;
                        let height = img.height;

                        // Calculate new size while maintaining aspect ratio
                        if (width > maxWidth || height > maxHeight) {
                            if (width / height > maxWidth / maxHeight) {
                                height = Math.round((height * maxWidth) / width);
                                width = maxWidth;
                            } else {
                                width = Math.round((width * maxHeight) / height);
                                height = maxHeight;
                            }
                        }

                        const canvas = document.createElement('canvas');
                        canvas.width = width;
                        canvas.height = height;
                        const ctx = canvas.getContext('2d');
                        ctx.drawImage(img, 0, 0, width, height);

                        // Compress to JPEG (smaller than PNG)
                        const compressedBase64 = canvas.toDataURL('image/jpeg', quality);
                        resolve(compressedBase64);
                    };
                    img.onerror = reject;
                    img.src = evt.target.result;
                };
                reader.onerror = reject;
                reader.readAsDataURL(file);
            });
        }

        // Compress all images and add to attachments
        Promise.all(
            files.map(file => compressImage(file, 800, 800, 0.7))
        ).then(images => {
            setAttachments(prev => [...prev, ...images]);
        });
    }
    function handleRemoveAttachment(idx) {
        setAttachments(prev => prev.filter((_, i) => i !== idx));
    }

    // Credit Note Number logic
    const handleEditCreditMemoNumber = () => {
        setEditCreditMemoNumber(true);
        setCreditMemoNumberInput(creditMemoNumber);
    };
    const handleCreditMemoNumberInputChange = (e) => {
        setCreditMemoNumberInput(e.target.value.replace(/[^0-9]/g, ""));
    };
    const handleCreditMemoNumberInputBlur = () => {
        let num = creditMemoNumberInput;
        // if (!num || num < 1) num = 1;
        setCreditMemoNumber(num);
        setEditCreditMemoNumber(false);
    };
    const handleCreditMemoNumberInputKeyDown = (e) => {
        if (e.key === "Enter" || e.key === "Escape") {
            handleCreditMemoNumberInputBlur();
        }
    };

    // Save logic (create new credit note)
    const handleSaveCreditNote = async () => {
        const clientPayload = selectedClient
            ? { ...selectedClient }
            : { ...clientForm };
        const itemsPayload = items.map(item => ({
            ...item
        }));
        const notePayload = {
            autosaveEnabled: (typeof localStorage !== 'undefined') ? localStorage.getItem('autosaveEnabled') : false,
            cnNumber: creditMemoNumber,
            clients: clientPayload,
            items: itemsPayload,
            subTotal: subtotal,
            total: total,
            paymentStatus: 'unpaid',
            sentStatus: sentStatus,
            logo,
            comment,
            customInvoice: formData,
            customInvoiceOption: optionData,
            attachments
        };
        try {
            const result = await dispatch(createCreditNoteData(notePayload)).unwrap();
            if (result && result.data) {
                setUnsaved(false)
                setTimeout(() => {
                    toast.success("Credit note created successfully!");
                    router.push('/credit-note');
                }, 50)
            } else {
                toast.error(result.message || 'Failed to create credit note');
            }
        } catch (err) {
            toast.error('Failed to create credit note');
        }
    };

    // Update logic (update existing credit note)
    const handleUpdateCreditNote = async () => {
        if (!noteId) return;
        const clientPayload = selectedClient
            ? { ...selectedClient }
            : { ...clientForm };
        const itemsPayload = items.map(item => ({
            ...item
        }));
        const notePayload = {
            id: noteId,
            autosaveEnabled: (typeof localStorage !== 'undefined') ? localStorage.getItem('autosaveEnabled') : false,
            cnNumber: creditMemoNumber,
            clients: clientPayload,
            items: itemsPayload,
            subTotal: subtotal,
            total: total,
            paymentStatus: 'unpaid',
            sentStatus: sentStatus,
            logo,
            comment,
            attachments
        };
        try {
            const result = await dispatch(updateCreditNoteData(notePayload)).unwrap;
            if (result && result.payload && result.payload.data) {
                setUnsaved(false)
                setTimeout(() => {
                    toast.success("Credit note updated successfully!");
                    router.push('/credit-note');
                }, 50)
            } else {
                toast.error(result.message || 'Failed to update credit note');
            }
        } catch (err) {
            toast.error('Failed to update credit note');
        }
    };

    // UI
    return (
        <div className="clientPadding">
            <div className="addClientForm mb-4">
                <button className="clientFormBackBtn" onClick={() => router.push("/credit-note")}>
                    <FontAwesomeIcon icon={faArrowLeft} /> Add Credit Note
                </button>
                <div className={`addClientFormTop ${isSticky ? 'sticky' : ''}`}>
                    <div className="addClientFormTopLeft">
                        <ul>
                            {TABS.map(tab => (
                                <li key={tab} className={activeTab === tab ? "active" : ""} style={{ cursor: "pointer" }} onClick={() => handleTabChange(tab)}>
                                    {tab}
                                </li>
                            ))}
                        </ul>
                    </div>
                    <div className="addClientFormTopRight">
                        {activeTab && (
                            noteId ? (
                                <button onClick={handleUpdateCreditNote}>Update</button>
                            ) : (
                                <button onClick={handleSaveCreditNote}>Save</button>
                            )
                        )}
                    </div>
                </div>
                <div className="addClientFormInner">
                    {activeTab === "Create" && (
                        <div className="row">
                            <div className="col-md-8">
                                <div className="communication-inner">
                                    <Accordion className="accordianHeaderCss" defaultActiveKey={["0", "1", "2", "3"]} alwaysOpen>
                                        <Accordion.Item eventKey="0">
                                            <Accordion.Header>
                                                <p className="accorheading">Bill To</p>
                                            </Accordion.Header>
                                            <Accordion.Body>
                                                {!selectedClient ? (
                                                    <div className="col-lg-12">
                                                        <button className="add-note" onClick={handleShowClientModal}>
                                                            <FontAwesomeIcon icon={faSquarePlus} /> Add Client
                                                        </button>
                                                    </div>
                                                ) : (
                                                    <div className="contactDetails">
                                                        <div className="contactDetailsLeft">
                                                            <h3>
                                                                {selectedClient.profileImage
                                                                    ? <img src={selectedClient.profileImage} style={{ width: '60px', height: '60px', borderRadius: '60%' }} alt={selectedClient.name} />
                                                                    : selectedClient.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                                                            </h3>
                                                        </div>
                                                        <div className="contactDetailsRight">
                                                            <h4>{selectedClient.name}</h4>
                                                            <ul>
                                                                <li>
                                                                    <FontAwesomeIcon icon={faEnvelope} />
                                                                    {selectedClient.email}
                                                                </li>
                                                                <li>
                                                                    <FontAwesomeIcon icon={faPhone} />
                                                                    {selectedClient.phone}
                                                                </li>
                                                                {selectedClient.address && (
                                                                    <li>
                                                                        <FontAwesomeIcon icon={faLocationDot} />
                                                                        {selectedClient.address}
                                                                    </li>
                                                                )}
                                                            </ul>
                                                        </div>
                                                        <div className="crossBtn" style={{ cursor: "pointer" }} onClick={handleClearClient}>
                                                            <FontAwesomeIcon icon={faCircleXmark} />
                                                        </div>
                                                    </div>
                                                )}
                                            </Accordion.Body>
                                        </Accordion.Item>
                                        <Accordion.Item eventKey="1">
                                            <Accordion.Header>
                                                <p className="accorheading">Items</p>
                                            </Accordion.Header>
                                            <Accordion.Body>
                                                <div className="row">
                                                    {/* <div className="col-lg-12">
                                                        {items.length === 0 && <div style={{ color: "#888", marginBottom: 8 }}>No items added yet.</div>}
                                                        {items.map((item, idx) => (
                                                            <div className="productName" key={idx}>
                                                                <div className="productNameLeftDot">
                                                                    <img src={IMAGE.dotted} alt="" />
                                                                </div>
                                                                <div className="productNameLeft">
                                                                    <h6>{item.name}</h6>
                                                                    <p>{item.description || "Add a description."}</p>
                                                                </div>
                                                                <div className="productNameRight">
                                                                    <h6>${parseFloat(item.rate || 0).toFixed(2)}</h6>
                                                                    <p>{item.quantity} X {item.rate}</p>
                                                                    {item.gstChecked && item.gstValue && (
                                                                        <span>{Number(item.gstValue)}% GST</span>
                                                                    )}
                                                                </div>
                                                                <div className="editDelete ">
                                                                    <span className="edit" style={{ cursor: "pointer" }} onClick={() => handleEditItem(idx)}>
                                                                        <img src={IMAGE.editBtn} alt="" />
                                                                    </span>
                                                                    <span className="delete" style={{ cursor: "pointer" }} onClick={() => handleDeleteItem(idx)}>
                                                                        <img src={IMAGE.DeleteBtn} alt="" />
                                                                    </span>
                                                                </div>
                                                            </div>
                                                        ))}
                                                    </div> */}
                                                    <div className="col-lg-12">
                                                        {items.length === 0 && (
                                                            <div style={{ color: '#888', marginBottom: 8 }}>No items added yet.</div>
                                                        )}
                                                        {/* CREDIT NOTE DRAGDROP */}
                                                        <DndKitList handleEditItem={handleEditItem} handleDeleteItem={handleDeleteItem} items={items} setItems={setItems} currencyList={currencyList} />
                                                    </div>
                                                </div>
                                                <div className="row">
                                                    <div className="col-lg-3">
                                                        <button className="add-note" onClick={handleShowItemModal}>
                                                            <FontAwesomeIcon icon={faSquarePlus} /> Add items
                                                        </button>
                                                    </div>
                                                </div>
                                            </Accordion.Body>
                                        </Accordion.Item>
                                        <Accordion.Item eventKey="2">
                                            <Accordion.Header>
                                                <p className="accorheading">Attachments</p>
                                            </Accordion.Header>
                                            <Accordion.Body>
                                                <div className="col-lg-12" style={{ display: "flex", flexWrap: "wrap", gap: 16 }}>
                                                    {/* {console.log(attachments, "123456789o")} */}
                                                    {attachments.map((img, idx) => (
                                                        <div key={idx} style={{ position: "relative", marginBottom: 8 }}>
                                                            <img
                                                                src={img}
                                                                alt={`Attachment ${idx + 1}`}
                                                                style={{
                                                                    width: 80,
                                                                    height: 80,
                                                                    objectFit: "cover",
                                                                    borderRadius: 6,
                                                                    border: "1px solid #eee"
                                                                }}
                                                            />
                                                            <span
                                                                style={{
                                                                    position: "absolute",
                                                                    top: 2,
                                                                    right: 2,
                                                                    background: "#fff",
                                                                    borderRadius: "50%",
                                                                    cursor: "pointer",
                                                                    padding: "2px 4px",
                                                                    color: "#047FFF"
                                                                }}
                                                                onClick={() => handleRemoveAttachment(idx)}
                                                            >
                                                                <div className="crossBtn deleteCross" style={{ cursor: "pointer" }} onClick={handleAddClientFromModal}>
                                                                    <FontAwesomeIcon icon={faCircleXmark} />
                                                                </div>
                                                            </span>
                                                        </div>
                                                    ))}
                                                    <div className='addPhotoInput addPhotoCard'>

                                                        <img src={IMAGE.imagePicker} alt="" />
                                                        <input
                                                            type="file"
                                                            accept="image/*"
                                                            ref={logoInputRef}

                                                            multiple
                                                            onChange={handleLogoChange}
                                                        />
                                                        <div className='addPhotoInputButton'>

                                                            <button
                                                                className="add-photo"
                                                                style={{ width: 80, height: 80, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}
                                                                onClick={() => {
                                                                    if (logoInputRef.current) {
                                                                        logoInputRef.current.value = "";
                                                                        logoInputRef.current.click();
                                                                    }
                                                                }}
                                                                onKeyDown={(e) => {
                                                                    if (e.key === 'Enter' || e.key === ' ') {
                                                                        e.preventDefault();
                                                                        if (logoInputRef.current) {
                                                                            logoInputRef.current.value = "";
                                                                            logoInputRef.current.click();
                                                                        }
                                                                    }
                                                                }}
                                                            >
                                                                {/* <img src={IMAGE.imagePicker} alt="" /> */}
                                                                <input
                                                                    type="file"
                                                                    accept="image/*"
                                                                    ref={logoInputRef}
                                                                    multiple
                                                                    onChange={handleLogoChange}
                                                                    style={{ display: 'none' }}
                                                                />
                                                                <div className='addPhotoInputButton'>

                                                                    <button
                                                                        type="button"
                                                                        className="add-photo"
                                                                        style={{ width: 80, height: 80, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", pointerEvents: 'none' }}
                                                                    >
                                                                        <FontAwesomeIcon icon={faSquarePlus} style={{ fontSize: 24 }} />
                                                                        <span style={{ fontSize: 12 }}>Add Photo</span>
                                                                    </button>

                                                                </div>
                                                                </button>
                                                        </div>

                                                    </div>
                                                </div>
                                            </Accordion.Body>
                                        </Accordion.Item>
                                        <Accordion.Item eventKey="3">
                                            <Accordion.Header>
                                                <p className="accorheading">Comments</p>
                                            </Accordion.Header>
                                            <Accordion.Body>
                                                <div className="col-lg-12">
                                                    <textarea
                                                        className="input-form-control"
                                                        value={comment}
                                                        onChange={e => setComment(e.target.value)}
                                                        placeholder="Enter a comment for your customer..."
                                                    />
                                                </div>
                                            </Accordion.Body>
                                        </Accordion.Item>
                                    </Accordion>
                                </div>
                            </div>
                            <div className="col-md-4">
                                <div className="invoiceSection">
                                    <h5>Credit Note</h5>
                                    <div className="invoiceSectionInner">
                                        {!noteId && (
                                            <>
                                                <h6 style={{ margin: 0, display: 'inline-block' }}>{optionData.invoicePrifix ? optionData.invoicePrifix + '-' : ''}{editCreditMemoNumber ? "" : creditMemoNumber}</h6>
                                                {editCreditMemoNumber ? (
                                                    <input className='input-form-control'
                                                        type="text"
                                                        value={creditMemoNumberInput}
                                                        onChange={handleCreditMemoNumberInputChange}
                                                        onBlur={handleCreditMemoNumberInputBlur}
                                                        onKeyDown={handleCreditMemoNumberInputKeyDown}
                                                        style={{
                                                            width: 60,
                                                            fontSize: 18,
                                                            fontWeight: 600,
                                                            border: '1px solid #047FFF',
                                                            borderRadius: 4,
                                                            padding: '2px 6px'
                                                        }}
                                                        autoFocus />
                                                ) : (
                                                    <>
                                                        {/* <h6 style={{ margin: 0, display: 'inline-block' }}>{optionData.invoicePrifix ? optionData.invoicePrifix + '-' : ''}{creditMemoNumber}</h6> */}
                                                        <span style={{ marginLeft: 8, cursor: 'pointer' }} onClick={handleEditCreditMemoNumber}>
                                                            <FontAwesomeIcon icon={faPenToSquare} />
                                                        </span>
                                                    </>
                                                )}
                                            </>
                                        )}

                                        {noteId && (
                                            <h6 style={{ margin: 0, display: 'inline-block' }}>{optionData.invoicePrifix ? optionData.invoicePrifix + '-' : ''}{creditMemoNumber}</h6>
                                        )}
                                    </div>
                                    <p className="unsent">{sentStatus === "sent" ? "Sent" : "Unsent"}</p>
                                </div>
                                <div className="invoiceBox">
                                    <ul className="borderBottom ">
                                        <li>
                                            <p>Date</p>
                                            <span
                                                className="listBorder"
                                                style={{ cursor: "pointer", position: "relative" }}
                                                onClick={handleDateClick}
                                            >
                                                {formatDate(noteDate)}
                                                {showCalendar && (
                                                    <div ref={calendarRef}>
                                                        <Calendar
                                                            value={noteDate}
                                                            onChange={handleDateSelect}
                                                            onClickDay={handleDateSelect}
                                                        />
                                                    </div>
                                                )}
                                            </span>
                                        </li>
                                    </ul>
                                    <ul className="borderBottom ">
                                        <li>
                                            <p>Sub Total</p>
                                            <span>{formatCurrency(subtotal.toFixed(2), currencyList)}</span>
                                        </li>
                                    </ul>
                                    {hasItemLevelGst ? (
                                        <ul className="borderBottom">
                                            <li>
                                                <p>GST</p>
                                                <span>{formatCurrency(gstTotal.toFixed(2), currencyList)}</span>
                                            </li>
                                        </ul>
                                    ) : (
                                        ""
                                    )}
                                    <ul className="borderBottom">
                                        <li>
                                            <p>Total</p>
                                            <span>{formatCurrency(total.toFixed(2), currencyList)}</span>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    )}

                    {activeTab === "Preview" && (
                        <div className='row'>
                            <div className='col-md-8'>
                                <div ref={previewRef}>
                                    {formData.templateName === 'impact' && (
                                        <CustomInvoiceImpact
                                            invoice={{
                                                name: "Credit Note",
                                                creditMemoNumber,
                                                selectedClient,
                                                noteDate,
                                                items,
                                                subtotal,
                                                gstTotal,
                                                total,
                                                logo,
                                                attachments,
                                                comment
                                            }}
                                            logoFile={logo}
                                            photoFiles={attachments}
                                            editCreditMemoNumber={editCreditMemoNumber}
                                            creditMemoNumberInput={creditMemoNumberInput}
                                            handleCreditMemoNumberInputChange={handleCreditMemoNumberInputChange}
                                            handleCreditMemoNumberInputBlur={handleCreditMemoNumberInputBlur}
                                            handleCreditMemoNumberInputKeyDown={handleCreditMemoNumberInputKeyDown}
                                            handleEditCreditMemoNumber={handleEditCreditMemoNumber}
                                            onBackToEdit={() => setActiveTab('Create')}
                                            ref={null}
                                            selectedTemp={formData.templateName}
                                            selectedId={
                                                formData.logoId
                                                    ? { id: formData.logoId, logoImage: formData.logoImage }
                                                    : null
                                            }
                                            selectedSize={formData.logoSize}
                                            alignPos={formData.logoPosition}
                                            selectedColour={
                                                formData.colourId
                                                    ? { id: formData.colourId, colourCode: formData.colourCode }
                                                    : null
                                            }
                                            customColour={formData.customColour}
                                            selectedHeader={
                                                formData.headerId
                                                    ? { id: formData.headerId, headerImg: formData.headerImg }
                                                    : null
                                            }
                                            selectedWatermark={
                                                formData.waterMarkId
                                                    ? {
                                                        id: formData.waterMarkId,
                                                        waterMarkImg: formData.waterMarkImg,
                                                    }
                                                    : null
                                            }
                                            customTemplates={customTemplates}
                                            customOption={optionData}
                                            signatureName={sigCreditNote}
                                            signatureType={signatureType}
                                            signature={{
                                                padSignature,
                                                uploadSignature,
                                                signatureText
                                            }}
                                            currencyList={currencyList}
                                        />
                                    )}
                                    {formData.templateName === 'modern' && (
                                        <CustomInvoiceImpact
                                            invoice={{
                                                name: "Credit Note",
                                                creditMemoNumber,
                                                selectedClient,
                                                noteDate,
                                                items,
                                                subtotal,
                                                gstTotal,
                                                total,
                                                logo,
                                                attachments,
                                                comment
                                            }}
                                            logoFile={logo}
                                            photoFiles={attachments}
                                            editCreditMemoNumber={editCreditMemoNumber}
                                            creditMemoNumberInput={creditMemoNumberInput}
                                            handleCreditMemoNumberInputChange={handleCreditMemoNumberInputChange}
                                            handleCreditMemoNumberInputBlur={handleCreditMemoNumberInputBlur}
                                            handleCreditMemoNumberInputKeyDown={handleCreditMemoNumberInputKeyDown}
                                            handleEditCreditMemoNumber={handleEditCreditMemoNumber}
                                            onBackToEdit={() => setActiveTab('Create')}
                                            ref={null}
                                            selectedId={
                                                formData.logoId
                                                    ? { id: formData.logoId, logoImage: formData.logoImage }
                                                    : null
                                            }
                                            selectedSize={formData.logoSize}
                                            alignPos={formData.logoPosition}
                                            selectedColour={
                                                formData.colourId
                                                    ? { id: formData.colourId, colourCode: formData.colourCode }
                                                    : null
                                            }
                                            customColour={formData.customColour}
                                            selectedHeader={
                                                formData.headerId
                                                    ? { id: formData.headerId, headerImg: formData.headerImg }
                                                    : null
                                            }
                                            selectedWatermark={
                                                formData.waterMarkId
                                                    ? {
                                                        id: formData.waterMarkId,
                                                        waterMarkImg: formData.waterMarkImg,
                                                    }
                                                    : null
                                            }
                                            customTemplates={customTemplates}
                                            customOption={optionData}
                                            signatureName={sigCreditNote}
                                            signatureType={signatureType}
                                            signature={{
                                                padSignature,
                                                uploadSignature,
                                                signatureText
                                            }}
                                            currencyList={currencyList}
                                        />
                                    )}

                                    {formData.templateName === 'classic' && (
                                        <CustomInvoiceImpact
                                            invoice={{
                                                name: "Credit Note",
                                                creditMemoNumber,
                                                selectedClient,
                                                noteDate,
                                                items,
                                                subtotal,
                                                gstTotal,
                                                total,
                                                logo,
                                                attachments,
                                                comment
                                            }}
                                            logoFile={logo}
                                            photoFiles={attachments}
                                            editCreditMemoNumber={editCreditMemoNumber}
                                            creditMemoNumberInput={creditMemoNumberInput}
                                            handleCreditMemoNumberInputChange={handleCreditMemoNumberInputChange}
                                            handleCreditMemoNumberInputBlur={handleCreditMemoNumberInputBlur}
                                            handleCreditMemoNumberInputKeyDown={handleCreditMemoNumberInputKeyDown}
                                            handleEditCreditMemoNumber={handleEditCreditMemoNumber}
                                            onBackToEdit={() => setActiveTab('Create')}
                                            ref={null}
                                            selectedId={
                                                formData.logoId
                                                    ? { id: formData.logoId, logoImage: formData.logoImage }
                                                    : null
                                            }
                                            selectedSize={formData.logoSize}
                                            alignPos={formData.logoPosition}
                                            selectedColour={
                                                formData.colourId
                                                    ? { id: formData.colourId, colourCode: formData.colourCode }
                                                    : null
                                            }
                                            customColour={formData.customColour}
                                            selectedHeader={
                                                formData.headerId
                                                    ? { id: formData.headerId, headerImg: formData.headerImg }
                                                    : null
                                            }
                                            selectedWatermark={
                                                formData.waterMarkId
                                                    ? {
                                                        id: formData.waterMarkId,
                                                        waterMarkImg: formData.waterMarkImg,
                                                    }
                                                    : null
                                            }
                                            customTemplates={customTemplates}
                                            customOption={optionData}
                                            signatureName={sigCreditNote}
                                            signatureType={signatureType}
                                            signature={{
                                                padSignature,
                                                uploadSignature,
                                                signatureText
                                            }}
                                            currencyList={currencyList}
                                        />
                                    )}
                                </div>
                            </div>
                            <div className="col-md-4">
                                <div className="invoiceSection">
                                    <h5>Credit Note</h5>
                                    <div className="invoiceSectionInner">
                                        {!noteId && (
                                            <>
                                                <h6 style={{ margin: 0, display: 'inline-block' }}>{optionData.invoicePrifix ? optionData.invoicePrifix + '-' : ''}{editCreditMemoNumber ? "" : creditMemoNumber}</h6>
                                                {editCreditMemoNumber ? (
                                                    <input className='input-form-control'
                                                        type="text"
                                                        value={creditMemoNumberInput}
                                                        onChange={handleCreditMemoNumberInputChange}
                                                        onBlur={handleCreditMemoNumberInputBlur}
                                                        onKeyDown={handleCreditMemoNumberInputKeyDown}
                                                        style={{
                                                            width: 60,
                                                            fontSize: 18,
                                                            fontWeight: 600,
                                                            border: '1px solid #047FFF',
                                                            borderRadius: 4,
                                                            padding: '2px 6px'
                                                        }}
                                                        autoFocus />
                                                ) : (
                                                    <>
                                                        {/* <h6 style={{ margin: 0, display: 'inline-block' }}>{optionData.invoicePrifix ? optionData.invoicePrifix + '-' : ''}{creditMemoNumber}</h6> */}
                                                        <span style={{ marginLeft: 8, cursor: 'pointer' }} onClick={handleEditCreditMemoNumber}>
                                                            <FontAwesomeIcon icon={faPenToSquare} />
                                                        </span>
                                                    </>
                                                )}
                                            </>
                                        )}

                                        {noteId && (
                                            <h6 style={{ margin: 0, display: 'inline-block' }}>{optionData.invoicePrifix ? optionData.invoicePrifix + '-' : ''}{creditMemoNumber}</h6>
                                        )}
                                        <p className="unsent">{sentStatus === "sent" ? "Sent" : "Unsent"}</p>
                                    </div>
                                    <div className="invoiceBox">
                                        <ul className="borderBottom ">
                                            <li>
                                                <p>Date</p>
                                                <span>{formatDate(noteDate)}</span>
                                            </li>
                                        </ul>
                                        <ul className="borderBottom ">
                                            <li>
                                                <p>Sub Total</p>
                                                <span>{formatCurrency(subtotal.toFixed(2), currencyList)}</span>
                                            </li>
                                        </ul>
                                        {hasItemLevelGst ? (
                                            <ul className="borderBottom">
                                                <li>
                                                    <p>GST</p>
                                                    <span>{formatCurrency(gstTotal.toFixed(2), currencyList)}</span>
                                                </li>
                                            </ul>
                                        ) : (
                                            ""
                                        )}
                                        <ul className="borderBottom">
                                            <li>
                                                <p>Total</p>
                                                <span>{formatCurrency(total.toFixed(2), currencyList)}</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}

                    {activeTab === "Send" && (
                        <div className="row">
                            <div style={{ position: "absolute", left: "-9999px" }}>
                                <div ref={previewRef}>
                                    {formData.templateName === 'impact' && (
                                        <CustomInvoiceImpact
                                            invoice={{
                                                name: "Credit Note",
                                                creditMemoNumber,
                                                selectedClient,
                                                noteDate,
                                                items,
                                                subtotal,
                                                gstTotal,
                                                total,
                                                logo,
                                                attachments,
                                                comment
                                            }}
                                            logoFile={logo}
                                            photoFiles={attachments}
                                            editCreditMemoNumber={editCreditMemoNumber}
                                            creditMemoNumberInput={creditMemoNumberInput}
                                            handleCreditMemoNumberInputChange={handleCreditMemoNumberInputChange}
                                            handleCreditMemoNumberInputBlur={handleCreditMemoNumberInputBlur}
                                            handleCreditMemoNumberInputKeyDown={handleCreditMemoNumberInputKeyDown}
                                            handleEditCreditMemoNumber={handleEditCreditMemoNumber}
                                            onBackToEdit={() => setActiveTab('Create')}
                                            ref={null}
                                            selectedTemp={formData.templateName}
                                            selectedId={
                                                formData.logoId
                                                    ? { id: formData.logoId, logoImage: formData.logoImage }
                                                    : null
                                            }
                                            selectedSize={formData.logoSize}
                                            alignPos={formData.logoPosition}
                                            selectedColour={
                                                formData.colourId
                                                    ? { id: formData.colourId, colourCode: formData.colourCode }
                                                    : null
                                            }
                                            customColour={formData.customColour}
                                            selectedHeader={
                                                formData.headerId
                                                    ? { id: formData.headerId, headerImg: formData.headerImg }
                                                    : null
                                            }
                                            selectedWatermark={
                                                formData.waterMarkId
                                                    ? {
                                                        id: formData.waterMarkId,
                                                        waterMarkImg: formData.waterMarkImg,
                                                    }
                                                    : null
                                            }
                                            customTemplates={customTemplates}
                                            customOption={optionData}
                                            signatureName={sigCreditNote}
                                            signatureType={signatureType}
                                            signature={{
                                                padSignature,
                                                uploadSignature,
                                                signatureText
                                            }}
                                            currencyList={currencyList}
                                        />
                                    )}
                                    {formData.templateName === 'modern' && (
                                        <CustomInvoiceImpact
                                            invoice={{
                                                name: "Credit Note",
                                                creditMemoNumber,
                                                selectedClient,
                                                noteDate,
                                                items,
                                                subtotal,
                                                gstTotal,
                                                total,
                                                logo,
                                                attachments,
                                                comment
                                            }}
                                            logoFile={logo}
                                            photoFiles={attachments}
                                            editCreditMemoNumber={editCreditMemoNumber}
                                            creditMemoNumberInput={creditMemoNumberInput}
                                            handleCreditMemoNumberInputChange={handleCreditMemoNumberInputChange}
                                            handleCreditMemoNumberInputBlur={handleCreditMemoNumberInputBlur}
                                            handleCreditMemoNumberInputKeyDown={handleCreditMemoNumberInputKeyDown}
                                            handleEditCreditMemoNumber={handleEditCreditMemoNumber}
                                            onBackToEdit={() => setActiveTab('Create')}
                                            ref={null}
                                            selectedId={
                                                formData.logoId
                                                    ? { id: formData.logoId, logoImage: formData.logoImage }
                                                    : null
                                            }
                                            selectedSize={formData.logoSize}
                                            alignPos={formData.logoPosition}
                                            selectedColour={
                                                formData.colourId
                                                    ? { id: formData.colourId, colourCode: formData.colourCode }
                                                    : null
                                            }
                                            customColour={formData.customColour}
                                            selectedHeader={
                                                formData.headerId
                                                    ? { id: formData.headerId, headerImg: formData.headerImg }
                                                    : null
                                            }
                                            selectedWatermark={
                                                formData.waterMarkId
                                                    ? {
                                                        id: formData.waterMarkId,
                                                        waterMarkImg: formData.waterMarkImg,
                                                    }
                                                    : null
                                            }
                                            customTemplates={customTemplates}
                                            customOption={optionData}
                                            signatureName={sigCreditNote}
                                            signatureType={signatureType}
                                            signature={{
                                                padSignature,
                                                uploadSignature,
                                                signatureText
                                            }}
                                            currencyList={currencyList}
                                        />
                                    )}

                                    {formData.templateName === 'classic' && (
                                        <CustomInvoiceImpact
                                            invoice={{
                                                name: "Credit Note",
                                                creditMemoNumber,
                                                selectedClient,
                                                noteDate,
                                                items,
                                                subtotal,
                                                gstTotal,
                                                total,
                                                logo,
                                                attachments,
                                                comment
                                            }}
                                            logoFile={logo}
                                            photoFiles={attachments}
                                            editCreditMemoNumber={editCreditMemoNumber}
                                            creditMemoNumberInput={creditMemoNumberInput}
                                            handleCreditMemoNumberInputChange={handleCreditMemoNumberInputChange}
                                            handleCreditMemoNumberInputBlur={handleCreditMemoNumberInputBlur}
                                            handleCreditMemoNumberInputKeyDown={handleCreditMemoNumberInputKeyDown}
                                            handleEditCreditMemoNumber={handleEditCreditMemoNumber}
                                            onBackToEdit={() => setActiveTab('Create')}
                                            ref={null}
                                            selectedId={
                                                formData.logoId
                                                    ? { id: formData.logoId, logoImage: formData.logoImage }
                                                    : null
                                            }
                                            selectedSize={formData.logoSize}
                                            alignPos={formData.logoPosition}
                                            selectedColour={
                                                formData.colourId
                                                    ? { id: formData.colourId, colourCode: formData.colourCode }
                                                    : null
                                            }
                                            customColour={formData.customColour}
                                            selectedHeader={
                                                formData.headerId
                                                    ? { id: formData.headerId, headerImg: formData.headerImg }
                                                    : null
                                            }
                                            selectedWatermark={
                                                formData.waterMarkId
                                                    ? {
                                                        id: formData.waterMarkId,
                                                        waterMarkImg: formData.waterMarkImg,
                                                    }
                                                    : null
                                            }
                                            customTemplates={customTemplates}
                                            customOption={optionData}
                                            signatureName={sigCreditNote}
                                            signatureType={signatureType}
                                            signature={{
                                                padSignature,
                                                uploadSignature,
                                                signatureText
                                            }}
                                            currencyList={currencyList}
                                        />
                                    )}
                                </div>
                            </div>
                            <div className="col-md-8">
                                <div className="mt-0 minScrollHeight">
                                    <div className="sub-head">
                                        <p className="subheading">Bill To</p>
                                    </div>
                                    <div className='col-lg-12 px-2'>

                                        <div className='email-setup-top' style={{ display: 'flex', gap: 0, alignItems: 'center' }}>
                                            <div className="floating-label-group" style={{ marginBottom: 8, width: '80%', }}>
                                                <label className="floating-label">To</label>
                                                <div className='selectInputUser' style={{ display: 'flex', flexWrap: 'wrap', gap: 4, alignItems: 'center' }}>
                                                    {sendToEmails.map((email, idx) => (
                                                        <span key={idx} style={{
                                                            background: '#e6f0ff',
                                                            borderRadius: 12,
                                                            padding: '2px 8px',
                                                            marginRight: 4,
                                                            marginTop: 0,
                                                            display: 'flex',
                                                            alignItems: 'center'
                                                        }}>
                                                            {email}
                                                            <span
                                                                style={{ marginLeft: 4, cursor: 'pointer', color: '#047FFF' }}
                                                                onClick={() => handleRemoveEmail('to', idx)}
                                                            >
                                                                <FontAwesomeIcon icon={faCircleXmark} />
                                                            </span>
                                                        </span>
                                                    ))}
                                                    {/* <input type="text" id="billing-add" className="input-form-control input-logo" required /> */}
                                                    <input
                                                        type="text"
                                                        // id="billing-add"
                                                        className="input-form-control input-logo inputBorderNone"
                                                        required
                                                        style={{ minWidth: 120, flex: 1 }}
                                                        value={sendToInput}
                                                        onChange={e => setSendToInput(e.target.value)}
                                                        onKeyDown={e => handleEmailInputKeyDown(e, 'to')}
                                                        onBlur={() => handleAddEmail('to', sendToInput)}
                                                        placeholder={sendToEmails.length === 0 ? "Enter email" : ""}
                                                    />
                                                </div>
                                            </div>
                                            <div className='ccbc' style={{ width: '20%', display: 'flex', gap: 8, alignItems: 'center', paddingLeft: "20px", marginTop: "16px" }} >
                                                {/* <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginLeft: 8 }}> */}
                                                {!showCc && (
                                                    <span
                                                        style={{ cursor: 'pointer', color: '#047FFF', fontWeight: 500 }}
                                                        onClick={() => setShowCc(true)}
                                                    >Cc</span>
                                                )}
                                                {!showBcc && (
                                                    <span
                                                        style={{ cursor: 'pointer', color: '#047FFF', fontWeight: 500 }}
                                                        onClick={() => setShowBcc(true)}
                                                    >Bcc</span>
                                                )}
                                            </div>
                                        </div>

                                        <div className='bcccTop' style={{ width: "80%" }}>

                                            {showCc && (
                                                <div className="floating-label-group" style={{ marginBottom: 8 }}>
                                                    <label className="floating-label">Cc</label>
                                                    <div className="selectInputUser" style={{ display: 'flex', flexWrap: 'wrap', gap: 4, alignItems: 'center' }}>
                                                        {sendCcEmails.map((email, idx) => (
                                                            <span key={idx} style={{
                                                                background: '#e6f0ff',
                                                                borderRadius: 12,
                                                                padding: '2px 8px',
                                                                marginRight: 4,
                                                                marginTop: 0,
                                                                display: 'flex',
                                                                alignItems: 'center'
                                                            }}>
                                                                {email}
                                                                <span
                                                                    style={{ marginLeft: 4, cursor: 'pointer', color: '#047FFF' }}
                                                                    onClick={() => handleRemoveEmail('cc', idx)}
                                                                >
                                                                    <FontAwesomeIcon icon={faCircleXmark} />
                                                                </span>
                                                            </span>
                                                        ))}
                                                        <input
                                                            type="text"
                                                            className="input-form-control input-logo inputBorderNone"
                                                            style={{ minWidth: 120, flex: 1 }}
                                                            value={sendCcInput}
                                                            onChange={e => setSendCcInput(e.target.value)}
                                                            onKeyDown={e => handleEmailInputKeyDown(e, 'cc')}
                                                            onBlur={() => handleAddEmail('cc', sendCcInput)}
                                                            placeholder={sendCcEmails.length === 0 ? "Enter email" : ""}
                                                        />
                                                    </div>
                                                </div>
                                            )}
                                            {showBcc && (
                                                <div className="floating-label-group" style={{ marginBottom: 8 }}>
                                                    <label className="floating-label">Bcc</label>
                                                    <div className="selectInputUser" style={{ display: 'flex', flexWrap: 'wrap', gap: 4, alignItems: 'center' }}>
                                                        {sendBccEmails.map((email, idx) => (
                                                            <span key={idx} style={{
                                                                background: '#e6f0ff',
                                                                borderRadius: 12,
                                                                padding: '2px 8px',
                                                                marginRight: 4,
                                                                marginTop: 0,
                                                                display: 'flex',
                                                                alignItems: 'center'
                                                            }}>
                                                                {email}
                                                                <span
                                                                    style={{ marginLeft: 4, cursor: 'pointer', color: '#047FFF' }}
                                                                    onClick={() => handleRemoveEmail('bcc', idx)}
                                                                >
                                                                    <FontAwesomeIcon icon={faCircleXmark} />
                                                                </span>
                                                            </span>
                                                        ))}
                                                        <input
                                                            type="text"
                                                            className="input-form-control input-logo inputBorderNone"
                                                            style={{ minWidth: 120, flex: 1 }}
                                                            value={sendBccInput}
                                                            onChange={e => setSendBccInput(e.target.value)}
                                                            onKeyDown={e => handleEmailInputKeyDown(e, 'bcc')}
                                                            onBlur={() => handleAddEmail('bcc', sendBccInput)}
                                                            placeholder={sendBccEmails.length === 0 ? "Enter email" : ""}
                                                        />
                                                    </div>
                                                </div>
                                            )}
                                        </div>

                                    </div>
                                    <div className="sub-head">
                                        <p className="subheading">Comment</p>
                                    </div>
                                    <div className='col-lg-12 col-md-12 col-sm-12 px-2'>
                                        <div className="floating-label-group">
                                            <label className="floating-label">Notes</label>
                                            <textarea
                                                type="text"
                                                id="logo"
                                                className="input-form-control"
                                                required
                                                value={sendNotes}
                                                onChange={e => setSendNotes(e.target.value)}
                                            />
                                        </div>
                                    </div>
                                    <div className="sub-head">
                                        <p className="subheading">Attachment</p>
                                    </div>
                                    <div className="row px-2">
                                        <div className="col-lg-3">
                                            <div className="card image-card pdfParaMargin">
                                                <div className="card-body">
                                                    <div>
                                                        <p style={{ margin: "0" }}>
                                                            <FontAwesomeIcon icon={faFilePdf} style={{ fontSize: 60, color: "#d32f2f", marginBottom: 8, width: 60, height: 60 }} /><br />
                                                            CN_<span>{creditMemoNumber}</span>
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        {attachments.map((img, idx) => (
                                            <div className="col-lg-3" key={idx}>
                                                <div className="card image-card pdfParaMargin">
                                                    <div className="card-body">
                                                        <img
                                                            src={img}
                                                            alt={`Attachment ${idx + 1}`}
                                                            style={{
                                                                width: 80,
                                                                height: 80,
                                                                objectFit: "cover",
                                                                borderRadius: 6,
                                                                border: "1px solid #eee"
                                                            }}
                                                        />
                                                    </div>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-4">
                                <div className="invoiceSection">
                                    <h5>Credit Note</h5>
                                    <div className="invoiceSectionInner">
                                        {!noteId && (
                                            <>
                                                <h6 style={{ margin: 0, display: 'inline-block' }}>{optionData.invoicePrifix ? optionData.invoicePrifix + '-' : ''}{editCreditMemoNumber ? "" : creditMemoNumber}</h6>
                                                {editCreditMemoNumber ? (
                                                    <input className='input-form-control'
                                                        type="text"
                                                        value={creditMemoNumberInput}
                                                        onChange={handleCreditMemoNumberInputChange}
                                                        onBlur={handleCreditMemoNumberInputBlur}
                                                        onKeyDown={handleCreditMemoNumberInputKeyDown}
                                                        style={{
                                                            width: 60,
                                                            fontSize: 18,
                                                            fontWeight: 600,
                                                            border: '1px solid #047FFF',
                                                            borderRadius: 4,
                                                            padding: '2px 6px'
                                                        }}
                                                        autoFocus />
                                                ) : (
                                                    <>
                                                        {/* <h6 style={{ margin: 0, display: 'inline-block' }}>{optionData.invoicePrifix ? optionData.invoicePrifix + '-' : ''}{creditMemoNumber}</h6> */}
                                                        <span style={{ marginLeft: 8, cursor: 'pointer' }} onClick={handleEditCreditMemoNumber}>
                                                            <FontAwesomeIcon icon={faPenToSquare} />
                                                        </span>
                                                    </>
                                                )}
                                            </>
                                        )}

                                        {noteId && (
                                            <h6 style={{ margin: 0, display: 'inline-block' }}>{optionData.invoicePrifix ? optionData.invoicePrifix + '-' : ''}{creditMemoNumber}</h6>
                                        )}
                                    </div>
                                    <p className="unsent">{sentStatus === "sent" ? "Sent" : "Unsent"}</p>
                                </div>
                                <div className="invoiceBox">
                                    <ul className="borderBottom ">
                                        <li>
                                            <p>Date</p>
                                            <span>{formatDate(noteDate)}</span>
                                        </li>
                                    </ul>
                                    <ul className="borderBottom ">
                                        <li>
                                            <p>Sub Total</p>
                                            <span>{formatCurrency(subtotal.toFixed(2), currencyList)}</span>
                                        </li>
                                    </ul>
                                    {hasItemLevelGst ? (
                                        <ul className="borderBottom">
                                            <li>
                                                <p>GST</p>
                                                <span>{formatCurrency(gstTotal.toFixed(2), currencyList)}</span>
                                            </li>
                                        </ul>
                                    ) : (
                                        ""
                                    )}
                                    <ul className="borderBottom">
                                        <li>
                                            <p>Total</p>
                                            <span>{formatCurrency(total.toFixed(2), currencyList)}</span>
                                        </li>
                                    </ul>
                                </div>
                                <div style={{ marginTop: 16 }}>
                                    <Button className="add-note" onClick={handleSendPdf} disabled={!previewPdfFile} style={{ width: "100%" }}>
                                        Send Credit Note
                                    </Button>
                                    <Button className="add-note" onClick={handleDownloadPdf} disabled={!previewPdfFile} style={{ width: "100%" }}>
                                        Download Credit Note
                                    </Button>
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </div>

            {/* Client Modal */}
            <Modal
                show={showClientModal}
                onHide={handleCloseClientModal} centered
            >
                <Modal.Header closeButton>
                    <Modal.Title>Add Client</Modal.Title>
                </Modal.Header>
                <Modal.Body style={{ marginTop: '0px' }}>
                    <div className="mb-3">
                        <div className="floating-label-group mb-2" style={{ position: 'relative' }}>
                            <label className="floating-label">Name</label>
                            <input
                                type="text"
                                name="name"
                                className="input-form-control"
                                required
                                autoComplete="off"
                                autoFocus
                                value={clientForm.name}
                                onChange={handleClientFormChange}
                                onFocus={() => {
                                    setShowClientDropdown(true);
                                    if (clientForm.name.trim().length === 0) setClientDropdown(clientList);
                                }}
                                onBlur={() => setTimeout(() => setShowClientDropdown(false), 200)}
                            />
                            {showClientDropdown && clientDropdown.length > 0 && (
                                <ul className="list-group" style={{
                                    position: 'absolute',
                                    zIndex: 10,
                                    width: '100%',
                                    top: '100%',
                                    left: 0,
                                    maxHeight: 150,
                                    overflowY: 'auto'
                                }}>
                                    {clientDropdown.map((client, idx) => (
                                        <li
                                            key={client.id || idx}
                                            className="list-group-item"
                                            style={{ cursor: 'pointer' }}
                                            onMouseDown={() => {
                                                handleClientDropdownSelect(client);
                                            }}
                                        >
                                            <strong>{client.name}</strong>
                                            <div style={{ fontSize: '0.9em', color: '#888' }}>{client.email}</div>
                                        </li>
                                    ))}
                                </ul>
                            )}
                            {clientFormErrors.name && (
                                <div style={{ color: 'red', fontSize: 13, marginTop: 2 }}>{clientFormErrors.name}</div>
                            )}
                        </div>
                        <div className="floating-label-group mb-2">
                            <label className="floating-label">Email</label>
                            <input
                                type="email"
                                name="email"
                                className="input-form-control"
                                required
                                value={clientForm.email}
                                onChange={handleClientFormChange}
                            />
                            {clientFormErrors.email && (
                                <div style={{ color: 'red', fontSize: 13, marginTop: 2 }}>{clientFormErrors.email}</div>
                            )}
                        </div>
                        <div className="floating-label-group mb-2">
                            <label className="floating-label">Phone</label>
                            <input
                                type="text"
                                name="phone"
                                className="input-form-control"
                                required
                                value={clientForm.phone}
                                onChange={handleClientFormChange}
                                maxLength={10}
                            />
                            {clientFormErrors.phone && (
                                <div style={{ color: 'red', fontSize: 13, marginTop: 2 }}>{clientFormErrors.phone}</div>
                            )}
                        </div>
                        <Button
                            variant="primary"
                            className='modal-btn addBtnn'
                            style={{ marginTop: 25 }}
                            onClick={handleAddClientFromModal}
                        >
                            Add
                        </Button>
                    </div>
                </Modal.Body>
            </Modal>

            {/* Add/Edit Item Modal */}
            <Modal centered
                show={showItemModal}
                onHide={handleCloseItemModal}
                onShow={async () => {
                    const result = await dispatch(fetchTaxData());
                    if (result && result.payload && Array.isArray(result.payload.data)) {
                        setTaxRates(result.payload.data);
                    } else {
                        setTaxRates([]);
                    }
                }}
            >
                <Modal.Header closeButton>
                    <Modal.Title>{editItemIndex !== null ? "Edit Item" : "Add Item"}</Modal.Title>
                </Modal.Header>
                <Modal.Body className='mt-0 mb-0 editItemModalonly'>
                    <div style={{ textAlign: 'center' }}>
                        <button className='add-note' type="button" onClick={handleChooseItemOpen}>
                            <FontAwesomeIcon icon={faSquarePlus} />Choose Multiple
                        </button>
                    </div>
                    <div style={{ textAlign: 'center', margin: '12px 0 0px' }}>Or</div>
                    <div className='row'>
                        <div className='col-lg-12'>
                            <div className="floating-label-group mb-3">
                                <label className="floating-label">Item Name</label>
                                <input
                                    type="text"
                                    name="name"
                                    className="input-form-control"
                                    required
                                    value={itemForm.name}
                                    onChange={handleItemFormChange}
                                />
                                {itemFormErrors.name && (
                                    <div style={{ color: "red", fontSize: 13, marginTop: 2 }}>{itemFormErrors.name}</div>
                                )}
                            </div>
                            <div className="floating-label-group mb-3">
                                <label className="floating-label">Item Description</label>
                                <textarea
                                    name="description"
                                    className="input-form-control modal-textarea"
                                    required
                                    value={itemForm.description}
                                    onChange={handleItemFormChange}
                                />
                            </div>
                            <div style={{ display: 'flex', gap: 16, marginBottom: 16 }}>
                                <div style={{ flex: 1 }}>
                                    <div className="floating-label-group">
                                        <label className="floating-label">Rate</label>
                                        <input
                                            type="number"
                                            name="rate"
                                            className="small-input input-form-control"
                                            required
                                            value={itemForm.rate}
                                            onChange={handleItemFormChange}
                                            min="0"
                                        />
                                        {itemFormErrors.rate && (
                                            <div style={{ color: "red", fontSize: 13, marginTop: 2 }}>{itemFormErrors.rate}</div>
                                        )}
                                    </div>
                                </div>
                                <div style={{ flex: 1 }}>
                                    <div className="floating-label-group">
                                        <label className="floating-label">Qty</label>
                                        <input
                                            type="number"
                                            name="quantity"
                                            className="small-input input-form-control"
                                            required
                                            value={itemForm.quantity}
                                            onChange={handleItemFormChange}
                                            min="1"
                                            max="9999999999"
                                        />
                                        {itemFormErrors.quantity && (
                                            <div style={{ color: "red", fontSize: 13, marginTop: 2 }}>{itemFormErrors.quantity}</div>
                                        )}
                                    </div>
                                </div>
                                <div style={{ flex: 1 }}>
                                    <div className="payment-type-dropdown">
                                        <label className="floating-label">Unit</label>
                                        <select
                                            className="small-input input-form-control"
                                            value={itemForm.unitTypes}
                                            onChange={(e) => setItemForm({ ...itemForm, unitTypes: e.target.value })}
                                            style={{ minWidth: 120, marginLeft: 0 }}
                                        >
                                            <option value="">Select Unit</option>
                                            {unitTypes.map((unit) => (
                                                <option key={unit.id} value={unit.value}>
                                                    {unit.value}
                                                </option>
                                            ))}
                                        </select>
                                        <p class="dropdownIcon">
                                            <img src={IMAGE.dropdownColor} />
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <Accordion defaultActiveKey="0">
                                <Accordion.Item eventKey="0">
                                    <Accordion.Header>
                                        <p className='accorheading'>GST</p>
                                    </Accordion.Header>
                                    <Accordion.Body>
                                        <div style={{ display: 'flex', gap: 16, alignItems: 'center', marginBottom: 16 }}>
                                            <div className='checkboxLeft' style={{ display: 'flex', alignItems: 'center' }}>
                                                <input
                                                    type="checkbox"
                                                    name="gstChecked"
                                                    checked={(itemForm.gstChecked == 'false' || itemForm.gstChecked == false) ? false : true}
                                                    onChange={handleItemGstCheck}
                                                    id="gstCheck"
                                                />
                                                <label htmlFor="gstCheck" style={{ marginLeft: 8 }}>GST</label>
                                            </div>
                                            {(itemForm.gstChecked == 'true' || itemForm.gstChecked == true) && (
                                                <div className="form-group payment-type-dropdown " style={{ margin: 0 }}>
                                                    <select
                                                        className="small-input input-form-control "
                                                        value={itemForm.gstValue}
                                                        onChange={(e) => setItemForm({ ...itemForm, gstValue: e.target.value })}
                                                        style={{ minWidth: 120, marginLeft: 8 }}
                                                    >
                                                        <option value="">Select Rate</option>
                                                        {taxRates.map((rate) => (
                                                            <option key={rate.id} value={rate.percentage}>
                                                                {rate.percentage}%
                                                            </option>
                                                        ))}
                                                    </select>
                                                    <p class="dropdownIcon drpdwnLable">
                                                        <img src={IMAGE.dropdownColor} />
                                                    </p>
                                                </div>
                                            )}
                                        </div>
                                    </Accordion.Body>
                                </Accordion.Item>
                            </Accordion>
                            <button className='modal-btn addBtnn' onClick={handleSaveItem}>
                                {editItemIndex !== null ? "Update" : "Add"}
                            </button>
                        </div>
                    </div>
                </Modal.Body>
            </Modal>

            {/* Choose Item Modal */}
            <Modal show={showChooseItemModal} onHide={handleChooseItemClose} centered>
                <Modal.Header closeButton>
                    <span
                        style={{ cursor: 'pointer', marginRight: 12 }}
                        onClick={handleBackClick}
                    >
                        <FontAwesomeIcon icon={faArrowLeft} />
                    </span>
                    <Modal.Title>Choose Items</Modal.Title>
                </Modal.Header>
                <Modal.Body style={{ marginTop: '0px' }} className='listingSearchMain'>
                    {filteredChooseItemList.length === 0 ? (
                        <div>There are no items added yet. <span style={{ cursor: 'pointer', color: '#007bff' }} onClick={handleBackClick}>Click here</span> to add items.</div>
                    ) : (
                        <>
                            <div className="d-flex justify-content-end mb-3 searchCustom">
                                <input
                                    type="text"
                                    className="search-input-retains-placeholder form-control"
                                    style={{
                                        width: '125px',
                                        borderRadius: '12px',
                                        boxShadow: '0 2px 6px rgba(0,0,0,0.1)',
                                        border: '1px solid #ccc',
                                    }}
                                    placeholder="🔍︎ Search here..."
                                    value={itemSearch}
                                    autoFocus
                                    onChange={e => setItemSearch(e.target.value)}
                                />
                            </div>
                            <ul className="list-group" style={{ marginBottom: '20px' }}>
                                {filteredChooseItemList.map((item, idx) => {
                                    const checked = !!chooseSelectedItems.find(i => i.id === item.id);
                                    return (
                                        <li
                                            key={item.id || idx}
                                            className="list-group-item"
                                            style={{ cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}
                                        // onClick={() => handleChooseItemToggle(item)}
                                        >
                                            <div className=''>
                                                <label htmlFor={'itemOfItems' + idx} className='' style={{ display: "flex", gap: "5px", alignItems: "center" }}>
                                                    <input
                                                        type="checkbox"
                                                        id={"itemOfItems" + idx}
                                                        checked={checked}
                                                        onChange={() => handleChooseItemToggle(item)}
                                                        style={{ marginRight: 8 }}
                                                    />
                                                    <div style={{ display: "flex", flexDirection: "column", gap: "2px", justifyContent: "center" }}>
                                                        <strong>{item.name || item.item_name}</strong>
                                                        <span style={{ fontSize: '0.9em', color: '#888', marginLeft: '0 !important' }}>
                                                            {(() => {
                                                                const maxLen = 40;
                                                                const description = item?.item_Description ?? item?.description ?? '';
                                                                return description.length > maxLen
                                                                    ?  description.slice(0, maxLen) + '...'
                                                                    : description;
                                                            })()}
                                                    </span>
                                                    </div>
                                                </label>
                                            </div>
                                            {checked && (
                                                <span
                                                    style={{ color: '#047FFF', cursor: 'pointer', marginLeft: 8 }}
                                                    onClick={e => { e.stopPropagation(); handleChooseSelectedDelete(item.id); }}
                                                >
                                                </span>
                                            )}
                                        </li>
                                    );
                                })}
                            </ul>
                        </>
                    )}
                </Modal.Body>
                <Modal.Footer className='pt-0'>
                    {filteredChooseItemList.length > 0 && (
                        <Button variant="primary" className='modal-btn addBtnn mt-0 mb-0' onClick={handleChooseItemSave} disabled={chooseSelectedItems.length === 0}>
                            Add
                        </Button>
                    )}

                </Modal.Footer>
            </Modal>
        </div>
    );
};

export default AddClientNotePage;