'use client';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import '../clientpayment-options/payment.css';
import '../../../Components/ProfileMiddleSection/middlesection.css';

import { IoMdInformationCircleOutline } from "react-icons/io";

import Pageheader from '@/utils/pageheader';
import Link from 'next/link';
import { fetchMasterData } from "@/redux/slices/dataSlice";
import { clientCompanyUpdate, clientProfileDetails } from "@/redux/slices/authSlice";
import { useRouter } from 'next/navigation';
import { ToastContainer, toast } from 'react-toastify';
import { IMAGE } from '@/utils/Theme';

const Language = () => {
    const dispatch = useDispatch();
    const router = useRouter();
    const { items } = useSelector((state) => state.dataReducer);
    const { user } = useSelector((state) => state.auth);

    const [selectedLanguage, setSelectedLanguage] = useState("");
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        dispatch(fetchMasterData());
        dispatch(clientProfileDetails());
    }, [dispatch]);

    useEffect(() => {
        if (user?.data?.companyLanguageDetails?.languageId) {
            setSelectedLanguage(user.data.companyLanguageDetails.languageId);
        }
    }, [user]);

    const handleLanguageChange = (event) => {
        setSelectedLanguage(event.target.value);
        setError('');
    };

    const handleSave = async () => {
        if (!selectedLanguage) {
            setError('Please select a language before saving.');
            return;
        }

        const formData = { languageId: selectedLanguage };
        setLoading(true); // Set loading to true
        try {
            const langSave = await dispatch(clientCompanyUpdate(formData)).unwrap();
            langSave.status ? toast.success(langSave.message) : toast.error(langSave.message);
            router.refresh();
            router.push(`/language`);
        } catch (error) {
            setError(`Error saving language: ${error.message}`);
            console.error('Error saving language:', error);
        } finally {
            setLoading(false); // Reset loading state
        }

    };

    return (
        <div className='ClientPayment middle-area-note'>
            <Pageheader label="Language" handleSave={handleSave} loading={loading} />
            <div className='language-inner commonPadding'>
                <p className='subheading '>Select Language</p>
                <form onSubmit={(e) => e.preventDefault()} encType=''>
                    <div className='payment-type-dropdown dropedownNone'>
                        <select
                            className="payment-terms"
                            name="languages"
                            id="languages"
                            value={selectedLanguage}
                            onChange={handleLanguageChange}
                        >
                            <option value="">-- Select a Language --</option>
                            {items?.languageLists?.map((language) => (
                                <option key={language.id} value={language.id}>
                                    {language.language}
                                </option>
                            ))}
                        </select>
                        <span className='dropwdownArw'><img src={IMAGE.downArw} alt="" /></span>
                    </div>
                    {error && <p className="error-message text-danger">{error}</p>}
                </form>
                <div className='info'>
                    <div className='info-icon'>
                        <IoMdInformationCircleOutline />
                    </div>

                    <div className='info-text'>
                        <p>Want your invoices, estimates and credit notes in a different language too?</p>
                        <Link href="/">Customize info</Link>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Language;