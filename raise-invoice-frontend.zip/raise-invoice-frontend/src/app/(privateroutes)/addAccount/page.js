import React from 'react'
import './addaccount.css';
import { IMAGE } from '@/utils/Theme';

const AddAccount = () => {
  return (
    <div className='account-container form-input-label'>
        <div className='account-container-head'>
            <img className="quote-image" src={IMAGE.quoteimg} alt="quoteimg" />
            <h4>Add Account</h4>
            <p>Add other contacts to this account</p>
        </div>

        <div className='field-group'>

            <div className="floating-label-group mt-5 mb-3">
                <input type="text" id="name" className="input-form-control" required />
                <label className="floating-label">Name</label>
            </div>
            <div className='payment-type-dropdown'>
                <label className='payment-label'>User role</label>

                <select className="payment-terms" name="cars" id="cars">
                    <option value="">Select user role</option>
                    <option value="volvo">Volvo</option>
                    <option value="saab">Saab</option>
                    <option value="mercedes">Mercedes</option>
                    <option value="audi">Audi</option>
                </select>
            </div>
            <div className="floating-label-group mb-3">
                <input type="text" id="name" className="input-form-control" required />
                <label className="floating-label">Email</label>
            </div>
            <div className="floating-label-group mb-3">
                <input type="text" id="name" className="input-form-control" required />
                <label className="floating-label">Password</label>
            </div>
        </div>

        <button className='save-btn'>Save</button>
    </div>
  )
}

export default AddAccount
