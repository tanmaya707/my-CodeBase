"use client";
import { useState, useEffect, } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
// import 'react-calendar/dist/Calendar.css';
import "../general.css";
import { useDispatch, useSelector } from "react-redux";
import DashboardHeader from "../../Components/dashboardheader/dashboardHeader";
import Sidebar from "../../Components/sidebar/Sidebar";
import { useRouter } from "next/navigation";
import { clientPlanDetails, clientProfileDetails } from "@/redux/slices/authSlice";
import ProtectedRoute from "@/Components/ProtectedRoute";

export default function PrivateLayout({ children }) {
  const router = useRouter();
  const dispatch = useDispatch();
  const { user } = useSelector((state) => state.auth);
  const [loading, setLoading] = useState(true); // Loading state
  const [isAuthenticated, setIsAuthenticated] = useState(true);
  const [sidebarOpen, setSideBarOpen] = useState(false);

  useEffect(() => {
      const authToken = Boolean((typeof localStorage !== 'undefined') ? localStorage.getItem("web-auth-token") : null);
      // console.log("authToken in dashboard ::: ", authToken);
      setIsAuthenticated(authToken)
  }, []);

  useEffect(() => {
    // console.log("isAuthenticated in dashboard ::: ", isAuthenticated);
    
    if(isAuthenticated) {
      const fetchProfileDetails = async () => {
        await dispatch(clientProfileDetails()).unwrap();
        setLoading(false); // Set loading to false after fetching
      };
      fetchProfileDetails();
    }
  }, [dispatch, isAuthenticated]);


  useEffect(() => {    
    if (!loading && !user?.data?.userCompany && !user?.data?.database_name) {
      router.push("/company-details");
    }
  }, [loading, user, router, isAuthenticated]);

  
  useEffect(() => {
    // console.log("user -----------> ", user?.data);
    if(user?.data?.planDetails) {
      dispatch(clientPlanDetails({"plan_id":user?.data?.planDetails?.id}))
    }
    
  }, [user])

  return (
      <ProtectedRoute isAuthenticated={isAuthenticated}>
        {loading ? <div
          className="d-flex justify-content-center align-items-center"
          style={{ height: "100vh" }}
        >
          <div className="spinner-border" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
        :
        <>
          <DashboardHeader />
          {sidebarOpen ? (
            <div className="DashbaordMain">
              <Sidebar sidebarOpen={sidebarOpen} setSideBarOpen={setSideBarOpen} />
              <div
                className={`right-panel ${sidebarOpen ? "" : "shortRightPanel"}`}
              >
                {children}
              </div>
              
            </div>
          ) : (
            <div className="DashbaordMain">
              <Sidebar
                sidebarOpen={sidebarOpen} setSideBarOpen={setSideBarOpen} />
              <div
                className={`right-panel ${sidebarOpen ? "" : "shortRightPanel"}`}
              >
                {children}
              </div>
            </div>
          )}
        </>}
      </ProtectedRoute>
  );
}
