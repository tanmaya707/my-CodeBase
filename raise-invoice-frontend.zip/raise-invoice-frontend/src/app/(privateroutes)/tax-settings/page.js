"use client";
import React, { useState, useEffect } from "react";
import Pageheader from "@/utils/pageheader";
import ToggleButton from "@/utils/ToggleButton/toggleButton";
import "./taxsettings.css";
import { useDispatch, useSelector } from "react-redux";
import { fetchMasterData, updateTaxSecurityData } from "@/redux/slices/dataSlice";
import { clientProfileDetails } from "@/redux/slices/authSlice";
import { toast } from "react-toastify";

const STORAGE_KEYS = {
    COUNTRY_ID: "CountryId",
    CURRENCY: "Currency",
    CURRENCY_SYMBOL: "CurrencySymbol",
};

const TaxSettings = () => {
    const dispatch = useDispatch();
    const { items } = useSelector((state) => state.dataReducer);
    const { user } = useSelector((state) => state.auth);

    const [loading, setLoading] = useState(false);
    const [enableWithholdingTax, setEnableWithholdingTax] = useState(true);
    const [selectedTaxSetting, setSelectedTaxSetting] = useState({});
    const [errors, setErrors] = useState({});

    const [formData, setFormData] = useState({
        countryId: "",
        currency: "",
        gst_no: "",
        co_reg_no: "",
        pan_no: "",
        tax_year_month: "",
        tax_year_day: "",
        gst_rate: "",
    });

    useEffect(() => {
        dispatch(fetchMasterData());
        dispatch(clientProfileDetails());
    }, [dispatch]);

    // Initialize from user data, then override with localStorage (if present)
    useEffect(() => {
        if (user?.data?.companyTaxDetails) {
            const taxDetails = user.data.companyTaxDetails;
            setSelectedTaxSetting(taxDetails);
            setFormData((prev) => ({
                ...prev,
                countryId: taxDetails.countryId || prev.countryId || "",
                currency: taxDetails.currency || prev.currency || "",
                gst_no: taxDetails.gst_no || "",
                co_reg_no: taxDetails.co_reg_no || "",
                pan_no: taxDetails.pan_no || "",
                tax_year_month: taxDetails.tax_year_month || "",
                tax_year_day: taxDetails.tax_year_day || "",
                gst_rate: taxDetails.gst_rate || "",
            }));
            setEnableWithholdingTax(taxDetails.enable_withholding_tax == 1);
        }

        const storedCountry = localStorage.getItem(STORAGE_KEYS.COUNTRY_ID);
        const storedCurrency = localStorage.getItem(STORAGE_KEYS.CURRENCY);
        if (storedCountry || storedCurrency) {
            setFormData((prev) => ({
                ...prev,
                countryId: storedCountry || prev.countryId,
                currency: storedCurrency || prev.currency,
            }));
        }
    }, [user]);

    // When countries list becomes available and a countryId is present but currency empty,
    // autofill currency based on country
    useEffect(() => {
        if (items?.countries?.length && formData.countryId && !formData.currency) {
            const country = items.countries.find((c) => String(c.value) === String(formData.countryId));
            if (country && country.currency) {
                setFormData((prev) => ({ ...prev, currency: country.currency }));
            }
        }
    }, [items?.countries, formData.countryId, formData.currency]);

    const handleToggle = (eventOrValue) => {
        let checked = false;
        if (eventOrValue && typeof eventOrValue === "object" && "target" in eventOrValue) {
            checked = !!eventOrValue.target.checked;
        } else {
            checked = !!eventOrValue;
        }
        setEnableWithholdingTax(checked);
    };

    const handleChange = (event) => {
        const { name, value } = event.target;
        if (name === "countryId") {
            const country = items?.countries?.find((c) => String(c.value) === String(value));
            const currency = country?.currency || "";
            setFormData((prev) => ({
                ...prev,
                countryId: value,
                currency,
            }));
            return;
        }

        // If user selects a currency, find matching country and set it
        if (name === "currency") {
            const country = items?.countries?.find((c) => String(c.currency) === String(value));
            const countryId = country ? country.value : "";
            setFormData((prev) => ({
                ...prev,
                currency: value,
                countryId,
            }));
            return;
        }

        setFormData((prev) => ({
            ...prev,
            [name]: value,
        }));
    };

    const validate = () => {
        const newErrors = {};
        if (!formData.countryId) newErrors.countryId = "Country is required.";
        if (!formData.currency) newErrors.currency = "Currency is required.";
        if (!formData.gst_no) newErrors.gst_no = "GSTIN is required.";
        if (!formData.co_reg_no) newErrors.co_reg_no = "Company Registration Number is required.";
        if (!formData.pan_no) newErrors.pan_no = "PAN is required.";
        if (!formData.tax_year_month) newErrors.tax_year_month = "Tax month is required.";
        if (!formData.tax_year_day) newErrors.tax_year_day = "Tax day is required.";
        if (!formData.gst_rate && formData.gst_rate !== 0) newErrors.gst_rate = "GST amount is required.";
        return newErrors;
    };

    const handleSave = async (event) => {
        if (event && event.preventDefault) event.preventDefault();
        const newErrors = validate();
        if (Object.keys(newErrors).length > 0) {
            setErrors(newErrors);
            return;
        }
        setErrors({});

        const payload = {
            countryId: formData.countryId,
            currency: formData.currency,
            gst_no: formData.gst_no,
            co_reg_no: formData.co_reg_no,
            pan_no: formData.pan_no,
            tax_year_month: formData.tax_year_month,
            tax_year_day: formData.tax_year_day,
            gst_rate: formData.gst_rate,
            enable_withholding_tax: enableWithholdingTax ? 1 : 0,
        };

        setLoading(true);
        try {
            const res = await dispatch(updateTaxSecurityData(payload)).unwrap();
            // persist country and currency for whole app
            try {
                localStorage.setItem(STORAGE_KEYS.COUNTRY_ID, String(payload.countryId));
                localStorage.setItem(STORAGE_KEYS.CURRENCY, String(payload.currency));
            } catch (e) {
                // ignore localStorage errors
                console.warn("Could not save country/currency to localStorage", e);
            }
            toast.success(res?.message || "Tax settings saved successfully.");
             window.location.reload();
        } catch (error) {
            console.error(error);
            toast.error("Failed to save tax settings");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="tax-settings-container">
            <Pageheader label="Tax settings & currency" handleSave={handleSave} loading={loading} />
            <div className="tax-container commonPadding">
                <form onSubmit={handleSave}>
                    <p className="subheading">Location</p>
                    <div className="row commonFrmMargin mb-3">
                        <div className="col-lg-6 col-md-6 col-sm-12">
                            <label className="payment-label">Select Country</label>
                            <select
                                className="payment-terms"
                                name="countryId"
                                id="countryId"
                                value={formData.countryId}
                                onChange={handleChange}
                            >
                                <option value="">Select Country</option>
                                {items?.countries?.length > 0 ? (
                                    items.countries.map((country) => (
                                        <option key={country.value} value={country.value}>
                                            {country.label}
                                        </option>
                                    ))
                                ) : (
                                    <option value="" disabled>
                                        No countries available
                                    </option>
                                )}
                            </select>
                            {errors.countryId && <div className="error text-danger">{errors.countryId}</div>}
                        </div>

                        <div className="col-lg-6 col-md-6 col-sm-12">
                            <label className="payment-label">Select Currency</label>
                            <select
                                className="payment-terms"
                                name="currency"
                                id="currency"
                                value={formData.currency}
                                onChange={handleChange}
                            >
                                <option value="">Select Currency</option>
                                {items?.countries?.length > 0 ? (
                                    // build unique list of currencies (to avoid duplicates)
                                    Array.from(
                                        new Map(items.countries.map((c) => [c.currency, c])).values()
                                    ).map((country) => (
                                        <option key={country.currency} value={country.currency}>
                                            {country.currency}
                                        </option>
                                    ))
                                ) : (
                                    <option value="" disabled>
                                        No currencies available
                                    </option>
                                )}
                            </select>
                            {errors.currency && <div className="error text-danger">{errors.currency}</div>}
                        </div>
                    </div>

                    <p className="subheading">Registration and certification</p>
                    <div className="row commonFrmMargin">
                        <div className="col-lg-4 col-md-6 col-sm-12">
                            <div className="floating-label-group">
                                <label className="floating-label">GSTIN</label>
                                <input
                                    type="text"
                                    name="gst_no"
                                    className="input-form-control"
                                    value={formData.gst_no}
                                    onChange={handleChange}
                                />
                                {errors.gst_no && <div className="error text-danger">{errors.gst_no}</div>}
                            </div>
                        </div>

                        <div className="col-lg-4 col-md-6 col-sm-12">
                            <div className="floating-label-group">
                                <label className="floating-label">Co. Reg. No.</label>
                                <input
                                    type="text"
                                    name="co_reg_no"
                                    className="input-form-control"
                                    value={formData.co_reg_no}
                                    onChange={handleChange}
                                />
                                {errors.co_reg_no && <div className="error text-danger">{errors.co_reg_no}</div>}
                            </div>
                        </div>

                        <div className="col-lg-4 col-md-6 col-sm-12">
                            <div className="floating-label-group">
                                <label className="floating-label">PAN</label>
                                <input
                                    type="text"
                                    name="pan_no"
                                    className="input-form-control"
                                    value={formData.pan_no}
                                    onChange={handleChange}
                                />
                                {errors.pan_no && <div className="error text-danger">{errors.pan_no}</div>}
                            </div>
                        </div>
                    </div>

                    <p className="subheading">Tax year starts</p>
                    <div className="row commonFrmMargin mb-3">
                        <div className="col-lg-4 col-md-6 col-sm-12">
                            <label className="payment-label">Month</label>
                            <select
                                className="payment-terms"
                                name="tax_year_month"
                                value={formData.tax_year_month}
                                onChange={handleChange}
                            >
                                <option value="">Select Month</option>
                                {Array.from({ length: 12 }, (_, i) => {
                                    const month = (i + 1).toString().padStart(2, "0");
                                    return (
                                        <option key={month} value={month}>
                                            {month}
                                        </option>
                                    );
                                })}
                            </select>
                            {errors.tax_year_month && <div className="error text-danger">{errors.tax_year_month}</div>}
                        </div>

                        <div className="col-lg-4 col-md-6 col-sm-12">
                            <label className="payment-label">Day</label>
                            <select
                                className="payment-terms"
                                name="tax_year_day"
                                value={formData.tax_year_day}
                                onChange={handleChange}
                            >
                                <option value="">Select Day</option>
                                {Array.from({ length: 31 }, (_, i) => {
                                    const day = (i + 1).toString();
                                    return (
                                        <option key={day} value={day}>
                                            {day}
                                        </option>
                                    );
                                })}
                            </select>
                            {errors.tax_year_day && <div className="error text-danger">{errors.tax_year_day}</div>}
                        </div>
                    </div>

                    <p className="subheading">GST Amount</p>
                    <p className="tax-info">
                        A tax can have multiple rates associated with it. Edit a tax to add additional rates. Default taxes and
                        rates will be applied to items.
                    </p>
                    <div className="row commonFrmMargin">
                        <div className="col-lg-4 col-md-6 col-sm-12">
                            <div className="floating-label-group mb-3">
                                <input
                                    type="number"
                                    name="gst_rate"
                                    className="input-form-control"
                                    value={formData.gst_rate}
                                    onChange={handleChange}
                                />
                                {errors.gst_rate && <div className="error text-danger">{errors.gst_rate}</div>}
                            </div>
                        </div>
                    </div>

                    <p className="subheading">Withholding</p>
                    <ToggleButton
                        isToggled={enableWithholdingTax}
                        onToggle={handleToggle}
                        id="withholding"
                        heading="Enable withholding tax"
                    />
                </form>
            </div>
        </div>
    );
};

export default TaxSettings;
