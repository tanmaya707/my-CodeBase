"use client"
import Link from 'next/link';
import "./Reports.css";
import { IMAGE } from '@/utils/Theme';
import ReportGraph from '@/Components/reportGraph/reportGraph';
const Reports = () => {
    return (
        <>
            <div className="reportPage">
                <div className="reportHeader">
                    <div className="reportHeaderLeft">
                        <h2>Reports</h2>
                    </div>
                    <div className="reportHeaderRight">
                        <ul>
                            <li><Link href="/">Dashboard</Link></li>
                            <li><Link href="/">Reports List</Link></li>
                            <li ><Link className='downloadIcon' href="/">Export Data <img src={IMAGE.downloadIcon} alt="" /></Link></li>
                        </ul>
                    </div>
                </div>

                <div className="reportInner">
                    <div className="row">
                        <div className="col-lg-4">
                            <div className="reportBalance">
                                <h5 className='reportHeaderinner' >Reports</h5>
                                <div className="outstandingBalance roprtCard">
                                    <div className="outstandingBalanceLeft">
                                        <h6>Total Outstanding Balance</h6>
                                        <p>$125</p>
                                    </div>
                                    <div className="outstandingBalanceRight ">
                                        <img src={IMAGE.report} alt="" />
                                        <p>List</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-8">
                            <div className="reportBalance paddingLeft">
                                <h5 className='reportHeaderinner'>Annual Sales by Client <img src={IMAGE.report} alt="" /></h5>
                                <div className="roprtCard">
                                </div>
                            </div>
                        </div>

                    </div>

                    <div className="salesGraph">
                        <ReportGraph />
                    </div>
                </div>
            </div>
        </>
    )
}

export default Reports;