"use client"
import React, { useState } from 'react'
import MiddleSection from "../../../Components/MiddleSection/MiddleSection";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  faSquarePlus,
  faPhoneVolume,
  faEnvelope,
  faMessage,
  faCircleExclamation,
  faPhone,
  faXmark,
  faLocationDot,
  faGlobe
} from '@fortawesome/free-solid-svg-icons';
import '../../general.css';
import './clientactivity.css';
import Accordion from 'react-bootstrap/Accordion';
import MenuLandingPage from '@/utils/MenuLanding/MenuLandingPage';
import { IMAGE } from '@/utils/Theme';

const ClientCreateInvoice = () => {
  const Image = IMAGE.tab;

  const [show, setShow] = useState(true);

  return (
    <>
      <MiddleSection label="Client" />
      <div className="col-lg-8 client-invoice">
        <div className='add-client contentArea'>
          <div className='clientactivity-head'>
            <div>
              <h4 className='name'>Akash Mishra</h4>
            </div>
            <div className='head-right'>
              <h4 className='name'>Activity</h4>
              <h6 className='project'>Projects</h6>
              <FontAwesomeIcon className="add-iconn" icon={faSquarePlus} />
              <FontAwesomeIcon className="head-icon" icon={faPhoneVolume} />
              <FontAwesomeIcon className="head-icon" icon={faEnvelope} />
              <FontAwesomeIcon className="head-icon" icon={faMessage} />
              <FontAwesomeIcon className="head-icon" icon={faCircleExclamation} />
       
            </div>
          </div>
          <hr className='client-activity-divide' />
          <MenuLandingPage
            Image={Image}
            text="There is no invoice added yet
                Please add an invoice"
            label="Create Invoice"
            // handleState={setAddInvoice}
            itemType="Invoice"
          // activeTag={activeTag}
          // setActiveTag={setActiveTag}
          />

          {show && (
            <div className='moreinfo-body'>
              <div className='moreinfo-content'>

                <div className='moreinfo-heading'>
                  <h6>More Information</h6>
                  <FontAwesomeIcon icon={faXmark} />
                </div>

                <Accordion defaultActiveKey="0">
                  <Accordion.Item eventKey="0">
                    <Accordion.Header>
                      <p className='accorheading'>Billing Details</p>
                    </Accordion.Header>
                    <Accordion.Body>
                      <div>
                        <div className='moreinfo-items'>
                          <div>
                            <p>Billing Name</p>
                            <h4>Akash Mishra</h4>
                          </div>
                        </div>
                        <hr className='client-activity-divide' />
                        <div className='moreinfo-items'>
                          <FontAwesomeIcon icon={faPhone} />
                          <div>
                            <p>Billing Name</p>
                            <h4>Akash Mishra</h4>
                          </div>
                        </div>
                        <hr className='client-activity-divide' />
                        <div className='moreinfo-items'>
                          <FontAwesomeIcon icon={faEnvelope} />
                          <div>
                            <p>Email Address</p>
                            <h4>akashmishra@gmail.com</h4>
                          </div>
                        </div>
                        <hr className='client-activity-divide' />
                        <div className='moreinfo-items'>
                          <FontAwesomeIcon icon={faLocationDot} />
                          <div>
                            <p>Location</p>
                            <h4>12, Worli Place, near worli, fort, Mumbai, Maharashtra 400030</h4>
                          </div>
                        </div>
                      </div>
                    </Accordion.Body>
                  </Accordion.Item>
                </Accordion>

                <Accordion defaultActiveKey="0">
                  <Accordion.Item eventKey="0">
                    <Accordion.Header>
                      <p className='accorheading'>Contact Details</p>
                    </Accordion.Header>
                    <Accordion.Body>
                      <div>
                        <div>
                          <div className='moreinfo-items'>
                            <div>
                              <p>Contact Name</p>
                              <h4>Akash Mishra</h4>
                            </div>
                          </div>
                        </div>
                        <hr className='client-activity-divide' />
                        <div className='moreinfo-items'>
                          <FontAwesomeIcon icon={faPhone} />
                          <div>
                            <p>Phone No.</p>
                            <h4>+91 912345 12345</h4>
                          </div>
                        </div>
                        <hr className='client-activity-divide' />
                        <div className='moreinfo-items'>
                          <FontAwesomeIcon icon={faGlobe} />
                          <div>
                            <p>Website</p>
                            <h4>www.akshmishra.com</h4>
                          </div>
                        </div>
                      </div>
                    </Accordion.Body>
                  </Accordion.Item>
                </Accordion>

                <Accordion defaultActiveKey="0">
                  <Accordion.Item eventKey="0">
                    <Accordion.Header>
                      <p className='accorheading'>Other Details</p>
                    </Accordion.Header>
                    <Accordion.Body>
                      <div>
                        <div>
                          <div className='moreinfo-items'>
                            <div>
                              <p>Tax No.</p>
                              <h4>ABP1245756</h4>
                            </div>
                          </div>
                        </div>
                        <hr className='client-activity-divide' />
                        <div className='moreinfo-items'>
                          <div>
                            <p>Payment Terms</p>
                            <h4>14 Days</h4>
                          </div>
                        </div>
                      </div>

                    </Accordion.Body>
                  </Accordion.Item>
                </Accordion>

                <button className='add-note'><FontAwesomeIcon icon={faSquarePlus} />
                  Add note
                </button>
              </div>

            </div>
          )}
        </div>
      </div>
    </>
  )
}

export default ClientCreateInvoice
