"use client"
import React, { use, useState, useEffect } from 'react';
import MiddleSection from '@/Components/MiddleSection/MiddleSection';
import '@/Components/newprojectdetails/newproject.css';
import ProjectDetailsHead from '@/Components/newprojectdetails/projectDetailsHead';
import ProjectDetails from '@/Components/newprojectdetails/projectDetails';
import ProjectContacts from '@/Components/newprojectdetails/projectContacts';
import ProjectNote from '@/Components/newprojectdetails/projectNote';
import ProjectTask from '@/Components/newprojectdetails/projectTask';
import { useDispatch, useSelector } from 'react-redux';
import { fetchProjectData, deatilsProjectData } from '@/redux/slices/dataSlice';
import NewProject from '@/Components/newproject/newproject';

const ProjectActivity = ({ params }) => {
    const { id, client_id } = use(params);
    console.log("Received params:", id, client_id);

    const [selectedOption, setSelectedOption] = useState('Active');
    const [selectedTab, setSelectedTab] = useState('Files');
    const dispatch = useDispatch();
    const [activeTag, setActiveTag] = useState(0);
    const [loading, setLoading] = useState(false);
    const [addProjectForm, setAddProjectForm] = useState(false);
    const [projectToEdit, setProjectToEdit] = useState(null);
    const { projects, project } = useSelector((state) => state.dataReducer);

    // console.log(project.data.enrichedProject.project_name);

    const handleDropdown = (data) => {
        setSelectedOption(data)
    }
    const handleSelectedTab = (tab) => {
        setSelectedTab(tab)
    }
    const middleSectionTabs = [
        {
            id: 1,
            name: "All",
        },
        {
            id: 2,
            name: "Active",
        },
        {
            id: 3,
            name: "Completed",
        }
    ]
    useEffect(() => {
        dispatch(fetchProjectData());
        dispatch(deatilsProjectData({
            client_id: client_id,
            projectId: id
        }));
    }, [dispatch]);

    const handleAddClientFormOpen = () => {
        setProjectToEdit(null);
        setAddProjectForm(true);
    };

    const handleProjectAdded = () => {
        dispatch(fetchClientData());
        setAddProjectForm(false);
    };

    const handleEditProject = (project) => {
        setProjectToEdit(project);
        setAddProjectForm(true);
    };

    const handleSave = (taskData) => {

    };

    return (
        <>
            <MiddleSection
                label="Project"
                tabs={middleSectionTabs}
                btnlabel="Add New Project"
                setActiveTag={setActiveTag}
                setAddProjectForm={handleAddClientFormOpen}
                projects={projects?.data}
                onEditProject={handleEditProject}
            />
            <div className="add-client contentArea">
                {addProjectForm ? <NewProject onProjectAdded={handleProjectAdded} projectToEdit={projectToEdit} /> : (
                    <>
                        <ProjectDetailsHead
                            handleDropdown={handleDropdown}
                            selectedTab={handleSelectedTab}
                            projectDetails={project?.data?.enrichedProject}
                            handleSave={handleSave} loading={loading}
                        />
                        {selectedTab === "Files" && selectedOption === "Active" && (
                            <>
                                <div className='project-contain'>
                                    <p className='project-file'>Add all your Files, Estimates & Invoices here</p>
                                </div>
                                <div className='btn-group'>
                                    <button className='create-btn'>Add photo</button>
                                    <button className='create-btn'>Add estimate</button>
                                    <button className='create-btn'>Add invoice</button>
                                    <button className='create-btn'>Add pdf</button>
                                </div>
                            </>
                        )}
                        {selectedTab === "Files" && selectedOption === "Completed" && (
                            <div className="project-files card">
                                <div className="card-body">
                                    <div className='subheading'>
                                        <div className='sub-head'>
                                            <h4>Overview</h4>
                                            <h4>$1500</h4>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col-lg-4">
                                            <div className="card">
                                                <div className="card-body">
                                                    <div className='card-details'>
                                                        <div className='left'>
                                                            <h4>Invoice Sent</h4>
                                                            <p>$125</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-lg-4">
                                            <div className="card">
                                                <div className="card-body">
                                                    <div className='card-details'>
                                                        <div className='left'>
                                                            <h4>Invoice Paid</h4>
                                                            <p>$125</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-lg-4">
                                            <div className="card">
                                                <div className="card-body">
                                                    <div className='card-details'>
                                                        <div className='left'>
                                                            <h4>Expenses</h4>
                                                            <p>$125</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        )}
                        {selectedTab === "Details" && <ProjectDetails selectedOption={selectedOption} />}
                        {selectedTab === "Contacts" && <ProjectContacts selectedOption={selectedOption} />}
                        {selectedTab === "Note" && <ProjectNote selectedOption={selectedOption} />}

                        {selectedTab === "Task" && <ProjectTask selectedOption={selectedOption} handleSave={handleSave} />}
                    </>
                )}
            </div>
        </>
    )
}

export default ProjectActivity


