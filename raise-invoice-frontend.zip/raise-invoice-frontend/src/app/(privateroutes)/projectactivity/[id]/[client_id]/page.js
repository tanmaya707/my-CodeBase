"use client"
import React, { useState, useEffect, useRef } from 'react';
import MiddleSection from '@/Components/MiddleSection/MiddleSection';
import '@/Components/newprojectdetails/newproject.css';
import ProjectDetailsHead from '@/Components/newprojectdetails/projectDetailsHead';
import ProjectDetails from '@/Components/newprojectdetails/projectDetails';
import ProjectContacts from '@/Components/newprojectdetails/projectContacts';
import { useDispatch, useSelector } from 'react-redux';
import { fetchProjectData, deatilsProjectData, updateProjectData, saveProjectFiles, getProjectFiles, deleteProjectFiles } from '@/redux/slices/dataSlice';
import NewProject from '@/Components/newproject/newproject';
import Calendar from 'react-calendar';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import {
    faEnvelope,
    faPhone,
    faLocationDot,
    faCalendarDays,
    faFile,
    faFilePdf,
    faFileInvoiceDollar,
    faFileInvoice
} from '@fortawesome/free-solid-svg-icons';
import Image from 'next/image';
import TaskList from '@/Components/newprojectdetails/getTaskList';
import { IMAGE } from '@/utils/Theme';
import Logs from '@/Components/newprojectdetails/getlogs';

const ProjectActivity = ({ params }) => {
    const noteRef = useRef(null)
    const unwrappedParams = React.use(params)
    const [selectedOption, setSelectedOption] = useState('Active');
    const [selectedTab, setSelectedTab] = useState('Files');
    const dispatch = useDispatch();
    const [activeTab, setActiveTab] = useState(0);
    const [activeTag, setActiveTag] = useState(0);
    const [loading, setLoading] = useState(false);
    const [addProjectForm, setAddProjectForm] = useState(false);
    const [projectToEdit, setProjectToEdit] = useState(null);
    const { projects, project } = useSelector((state) => state.dataReducer);

    // const [showCalendarStart, setShowCalendarStart] = useState(false);
    // const [showCalendarEnd, setShowCalendarEnd] = useState(false);

    const [formData, setFormData] = useState({
        taskName: '',
        taskDescription: '',
        taskStartDate: '',
        taskEndDate: '',
        notes: project?.data?.enrichedProject?.notes || '',
        logo: null,
        image : '',
    });

    const [noteUpdated, setNoteUpdated] = useState(false);
    const [taskUpdated, setTaskUpdated] = useState(false);

    // Document upload state
    const [showUploadOptions, setShowUploadOptions] = useState(true);
    const [uploadedDocuments, setUploadedDocuments] = useState([]);
    const [uploadType, setUploadType] = useState(null);
    const fileInputRef = useRef();
    const [menuOpenId, setMenuOpenId] = useState(null);
    const [isAutoScrolled, setIsAutoScrolled] = useState(false);
    const middleSectionTabs = [
        { id: 1, name: "All" },
        { id: 2, name: "Active" },
        { id: 3, name: "Completed" }
    ];

    const client_id = unwrappedParams.client_id;
    const projectId = unwrappedParams.id;

    // Fetch project data
    useEffect(() => {
        dispatch(fetchProjectData());
        dispatch(deatilsProjectData({
            client_id,
            projectId,
        }));
    }, [dispatch, client_id, projectId, noteUpdated, taskUpdated]);

    // Fetch uploaded documents
    useEffect(() => {
        if (selectedTab === "Files" && selectedOption === "Active") {
            dispatch(getProjectFiles({ projectId }))
                .unwrap()
                .then(docs => {
                    if (docs.status === false) return;
                    setUploadedDocuments(docs.data);
                    setShowUploadOptions(docs.data.length === 0);
                });
        }
    }, [selectedTab, selectedOption, client_id, projectId, taskUpdated]);

    const handleAddClientFormOpen = () => {
        setProjectToEdit(null);
        setAddProjectForm(true);
    };

    const handleProjectAdded = () => {
        dispatch(fetchProjectData());
        setAddProjectForm(false);
    };

    const handleEditProject = (project) => {
        setProjectToEdit(project);
        setAddProjectForm(true);
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value,
        });
    };

    const handleSave = async (e) => {
        e.preventDefault();
        setLoading(true);
        const formDataToSubmit = {
            ...formData,
            client_id,
            projectId,
        };
        try {
            await dispatch(updateProjectData(formDataToSubmit)).unwrap();
            setTaskUpdated(prev => !prev);
        } catch (err) {}
        setLoading(false);
    };

    const handleNoteSave = async (e) => {
        e.preventDefault();
        setLoading(true);
        const noteToSubmit = {
            ...formData,
            client_id,
            projectId,
        };
        try {
            await dispatch(updateProjectData(noteToSubmit)).unwrap();
            setNoteUpdated(prev => !prev);
        } catch (err) {}
        finally { setLoading(false); }
    };


    const handleDropdown = async (data) => {
        setSelectedOption(data);
        setLoading(true);
        try {
            await dispatch(updateProjectData({
                client_id,
                projectId,
                status: data === "Completed" ? 3 : 1,
            })).unwrap();
            setTaskUpdated(prev => !prev);
        } catch (err) {}
        setLoading(false);
    };

    // const getFilteredProjects = () => {
    //     if (!projects?.data) return [];
    //     if (activeTab === 0) return projects.data;
    //     if (activeTab === 1) return projects.data.filter(p => p.status !== 3);
    //     if (activeTab === 2) return projects.data.filter(p => p.status === 3);
    //     return projects.data;
    // };

    const handleSelectedTab = (tab) => setSelectedTab(tab);

    useEffect(() => {
        if (selectedTab === "Task") {
            const task = project?.data?.enrichedProject;
            setFormData({
                taskName: task?.taskName || '',
                taskDescription: task?.taskDescription || '',
                taskPriority: task?.taskPriority || '', 
                taskStartDate: task?.taskStartDate ? new Date(task?.taskStartDate) : '',
                taskEndDate: task?.taskEndDate ? new Date(task?.taskEndDate) : '',
            });
        } else if (selectedTab === "Note") {
            const note = project?.data?.enrichedProject;
            
            setFormData({
                ...formData,
                notes: note?.notes || ''
            });
        }
    }, [selectedTab, project]);

    const handleUploadClick = (type) => {
        setUploadType(type);
        setTimeout(() => {
            if (fileInputRef.current) {
                fileInputRef.current.value = '';
                if (type === 'photo') {
                    fileInputRef.current.accept = 'image/*';
                } else if (type === 'pdf') {
                    fileInputRef.current.accept = 'application/pdf';
                } else if (type === 'estimate' || type === 'invoice') {
                    fileInputRef.current.accept = '*';
                } else {
                    fileInputRef.current.accept = '*';
                }
                fileInputRef.current.click();
            }
        }, 0);
    };

    const handleFileInputChange = async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        const formDataObj = new FormData();
        formDataObj.append('document', file);
        formDataObj.append('client_id', client_id);
        formDataObj.append('projectId', projectId);
        formDataObj.append('type', uploadType);

        try {
            await dispatch(saveProjectFiles(formDataObj)).unwrap();
            setTaskUpdated(prev => !prev);
            setShowUploadOptions(false);
        } catch (err) {
            console.error('File upload error:', err);
        }
    };
      const getFilteredProjects = () => {
        if (!projects?.data) return [];
        if (activeTab === 0) return projects.data;
        if (activeTab === 1) return projects.data.filter(p => p.status !== 3);
        if (activeTab === 2) return projects.data.filter(p => p.status === 3);
        return projects.data;
    };

    useEffect(() => {   
        if(selectedTab !== 'Note') {
            setIsAutoScrolled(false)
        }
        if( noteRef.current !== null && selectedTab === "Note" && !isAutoScrolled && formData?.notes?.length > 0) {
            // console.log("noteRef.current.scrollHeight ::: ", noteRef.current.scrollHeight, noteRef.current);    
            
            noteRef.current.scrollTo({
            top: noteRef.current.scrollHeight,
            behavior: "smooth"
            });
            setIsAutoScrolled(true)
        }
    }, [selectedTab, isAutoScrolled, formData?.notes])

    return (
        <>
            <MiddleSection
                label="Project"
                tabs={middleSectionTabs}
                btnlabel="Add New Project"
                setActiveTag={setActiveTab}
                setAddProjectForm={handleAddClientFormOpen}
                projects={getFilteredProjects()}
                onEditProject={handleEditProject}
                handleCreate={handleAddClientFormOpen}
                activeTag={activeTab}
            />
            <div className="add-client contentArea">
                {addProjectForm ? (
                    <NewProject onProjectAdded={handleProjectAdded} projectToEdit={projectToEdit} />
                ) : (
                    <>
                        <ProjectDetailsHead
                            handleDropdown={handleDropdown}
                            selectedTab={handleSelectedTab}
                            projectDetails={project?.data?.enrichedProject}
                            handleSave={handleSave}
                            loading={loading}
                        />
                        {selectedTab === "Files" && selectedOption === "Active" && (
                            <>
                                <div className='project-contain'>
                                    <p className='project-file'>Add all your Files, Estimates & Invoices here</p>
                                </div>
                                <div className="uploaded-files-list">
                                    {uploadedDocuments && uploadedDocuments.length > 0 && (
                                        <h5>Uploaded Documents</h5>
                                    )}
                                    <ul style={{ 
                                        display: 'flex', 
                                        flexWrap: 'wrap', 
                                        flexDirection: 'row', 
                                        gap: 24, 
                                        padding: '10px',
                                        margin: 0
                                    }}>
                                        {uploadedDocuments.map(doc => {
                                            const addedDate = doc.createdAt;
                                            const fileName = doc.fileName || doc.name || 'document';

                                            // Download
                                            const handleDownload = (url, fileName, fileType) => {
                                                if (fileType.startsWith('image/')) {
                                                    fetch(url)
                                                        .then(res => res.blob())
                                                        .then(blob => {
                                                            const link = document.createElement('a');
                                                            link.href = URL.createObjectURL(blob);
                                                            link.download = fileName || 'document';
                                                            document.body.appendChild(link);
                                                            link.click();
                                                            document.body.removeChild(link);
                                                        });
                                                } else {
                                                    const link = document.createElement('a');
                                                    link.href = url;
                                                    link.download = fileName || 'document';
                                                    document.body.appendChild(link);
                                                    link.click();
                                                    document.body.removeChild(link);
                                                }
                                            };

                                            // Print
                                            const handlePrint = (url, fileType) => {
                                                if (fileType.startsWith('image/')) {
                                                    const printWindow = window.open('', '_blank');
                                                    if (printWindow) {
                                                        printWindow.document.write(`
                                                            <html>
                                                                <head>
                                                                    <title>Print Image</title>
                                                                    <style>
                                                                        body { margin: 0; text-align: center; }
                                                                        img { max-width: 100vw; max-height: 100vh; }
                                                                    </style>
                                                                </head>
                                                                <body>
                                                                    <img src="${url}" onload="window.print();window.close();" />
                                                                </body>
                                                            </html>
                                                        `);
                                                        printWindow.document.close();
                                                    }
                                                } else if (fileType === 'application/pdf') {
                                                    const printWindow = window.open(url, '_blank');
                                                    if (printWindow) {
                                                        printWindow.focus();
                                                        printWindow.onload = () => {
                                                            printWindow.print();
                                                        };
                                                    }
                                                }
                                            };

                                            // Remove
                                            const handleRemove = async (docId) => {
                                                if (window.confirm('Are you sure you want to remove this file?')) {
                                                    try {
                                                        const payload = { fileId : docId, projectId };
                                                        await dispatch(deleteProjectFiles(payload)).unwrap();
                                                        setTaskUpdated(prev => !prev);
                                                    } catch (err) {
                                                        alert('Failed to remove file');
                                                    }
                                                }
                                            };

                                            // Open in browser
                                            const handleOpenInBrowser = (url) => {
                                                window.open(url, '_blank', 'noopener,noreferrer');
                                            };

                                            return (
                                                <li
                                                    key={doc.id}
                                                    style={{
                                                        listStyle: 'none',
                                                        width: 120,
                                                        textAlign: 'center',
                                                        marginBottom: 16,
                                                        position: 'relative'
                                                    }}
                                                    onMouseLeave={() => setMenuOpenId(null)}
                                                >
                                                    <div style={{ position: 'relative' }}>
                                                        {doc.fileType === 'image/png' || doc.fileType === 'image/jpeg' ? (
                                                            <a
                                                                href={doc.url}
                                                                target="_blank"
                                                                rel="noopener noreferrer"
                                                                style={{ display: 'inline-block' }}
                                                            >
                                                                <Image src={doc.url} alt="img" width={60} height={60} style={{ objectFit: 'cover', borderRadius: 8, marginBottom: 8, border: '1px solid #eee' }} />
                                                            </a>
                                                        ) : doc.fileType === 'application/pdf' ? (
                                                            <a
                                                                href={doc.url}
                                                                target="_blank"
                                                                rel="noopener noreferrer"
                                                                style={{ display: 'inline-block' }}
                                                            >
                                                                <FontAwesomeIcon icon={faFilePdf} style={{ fontSize: 60, color: '#d32f2f', marginBottom: 8, width: 60, height: 60 }} />
                                                            </a>
                                                        ) : doc.type === 'estimate' ? (
                                                            <FontAwesomeIcon icon={faFileInvoiceDollar} style={{ fontSize: 48, color: '#1976d2', marginBottom: 8 }} />
                                                        ) : doc.type === 'invoice' ? (
                                                            <FontAwesomeIcon icon={faFileInvoice} style={{ fontSize: 48, color: '#388e3c', marginBottom: 8 }} />
                                                        ) : (
                                                            <FontAwesomeIcon icon={faFile} style={{ fontSize: 48, color: '#888', marginBottom: 8 }} />
                                                        )}

                                                        {/* 3 dots menu */}
                                                        {(doc.fileType === 'image/png' || doc.fileType === 'image/jpeg' || doc.fileType === 'application/pdf') && (
                                                            <div
                                                                style={{
                                                                    position: 'absolute',
                                                                    left: '50%',
                                                                    bottom: -10,
                                                                    transform: 'translateX(-50%)',
                                                                    cursor: 'pointer',
                                                                    zIndex: 2
                                                                }}
                                                                onMouseEnter={() => setMenuOpenId(doc.id)}
                                                            >
                                                                <span style={{ fontSize: 22, letterSpacing: 2, color: '#888' }}>⋯</span>
                                                                {menuOpenId === doc.id && (
                                                                    <div
                                                                        style={{
                                                                            position: 'absolute',
                                                                            left: '50%',
                                                                            top: 24,
                                                                            transform: 'translateX(-50%)',
                                                                            background: '#fff',
                                                                            border: '1px solid #eee',
                                                                            borderRadius: 6,
                                                                            boxShadow: '0 2px 8px rgba(0,0,0,0.08)',
                                                                            minWidth: 120,
                                                                            zIndex: 10
                                                                        }}
                                                                        onMouseLeave={() => setMenuOpenId(null)}
                                                                    >
                                                                        <button
                                                                            style={{
                                                                                display: 'block',
                                                                                width: '100%',
                                                                                padding: '8px 12px',
                                                                                border: 'none',
                                                                                background: 'none',
                                                                                textAlign: 'left',
                                                                                cursor: 'pointer'
                                                                            }}
                                                                            onClick={() => {
                                                                                handlePrint(doc.url, doc.fileType);
                                                                                setMenuOpenId(null);
                                                                            }}
                                                                        >
                                                                            Print
                                                                        </button>
                                                                        <button
                                                                            style={{
                                                                                display: 'block',
                                                                                width: '100%',
                                                                                padding: '8px 12px',
                                                                                border: 'none',
                                                                                background: 'none',
                                                                                textAlign: 'left',
                                                                                cursor: 'pointer'
                                                                            }}
                                                                            onClick={() => {
                                                                                handleDownload(doc.url, doc.fileName || 'document', doc.fileType);
                                                                                setMenuOpenId(null);
                                                                            }}
                                                                        >
                                                                            Download
                                                                        </button>
                                                                        <button
                                                                            style={{
                                                                                display: 'block',
                                                                                width: '100%',
                                                                                padding: '8px 12px',
                                                                                border: 'none',
                                                                                background: 'none',
                                                                                textAlign: 'left',
                                                                                color: '#d32f2f',
                                                                                cursor: 'pointer'
                                                                            }}
                                                                            onClick={() => {
                                                                                handleRemove(doc.id);
                                                                                setMenuOpenId(null);
                                                                            }}
                                                                        >
                                                                            Remove
                                                                        </button>
                                                                    </div>
                                                                )}
                                                            </div>
                                                        )}
                                                    </div>
                                                    <div
                                                        style={{
                                                            fontSize: 12,
                                                            wordBreak: 'break-all',
                                                            color: '#1976d2',
                                                            textDecoration: 'underline',
                                                            display: 'block',
                                                            marginBottom: 4,
                                                            whiteSpace: 'normal',
                                                            overflowWrap: 'break-word',
                                                            wordBreak: 'break-all',
                                                            maxWidth: 110,
                                                            cursor: 'pointer'
                                                        }}
                                                        onClick={() => handleOpenInBrowser(doc.url)}
                                                    >
                                                        {fileName}
                                                    </div>
                                                    <span style={{ fontSize: 11, color: '#888', display: 'block', marginBottom: 2 }}>Added</span>
                                                    <span style={{ fontSize: 11, color: '#888', display: 'block', marginBottom: 2 }}>{addedDate}</span>
                                                    <span style={{ fontSize: 11, color: '#888' }}>{doc.type}</span>
                                                </li>
                                            );
                                        })}
                                    </ul>
                                </div>
                                <div style={{ textAlign: 'center' }}>
                                    {!showUploadOptions ? (
                                        <button
                                            className='create-btn'
                                            onClick={() => setShowUploadOptions(true)}
                                            style={{ minWidth: 80, fontSize: 12, padding: '4px 12px' }}
                                        >
                                            Add More
                                        </button>
                                    ) : (
                                        <div className='btn-group' style={{ justifyContent: 'center', gap: 12 }}>
                                            <button className='create-btn' onClick={() => handleUploadClick('photo')}>Add photo</button>
                                            <button className='create-btn' onClick={() => handleUploadClick('estimate')}>Add estimate</button>
                                            <button className='create-btn' onClick={() => handleUploadClick('invoice')}>Add invoice</button>
                                            <button className='create-btn' onClick={() => handleUploadClick('pdf')}>Add pdf</button>
                                            <input
                                                type="file"
                                                ref={fileInputRef}
                                                style={{ display: 'none' }}
                                                multiple
                                                name={uploadType === 'photo' ? 'image' : uploadType === 'pdf' ? 'pdf' : uploadType}
                                                accept={
                                                    uploadType === 'photo'
                                                        ? 'image/*'
                                                        : uploadType === 'pdf'
                                                        ? 'application/pdf'
                                                        : '*'
                                                }
                                                onChange={handleFileInputChange}
                                            />
                                        </div>
                                    )}
                                </div>
                            </>
                        )}
                        {selectedTab === "Files" && selectedOption === "Completed" && (
                            <div className="project-files card">
                                <div className="card-body">
                                    <div className='subheading'>
                                        <div className='sub-head'>
                                            <h4>Overview</h4>
                                            <h4>$1500</h4>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col-lg-4">
                                            <div className="card">
                                                <div className="card-body">
                                                    <div className='card-details'>
                                                        <div className='left'>
                                                            <h4>Invoice Sent</h4>
                                                            <p>$125</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-lg-4">
                                            <div className="card">
                                                <div className="card-body">
                                                    <div className='card-details'>
                                                        <div className='left'>
                                                            <h4>Invoice Paid</h4>
                                                            <p>$125</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-lg-4">
                                            <div className="card">
                                                <div className="card-body">
                                                    <div className='card-details'>
                                                        <div className='left'>
                                                            <h4>Expenses</h4>
                                                            <p>$125</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        )}
                        {selectedTab === "Details" && (
                            <ProjectDetails selectedOption={selectedOption} project={project} />
                        )}
                        {selectedTab === "Contacts" && (
                            <ProjectContacts selectedOption={selectedOption} project={project} />
                        )}
                        {selectedTab === "Note" && (
                            <form>
                                <div className='form-input-label'>
                                    <div className='floating-label-group mynote my-3'>
                                        <div className="floating-label-group mb-3">
                                            <textarea
                                                ref={noteRef}
                                                type="text"
                                                name="notes"
                                                className="input-form-control note-textarea"
                                                onChange={handleChange}
                                                value={formData.notes}
                                                required
                                            />
                                            <label className="floating-label">Notes</label>
                                        </div>
                                        <button className='create-btn' onClick={handleNoteSave}>{loading ? 'Saving...' : 'Save'}</button>
                                    </div>
                                </div>
                            </form>
                        )}
                        {selectedTab === "Task" && (
                            <TaskList project={project} />
                        )}
                        {selectedTab === "Logs" && (
                            <Logs project={project} />
                        )}
                    </>
                )}
            </div>
        </>
    )
}

export default ProjectActivity