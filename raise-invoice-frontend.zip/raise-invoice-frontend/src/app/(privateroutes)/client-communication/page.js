"use client"
import React, { useEffect, useState } from 'react';
import Accordion from 'react-bootstrap/Accordion';
import Pageheader from '@/utils/pageheader';
import ToggleButton from '@/utils/ToggleButton/toggleButton';
import './communication.css';
import '../../general.css';
import { useDispatch, useSelector } from 'react-redux';
import { useRouter } from 'next/navigation';
import { fetchCommunicationSettingData, updateCommunicationSettingData } from "@/redux/slices/dataSlice";
import { toast } from 'react-toastify';

const ClientCommunication = () => {
    const dispatch = useDispatch();
    const router = useRouter();
    const [loading, setLoading] = useState(false);
    const { items } = useSelector((state) => state.dataReducer);
    const [formData, setFormData] = useState({
        id: '',
        sameEmail: false,
        message: '',
        cc: '',
        bcc: '',
        paymentReminder: true,
        day3BeforeDueDate: true,
        dueDate: true,
        day3AfterDueDate: true,
        day7AfterDueDate: true,
        paymentNotification: true,
        paymentReceipt: true,
        email: true,
        businessResource: false,
        invoice2go: true,
        productUpdate: true,
        specialOffer: true,
    });

    useEffect(() => {
        const fetchData = async () => {
            try {
                const result = await dispatch(fetchCommunicationSettingData()).unwrap();
                const fetchedData = result.data;

                setFormData(prevState => ({
                    ...prevState,
                    id: fetchedData.id,
                    sameEmail: fetchedData.sameEmail,
                    message: fetchedData.message || '',
                    cc: fetchedData.cc || '',
                    bcc: fetchedData.bcc || '',
                    paymentReminder: fetchedData.paymentReminder,
                    day3BeforeDueDate: fetchedData.day3BeforeDueDate,
                    dueDate: fetchedData.dueDate,
                    day3AfterDueDate: fetchedData.day3AfterDueDate,
                    day7AfterDueDate: fetchedData.day7AfterDueDate,
                    paymentNotification: fetchedData.paymentNotification,
                    paymentReceipt: fetchedData.paymentReceipt,
                    email: fetchedData.email,
                    businessResource: fetchedData.businessResource,
                    invoice2go: fetchedData.invoice2go,
                    productUpdate: fetchedData.productUpdate,
                    specialOffer: fetchedData.specialOffer,
                }));
            } catch (error) {
                console.error('Error fetching communication settings:', error);
            }
        };

        fetchData();
    }, [dispatch]);

    const handleToggle = (event) => {
        const { id, checked } = event.target;
        setFormData(prevState => ({
            ...prevState,
            [id]: checked
        }));
    };

    const handleChange = (event) => {
        const { id, value } = event.target;
        setFormData(prevState => ({
            ...prevState,
            [id]: value
        }));
    };

    const handleSave = async () => {
        const {
            id,
            sameEmail,
            message,
            cc,
            bcc,
            paymentReminder,
            day3BeforeDueDate,
            dueDate,
            day3AfterDueDate,
            day7AfterDueDate,
            paymentNotification,
            paymentReceipt,
            email,
            businessResource,
            invoice2go,
            productUpdate,
            specialOffer,
        } = formData;

        const dataToSave = {
            id,
            sameEmail,
            message,
            cc,
            bcc,
            paymentReminder,
            day3BeforeDueDate,
            dueDate,
            day3AfterDueDate,
            day7AfterDueDate,
            paymentNotification,
            paymentReceipt,
            email,
            businessResource,
            invoice2go,
            productUpdate,
            specialOffer,
        };
        setLoading(true); // Set loading to true
        try {
            const response = await dispatch(updateCommunicationSettingData(dataToSave)).unwrap();
            if (response.status) {
                toast.success(response.message);
            } else {
                toast.error(response.message);
            }
            router.refresh();
            router.push(`/client-communication`);
        } catch (error) {
            toast.error(`Error saving settings: ${error.message}`);
            console.error('Error saving settings:', error);
        } finally {
            setLoading(false); // Reset loading state
        }

    };

    return (
        <div className='communication-container'>
            <Pageheader label="Client communication" handleSave={handleSave} loading={loading} />
            <div className='communication-inner'>
                <div className='form-input-label'>
                    <Accordion defaultActiveKey="0">
                        <Accordion.Item eventKey="0">
                            <Accordion.Header>
                                <p className='accorheading'>Email messages</p>
                            </Accordion.Header>
                            <Accordion.Body>
                                <ToggleButton
                                    isToggled={formData.sameEmail}
                                    onToggle={handleToggle}
                                    id="sameEmail"
                                    para="Use the same email message for all document types"
                                />
                                <div className="floating-label-group mb-3">
                                    <textarea type="text"
                                        id="message"
                                        className='input-form-control'
                                        value={formData.message}
                                        onChange={handleChange}
                                    />
                                    <label className="floating-label">Message</label>
                                </div>

                                <div className='row'>
                                    <div className='col-lg-6 col-md-6 col-sm-12'>
                                        <div className="floating-label-group">
                                            <input
                                                type="text"
                                                id="cc"
                                                className="input-form-control"
                                                value={formData.cc}
                                                onChange={handleChange}
                                            />
                                            <label className="floating-label" htmlFor="cc">Email CC</label>
                                        </div>
                                    </div>
                                    <div className='col-lg-6 col-md-6 col-sm-12'>
                                        <div className="floating-label-group">
                                            <input
                                                type="text"
                                                id="bcc"
                                                className="input-form-control"
                                                value={formData.bcc}
                                                onChange={handleChange}
                                            />
                                            <label className="floating-label" htmlFor="bcc">Email BCC</label>
                                        </div>
                                    </div>
                                </div>
                            </Accordion.Body>
                        </Accordion.Item>
                    </Accordion>
                </div>

                <div className='sub-head'>
                    <p className='subheading'>Reminders</p>
                </div>
                <ToggleButton
                    isToggled={formData.paymentReminder}
                    onToggle={handleToggle}
                    id="paymentReminder"
                    para="Send payment reminders by email to your customers"
                />
                <div className='reminders'>
                    <div>
                        <input
                            type="checkbox"
                            id="day3BeforeDueDate"
                            checked={formData.day3BeforeDueDate}
                            onChange={handleToggle}
                        />
                        <label htmlFor="day3BeforeDueDate">3 Days Before Due Date</label>
                    </div>
                    <div>
                        <input
                            type="checkbox"
                            id="dueDate"
                            checked={formData.dueDate}
                            onChange={handleToggle}
                        />
                        <label htmlFor="dueDate">On Due Date</label>
                    </div>
                    <div>
                        <input
                            type="checkbox"
                            id="day3AfterDueDate"
                            checked={formData.day3AfterDueDate}
                            onChange={handleToggle}
                        />
                        <label htmlFor="day3AfterDueDate">3 Days After Due Date</label>
                    </div>
                    <div>
                        <input
                            type="checkbox"
                            id="day7AfterDueDate"
                            checked={formData.day7AfterDueDate}
                            onChange={handleToggle}
                        />
                        <label htmlFor="day7AfterDueDate">7 Days After Due Date</label>
                    </div>
                </div>

                <div className='preview'>
                    <h6>Send me a preview</h6>
                    <p>Example reminders will be sent to askyoff@gmail.com.</p>
                </div>

                <div className='sub-head'>
                    <p className='subheading'>Post payment options</p>
                </div>
                <ToggleButton
                    isToggled={formData.paymentNotification}
                    onToggle={handleToggle}
                    id="paymentNotification"
                    heading="Payment notifications"
                    para="Your clients can notify you when they have paid."
                />
                <hr className='separator-line' />
                <ToggleButton
                    isToggled={formData.paymentReceipt}
                    onToggle={handleToggle}
                    id="paymentReceipt"
                    heading="Payment receipts"
                    para="Send a receipt to your client after they pay you."
                />
                <div className='sub-head'>
                    <p className='subheading'>Communication Preferences</p>
                </div>
                <div>
                    <ToggleButton
                        isToggled={formData.email}
                        onToggle={handleToggle}
                        id="email"
                        heading="Email"
                        para="Subscribe to emails"
                    />
                    <hr className='separator-line' />
                    <ToggleButton
                        isToggled={formData.businessResource}
                        onToggle={handleToggle}
                        id="businessResource"
                        heading="Business Resources"
                        para="Articles, videos and podcasts"
                    />
                    <hr className='separator-line' />
                    <ToggleButton
                        isToggled={formData.invoice2go}
                        onToggle={handleToggle}
                        id="invoice2go"
                        heading="Invoice2go Fundamentals"
                        para="Tips and how-to guides"
                    />
                    <hr className='separator-line' />
                    <ToggleButton
                        isToggled={formData.productUpdate}
                        onToggle={handleToggle}
                        id="productUpdate"
                        heading="Product Updates"
                        para="New features and improvements"
                    />
                    <hr className='separator-line' />
                    <ToggleButton
                        isToggled={formData.specialOffer}
                        onToggle={handleToggle}
                        id="specialOffer"
                        heading="Special Offers"
                        para="Contests, giveaways and prizes"
                    />
                </div>
            </div>
        </div>
    );
};


export default ClientCommunication;