"use client"
import React, {useState} from 'react';
import Accordion from 'react-bootstrap/Accordion';
import Pageheader from '@/utils/pageheader';
import ToggleButton from '@/utils/ToggleButton/toggleButton';
import './communication.css';
import '../../general.css';

const ClientCommunication = () => {

    const [value, setValue] = useState(true)

    const handleToggle = (event) => {
        setValue(event.target.checked);
    };
    const handleChange = (event) => {
        setValue(event.target.checked);
    }
  return (
    <div className='communication-container'>
        <Pageheader label="Client communication" />
        <div className='communication-inner'>
            <div className='form-input-label'>
                <Accordion defaultActiveKey="0">
                    <Accordion.Item eventKey="0">
                        <Accordion.Header>
                            <p className='accorheading'>Email messages</p>
                        </Accordion.Header>
                        <Accordion.Body>
                            <ToggleButton 
                                checked={true}
                                onChange={handleChange}
                                id="message"
                                para="Use the same email message for all document types"
                            />
                            
                                <div className="floating-label-group mb-3">
                                    <textarea type="text" id="logo" className="input-form-control" required />
                                    <label className="floating-label">Message</label>
                                </div>
                                <div className='row'>
                                    <div className='col-lg-6 col-md-6 col-sm-12'>
                                        <div className="floating-label-group">
                                            <input type="text" id="tax" className="input-form-control" required />
                                            <label className="floating-label">Email CC</label>
                                        </div>
                                    </div>
                                    <div className='col-lg-6 col-md-6 col-sm-12'>
                                        <div className="floating-label-group">
                                            <input type="text" id="tax" className="input-form-control" required />
                                            <label className="floating-label">Email BCC</label>
                                        </div>
                                    </div>
                                </div>
                                
                        </Accordion.Body>
                    </Accordion.Item>
                </Accordion>
            </div>

            <div className='sub-head'>
                <p className='subheading'>Reminders</p>
            </div>
            <ToggleButton 
                checked={true}
                onChange={handleChange}
                id="message"
                para="Send payment reminders by email to your customers"
            />

            <div className='reminders'>
                <div>
                    <input type="checkbox" checked/> 
                    <label>3 Days Before Due Date</label>
                </div>
                <div>
                    <input type="checkbox"/> 
                    <label>On Due Date</label>
                </div>
                <div>
                    <input type="checkbox"/> 
                    <label>3 Days After Due Date</label>
                </div>
                <div>
                    <input type="checkbox"/> 
                    <label>7 Days After Due Date</label>
                </div>
            </div>
            <div className='preview'>
                <h6>Send me a preview</h6>
                <p>Example reminders will be sent to askyoff@gmail.com.</p>
            </div>
            <div className='sub-head'>
                <p className='subheading'>Post payment options</p>
            </div>

            <ToggleButton 
                checked={true}
                onChange={handleChange}
                id="message"
                heading="Payment notifications"
                para="Your clients can notify you when they have paid."
            />
            <hr className='separator-line'/>
            <ToggleButton 
                checked={true}
                onChange={handleChange}
                id="message"
                heading="Payment receipts"
                para="Send a receipt to your client after they pay you."
            />
            <div className='sub-head'>
                <p className='subheading'>Communication Preferences</p>
            </div>

            <div>
                <ToggleButton 
                    isToggled={value}
                    onToggle={handleToggle}
                    id="email"
                    heading="Email"
                    para="Subscribe to emails"
                />
                <hr className='separator-line'/>
                <ToggleButton 
                    isToggled={value}
                    onToggle={handleToggle}
                    id="Resources"
                    heading="Business Resources"
                    para="Articles, videos and podcasts"
                />
                <hr className='separator-line'/>
                <ToggleButton 
                    isToggled={value}
                    onToggle={handleToggle}
                    id="Fundamentals"
                    heading="Invoice2go Fundamentals"
                    para="Tips and how-to guides"
                />
                <hr className='separator-line'/>
                <ToggleButton 
                    isToggled={value}
                    onToggle={handleToggle}
                    id="Updates"
                    heading="Product Updates"
                    para="New features and improvements"
                />
                <hr className='separator-line'/>
                <ToggleButton 
                    isToggled={value}
                    onToggle={handleToggle}
                    id="Offers"
                    heading="Special Offers"
                    para="Contests, giveaways and prizes"
                />
            </div>
        </div>
    </div>
  )
}

export default ClientCommunication
