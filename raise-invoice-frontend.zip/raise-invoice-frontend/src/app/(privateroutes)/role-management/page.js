"use client"
import React, {useState, useEffect} from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { 
    faSquarePlus,
    faPenToSquare,
    faTrashCan,
    faLongArrowLeft
} from '@fortawesome/free-solid-svg-icons';
import './role-management.css';
import { IMAGE } from '@/utils/Theme';
import { ToastContainer, toast } from 'react-toastify';
import { useDispatch } from 'react-redux';
import { fetchRoleData, createRoleData, deatilsRoleData, updateRoleData, deleteRoleData } from "@/redux/slices/dataSlice";
import Link from 'next/link';
import { confirmAlert } from 'react-confirm-alert';
import 'react-confirm-alert/src/react-confirm-alert.css';

const RoleManagement = () => {
    const dispatch = useDispatch();
    const [isEdit, setIsEdit] = useState(false)
    const [loading, setLoading] = useState(false);
    const [errors, setErrors] = useState({});
    const [formTitle, setFormTitle] = useState('Add Role');
    const [formData, setFormData] = useState({
        id: null,
        roleName: '',
        accessStatus: '',
    });
    const [roles, setRoles] = useState([]);
    const resetFormData = () => {
        setFormData({
            id: null,
            roleName: '',
            accessStatus: '',
        });
        setErrors({});
    }
    const handleAddRole = () => {
        resetFormData();
        setIsEdit(!isEdit);
        setFormTitle('Add Role');
    }
    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };
    const validateForm = () => {
        const newErrors = {};
        console.log(formData)
        if (!formData.roleName) newErrors.roleName = 'Role Name is required';
        if (formData.accessStatus == '' && formData.accessStatus != '0' && formData.accessStatus != '1') newErrors.accessStatus = 'Role access is required';
        return newErrors;
    };
    const handleSave = async () => {
        const validationErrors = validateForm();
        if (Object.keys(validationErrors).length > 0) {
            setErrors(validationErrors);
            return;
        }
    
        var slugify = require('slugify')
        const formDataToSubmit = new FormData();
        formDataToSubmit.append('roleName', formData.roleName);
        formDataToSubmit.append('roleSlug', slugify(formData.roleName, {lower: true}));
        formDataToSubmit.append('accessStatus', formData.accessStatus);
        setLoading(true);
        try {
            let roleSave;
            if (formData.id) {
                // Update existing role
                roleSave = await dispatch(updateRoleData({ roleId: formData.id, roleData: formDataToSubmit })).unwrap();
            } else {
                // Create new role
                roleSave = await dispatch(createRoleData(formDataToSubmit)).unwrap();
            }        
            roleSave.status ? toast.success(roleSave.message) : toast.error(roleSave.message);
            setIsEdit(!isEdit)
            resetFormData();
            fetchRoles();
        } catch (error) {
            console.error('Error saving role data:', error);
        } finally {
            setLoading(false);
        }
    };
    const handleRoleEdit = async (roleToEdit) => {
        // Check if roleToEdit is defined and has an id
        if (roleToEdit && roleToEdit.id) {
            setFormData({
                id: roleToEdit.id,
                roleName: roleToEdit.roleName,
                accessStatus: roleToEdit.accessStatus
            });
            setIsEdit(!isEdit)
            setFormTitle('Edit Role');
        }
    };
    const handleRoleDelete = async (roleToDelete) => {
        if (roleToDelete && roleToDelete.id) {
            confirmAlert({
                title: 'Confirm to delete',
                message: 'Are you sure to do this.',
                buttons: [
                    {
                        label: 'Yes',
                        onClick: async () => {
                            try {
                                const response = await dispatch(deleteRoleData({ roleId: roleToDelete.id })).unwrap();
                                if (response.status) {
                                    toast.success("Role deleted successfully");
                                    fetchRoles();
                                }
                            } catch (error) {
                                console.error('Error deleting role data:', error);
                            }
                        }
                    },
                    {
                        label: 'No'
                    }
                ]
            });
        }
    };
    const fetchRoles = async () => {
        try {
            // Fetch role details
            const roleData = await dispatch(fetchRoleData()).unwrap(); 
            // Set form data with the fetched role details
            if(roleData.status){
                setRoles(roleData.data);
            }                
        } catch (error) {
            console.error('Error fetching role details:', error);
        }
    };
    useEffect(() => {
        fetchRoles();    
    }, [dispatch]);
  return (
    <>
        {isEdit ? (
            <div className='role-container'>
                <div className='management-container'>
                    <div className='account-container form-input-label'>
                        <div className='navbar-tab'>
                            <Link href="#" onClick={handleAddRole}>
                                <FontAwesomeIcon icon={faLongArrowLeft} />
                            </Link>
                        </div>
                        <div className='account-container-head'>
                            <img className="quote-image" src={IMAGE.quoteimg} alt="quoteimg" />
                            <h4>{formTitle}</h4>
                            <p>Manage roles for this account</p>
                        </div>                
                        <div className='field-group'>        
                            <div className="floating-label-group mt-5 mb-4">
                                <input type="text" id="name" name="roleName" className="input-form-control" value={formData.roleName} onChange={handleChange} required />
                                <label className="floating-label">Name</label>
                                {errors.roleName && <span className="text-danger">{errors.roleName}</span>}
                            </div>
                            <div className='payment-type-dropdown'>
                                <label className='payment-label'>Access</label>            
                                <select className="payment-terms mb-0" id="access" name="accessStatus" value={formData.accessStatus} onChange={handleChange}>
                                    <option value="">Select role access</option>
                                    <option value="0">Access to everything</option>
                                    <option value="1">Limited access</option>
                                </select>
                                {errors.accessStatus && <span className="text-danger">{errors.accessStatus}</span>}
                            </div>
                            <div className="text-center">
                                <button className='save-btn mt-4 mb-5' onClick={handleSave} disabled={loading}>
                                    {loading ? 'Saving...' : 'Save'}
                                </button>
                            </div>
                        </div>  
                        
                    </div>
                </div>
            </div>
        ) :
        (
            <div className='role-container'>
                <div className='navbar-tab'>
                    <Link href="/profile">
                        <FontAwesomeIcon icon={faLongArrowLeft} />
                    </Link>
                </div>
                <div className='member-container'>
                    <div className='sub-head'>
                        <p className='heading'>User Role Management</p>
                        <div className='add-members' onClick={handleAddRole}>
                            <p>Add</p>
                            <FontAwesomeIcon icon={faSquarePlus} />
                        </div>
                    </div>
                
                    {
                        roles.map(role => (
                            <div key={role.id}>
                                <div className='member-details-container'>
                                    <div className='management-details'>
                                        <p>{role.roleName}</p>
                                    </div>
                                    {
                                        (role.roleSlug != 'super-admin') ?
                                        <div className='icon-group'>
                                            <Link href="#" onClick={() => handleRoleEdit(role)}>
                                                <FontAwesomeIcon icon={faPenToSquare} className='text-success'/>
                                            </Link>
                                            <Link href="#" onClick={() => handleRoleDelete(role)}>
                                                <FontAwesomeIcon icon={faTrashCan} className='text-danger' />
                                            </Link>                                        
                                        </div>
                                        : ''
                                    }                                
                                </div>
                                <hr className='seperator'/>
                            </div>
                        ))
                    }
                    
                </div>
            </div>
            )
        }
        <ToastContainer />
    </>
    
  )
}

export default RoleManagement
