"use client"
import React, { useState, useEffect, useRef, use } from 'react';
import MiddleSection from "../../../../Components/MiddleSection/MiddleSection";
import { IMAGE } from '@/utils/Theme';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import Accordion from 'react-bootstrap/Accordion';
import Dropdown from 'react-bootstrap/Dropdown';
import Link from 'next/link';



import './clientactivity.css';
import '../../../general.css';

import {
  faSquarePlus,
  faPhoneVolume,
  faEnvelope,
  faPhone,
  faMessage,
  faCircleExclamation,
  faArrowRight,
  faAngleDown,
  faXmark,
  faLocationDot,
  faGlobe,
} from '@fortawesome/free-solid-svg-icons';

import './clientactivity.css';
import '../../../general.css';
import AddClientForm from '../../../../Components/addClientForm/addClientForm';
import { useDispatch, useSelector } from 'react-redux';
import { fetchClientData } from '@/redux/slices/dataSlice';
import { useRouter } from 'next/navigation';

const ClientActivity = ({ params }) => {
  const router = useRouter();
  const { id } = use(params);

  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  // Plus icon dropdown and blur
  const [plusShow, setPlusShow] = useState(false);
  const plusClick = () => setPlusShow(!plusShow);
  const dropdownRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setPlusShow(false);
      }
    };

    // Bind the event listener
    document.addEventListener('mousedown', handleClickOutside);
    // Cleanup the event listener on component unmount
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const dispatch = useDispatch();
  const [addClientForm, setAddClientForm] = useState(false);
  const [clientToEdit, setClientToEdit] = useState(null);
  const { clients } = useSelector((state) => state.dataReducer);

  useEffect(() => {
    dispatch(fetchClientData());
  }, [dispatch]);

  const handleAddClientFormOpen = () => {
    setClientToEdit(null);
    setAddClientForm(true);
  };

  const handleClientAdded = () => {
    dispatch(fetchClientData());
    setAddClientForm(false);
  };

  const handleEditClient = (client) => {
    setClientToEdit(client);
    setAddClientForm(true);
  };

  const [activeTab, setActiveTab] = useState("1");

  const detailsTab = [
    { id: "1", title: "Activity" },
    { id: "2", title: "Projects" }
  ];

  return (
    <>
      <MiddleSection
        label="Client"
        btnlabel={handleClientAdded ? "Add New Client" : "Edit Client"}
        setAddClientForm={handleAddClientFormOpen}
        clients={clients?.data}
        onEditClient={handleEditClient}
        handleCreate={handleAddClientFormOpen}
      />

      <div className='col-lg-8'>
        <div className='add-client contentArea'>
          {addClientForm ? (
            <AddClientForm onClientAdded={handleClientAdded} clientToEdit={clientToEdit} />
          ) : (
            <>
              {/* Blur overlay */}
              {plusShow && (
                <div
                  className="clientactivity-blur-overlay"
                  style={{
                    position: 'fixed',
                    top: 0,
                    left: 0,
                    width: '100vw',
                    height: '100vh',
                    zIndex: 100,
                    backdropFilter: 'blur(6px)',
                    background: 'rgba(255,255,255,0.2)',
                  }}
                />
              )}

              <div className='clientactivity-head' style={plusShow ? { position: 'relative', zIndex: 101 } : {}}>
                <div>
                  <h4 className='name'> <b>Akash Mishra</b></h4>
                </div>
                <div className='head-right'>
                  <div className='activityProject'>
                    {detailsTab.map((tab, index) => (
                      <h4
                        className={tab.id == activeTab ? "active1" : ""}
                        onClick={() => setActiveTab(tab.id)}
                        key={index}
                      >
                        {tab.title}
                      </h4>
                    ))}
                  </div>
                <div className='head-right-innerBody'>

                  <div className='clientActivity' ref={dropdownRef} style={{ position: 'relative', zIndex: 102 }}>
                    <FontAwesomeIcon onClick={plusClick} className="add-iconn" icon={faSquarePlus} />

                    {plusShow && (
                      <ul className='clientActivityDropedown' style={{ position: 'absolute', zIndex: 103 }}>
                        <li><Link href='/addCreditNote'> Credit Note <img src={IMAGE.plusDrpdown} alt="" /></Link></li>
                        <li><Link href={`/purchaseOrder/create?cId=${id}`}>Purchase Order <img src={IMAGE.plusDrpdown} alt="" /></Link></li>
                        <li><Link href={`/estimate/create?cId=${id}`}>Estimate <img src={IMAGE.plusDrpdown} alt="" /></Link></li>
                        <li><Link href={`/addInvoice?cId=${id}`}>Invoice <img src={IMAGE.plusDrpdown} alt="" /></Link></li>
                        <li className='opacityLess'>
                          <Link href={{}}>Statement <img src={IMAGE.downloadColored} alt="" /></Link>
                        </li>
                      </ul>
                    )}
                  </div>

                  <FontAwesomeIcon className="head-icon" icon={faPhoneVolume} />
                  <FontAwesomeIcon className="head-icon" icon={faEnvelope} />
                  <FontAwesomeIcon className="head-icon" icon={faMessage} />
                  <FontAwesomeIcon onClick={handleShow} className="head-icon" icon={faCircleExclamation} />
                </div>
                </div>


                {show && (
                  <div
                    className='moreinfo-body'
                    // style={{
                    //   maxHeight: '80vh',
                    //   overflowY: 'auto',
                    // }}
                  >
                    <div className='moreinfo-content'>
                      <div className='moreinfo-heading'>
                        <h6>More Information</h6>
                        <FontAwesomeIcon onClick={handleClose} icon={faXmark} />
                      </div>

                      <Accordion defaultActiveKey="0">
                        <Accordion.Item eventKey="0">
                          <Accordion.Header>
                            <p className='accorheading'>Billing Details</p>
                          </Accordion.Header>
                          <Accordion.Body>
                            <div className='accordianItemActivity'>
                              <div className='moreinfo-items'>
                                <div>
                                  <p>Billing Name</p>
                                  <h4>Akash Mishra</h4>
                                </div>
                              </div>
                              {/* <hr className='client-activity-divide' /> */}
                              <div className='moreinfo-items'>
                                <FontAwesomeIcon icon={faPhone} />
                                <div>
                                  <p>Billing Name</p>
                                  <h4>Akash Mishra</h4>
                                </div>
                              </div>
                              {/* <hr className='client-activity-divide' /> */}
                              <div className='moreinfo-items'>
                                <FontAwesomeIcon icon={faEnvelope} />
                                <div>
                                  <p>Email Address</p>
                                  <h4>akashmishra@gmail.com</h4>
                                </div>
                              </div>
                              {/* <hr className='client-activity-divide' /> */}
                              <div className='moreinfo-items'>
                                <FontAwesomeIcon icon={faLocationDot} />
                                <div>
                                  <p>Location</p>
                                  <h4>12, Worli Place, near worli, fort, Mumbai, Maharashtra 400030</h4>
                                </div>
                              </div>
                            </div>
                          </Accordion.Body>
                        </Accordion.Item>
                      </Accordion>

                      <Accordion defaultActiveKey="0">
                        <Accordion.Item eventKey="0">
                          <Accordion.Header>
                            <p className='accorheading'>Contact Details</p>
                          </Accordion.Header>
                          <Accordion.Body>
                            <div className='accordianItemActivity'>
                                <div className='moreinfo-items'>
                                  <div>
                                    <p>Contact Name</p>
                                    <h4>Akash Mishra</h4>
                                  </div>
                                </div>
                              {/* <hr className='client-activity-divide' /> */}
                              <div className='moreinfo-items'>
                                <FontAwesomeIcon icon={faPhone} />
                                <div>
                                  <p>Phone No.</p>
                                  <h4>+91 912345 12345</h4>
                                </div>
                              </div>
                              {/* <hr className='client-activity-divide' /> */}
                              <div className='moreinfo-items'>
                                <FontAwesomeIcon icon={faGlobe} />
                                <div>
                                  <p>Website</p>
                                  <h4>www.akshmishra.com</h4>
                                </div>
                              </div>
                            </div>
                          </Accordion.Body>
                        </Accordion.Item>
                      </Accordion>

                      <Accordion defaultActiveKey="0">
                        <Accordion.Item eventKey="0">
                          <Accordion.Header>
                            <p className='accorheading'>Other Details</p>
                          </Accordion.Header>
                          <Accordion.Body>
                            <div className='accordianItemActivity'>
                        
                                <div className='moreinfo-items'>
                                  <div>
                                    <p>Tax No.</p>
                                    <h4>ABP1245756</h4>
                                  </div>
                                </div>
                             
                              {/* <hr className='client-activity-divide' /> */}
                              <div className='moreinfo-items'>
                                <div>
                                  <p>Payment Terms</p>
                                  <h4>14 Days</h4>
                                </div>
                              </div>
                            </div>
                          </Accordion.Body>
                        </Accordion.Item>
                      </Accordion>

                      <button className='add-note'><FontAwesomeIcon icon={faSquarePlus} />
                        Add note
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {activeTab == "1" && (
                <div className='clientDetails'>
                  <div className='client-activity-details'>
                    <div className="clientActvtyLeft">
                      <h6>Outstanding Balance1</h6>
                      <p>1 unpaid(1 overdue)</p>
                    </div>
                    <div>
                      <h4>$120</h4>
                    </div>
                  </div>
                  <div className='client-activity-details'>
                    <div className="clientActvtyLeft">
                      <h6>Statement</h6>
                      <p>Collect Payment</p>
                    </div>
                    <div>
                      <FontAwesomeIcon className='arrwIconRight' icon={faArrowRight} />
                    </div>
                  </div>
                  <div className='client-activity-details'>
                    <div className='sort clientActvtyLeft'>
                      <h6>2025 sorted by category</h6>
                      <FontAwesomeIcon icon={faAngleDown} />
                    </div>
                    <div>
                      <img className='sort-arrow' src={IMAGE.up_down_arrow} alt="sort-arrow" />
                    </div>
                  </div>
                  <div className="card">
                    <div className="card-body">
                      <div className='client-activity-details'>
                        <div className="clientActvtyLeft">
                          <h6>Akash Mishra</h6>
                          <p>23 Oct, Due in 2 days</p>
                        </div>
                        <div>
                          <h6>$125</h6>
                          <p className='unsent'>Unsent</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
              {activeTab == "2" && (
                <div className='clientDetails'>
                  <div className='client-activity-details'>
                    <div className="clientActvtyLeft">
                      <h6>Outstanding Balance</h6>
                      <p>1 unpaid(1 overdue)</p>
                    </div>
                    <div>
                      <h4>$120</h4>
                    </div>
                  </div>
                  <div className='client-activity-details'>
                    <div className="clientActvtyLeft">
                      <h6>Statement</h6>
                      <p>Collect Payment</p>
                    </div>
                    <div>
                      <FontAwesomeIcon className='arrwIconRight' icon={faArrowRight} />
                    </div>
                  </div>
                  <div className='client-activity-details'>
                    <div className='sort clientActvtyLeft'>
                      <h6>2025 sorted by category</h6>
                      <FontAwesomeIcon icon={faAngleDown} />
                    </div>
                    <div>
                      <img className='sort-arrow' src={IMAGE.up_down_arrow} alt="sort-arrow" />
                    </div>
                  </div>
                  <div className="card">
                    <div className="card-body">
                      <div className='client-activity-details'>
                        <div className="clientActvtyLeft">
                          <h6>Akash Mishra</h6>
                          <p>23 Oct, Due in 2 days</p>
                        </div>
                        <div>
                          <h6>$125</h6>
                          <p className='unsent'>Unsent</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </>
  )
}

export default ClientActivity
