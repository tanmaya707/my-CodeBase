"use client"
import React,{useState} from 'react'
import { IMAGE } from '@/utils/Theme';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import MiddleSection from "@/Components/MiddleSection/MiddleSection";
import { 
    faPenToSquare, 
    faTrashCan, 
    faSquarePlus, 
    faPhoneVolume, 
    faEnvelope, 
    faMessage, 
    faCircleExclamation,
    faPhone,
    faLocationDot,
    faGlobe
} from '@fortawesome/free-solid-svg-icons';
import Link from 'next/link';
import './createinvoice.css';
import Dropdown from 'react-bootstrap/Dropdown';
import Accordion from 'react-bootstrap/Accordion';
import Modal from 'react-bootstrap/Modal';

const CreateInvoice = () => {

    const [openModal, setOpenModal] = useState(true);

    return (
    <div className="row">
        <div className="col-lg-5">
            <MiddleSection label="addInvoice"/>

            <p className='letter'>A</p>
            <div className="card">
                <ul className="list-group list-group-flush">
                    <li className="list-group-item">
                        <div className='client-card'>
                            <div className='left-side'>
                                    <img src={IMAGE.circle}/>
                                <div>
                                    <h4>Akash Mishra</h4>
                                    <p>akashmishra@gmail.com</p>
                                </div>
                            </div>
                            <div className='icon-group'>
                                <FontAwesomeIcon className='action-icons' icon={faPenToSquare} />
                                <FontAwesomeIcon className='action-icons' icon={faTrashCan} />
                            </div>
                        </div>
                    </li>
                    <li className="list-group-item">
                        <div className='client-card'>
                            <div className='left-side'>
                                    <img src={IMAGE.circle}/>
                                <div>
                                    <h4>Akash Mishra</h4>
                                    <p>akashmishra@gmail.com</p>
                                </div>
                            </div>
                            <div className='icon-group'>
                                <FontAwesomeIcon className='action-icons' icon={faPenToSquare} />
                                <FontAwesomeIcon className='action-icons' icon={faTrashCan} />
                            </div>
                        </div>
                    </li>                    
                    <li className="list-group-item">
                        <div className='client-card'>
                            <div className='left-side'>
                                    <img src={IMAGE.circle}/>
                                <div>
                                    <h4>Akash Mishra</h4>
                                    <p>akashmishra@gmail.com</p>
                                </div>
                            </div>
                            <div className='icon-group'>
                                <FontAwesomeIcon className='action-icons' icon={faPenToSquare} />
                                <FontAwesomeIcon className='action-icons' icon={faTrashCan} />
                            </div>
                        </div>
                    </li>                
                </ul>
            </div>

            <p className='letter'>B</p>
            <div className="card">
                <ul className="list-group list-group-flush">
                <li className="list-group-item">
                        <div className='client-card'>
                            <div className='left-side'>
                                    <img src={IMAGE.circle}/>
                                <div>
                                    <h4>Akash Mishra</h4>
                                    <p>akashmishra@gmail.com</p>
                                </div>
                            </div>
                            <div className='icon-group'>
                                <FontAwesomeIcon className='action-icons' icon={faPenToSquare} />
                                <FontAwesomeIcon className='action-icons' icon={faTrashCan} />
                            </div>
                        </div>
                    </li>
                    <li className="list-group-item">
                        <div className='client-card'>
                            <div className='left-side'>
                                    <img src={IMAGE.circle}/>
                                <div>
                                    <h4>Akash Mishra</h4>
                                    <p>akashmishra@gmail.com</p>
                                </div>
                            </div>
                            <div className='icon-group'>
                                <FontAwesomeIcon className='action-icons' icon={faPenToSquare} />
                                <FontAwesomeIcon className='action-icons' icon={faTrashCan} />
                            </div>
                        </div>
                    </li>
                    <li className="list-group-item">
                        <div className='client-card'>
                            <div className='left-side'>
                                    <img src={IMAGE.circle}/>
                                <div>
                                    <h4>Akash Mishra</h4>
                                    <p>akashmishra@gmail.com</p>
                                </div>
                            </div>
                            <div className='icon-group'>
                                <FontAwesomeIcon className='action-icons' icon={faPenToSquare} />
                                <FontAwesomeIcon className='action-icons' icon={faTrashCan} />
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
  
        <div className="col-lg-7">
            <div className='add-client contentArea'>
                <div className='sub-head'>
                    <h4 className='name'>Akash Mishra</h4>
                    <h4 className='section'>Activity</h4>
                    <h6 className='section'>Projects</h6>
                    <div className="button-group">
                        <Dropdown>
                            <Dropdown.Toggle>
                                <FontAwesomeIcon icon={faSquarePlus} />
                            </Dropdown.Toggle>

                            <Dropdown.Menu className='dropdown-list'>
                                <Dropdown.Item href="#/action-1">Credit Note <FontAwesomeIcon icon={faSquarePlus} /></Dropdown.Item>
                                <hr/>
                                <Dropdown.Item href="#/action-2">Purchase Order<FontAwesomeIcon icon={faSquarePlus} /></Dropdown.Item>
                                <hr/>
                                <Dropdown.Item href="#/action-3">Estimate<FontAwesomeIcon icon={faSquarePlus} /></Dropdown.Item>
                                <hr/>
                                <Dropdown.Item href="#/action-3">Invoice<FontAwesomeIcon icon={faSquarePlus} /></Dropdown.Item>
                                <hr/>
                                <Dropdown.Item href="#/action-3">Statement<FontAwesomeIcon icon={faSquarePlus} /></Dropdown.Item>
                            </Dropdown.Menu>
                        </Dropdown>
                        <Link className="head-icon" href={{}}><FontAwesomeIcon icon={faPhoneVolume} /></Link>
                        <Link className="head-icon" href={{}}><FontAwesomeIcon icon={faEnvelope} /></Link>
                        <Link className="head-icon" href={{}}><FontAwesomeIcon icon={faMessage} /></Link>
                        <Link className="head-icon" href={{}}><FontAwesomeIcon icon={faCircleExclamation} /></Link>
                    </div>
                </div>
                <hr />

                <img className="blob" src={IMAGE.blob}/>
                <img className="tab" src={IMAGE.tab}/>
                <p>There is no Activity here
                Please create a invoice to start</p>
                <button className='create-btn'>Create Invoice</button>
            </div>    
            </div>
        </div>
    )
}

export default CreateInvoice
