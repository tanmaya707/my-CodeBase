"use client"
import React,{ useEffect, useState } from 'react';
import { IMAGE } from '@/utils/Theme';
import ToggleButton from '@/utils/ToggleButton/toggleButton';
import Pageheader from '@/utils/pageheader';
import './allowreviews.css';

const AllowReviews = () => {

    const [value, setValue] = useState(false);

    const handleToggle = (event) => {
        setValue(event.target.checked);
    };


    return (
        <>
            <div className='review-container'>
                <Pageheader label="Allow Reviews"  />
                <div className='review-container-inside'>

                    <p className='subheading'>Reviews</p>
                    {/* <div className='review'>
                        <p>Allow reviews</p> */}
                        <ToggleButton 
                            isToggled={value}
                            onToggle={handleToggle}
                            id="email"
                            heading="Email"
                            para="Subscribe to emails"
                        />
                    {/* </div> */}
                  
                    <img src={IMAGE.review} alt="review"/>
                    <p className='no-revoew' >No Reviews Yet</p>
                    <button className='upgrade'>Request a review</button>
                </div>


            {/* <div className="card mb-4">
                <div className="card-body">
                    <p className='user-details'>
                        Cardinal ensures we’re making decisions based on data we
                        can trust and gives stakeholders visibility into results without
                        constant back and forth among teams. Cardinal solves that
                        for us and provides a central place for our whole company to
                        see the true impact of our entire product strategy as a whole.
                    </p>

                    <div className='user-info'>
                        <div>
                            <h6>Josh Christensen</h6>
                            <p>Founder & CTO</p>
                            <p>Hona</p>
                        </div>
                        <div>
                            <img src={IMAGE.profile}/>
                        </div>
                    </div>
                </div>
            </div>

            <div className="card mb-4">
                <div className="card-body">
                    <p className='user-details'>
                        Cardinal ensures we’re making decisions based on data we
                        can trust and gives stakeholders visibility into results without
                        constant back and forth among teams. Cardinal solves that
                        for us and provides a central place for our whole company to
                        see the true impact of our entire product strategy as a whole.
                    </p>

                    <div className='user-info'>
                        <div>
                            <h6>Josh Christensen</h6>
                            <p>Founder & CTO</p>
                            <p>Hona</p>
                        </div>
                        <div>
                            <img src={IMAGE.profile}/>
                        </div>
                    </div>
                </div>
            </div> */}
        </div>

        </>
    );
};

export default AllowReviews;
