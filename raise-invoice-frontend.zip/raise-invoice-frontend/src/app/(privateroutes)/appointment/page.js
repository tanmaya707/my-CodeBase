"use client"
import React, { useState, useRef, useEffect } from 'react';
import { IMAGE } from '@/utils/Theme';
import './appointment.css';
import Link from 'next/link';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faMagnifyingGlass, faAngleDown, faCirclePlus } from '@fortawesome/free-solid-svg-icons';
import AppointmentList from '@/Components/appointmentList/AppointmentList';
import Searchbar from '@/Components/searchbar/Searchbar';

const months = [
    { id: 100, name: 'January', value: 1 },
    { id: 101, name: 'February', value: 2 },
    { id: 102, name: 'March', value: 3 },
    { id: 103, name: 'April', value: 4 },
    { id: 104, name: 'May', value: 5 },
    { id: 105, name: 'June', value: 6 },
    { id: 106, name: 'July', value: 7 },
    { id: 107, name: 'August', value: 8 },
    { id: 108, name: 'September', value: 9 },
    { id: 109, name: 'October', value: 10 },
    { id: 110, name: 'November', value: 11 },
    { id: 111, name: 'December', value: 12 },
];

const getYearOptions = (range = 5) => {
    const currentYear = new Date().getFullYear();
    const years = [];
    for (let i = currentYear - range; i <= currentYear + range; i++) {
        years.push(i);
    }
    return years;
};

const Appointment = () => {
    const currentYear = new Date().getFullYear();
    const currentMonth = new Date().getMonth() + 1;

    const [selectedYear, setSelectedYear] = useState(currentYear);
    const [activeMonth, setActiveMonth] = useState(currentMonth);
    const [showYearDropdown, setShowYearDropdown] = useState(false);

    const years = getYearOptions();

    const yearDropdownRef = useRef(null);

    const handleYearChange = (e) => {
        console.log("Selected Year:", e.target.value);
        setSelectedYear(Number(e.target.value));
        setShowYearDropdown(false);
    };

    useEffect(() => {
        const handleOutside = (event) => {
            if (yearDropdownRef.current && !yearDropdownRef.current.contains(event.target)) {
                setShowYearDropdown(false);
            }
        };
        // pointerdown covers mouse/touch/stylus
        document.addEventListener('pointerdown', handleOutside);
        return () => document.removeEventListener('pointerdown', handleOutside);
    }, []);

    return (
        <div className="appointment-header">
            <div className='navbar-container'>
                <img className="background" src={IMAGE.background_img} />
                <h6 className='app-text'>Appointment</h6>
                <div className='right-tabs'>
                    <div className='month-yr-list' style={{ position: 'relative' }} ref={yearDropdownRef}>
                        <div
                            className="year-dropdown-toggle"
                            onClick={() => setShowYearDropdown((prev) => !prev)}
                            style={{
                                display: 'flex',
                                alignItems: 'center',
                                cursor: 'pointer',
                                userSelect: 'none'
                            }}
                        >
                            <span className="selected-year">{selectedYear}</span>
                            <FontAwesomeIcon style={{ color: "#44BBFE", marginLeft: 6 }} icon={faAngleDown} />
                        </div>
                        {showYearDropdown && (
                            <select
                                className="year-dropdown"
                                value={selectedYear}
                                onChange={handleYearChange}
                                size={years.length}
                                // style={{
                                //     position: 'absolute',
                                //     top: '100%',
                                //     left: 0,
                                //     zIndex: 10,
                                //     background: '#fff',
                                //     border: '1px solid #ccc',
                                //     width: '100%',
                                //     marginTop: 2
                                // }}
                                onBlur={() => setShowYearDropdown(false)}
                            >
                                {years.map(year => (
                                    <option key={year} value={year}>{year}</option>
                                ))}
                            </select>
                        )}
                    </div>
                    <div className='icon-group'>
                        <Searchbar />
                        {/* <FontAwesomeIcon className="icon-magnify" icon={faMagnifyingGlass} /> */}
                        <Link href="/addappointment"><FontAwesomeIcon className="icons-add" icon={faCirclePlus} /></Link>
                    </div>
                </div>
            </div>
            <div className='month-tabs'>
                {months.map(month => (
                    <span
                        key={month.value}
                        className={activeMonth === month.value ? 'active' : ""}
                        onClick={() => setActiveMonth(month.value)}
                    >
                        {month.name}
                    </span>
                ))}
            </div>
            <AppointmentList active={activeMonth} year={selectedYear} />
        </div>
    );
};

export default Appointment;
