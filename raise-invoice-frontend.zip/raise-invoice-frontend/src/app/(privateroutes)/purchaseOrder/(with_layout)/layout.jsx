"use client"
import MiddleSection from "@/Components/MiddleSection/MiddleSection";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getPurchaseOrderData, setActiveMidTab } from "@/redux/slices/dataSlice";
import "bootstrap/dist/css/bootstrap.min.css";
import "../../../general.css";
import '../../project/project.css'


const middleSectionTabs = [
    {
        id: 1,
        name: "All",
    },
    {
        id: 2,
        name: "Active",
    },
    {
        id: 3,
        name: "Completed",
    }
]

export default function authLayout({ children }) {
    // const router = useRouter();
    const dispatch = useDispatch();
    const { purchaseOrders, loading } = useSelector(state => state?.dataReducer)
    const [activeTag, setActiveTag] = useState(0);
    const [filteredCreditNotes, setFilteredCreditNotes] = useState([]);

    useEffect(() => {
        dispatch(getPurchaseOrderData());
    }, [dispatch]);

    useEffect(() => {
        // console.log("activeTag ::: ", activeTag, purchaseOrders);

        dispatch(setActiveMidTab(activeTag === 0 ? null : activeTag === 1 ? 1 : 3))
        if (!purchaseOrders?.data) setFilteredCreditNotes();
        if (activeTag === 0) setFilteredCreditNotes(purchaseOrders.data);
        else if (activeTag === 1) setFilteredCreditNotes(purchaseOrders.data.filter(p => p.status !== 3));
        else if (activeTag === 2) setFilteredCreditNotes(purchaseOrders.data.filter(p => p.status === 3));
        else setFilteredCreditNotes(purchaseOrders.data);
    }, [purchaseOrders, activeTag]);


    return (
        <>
            <MiddleSection
                itemType={"Purchase Order"}
                label="Purchase Order"
                tabs={middleSectionTabs}
                activeTag={activeTag}
                setActiveTag={setActiveTag}
                list={filteredCreditNotes}
                createRoute="/purchaseOrder/create"
            />

            <div className={"col-lg-8"}>
                <div className="add-client contentArea">
                    {children}
                </div>
            </div>
        </>
    );
}
