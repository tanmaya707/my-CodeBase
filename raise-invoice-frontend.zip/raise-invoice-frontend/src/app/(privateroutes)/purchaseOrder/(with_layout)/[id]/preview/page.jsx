"use client";
import { useSelector } from "react-redux";
import CustomInvoiceImpact from "@/Components/templates/impact";
import "../../../../invoice/invoice.css"
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { detailsPurchaseOrderData } from "@/redux/slices/dataSlice";

const InvoicePreview = ({params}) => {
    const dispatch = useDispatch();
    // const {invoiceDetails, loading} = useSelector(state => state.dataReducer);
    const [previewDetails, setPreviewDetails] = useState({})
    useEffect(() => {
        (async () => {
            const invoiceParam = await params
            console.log("invoiceParam ::: ", invoiceParam, invoiceParam?.id);
            const preview = await dispatch(detailsPurchaseOrderData({id : invoiceParam.id})).unwrap();
            setPreviewDetails(preview?.data)
        })()
    }, [params]);

    // useEffect(() => {
    //     console.log("invoiceDetails in preview ::: ", invoiceDetails?.customInvoice);
    // }, [invoiceDetails])
    
    return (
        <div className="preview-container-page">
            <div className="preview-container">
                <div className='preview-content'>
                    <CustomInvoiceImpact 
                    invoice={{...previewDetails?.purchaseOrder,
                        invoiceDate : previewDetails?.purchaseOrder?.date, 
                        name: "Invoice", 
                        selectedClient : previewDetails?.client,
                        discountTotal : previewDetails?.purchaseOrder?.discount || ''
                    }} 
                    // customTemplates={customTemplates} 
                    // customTemplates={[]}
                    selectedTemp={previewDetails?.customInvoice?.templateName}
                    selectedId={
                        previewDetails?.customInvoice?.logoId
                            ? { id: previewDetails?.customInvoice?.logoId, logoImage: previewDetails?.customInvoice?.logoImage }
                            : null
                    }
                    selectedSize={previewDetails?.customInvoice?.logoSize}
                    alignPos={previewDetails?.customInvoice?.logoPosition}
                    selectedColour={
                        previewDetails?.customInvoice?.colourId
                            ? { id: previewDetails?.customInvoice?.colourId, colourCode: previewDetails?.customInvoice?.colourCode }
                            : null
                    }
                    customColour={previewDetails?.customInvoice?.customColour}
                    selectedHeader={
                        previewDetails?.customInvoice?.headerId
                            ? { id: previewDetails?.customInvoice?.headerId, headerImg: previewDetails?.customInvoice?.headerImg }
                            : null
                    }
                    selectedWatermark={
                        previewDetails?.customInvoice?.waterMarkId
                            ? {
                                    id: previewDetails?.customInvoice?.waterMarkId,
                                    waterMarkImg: previewDetails?.customInvoice?.waterMarkImg,
                                }
                            : null
                    }
                    customOption={previewDetails?.customInvoiceOption}
                     />
                </div>
            </div>    
        </div>    
    );
}
export default InvoicePreview;


// customTemplates={customTemplates}