
"use client"

import { detailsEstimateData, detailsPurchaseOrderData } from "@/redux/slices/dataSlice";
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import "../../../invoice/invoice.css"
import InvoiceHeader from "@/Components/invoices/header";
import { dateFormater, differentOfDate } from "@/dependencies/utils/helper";
import InvoicePreview from "@/Components/invoices/preview";
import Payment from "@/Components/invoices/payment";
import MoreDetails from "@/Components/invoices/more";

const PurchaseOrderDetailsPage = ({ params }) => {
    const dispatch = useDispatch();
    // const {poDetails, loading} = useSelector(state => state.dataReducer);
    const [poDetails, setPoDetails] = useState({})
    const [invoiceHeader, setInvoiceHeader] = useState(null)
    const [previewRef, setPreviewRef] = useState(null)
    const [purchaseOrder, setPurchaseOrder] = useState({})
    // const [selectedClient, setSelectedClient] = useState(estimate?.client || {})

    useEffect(() => {
        (async () => {
            const estimateParam = await params
            // console.log("estimateParam ::: ", estimateParam, estimateParam?.id);
            const poData = await dispatch(detailsPurchaseOrderData({id : estimateParam.id})).unwrap();
            // console.log("poData :: ", poData?.data);
            
            setPoDetails(poData?.data)
        })()
    }, [params]);

    useEffect(() => {
        // console.log("poDetails ::: ", poDetails);
        if(poDetails && poDetails?.purchaseOrder){
            const purchaseOrder = poDetails?.purchaseOrder
            // console.log("purchaseOrder ::: ", purchaseOrder);
            setPurchaseOrder(purchaseOrder)
            setInvoiceHeader({
                type : "Purchase Order",
                paymentStatus : purchaseOrder?.paymentStatus,
                date : dateFormater(purchaseOrder?.createdAt),
                // dueDate : differentOfDate(purchaseOrder?.dueDate),
                name : purchaseOrder?.client?.name,
                amount : purchaseOrder?.total
            })
        }   
    }, [poDetails])

    return (
        <div className="invoice-details">
            {invoiceHeader !== null && <InvoiceHeader headerInfo={invoiceHeader} />}
            {poDetails && purchaseOrder && <InvoicePreview addRoute="purchaseOrder/edit" customInvoice={poDetails?.customInvoice} customInvoiceOption={poDetails?.customInvoiceOption} route="purchaseOrder" setPreviewRef={setPreviewRef} previewRef={previewRef}  invoice={{...purchaseOrder, invoiceDate : purchaseOrder?.createdAt, name: "PurchaseOrder", selectedClient : poDetails?.client,
                        discountTotal : purchaseOrder?.discount || ''

            }} />}
            {/* <InvoicePreview /> */}
            <Payment isNonPaid={purchaseOrder.paymentStatus === "unpaid"} />
            <MoreDetails  previewRef={previewRef} id={purchaseOrder.id} invoiceNumber={purchaseOrder?.invoiceNumber} isNonPaid={purchaseOrder.paymentStatus === "unpaid"} route="/purchaseOrder/create" />
        </div>
    )
}
export default PurchaseOrderDetailsPage;
