"use client"
import React, { useState } from 'react';
import './payment.css';
import { IMAGE } from '@/utils/Theme';
import Link from 'next/link';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faSquareArrowUpRight } from '@fortawesome/free-solid-svg-icons';
import ToggleButton from '@/utils/ToggleButton/toggleButton';
import Pageheader from '@/utils/pageheader';

const ClientPaymentOptions = () => {

    const [value, setValue] = useState(false);
    const [value2, setValue2] = useState(false);

    const handleTips = (e) => {
        setValue(e.target.checked);
    }
    const handleAdvice = (e) => {
        setValue2(e.target.checked);
    }
    return (
        <div className='ClientPayment middle-area-note'>
            <div className="paymentcontainer">
                <div>
                    <Pageheader label="Client payment options" />

                    <div className='px-5'>
                        <p className='subheading'> Raise Invoice Money</p>

                        <div className="card">
                            <div className="card-body">
                                <div className='payment-card'>
                                    <div>
                                        <div className='card-left'>
                                            <img src={IMAGE.cards} alt="" />
                                            <div>
                                                <h6>Card Payment</h6>
                                                <p>Powered by raiseinvoice.com</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <Link href="">Setup</Link>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="card">
                            <div className="card-body">
                                <div className='payment-card'>
                                    <div>
                                        <div className='card-left'>
                                            <img src={IMAGE.bank} alt="" />
                                            <div>
                                                <h6>Card Payment</h6>
                                                <p>Powered by raiseinvoice.com</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <Link href="">Setup</Link>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <p className='subheading'> Online Payment Methods</p>

                        <div className="card">
                            <div className="card-body">
                                <div className='payment-card'>
                                    <div>
                                        <div className='card-left'>
                                            <img src={IMAGE.paypal} alt="" />
                                            <div>
                                                <h6>Paypal</h6>
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <Link href="">Setup</Link>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <p className='subheading'> Invoice Due Date</p>

                        <div className='payment-type-dropdown'>
                            <label className='payment-label'>Payment Terms</label>

                            <select className="payment-terms" name="cars" id="cars">
                                <option value="volvo">Volvo</option>
                                <option value="saab">Saab</option>
                                <option value="mercedes">Mercedes</option>
                                <option value="audi">Audi</option>
                            </select>
                        </div>

                        <p className='subheading'> Tips</p>
                        <ToggleButton
                            isToggled={value}
                            onToggle={handleTips}
                            id="tips"
                            heading="Allow Tips"
                            para="Let customers add a tip when they pay online"
                        />

                        <p className='subheading'> Invoice Instructions</p>

                        <p className='instruction'>Payment Instruction</p>

                        <ToggleButton
                            isToggled={value2}
                            onToggle={handleAdvice}
                            id="advice"
                            heading="Remittance Advice"
                            para="Show remittance advice at the bottom of invoices so clients can attach payments"
                        />

                        <p className='subheading'> Estimate Deposit</p>

                        <p className='estimate'>Let clients pay estimate deposits using offline payment methods, such as cash and checks.</p>
                    </div>


                </div>

                <div>
                    <div className='navbar-tab-right mb-4'>
                        <p>Payment Transactions</p>
                        <FontAwesomeIcon icon={faSquareArrowUpRight} />
                    </div>
                    <div className="card">
                        <div className="card-body">
                            <div className='payment-card'>
                                <div>
                                    <div className='card-left'>
                                        <img src={IMAGE.paypal} alt="" />
                                        <div className='payment-details'>
                                            <h6>From PayPal</h6>
                                            <p>From Akash Mishra</p>
                                            <p>Transaction ID</p>
                                            <p>564925374920</p>
                                        </div>
                                    </div>
                                </div>
                                <div className='card-right'>
                                    <h6>$ 100.00</h6>
                                    <p>17 Dec 2024</p>
                                    <p>10:34 AM</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="card">
                        <div className="card-body">
                            <div className='payment-card'>
                                <div>
                                    <div className='card-left'>
                                        <img src={IMAGE.paypal} alt="" />
                                        <div className='payment-details'>
                                            <h6>From PayPal</h6>
                                            <p>From Akash Mishra</p>
                                            <p>Transaction ID</p>
                                            <p>564925374920</p>
                                        </div>
                                    </div>
                                </div>
                                <div className='card-right'>
                                    <h6>$ 100.00</h6>
                                    <p>17 Dec 2024</p>
                                    <p>10:34 AM</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="card">
                        <div className="card-body">
                            <div className='payment-card'>
                                <div>
                                    <div className='card-left'>
                                        <img src={IMAGE.paypal} alt="" />
                                        <div className='payment-details'>
                                            <h6>From PayPal</h6>
                                            <p>From Akash Mishra</p>
                                            <p>Transaction ID</p>
                                            <p>564925374920</p>
                                        </div>
                                    </div>
                                </div>
                                <div className='card-right'>
                                    <h6>$ 100.00</h6>
                                    <p>17 Dec 2024</p>
                                    <p>10:34 AM</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="card">
                        <div className="card-body">
                            <div className='payment-card'>
                                <div>
                                    <div className='card-left'>
                                        <img src={IMAGE.paypal} alt="" />
                                        <div className='payment-details'>
                                            <h6>From PayPal</h6>
                                            <p>From Akash Mishra</p>
                                            <p>Transaction ID</p>
                                            <p>564925374920</p>
                                        </div>
                                    </div>
                                </div>
                                <div className='card-right'>
                                    <h6>$ 100.00</h6>
                                    <p>17 Dec 2024</p>
                                    <p>10:34 AM</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="card">
                        <div className="card-body">
                            <div className='payment-card'>
                                <div>
                                    <div className='card-left'>
                                        <img src={IMAGE.paypal} alt="" />
                                        <div className='payment-details'>
                                            <h6>From PayPal</h6>
                                            <p>From Akash Mishra</p>
                                            <p>Transaction ID</p>
                                            <p>564925374920</p>
                                        </div>
                                    </div>
                                </div>
                                <div className='card-right'>
                                    <h6>$ 100.00</h6>
                                    <p>17 Dec 2024</p>
                                    <p>10:34 AM</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default ClientPaymentOptions