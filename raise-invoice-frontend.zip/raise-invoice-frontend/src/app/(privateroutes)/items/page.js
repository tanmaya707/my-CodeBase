// Client.js
"use client";
import React, { useState, useEffect } from "react";
import MiddleSection from "@/Components/MiddleSection/MiddleSection";
import { IMAGE } from "@/utils/Theme";
import "../../../Components/addClientForm/addClientForm.css";
import "./items.css";
import { useDispatch, useSelector } from "react-redux";
import { fetchItemData } from "@/redux/slices/dataSlice";
import Link from "next/link";
import AddItemFormInner from "../../../Components/addItemForm/addItemForm";
import DigitalMarketing from "@/Components/digitalMarketing/digitalMarketing";

const Items = () => {
  const dispatch = useDispatch();
  const [AddItemForm, setAddItemForm] = useState(false);
  const [itemToEdit, setItemToEdit] = useState(null);
  const { projectItems } = useSelector((state) => state.dataReducer);

  const setAddAppointmentForm = () => {
    window.location.href = `addappointment`;
  };

  useEffect(() => {
    dispatch(fetchItemData());
  }, [dispatch]);

  const handleAddItemFormOpen = () => {
    setItemToEdit(null);
    setAddItemForm(true);
  };

  const handleItemAdded = () => {
    dispatch(fetchItemData());
    setAddItemForm(false);
  };

  const handleEditItem = (item) => {
    setItemToEdit(item);
    setAddItemForm(true);
  };

  return (
    <>
      <MiddleSection
        label="Items"
        className={ itemToEdit ? "itemsBg" : "" }
        btnlabel={itemToEdit ? "Edit Item" : "Add New Item"}
        setAddItemForm={handleAddItemFormOpen}
        items={projectItems?.data}
        onEditItem={handleEditItem}
        itemType="Items"
      />
      <div className="col-lg-8">
        <div className="add-client contentArea ">
          {AddItemForm ? (
            <AddItemFormInner
              onItemAdded={handleItemAdded}
              itemToEdit={itemToEdit}
            />
          ) : (
            <>
              <div className={!AddItemForm ? "scrollRightSide" : ""}>
                <img className="worldmap" src={IMAGE.itemIamge} />
                {!projectItems?.data && (
                  <p className="client-text mt-3">No Item Added Yet</p>
                )}
                <div className="client-btn mt-3">
                  <button
                    className="create-btn"
                    onClick={() => setAddItemForm(true)}
                  >
                    Add New Item
                  </button>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </>
  );
};

export default Items;
