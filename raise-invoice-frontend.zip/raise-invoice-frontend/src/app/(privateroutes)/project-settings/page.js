"use client"
import React, { useEffect, useState } from 'react';
import Pageheader from '@/utils/pageheader';
import Accordion from 'react-bootstrap/Accordion';
import { useDispatch } from 'react-redux';
import { fetchProjectSettingData, updateProjectSettingData } from "@/redux/slices/dataSlice"; // Adjust the import based on your actual slice
import { toast } from 'react-toastify';
import { useRouter } from 'next/navigation';
import '../client-communication/communication.css';

const ProjectSettings = () => {
  const dispatch = useDispatch();
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [newId, setNewId] = useState(""); // State to hold the project ID
  const [newClient, setNewClient] = useState(false);
  const [newEstimate, setNewEstimate] = useState(false);
  const [newInvoice, setNewInvoice] = useState(false);
  const [prefix, setPrefix] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const result = await dispatch(fetchProjectSettingData()).unwrap();

        if (result) {
          setNewId(result.data.id); // Set the project ID
          setNewClient(result.data.addNewClient);
          setNewEstimate(result.data.newEstimate);
          setNewInvoice(result.data.newInvoice);
          setPrefix(result.data.prefix || '');
        }
      } catch (error) {
        console.error('Error fetching project settings:', error);
      }
    };

    fetchData();
  }, [dispatch]);

  const handleCheckboxChange = (setter) => (event) => {
    setter(event.target.checked);
  };

  const handlePrefixChange = (event) => {
    setPrefix(event.target.value);
  };

  const handleSave = async () => {
    const formData = {
      id: newId, // Include the project ID in the form data
      addNewClient: newClient ? 1 : 0,
      newEstimate: newEstimate ? 1 : 0,
      newInvoice: newInvoice ? 1 : 0,
      prefix: prefix,
    };
    setLoading(true); // Set loading to true
    try {
      const projectSave = await dispatch(updateProjectSettingData(formData)).unwrap();
      projectSave.status ? toast.success(projectSave.message) : toast.error(projectSave.message);
      router.refresh();
      router.push(`/project-settings`);
    } catch (error) {
      setError(`Error saving settings: ${error.message}`);
      console.error('Error saving settings:', error);
    } finally {
      setLoading(false); // Reset loading state
    }

  };

  return (
    <div className='communication-container'>
      <Pageheader label="Project Settings" handleSave={handleSave} loading={loading} />
      <div className='communication-inner'>
        <Accordion defaultActiveKey="0">
          <Accordion.Item eventKey="0">
            <Accordion.Header>
              <p className='accorheading'>Projects settings</p>
            </Accordion.Header>
            <Accordion.Body>
              <div className='reminders'>
                <div>
                  <input
                    type="checkbox"
                    checked={newClient}
                    onChange={handleCheckboxChange(setNewClient)}
                  />
                  <label>Add New Client</label>
                </div>
                <div>
                  <input
                    type="checkbox"
                    checked={newEstimate}
                    onChange={handleCheckboxChange(setNewEstimate)}
                  />
                  <label>New Estimate</label>
                </div>
                <div>
                  <input
                    type="checkbox"
                    checked={newInvoice}
                    onChange={handleCheckboxChange(setNewInvoice)}
                  />
                  <label>New Invoice</label>
                </div>
              </div>
            </Accordion.Body>
          </Accordion.Item>
        </Accordion>

        <div className='sub-head'>
          <p className='subheading'>Project numbers</p>
        </div>
        <div className='preview mb-3'>
          <p>Add a prefix before project numbers (e.g. PROJECT123).</p>
        </div>
        <div className="floating-label-group mb-3">
          <input
            type="text"
            id="prefix"
            className="input-form-control"
            value={prefix}
            onChange={handlePrefixChange}
            required
          />
          <label className="floating-label">Prefix</label>
        </div>
        {error && <p className="error-message">{error}</p>} {/* Display error message if any */}
      </div>
    </div>
  );
}

export default ProjectSettings;
