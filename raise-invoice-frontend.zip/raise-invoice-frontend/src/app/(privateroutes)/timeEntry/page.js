"use client"
import React, { useState } from 'react';
import {IMAGE } from "../../../utils/Theme"
import Link from 'next/link';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faMagnifyingGlass, faAngleDown, faCirclePlus } from '@fortawesome/free-solid-svg-icons';
import Searchbar from '@/Components/searchbar/Searchbar';
import "./TimeEntry.css"
import AppointmentList from '@/Components/appointmentList/AppointmentList';
import { useModal } from '@/cotexts/modalContext';

    const getYearOptions = (range = 5) => {
    const currentYear = new Date().getFullYear();
    const years = [];
    for (let i = currentYear - range; i <= currentYear + range; i++) {
        years.push(i);
    }
    return years;
};

const billedList = [
    { id: 100, name: 'All', value: 1 },
    { id: 101, name: 'Unbilled', value: 2 },
    { id: 102, name: 'Billed', value: 3 },
];



const TimeEntry = () => {
    const {openModal, setParameters} = useModal();
    const [activeTab, setActiveTab] = useState(billedList[0].value);
      const [AddItemForm, setAddItemForm] = useState(false);
      const handleAddItemFormOpen = () => {
            setItemToEdit(null);
            setAddItemForm(true);
        };



    const currentYear = new Date().getFullYear();
     const currentMonth = new Date().getMonth() + 1;
 
     const [selectedYear, setSelectedYear] = useState(currentYear);
     const [activeMonth, setActiveMonth] = useState(1);
     const [showYearDropdown, setShowYearDropdown] = useState(false);


 
     const years = getYearOptions();
 
     const handleYearChange = (e) => {
         console.log("Selected Year:", e.target.value);
         setSelectedYear(Number(e.target.value));
         setShowYearDropdown(false);
      
     };

    const addTimes = (e) => {
        e.preventDefault()
        console.log("szdfghjkl;");
        
        openModal("addTimes")
        setParameters({header : "Add Time"})
    }

    return(
        <>
        <div className="appointment-header">
             <div className='navbar-container'>
                <img className="background" src={IMAGE.background_img} />
                <h6 className='app-text'>Appointment</h6>
                <div className='right-tabs'>
                    <div className='month-yr-list' style={{ position: 'relative' }}>
                        <div
                            className="year-dropdown-toggle"
                            onClick={() => setShowYearDropdown((prev) => !prev)}
                            style={{
                                display: 'flex',
                                alignItems: 'center',
                                cursor: 'pointer',
                                userSelect: 'none'
                            }}
                        >
                            <span className="selected-year">{selectedYear}</span>
                            <FontAwesomeIcon style={{ color: "#44BBFE", marginLeft: 6 }} icon={faAngleDown} />
                        </div>
                        {showYearDropdown && (
                            <select
                                className="year-dropdown"
                                value={selectedYear}
                                onChange={handleYearChange}
                                size={years.length}
                                onBlur={() => setShowYearDropdown(false)}
                            >
                                {years.map(year => (
                                    <option key={year} value={year}>{year}</option>
                                ))}
                            </select>
                        )}
                    </div>
                    <div className='icon-group'>
                        <Searchbar />
                        {/* <FontAwesomeIcon className="icon-magnify" icon={faMagnifyingGlass} /> */}
                        <Link href="#"><FontAwesomeIcon className="icons-add" icon={faCirclePlus}  onClick={addTimes} /></Link> 
                    </div>
                </div>
            </div>

            <div className="addNewTimeEntry">
               

               {!AddItemForm ? (
                       <div className="scrollRightSide">
                    <img className="worldmap" src={IMAGE.timeEntry} />
                    
                    <p className="client-text mt-3">There no time entry added yet</p>
            
                    <div className="client-btn mt-3">
                    <button
                        className="create-btn"
                        onClick={() => setAddItemForm(true)}
                    >
                        Add new Time entry
                    </button>
                    </div>
                </div>
                    ) : (
                        <div className='fixedWidth'>
                        
                            <div className='month-tabs timeTab'>
                                {billedList.map(month => (
                                    <span
                                        key={month.value}
                                        className={activeMonth === month.value ? 'active' : ""}
                                        onClick={() => setActiveMonth(month.value)}
                                    >
                                        {month.name}
                                    </span>
                                ))}
                            </div>

                            <div className="tab-content">
                                {{
                                    1: (
                                        <div className="tab-content-inner">
                                               <div className="innerHeader">   
                                                    <h6>1 Nov </h6>
                                                    <h6 className='timeImageText'><img src={IMAGE.timeImage} alt="" /> 30:00  </h6> 
                                                </div>
                                                 <div className="contentNote">   
                                                   <h6>Akash Misra</h6>
                                                   <p>Note</p>
                                                </div>


                                        </div>
                                    ),
                                    2: (
                                        <>
                                            <div className="tab-content-inner">
                                               <div className="innerHeader">   
                                                    <h6>1 Nov </h6>
                                                    <h6 className='timeImageText'><img src={IMAGE.timeImage} alt="" /> 30:00  </h6> 
                                                </div>
                                                 <div className="contentNote">   
                                                   <h6>Akash Misra</h6>
                                                   <p>Note</p>
                                                </div>

                                        </div>
                                        </>
                                    ),
                                    3: (
                                        <>
                                            <p>Tab 3: Billed content here</p>
                                        </>
                                    )
                                }[activeMonth] || <p>No content</p>}
                            </div>
                        </div>
                    )}



            </div>


        </div>
        </>
    )


}

export default TimeEntry;