"use client"
import React, { useState, useEffect } from 'react'
import MiddleSection from '@/Components/MiddleSection/MiddleSection';
import { getExpenseData } from '@/redux/slices/dataSlice';
import { useDispatch, useSelector } from 'react-redux';

const Expense = ({ children }) => {

    const dispatch = useDispatch();
    const { expenses } = useSelector((state) => state.dataReducer);

    useEffect(() => {
        dispatch(getExpenseData());
    }, []);


    return (
        <>
            <MiddleSection
                label="Expense"
                itemType="Expense"
                list={expenses}
                createRoute="/expense/create"
            />
            <div className="col-lg-8">
                <div className='add-expense contentArea'>
                    {children}
                </div>
            </div>
        </>
    )
}

export default Expense
