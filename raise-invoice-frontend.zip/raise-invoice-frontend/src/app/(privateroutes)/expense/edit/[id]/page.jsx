"use client"

import NewExpense from "@/Components/newExpense/newExpense";
import { detailsExpenseData } from "@/redux/slices/dataSlice";
import { use, useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { useDispatch } from "react-redux";

const EditExpense = ({params}) => {
    const { expenses } = useSelector((state) => state.dataReducer);
    const { id } = use(params);
    const [expense, setExpense] = useState({})
    // const dispatch = useDispatch();

    useEffect(() => {
        const allExpenses = expenses?.flatMap(cat => cat.expenses) || [];
        setExpense(allExpenses.filter(el => el?.id === Number(id)));
    }, [id, expenses]);

    return <div>
        <NewExpense id={id} expenseToEdit={expense?.length > 0 ? expense[0] : {}} />

    </div>
}

export default EditExpense;