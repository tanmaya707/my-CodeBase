const ExpenseDetails = () => {
    return <div></div>
}

export default ExpenseDetails;