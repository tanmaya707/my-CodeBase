"use client"
import React, { useState, useEffect } from 'react'
// import MiddleSection from '@/Components/MiddleSection/MiddleSection';
import MenuLandingPage from '@/utils/MenuLanding/MenuLandingPage';
// import NewExpense from '@/Components/newExpense/newExpense';
// import DigitalMarketing from '@/Components/digitalMarketing/digitalMarketing';
import { IMAGE } from '@/utils/Theme';
import { getExpenseData } from '@/redux/slices/dataSlice';
import { useDispatch, useSelector } from 'react-redux';

const Expense = () => {

  // const dispatch = useDispatch();
  // const [addExpense, setAddExpense] = useState(false)
  // const [activeTag, setActiveTag] = useState(0);

  // const [addExpenseForm, setAddExpenseForm] = useState(false);
  // const [expenseToEdit, setExpenseToEdit] = useState(null);
  const { expenses } = useSelector((state) => state.dataReducer);

  const Image = IMAGE.blank_project

  // useEffect(() => {
  //   dispatch(getExpenseData());
  // }, [dispatch]);

  // const handleAddExpenseFormOpen = () => {
  //   setExpenseToEdit(null);
  //   setAddExpenseForm(true);
  // };

  // const handleExpenseAdded = () => {
  //   dispatch(fetchClientData());
  //   setAddExpenseForm(false);
  // };

  // const handleEditExpense = (project) => {
  //   setExpenseToEdit(project);
  //   setAddExpenseForm(true);
  // };

  return (
    <>
      {/* <MiddleSection
        label="Expense"
        // btnlabel="Create Expense"
        handleState={setAddExpense}
        itemType="Expense"
        setAddExpenseForm={handleAddExpenseFormOpen}
        expenses={expenses?.data}
        handleEditExpense={handleEditExpense}
      /> */}
   {/* <div className="col-lg-8">
        <div className='add-expense contentArea'>  */}
          {/* {addExpenseForm ? <NewExpense onExpenseAdded={handleExpenseAdded} expenseToEdit={expenseToEdit} /> : ( */}
            <MenuLandingPage
              Image={Image}
              text={expenses?.length > 0 ? "" : "There is no expense added yet. Please add an expense"}
              label="Create Expense"
              createRoute="/expense/create"
              // handleState={setAddExpenseForm}
              itemType="Expense"
            />
          {/* )} */}
      {/* </div>
      </div>  */}
    </>
  )
}

export default Expense
