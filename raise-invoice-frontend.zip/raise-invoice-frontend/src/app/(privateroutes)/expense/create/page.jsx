import NewExpense from "@/Components/newExpense/newExpense";

const CreateExpense = () => {
    return <div>
        <NewExpense />
        
    </div>
}

export default CreateExpense;