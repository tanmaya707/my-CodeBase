/* eslint-disable @next/next/no-img-element */
"use client";
import React, { useEffect, useState, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import { IMAGE } from "@/utils/Theme";
import Accordion from "react-bootstrap/Accordion";
import Pageheader from "@/utils/pageheader";
import Form from "react-bootstrap/Form";
import { ToastContainer, toast } from "react-toastify";
import { useRouter } from "next/navigation";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faSquarePlus } from "@fortawesome/free-solid-svg-icons";
import {
  listLogosData,
  listColorsData,
  listWaterMarksData,
  listHeadersData,
  createCustomInvoiceData,
  getCustomInvoiceData,
  createCustomInvoiceOptionData,
  getCustomInvoiceOptionData,
  createLogosData,
  uploadHeader,
  uploadWatermark,
} from "@/redux/slices/dataSlice";
import "./customise.css";
import "../client-communication/communication.css";
import "../../general.css";
import CustomInvoiceImpact from "@/Components/customInvoice/impact";
import CustomInvoiceModern from "@/Components/customInvoice/modern";
import CustomInvoiceClassic from "@/Components/customInvoice/classic";

const CustomiseInvoice = () => {
  const dispatch = useDispatch();
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  // State for all fields
  const [formData, setFormData] = useState({
    id: null, // for update
    templateName: "impact",
    logoId: "",
    logoImage: "",
    logoSize: "medium",
    logoPosition: "center",
    colourId: "",
    colourCode: "",
    customColour: "",
    headerId: "",
    headerImg: "",
    waterMarkId: "",
    waterMarkImg: "",
  });

  // Custom Invoice Option fields
  const [optionData, setOptionData] = useState({
    id: null,
    shippingDetails: false,
    due_date: true,
    payment_terms: true,
    itemCode: false,
    quantityAndRate: true,
    pTax: false,
    tax_amounts: false,
    includeSignatureLine: true,
    invoicePrifix: "",
  });

  const { customTemplates } = useSelector(
    (state) => state.dataReducer
  );

  const [tab, setTab] = useState(0);
  const [footerTab, setFooterTab] = useState(0);

  // Prefill data on mount
  useEffect(() => {
    dispatch(listLogosData());
    dispatch(listColorsData());
    dispatch(listWaterMarksData());
    dispatch(listHeadersData());

    // Get custom invoice
    dispatch(getCustomInvoiceData()).then((res) => {
      const data = res?.payload?.data;
      if (data) {
        setFormData({
          id: data.id || null,
          templateName: data.name || "impact",
          logoId: data.logoDetails?.id || "",
          logoImage: data.logoDetails?.logoImage || "",
          logoSize: data.logoSize || "medium",
          logoPosition: data.logoPosition || "center",
          colourId: data.colourDetails?.id || "",
          colourCode: data.colourDetails?.colourCode || "",
          customColour: data.colourDetails?.customColour || "",
          headerId: data.headerDetails?.id || "",
          headerImg: data.headerDetails?.headerImg || "",
          waterMarkId: data.waterMarkDetails?.id || "",
          waterMarkImg: data.waterMarkDetails?.waterMarkImg || "",
        });
      } else if (customTemplates) {
        setFormData({
          id: customTemplates.data?.id || null,
          templateName: customTemplates.data?.name || "impact",
          logoId: customTemplates.logoDetails?.id || "",
          logoImage: customTemplates.data?.logoDetails?.logoImage || "",
          logoSize: customTemplates.data?.logoSize || "medium",
          logoPosition: customTemplates.data?.logoPosition || "center",
          colourId: customTemplates.data?.colourDetails?.id || "",
          colourCode: customTemplates.data?.colourDetails?.colourCode || "",
          customColour: customTemplates.data?.colourDetails?.customColour || "",
          headerId: customTemplates.data?.headerDetails?.id || "",
          headerImg: customTemplates.data?.headerDetails?.headerImg || "",
          waterMarkId: customTemplates.data?.waterMarkDetails?.id || "",
          waterMarkImg: customTemplates.data?.waterMarkDetails?.waterMarkImg || "",
        });
      }
    });
    // Get custom invoice option
    dispatch(getCustomInvoiceOptionData()).then((res) => {
      const data = res?.payload?.data;
      if (data) {
        setOptionData({
          id: data.id || null,
          shippingDetails: !!data.shippingDetails,
          due_date: !!data.due_date,
          payment_terms: !!data.payment_terms,
          itemCode: !!data.itemCode,
          quantityAndRate: !!data.quantityAndRate,
          pTax: !!data.pTax,
          tax_amounts: !!data.tax_amounts,
          includeSignatureLine: !!data.includeSignatureLine,
          invoicePrifix: data.invoicePrifix || "",
        });
      }
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dispatch]);


  // Checkbox handler for option fields
  const handleOptionChange = (field) => {
    setOptionData((prev) => ({
      ...prev,
      [field]: !prev[field],
    }));
  };

  // Input handler for invoicePrifix
  const handlePrefixChange = (e) => {
    setOptionData((prev) => ({
      ...prev,
      invoicePrifix: e.target.value,
    }));
  };

  // Save handler
  const handleSave = async () => {
    setLoading(true);
    try {
      // Save custom invoice
      // let invoiceRes;
      // if (formData.id) {
      //   invoiceRes = await dispatch(createCustomInvoiceData(formData)).unwrap();
      // } else {
      //   invoiceRes = await dispatch(createCustomInvoiceData(formData)).unwrap();
      // }

      // Save custom invoice option
      const optionPayload = {
        ...optionData,
        // templateId: invoiceRes.data?.id || formData.id,
      };
      let optionRes;
      if (optionData.id) {
        optionRes = await dispatch(createCustomInvoiceOptionData(optionPayload)).unwrap();
      } else {
        optionRes = await dispatch(createCustomInvoiceOptionData(optionPayload)).unwrap();
      }

      if (optionRes.status) {
        toast.success("Invoice customized successfully");
        router.refresh();
        router.push(`/profile`);
      } else {
        toast.error("Error customizing invoice");
      }
    } catch (error) {
      toast.error("Error customizing invoice");
    } finally {
      setLoading(false);
    }
  };

  const footerTabs = [
    { title: "Tax Summary", id: 0 },
    { title: "Signature", id: 1 },
  ];

  return (
    <>
      <div className="col-lg-4 fixedHeader">
        <div className="communication-container customise">
          <Pageheader
            label="Customize invoice options"
            handleSave={handleSave}
            loading={loading}
          />
          <Accordion  defaultActiveKey="0" alwaysOpen>
            {/* Header */}
            <Accordion.Item className="templateImageCss " eventKey="0">
              <Accordion.Header>
                <p className="accorheading">Header</p>
              </Accordion.Header>
              <Accordion.Body>
                <Form.Check
                  type="checkbox"
                  label="Shipping Details"
                  checked={optionData.shippingDetails}
                  onChange={() => handleOptionChange("shippingDetails")}
                />
                <Form.Check
                  type="checkbox"
                  label="Due Date"
                  checked={optionData.due_date}
                  onChange={() => handleOptionChange("due_date")}
                />
                <Form.Check
                  type="checkbox"
                  label="Payment Terms"
                  checked={optionData.payment_terms}
                  onChange={() => handleOptionChange("payment_terms")}
                />
              </Accordion.Body>
            </Accordion.Item>

            {/* Table */}
            <Accordion.Item eventKey="1">
              <Accordion.Header>
                <p className="accorheading">Table</p>
              </Accordion.Header>
              <Accordion.Body>
                <Form.Check
                  type="checkbox"
                  label="Item Code"
                  checked={optionData.itemCode}
                  onChange={() => handleOptionChange("itemCode")}
                />
                <Form.Check
                  type="checkbox"
                  label="Quantity and Rate"
                  checked={optionData.quantityAndRate}
                  onChange={() => handleOptionChange("quantityAndRate")}
                />
                <Form.Check
                  type="checkbox"
                  label="P-Tax"
                  checked={optionData.pTax}
                  onChange={() => handleOptionChange("pTax")}
                />
              </Accordion.Body>
            </Accordion.Item>

            {/* Footer */}
            <Accordion.Item eventKey="2">
              <Accordion.Header>
                <p className="accorheading">Footer</p>
              </Accordion.Header>
              <Accordion.Body>
                <div className="footer-tabs-row" style={{ display: "flex", gap: "70px", marginBottom: "16px" }}>
                  {footerTabs.map((tabItem) => (
                    <div
                      key={tabItem.id}
                      style={{
                        cursor: "pointer",
                        padding: "8px 16px",
                        borderRadius: "4px",
                        // background: footerTab === tabItem.id ? "#e0e0e0" : "transparent",
                        color: footerTab === tabItem.id ? "#007bff" : "#333",
                        fontWeight: footerTab === tabItem.id ? "bold" : "normal",
                        borderBottom: footerTab === tabItem.id ? "3px solid #007bff" : "3px solid transparent",
                        transition: "background 0.2s, color 0.2s, border-bottom 0.2s"
                      }}
                      onClick={() => setFooterTab(tabItem.id)}
                    >
                      {tabItem.title}
                    </div>
                  ))}
                </div>
                {footerTab === 0 ? (
                  <Form.Check
                    type="checkbox"
                    label="Tax"
                    checked={optionData.tax_amounts}
                    onChange={() => handleOptionChange("tax_amounts")}
                  />
                ) : (
                  <Form.Check
                    type="checkbox"
                    label="Include Signature Line"
                    checked={optionData.includeSignatureLine}
                    onChange={() => handleOptionChange("includeSignatureLine")}
                  />
                )}
              </Accordion.Body>
            </Accordion.Item>

            {/* Numbering */}
            <Accordion.Item eventKey="3">
              <Accordion.Header>
                <p className="accorheading">Numbering</p>
              </Accordion.Header>
              <Accordion.Body>
                <Form.Label>Invoice Numbers</Form.Label>
                <Form.Group>
                  <Form.Label>Enter a prefix</Form.Label>
                  <Form.Control
                    type="text"
                    value={optionData.invoicePrifix}
                    onChange={handlePrefixChange}
                    placeholder="Add a prefix to invoice numbers (e.g. INV)"
                  />
                </Form.Group>
              </Accordion.Body>
            </Accordion.Item>
          </Accordion>
        </div>
      </div>

      <div className="col-lg-8 billMargin">
        <div className="bill-section-uppersection">

        <div className="bill-section">
          {formData.templateName === "impact" && (
            <CustomInvoiceImpact
              selectedTemp={formData.templateName}
              selectedId={
                formData.logoId
                  ? { id: formData.logoId, logoImage: formData.logoImage }
                  : null
              }
              selectedSize={formData.logoSize}
              alignPos={formData.logoPosition}
              selectedColour={
                formData.colourId
                  ? { id: formData.colourId, colourCode: formData.colourCode }
                  : null
              }
              customColour={formData.customColour}
              selectedHeader={
                formData.headerId
                  ? { id: formData.headerId, headerImg: formData.headerImg }
                  : null
              }
              selectedWatermark={
                formData.waterMarkId
                  ? {
                      id: formData.waterMarkId,
                      waterMarkImg: formData.waterMarkImg,
                    }
                  : null
              }
              customTemplates={customTemplates}
              customOption={optionData}
            />
          )}
          {formData.templateName === "modern" && (
            <CustomInvoiceModern
              selectedTemp={formData.templateName}
              selectedId={
                formData.logoId
                  ? { id: formData.logoId, logoImage: formData.logoImage }
                  : null
              }
              selectedSize={formData.logoSize}
              alignPos={formData.logoPosition}
              selectedColour={
                formData.colourId
                  ? { id: formData.colourId, colourCode: formData.colourCode }
                  : null
              }
              customColour={formData.customColour}
              selectedHeader={
                formData.headerId
                  ? { id: formData.headerId, headerImg: formData.headerImg }
                  : null
              }
              selectedWatermark={
                formData.waterMarkId
                  ? {
                      id: formData.waterMarkId,
                      waterMarkImg: formData.waterMarkImg,
                    }
                  : null
              }
              customOption={optionData}
            />
          )}
          {formData.templateName === "classic" && (
            <CustomInvoiceClassic
              selectedTemp={formData.templateName}
              selectedId={
                formData.logoId
                  ? { id: formData.logoId, logoImage: formData.logoImage }
                  : null
              }
              selectedSize={formData.logoSize}
              alignPos={formData.logoPosition}
              selectedColour={
                formData.colourId
                  ? { id: formData.colourId, colourCode: formData.colourCode }
                  : null
              }
              customColour={formData.customColour}
              selectedHeader={
                formData.headerId
                  ? { id: formData.headerId, headerImg: formData.headerImg }
                  : null
              }
              selectedWatermark={
                formData.waterMarkId
                  ? {
                      id: formData.waterMarkId,
                      waterMarkImg: formData.waterMarkImg,
                    }
                  : null
              }
              customOption={optionData}
            />
          )}
        </div>
      </div>
      </div>

    </>
  );
};

export default CustomiseInvoice;
