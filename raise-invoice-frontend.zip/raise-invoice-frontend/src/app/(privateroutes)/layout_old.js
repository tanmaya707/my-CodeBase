// "use client"
// import { useState, useEffect } from "react";
// import "bootstrap/dist/css/bootstrap.min.css";
// import "../globals.css";
// import DashboardHeader from "../../Components/dashboardheader/dashboardHeader";
// import Sidebar from "../../Components/sidebar/Sidebar";
// import { useRouter } from 'next/navigation';

// export default function privateLayout({ children }) {
//     const router = useRouter();
//     const authToken = (typeof localStorage !== 'undefined') ? localStorage.getItem("web-auth-token") : null;
//     useEffect(() => {
//         if (authToken) {
//             router.push('/dashboard/')
//         } else {
//             router.push('/login');
//         }
//     }, []);

//     const [sidebarOpen, setSideBarOpen] = useState(true);

//     const handleToggle = () => {
//         setSideBarOpen((prev) => !prev)
//     }

//     return (
//         <>
//             <DashboardHeader />

//             {sidebarOpen ? (
//                 <div className="row">
//                     <div className="col-lg-2">
//                         <Sidebar
//                             sidebarOpen={sidebarOpen}
//                             handleToggle={handleToggle}
//                         />
//                     </div>
//                     <div className="col-lg-10 right-panel">
//                         {children}
//                     </div>
//                 </div>
//             ) : (
//                 <div className="row">
//                     <div className="col-lg-1">
//                         <Sidebar
//                             sidebarOpen={sidebarOpen}
//                             handleToggle={handleToggle}
//                         />
//                     </div>
//                     <div className="col-lg-11 right-panel">
//                         {children}
//                     </div>
//                 </div>
//             )}
//         </>
//     )
// }
