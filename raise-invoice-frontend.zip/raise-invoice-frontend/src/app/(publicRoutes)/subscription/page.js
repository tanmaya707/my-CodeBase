"use client";
import React, { useEffect, useState } from "react";
import { IMAGE } from "@/utils/Theme";
import Link from "next/link";
import "./subscription.css";
import Accordion from "react-bootstrap/Accordion";
import Slider from "react-slick";

import Api from "../../../api/api";

const Subscription = () => {
  const [selectedFrequency, setSelectedFrequency] = useState("yearly"); // Default frequency
  const [error, setError] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [planList, setPlanList] = useState(null);
  const [featureCategories, setFeatureCategories] = useState(null);

  useEffect(() => {
    getPlanList();
    getFeatureCategories();
  }, []);

  const getPlanList = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const palnResponse = await Api.POST("get-plan-list", {});
      setPlanList(palnResponse.data.data);
    } catch (err) {
      setError("Failed to fetch plan list.");
    } finally {
      setIsLoading(false);
    }
  };
  const getFeatureCategories = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const featureCategories = await Api.POST("get-features-categories", {});
      setFeatureCategories(featureCategories.data.data);
    } catch (err) {
      setError("Failed to fetch plan list.");
    } finally {
      setIsLoading(false);
    }
  };
  const getPlanPrice = (priceData, frequency = "yearly") => {
    let priceVal = priceData.find(
      (priceDetail) => priceDetail.name === frequency
    );
    let planPrice = priceVal.price ?? 0;
    if (priceVal.discount) {
      planPrice = planPrice - (planPrice * priceVal.discount) / 100;
    }
    return {
      price: priceVal.price ?? 0,
      discount: priceVal.discount ?? 0,
      discountedPrice: planPrice,
    };
  };
  const getFrequencyName = (frequency = "yearly") => {
    let frequencyName = "";
    switch (frequency) {
      case "monthly":
        frequencyName = "Month";
        break;
      case "yearly":
        frequencyName = "Year";
        break;
    }
    return frequencyName;
  };

  const sliderPositionStyle = {
    left: selectedFrequency === "monthly" ? "0" : "72%",
    transform:
      selectedFrequency === "monthly" ? "translateX(0)" : "translateX(-41%)",
    transition: "all 0.3s ease-in-out",
  };

  var settings = {
    dots: false,
    infinite: true,
    speed: 500,
    slidesToShow: 4.3,
    slidesToScroll: 1,
    // centerPadding: '150px',

    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
          infinite: true,
          dots: true,
        },
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1.2,
          slidesToScroll: 1,
          dots: false,
          centerMode: true,
          centerPadding: "10px", // Adjust for smaller
        },
      },
    ],
  };

  return (
    <>
      <div className="Subscription">
        <div className="container">
          <div className="row col-sm-12">
            <h1 className="select">Select Plan</h1>
            <div className="select-plan-all">
              <div className="select-plan">
                <div
                  className={`option ${
                    selectedFrequency === "monthly" ? "active" : ""
                  }`}
                  onClick={() => setSelectedFrequency("monthly")}
                >
                  Monthly
                </div>
                <div className="slider" style={sliderPositionStyle}></div>
                <div
                  className={`option ${
                    selectedFrequency === "yearly" ? "active" : ""
                  }`}
                  onClick={() => setSelectedFrequency("yearly")}
                >
                  Yearly
                </div>
                <div className="slider" style={sliderPositionStyle}></div>
              </div>
            </div>

            <div className="planPricePanel">
              <div className="ppWrap">
                {planList &&
                  planList?.map((plan, i) => (
                    <div
                      className={`ppBox ${
                        i != 0 && i != planList.length - 1 ? "mid-ppbox" : ""
                      }`}
                      key={i}
                    >
                      {plan.is_recommended ? (
                        <img src={IMAGE.sub_img} className="sub-tag" />
                      ) : (
                        ""
                      )}
                      <h2>{plan.name}</h2>
                      <h2 className="rupees">
                        ₹
                        {getPlanPrice(
                          plan.plan_prices,
                          selectedFrequency
                        ).discountedPrice.toFixed(2)}
                      </h2>
                      <p>Per {getFrequencyName(selectedFrequency)}</p>
                      <Link className="subs-btn mb-3" href={{}}>
                        {i == 0 ? `Join Now` : `Start ${plan.name}`}
                      </Link>
                      <div
                        dangerouslySetInnerHTML={{ __html: plan.description }}
                      />
                    </div>
                  ))}
                {/* <div className='ppBox'>
                                    <h2>Starter</h2>
                                    <h2 className="rupees">₹ 5,300</h2>
                                    <p>Per Year</p>
                                    <Link className='subs-btn mb-3' href={{}}>Join Now</Link>
                                    <ul>
                                        <li><img src={IMAGE.black_tick} />30 invoices/year</li>
                                        <li><img src={IMAGE.black_tick} />unlimited quotes</li>
                                        <li><img src={IMAGE.black_tick} />free bank transfers</li>
                                        <li><img src={IMAGE.black_tick} />bank account</li>
                                        <li><img src={IMAGE.black_tick} />client communications</li>
                                        <li><img src={IMAGE.black_tick} />ratings & reviews</li>
                                    </ul>
                                </div>
                                <div className='ppBox mid-ppbox'>
                                    <img src={IMAGE.sub_img} className='sub-tag' />
                                    <h2>Premium</h2>
                                    <h2 className="rupees">$14.00</h2>
                                    <p>Per Year</p>
                                    <Link className='subs-btn mb-3' href={{}}>Start Premium</Link>
                                    <div className='left-sub-arww'>
                                        <h5><img src={IMAGE.left_arw} className='left_arw' /> Everything
                                            included in Starter Plus</h5>
                                    </div>
                                    <ul>
                                        <li><img src={IMAGE.black_tick} />QuickBooks/Xero integration</li>
                                        <li><img src={IMAGE.black_tick} />no advanced reports</li>
                                        <li><img src={IMAGE.black_tick} />marketplace integrations </li>
                                        <li><img src={IMAGE.black_tick} />bank account</li>
                                        <li><img src={IMAGE.black_tick} />recurring invoices</li>
                                        <li><img src={IMAGE.black_tick} />phone support</li>
                                    </ul>
                                </div>
                                <div className='ppBox'>
                                    <h2>Business</h2>
                                    <h2 className="rupees">$19.00</h2>
                                    <p>Per Year</p>
                                    <Link className='subs-btn mb-3' href={{}}>Start Business</Link>
                                    <div className='left-sub-arww'>
                                        <h5><img src={IMAGE.left_arw} className='left_arw' /> Everything included in Premium, plus..</h5>
                                    </div>
                                    <ul>
                                        <li><img src={IMAGE.black_tick} />QuickBooks/Xero integration</li>
                                        <li><img src={IMAGE.black_tick} />no advanced reports</li>
                                        <li><img src={IMAGE.black_tick} />marketplace integrations </li>
                                        <li><img src={IMAGE.black_tick} />recurring invoices</li>
                                        <li><img src={IMAGE.black_tick} />client communications</li>
                                        <li><img src={IMAGE.black_tick} />phone support</li>
                                    </ul>
                                </div> */}
              </div>
            </div>
          </div>

          <div className="faqs only-faq">
            <div className="container">
              <div className="row">
                <div className="col-lg-12 col-md-12 col-12">
                  <h2 className="faqs-title mb-5">Compare Features</h2>

                  <table className="table-here">
                    <thead>
                      <tr>
                        <th></th>
                        {planList &&
                          planList?.map((plan, l) => (
                            <th key={l}>{plan.name}</th>
                          ))}
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td colSpan={4}>
                          <table>
                            <tbody>
                              <tr>
                                <td>
                                  <Accordion defaultActiveKey={0}>
                                    {featureCategories &&
                                      featureCategories?.map(
                                        (featureCategory, k) => (
                                          <Accordion.Item eventKey={k} key={k}>
                                            <Accordion.Header>
                                              {featureCategory.name}
                                            </Accordion.Header>
                                            <Accordion.Body>
                                              <div className="table-responsive">
                                                <table className="table fixed-table">
                                                  <tbody>
                                                    {featureCategory.features &&
                                                      featureCategory.features?.map(
                                                        (feature, index) => (
                                                          <tr key={index}>
                                                            <td scope="row">
                                                              {feature.name}
                                                            </td>
                                                            {feature.plans &&
                                                              feature.plans?.map(
                                                                (data, j) => (
                                                                  <td key={j}>
                                                                    {feature.type ==
                                                                    "text" ? (
                                                                      <p>
                                                                        {data
                                                                          .plan_features
                                                                          .value ? (
                                                                          data
                                                                            .plan_features
                                                                            .value
                                                                        ) : (
                                                                          <span>
                                                                            -
                                                                          </span>
                                                                        )}
                                                                      </p>
                                                                    ) : data
                                                                        .plan_features
                                                                        .value ==
                                                                      "1" ? (
                                                                      <img
                                                                        src={
                                                                          IMAGE.black_tick
                                                                        }
                                                                      />
                                                                    ) : (
                                                                      <span>
                                                                        -
                                                                      </span>
                                                                    )}
                                                                  </td>
                                                                )
                                                              )}
                                                          </tr>
                                                        )
                                                      )}
                                                  </tbody>
                                                </table>
                                              </div>
                                            </Accordion.Body>
                                          </Accordion.Item>
                                        )
                                      )}
                                  </Accordion>
                                </td>
                              </tr>
                              {/* <tr>
                                                                <td >
                                                            <Accordion defaultActiveKey="0">
                                                             
                                                                <Accordion.Item eventKey="1">
                                                                    <Accordion.Header>Invoicing</Accordion.Header>
                                                                    <Accordion.Body>
                                                                        <div className="table-responsive">

                                                                            <table className="table">
                                                                                <tbody>
                                                                                    <tr>
                                                                                        <td scope="row">Invoices</td>
                                                                                        <td>30/year</td>
                                                                                        <td>30/year</td>
                                                                                        <td>30/year</td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td scope="row">Card payment fee</td>
                                                                                        <td>3.5%</td>
                                                                                        <td>3.5%</td>
                                                                                        <td>3.5%</td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td scope="row">Estimates</td>
                                                                                        <td>Unlimited</td>
                                                                                        <td>Unlimited</td>
                                                                                        <td>Unlimited</td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td scope="row">Projects</td>
                                                                                        <td>Unlimited</td>
                                                                                        <td>Unlimited</td>
                                                                                        <td>Unlimited</td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td scope="row">Clients</td>
                                                                                        <td>Unlimited</td>
                                                                                        <td>Unlimited</td>
                                                                                        <td>Unlimited</td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td scope="row">Team Members</td>
                                                                                        <td>Unlimited</td>
                                                                                        <td>Unlimited</td>
                                                                                        <td>Unlimited</td>
                                                                                    </tr>
                                                                                </tbody>
                                                                            </table>
                                                                        </div>

                                                                    </Accordion.Body>
                                                                </Accordion.Item>                                                          
                                                            </Accordion>
                                                            </td>
                                                      

                                                            </tr> */}
                            </tbody>
                          </table>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>

          <div className="make-invoicing">
            <div className="container">
              <h2 className="my-5">Make Invoicing Simple with us</h2>
              <div className="make-invoicing-body">
                <div className="simple-invoice">
                  <h2>01</h2>
                  <h4>Handle all your admin work in minutes</h4>
                  <p>
                    Easy-to-use tools to attach expenses, schedule appointments,
                    and track & bill hours.
                  </p>
                </div>
                <div className="simple-invoice">
                  <h2>02</h2>
                  <h4>See the big picture with business reports</h4>
                  <p>
                    Track how your business is doing and get critical insights
                    with easy-to-use charts and graphs.
                  </p>
                </div>
                <div className="simple-invoice">
                  <h2>03</h2>
                  <h4>Spend less time managing your books</h4>
                  <p>
                    Sync all of your invoicing and payments data to QuickBooks
                    or Xero for your tax preparer.
                  </p>
                </div>
                <div className="simple-invoice">
                  <h2>04</h2>
                  <h4>Take care of business on the spot</h4>
                  <p>
                    With the&nbsp;Invoice2go&nbsp;app (available on the web,
                    iOS, and Android) all of your information is synced&nbsp;
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="testimonials">
        <div className="container">
          <div>
            <h4>What customers say about us </h4>
            <p className="experience">
              We do our best to provide you the best experience ever
            </p>

            <div className="mobile-testi-card">
              <div className="card customer-card">
                <div className="card-body excellence">
                  <h6>Excellent</h6>
                  <img
                    className="stars"
                    src={IMAGE.greenStars}
                    alt="Image broken"
                  />
                  <p>
                    Based on <span>456 reviews</span>
                  </p>
                  <div className="rating">
                    <img src={IMAGE.star} alt="Image broken" />
                    <p>Trustpilot</p>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <Slider {...settings}>
                <div style={{ border: "2px solid black" }}>
                  <div className="card customer-card">
                    <div className="card-body excellence">
                      <h6>Excellent</h6>
                      <img
                        className="stars"
                        src={IMAGE.greenStars}
                        alt="Image broken"
                      />
                      <p>
                        Based on <span>456 reviews</span>
                      </p>
                      <div className="rating">
                        <img src={IMAGE.star} alt="Image broken" />
                        <p>Trustpilot</p>
                      </div>
                    </div>
                  </div>
                </div>
                <div>
                  <div className="card customer-card">
                    <div className="card-body best">
                      <img src={IMAGE.quote} alt="Image broken" />
                      <h6>Best on the market</h6>
                      <div className="rating-time">
                        <img
                          className=""
                          src={IMAGE.greenStars}
                          alt="Image broken"
                        />
                        <p>2 days ago</p>
                      </div>
                      <p className="best-para">
                        I love this product because the support is great. Ple
                        ...
                      </p>
                      <h6 className="traveller">Worldtraveler</h6>
                    </div>
                  </div>
                </div>
                <div>
                  <div className="card customer-card">
                    <div className="card-body best">
                      <img src={IMAGE.quote} alt="Image broken" />
                      <h6>Best on the market</h6>
                      <div className="rating-time">
                        <img
                          className=""
                          src={IMAGE.greenStars}
                          alt="Image broken"
                        />
                        <p>2 days ago</p>
                      </div>
                      <p className="best-para">
                        I love this product because the support is great. Ple
                        ...
                      </p>
                      <h6 className="traveller">Worldtraveler</h6>
                    </div>
                  </div>
                </div>
                <div>
                  <div className="card customer-card">
                    <div className="card-body best">
                      <img src={IMAGE.quote} alt="Image broken" />
                      <h6>Best on the market</h6>
                      <div className="rating-time">
                        <img
                          className=""
                          src={IMAGE.greenStars}
                          alt="Image broken"
                        />
                        <p>2 days ago</p>
                      </div>
                      <p className="best-para">
                        I love this product because the support is great. Ple
                        ...
                      </p>
                      <h6 className="traveller">Worldtraveler</h6>
                    </div>
                  </div>
                </div>
                <div>
                  <div className="card customer-card">
                    <div className="card-body best">
                      <img src={IMAGE.quote} alt="Image broken" />
                      <h6>Best on the market</h6>
                      <div className="rating-time">
                        <img
                          className=""
                          src={IMAGE.greenStars}
                          alt="Image broken"
                        />
                        <p>2 days ago</p>
                      </div>
                      <p className="best-para">
                        I love this product because the support is great. Ple
                        ...
                      </p>
                      <h6 className="traveller">Worldtraveler</h6>
                    </div>
                  </div>
                </div>
              </Slider>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Subscription;
