import React from 'react'
import Link from 'next/link';
import { IMAGE } from '@/utils/Theme';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faArrowRight } from '@fortawesome/free-solid-svg-icons';
import './contact.css'

const ContactUs = () => {
  return (
    <>
        <div className='contact-banner'>
        <div className='contact-banner-sec'>

            <img className="background" src={IMAGE.background} alt='Image broken'/>
            <div className='banner-text'>
                    <h4>Contact Our Team</h4>
                    <p>If you need our help, have questions about how to use the platform or are experiencing 
                        technical difficulties, please do not hesitate to contact us.
                    </p>
                </div>
        </div>

            <div className='container'>
              
                <div className="card">
                    <div className="card-body">
                        <form>
                            <div className="row">
                                <div className="col-lg-6">
                                    <input type="text" className="form-control" placeholder="Name" aria-label="First name"/>
                                </div>
                                <div className="col-lg-6">
                                    <input type="text" className="form-control" placeholder="Email Id" aria-label="Last name"/>
                                </div>
                                <div className="col-lg-6">
                                    <input type="text" className="form-control" placeholder="Company" aria-label="Last name"/>
                                </div>
                                <div className="col-lg-6">
                                    <select id="inputState" className="form-select">
                                        <option defaultValue>Country</option>
                                        <option>...</option>
                                    </select>
                                </div>
                                <div className='col-lg-12'>
                                    <textarea 
                                        className="form-control text-area" 
                                        id="exampleFormControlTextarea1" 
                                        rows="3"
                                        placeholder='Type your message...'
                                    ></textarea>
                                </div>
                            </div>
                            <div className='mb-5'>
                                <p>By submitting this form you agree to our terms and conditions and our Privacy Policy which explains 
                                    how we may collect, use and disclose your personal information including to third parties.
                                </p>
                                <div className='contact-btn'>
                                    <button>Contact us</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div className='container'>
        <div className='contact-footer'>
            
            <div className='contact-footer-div'>
                <img src={IMAGE.icon_email} alt='Image broken'/>
                <h4>Email us</h4>
                <p className="contact-para" >Email us for general queries, including marketing and partnership opportunities.</p>
                <Link className="link-text" href={{}}>hello@helpcenter.com</Link>
            </div>
            <div className='contact-footer-div'>
                <img src={IMAGE.icon_profile} alt='Image broken'/>
                <h4>Support</h4>
                <p className="contact-para">Check out helpful resources, FAQs and developer tools.</p>
                <Link className="support-center" href={{}}>Support Center <FontAwesomeIcon className='right-arrow' icon={faArrowRight} /></Link>
            </div>
        </div>
        </div>

    </>
  )
}

export default ContactUs
