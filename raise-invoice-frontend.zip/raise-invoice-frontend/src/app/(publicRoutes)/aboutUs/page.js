'use client'
import React from 'react';
import { IMAGE } from '../../../utils/Theme';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faFireFlameCurved, faUserCheck, faEnvelope, faFlag,faHeart } from '@fortawesome/free-solid-svg-icons';
import Slider from "react-slick";
import './aboutus.css';
import Link from 'next/link';

const AboutUs = () => {

  var settings = {
    dots: false,
    infinite: true,
    speed: 500,
    slidesToScroll: 1,
    slidesToShow: 2,
    centerMode: true,
    centerPadding: '150px',
    responsive: [
        {
            breakpoint: 1024, // For screens wider than 1024px
            settings: {
                slidesToShow: 2,
                slidesToScroll: 1
            }
        },
        {
            breakpoint: 900, // For tablets and smaller screens
            settings: {
                slidesToShow: 2,
                slidesToScroll: 1,
            centerPadding: '0px',

            }
        },
        {
            breakpoint: 576, // For mobile devices
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1,
            centerPadding: '0px',

            }
        }
    ]

  };

  return (
    <>
      <div className='aboutus-banner'>
      <div className='container'>
      <div className='about-banner-content'>
      
        <img className='background' src={IMAGE.halfCircle} alt='Image broken'/>
        <div className='banner-text'>
          <h1>Our Story</h1>
          <p>Lorem ipsum dolor sit amet consectetur. Vestibulum ornare lacus nisl elementum facilisi vitae. 
            Morbi sagittis sagittis id facilisi sed mauris id facilisi molestie. Porta orci bibendum pellentesque 
            quam augue scelerisque massa in lorem. Lacus est sem ligula feugiat ac orci est.</p>
        </div>
        </div>

      </div>


      <div className='client-uses'>
      <div className="container">

        <img className="people" src={IMAGE.people} alt='Image broken'/>
        <div className='about-bottom'>
            <div className="row">
              <div className="col-lg-3 col-md-6 col-6">
              <div className='white-icon-imgs'>
                <div className='white-icon'><FontAwesomeIcon icon={faFireFlameCurved}/></div>
              <div className='white-icon-cntnt'>
                <h2>225K</h2>
                <p>Small businesses use Raise Invoice to work their way</p>
               </div>
               </div>

              </div>
              <div className="col-lg-3 col-md-6 col-6">
                <div className='white-icon-imgs'>
                  <div className='white-icon'><FontAwesomeIcon icon={faUserCheck} /></div>
                <div className='white-icon-cntnt'>
                  <h2>225K</h2>
                  <p>Small businesses use Raise Invoice to work their way</p>
                </div>
                </div>

              </div>

              <div className="col-lg-3 col-md-6 col-6">
                <div className='white-icon-imgs'>
                
                <div className='white-icon'><FontAwesomeIcon icon={faEnvelope} /></div>
                <div className='white-icon-cntnt'>
                <h2>225K</h2>
                <p>Small businesses use Raise Invoice to work their way</p>
              </div>
              </div>

              </div>

              <div className="col-lg-3 col-md-6 col-6">
              <div className='white-icon-imgs'>
                <div className='white-icon'><FontAwesomeIcon icon={faFlag} /></div>
                <div className='white-icon-cntnt'>
                <h2>225K</h2>
                <p>Small businesses use Raise Invoice to work their way</p>
              </div>
              </div>

              </div>

            </div>
          </div>
        </div>
      </div>
      </div>

      <div className='testimonials'>
      
          <div className='container'>
            <p className='loved'><FontAwesomeIcon icon={faHeart} /> Loved by experts</p>
            <h2>Our Testimonials</h2>
            <p className="paratext">Join us now and see what the hype is all about.</p>

            <div>
              <Slider {...settings}>
                <div>
                  <div className="card-body">

                      <p className="card-text">Cardinal ensures we&apos;re making decisions based on data we
                      can trust and gives stakeholders visibility into results without 
                      constant back and forth among teams. Cardinal solves that
                      for us and provides a central place for our whole company to 
                      see the true impact of our entire product strategy as a whole.
                      </p>
                      <div className='card-footer'>
                          <div className='user-details'>
                              <h4>Christopher Byrum</h4>
                              <p>VP Product</p>
                              <p>Puls</p>
                          </div>
                          <div className="client-img">
                              <img src={IMAGE.profile} alt='Image broken'/>
                          </div>
                      </div>
                  </div>
                </div>
                <div>
                  <div className="card-body">

                      <p className="card-text">Cardinal ensures we&apos;re making decisions based on data we
                      can trust and gives stakeholders visibility into results without 
                      constant back and forth among teams. Cardinal solves that
                      for us and provides a central place for our whole company to 
                      see the true impact of our entire product strategy as a whole.
                      </p>
                      <div className='card-footer'>
                          <div className='user-details'>
                              <h4>Christopher Byrum</h4>
                              <p>VP Product</p>
                              <p>Puls</p>
                          </div>
                          <div className="client-img">
                              <img src={IMAGE.profile} alt='Image broken'/>
                          </div>
                      </div>
                  </div>
                </div>
                <div>
                  <div className="card-body">

                      <p className="card-text">Cardinal ensures we&apos;re making decisions based on data we
                      can trust and gives stakeholders visibility into results without 
                      constant back and forth among teams. Cardinal solves that
                      for us and provides a central place for our whole company to 
                      see the true impact of our entire product strategy as a whole.
                      </p>
                      <div className='card-footer'>
                          <div className='user-details'>
                              <h4>Christopher Byrum</h4>
                              <p>VP Product</p>
                              <p>Puls</p>
                          </div>
                          <div className="client-img">
                              <img src={IMAGE.profile} alt='Image broken'/>
                          </div>
                      </div>
                  </div>
                </div>
                <div>
                  <div className="card-body">

                      <p className="card-text">Cardinal ensures we&apos;re making decisions based on data we
                      can trust and gives stakeholders visibility into results without 
                      constant back and forth among teams. Cardinal solves that
                      for us and provides a central place for our whole company to 
                      see the true impact of our entire product strategy as a whole.
                      </p>
                      <div className='card-footer'>
                          <div className='user-details'>
                              <h4>Christopher Byrum</h4>
                              <p>VP Product</p>
                              <p>Puls</p>
                          </div>
                          <div className="client-img">
                              <img src={IMAGE.profile} alt='Image broken'/>
                          </div>
                      </div>
                  </div>
                </div>
                <div>
                  <div className="card-body">

                      <p className="card-text">Cardinal ensures we&apos;re making decisions based on data we
                      can trust and gives stakeholders visibility into results without 
                      constant back and forth among teams. Cardinal solves that
                      for us and provides a central place for our whole company to 
                      see the true impact of our entire product strategy as a whole.
                      </p>
                      <div className='card-footer'>
                          <div className='user-details'>
                              <h4>Christopher Byrum</h4>
                              <p>VP Product</p>
                              <p>Puls</p>
                          </div>
                          <div className="client-img">
                              <img src={IMAGE.profile} alt='Image broken'/>
                          </div>
                      </div>
                  </div>
                </div>
                <div>
                  <div className="card-body">

                      <p className="card-text">Cardinal ensures we&apos;re making decisions based on data we
                      can trust and gives stakeholders visibility into results without 
                      constant back and forth among teams. Cardinal solves that
                      for us and provides a central place for our whole company to 
                      see the true impact of our entire product strategy as a whole.
                      </p>
                      <div className='card-footer'>
                          <div className='user-details'>
                              <h4>Christopher Byrum</h4>
                              <p>VP Product</p>
                              <p>Puls</p>
                          </div>
                          <div>
                              <img src={IMAGE.profile} alt='Image broken'/>
                          </div>
                      </div>
                  </div>
                </div>
            </Slider>
            </div>
          </div>

      </div>

  
      <div className='ecosystem padding-bottom'>
        <div className="container">
          <div className="row brdr-top align-items-center ">
            <div className="col-lg-6 col-md-6 col-12">
            <div className="building-ecosystem">

              <img className="writing" src={IMAGE.writing} alt='Image broken'/>
              <img className="typing" src={IMAGE.typing} alt='Image broken'/>
            </div>
            </div>

            <div className="col-lg-6 col-md-6 col-12 building-ecosystem-text">
              <h2>Building the Right
              Invoicing Work Ecosystem</h2>
              <p>Lorem ipsum dolor sit amet consectetur. In convallis elementum erat cursus. Pretium 
                dictum velit consectetur velit mauris sapien metus commodo varius. Penatibus sodales in 
                enim massa sit non turpis. Nisl urna amet tincidunt cras. Sit non lectus pellentesque 
                massa aliquet turpis tellus. Facilisis blandit ut donec sed nunc sed eget nec non. 
                Elit et ultricies lorem pharetra a luctus consectetur risus.</p>
            </div>
          </div>
        </div>
      </div>

      <div className='our-values'>
        <div className="container ">
        <div className="value-top-mobile">
          <h2>Our Values</h2>
              <p>Like Steve Jobs quotes, “Design is not just what it looks like and feels like. 
                Design is how it works”. We always try to make a great output by this culture:
              </p>

              </div>
          <div className="row align-items-center flip-column">
            <div className="col-lg-5 col-md-6 col-12">
          <div className="value-top-desktop">
              <h2>Our Values</h2>
              <p>Like Steve Jobs quotes, “Design is not just what it looks like and feels like. 
                Design is how it works”. We always try to make a great output by this culture:
              </p>
              </div>
              <ul>
                <li><img src={IMAGE.tick} alt="" />Fast Delivery</li>
                <li><img src={IMAGE.tick} alt="" />Hungry for Explorations</li>
                <li><img src={IMAGE.tick} alt="" />Teamwork Always</li>
                <li><img src={IMAGE.tick} alt="" />Communication is the Key</li>
                <li><img src={IMAGE.tick} alt="" />Weekly Evaluation</li>
                <li><img src={IMAGE.tick} alt="" />Update for th Trend</li>
              </ul>
            </div>
            <div className="col-lg-7 col-md-6 col-12 ">
              <img className="puzzle" src={IMAGE.puzzle} alt='Image broken'/>
            </div>
          </div>
        </div>
      </div>

      <div className='future-work mbl-view my-5'>
        <div className="container">
          <div className="row align-items-center flip-column">
            <div className="col-lg-5 col-md-5 col-12">
              <img className="business-woman" src={IMAGE.business_woman} alt='Image broken'/>
            </div>
            <div className="col-lg-7 col-md-5 col-12 building-ecosystem-text left-align-text p-0">
              <h2>The future of work</h2>
              <p className='future-text'>What is the future of work? To find out, look no further than your own home. 
                Connect with colleagues from across the globe while doing work that matters.
              </p>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

export default AboutUs
