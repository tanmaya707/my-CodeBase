import Api from "../../../dependencies/utils/Api";
import axios from "axios";

export const AdvisorLoginService = {
advisorProfile() {
    return Api.GET('https://jsonplaceholder.typicode.com/todos/1').then((response) => {
        const { data, status} = response
        if(status === 200) {
            return {data, status}
        }else {
            const {data: {message} = {}} = response
            return {message, status}
        }
    })
}
}