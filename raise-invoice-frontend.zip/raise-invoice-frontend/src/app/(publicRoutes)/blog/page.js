import React from 'react';
import './blog.css'

const Blog = () => {

    return (
        <div>
            <div className='blog-banner'>
                <h1>Blog</h1>
                <h2>Our Blogs & Highlight</h2>
            </div>

            <div className='blog-content'>
                <div className='container'>

                    <div className='row '>
                        <div className='col-lg-6 col-sm-12'>
                            <div className='blog-big-card'>
                                <div className='blog-big-card-img'>
                                </div>
                                <div className='blog-big-card-btm'>

                                    <h5>Invoice</h5>
                                    <h6>Quis platea lacus condimentum orci sollicitudin. Suspendisse
                                        vitae lacus sed leo sem sit mattis nibh. Urna semper id proin
                                        mollis praesent.</h6>

                                    <p>Odio porttitor sit magna scelerisque vestibulum tristique ut arcu.
                                        Quam id viverra convallis scelerisque id. Et fermentum adipiscing
                                        aenean tempus egestas lectus gravida turpis rutrum. Morbi tempus ut
                                        eu viverra senectus.</p>

                                    <div className='blog-big-card-para'>
                                        <span>Cameron Williamson</span>
                                        <span>8 min read</span>
                                    </div>

                                </div>
                            </div>



                        </div>
                        <div className='col-lg-6 col-sm-12 last-order order-3'>
                            <div className='general-card'>
                                <div className='general-card-left'>
                                    <div className='blog-big-card-img'>
                                    </div>
                                </div>
                                
                                <div className='general-card-right '>
                                    <h5>General</h5>
                                    <h6>Arcu morbi pretium malesuada ultrices sed. Interdum felis
                                        eros tortor lacus porta nascetur nec nec suscipit. Nulla
                                        placerat felis nisi tristique purus tellus risus libero volutpat.</h6>

                                    <div className='blog-big-card-para'>
                                        <span>Jenny Wilson</span>
                                        <span>4 min read</span>
                                    </div>
                                </div>

                            </div>
                            <div className='general-card'>
                                <div className='general-card-left'>
                                    <div className='blog-big-card-img'>
                                    </div>
                                </div>
                                <div className='general-card-right'>
                                    <h5>Accounts</h5>
                                    <h6>Arcu morbi pretium malesuada ultrices sed. Interdum felis
                                        eros tortor lacus porta nascetur nec nec suscipit. Nulla
                                        placerat felis nisi tristique purus tellus risus libero volutpat.</h6>

                                    <div className='blog-big-card-para'>
                                        <span>Savannah Nguyen</span>
                                        <span>2 min read</span>
                                    </div>
                                </div>

                            </div>
                            <div className='general-card'>
                                <div className='general-card-left'>
                                    <div className='blog-big-card-img'>
                                    </div>
                                </div>
                                <div className='general-card-right'>
                                    <h5>Payment</h5>
                                    <h6>Arcu morbi pretium malesuada ultrices sed. Interdum felis
                                        eros tortor lacus porta nascetur nec nec suscipit. Nulla
                                        placerat felis nisi tristique purus tellus risus libero volutpat.</h6>

                                    <div className='blog-big-card-para'>
                                        <span>Savannah Nguyen</span>
                                        <span>2 min read</span>
                                    </div>
                                </div>

                            </div>
                        </div>

                        <div className='col-lg-12 col-sm-12  '>
                            <div className='row'>
                                <div className='col-lg-6'>
                                    <div className='blog-content content-btm'>
                                        <h5>Latest Articles</h5>
                                        <p>Amet quam tellus tempor mauris tristique et volutpat egestas tellus.
                                            Dictum tellus eget in diam eu vulputate massa nulla.</p>

                                    </div>
                                </div>

                            </div>

                            <div className='row'>
                                <div className='col-lg-4 col-md-6 col-12'>
                                    <div className='blog-big-card latest-card'>
                                        <div className='blog-big-card-img'>
                                        </div>
                                        <div className='bigcard-btm para-none'>

                                        <h5>Invoice</h5>
                                        <h6>Quis platea lacus condimentum orci sollicitudin. Suspendisse
                                            vitae lacus sed leo sem sit mattis nibh. Urna semper id proin
                                            mollis praesent.</h6>

                                        <p>Scelerisque et velit id dictumst ultricies convallis magna odio
                                            eget. Aliquam augue risus cras nulla massa.</p>

                                        <div className='blog-big-card-para'>
                                            <span>Savannah Nguyen</span>
                                            <span>8 min read</span>
                                        </div>
                                        </div>


                                    </div>
                                </div>
                                <div className='col-lg-4 col-md-6 col-12'>
                                    <div className='blog-big-card latest-card '>
                                        <div className='blog-big-card-img'>
                                        </div>
                                        <div className='bigcard-btm para-none'>

                                        <h5>Invoice</h5>
                                        <h6>Quis platea lacus condimentum orci sollicitudin. Suspendisse
                                            vitae lacus sed leo sem sit mattis nibh. Urna semper id proin
                                            mollis praesent.</h6>

                                        <p>Scelerisque et velit id dictumst ultricies convallis magna odio
                                            eget. Aliquam augue risus cras nulla massa.</p>

                                        <div className='blog-big-card-para'>
                                            <span>Savannah Nguyen</span>
                                            <span>8 min read</span>
                                        </div>
                                        </div>

                                    </div>
                                </div>
                                <div className='col-lg-4 col-md-6 col-12'>
                                    <div className='blog-big-card latest-card para-none'>
                                        <div className='blog-big-card-img'>
                                        </div>
                                        <div className='bigcard-btm para-none'>

                                        <h5>Invoice</h5>
                                        <h6>Quis platea lacus condimentum orci sollicitudin. Suspendisse
                                            vitae lacus sed leo sem sit mattis nibh. Urna semper id proin
                                            mollis praesent.</h6>

                                        <p>Scelerisque et velit id dictumst ultricies convallis magna odio
                                            eget. Aliquam augue risus cras nulla massa.</p>

                                        <div className='blog-big-card-para'>
                                            <span>Savannah Nguyen</span>
                                            <span>8 min read</span>
                                        </div>
                                        </div>


                                    </div>
                                </div>
                                <div className='col-lg-4 col-md-6 col-12'>
                                    <div className='blog-big-card latest-card'>
                                        <div className='blog-big-card-img'>
                                        </div>
                                        <div className='bigcard-btm para-none'>

                                        <h5>Invoice</h5>
                                        <h6>Quis platea lacus condimentum orci sollicitudin. Suspendisse
                                            vitae lacus sed leo sem sit mattis nibh. Urna semper id proin
                                            mollis praesent.</h6>

                                        <p>Scelerisque et velit id dictumst ultricies convallis magna odio
                                            eget. Aliquam augue risus cras nulla massa.</p>

                                        <div className='blog-big-card-para'>
                                            <span>Savannah Nguyen</span>
                                            <span>8 min read</span>
                                        </div>
                                        </div>

                                    </div>
                                </div>
                                <div className='col-lg-4 col-md-6 col-12'>
                                    <div className='blog-big-card latest-card'>
                                        <div className='blog-big-card-img'>
                                        </div>
                                        <div className='bigcard-btm para-none'>

                                        <h5>Invoice</h5>
                                        <h6>Quis platea lacus condimentum orci sollicitudin. Suspendisse
                                            vitae lacus sed leo sem sit mattis nibh. Urna semper id proin
                                            mollis praesent.</h6>

                                        <p>Scelerisque et velit id dictumst ultricies convallis magna odio
                                            eget. Aliquam augue risus cras nulla massa.</p>

                                        <div className='blog-big-card-para'>
                                            <span>Savannah Nguyen</span>
                                            <span>8 min read</span>
                                        </div>
                                        </div>


                                    </div>
                                </div>
                                <div className='col-lg-4 col-md-6 col-12'>
                                    <div className='blog-big-card latest-card'>
                                        <div className='blog-big-card-img'>
                                        </div>
                                        <div className='bigcard-btm para-none'>

                                        <h5>Invoice</h5>
                                        <h6>Quis platea lacus condimentum orci sollicitudin. Suspendisse
                                            vitae lacus sed leo sem sit mattis nibh. Urna semper id proin
                                            mollis praesent.</h6>

                                        <p>Scelerisque et velit id dictumst ultricies convallis magna odio
                                            eget. Aliquam augue risus cras nulla massa.</p>

                                        <div className='blog-big-card-para'>
                                            <span>Savannah Nguyen</span>
                                            <span>8 min read</span>
                                        </div>
                                        </div>


                                    </div>
                                </div>
                                <div className='col-lg-4 col-md-6 col-12'>
                                    <div className='blog-big-card latest-card'>
                                        <div className='blog-big-card-img'>
                                        </div>
                                        <div className='bigcard-btm para-none'>

                                        <h5>Invoice</h5>
                                        <h6>Quis platea lacus condimentum orci sollicitudin. Suspendisse
                                            vitae lacus sed leo sem sit mattis nibh. Urna semper id proin
                                            mollis praesent.</h6>

                                        <p>Scelerisque et velit id dictumst ultricies convallis magna odio
                                            eget. Aliquam augue risus cras nulla massa.</p>

                                        <div className='blog-big-card-para'>
                                            <span>Savannah Nguyen</span>
                                            <span>8 min read</span>
                                        </div>
                                        </div>

                                    </div>
                                </div>
                                <div className='col-lg-4 col-md-6 col-12'>
                                    <div className='blog-big-card latest-card'>
                                        <div className='blog-big-card-img'>
                                        </div>
                                        <div className='bigcard-btm para-none'>

                                        <h5>Invoice</h5>
                                        <h6>Quis platea lacus condimentum orci sollicitudin. Suspendisse
                                            vitae lacus sed leo sem sit mattis nibh. Urna semper id proin
                                            mollis praesent.</h6>

                                        <p>Scelerisque et velit id dictumst ultricies convallis magna odio
                                            eget. Aliquam augue risus cras nulla massa.</p>

                                        <div className='blog-big-card-para'>
                                            <span>Savannah Nguyen</span>
                                            <span>8 min read</span>
                                        </div>

                                    </div>
                                    </div>

                                </div>
                                <div className='col-lg-4 col-md-6 col-12'>
                                    <div className='blog-big-card latest-card'>
                                        <div className='blog-big-card-img'>
                                        </div>
                                        <div className='bigcard-btm para-none'>

                                        <h5>Invoice</h5>
                                        <h6>Quis platea lacus condimentum orci sollicitudin. Suspendisse
                                            vitae lacus sed leo sem sit mattis nibh. Urna semper id proin
                                            mollis praesent.</h6>

                                        <p>Scelerisque et velit id dictumst ultricies convallis magna odio
                                            eget. Aliquam augue risus cras nulla massa.</p>

                                        <div className='blog-big-card-para'>
                                            <span>Savannah Nguyen</span>
                                            <span>8 min read</span>
                                        </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>





                    <div className='showmore'>
                        {/* <a href="/blogDetails">show more</a> */}
                        <a href="#">show more</a>

                    </div>


                </div>


            </div>



        </div>
    );
}

export default Blog;
