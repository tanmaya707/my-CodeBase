"use client"
import React, { useEffect, useState } from 'react'
import './careers.css';
import Link from 'next/link';
import Modal from 'react-bootstrap/Modal';
import { IMAGE } from '@/utils/Theme';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faMagnifyingGlass } from '@fortawesome/free-solid-svg-icons';
import { useDispatch } from 'react-redux';
// import { postCarrerHero, postCarrerList, postCarrerListDetails } from '@/redux/slices/authSlice';

import Api from "../../../api/api";

const Careers = () => {

    const [show, setShow] = useState(false);
    const [data, setData] = useState([]);
    const [data2, setData2] = useState([]);
    const [data3, setData3] = useState([]);
    const [searchTerm, setSearchTerm] = useState("");
    const [selectedJobUuid, setSelectedJobUuid] = useState(null);
    const dispatch = useDispatch();

    const [error, setError] = useState(null);
    const [isLoading, setIsLoading] = useState(false);
    const [jobCategories, setJobCategories] = useState([]);
    const [jobList, setJobList] = useState([]);
    const [selectedCategoryUuid, setSelectedCategoryUuid] = useState("");
    const [searchText, setSearchText] = useState('');
    const [jobDetails, setJobDetails] = useState(null);

    useEffect(() => {
        getJobCategories();
        getJobList();
    }, []);

    const getJobCategories = async (searchText = '') => {
        setIsLoading(true);
        setError(null);
        try {
            const jobCategoryResponse = await Api.POST('get-job-categories', {searchText: searchText});
            setJobCategories(jobCategoryResponse.data.data);
        } catch (err) {
            setError("Failed to fetch job Category list.");
        } finally {
            setIsLoading(false);
        }
    };
    const getJobList = async (searchText = '', categoryUuid = '') => {
        setIsLoading(true);
        setError(null);
        try {            
            const jobResponse = await Api.POST('get-job-list', {searchText, categoryUuid});
            setJobList(jobResponse.data.data);
        } catch (err) {
            setError("Failed to fetch job list.");
        } finally {
            setIsLoading(false);
        }
    };

    const handleCategoryClick = (categoryUuid) => {
        setSelectedCategoryUuid(categoryUuid);
        getJobList(searchText, categoryUuid);
    };

    const handleClose = () => setShow(false);
    const handleShow = async (uuid) => {
        setIsLoading(true);
        setError(null);
        try {            
            const jobDetailsResponse = await Api.POST('get-job-details', {uuid});
            setJobDetails(jobDetailsResponse.data.data);
            setShow(true)
        } catch (err) {
            setError("Failed to fetch job list.");
        } finally {
            setIsLoading(false);
        }        
    };

    const handleSearchChange = (e) => {
        setSearchText(e.target.value);
        getJobList(e.target.value, selectedCategoryUuid);
    };
    const filteredJobs = data2.filter(job => {
        const matchesSearchTerm = job.title.toLowerCase().includes(searchTerm) || 
                                  job.categories.some(cat => cat.name.toLowerCase().includes(searchTerm));
        const matchesCategory = selectedCategoryUuid === '' || 
                                job.categories.some(cat => cat.name.toLowerCase() === selectedCategoryUuid.toLowerCase());
        return matchesSearchTerm && matchesCategory;
    });
    

    const handleKnowMore = async (uuid) => {
        setSelectedJobUuid(uuid);
        try {
            const response = await dispatch(postCarrerListDetails({ uuid }));
            if (response.payload) {
                setJobDetails(response.payload.data); // Store the response in state
                handleShow(); // Show the modal
            }
        } catch (error) {
            console.error('Error fetching job details:', error);
        }
    };

    const handleAllClick = () => {
        setSelectedCategoryUuid(''); 
    };

    return (
        <>
            <div className='career-banner'>
                <div className='container'>
                    <div className='banner-text'>
                        <div>
                            <h6>Careers</h6>
                            <h3>Join Our Team and Shape the Future</h3>
                        </div>
                        <p>If you&apos;re passionate about driving change, pushing boundaries, and making an impact, we want to hear from you</p>
                    </div>
                </div>
            </div>

            <div className='container job cards'>
                <div className='openings'>
                    <div className="row">
                        <div className="col-lg-7">
                            <h2>Current Openings</h2>
                        </div>
                        <div className="col-lg-5">
                            <p>Can&apos;t find no suitable careers? drop us a line career.raiseinvoice.com</p>
                        </div>
                    </div>
                </div>
                <div className='navigation'>
                    {/* <ul className='nav-tabs'>
                        <li><button onClick={handleAllClick}>All</button></li>
                        {data.map((item) => (
                            <li key={item.id}>
                                <button onClick={() => handleCategoryClick(item.name)}>{item.name}</button>
                            </li>
                        ))}

                    </ul> */}
                    <ul className='nav-tabs'>
                        <li><button onClick={() => handleCategoryClick("")} className={`${selectedCategoryUuid === "" ? "active" : ""}`}>All</button></li>
                        {jobCategories && jobCategories.map((jobCategory, k) => (
                            <li key={k}>
                                <button onClick={() => handleCategoryClick(jobCategory.uuid)} className={`${selectedCategoryUuid === jobCategory.uuid ? "active" : ""}`}>{jobCategory.name}</button>
                            </li>
                        ))}
                    </ul>
                    <div className="search-container">
                        <button className="search-button">
                            <FontAwesomeIcon className="search-icon" icon={faMagnifyingGlass} />
                        </button>
                        <input type="text" placeholder="Search Career..." value={searchText}
                            onChange={handleSearchChange} className="search-input" />
                    </div>

                   
                </div>
               
                    {/* {filteredJobs.map((job) => (
                        <div className="col-lg-4" key={job.id}>
                            <div className="card">
                                <div className="card-body">
                                    <h5 className="card-title">
                                        {job.title} <span className="imp">{job.categories.map(cat => cat.name).join(', ')}</span>
                                    </h5>
                                    <h6 className="card-subtitle my-2 text-muted">
                                        <ul>
                                            <li>{job.is_remote === 1 ? 'Remote' : 'On-site'}</li>
                                            <li></li>
                                            <li>{job.language}</li>
                                            <li></li>
                                            <li>{job.categories.map(cat => cat.name).join(', ')}</li>
                                        </ul>
                                    </h6>
                                    <div className='footer'>
                                        <span>{job.experience}+ Years Experience</span>
                                        <button className="know" onClick={() => handleKnowMore(job.uuid)}>Know More</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    ))} */}

            <div className="row cards-all mb-5">
                {(jobList && jobList.length) ? jobList.map((job, i) => (
                    <div className="col-lg-4" key={i}>
                        <div className="card">
                            <div className="card-body">
                                <h5 className="card-title"><span className='jobTitle'>{job.title}</span>  {job.categories && job.categories.find(function(item) { return item.name == "Urgently Needed"; }) ? <span className="imp">Urgently Needed</span> : ''}</h5>                                
                                <h6 className="card-subtitle my-2 text-muted">
                                    <ul>
                                        {job.is_remote ? <li>Remote</li> : ''}
                                        {job.language ? <li>{job.language}</li> : ''}
                                        {job.categories && job.categories.map((category, j) => (
                                            (category.name != 'Urgently Needed') ? <li key={j}>{category.name}</li> : ''
                                        ))}
                                    </ul>
                                </h6>
                                <div className='footer'>
                                    <span>{job.experience}+ Years Experience</span>
                                    <button className="know" onClick={() => handleShow(job.uuid)}>Know More</button>
                                </div>
                            </div>
                        </div>
                    </div>
                ))
                : <p>No jobs are available.</p>
                }
                {/* <div className="col-lg-4">
                    <div className="card">
                        <div className="card-body">
                            <h5 className="card-title">UI/UX Designer <span className="imp">Urgently Needed</span></h5>
                            
                            <h6 className="card-subtitle my-2 text-muted">
                                <ul>
                                    <li>Remote</li>
                                    <li>English</li>
                                    <li>Senior</li>
                                </ul>
                            </h6>
                            <div className='footer'>
                                <span>2+ Years Experience</span>
                                <button className="know" onClick={handleShow}>Know More</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="col-lg-4">
                    <div className="card">
                        <div className="card-body">
                            <h5 className="card-title">Project Manager</h5>
                            <h6 className="card-subtitle my-2 text-muted">
                                <ul>
                                    <li>Remote</li>
                                    <li>English</li>
                                    <li>Senior</li>
                                </ul>
                            </h6>
                            <div className='footer'>
                                <span>2+ Years Experience</span>
                                <button className="know" onClick={handleShow}>Know More</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="col-lg-4">
                    <div className="card">
                        <div className="card-body">
                            <h5 className="card-title">AI Specialist </h5>
                            <h6 className="card-subtitle my-2 text-muted">
                                <ul>
                                    <li>Remote</li>
                                    <li>English</li>
                                    <li>Senior</li>
                                </ul>
                            </h6>
                            <div className='footer'>
                                <span>2+ Years Experience</span>
                                <button className="know" onClick={handleShow}>Know More</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="col-lg-4">
                    <div className="card">
                        <div className="card-body">
                            <h5 className="card-title">Customer Support</h5>
                            <h6 className="card-subtitle my-2 text-muted">
                                <ul>
                                    <li>Remote</li>
                                    <li>English</li>
                                    <li>Senior</li>
                                </ul>
                            </h6>
                            <div className='footer'>
                                <span>2+ Years Experience</span>
                                <button className="know" onClick={handleShow}>Know More</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="col-lg-4">
                    <div className="card">
                        <div className="card-body">
                            <h5 className="card-title">UI/UX Designer</h5>
                            <h6 className="card-subtitle my-2 text-muted">
                                <ul>
                                    <li>Remote</li>
                                    <li>English</li>
                                    <li>Senior</li>
                                </ul>
                            </h6>
                            <div className='footer'>
                                <span>2+ Years Experience</span>
                                <button className="know" onClick={handleShow}>Know More</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="col-lg-4">
                    <div className="card">
                        <div className="card-body">
                            <h5 className="card-title">Programmer</h5>
                            <h6 className="card-subtitle my-2 text-muted">
                                <ul>
                                    <li>Remote</li>
                                    <li>English</li>
                                    <li>Senior</li>
                                </ul>
                            </h6>
                            <div className='footer'>
                                <span>2+ Years Experience</span>
                                <button className="know" onClick={handleShow}>Know More</button>
                            </div>
                        </div>
                    </div>
                </div> */}
            </div>

        </div>

        <Modal show={show} centered onHide={handleClose} animation={false}>
            <Modal.Header closeButton>
                <Modal.Title>{jobDetails?.title}</Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <h6 className="card-subtitle my-2 text-muted">
                    <ul>
                        {jobDetails?.is_remote ? <li>Remote</li> : ''}
                        {jobDetails?.language ? <li>{jobDetails?.language}</li> : ''}
                        {jobDetails?.categories && jobDetails?.categories.map((jobCategory, j) => (
                            <li key={j}>{jobCategory.name}</li>
                        ))}
                    </ul>
                </h6>
                <div className='footer'>
                    <span>{jobDetails?.experience}+ Years Experience</span>
                </div>
                <div className='JD'>
                    <h4>Key Responsibilities</h4>
                    <div dangerouslySetInnerHTML={{__html:jobDetails?.key_responsibilities}} />
                    <h4>Technology Stack: </h4>
                    <div dangerouslySetInnerHTML={{__html:jobDetails?.technology_stack}} />
                </div>
                <div className='modl-btn'>
                    <Link className='ContactUs-btn' href={{}}>Contact Us<img className='bluearrow' src={IMAGE.blue_arrow}/></Link>
                    <Link className='ContactUs-btn linkedin-btn' href={{}}><img  src={IMAGE.linkedin_img}/>Apply with LinkedIn</Link>
                    {/* <Link className='ContactUs-btn linkedin-btn' href={{}}>Linked In</Link> */}

                </div>


            </Modal.Body>
        </Modal>
            {/* {jobDetails && (
                <Modal show={show} centered onHide={handleClose} >
                    <Modal.Header closeButton>
                        <Modal.Title>{jobDetails.title}</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        <h6 className="card-subtitle my-2 text-muted">
                            <ul>
                                <li>{jobDetails.is_remote === 1 ? 'Remote' : 'On-site'}</li>
                                <li>{jobDetails.language}</li>
                                <li>{jobDetails.categories.map(cat => cat.name).join(', ')}</li>
                            </ul>
                        </h6>
                        <div className='footer'>
                            <span>{jobDetails.experience}+ Years Experience</span>
                        </div>
                        <div className='JD'>
                            <h4>Key Responsibilities</h4>
                            <p>{jobDetails.key_responsibilities}</p>
                            <h4>Technology Stack: </h4>
                            <p>{jobDetails.technology_stack}</p>
                        </div>
                        <div className='mb-5'>
                            <Link className='ContactUs-btn' href={{}}>Contact Us<img className='bluearrow' src={IMAGE.blue_arrow} alt='Image broken'/></Link>
                            <Link href={{}}><img className="linkedin-btn" src={IMAGE.linkedin} alt='Image broken' /></Link>
                        </div>
                    </Modal.Body>
                </Modal>
            )} */}
        </>
    )
}

export default Careers
