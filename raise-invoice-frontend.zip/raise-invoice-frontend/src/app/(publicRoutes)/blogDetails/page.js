import React from 'react'
import '../blog/blog.css'

function blogDetails() {
  return (
    <div>


      <div className='blog-content blogdetails-content'>
        <div className='container'>

          <div className='row '>
            <div className='col-lg-8 col-sm-12'>
              <div className='blog-big-card'>

                <div className='blog-big-card-btm'>

                  <h5>Invoice</h5>
                  <h6>Quis platea lacus condimentum orci sollicitudin. Suspendisse vitae lacus sed leo sem sit mattis</h6>
                </div>
                <div className='blog-big-card-img'>
                </div>


                <div className='blog-big-card-para'>
                  <span>Cameron Williamson</span>
                  <span>8 min read</span>
                </div>



                <div className='blogdetails-para'>
                  <p>Lorem ipsum dolor sit amet consectetur. Vitae suspendisse pellentesque nisi 
                  fames fermentum sit id elementum. Consequat lectus rhoncus euismod quis congue 
                  sed metus tellus ullamcorper. Dignissim cursus adipiscing orci sed risus porttitor 
                  ornare vel. Eu lobortis pulvinar pharetra nec cursus porttitor in consectetur. 
                  Imperdiet vitae cum ultrices tristique aliquam. Vestibulum pharetra sed nunc id 
                  cursus metus. Ornare tempor in phasellus vitae netus blandit mauris ipsum. 
                  Ultrices egestas tempus elementum elementum sed nunc faucibus iaculis metus. 
                  Diam enim sit tellus convallis vel magna tortor arcu. In pellentesque 
                  praesent amet nisl. Amet ut elementum lobortis justo. Erat posuere pharetra 
                  nibh amet. Natoque aliquam consectetur consectetur quam sed semper. Eget 
                  quis eget scelerisque lacus. Laoreet massa nibh nulla pretium. Ut quam 
                  blandit quis nisl nisl turpis. Elit feugiat neque nibh pretium amet egestas et 
                  fermentum eu. Adipiscing vitae adipiscing lectus enim nullam tempus nec. Senectus 
                  phasellus tristique facilisis quis scelerisque imperdiet. A amet commodo nulla elit 
                  tortor. Commodo interdum ac nisl cras vitae. Odio venenatis proin cursus fringilla 
                  molestie in pulvinar ac. Vitae aliquam neque lacus lectus. Turpis lectus sed etiam 
                  justo lectus mi pharetra. Risus placerat non eu morbi tristique. Viverra amet duis 
                  sodales amet amet amet senectus. Aliquam hac egestas arcu eget malesuada nunc 
                  consectetur justo. Sagittis imperdiet pretium quis duis. Netus phasellus fames 
                  et id nisl et sed bibendum morbi. Elementum id in sed nec sagittis cursus enim 
                  suspendisse rutrum. Pellentesque dictum platea vestibulum pulvinar eu aliquet 
                  nulla. Ornare lectus montes lectus malesuada in tempor neque. Iaculis dolor semper 
                  facilisis sed tellus diam sed dolor. Porttitor consectetur turpis enim montes 
                  molestie proin curabitur. Tempus velit rhoncus sit risus. Habitasse semper condimentum 
                  volutpat enim sem in. Arcu urna egestas sed velit urna. Faucibus placerat 
                  faucibus non leo purus justo faucibus. Vel eu morbi faucibus ullamcorper. Tortor 
                  gravida sed nec rhoncus at tempor volutpat. Fames nullam mauris quisque adipiscing. 
                  Tortor enim libero commodo tellus. Id quis in magnis leo nibh. Interdum justo justo 
                  maecenas mauris et elementum etiam. Id enim quam semper pellentesque nunc velit sed. 
                  In viverra enim ac tortor felis eleifend sagittis mauris urna. Molestie integer ornare 
                  dignissim volutpat non et felis egestas. Magna sit tincidunt aliquam pellentesque 
                  ipsum morbi nullam ut tincidunt. Nullam quisque pellentesque vel ultricies id rhoncus 
                  feugiat mauris. Egestas integer sagittis velit morbi fermentum. Morbi vel in fermentum 
                  tincidunt id pellentesque ut nisi tincidunt. Pulvinar porta sed sagittis varius 
                  adipiscing elementum laoreet. Sed commodo tristique volutpat amet faucibus vestibulum. 
                  Est maecenas sodales lectus volutpat dolor. Enim viverra lectus mauris at volutpat
                   porttitor. Vehicula tortor enim sed velit consequat vel purus cras tincidunt. Enim 
                   sapien aliquam nibh nunc ultrices purus. At vestibulum ullamcorper condimentum massa 
                   id rhoncus. Blandit in amet at blandit erat malesuada. Rhoncus quam rhoncus faucibus 
                   tristique volutpat id sit tincidunt. Elit praesent facilisis nisl urna tellus congue. 
                   Justo nisl tortor eleifend porttitor senectus tellus consectetur lobortis. Dictum dui 
                   cursus risus quam. Egestas ullamcorper non morbi gravida tortor leo. Nullam mattis nisi
                    facilisis eget felis amet. Pulvinar amet nunc ipsum neque eget proin maecenas. Nulla 
                    dignissim in eget egestas gravida eleifend nisi consectetur sit. Praesent mi imperdiet 
                    amet ac cras. Ultrices ultricies vitae id proin faucibus scelerisque viverra morbi 
                    sit. Fermentum dictum nulla auctor lacus enim in. Quisque mattis est leo cras nunc. 
                    Tempus tempus a donec eget ut eu lacus et morbi. Sagittis quisque neque pellentesque 
                    ac mauris. Aliquam cras libero eleifend ac ultrices faucibus non. Augue est urna id 
                    facilisis nunc. Mauris ullamcorper risus proin tristique phasellus. Aliquam et et in 
                    massa phasellus ullamcorper sed a id. Dictum non aliquam pellentesque ut facilisi 
                    adipiscing nulla. Lorem mattis vitae mollis vel. Quam sed enim cras nisl metus 
                    fermentum massa vestibulum tortor. Placerat arcu a sodales euismod justo in mattis 
                    mauris. Volutpat urna in netus mauris ipsum eget elementum convallis. Mattis cras 
                    eget ut ut ut dignissim vel euismod. Elementum dolor auctor eget tincidunt cursus 
                    maecenas semper tristique turpis. Sit et aliquet enim ullamcorper malesuada in. Id 
                    arcu est ultricies nunc vel sed dictum habitasse. Sed velit in aliquet cras sed 
                    imperdiet. Velit aliquet turpis vestibulum nibh ullamcorper. Adipiscing et tellus 
                    fames elit auctor nulla congue id commodo. Nisl volutpat risus ante dis vitae vel 
                    sed. Quam aliquam eleifend tincidunt felis auctor dictumst purus. Ac massa integer 
                    sed vitae maecenas feugiat lobortis. Amet tortor adipiscing aenean pharetra 
                    ultricies ipsum. Morbi pellentesque nisi mollis nisi vitae convallis diam quis. 
                    In diam ipsum a id pretium sed. Luctus a ornare ac ut hendrerit a duis diam. Nisi 
                    purus scelerisque diam dolor netus. Dis dictum senectus volutpat pellentesque duis 
                    neque a nisl odio. Maecenas aenean tortor laoreet nibh ac tortor. Est scelerisque 
                    aliquam vestibulum adipiscing massa. Leo felis tincidunt viverra at adipiscing non 
                    tortor ut sed.</p>
                </div>

              </div>



            </div>
            <div className='col-lg-4 col-sm-12 '>
              <div className='related-articles'>
                <h3>Related Articles</h3>
              </div>
              <div className='general-card'>
                <div className='general-card-left'>
                  <div className='blog-big-card-img'>
                  </div>
                </div>
                <div className='general-card-right'>
                  <h5>General</h5>
                  <h6>Arcu morbi pretium malesuada ultrices sed. Interdum felis
                    eros tortor lacus porta nascetur nec nec suscipit. Nulla
                    placerat felis nisi tristique purus tellus risus libero volutpat.</h6>

                  <div className='blog-big-card-para'>
                    <span>Jenny Wilson</span>
                    <span>4 min read</span>
                  </div>
                </div>

              </div>
              <div className='general-card'>
                <div className='general-card-left'>
                  <div className='blog-big-card-img'>
                  </div>
                </div>
                <div className='general-card-right'>
                  <h5>Accounts</h5>
                  <h6>Arcu morbi pretium malesuada ultrices sed. Interdum felis
                    eros tortor lacus porta nascetur nec nec suscipit. Nulla
                    placerat felis nisi tristique purus tellus risus libero volutpat.</h6>

                  <div className='blog-big-card-para'>
                    <span>Savannah Nguyen</span>
                    <span>2 min read</span>
                  </div>
                </div>

              </div>
              <div className='general-card'>
                <div className='general-card-left'>
                  <div className='blog-big-card-img'>
                  </div>
                </div>
                <div className='general-card-right'>
                  <h5>Payment</h5>
                  <h6>Arcu morbi pretium malesuada ultrices sed. Interdum felis
                    eros tortor lacus porta nascetur nec nec suscipit. Nulla
                    placerat felis nisi tristique purus tellus risus libero volutpat.</h6>

                  <div className='blog-big-card-para'>
                    <span>Savannah Nguyen</span>
                    <span>2 min read</span>
                  </div>
                </div>

              </div>
            </div>

           
          </div>







        </div>


      </div>



    </div>
  )
}

export default blogDetails