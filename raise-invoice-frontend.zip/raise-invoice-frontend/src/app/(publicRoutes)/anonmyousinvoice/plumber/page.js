'use client';

import React, { useEffect, useState } from 'react';
import '@/app/(publicRoutes)/anonmyousinvoice/anonymousgeneral.css';
import Banner from '@/app/(publicRoutes)/anonmyousinvoice/component/banner/Banner';
import { IMAGE } from '@/utils/Theme';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faHeart } from '@fortawesome/free-solid-svg-icons';
import Testimonial from '@/Components/testimonial/Testimonial';
import Accordion from 'react-bootstrap/Accordion';
import Api from '@/api/api';
import Link from 'next/link';
import "./plumber.css";

const offers = [
  {
    id: 1,
    title: 'Tailored for Plumbers',
    description: 'Designed with your needs in mind',
    icon: IMAGE.checkList,
  },
  {
    id: 2,
    title: 'Instant Download & Email',
    description: 'Send invoices directly to clients',
    icon: IMAGE.checkList,
  },
  {
    id: 3,
    title: 'Secure & Private',
    description: 'Your data stays with you',
    icon: IMAGE.checkList,
  },
  {
    id: 4,
    title: 'Customizable Templates ',
    description: 'Add your logo, services, and rates',
    icon: IMAGE.checkList,
  },
  {
    id: 5,
    title: 'No Hidden Fees ',
    description: '100% free, forever',
    icon: IMAGE.checkList,
  },
];

const Plumber = () => {
  const [testimonials, setTestimonials] = useState([]);
  const [faqs, setFaqs] = useState([]);
  const [pagecontent, setPagecontent] = useState([]);
  const [trialSection, setTrialSection] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    getPageContent();
  }, []);

  const getPageContent = async () => {
    setIsLoading(true);
    try {
      const pagecontentResponse = await Api.POST('get-pagecontent-by-slug', { slug: 'home' });
      setPagecontent(pagecontentResponse.data.data);
      let blocks = pagecontentResponse?.data?.data?.blocks || [];
      // Testimonials
      const testimonialIndex = blocks.findIndex(b => b.section_type === 2);
      let testimonialIds = (testimonialIndex >= 0 && blocks[testimonialIndex].testimonial_ids)
        ? blocks[testimonialIndex].testimonial_ids.split(',').map(Number)
        : [];
      getTestimonials(testimonialIds);
      // FAQs
      const faqIndex = blocks.findIndex(b => b.section_type === 1);
      let faqIds = (faqIndex >= 0 && blocks[faqIndex].faq_ids)
        ? blocks[faqIndex].faq_ids.split(',').map(Number)
        : [];
      getFaqList(faqIds);
      // Trial Section
      const trialIndex = blocks.findIndex(b => b.order_number === 7);
      if (trialIndex >= 0 && blocks[trialIndex].template) {
        setTrialSection(blocks[trialIndex].template);
      }
    } catch (err) {
      // handle error
    } finally {
      setIsLoading(false);
    }
  };

  const getTestimonials = async (testimonialIds = []) => {
    try {
      const testimonialResponse = await Api.POST('get-testimonial-list', { testimonialIds });
      setTestimonials(testimonialResponse.data.data || []);
    } catch (err) {
      setTestimonials([]);
    }
  };

  const getFaqList = async (faqIds = []) => {
    try {
      const faqResponse = await Api.POST('get-faq-list', { searchText: '', faqIds });
      setFaqs(faqResponse.data.data || []);
    } catch (err) {
      setFaqs([]);
    }
  };

  return (
    <>
      <div className="plumber-page">
        <Banner />

        {/* Free Invoice Tool Section */}
        <div className="freeInvoiceTool">
          <div className="container">
            <div className="row no-gutters align-items-center">
              <div className="col-lg-6">
                <div className="freeInvoiceToolLeft">
                  <img src={IMAGE.invoiceTool1} className="plumber1" alt="" />
                  <img src={IMAGE.invoiceTool2} className="plumber2" alt="" />
                </div>
              </div>
              <div className="col-lg-6">
                <div className="freeInvoiceToolRight">
                  <h2 className="freeInvoiceToolTitle">
                    <span className="positionText">
                      Why Use{' '}
                      <img className="textImage" src={IMAGE.line} alt="" />
                    </span>{' '}
                    Our Free Invoice Tool?
                  </h2>
                  <p className="freeInvoiceToolSubtitle">
                    Lorem ipsum dolor sit amet consectetur. Egestas sem arcu
                    tincidunt nisl in cursus. Est sollicitudin interdum nulla
                    in. Aliquet vitae aliquam ridiculus nec quis luctus. Justo
                    suspendisse libero vulputate sapien. Lorem ipsum dolor sit
                    amet consectetur. Egestas sem arcu tincidunt nisl in cursus.
                    Est sollicitudin interdum nulla in.
                  </p>
                  <h6 className="offer">What We Offer</h6>
                  <ul className="freeInvoiceToolList">
                    {offers.map((offer) => (
                      <li key={offer.id}>
                        <div className="freeInvoiceToolLeft">
                          <img src={offer.icon} alt={offer.title} />
                        </div>
                        <div className="freeInvoiceToolRight">
                          <h6>{offer.title}</h6>
                          <p>{offer.description}</p>
                        </div>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* How It Works Section */}
        <div className="howItWorks">
          <div className="container">
            <div className="row  ">
              {/* Step Column */}
              <div className="col-lg-6">
                <div className="howItWorksLeft">
                  <div className="howItWorksLeftTop">
                    <h6>How It Works?</h6>
                    <p>3 Simple Steps to Create Your Invoice</p>
                  </div>
                </div>
              </div>
              <div className="workingStep">
                <div className="row align-items-center ">
                  <div className="col-lg-6">
                    <ul className="howWorkingList">
                      <li>
                        <div className="howworkingListLeft">
                          <span>01</span>
                        </div>
                        <div className="howworkingListRight">
                          <h6>Enter Your Details</h6>
                          <p>Business name, client info, and job description</p>
                        </div>
                      </li>
                      <li>
                        <div className="howworkingListLeft">
                          <span>02</span>
                        </div>
                        <div className="howworkingListRight">
                          <h6>Add Services & Costs</h6>
                          <p>Itemize your work and set prices</p>
                        </div>
                      </li>
                      <li>
                        <div className="howworkingListLeft">
                          <span>01</span>
                        </div>
                        <div className="howworkingListRight">
                          <h6>Download or Send</h6>
                          <p>Get a PDF or email it instantly</p>
                        </div>
                      </li>
                    </ul>
                  </div>
                  <div className="col-lg-6">
                    <div className="howItWorksRight">
                      <img
                        src={IMAGE.workDetails}
                        alt="How it works"
                        style={{ width: '100%' }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="workBgTop">
            <img src={IMAGE.binary} className="binarybg" alt="" />
          </div>
        </div>

        <div className="reliableService">
          <img src={IMAGE.reliableService} className="reliableService" alt="" />
          <div className="container">
            <div className="reliableServiceCard">
              <h5>
                We offering reliable and <span>Free</span> Service
              </h5>
              <p>
                Easy-to-use tools to attach expenses, schedule appointments, and
                track & bill hours.
              </p>
              <a className="themeButton" href="#">
                Start Creating Invoice <img src={IMAGE.arrowBg} alt="" />
              </a>
            </div>
          </div>
        </div>

        <div className="image-container-background plumber">

                <div className='container '>
                        <h2 className='perfectPlumber'>Perfect for Plumbers Who</h2>
                    <div className="row align-items-center">
                        <div className="col-lg-5 col-md-6 col-12">
                        <div className="businessImage">
                            <img className="businness-img " src={IMAGE.plumber} alt="Card image cap" />
                        </div>
                        </div>

                        <div className="col-lg-7 col-md-6 col-12">
                            <div className="business-text padding-left">
                                <h2 >Work On-Site and Need Quick Billing</h2>
                               
                                <p>As a plumber, your work often takes you from one job site to another. You don’t have time to sit at a desk and create invoices manually. That’s why our tool is designed for speed and mobility—so you can bill your clients immediately after completing a job, right from your phone or tablet.</p>
                                <h4 className='quickBilling'>Key Benefits:</h4>
                                <ul className='quickList'>
                                    <li> <img src={IMAGE.checkList}  /><p> Create invoices on-site, right after the job is done</p></li>
                                    <li> <img src={IMAGE.checkList}  /><p> Use your mobile device—no need for a computer</p></li>
                                         <li> <img src={IMAGE.checkList}  /><p>Save time and reduce delays in getting paid</p></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>  
        </div>             

        <div className=" plumber complexSoftware bg-color">

                <div className='container '>
                        <div className="row align-items-center">
                    
                            <div className="col-lg-7 col-md-6 col-12">
                                <div className="business-text padding-left">
                                    <h2 >Look Professional Without Complex Software</h2>
                                
                                    <p>You don’t need expensive accounting software to look professional. Our invoice generator gives you clean, customizable templates that reflect your brand. Add your logo, contact details, and service descriptions to impress clients and build trust.</p>
                                    <h4 className='quickBilling'>Key Benefits:</h4>
                                    <ul className='quickList'>
                                        <li> <img src={IMAGE.checkList}  /><p>Create invoices on-site, right after the job is done  </p></li>
                                        <li> <img src={IMAGE.checkList}  /><p>Use your mobile device—no need for a computer</p></li>
                                            <li> <img src={IMAGE.checkList}  /><p>Save time and reduce delays in getting paid</p></li>
                                    </ul>
                                </div>
                            </div>

                                <div className="col-lg-5 col-md-6 col-12">
                                <div className="businessImage">
                                    <img className="businness-img " src={IMAGE.complexSoftwareImg} alt="Card image cap" />
                                </div>
                            </div>
                        </div>
                </div>  
        </div>    

        <div className="image-container-background plumber paymentJob">

                <div className='container '>
                
                    <div className="row align-items-center">
                        <div className="col-lg-5 col-md-6 col-12">
                        <div className="businessImage">
                            <img className="businness-img " src={IMAGE.paymentJobImg} alt="Card image cap" />
                        </div>
                        </div>

                        <div className="col-lg-7 col-md-6 col-12">
                            <div className="business-text padding-left ">
                                <h2 >Keep Track of Payments and Jobs Easily</h2>
                            
                                <p>Key Benefits: Track which invoices are paid, pending, or overdue Keep all client and job details in one place Stay organized and in control of your plumbing businessAs a plumber, your work often takes you from one job site to another. You don’t have time to sit at a desk and create invoices manually. That’s why our tool is designed for speed and mobility—so you can bill your clients immediately after completing a job, right from your phone or tablet.</p>
                                <h4 className='quickBilling'>Key Benefits:</h4>
                                <ul className='quickList'>
                                    <li> <img src={IMAGE.checkList}  /><p>  Track which invoices are paid, pending, or overdue</p></li>
                                    <li> <img src={IMAGE.checkList}  /><p> Keep all client and job details in one place</p></li>
                                        <li> <img src={IMAGE.checkList}  /><p>Stay organized and in control of your plumbing business</p></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>  
        </div>  

        {/* Trial Section from pagecontent */}
        {trialSection && (
          <div dangerouslySetInnerHTML={{ __html: trialSection }} />
        )}

        {/* FAQ Section */}
        {faqs.length > 0 && (
          <div className='faqs faq-home'>
            <div className='container'>
              <div className="row">
                <div className="col-lg-6 col-md-6 col-12">
                  <h2 className='faqs-title'>Our FAQ’s</h2>
                  <Accordion defaultActiveKey={0}>
                    {faqs.map((faq, j) => (
                      <Accordion.Item eventKey={j} key={j}>
                        <Accordion.Header>{faq.question}</Accordion.Header>
                        <Accordion.Body>
                          <div dangerouslySetInnerHTML={{ __html: faq.answer }} />
                        </Accordion.Body>
                      </Accordion.Item>
                    ))}
                  </Accordion>
                </div>
                <div className="col-lg-6 col-md-6 col-12 h-100">
                  <div className="faq-right">
                    <img className="woman" src={IMAGE.woman} alt='Image broken' />
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Testimonials Section */}
        {testimonials.length > 0 && (
          <div className="testimonialDiv">
            <div className='testimonials'>
              <div className='container'>
                <p className='loved'><FontAwesomeIcon icon={faHeart} /> Loved by experts</p>
                <h2>Our Testimonials</h2>
                <p className="paratext">Join us now and see what the hype is all about.</p>
                <Testimonial testimonials={testimonials} />
              </div>
            </div>
          </div>
        )}

        {/* ... rest of static sections ... */}
      </div>
    </>
  );
};

export default Plumber;
