'use client'
import React from 'react'
import { IMAGE } from '../../utils/Theme';
import './testimonial.css'
import Link from 'next/link';
import Slider from "react-slick";

const Testimonial = ({testimonials}) => {
  var settings = {
    dots: false,
    infinite: true,
    speed: 500,
    slidesToScroll: 1,
    slidesToShow: 2,
    centerMode: true,
    centerPadding: '150px',
    responsive: [
        {
            breakpoint: 1024, // For screens wider than 1024px
            settings: {
                slidesToShow: 2,
                slidesToScroll: 1
            }
        },
        {
            breakpoint: 900, // For tablets and smaller screens
            settings: {
                slidesToShow: 2,
                slidesToScroll: 1,
            centerPadding: '0px',

            }
        },
        {
            breakpoint: 576, // For mobile devices
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1,
            centerPadding: '0px',

            }
        }
    ]
  };
  
  return (
    <div>
      <Slider {...settings}>
        {testimonials && 
          testimonials.map((testimonial, i) => (
            <div key={i}>
              <div className="card-body">

                  <p className="card-text">{testimonial.message}</p>
                  <div className='card-footer'>
                      <div className='user-details'>
                          <h4>{testimonial.name}</h4>
                          <p>{testimonial.designation}</p>
                          <p>{testimonial.company}</p>
                      </div>
                      <div className="client-img">
                          <img src={testimonial.image ? `${process.env.serverUrl}uploads/testimonial/${testimonial.image}` : `${process.env.serverUrl}images/user.png`} alt='Image broken'/>
                      </div>
                  </div>
              </div>
            </div>
        ))}
        
      </Slider>
    </div>
  )
}

export default Testimonial