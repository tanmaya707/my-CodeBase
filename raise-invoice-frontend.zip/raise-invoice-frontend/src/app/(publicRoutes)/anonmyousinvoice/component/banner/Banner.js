'use client';

import React, { useState, useEffect } from 'react';
import { IMAGE } from '@/utils/Theme';



import './banner.css';
const Banner = () => {
  return (
    <div className="plumber-banner">
      <div className="container">
        <div className="row no-gutters align-items-center">
          <div className="col-lg-6 col-md-6 col-12 plumber-contentRight">
            <div className="plumber-contentLeft">
              <h1 className="plumber-title">
                Free Invoice Generator for <span>Plumbers</span>  - Quick, Easy & Professional
              </h1>
              <p className="plumber-subtitle">
                Create and send professional invoices in minutes. No
                registration required!
              </p>
              <button className="themeButton">
                Start Creating Invoice <img src={IMAGE.arrowBg} alt="" />
              </button>
            </div>
          </div>

          <div className="col-lg-6 col-md-6 col-12 plumber-imgRight">
            <div className="plumber-imgLeft">
              <img src={IMAGE.plumber1} alt="Image broken" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Banner;
