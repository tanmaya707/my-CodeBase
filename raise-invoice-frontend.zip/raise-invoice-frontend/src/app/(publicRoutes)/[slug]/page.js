"use client"
import React, { useEffect, useState, Suspense } from 'react'
import './page.css';
import { IMAGE } from '@/utils/Theme';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faHeart } from '@fortawesome/free-solid-svg-icons';
import Accordion from 'react-bootstrap/Accordion';
import Api from "../../../api/api";
import { useParams } from 'next/navigation';
import Testimonial from "@/Components/testimonial/Testimonial";
import NotFound from "@/Components/NotFound";
import LoadingScreen from "@/Components/loadingScreen/LoadingScreen";

const Page = () => {
    const { slug } = useParams();
    const [error, setError] = useState(null);
    const [isLoading, setIsLoading] = useState(true);
    const [pagecontent, setPagecontent] = useState([]);
    const [testimonials, setTestimonials] = useState([]);
    const [faqs, setFaqs] = useState([]);
    
    useEffect(() => {
        getPagecontent();
    }, []);

    const getPagecontent = async () => {
        setIsLoading(true);
        setError(null);
        try {
            const menuResponse = await Api.POST('get-menu-details', { slug: slug });
            const pagecontentResponse = menuResponse?.data?.data?.page ? await Api.POST('get-pagecontent-by-slug', { slug: menuResponse?.data?.data?.page?.slug }) : [];
            setPagecontent(pagecontentResponse?.data?.data);
            let blocks = pagecontentResponse?.data?.data?.blocks;
            var testimonialIndex = blocks && blocks.findIndex(b => b.section_type == 2);
            let testimonialIds = (testimonialIndex >= 0) && blocks[testimonialIndex].testimonial_ids ? blocks[testimonialIndex].testimonial_ids.split(',').map(Number) : [];
            getTestimonials(testimonialIds);
            var faqIndex = blocks && blocks.findIndex(b => b.section_type == 1);
            let faqIds = (faqIndex >= 0) && blocks[faqIndex].faq_ids ? blocks[faqIndex].faq_ids.split(',').map(Number) : [];
            getFaqList(faqIds);
        } catch (err) {
            setError("Failed to fetch page content.");
        } finally {
            setIsLoading(false);
        }
    };
    const getTestimonials = async (testimonialIds = []) => {
        setIsLoading(true);
        setError(null);
        try {
            const testimonialResponse = await Api.POST('get-testimonial-list', { testimonialIds: testimonialIds });
            setTestimonials(testimonialResponse.data.data);
        } catch (err) {
            setError("Failed to fetch testimonial list.");
        } finally {
            setIsLoading(false);
        }
    };
    const getFaqList = async (faqIds = []) => {
        setIsLoading(true);
        setError(null);
        try {
            const faqResponse = await Api.POST('get-faq-list', { searchText: '', faqIds: faqIds });
            setFaqs(faqResponse.data.data);
        } catch (err) {
            setError("Failed to fetch Faq list.");
        } finally {
            setIsLoading(false);
        }
    }

    const renderBlock = (data, i) => {
        switch (data.section_type) {
            case 1:              
                return <div className='faqs faq-home' key={i}>
                    <div className='container'>
                        <div className="row">
                            <div className="col-lg-6 col-md-6 col-12">
                                <h2 className='faqs-title'>{data.title}</h2>
                                <Accordion defaultActiveKey={0}>
                                    {faqs &&
                                        faqs.map((faq, j) => (
                                            <Accordion.Item eventKey={j} key={j}>
                                                <Accordion.Header>{faq.question}</Accordion.Header>
                                                <Accordion.Body>
                                                    <div key={j} dangerouslySetInnerHTML={{ __html: faq.answer }} />
                                                </Accordion.Body>
                                            </Accordion.Item>
                                        ))}
                                </Accordion>
                            </div>
                            <div className="col-lg-6 col-md-6 col-12 h-100">
                                <div className="faq-right">
                                    <img className="woman" src={IMAGE.woman} alt='Image broken' />
                                </div>
                            </div>
                        </div>

                    </div>
                </div>;
            case 2:
                return <div className='testimonials' key={i}>
                    <div className='container'>
                        <p className='loved'><FontAwesomeIcon icon={faHeart} /> Loved by experts</p>
                        <h2>{data.title}</h2>
                        <p className="paratext">{data.subtitle}</p>
                        {testimonials && testimonials.length && <Testimonial testimonials={testimonials} />}
                    </div>
                </div>;
            case 3:
                return <div key={i} dangerouslySetInnerHTML={{ __html: data.template }} />;
        }
    }

    return (
        <>
            {
                (!isLoading) ?
                    (pagecontent && pagecontent.id) ?
                        (pagecontent.blocks && pagecontent.blocks.length) ?
                            pagecontent.blocks.map((block, i) => (
                                <div className='custom-page'>
                                    <Suspense fallback={<p>Loading...</p>} key={i}>
                                        {renderBlock(block, i)}
                                    </Suspense>
                                </div>
                            ))
                        :
                        <Suspense fallback={<p>Loading...</p>}>
                            <div className='about-us-custom'>
                                <div className='container'>
                                    <div className="about-banner-content">
                                        <div className="banner-text">
                                            <h1>{pagecontent.page_title}</h1>
                                            <p>Coming Soon..</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </Suspense>
                        :
                        <NotFound />
                : <LoadingScreen />
            }
        </>
    )
}

export default Page
