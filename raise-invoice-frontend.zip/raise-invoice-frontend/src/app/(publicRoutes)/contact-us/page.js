"use client"
import React, { useEffect, useState } from 'react'
import Link from 'next/link';
import { IMAGE } from '@/utils/Theme';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faArrowRight } from '@fortawesome/free-solid-svg-icons';
import './contact-us.css'
import ContactForm from "@/Components/contactForm/ContactForm";
import LoadingScreen from "@/Components/loadingScreen/LoadingScreen";

const ContactUs = () => {
    const [isLoading, setIsLoading] = useState(true);
    useEffect(() => {
        setIsLoading(false);
    }, []);
    return (
        <>
            {!isLoading ?
                <>
                    <div className='contact-banner'>
                        <div className='contact-banner-sec'>
                            <img className="background" src={IMAGE.background} alt='Image broken'/>
                            <div className='banner-text'>
                                <h4>Contact Our Team</h4>
                                <p>If you need our help, have questions about how to use the platform or are experiencing 
                                    technical difficulties, please do not hesitate to contact us.
                                </p>
                            </div>
                        </div>
                        <div className='container'>              
                            <div className="card">
                                <div className="card-body">
                                    <ContactForm />                        
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className='container'>
                        <div className='contact-footer'>                
                            <div className='contact-footer-div'>
                                <img src={IMAGE.icon_email} alt='Image broken'/>
                                <h4>Email us</h4>
                                <p className="contact-para" >Email us for general queries, including marketing and partnership opportunities.</p>
                                <Link className="link-text" href={{}}>hello@helpcenter.com</Link>
                            </div>
                            <div className='contact-footer-div'>
                                <img src={IMAGE.icon_profile} alt='Image broken'/>
                                <h4>Support</h4>
                                <p className="contact-para">Check out helpful resources, FAQs and developer tools.</p>
                                <Link className="support-center" href={{}}>Support Center <FontAwesomeIcon className='right-arrow' icon={faArrowRight} /></Link>
                            </div>
                        </div>
                    </div>
                </>
            : <LoadingScreen />}
        </>
    )
}

export default ContactUs
