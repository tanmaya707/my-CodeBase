import React from 'react'
import Link from 'next/link';
import { IMAGE } from '@/utils/Theme';
// import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
// import { faCircleArrowRight } from '@fortawesome/free-solid-svg-icons';
import './feature.css';

const Features = () => {
    return (
        <>
            <div className="feature-banner">
                <div className='container'>
                    <div className="row">
                        <div className="col-lg-4">
                            <h2>Send professional invoices <span>in seconds</span></h2>
                            <p>Use a standard invoice template or add a logo, choose colors,
                                and include your brand with&nbsp;Invoice2go’s invoicing software.</p>
                        </div>
                        <div className="col-lg-8">

                            <div className='about-bottom'>
                                <img className='about-bottom-img' src={IMAGE.features_img_bnr} alt='Image broken' />
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div className='boost-bussiness'>
                <h2>Boost Your Business With Invoice
                    Management  Now</h2>
                <p>Join us now and see what the hype is all about.</p>
                <Link className='getstarted' href={{}}>Get Started <img className='bluearrow' src={IMAGE.blue_arrow} alt='Image broken' /></Link>
            </div>

            <div className='features'>
                <div className="container">
                    <div className="row feature-background">
                        <div className="col-lg-6">

                        </div>
                        <div className="col-lg-6 feature-list left">
                            <h6>Custom Design</h6>
                            <h2>Create customizable invoices</h2>
                            <p>Each invoice is beautifully formatted, making you look like the professional you
                                are. Use a standard invoice template or add a logo, choose colors, and include
                                your brand with&nbsp;Raise Invoice invoicing software.
                            </p>
                        </div>
                    </div>

                    <div className="row feature-background">
                        <div className="col-lg-6">

                        </div>
                        <div className="col-lg-6 feature-list ">
                            <h6>Custom Design</h6>
                            <h2>Send an invoice on the spot</h2>
                            <p>When you can send an invoice straight after you complete a job, you’ll save time
                                and get paid faster.
                            </p>
                        </div>
                    </div>

                    <div className="row feature-background">
                        <div className="col-lg-6">

                        </div>
                        <div className="col-lg-6 feature-list left">
                            <h6>Custom Design</h6>
                            <h2>Send an invoice via email, Facebook Messenger, and more</h2>
                            <p>Share your invoices via text, email, or other platforms like WhatsApp and Facebook Messenger.
                            </p>
                        </div>
                    </div>


                    <div className="row feature-background">
                        <div className="col-lg-6">

                        </div>
                        <div className="col-lg-6 feature-list">
                            <h6>Custom Design</h6>
                            <h2>Stay on top of your invoices with status tracking and reminders</h2>
                            <p>Get notified when clients view your invoices. Set up automatic reminders to stop
                                chasing unpaid invoices.
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <div className='financial-service'>
                <div className='container'>
                    <div className='financial-service-head mb-5'>
                        <h2>Trusted and Best Financial Service</h2>
                        <p>We offer the best financial services for you, in terms that our services are secure
                            and easy to be used
                        </p>
                    </div>

                    <div className="financial-service-body">
                        <div className="financial-lft">
                            <div className="financial-lft-img">
                                <img className="mb-5" src={IMAGE.icon} alt='Image broken' />
                            </div>
                            <div className="financial-lft-cntnt">
                                <h4>Safe and Reliable</h4>
                                <p>We guarantee your data, transaction history, balance secured under our security system.</p>
                            </div>
                        </div>

                        <div className="financial-lft">
                            <div className="financial-lft-img">
                                <img className="mb-5" src={IMAGE.icon2} alt='Image broken' />
                            </div>
                            <div className="financial-lft-cntnt">
                                <h4>Easy To Use</h4>
                                <p>We have all feature you need. We profide all planing, saving, and transaction. It’s all easy to use.</p>
                            </div>
                        </div>

                        <div className="financial-lft">
                            <div className="financial-lft-img">
                                <img className="mb-5" src={IMAGE.icon3} alt='Image broken' />
                            </div>
                            <div className="financial-lft-cntnt">
                                <h4>Integrations</h4>
                                <p>Connect you to every bank and financial platform in more than 120 countries around the world for free</p>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

            <div className='container faq'>
                <h2 className='faq-title mb-4'>FAQ</h2>
                <div className="faq-cards">
                    <div className="row">

                        <div className="col-lg-6">
                            <div className="card mb-3">
                                <div className="card-body card-details">
                                    <div className=" card-details-leftt">

                                        <img className="profile-img" src={IMAGE.user} alt='Image broken' />
                                        <div>
                                            <h4>General Questions</h4>
                                            <p>Lorem ipsum dolor sit amet consectetur </p>
                                        </div>
                                    </div>

                                    <Link href={{}}><img src={IMAGE.rightArrow} alt='Image broken' /></Link>
                                </div>

                            </div>
                        </div>
                        <div className="col-lg-6">
                            <div className="card mb-3">
                                <div className="card-body card-details">
                                    <div className=" card-details-leftt">

                                        <img className="profile-img" src={IMAGE.user} alt='Image broken' />
                                        <div>
                                            <h4>General Questions</h4>
                                            <p>Lorem ipsum dolor sit amet consectetur </p>
                                        </div>
                                    </div>

                                    <Link href={{}}><img src={IMAGE.rightArrow} alt='Image broken' /></Link>
                                </div>

                            </div>
                        </div>
                        <div className="col-lg-6">
                            <div className="card mb-3">
                                <div className="card-body card-details">
                                    <div className=" card-details-leftt">

                                        <img className="profile-img" src={IMAGE.user} alt='Image broken' />
                                        <div>
                                            <h4>General Questions</h4>
                                            <p>Lorem ipsum dolor sit amet consectetur </p>
                                        </div>
                                    </div>

                                    <Link href={{}}><img src={IMAGE.rightArrow} alt='Image broken' /></Link>
                                </div>

                            </div>
                        </div>
                        <div className="col-lg-6">
                            <div className="card mb-3">
                                <div className="card-body card-details">
                                    <div className=" card-details-leftt">

                                        <img className="profile-img" src={IMAGE.user} alt='Image broken' />
                                        <div>
                                            <h4>General Questions</h4>
                                            <p>Lorem ipsum dolor sit amet consectetur </p>
                                        </div>
                                    </div>

                                    <Link href={{}}><img src={IMAGE.rightArrow} alt='Image broken' /></Link>
                                </div>

                            </div>
                        </div>
                        <div className="col-lg-6">
                            <div className="card mb-3">
                                <div className="card-body card-details">
                                    <div className=" card-details-leftt">

                                        <img className="profile-img" src={IMAGE.user} alt='Image broken' />
                                        <div>
                                            <h4>General Questions</h4>
                                            <p>Lorem ipsum dolor sit amet consectetur </p>
                                        </div>
                                    </div>

                                    <Link href={{}}><img src={IMAGE.rightArrow} alt='Image broken' /></Link>
                                </div>

                            </div>
                        </div>
                        <div className="col-lg-6">
                            <div className="card mb-3">
                                <div className="card-body card-details">
                                    <div className=" card-details-leftt">

                                        <img className="profile-img" src={IMAGE.user} alt='Image broken' />
                                        <div>
                                            <h4>General Questions</h4>
                                            <p>Lorem ipsum dolor sit amet consectetur </p>
                                        </div>
                                    </div>

                                    <Link href={{}}><img src={IMAGE.rightArrow} alt='Image broken' /></Link>
                                </div>

                            </div>
                        </div>
                        <div className="col-lg-6">
                            <div className="card mb-3">
                                <div className="card-body card-details">
                                    <div className=" card-details-leftt">

                                        <img className="profile-img" src={IMAGE.user} alt='Image broken' />
                                        <div>
                                            <h4>General Questions</h4>
                                            <p>Lorem ipsum dolor sit amet consectetur </p>
                                        </div>
                                    </div>

                                    <Link href={{}}><img src={IMAGE.rightArrow} alt='Image broken' /></Link>
                                </div>

                            </div>
                        </div>
                        <div className="col-lg-6">
                            <div className="card mb-3">
                                <div className="card-body card-details">
                                    <div className=" card-details-leftt">

                                        <img className="profile-img" src={IMAGE.user} alt='Image broken' />
                                        <div>
                                            <h4>General Questions</h4>
                                            <p>Lorem ipsum dolor sit amet consectetur </p>
                                        </div>
                                    </div>

                                    <Link href={{}}><img src={IMAGE.rightArrow} alt='Image broken' /></Link>
                                </div>

                            </div>
                        </div>

                    </div>


                </div>
            </div>

        </>
    )
}

export default Features