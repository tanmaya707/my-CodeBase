'use client'
import React, { useEffect, useState, Suspense } from 'react'
import Link from 'next/link';
import { IMAGE } from '@/utils/Theme';
// import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
// import { faCircleArrowRight } from '@fortawesome/free-solid-svg-icons';
import './features.css';
import Accordion from 'react-bootstrap/Accordion';
import Api from "../../../api/api";
import LoadingScreen from "@/Components/loadingScreen/LoadingScreen";
const Features = () => {
    const [error, setError] = useState(null);
    const [isLoading, setIsLoading] = useState(false);
    const [pagecontent, setPagecontent] = useState([]);
    const [faqCategories, setFaqCategories] = useState(null);
    const [faqCategoryTitle, setFaqCategoryTitle] = useState('');
    const [faqs, setFaqs] = useState([]);
    const [isShowFaq, setIsShowFaq] = useState(false);
    const [faqCategorySlug, setFaqCategorySlug] = useState('');
    const [faqCategoryName, setFaqCategoryName] = useState('');
    const [faqCategoryImage, setFaqCategoryImage] = useState('');
    useEffect(() => {
        getPagecontent();
        getFaqCategories();
    }, []);
    const getPagecontent = async () => {
        setIsLoading(true);
        setError(null);
        try {
            const pagecontentResponse = await Api.POST('get-pagecontent-by-slug', { slug: 'features' });
            setPagecontent(pagecontentResponse.data.data);
        } catch (err) {
            setError("Failed to fetch page content.");
        } finally {
            setIsLoading(false);
        }
    };
    const getFaqCategories = async () => {
        setIsLoading(true);
        setError(null);
        try {
            const faqCategoryResponse = await Api.POST('get-faq-categories', {});
            setFaqCategories(faqCategoryResponse.data.data);
        } catch (err) {
            setError("Failed to fetch Faq Category list.");
        } finally {
            setIsLoading(false);
        }
    };
    const handleGetFaq = async (e, faqCategorySlug, faqCategoryName, faqCategoryImage) => {
        e.preventDefault();
        setFaqCategorySlug(faqCategorySlug);
        setFaqCategoryName(faqCategoryName);
        setFaqCategoryImage(faqCategoryImage);
        getFaqList(faqCategorySlug, faqCategoryName);
    }
    const getFaqList = async (faqCategorySlug = '', faqCategoryName = '') => {
        setIsShowFaq(true);
        setFaqCategoryTitle(faqCategoryName);
        setIsLoading(true);
        setError(null);
        try {
            const faqResponse = await Api.POST('get-faq-by-category', { searchText: '', slug: faqCategorySlug });
            setFaqs(faqResponse.data.data);
        } catch (err) {
            setError("Failed to fetch Faq Category list.");
        } finally {
            setIsLoading(false);
        }
    }
    const handleBackToFaqCategory = (e) => {
        e.preventDefault();
        setIsShowFaq(false);
        setFaqCategorySlug('');
        setFaqCategoryName('');
        setFaqCategoryImage('');
    }
    const renderBlock = (data, i) => {
        switch (data.section_type) {
            case 1:
                return <div className='container faq features' key={i}>
                    <h2 className='faq-title mb-4'>FAQ</h2>
                    <div className="faq-cards">
                        {!isShowFaq ?
                            <div className="row">
                                {faqCategories &&
                                    faqCategories.map((faqCategory, i) => (
                                        <div className="col-lg-6" key={i}>
                                            <div className="card mb-3">
                                                <div className="card-body card-details">
                                                    <div className=" card-details-leftt">

                                                        <img className="profile-img" src={faqCategory.image ? `${process.env.serverUrl}uploads/faq/${faqCategory?.image}` : IMAGE.user} alt='Image broken' style={{ width: '40px', height: '40px' }} />
                                                        <div className='pt-15 pb-15'>
                                                            <h4>{faqCategory.name}</h4>
                                                            <p>{ faqCategory.description }</p>
                                                            {/* <div dangerouslySetInnerHTML={{ __html: faqCategory.description }} /> */}
                                                        </div>
                                                    </div>

                                                    <Link href="javascript:void(0)" onClick={(e) => handleGetFaq(e, faqCategory.slug, faqCategory.name, faqCategory.image ? `${process.env.serverUrl}uploads/faq/${faqCategory?.image}` : IMAGE.user)}><img src={IMAGE.rightArrow} alt='Image broken' /></Link>
                                                </div>

                                            </div>
                                        </div>
                                    ))
                                }

                            </div>

                            :
                            <div className='faqs faq-home w-100' >
                                <div className='container'>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 col-12">
                                            <div className='d-flex justify-content-between'>
                                                <h4 className='faq-cat-title'>
                                                    {faqCategoryImage ?
                                                        <img className="profile-img" src={faqCategoryImage} alt='Image broken' style={{ width: '40px', height: '40px' }} />
                                                        : ''}
                                                    <span className='ml-10'>{faqCategoryTitle}</span>
                                                </h4>
                                                <Link href="javascript:void(0);" className='align-right' onClick={handleBackToFaqCategory}><img src={IMAGE.left_arw} alt='Image broken' /></Link>
                                            </div>
                                            <Accordion defaultActiveKey={0}>
                                                {faqs.length ?
                                                    faqs.map((faq, k) => (
                                                        <Accordion.Item eventKey={k} key={k}>
                                                            <Accordion.Header>{faq.question}</Accordion.Header>
                                                            <Accordion.Body>
                                                                <div dangerouslySetInnerHTML={{ __html: faq.answer }} />
                                                            </Accordion.Body>
                                                        </Accordion.Item>
                                                    ))
                                                    :
                                                    <Accordion.Item eventKey={0} key={0}>
                                                        <Accordion.Body>
                                                            <p>No questions are found.</p>
                                                        </Accordion.Body>
                                                    </Accordion.Item>
                                                }
                                            </Accordion>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        }
                    </div>
                </div>
            case 3:
                return <div key={i} dangerouslySetInnerHTML={{ __html: data.template }} />;
        }
    }
    return (
        <>
            {
                (pagecontent && pagecontent.blocks) ?
                    pagecontent.blocks.length &&
                    pagecontent.blocks.map((block, i) => (
                        <Suspense fallback={<p>Loading...</p>} key={i}>
                            {renderBlock(block, i)}
                        </Suspense>
                    ))
                    : <LoadingScreen />
            }
            {/* <div className="feature-banner">
            <div className='container'>
                <div className="row">
                    <div className="col-lg-4">
                        <h2>Send professional invoices <span>in seconds</span></h2>
                        <p>Use a standard invoice template or add a logo, choose colors, 
                            and include your brand with&nbsp;Invoice2go’s invoicing software.</p>
                    </div>
                    <div className="col-lg-8">

                        <div className='about-bottom'>
                        <img className='about-bottom-img' src={IMAGE.features_img_bnr} alt='Image broken'/>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div className='boost-bussiness'>
            <h2>Boost Your Business With Invoice 
            Management  Now</h2>
            <p>Join us now and see what the hype is all about.</p>
            <Link className='getstarted' href={{}}>Get Started <img className='bluearrow' src={IMAGE.blue_arrow} alt='Image broken'/></Link>
        </div>

        <div className='features'>
            <div className="container">
                <div className="row feature-background">
                    <div className="col-lg-6">
                    
                    </div>
                    <div className="col-lg-6 feature-list left">
                        <h6>Custom Design</h6>
                        <h2>Create customizable invoices</h2>
                        <p>Each invoice is beautifully formatted, making you look like the professional you 
                            are. Use a standard invoice template or add a logo, choose colors, and include 
                            your brand with&nbsp;Raise Invoice invoicing software.
                        </p>
                    </div>
                </div>
            
                <div className="row feature-background">
                    <div className="col-lg-6">
                    
                    </div>
                    <div className="col-lg-6 feature-list ">
                        <h6>Custom Design</h6>
                        <h2>Send an invoice on the spot</h2>
                        <p>When you can send an invoice straight after you complete a job, you’ll save time 
                            and get paid faster.
                        </p>
                    </div>
                </div>
            
                <div className="row feature-background">
                    <div className="col-lg-6">
                    
                    </div>
                    <div className="col-lg-6 feature-list left">
                        <h6>Custom Design</h6>
                        <h2>Send an invoice via email, Facebook Messenger, and more</h2>
                        <p>Share your invoices via text, email, or other platforms like WhatsApp and Facebook Messenger.
                        </p>
                    </div>
                </div>
            
            
                <div className="row feature-background">
                    <div className="col-lg-6">
                    
                    </div>
                    <div className="col-lg-6 feature-list">
                        <h6>Custom Design</h6>
                        <h2>Stay on top of your invoices with status tracking and reminders</h2>
                        <p>Get notified when clients view your invoices. Set up automatic reminders to stop 
                            chasing unpaid invoices.
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <div className='financial-service'>
            <div className='container'>
                <div className='financial-service-head mb-5'>
                    <h2>Trusted and Best Financial Service</h2>
                    <p>We offer the best financial services for you, in terms that our services are secure 
                        and easy to be used
                    </p>
                </div>
    
                <div className="financial-service-body">
                    <div className="financial-lft">
                    <div className="financial-lft-img">
                        <img className="mb-5" src={IMAGE.icon} alt='Image broken'/>
                    </div>
                    <div className="financial-lft-cntnt">
                        <h4>Safe and Reliable</h4>
                        <p>We guarantee your data, transaction history, balance secured under our security system.</p>
                    </div>
                    </div>

                    <div className="financial-lft">
                    <div className="financial-lft-img">
                        <img className="mb-5" src={IMAGE.icon2} alt='Image broken'/>
                    </div>
                    <div className="financial-lft-cntnt">
                        <h4>Easy To Use</h4>
                        <p>We have all feature you need. We profide all planing, saving, and transaction. It’s all easy to use.</p>
                    </div>
                    </div>

                    <div className="financial-lft">
                    <div className="financial-lft-img">
                        <img className="mb-5" src={IMAGE.icon3} alt='Image broken'/>
                    </div>
                    <div className="financial-lft-cntnt">
                        <h4>Integrations</h4>
                        <p>Connect you to every bank and financial platform in more than 120 countries around the world for free</p>
                    </div>
                    </div>

                </div>
            </div>
        </div>

        <div className='container faq'>
            <h2 className='faq-title mb-4'>FAQ</h2>
            <div className="faq-cards">
              {!isShowFaq ? 
                <div className="row">
                  { faqCategories && 
                    faqCategories.map((faqCategory, i) => (
                      <div className="col-lg-6" key={i}>
                        <div className="card mb-3">
                          <div className="card-body card-details">
                            <div className=" card-details-leftt">

                              <img className="profile-img" src={faqCategory.image ? `${process.env.serverUrl}uploads/faq/${faqCategory?.image}` : IMAGE.user} alt='Image broken' style={{width:'40px', height:'40px'}} />
                              <div>
                                <h4>{faqCategory.name}</h4>
                                <div dangerouslySetInnerHTML={{__html:faqCategory.description}} />
                              </div>
                            </div>

                            <Link href="javascript:void(0)" onClick={(e)=>handleGetFaq(e, faqCategory.slug, faqCategory.name, faqCategory.image ? `${process.env.serverUrl}uploads/faq/${faqCategory?.image}` : IMAGE.user)}><img src={IMAGE.rightArrow} alt='Image broken' /></Link>
                          </div>

                        </div>
                      </div>
                    ))
                  }

                </div>
              
              :
                <div className='faqs faq-home w-100'>
                  <div className='container'>
                    <div className="row">
                      <div className="col-lg-12 col-md-12 col-12">
                          <div className='d-flex justify-content-between'>
                            <h4 className='faq-cat-title'>
                              {faqCategoryImage ? 
                              <img className="profile-img" src={faqCategoryImage} alt='Image broken' style={{width:'40px', height:'40px'}} /> 
                              : ''}
                              <span className='ml-10'>{faqCategoryTitle}</span>
                            </h4>
                            <Link href="javascript:void(0);" className='align-right' onClick={handleBackToFaqCategory}><img src={IMAGE.left_arw} alt='Image broken' /></Link>
                          </div>
                          <Accordion defaultActiveKey={0}>
                            { faqs.length ? 
                              faqs.map((faq, k) => (
                                <Accordion.Item eventKey={k} key={k}>
                                  <Accordion.Header>{faq.question}</Accordion.Header>
                                  <Accordion.Body>
                                    <div dangerouslySetInnerHTML={{__html:faq.answer}} />
                                  </Accordion.Body>
                                </Accordion.Item>
                              ))
                              :
                              <Accordion.Item eventKey={0} key={0}>
                                <Accordion.Body>
                                  <p>No questions are found.</p>
                                </Accordion.Body>
                              </Accordion.Item>
                            }
                          </Accordion>
                      </div>
                    </div>
                  </div>
                </div>
              }
            </div>
        </div> */}

        </>
    )
}

export default Features