'use client'
import React, { useEffect, useState, Suspense } from 'react'
// import { IMAGE } from '../../../utils/Theme';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faHeart } from '@fortawesome/free-solid-svg-icons';
import './about-us.css';
// import Link from 'next/link';
import Testimonial from "@/Components/testimonial/Testimonial";
import Api from "../../../api/api";
import LoadingScreen from "@/Components/loadingScreen/LoadingScreen";
const AboutUs = () => {
  const [error, setError] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [pagecontent, setPagecontent] = useState([]);
  const [testimonials, setTestimonials] = useState([]);
  useEffect(() => {
    getPagecontent();
    getTestimonials();
  }, []);
  const getPagecontent = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const pagecontentResponse = await Api.POST('get-pagecontent-by-slug', { slug: 'about-us' });
      setPagecontent(pagecontentResponse.data.data);
    } catch (err) {
      setError("Failed to fetch page content.");
    } finally {
      setIsLoading(false);
    }
  };
  const getTestimonials = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const testimonialResponse = await Api.POST('get-testimonial-list', {});
      setTestimonials(testimonialResponse.data.data);
    } catch (err) {
      setError("Failed to fetch testimonial list.");
    } finally {
      setIsLoading(false);
    }
  };
  const renderBlock = (data, i) => {
    switch (data.section_type) {
      case 2:
        return <div className='testimonials' key={i}>

          <div className='container'>
            <p className='loved'><FontAwesomeIcon icon={faHeart} /> Loved by experts</p>
            <h2>{data.title}</h2>
            <p className="paratext">{data.subtitle}</p>

            {testimonials && testimonials.length && <Testimonial testimonials={testimonials} />}

          </div>

        </div>
      case 3:
        return <div key={i} dangerouslySetInnerHTML={{ __html: data.template }} />;
    }
  }

  return (
    <>
      {
        (pagecontent && pagecontent.blocks) ?
          pagecontent.blocks.length &&
          pagecontent.blocks.map((block, i) => (
            <Suspense fallback={<p style={{ margin: "0 !important" }}>Loading...</p>} key={i}>
              {renderBlock(block, i)}
            </Suspense>
          ))
          : <LoadingScreen />
      }


      {/* <div className='aboutus-banner'>
      <div className='container'>
      <div className='about-banner-content'>
      
        <img className='background' src={IMAGE.halfCircle} alt='Image broken'/>
        <div className='banner-text'>
          <h1>Our Story</h1>
          <p>Lorem ipsum dolor sit amet consectetur. Vestibulum ornare lacus nisl elementum facilisi vitae. 
            Morbi sagittis sagittis id facilisi sed mauris id facilisi molestie. Porta orci bibendum pellentesque 
            quam augue scelerisque massa in lorem. Lacus est sem ligula feugiat ac orci est.</p>
        </div>
        </div>

      </div>


      <div className='client-uses'>
      <div className="container">

        <img className="people" src={IMAGE.people} alt='Image broken'/>
        <div className='about-bottom'>
            <div className="row">
              <div className="col-lg-3 col-md-6 col-6">
              <div className='white-icon-imgs'>
                <div className='white-icon'><FontAwesomeIcon icon={faFireFlameCurved}/></div>
              <div className='white-icon-cntnt'>
                <h2>225K</h2>
                <p>Small businesses use Raise Invoice to work their way</p>
               </div>
               </div>

              </div>
              <div className="col-lg-3 col-md-6 col-6">
                <div className='white-icon-imgs'>
                  <div className='white-icon'><FontAwesomeIcon icon={faUserCheck} /></div>
                <div className='white-icon-cntnt'>
                  <h2>225K</h2>
                  <p>Small businesses use Raise Invoice to work their way</p>
                </div>
                </div>

              </div>

              <div className="col-lg-3 col-md-6 col-6">
                <div className='white-icon-imgs'>
                
                <div className='white-icon'><FontAwesomeIcon icon={faEnvelope} /></div>
                <div className='white-icon-cntnt'>
                <h2>225K</h2>
                <p>Small businesses use Raise Invoice to work their way</p>
              </div>
              </div>

              </div>

              <div className="col-lg-3 col-md-6 col-6">
              <div className='white-icon-imgs'>
                <div className='white-icon'><FontAwesomeIcon icon={faFlag} /></div>
                <div className='white-icon-cntnt'>
                <h2>225K</h2>
                <p>Small businesses use Raise Invoice to work their way</p>
              </div>
              </div>

              </div>

            </div>
          </div>
        </div>
      </div>
      </div>

      <div className='testimonials'>
      
          <div className='container'>
            <p className='loved'><FontAwesomeIcon icon={faHeart} /> Loved by experts</p>
            <h2>Our Testimonials</h2>
            <p className="paratext">Join us now and see what the hype is all about.</p>
            
            {testimonials.length && <Testimonial testimonials={testimonials} />}
            
          </div>

      </div>

  
      <div className='ecosystem padding-bottom'>
        <div className="container">
          <div className="row brdr-top align-items-center ">
            <div className="col-lg-6 col-md-6 col-12">
            <div className="building-ecosystem">

              <img className="writing" src={IMAGE.writing} alt='Image broken'/>
              <img className="typing" src={IMAGE.typing} alt='Image broken'/>
            </div>
            </div>

            <div className="col-lg-6 col-md-6 col-12 building-ecosystem-text">
              <h2>Building the Right
              Invoicing Work Ecosystem</h2>
              <p>Lorem ipsum dolor sit amet consectetur. In convallis elementum erat cursus. Pretium 
                dictum velit consectetur velit mauris sapien metus commodo varius. Penatibus sodales in 
                enim massa sit non turpis. Nisl urna amet tincidunt cras. Sit non lectus pellentesque 
                massa aliquet turpis tellus. Facilisis blandit ut donec sed nunc sed eget nec non. 
                Elit et ultricies lorem pharetra a luctus consectetur risus.</p>
            </div>
          </div>
        </div>
      </div>

      <div className='our-values'>
        <div className="container ">
        <div className="value-top-mobile">
          <h2>Our Values</h2>
              <p>Like Steve Jobs quotes, “Design is not just what it looks like and feels like. 
                Design is how it works”. We always try to make a great output by this culture:
              </p>

              </div>
          <div className="row align-items-center flip-column">
            <div className="col-lg-5 col-md-6 col-12">
          <div className="value-top-desktop">
              <h2>Our Values</h2>
              <p>Like Steve Jobs quotes, “Design is not just what it looks like and feels like. 
                Design is how it works”. We always try to make a great output by this culture:
              </p>
              </div>
              <ul>
                <li><img src={IMAGE.tick} alt="" />Fast Delivery</li>
                <li><img src={IMAGE.tick} alt="" />Hungry for Explorations</li>
                <li><img src={IMAGE.tick} alt="" />Teamwork Always</li>
                <li><img src={IMAGE.tick} alt="" />Communication is the Key</li>
                <li><img src={IMAGE.tick} alt="" />Weekly Evaluation</li>
                <li><img src={IMAGE.tick} alt="" />Update for th Trend</li>
              </ul>
            </div>
            <div className="col-lg-7 col-md-6 col-12 ">
              <img className="puzzle" src={IMAGE.puzzle} alt='Image broken'/>
            </div>
          </div>
        </div>
      </div>

      <div className='future-work mbl-view my-5'>
        <div className="container">
          <div className="row align-items-center flip-column">
            <div className="col-lg-5 col-md-5 col-12">
              <img className="business-woman" src={IMAGE.business_woman} alt='Image broken'/>
            </div>
            <div className="col-lg-7 col-md-5 col-12 building-ecosystem-text left-align-text p-0">
              <h2>The future of work</h2>
              <p className='future-text'>What is the future of work? To find out, look no further than your own home. 
                Connect with colleagues from across the globe while doing work that matters.
              </p>
            </div>
          </div>
        </div>
      </div> */}



    </>
  )
}

export default AboutUs