import { GET_ITEM, isLoading } from "@/constaints/actionConstaints";
import { AdvisorLoginService } from "./service";

export const advisorProfile = (params) => async (dispatch) => {
    dispatch(isLoading(true));
    try {
      const response = await AdvisorLoginService.advisorProfile(
        params
      );
      dispatch({
        type: GET_ITEM,
        payload: response,
      });
      dispatch(isLoading(false));
      return response.data;
    } catch (error) {
      console.error(error);
      dispatch(isLoading(false));
      throw error;
    }
};