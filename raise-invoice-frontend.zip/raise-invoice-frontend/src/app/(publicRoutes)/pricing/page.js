"use client"
import React, { useEffect, useState, Suspense } from 'react'
import { IMAGE } from '@/utils/Theme';
import Link from 'next/link';
import './pricing.css';
import Accordion from 'react-bootstrap/Accordion';
import Slider from "react-slick";
import { useDispatch, useSelector } from 'react-redux';
import Api from "../../../api/api";
import { toast } from 'react-toastify';
import LoadingScreen from "@/Components/loadingScreen/LoadingScreen";
import { addSubscriptionRequest } from '@/redux/slices/dataSlice';
import { clientProfileDetails } from "@/redux/slices/authSlice";
import { useRouter } from 'next/navigation';

const Pricing = () => {
    const dispatch = useDispatch();
    const router = useRouter();
    const [selectedFrequency, setSelectedFrequency] = useState("yearly"); // Default frequency
    const [error, setError] = useState(null);
    const [isLoading, setIsLoading] = useState(false);
    const [loading, setLoading] = useState(false); // Loading state
    const [planList, setPlanList] = useState(null);
    const [featureCategories, setFeatureCategories] = useState(null);
    const [defaultCurrency, setDefaultCurrency] = useState(null);
    const [selectedPlan, setSelectedPlan] = useState(null); // State to hold selected plan
    const { user } = useSelector((state) => state.auth);

    useEffect(() => {
        getDefaultCurrency();
        getFeatureCategories();
        dispatch(clientProfileDetails());
    }, []);

    const getPlanList = async (defaultCurrencyId) => {
        setIsLoading(true);
        setError(null);
        try {
            const palnResponse = await Api.POST('get-plan-list', { defaultCurrencyId: defaultCurrencyId, status: 1 });
            console.log('palnResponse', palnResponse);
            setPlanList(palnResponse.data.data);
        } catch (err) {
            setError("Failed to fetch plan list.");
        } finally {
            setIsLoading(false);
        }
    };
    const getFeatureCategories = async () => {
        setIsLoading(true);
        setError(null);
        try {
            const featureCategories = await Api.POST('get-features-categories', {});
            // console.log('featureCategories', featureCategories);
            setFeatureCategories(featureCategories.data.data);
        } catch (err) {
            setError("Failed to fetch feature category list.");
        } finally {
            setIsLoading(false);
        }
    };
    const getPlanPrice = (priceData, frequency = 'yearly') => {
        let priceVal = priceData.find((priceDetail) => priceDetail.name === frequency);
        let planPrice = priceVal.price ?? 0;
        if (priceVal.discount) {
            planPrice = planPrice - (planPrice * priceVal.discount / 100);
        }
        return {
            price: priceVal.price ?? 0,
            discount: priceVal.discount ?? 0,
            discountedPrice: planPrice
        };
    };
    const getFrequencyName = (frequency = 'yearly') => {
        let frequencyName = '';
        switch (frequency) {
            case 'monthly':
                frequencyName = 'Month';
                break;
            case 'yearly':
                frequencyName = 'Year';
                break;
        }
        return frequencyName;
    };
    //Buy Subscription
    const processSubscription = async (plan) => {
        setLoading(true);
        try {
            if (!plan) {
                alert("Invalid plan selected.");
                return;
            }
            const payload = {
                planId: plan.id,
                startDate: new Date(),
                planType: selectedFrequency,
                price: getPlanPrice(plan.plan_prices, selectedFrequency).discountedPrice,
            };
            const clientSubscription = await dispatch(addSubscriptionRequest(payload)).unwrap();

            if (clientSubscription.status) {
                toast.success(clientSubscription.message);
                router.push('/profile');
            } else {
                toast.error(clientSubscription.message);
                return;
            }
        } catch (err) {
            console.error("Profile error:", err);
            toast.error("Failed to create profile.");
        } finally {
            setLoading(false); // Reset loading state
        }
    };

    const sliderPositionStyle = {
        left: selectedFrequency === "monthly" ? "15px" : "72%",
        transform: selectedFrequency === "monthly" ? "translateX(0)" : "translateX(-41%)",
        transition: "all 0.3s ease-in-out",
        // marginLeft: "42px",
        // width: "141px"

    };

    var settings = {
        dots: false,
        infinite: true,
        speed: 500,
        slidesToShow: 4.3,
        slidesToScroll: 1,
        // centerPadding: '150px',

        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1,
                    infinite: true,
                    dots: true,
                },
            },
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1,
                },
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1.2,
                    slidesToScroll: 1,
                    dots: false,
                    centerMode: true,
                    centerPadding: '10px', // Adjust for smaller 

                },
            },
        ]
    };

    const getDefaultCurrency = async () => {
        try {
            const response = await Api.POST('get-currency-info', { isDefault: 1 });
            setDefaultCurrency(response?.data?.data);
            getPlanList(response?.data?.data?.id);
        } catch (error) {
            console.log('error', error);
        }
    };

    return (
        <>
            {!isLoading ?
                <Suspense fallback={<p>Loading...</p>}>
                    <div className="Subscription">
                        <div className="container">
                            <div className="row col-sm-12" >
                                <h1 className='select'>Select Plan  </h1>
                                <div className="select-plan-all">
                                    <div className="select-plan">
                                    <div className="monthlyDiv">
                                        <div
                                            className={`option ${selectedFrequency === "monthly" ? "active" : ""}`}
                                            onClick={() => setSelectedFrequency("monthly")}
                                        >
                                            Monthly
                                        </div>
                                        <div  className={`slider ${selectedFrequency === "monthly" ? "MonthlyActive" : ""}`} style={sliderPositionStyle}></div>
                                    </div>

                                    <div className="yearlyDiv">

                                        <div
                                            className={`option ${selectedFrequency === "yearly" ? "active" : ""}`}
                                            onClick={() => setSelectedFrequency("yearly")}
                                        >
                                            Yearly
                                        </div>
                                        
                                        <div className={`slider ${selectedFrequency === "yearly" ? "YearlyActive" : ""}`} style={sliderPositionStyle}></div>
                                    </div>
                                        </div>

                                </div>

                                <div className='planPricePanel'>
                                    <div className='ppWrap'>
                                        {planList && planList?.map((plan, i) => (
                                            <div className={`ppBox ${(i != 0 && i != (planList.length - 1)) ? 'mid-ppbox' : ''}`} key={i}>
                                                {plan.is_recommended ?
                                                    <img src={IMAGE.sub_img} className='sub-tag' />
                                                    : ''}
                                                <h2>{plan.name}</h2>
                                                <h2 className="rupees">{`${defaultCurrency.symbol} ${getPlanPrice(plan.plan_prices, selectedFrequency).discountedPrice.toFixed(2)}`}</h2>
                                                <p>Per {getFrequencyName(selectedFrequency)}</p>
                                                <button
                                                    className={`subs-btn  ${user?.data?.planType == selectedFrequency && user?.data?.planDetails?.id === plan.id ? 'bg-secondary' : ''}`}
                                                    onClick={() => processSubscription(plan)}
                                                    disabled={user?.data?.planType == selectedFrequency && user?.data?.planDetails?.id === plan.id}
                                                >
                                                    {user?.data?.planType == selectedFrequency && user?.data?.planDetails?.id === plan.id ? 'Current Plan' : (i === 0 ? `Join Now` : `Start ${plan.name}`)}
                                                </button>
                                                <div className='plan_desc' dangerouslySetInnerHTML={{ __html: plan.description }} />
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>

                            <div className='faqs only-faq'>
                                <div className='container'>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 col-12">
                                            <h2 className='faqs-title mb-3'>Compare Features</h2>

                                            <div className='feature_table table-responsive'>
                                                <table className='table-here'>
                                                    <thead>
                                                        <tr>
                                                            <th className='feature_head_blank'></th>
                                                            {planList && planList?.map((plan, l) => (
                                                                <th key={l}>{plan.name}</th>
                                                            ))}
                                                        </tr>

                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td colSpan={4}>
                                                                <table>
                                                                    <tbody>
                                                                        <tr>
                                                                            <td >
                                                                                <Accordion defaultActiveKey={0}>
                                                                                    {featureCategories && featureCategories?.map((featureCategory, k) => (
                                                                                        <Accordion.Item eventKey={k} key={k}>
                                                                                            <Accordion.Header>{featureCategory.name}</Accordion.Header>
                                                                                            <Accordion.Body>
                                                                                                <div className="table-responsive">
                                                                                                    <table className="table fixed-table">
                                                                                                        <tbody>
                                                                                                            {featureCategory.features && featureCategory.features?.map((feature, index) => (
                                                                                                                <tr key={index}>
                                                                                                                    <td scope="row">{feature.name}</td>
                                                                                                                    {feature.plans && feature.plans?.map((data, j) => (
                                                                                                                        <td key={j}>
                                                                                                                            {feature.type == 'text' ?
                                                                                                                                <p>{data.plan_features.value ? data.plan_features.value : <span>-</span>}</p>
                                                                                                                                : (data.plan_features.value == '1' ? <img src={IMAGE.black_tick} /> : <span>-</span>)
                                                                                                                            }
                                                                                                                        </td>
                                                                                                                    ))}
                                                                                                                </tr>
                                                                                                            ))}
                                                                                                        </tbody>
                                                                                                    </table>
                                                                                                </div>
                                                                                            </Accordion.Body>
                                                                                        </Accordion.Item>
                                                                                    ))}
                                                                                </Accordion>
                                                                            </td>


                                                                        </tr>
                                                                        {/* <tr>
                                                                            <td >
                                                                        <Accordion defaultActiveKey="0">
                                                                        
                                                                            <Accordion.Item eventKey="1">
                                                                                <Accordion.Header>Invoicing</Accordion.Header>
                                                                                <Accordion.Body>
                                                                                    <div className="table-responsive">

                                                                                        <table className="table">
                                                                                            <tbody>
                                                                                                <tr>
                                                                                                    <td scope="row">Invoices</td>
                                                                                                    <td>30/year</td>
                                                                                                    <td>30/year</td>
                                                                                                    <td>30/year</td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                    <td scope="row">Card payment fee</td>
                                                                                                    <td>3.5%</td>
                                                                                                    <td>3.5%</td>
                                                                                                    <td>3.5%</td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                    <td scope="row">Estimates</td>
                                                                                                    <td>Unlimited</td>
                                                                                                    <td>Unlimited</td>
                                                                                                    <td>Unlimited</td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                    <td scope="row">Projects</td>
                                                                                                    <td>Unlimited</td>
                                                                                                    <td>Unlimited</td>
                                                                                                    <td>Unlimited</td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                    <td scope="row">Clients</td>
                                                                                                    <td>Unlimited</td>
                                                                                                    <td>Unlimited</td>
                                                                                                    <td>Unlimited</td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                    <td scope="row">Team Members</td>
                                                                                                    <td>Unlimited</td>
                                                                                                    <td>Unlimited</td>
                                                                                                    <td>Unlimited</td>
                                                                                                </tr>
                                                                                            </tbody>
                                                                                        </table>
                                                                                    </div>

                                                                                </Accordion.Body>
                                                                            </Accordion.Item>                                                          
                                                                        </Accordion>
                                                                        </td>
                                                                

                                                                        </tr> */}
                                                                    </tbody>
                                                                </table>
                                                            </td>

                                                        </tr>

                                                    </tbody>
                                                </table>
                                            </div>




                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div className='make-invoicing'>
                                <div className='container'>
                                    <h2 className='my-5'>Make Invoicing Simple with us</h2>
                                    <div className='make-invoicing-body'>
                                        <div className='simple-invoice'>
                                            <h2>01</h2>
                                            <h4>Handle all your admin work in minutes</h4>
                                            <p>Easy-to-use tools to attach expenses, schedule appointments, and track & bill hours.</p>
                                        </div>
                                        <div className='simple-invoice'>
                                            <h2>02</h2>
                                            <h4>See the big picture with business reports</h4>
                                            <p>Track how your business is doing and get critical insights with easy-to-use charts and graphs.</p>
                                        </div>
                                        <div className='simple-invoice'>
                                            <h2>03</h2>
                                            <h4>Spend less time managing your books</h4>
                                            <p>Sync all of your invoicing and payments data to QuickBooks or Xero for your tax preparer.</p>
                                        </div>
                                        <div className='simple-invoice'>
                                            <h2>04</h2>
                                            <h4>Take care of business on the spot</h4>
                                            <p>With the&nbsp;Invoice2go&nbsp;app (available on the web, iOS, and Android) all of your information is synced&nbsp;</p>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>

                    </div>

                    <div className='testimonials customer-section'>
                        <div className='container'>
                            <div>
                                <h4>What customers say about us </h4>
                                <p className='experience'>We do our best to provide you the best experience ever</p>

                                <div className="mobile-testi-card">
                                    <div className="card customer-card">
                                        <div className="card-body excellence">
                                            <h6>Excellent</h6>
                                            <img className="stars" src={IMAGE.greenStars} alt='Image broken' />
                                            <p>Based on <span>456 reviews</span></p>
                                            <div className='rating'>
                                                <img src={IMAGE.star} alt='Image broken' />
                                                <p>Trustpilot</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div>
                                    <Slider {...settings}>
                                        <div style={{ border: "2px solid black" }} >
                                            <div className="card customer-card">
                                                <div className="card-body excellence">
                                                    <h6>Excellent</h6>
                                                    <img className="stars" src={IMAGE.greenStars} alt='Image broken' />
                                                    <p>Based on <span>456 reviews</span></p>
                                                    <div className='rating'>
                                                        <img src={IMAGE.star} alt='Image broken' />
                                                        <p>Trustpilot</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div>
                                            <div className="card customer-card">
                                                <div className="card-body best">
                                                    <img src={IMAGE.quote} alt='Image broken' />
                                                    <h6>Best on the market</h6>
                                                    <div className='rating-time'>
                                                        <img className="" src={IMAGE.greenStars} alt='Image broken' />
                                                        <p>2 days ago</p>
                                                    </div>
                                                    <p className='best-para'>I love this product because the support is great. Ple ...</p>
                                                    <h6 className='traveller'>Worldtraveler</h6>
                                                </div>
                                            </div>
                                        </div>
                                        <div>
                                            <div className="card customer-card">
                                                <div className="card-body best">
                                                    <img src={IMAGE.quote} alt='Image broken' />
                                                    <h6>Best on the market</h6>
                                                    <div className='rating-time'>
                                                        <img className="" src={IMAGE.greenStars} alt='Image broken' />
                                                        <p>2 days ago</p>
                                                    </div>
                                                    <p className='best-para'>I love this product because the support is great. Ple ...</p>
                                                    <h6 className='traveller'>Worldtraveler</h6>
                                                </div>
                                            </div>
                                        </div>
                                        <div>
                                            <div className="card customer-card">
                                                <div className="card-body best">
                                                    <img src={IMAGE.quote} alt='Image broken' />
                                                    <h6>Best on the market</h6>
                                                    <div className='rating-time'>
                                                        <img className="" src={IMAGE.greenStars} alt='Image broken' />
                                                        <p>2 days ago</p>
                                                    </div>
                                                    <p className='best-para'>I love this product because the support is great. Ple ...</p>
                                                    <h6 className='traveller'>Worldtraveler</h6>
                                                </div>
                                            </div>
                                        </div>
                                        <div>
                                            <div className="card customer-card">
                                                <div className="card-body best">
                                                    <img src={IMAGE.quote} alt='Image broken' />
                                                    <h6>Best on the market</h6>
                                                    <div className='rating-time'>
                                                        <img className="" src={IMAGE.greenStars} alt='Image broken' />
                                                        <p>2 days ago</p>
                                                    </div>
                                                    <p className='best-para'>I love this product because the support is great. Ple ...</p>
                                                    <h6 className='traveller'>Worldtraveler</h6>
                                                </div>
                                            </div>
                                        </div>
                                    </Slider>
                                </div>
                            </div>
                        </div>
                    </div>
                </Suspense>
                : <LoadingScreen />}
        </>
    )
}

export default Pricing
