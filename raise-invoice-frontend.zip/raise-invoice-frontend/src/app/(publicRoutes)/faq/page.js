'use client'
import React, { useEffect, useState, Suspense } from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faMagnifyingGlass, faEnvelope, faPhoneVolume } from '@fortawesome/free-solid-svg-icons';
import { IMAGE } from '@/utils/Theme';
import Link from 'next/link';
import './faq.css';
import Accordion from 'react-bootstrap/Accordion';
import Api from "../../../api/api";
import LoadingScreen from "@/Components/loadingScreen/LoadingScreen";

const Faqs = () => {
  const [error, setError] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [searchText, setSearchText] = useState(''); // State for search text  

  const [faqCategories, setFaqCategories] = useState(null);
  const [faqCategoryTitle, setFaqCategoryTitle] = useState('');
  const [faqs, setFaqs] = useState([]);
  const [isShowFaq, setIsShowFaq] = useState(false);
  const [faqCategorySlug, setFaqCategorySlug] = useState('');
  const [faqCategoryName, setFaqCategoryName] = useState('');
  const [faqCategoryImage, setFaqCategoryImage] = useState('');

  useEffect(() => {
    getFaqCategories(searchText);
  }, []);


  const getFaqCategories = async (searchText = '') => {
    setIsLoading(true);
    setError(null);
    try {
        const faqCategoryResponse = await Api.POST('get-faq-categories', {searchText: searchText});
        setFaqCategories(faqCategoryResponse.data.data);
    } catch (err) {
        setError("Failed to fetch Faq Category list.");
    } finally {
        setIsLoading(false);
    }
  };


  // Handle input change and trigger debounced search
  const handleSearchInput = (e) => {
    const value = e.target.value;
    setSearchText(value);
    getFaqList(faqCategorySlug, faqCategoryName); // Call the debounced function
  };

  const handleGetFaq = async (e, faqCategorySlug, faqCategoryName, faqCategoryImage) => {
    e.preventDefault();
    setFaqCategorySlug(faqCategorySlug);
    setFaqCategoryName(faqCategoryName);
    setFaqCategoryImage(faqCategoryImage);
    getFaqList(faqCategorySlug, faqCategoryName);
  }
  const getFaqList = async (faqCategorySlug = '', faqCategoryName = '') => {
    setIsShowFaq(true);
    setFaqCategoryTitle(faqCategoryName);
    setIsLoading(true);
    setError(null);
    try {
        const faqResponse = await Api.POST('get-faq-by-category', {searchText: searchText, slug: faqCategorySlug});
        setFaqs(faqResponse.data.data);
    } catch (err) {
        setError("Failed to fetch Faq Category list.");
    } finally {
        setIsLoading(false);
    }
  }
  const handleBackToFaqCategory = (e) => {
    e.preventDefault();
    setIsShowFaq(false);
    setSearchText('');
    setFaqCategorySlug('');
    setFaqCategoryName('');
    setFaqCategoryImage('');
  }

  return (
    <>
      {!isLoading ?
        <div className='faq-section'>

          <div className='container'>
            <div className="row">
              <div className="col-lg-8">
                <div className="left-top">
                  <h4>FAQs</h4>
                  <h4>Ask us anything</h4>
                  <p>Have any questions? We&apos;re here to assist you.</p>
                  <div className="search-container">
                    <button className="search-button">
                      <FontAwesomeIcon onClick={handleSearchInput} className="search-icon" icon={faMagnifyingGlass} />
                    </button>
                    <input
                      type='text'
                      className='search-input'
                      placeholder='Search Questions...'
                      value={searchText}
                      onChange={handleSearchInput} // Trigger search on typing
                    />
                  </div>
                </div>


                {/* {isLoading ? (
                  <p>Loading...</p>
                ) : error ? (
                  <p className='error'>{error}</p>
                ) : data1.length > 0 ? (
                  data1.map((faq) => (
                    <div className='faq-cards' key={faq.id}>
                      <div className='card mb-3'>
                        <div className='card-body card-details'>
                          <img className='profile-img' src={IMAGE.user} alt='Profile' />
                          <div>
                            <h4>{faq.name}</h4>
                            <p>{faq.description}</p>
                          </div>
                          <Link href={{}}>
                            <img src={IMAGE.rightArrow} alt='Right Arrow' />
                          </Link>
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <p>No FAQs found.</p>
                )} */}
                <Suspense fallback={<p>Loading...</p>}>
                  <div className="faq-cards">
                    {!isShowFaq ? 
                      <div className="row">
                        { faqCategories && 
                          faqCategories.map((faqCategory, i) => (
                            <div className="col-lg-6" key={i}>
                              <div className="card faqCard mb-3">
                                <div className="card-body card-details">
                                  <div className=" card-details-leftt">

                                    <img className="profile-img" src={faqCategory.image ? `${process.env.serverUrl}uploads/faq/${faqCategory?.image}` : IMAGE.user} alt='Image broken' style={{width:'40px', height:'40px'}} />
                                    <div>
                                      <h4>{faqCategory.name}</h4>
                                      <p>{ faqCategory.description }</p>
                                      {/* <div dangerouslySetInnerHTML={{__html:faqCategory.description}} /> */}
                                    </div>
                                  </div>

                                  <Link href="javascript:void(0)" onClick={(e)=>handleGetFaq(e, faqCategory.slug, faqCategory.name, faqCategory.image ? `${process.env.serverUrl}uploads/faq/${faqCategory?.image}` : IMAGE.user)}><img src={IMAGE.rightArrow} alt='Image broken' /></Link>
                                </div>

                              </div>
                            </div>
                          ))
                        }

                      </div>
                    
                    :
                      <div className='faqs faq-home w-100'>
                        <div className='container'>
                          <div className="row">
                            <div className="col-lg-12 col-md-12 col-12">
                                <div className='d-flex justify-content-between'>
                                  <h4 className='faq-cat-title'>
                                    {faqCategoryImage ? 
                                    <img className="profile-img" src={faqCategoryImage} alt='Image broken' style={{width:'40px', height:'40px'}} /> 
                                    : ''}
                                    <span className='ml-10'>{faqCategoryTitle}</span>
                                  </h4>
                                  <Link href="javascript:void(0);" className='align-right' onClick={handleBackToFaqCategory}><img src={IMAGE.left_arw} alt='Image broken' /></Link>
                                </div>
                                <Accordion defaultActiveKey={0}>
                                  { faqs.length ? 
                                    faqs.map((faq, k) => (
                                      <Accordion.Item eventKey={k} key={k}>
                                        <Accordion.Header>{faq.question}</Accordion.Header>
                                        <Accordion.Body>
                                          <div dangerouslySetInnerHTML={{__html:faq.answer}} />
                                        </Accordion.Body>
                                      </Accordion.Item>
                                    ))
                                    :
                                    <Accordion.Item eventKey={0} key={0}>
                                      <Accordion.Body>
                                        <p>No questions are found.</p>
                                      </Accordion.Body>
                                    </Accordion.Item>
                                  }
                                </Accordion>
                            </div>
                          </div>
                        </div>
                      </div>
                    }
                  </div>
                </Suspense>
              </div>


          
              <div className="col-lg-4">
                <span className='help'>Help & Support</span>
                <div className="details mb-2">
                  <FontAwesomeIcon className='faq-icon' icon={faEnvelope} />
                  <div>
                    <h4>Email Us</h4>
                    <p>raiseinvoice@gmail.com</p>
                  </div>
                </div>
                <div className="details mb-2">
                  <FontAwesomeIcon className='faq-icon' icon={faPhoneVolume} />
                  <div>
                    <h4>Call Us</h4>
                    <p>1800 2502 2456</p>
                  </div>
                </div>
              </div>
              <div className="col-lg-8 order-sm-second">
                <div className='left-bottom'>
                  <div>
                    <h6>Still have questions?</h6>
                    <p>Can’t find the answer you’re looking for? Please chat to our friendly team.</p>
                  </div>
                  <Link className='getin-touch' href={{}}>Get in touch</Link>
                </div>
              </div> 
            </div>
          </div>
        </div>
      : <LoadingScreen />}
    </>
  )
}

export default Faqs
