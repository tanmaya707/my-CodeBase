// import "bootstrap/dist/css/bootstrap.min.css";
// import "../globals.css";
import Header from '../../Components/header/Header';
import Footer from "../../Components/footer/footer";

export default function publicLayout({ children }) {
  return (
    <>
        <Header />
          {children}
        <Footer />
    </>
  );
}
