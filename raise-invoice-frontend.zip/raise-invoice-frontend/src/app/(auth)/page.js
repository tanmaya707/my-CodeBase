'use client'
import React, { useEffect, useState } from "react";
// import { setDispatch } from "../api/axiosInstance";
// import Banner from "@/Components/banner/Banner";
import Details from "@/Components/details/Details";
import Header from "@/Components/header/Header";
import Footer from "@/Components/footer/footer";
// import store from "@/dependencies/store/index";
import { useRouter } from 'next/navigation';
// import '../Components/banner/banner.css'

export default function Home() {
  const router = useRouter();
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  // useEffect(() => {
  //   const authToken = (typeof localStorage !== 'undefined') ? localStorage.getItem("web-auth-token") : null;
  //   setIsAuthenticated(Boolean(authToken))
  //   if (!authToken) {
  //     // router.push('/');
  //   } else {
  //     router.push('/dashboard');
  //   }
  // }, [router]);

  return (
    isAuthenticated ? null :
    <>
      <Header />
      {/* <Banner /> */}
      <Details />
      <Footer />
    </>
  );
}