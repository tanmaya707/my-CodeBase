"use client";
import React, { useCallback, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { IMAGE } from "@/utils/Theme";
import Leftpanel from "@/Components/leftpanel/leftpanel";
import Link from "next/link";
import { ToastContainer, toast } from "react-toastify";
import { signin } from "@/redux/slices/authSlice";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEye, faEyeSlash } from "@fortawesome/free-solid-svg-icons";
import { AiOutlineExclamationCircle } from "react-icons/ai";
import { useRouter } from "next/navigation";
import "./login.css";
import "./login-signup-responsive.css";
import "react-toastify/dist/ReactToastify.css";

const LogIn = () => {
  const dispatch = useDispatch();
  const router = useRouter();
  const { isLoading } = useSelector((s) => s.auth);

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  // store plain error messages; render with icon where needed
  const [formErrors, setFormErrors] = useState({});

  const validateField = useCallback((name, value) => {
    if (name === "email") {
      if (!value) return "Email is required.";
      if (!/\S+@\S+\.\S+/.test(value)) return "Email format is invalid.";
      return "";
    }

    if (name === "password") {
      if (!value) return "Password is required.";
      if (value.length < 6) return "Password must be at least 6 characters long.";
      if (!/[A-Z]/.test(value)) return "Password must contain at least one uppercase letter.";
      if (!/[a-z]/.test(value)) return "Password must contain at least one lowercase letter.";
      if (!/[0-9]/.test(value)) return "Password must contain at least one number.";
      if (!/[!@#$%^&*]/.test(value)) return "Password must contain at least one special character.";
      return "";
    }

    return "";
  }, []);

  const validateForm = useCallback(() => {
    const emailErr = validateField("email", email);
    const passwordErr = validateField("password", password);
    const errors = {};
    if (emailErr) errors.email = emailErr;
    if (passwordErr) errors.password = passwordErr;
    return errors;
  }, [email, password, validateField]);

  const handleEmailChange = (e) => {
    const v = e.target.value;
    setEmail(v);
    // clear or update email error live
    setFormErrors((prev) => {
      const next = { ...prev };
      const err = validateField("email", v);
      if (err) next.email = err;
      else delete next.email;
      return next;
    });
  };

  const handlePasswordChange = (e) => {
    const v = e.target.value;
    setPassword(v);
    // clear or update password error live
    setFormErrors((prev) => {
      const next = { ...prev };
      const err = validateField("password", v);
      if (err) next.password = err;
      else delete next.password;
      return next;
    });
  };

  const submitForm = async (e) => {
    e.preventDefault();
    const errors = validateForm();
    setFormErrors(errors);

    if (Object.keys(errors).length) return;

    const userData = { email, password, deviceType: 1 };
    try {
      const login = await dispatch(signin(userData)).unwrap();
      if (login && login.status) {
        const { user } = login.data || {};
        if (user && user.database_name) {
          toast.success("Login successful.");
          router.push("/dashboard");
        } else {
          toast.info("Please complete your company details.");
          router.push("/company-details");
        }
      } else {
        toast.error("Login failed. Please check your credentials.");
      }
    } catch (err) {
      console.error("Signin error:", err);
      toast.error("An error occurred during login.");
      setFormErrors((prev) => ({ ...prev, signin: "Signin failed." }));
    }
  };

  const renderError = (key) =>
    formErrors[key] ? (
      <p className="text-danger text-start">
        <AiOutlineExclamationCircle /> {formErrors[key]}
      </p>
    ) : null;

  return (
    <div className="login">
      <div className="row g-0">
        <div className="col-lg-5">
          <Leftpanel />
        </div>

        <div className="col-lg-7">
          <div className="rightpanel">
            <img src={IMAGE.dahbordRight} className="auth_bg" alt="background" />

            <h4>Log In to RaiseInvoice</h4>
            <p className="start-invoice">Start Your Invoicing</p>

            <div className="social-icons">
              <Link href="#">
                <img src={IMAGE.google} alt="google" />
              </Link>
              <Link href="#">
                <img src={IMAGE.apple} alt="apple" />
              </Link>
              <Link className="microsoft" href="#">
                <img src={IMAGE.microsoft} alt="microsoft" />
              </Link>
            </div>

            <p className="my-3 continue-with">Or Login With</p>

            <form onSubmit={submitForm} className="login-form" noValidate>
              <div className={`form-groupTop ${formErrors.email ? "inputErrorTop" : ""}`}>
                <div className="form-group mb-1">
                  <input
                    type="email"
                    className={`form-control ${formErrors.email ? "input-error" : ""}`}
                    value={email}
                    onChange={handleEmailChange}
                    placeholder="Email"
                    autoComplete="email"
                  />
                </div>
                <div className="mb-1">{renderError("email")}</div>
              </div>

              <div className={`form-groupTop ${formErrors.password ? "inputErrorTop" : ""}`}>
                <div className="form-group eyeButton mb-1">
                  <input
                    type={showPassword ? "text" : "password"}
                    className={`form-control ${formErrors.password ? "input-error" : ""}`}
                    value={password}
                    onChange={handlePasswordChange}
                    placeholder="Password"
                    autoComplete="current-password"
                  />
                  <FontAwesomeIcon
                    className="eyeIcon"
                    icon={showPassword ? faEyeSlash : faEye}
                    onClick={() => setShowPassword((s) => !s)}
                    style={{ cursor: "pointer" }}
                  />
                </div>
                <div className="mb-1">{renderError("password")}</div>
              </div>

              <div className="forgetpassword">
                <div className="checkbox">
                  <input type="checkbox" id="logged" name="logged" value="true" />
                  <p>Stay logged in</p>
                </div>
                <Link className="forget-pass" href="/forgotPass">
                  Forgot password?
                </Link>
              </div>

              <div className="loginSignUpBottom">
                <button type="submit" className="login-btn my-5" disabled={isLoading}>
                  {isLoading ? "Login..." : "Login"}
                  <img className="bluearrow" src={IMAGE.blue_arrow} alt="arrow" />
                </button>

                <p>
                  Don't have an account?
                  <Link className="signupPageBtn" href="/signup">
                    Sign Up
                  </Link>
                </p>
              </div>
            </form>

            <p className="trouble-login">
              Any Trouble Logging in? Contact our{" "}
              <Link href="#">
                Customer Support <img src={IMAGE.headphone} alt="support" />
              </Link>
            </p>
          </div>
        </div>
      </div>
      <ToastContainer position="top-right" autoClose={3000} hideProgressBar />
    </div>
  );
};

export default LogIn;
