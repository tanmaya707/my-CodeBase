"use client"
import "bootstrap/dist/css/bootstrap.min.css";
// import "../../globals.css";
import Header from "../../../Components/authHeader/authHeader"

export default function authLayout({ children }) {

    return (
        <>
            <Header />
            {children}
        </>
    )
}