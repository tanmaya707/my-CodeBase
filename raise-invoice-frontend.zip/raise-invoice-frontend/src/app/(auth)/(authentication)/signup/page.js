"use client";
import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { signup } from "@/redux/slices/authSlice";
import { IMAGE } from "@/utils/Theme";
import Leftpanel from "@/Components/leftpanel/leftpanel";
import Link from "next/link";
import "./signup.css";
import "../login/login.css";
import "../login/login-signup-responsive.css";

import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useRouter } from "next/navigation";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEye, faEyeSlash } from "@fortawesome/free-solid-svg-icons";
import { AiOutlineExclamationCircle } from "react-icons/ai";

const SignUp = () => {
  const [showPassword, setShowPassword] = useState(false);

  const router = useRouter();
  // useEffect(() => {
  //   const authToken =
  //     typeof localStorage !== "undefined"
  //       ? localStorage.getItem("web-auth-token")
  //       : null;

  //   if (authToken) {
  //     router.push("/dashboard");
  //   }
  // }, [router]);
  const dispatch = useDispatch();
  const { isLoading } = useSelector((state) => state.auth);

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [termsAgreed, setTermsAgreed] = useState(false);
  const [marketingAgreed, setMarketingAgreed] = useState(false);
  const [formErrors, setFormErrors] = useState({});

  // single-field validation used onChange to clear errors as soon as user rectifies
  const validateField = (field, value) => {
    setFormErrors((prev) => {
      const { [field]: removed, ...rest } = prev;
      // We'll only return 'rest' if field is valid; otherwise set new error for that field
      const makeError = (msg) => ({
        ...rest,
        [field]: (
          <span>
            <AiOutlineExclamationCircle />
            {msg}
          </span>
        ),
      });

      switch (field) {
        case "name": {
          if (!value) return makeError("Name is required.");
          if (value.length < 2) return makeError("Name must be at least 2 characters long.");
          if (!/^[a-zA-Z\s]+$/.test(value)) return makeError("Name can only contain letters and spaces.");
          return rest; // valid -> remove error
        }
        case "email": {
          if (!value) return makeError("Email is required.");
          if (!/\S+@\S+\.\S+/.test(value)) return makeError("Email format is invalid.");
          return rest;
        }
        case "password": {
          if (!value) return makeError("Password is required");
          if (value.length < 6) return makeError("Password must be at least 6 characters long.");
          if (!/[A-Z]/.test(value)) return makeError("Password must contain at least one uppercase letter.");
          if (!/[a-z]/.test(value)) return makeError("Password must contain at least one lowercase letter.");
          if (!/[0-9]/.test(value)) return makeError("Password must contain at least one number.");
          if (!/[!@#$%^&*]/.test(value)) return makeError("Password must contain at least one special character.");
          return rest;
        }
        case "termsAgreed": {
          if (!value) return makeError("You must agree to the terms and conditions.");
          return rest;
        }
        default:
          return rest;
      }
    });
  };

  // full form validation on submit
  const validateForm = () => {
    const errors = {};

    // Name validation
    if (!name) {
      errors.name = (
        <span>
          <AiOutlineExclamationCircle />
          Name is required.
        </span>
      );
    } else if (name.length < 2) {
      errors.name = (
        <span>
          <AiOutlineExclamationCircle />
          Name must be at least 2 characters long.
        </span>
      );
    } else if (!/^[a-zA-Z\s]+$/.test(name)) {
      errors.name = (
        <span>
          <AiOutlineExclamationCircle />
          Name can only contain letters and spaces.
        </span>
      );
    }

    // Email validation
    if (!email) {
      errors.email = (
        <span>
          <AiOutlineExclamationCircle />
          Email is required.
        </span>
      );
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      errors.email = (
        <span>
          <AiOutlineExclamationCircle />
          Email format is invalid.
        </span>
      );
    }

    // Password validation
    if (!password) {
      errors.password = (
        <span>
          <AiOutlineExclamationCircle />
          Password is required
        </span>
      );
    } else if (password.length < 6) {
      errors.password = (
        <span>
          <AiOutlineExclamationCircle />
          Password must be at least 6 characters long.
        </span>
      );
    } else if (!/[A-Z]/.test(password)) {
      errors.password = (
        <span>
          <AiOutlineExclamationCircle />
          Password must contain at least one uppercase letter.
        </span>
      );
    } else if (!/[a-z]/.test(password)) {
      errors.password = (
        <span>
          <AiOutlineExclamationCircle />
          Password must contain at least one lowercase letter.
        </span>
      );
    } else if (!/[0-9]/.test(password)) {
      errors.password = (
        <span>
          <AiOutlineExclamationCircle />
          Password must contain at least one number.
        </span>
      );
    } else if (!/[!@#$%^&*]/.test(password)) {
      errors.password = (
        <span>
          <AiOutlineExclamationCircle />
          Password must contain at least one special character.
        </span>
      );
    }

    // Terms agreement validation
    if (!termsAgreed) {
      errors.termsAgreed = (
        <span >
          <AiOutlineExclamationCircle />
          You must agree to the terms and conditions.
        </span>
      );
    }

    return errors;
  };

  const submitForm = async (e) => {
    e.preventDefault();
    const errors = validateForm();
    setFormErrors(errors);

    if (Object.keys(errors).length === 0) {
      const userData = { name, email, password, deviceType: 1 };
      try {
        const signupClient = await dispatch(signup(userData)).unwrap();
        if (signupClient?.status === false) {
          toast.warning(signupClient?.message || "Signup failed. Please try again.");
          setFormErrors((prev) => ({ ...prev, signup: true }));
          return;
        }
        if (signupClient.data.userDetails.isVerified) {
          // router.push(`/dashboard`);
          window.location.href = `/dashboard`;
          toast.success("Signup successful.");
        } else {
          // router.push(`/company-details`);
          window.location.href = `/company-details`;
          toast.info("Please complete your company details.");
        }
        // router.push(`/dashboard`);
      } catch (err) {
        toast.warning(err.message || "Signup failed.");
        setFormErrors((prev) => ({ ...prev, signup: true }));
      }
    } else {
      // focus first error field (optional UX improvement)
      const firstError = Object.keys(errors)[0];
      if (firstError === "name") {
        document.getElementById("signup-name")?.focus();
      } else if (firstError === "email") {
        document.getElementById("signup-email")?.focus();
      } else if (firstError === "password") {
        document.getElementById("signup-password")?.focus();
      }
    }
  };

  return (
    <>
      <div className="signup">
        <div className="row g-0">
          <div className="col-lg-5 col-md-6 col-12">
            <Leftpanel />
          </div>

          <div className="col-lg-7 col-md-6 col-12">
            <div
              className={`rightpanel sign-up-rightpanel ${
                formErrors.name ||
                formErrors.email ||
                formErrors.password ||
                formErrors.termsAgreed
                  ? "signupFormErrorPadding"
                  : ""
              }`}
            >
              <img src={IMAGE.auth_bg} className="auth_bg" />
              <div className="star-text">
                <span>
                  <img src={IMAGE.stars} />
                </span>
                <p className="rating">Most Trusted By Small Business Owners</p>
              </div>
              <h4>
                Start Your free 30 days trial with <span>RaiseInvoice</span>
              </h4>
              <div className="start-invoicing-all">
                <p className="start-invoicing">Send Invoices</p>
                <p className="start-invoicing"> Accept Payments </p>
                <p className="start-invoicing"> Manage Cash Flow </p>
                <p className="start-invoicing">Manage Projects</p>
              </div>

              <form onSubmit={submitForm} className="login-form signup-form" noValidate>
                <div className={`form-groupTop ${formErrors.name ? "inputErrorTop" : ""}`}>
                  <div className="form-group">
                    <input
                      id="signup-name"
                      type="text"
                      className={`form-control ${formErrors.name ? "input-error" : ""}`}
                      value={name}
                      onChange={(e) => {
                        const v = e.target.value;
                        setName(v);
                        validateField("name", v);
                      }}
                      placeholder="Name"
                      aria-invalid={!!formErrors.name}
                    />
                  </div>
                  <div className="mb-2">{formErrors.name && <p className="text-danger text-start">{formErrors.name}</p>}</div>
                </div>

                <div className={`form-groupTop ${formErrors.email ? "inputErrorTop" : ""}`}>
                  <div className="form-group">
                    <input
                      id="signup-email"
                      type="email"
                      className={`form-control ${formErrors.email ? "input-error" : ""}`}
                      value={email}
                      onChange={(e) => {
                        const v = e.target.value;
                        setEmail(v);
                        validateField("email", v);
                      }}
                      placeholder="Email"
                      aria-invalid={!!formErrors.email}
                    />
                  </div>
                  <div className="mb-2">{formErrors.email && <p className="text-danger text-start">{formErrors.email}</p>}</div>
                </div>

                <div className={`form-groupTop ${formErrors.password ? "inputErrorTop" : ""}`}>
                  <div className="form-group eyeButton">
                    <input
                      id="signup-password"
                      type={showPassword ? "text" : "password"}
                      className={`form-control ${formErrors.password ? "input-error" : ""}`}
                      value={password}
                      onChange={(e) => {
                        const v = e.target.value;
                        setPassword(v);
                        validateField("password", v);
                      }}
                      placeholder="Password"
                      aria-invalid={!!formErrors.password}
                    />
                    <FontAwesomeIcon
                      className="eyeIcon"
                      icon={showPassword ? faEyeSlash : faEye}
                      onClick={() => setShowPassword((prev) => !prev)}
                      style={{ cursor: "pointer" }}
                    />
                  </div>
                  <div className="mb-2">{formErrors.password && <p className="text-danger text-start">{formErrors.password}</p>}</div>
                </div>

                <div className="termsandcondition">
                  <div className="terms checkbox">
                    <input
                      type="checkbox"
                      checked={termsAgreed}
                      onChange={() => {
                        const nxt = !termsAgreed;
                        setTermsAgreed(nxt);
                        validateField("termsAgreed", nxt);
                      }}
                      id="terms"
                    />
                    <p>
                      I&apos;ve read and agreed to the terms of use, privacy notice, and offer details:
                      <Link href="#">Terms of use</Link>, <Link href="#">Privacy notice</Link>, and{" "}
                      <Link href="#">Offer details</Link>.
                    </p>
                  </div>
                  <div>{formErrors.termsAgreed && <p className="text-danger">{formErrors.termsAgreed}</p>}</div>
                  <div className="terms checkbox">
                    <input
                      type="checkbox"
                      checked={marketingAgreed}
                      onChange={() => setMarketingAgreed((prev) => !prev)}
                      id="marketing"
                    />
                    <p>Please send me marketing communications</p>
                  </div>
                </div>

                <div className="loginSignUpBottom">
                  <button type="submit" className={isLoading ? "login-btn login-btnLoading my-3" : "login-btn my-3" }  disabled={isLoading}>
                    {isLoading ? "Signing Up..." : "Signup"}
                    <img className="bluearrow" src={IMAGE.blue_arrow} />
                  </button>
                  <p>
                    Already have an account?
                    <Link className="signupPageBtn" href="/login">
                      Sign in
                    </Link>
                  </p>
                </div>
              </form>

              {/* {formErrors.signup && <p className="error-message">Signup failed. Please try again.</p>} */}

              <p className="login-width">Or Continue With</p>
              <div className="social-icons my-3">
                <Link href={{}}>
                  <img src={IMAGE.google} alt="Image broken" />
                </Link>
                <Link href={{}}>
                  <img src={IMAGE.apple} alt="Image broken" />
                </Link>
                <Link href={{}}>
                  <img src={IMAGE.microsoft} alt="Image broken" />
                </Link>
              </div>

              <p className="trouble-login">
                Any Trouble Logging in? Contact our{" "}
                <Link href={{}}>
                  Customer Support <img src={IMAGE.headphone} />
                </Link>
              </p>
            </div>
          </div>
        </div>
      </div>

      <ToastContainer position="top-right" autoClose={3000} hideProgressBar />
    </>
  );
};

export default SignUp;
