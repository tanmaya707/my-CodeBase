'use client';

import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import '../login/login.css';
import './forgotpass.css';
import { IMAGE } from '@/utils/Theme';
import { resetPasswordMail } from "@/redux/slices/dataSlice";
import { toast } from 'react-toastify';
import Link from 'next/link';

function ForgotPass() {
  const [email, setEmail] = useState('');
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const dispatch = useDispatch();

  const getApiUrl = () => {
    if (typeof window !== 'undefined') {
      return window.location.origin + '/forgotPassReset';
    }
    return '';
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const mailData = {
        to: email,
        subject: 'Reset Your Password',
        link: `${getApiUrl()}`
      };
      try {
        const result = await dispatch(resetPasswordMail(mailData)).unwrap();
        if (result && result.status === true) {
          toast.success("Mail sent successfully!");
          setSent(true);
        } else {
          toast.error(result.error || "Failed to send mail.");
        }
      } catch (err) {
        toast.error("Failed to send mail.");
      }
    } catch (err) {
      setError('Failed to send reset link. Please try again.');
    }
    setLoading(false);
  };

  const handleEditEmail = () => {
    setSent(false);
  };

  return (
    <div className='forgotPass'>
      <div className='container'>
        <div className="forgotpass-div">
        <div className={sent ? 'forgotPassSent' : ''}>

          {sent ? (
            <div className="success-message">
                <img
                  src={IMAGE.reset}
                  alt="Reset"
                  className="reset-image"
                />
              <p style={{ fontSize: '21px', color: 'black' }}>
                Reset link sent! Please check your email.<br />
                <span className="sent-email" style={{ fontSize: '17px', color: 'red' }}>
                  {email}
                  <button
                    className="edit-email-btn"
                    onClick={handleEditEmail}
                    style={{
                      background: 'none',
                      border: 'none',
                      cursor: 'pointer',
                      marginLeft: '8px',
                      verticalAlign: 'middle'
                    }}
                    aria-label="Edit email"
                  >
                    <img
                      src={IMAGE.edit}
                      alt="Edit"
                      style={{ width: '16px', height: '16px' }}
                    />
                  </button>
                </span>
              </p>
            </div>
          ) : (
            <form className='login-form' onSubmit={handleSubmit}>
              <img src={IMAGE.auth_bg} className='auth_bg' alt='Image broken' />
              <h1>Forgot Password?</h1>
              <p className='start-invoicing'>
                To reset your password, enter the email address you signed up with.
              </p>
              <div className='form-group'>
                <input
                  type="email"
                  className='form-control'
                  value={email}
                  placeholder='Email'
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
            <button 
            type="submit"
            className="login-btn my-5"
            style={loading ? { display: 'flex', justifyContent: 'center', alignItems: 'center', padding:"8px 15px 8px 15px"  } : {}}
            disabled={loading}
          >
            {loading ? 'Sending...' : (
              <>
                Send Reset Link
                <img className='bluearrow' src={IMAGE.blue_arrow} alt='Image broken' />
              </>
            )}
          </button>

              {error && <p className="error-message">{error}</p>}
            </form>
          )}
        
            <p className="trouble-login mt-3">
            <Link className={sent ? 'login-btn' : ''}  href='/login'>Back to Login</Link>
          </p>
        </div>
        </div>

      </div>
    </div>
  );
}

export default ForgotPass;