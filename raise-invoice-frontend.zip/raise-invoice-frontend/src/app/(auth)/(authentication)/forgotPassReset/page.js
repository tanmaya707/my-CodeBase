'use client';
import React, { useState, useEffect, Suspense } from 'react';
import { IMAGE } from '@/utils/Theme';
import Link from 'next/link';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEye, faEyeSlash } from '@fortawesome/free-solid-svg-icons';
import { DotLottieReact } from '@lottiefiles/dotlottie-react';
import { resetPassword } from '@/redux/slices/dataSlice';
import '../login/login.css';
import './forgotpass.css';
import { useDispatch } from 'react-redux';
import { AiOutlineExclamationCircle } from 'react-icons/ai';
import { useSearchParams } from 'next/navigation';

function ForgotPassResetInner() {
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [formErrors, setFormErrors] = useState({});
  const [password, setPassword] = useState('');
  const [passwordConfrm, setPasswordConfrm] = useState('');
  const [tokenValid, setTokenValid] = useState(null);
  const [apiError, setApiError] = useState('');
  const [resetSuccess, setResetSuccess] = useState(false);
  const [loading, setLoading] = useState(false);

  const dispatch = useDispatch();
  const searchParams = useSearchParams();
  const token = searchParams.get('token');

  useEffect(() => {
    async function verifyToken() {
      if (token) {
        const result = await dispatch(resetPassword({ otp: token })).unwrap();
        if (result.status) {
          setTokenValid(true);
        } else {
          setTokenValid(false);
          setApiError(result.message || 'Invalid or expired token.');
        }
      } else {
        setTokenValid(false);
        setApiError('Token not found.');
      }
    }
    verifyToken();
  }, [token, dispatch]);

  const handleSubmit = async (e) => {
    setLoading(true);
    e.preventDefault();
    let errors = {};

    if (!password) {
      errors.password = (
        <span>
          <AiOutlineExclamationCircle /> Password is required
        </span>
      );
    } else if (password.length < 6) {
      errors.password = (
        <span>
          <AiOutlineExclamationCircle /> Password must be at least 6 characters
          long.
        </span>
      );
    } else if (!/[A-Z]/.test(password)) {
      errors.password = (
        <span>
          <AiOutlineExclamationCircle /> Password must contain at least one
          uppercase letter.
        </span>
      );
    } else if (!/[a-z]/.test(password)) {
      errors.password = (
        <span>
          <AiOutlineExclamationCircle /> Password must contain at least one
          lowercase letter.
        </span>
      );
    } else if (!/[0-9]/.test(password)) {
      errors.password = (
        <span>
          <AiOutlineExclamationCircle /> Password must contain at least one
          number.
        </span>
      );
    } else if (!/[!@#$%^&*]/.test(password)) {
      errors.password = (
        <span>
          <AiOutlineExclamationCircle /> Password must contain at least one
          special character.
        </span>
      );
    }

    if (!passwordConfrm) {
      errors.passwordConfrm = (
        <span>
          <AiOutlineExclamationCircle /> Confirm password is required
        </span>
      );
    } else if (password !== passwordConfrm) {
      errors.passwordConfrm = (
        <span>
          <AiOutlineExclamationCircle /> Confirm password does not match
        </span>
      );
    }

    setFormErrors(errors);
      setFormErrors(errors);
      if (Object.keys(errors).length) {
        setLoading(false);
        return;
      }

    const data = {
      otp: token,
      password: password,
      confirm_password: passwordConfrm,
    };

    const res = await dispatch(resetPassword(data)).unwrap();
    if (res.status) {
      setResetSuccess(true);
    } else {
      setApiError(res.message || 'Failed to reset password.');
    }
    setLoading(false);
  };

  return (
    <div className="forgotPass">
      <div className="container">
        {tokenValid === null && (
          <div className="forgotpass-div">
            <img src={IMAGE.auth_bg} className="auth_bg" alt="Image broken" />
            <h1>Verifying Token...</h1>
          </div>
        )}

        {tokenValid === false && (
          <div className="forgotpass-div">
            <img src={IMAGE.auth_bg} className="auth_bg" alt="Image broken" />
            <p className="start-invoicing">{apiError}</p>
            <p className="trouble-login">
              <Link href="/login">Back to Login </Link>
            </p>
          </div>
        )}

        {tokenValid === true && !resetSuccess && (
          <div className="forgotpass-div">
            <img src={IMAGE.auth_bg} className="auth_bg" alt="Image broken" />
            <h1>Reset Your Password</h1>
            <p className="start-invoicing">
              To reset your password, enter new password and confirm password.
            </p>
            <form className="login-form" onSubmit={handleSubmit}>
              <div className="form-group eyeButton mb-3">
                <input
                  type={showPassword ? 'text' : 'password'}
                  className={`form-control ${formErrors.password ? 'input-error' : ''}`}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="New Password"
                />
                <FontAwesomeIcon
                  className="eyeIcon"
                  icon={showPassword ? faEyeSlash : faEye}
                  onClick={() => setShowPassword((prev) => !prev)}
                  style={{ cursor: 'pointer' }}
                />
              </div>
              {formErrors.password && (
                <p
                  className="text-danger text-start"
                  style={{ fontSize: '13px' }}
                >
                  {formErrors.password}
                </p>
              )}

              <div className="form-group eyeButton mb-3">
                <input
                  type={showConfirmPassword ? 'text' : 'password'}
                  className={`form-control ${formErrors.passwordConfrm ? 'input-error' : ''}`}
                  value={passwordConfrm}
                  onChange={(e) => setPasswordConfrm(e.target.value)}
                  placeholder="Confirm Password"
                />
                <FontAwesomeIcon
                  className="eyeIcon"
                  icon={showConfirmPassword ? faEyeSlash : faEye}
                  onClick={() => setShowConfirmPassword((prev) => !prev)}
                  style={{ cursor: 'pointer' }}
                />
              </div>
              {formErrors.passwordConfrm && (
                <p
                  className="text-danger text-start"
                  style={{ fontSize: '13px' }}
                >
                  {formErrors.passwordConfrm}
                </p>
              )}

              {apiError && <div className="error mb-2">{apiError}</div>}

              {/* {loading ? 'Sending...' : (
                        <>
                           <button type="submit" className='login-btn my-5'>
                            Update Password <img className='bluearrow' src={IMAGE.blue_arrow} alt='Image broken' />

                          </button>
                        </>
                      )} */}

              <button
                type="submit"
                className="login-btn my-5"
                style={loading ? { display: 'flex', justifyContent: 'center', alignItems: 'center', padding:"8px 15px 8px 15px"  } : {}}
                disabled={loading}
              >
                {loading ? (
                  'Sending...'
                ) : (
                  <>
                    Update Password
                    <img
                      className="bluearrow"
                      src={IMAGE.blue_arrow}
                      alt="Image broken"
                    />
                  </>
                )}
              </button>
            </form>
            <p className="trouble-login">
              <Link href="/login">Back to Login </Link>
            </p>
          </div>
        )}

        {resetSuccess && (
          <div className="successfulMessage">
            <DotLottieReact
              src="https://lottie.host/f6b705be-52d8-4768-a900-6d25ad0d8e94/T7dLeeN75k.lottie"
              autoplay
            />
            <h2>Password Reset Successful!</h2>
            <p>Your password has been updated.</p>
            <p className="trouble-login">
              <Link href="/login">Back to Login </Link>
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

export default function ForgotPassReset() {
  return (
    <Suspense fallback={<div>Loading...</div>}>
      <ForgotPassResetInner />
    </Suspense>
  );
}
