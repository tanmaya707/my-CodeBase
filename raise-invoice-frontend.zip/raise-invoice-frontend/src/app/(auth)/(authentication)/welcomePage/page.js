import React from 'react'

import '../login/login.css'
import '../forgotPass/forgotpass.css'
import './welcome.css'
import { IMAGE } from '@/utils/Theme'
import Link from 'next/link';

function welcomePage()  {
  return (
    <div>
    <div className='forgotPass welcomePagedcustm'>
    <div className='container'>
      <div className=' forgotpass-div'>
        <img src={IMAGE.auth_bg} className='auth_bg' alt='Image broken' />

        <h1 >Hi Nehal! Welcome to
        <span>RaiseInvoice</span> 
        <img src={IMAGE.quoteimg} className='quoteimage' alt='Image broken' />
        </h1>
        <p className='start-invoicing'>Thank you for choosing us. <span>Your free 30 days trial has</span>  started </p>

        <Link className='login-btn my-5' href={{}}>Create Your First Invoice <img className='bluearrow' src={IMAGE.blue_arrow} alt='Image broken' /></Link>

      </div>

      <div className='welcomeHand-div'>
        <img src={IMAGE.welcomeHand} className='welcomeHand' alt='Image broken' />
        </div>
    </div>
    </div>
  </div>
  )
}

export default welcomePage