"use client"
import "bootstrap/dist/css/bootstrap.min.css";
import { useEffect, useState } from "react";
import UnprotectedRoute from "@/Components/UnprotectedRoutes";

export default function authLayout({ children }) {

  const [isAuthenticated, setIsAuthenticated] = useState(false);
    useEffect(() => {
        const authToken = Boolean((typeof localStorage !== 'undefined') ? localStorage.getItem("web-auth-token") : null);
        setIsAuthenticated(authToken)
    }, []);

    return (
        <>
            <UnprotectedRoute isAuthenticated={isAuthenticated}>
                {children}
            </UnprotectedRoute>
        </>
    )
}