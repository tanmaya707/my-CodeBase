
'use client';
import "bootstrap/dist/css/bootstrap.min.css";
// import React, { useState, useEffect } from 'react'
import "./globals.css";
import { Provider } from "react-redux";
import store from "../redux/store/store";
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { Helmet, HelmetProvider } from 'react-helmet-async';
import { IMAGE } from '../utils/Theme';
import { usePathname } from 'next/navigation'
import ModalCommon from "@/Components/modalCommon/modalCommon";
import { ModalProvider } from "@/cotexts/modalContext";
import { DraggableProvider } from "@/cotexts/draggableContext";
import CommonDraggableModal from "@/Components/modalCommon/CommonDraggableModal";
// const metadata = {
//   title: "Raise Invoice",
//   description: "Raise Invoice",
// };

export default function RootLayout({ children }) {
  const pathname = usePathname()
  // const [domLoaded, setDomLoaded] = useState(false);
  // useEffect(() => {
  //   setDomLoaded(true);
  // }, []);
  

  const urlPaths = pathname.split('/');

  return (
    <html lang="en">
      <HelmetProvider>
        <Helmet>
          <meta charSet="utf-8" />
          <title>Raise Invoice</title>
          <meta name="description" content="Raise Invoice" />
          <link rel="icon" type="image/png" href={IMAGE.favicon} sizes="26x26" />
        </Helmet>
      </HelmetProvider>
      <body className={`${ urlPaths[1] ? urlPaths[1] : 'home' }-page`}>
          <ToastContainer />
          <DraggableProvider>
            <ModalProvider>
              <Provider store={store}>
                <ModalCommon />
                <CommonDraggableModal />
                    {children}
              </Provider>
            </ModalProvider>
          </DraggableProvider>
      </body>
    </html>
  );
}
// export default metadata;
