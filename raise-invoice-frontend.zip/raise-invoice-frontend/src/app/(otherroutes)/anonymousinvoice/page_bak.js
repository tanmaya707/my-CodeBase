'use client';
import React, { useState, useRef, useEffect } from 'react';
import { Modal } from 'react-bootstrap';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faArrowLeft, faSquarePlus, faCalendarDays, faTrash, faEdit, faTimes } from '@fortawesome/free-solid-svg-icons';
import jsPDF from "jspdf";
import html2canvas from "html2canvas";
import { v4 as uuidv4 } from 'uuid';
import Calendar from 'react-calendar';
import Image from 'next/image';
import {IMAGE} from '../../../utils/Theme'
import './anonymousinvoice.css';
import 'react-calendar/dist/Calendar.css';
import '../../../app/general.css';

const API_BASE = process.env.NEXT_PUBLIC_API_URL;
const INVOICE_LIMIT = 10;
const currencySymbols = { INR: '₹', USD: '$', EUR: '€', GBP: '£', JPY: '¥', AUD: 'A$', CAD: 'C$', SGD: 'S$', CNY: '¥' };
const TERMS_OPTIONS = [
    { value: "", label: "None", days: 0 },
    { value: "1", label: "Custom", days: 0 },
    { value: "2", label: "Next Day", days: 1 },
    { value: "3", label: "2 Days", days: 2 },
    { value: "4", label: "3 Days", days: 3 },
    { value: "5", label: "4 Days", days: 4 },
    { value: "6", label: "5 Days", days: 5 },
    { value: "7", label: "10 Days", days: 10 },
    { value: "8", label: "30 Days", days: 30 },
    { value: "9", label: "90 Days", days: 90 },
    { value: "10", label: "180 Days", days: 180 },
    { value: "11", label: "365 Days", days: 365 },
];

const defaultInvoice = {
    uuid: '',
    ip: '',
    logo: '',
    from: { name: '', businessName: '', email: '', address: '', phone: '', businessNumber: '' },
    billTo: { name: '', email: '', address: '', phone: '', mobile: '', fax: '' },
    number: '', date: '', due: '',
    items: [{ description: '', details: '', quantity: 0, price: 0 }],
    notes: '', signature: '', signatureData: '', photos: [],
    taxRate: 0, taxInclusive: false,
    discountType: 'percent', discountValue: 0,
    currency: 'INR', color: '#2b6cb0', taxLabel: 'Tax',
    paymentTerm: "",
};

function getImageSrc(fileOrBase64) {
    if (!fileOrBase64) return null;
    if (typeof window !== 'undefined' && fileOrBase64 instanceof File) {
        return URL.createObjectURL(fileOrBase64);
    }
    if (typeof fileOrBase64 === 'string' && fileOrBase64.startsWith('data:image')) {
        return fileOrBase64;
    }
    if (typeof fileOrBase64 === 'string' && fileOrBase64.length > 100) {
        return `data:image/png;base64,${fileOrBase64}`;
    }
    if (typeof fileOrBase64 === 'string' && fileOrBase64.startsWith('http')) {
        return fileOrBase64;
    }
    return null;
}

// Signature Pad
function SignaturePad({ value, onChange, color }) {
    const canvasRef = useRef(null);
    const [drawing, setDrawing] = useState(false);

    useEffect(() => {
        if (value && canvasRef.current) {
            const ctx = canvasRef.current.getContext('2d');
            const img = new window.Image();
            img.onload = () => {
                ctx.clearRect(0, 0, 600, 160);
                ctx.drawImage(img, 0, 0, 600, 160);
            };
            img.src = value.startsWith('data:image') ? value : `data:image/png;base64,${value}`;
        } else if (canvasRef.current) {
            const ctx = canvasRef.current.getContext('2d');
            ctx.clearRect(0, 0, 600, 160);
        }
    }, [value]);

    const getPos = (e) => {
        const canvas = canvasRef.current;
        const rect = canvas.getBoundingClientRect();
        let x, y;
        if (e.touches && e.touches.length) {
            x = e.touches[0].clientX - rect.left;
            y = e.touches[0].clientY - rect.top;
        } else {
            x = e.nativeEvent.offsetX !== undefined ? e.nativeEvent.offsetX : e.nativeEvent.layerX;
            y = e.nativeEvent.offsetY !== undefined ? e.nativeEvent.offsetY : e.nativeEvent.layerY;
        }
        return { x, y };
    };

    const handleStart = (e) => {
        e.preventDefault();
        setDrawing(true);
        const { x, y } = getPos(e);
        const ctx = canvasRef.current.getContext('2d');
        ctx.strokeStyle = color || '#222';
        ctx.lineWidth = 2.5;
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(x, y);
    };

    const handleMove = (e) => {
        if (!drawing) return;
        e.preventDefault();
        const { x, y } = getPos(e);
        const ctx = canvasRef.current.getContext('2d');
        ctx.lineTo(x, y);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(x, y);
    };

    const handleEnd = () => {
        if (!drawing) return;
        setDrawing(false);
        const canvas = canvasRef.current;
        const data = canvas.toDataURL();
        onChange(data);
    };

    const clearPad = () => {
        const canvas = canvasRef.current;
        const ctx = canvas.getContext('2d');
        ctx.clearRect(0, 0, 600, 160);
        onChange('');
    };

    return (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            <canvas
                ref={canvasRef}
                width={600}
                height={160}
                style={{ border: '1.5px solid #cbd5e1', borderRadius: 8, background: '#fff', touchAction: 'none', cursor: 'crosshair' }}
                onMouseDown={handleStart}
                onMouseUp={handleEnd}
                onMouseOut={handleEnd}
                onMouseMove={handleMove}
                onTouchStart={handleStart}
                onTouchEnd={handleEnd}
                onTouchCancel={handleEnd}
                onTouchMove={handleMove}
            />
            <button type="button" onClick={clearPad} style={{
                background: '#edf2f7', color: color, border: '1px solid #cbd5e1', borderRadius: 8,
                padding: '0.3rem 1rem', fontSize: '1rem', fontWeight: 500, cursor: 'pointer', width: 120
            }}>Clear</button>
        </div>
    );
}

// Invoice List Landing Page
function InvoiceLanding({ invoices, onEdit, onDelete, onCreate, limit }) {
    function formatDate(dateStr) {
        if (!dateStr) return '';
        const date = new Date(dateStr);
        const options = { year: 'numeric', month: 'short', day: 'numeric' };
        return date.toLocaleDateString('en-US', options);
    }

    return (
        <div className="invoice-list-landing">
            <h3>Saved Invoices ({invoices.length}/{limit})</h3>
        {/* ===============dynamic invoice listing================ */}
            <div className='invoiceListingTable'>
                <table className="invoice-table">
                    <thead>
                        <tr>
                        <th>#</th>
                        <th>Business Name</th>
                        <th>Date</th>
                        <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {invoices.length === 0 && (
                            <tr>
                                <td colSpan="4">No invoices found.</td>
                            </tr>
                        )}
                        {invoices.map((inv, idx) => {
                        let from = {};
                        try {
                            from = typeof inv.from === "string" ? JSON.parse(inv.from) : inv.from;
                        } catch {
                            from = inv.from || {};
                        }

                        return (
                            <tr key={inv.uuid || idx}>
                            <td>{inv.number}</td>
                            <td>{inv?.billTo.name || from.name}</td>
                            <td>{formatDate(inv.date)}</td>
                            <td>
                                <button onClick={() => onEdit(idx)} className="action-btn edit-btn">
                                <FontAwesomeIcon icon={faEdit} /> 
                                </button>
                                <button onClick={() => onDelete(idx)} className="action-btn delete-btn">
                                <FontAwesomeIcon icon={faTrash} /> 
                                </button>
                            </td>
                            </tr>
                        );
                        })}
                    </tbody>
                    </table>

            </div>
            {invoices.length >= limit && (
                <div className="limit-msg">Invoice limit exceeded for this network ({limit}). Delete one to create new.</div>
            )}
            <button
                className="primary-btn primaryNoBorder"
                style={{ marginTop: 10 }}
                onClick={onCreate}
                disabled={invoices.length >= limit}
            >
                <FontAwesomeIcon icon={faSquarePlus} /> Create Invoice
            </button>
        </div>
    );
}

// Invoice Form (Create/Edit)
function InvoiceForm({
    invoice, setInvoice, logoFile, setLogoFile, photoFiles, setPhotoFiles,
    onSave, tab, setTab, showCalendarStart, setShowCalendarStart,
    showCalendarDue, setShowCalendarDue, termsOptions
}) {
    const [show, setShow] = useState(false);
    const [itemModal, setItemModal] = useState({ description: '', details: '', quantity: 1, price: 0 });

    // Handlers
    const handleInput = (e, section) => {
        const { name, value } = e.target;
        if (section === 'from') setInvoice(inv => ({ ...inv, from: { ...inv.from, [name]: value } }));
        else if (section === 'billTo') setInvoice(inv => ({ ...inv, billTo: { ...inv.billTo, [name]: value } }));
        else setInvoice(inv => ({ ...inv, [name]: value }));
    };

    const handleLogoUpload = (e) => {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = () => {
                setLogoFile(reader.result);
                setInvoice(inv => ({ ...inv, logo: reader.result.split(',')[1] }));
            };
            reader.readAsDataURL(file);
        }
    };

    const handleLogoDelete = () => {
        setLogoFile(null);
        setInvoice(inv => ({ ...inv, logo: '' }));
    };

    const handlePhotoUpload = (e) => {
        const files = Array.from(e.target.files);
        const readers = files.map(file => {
            return new Promise(resolve => {
                const reader = new FileReader();
                reader.onload = () => resolve(reader.result);
                reader.readAsDataURL(file);
            });
        });
        Promise.all(readers).then(results => {
            setPhotoFiles(results);
            setInvoice(inv => ({ ...inv, photos: results.map(r => r.split(',')[1]) }));
        });
    };

    const handleSignatureChange = (data) => {
        setInvoice(inv => ({ ...inv, signatureData: data.startsWith('data:image') ? data.split(',')[1] : data }));
    };

    const handleAddItem = () => {
        setInvoice(inv => ({
            ...inv,
            items: [...inv.items, { ...itemModal }]
        }));
        setItemModal({ description: '', details: '', quantity: 1, price: 0 });
        setShow(false);
    };

    const handleRemoveItem = (idx) => {
        setInvoice(inv => ({
            ...inv,
            items: inv.items.filter((_, i) => i !== idx)
        }));
    };

    // Subtotal, Discount, Tax, Total
    const subtotal = invoice.items.reduce((sum, item) => sum + (Number(item.quantity) * Number(item.price)), 0);
    const discount = invoice.discountType === 'percent'
        ? subtotal * (Number(invoice.discountValue) / 100)
        : Number(invoice.discountValue);
    let tax = 0, total = 0;
    if (invoice.taxInclusive) {
        const divisor = 1 + (Number(invoice.taxRate) / 100);
        const taxable = subtotal - discount;
        tax = taxable - (taxable / divisor);
        total = taxable;
    } else {
        tax = (subtotal - discount) * (Number(invoice.taxRate) / 100);
        total = subtotal - discount + tax;
    }
    const symbol = currencySymbols[invoice.currency] || invoice.currency;

    // Payment Terms
    const handleTermChange = (e) => {
        const val = e.target.value;
        if (val === "1") {
            setInvoice(inv => ({ ...inv, due: '' }));
            setShowCalendarDue(true);
        } else {
            const option = TERMS_OPTIONS.find(opt => opt.value === val);
            if (option && invoice.date) {
                const startDate = new Date(invoice.date);
                const dueDate = new Date(startDate);
                dueDate.setDate(startDate.getDate() + option.days);
                setInvoice(inv => ({ ...inv, due: dueDate.toISOString().slice(0, 10) }));
            }
        }
        setInvoice(inv => ({ ...inv, paymentTerm: val }));
    }
    return (
        <div>
            <div className='invoiceLeft'>
                <div className='addClientFormInnerInvoice'>
                    <h6>Invoice</h6>
                    <div className="card image-card pdfParaMargin">
                        <div className="card-body" style={{ position: 'relative' }}>
                            {getImageSrc(logoFile) && (
                                <div style={{ display: 'inline-block', position: 'relative' }}>
                                    <Image 
                                        src={getImageSrc(logoFile)}
                                        alt="Logo"
                                        width={120}
                                        height={80}
                                        style={{ maxWidth: 120, maxHeight: 80, objectFit: 'contain', borderRadius: 8, border: '1px solid #e2e8f0', padding:'10px' }}
                                    />
                                    <button
                                        type="button"
                                        className="remove-logo-btn"
                                        style={{
                                            position: 'absolute', top: 2, right: 2, background: 'rgba(255,255,255,0.8)', border: 'none', borderRadius: '50%', cursor: 'pointer', padding: 2
                                        }}
                                        onClick={handleLogoDelete}
                                    >
                                        <FontAwesomeIcon icon={faTimes} />
                                    </button>
                                </div>
                            )}
                            {!getImageSrc(logoFile) && (
                                <>
                                    <input type="file" accept="image/*" style={{ display: 'none' }} id="logo-upload" onChange={handleLogoUpload} />
                                    <button className='add-photo' onClick={() => document.getElementById('logo-upload').click()}>
                                        <FontAwesomeIcon icon={faSquarePlus} /> Add Logo
                                    </button>
                                </>
                            )}
                        </div>
                    </div>
                </div>
                <div className='communication-inner form-input-label'>
                    <div className="row">
                        <div className="col-lg-6">
                            <div className="sub-head"><p className="subheading">From</p></div>
                            <div className="floating-label-group mb-3">
                                <input type="text" className="input-form-control" name="businessName" value={invoice.from.businessName} onChange={e => handleInput(e, 'from')} required />
                                <label className="floating-label">Business Name</label>
                            </div>
                            {/* <div className="floating-label-group mb-3">
                                <input type="email" className="input-form-control" name="email" value={invoice.from.email} onChange={e => handleInput(e, 'from')} required />
                                <label className="floating-label">Email</label>
                            </div> */}

                              <div className="floating-label-group  mb-3">
                                    <input
                                    type="text"
                                    id="email"
                                    name="email" value={invoice.from.email}
                                    className="input-form-control"
                                    onChange={e => handleInput(e, 'from')}
                                    required
                                    />
                                    <label className="floating-label">Email</label>
                                  
                            </div>


                            <div className="floating-label-group mb-3">
                                <input type="text" className="input-form-control" name="address" value={invoice.from.address} onChange={e => handleInput(e, 'from')} required />
                                <label className="floating-label">Address</label>
                            </div>
                            <div className="floating-label-group mb-3">
                                <input type="text" className="input-form-control" name="phone" value={invoice.from.phone} onChange={e => handleInput(e, 'from')} required />
                                <label className="floating-label">Phone No.</label>
                            </div>
                            <div className="floating-label-group mb-3">
                                <input type="text" className="input-form-control" name="businessNumber" value={invoice.from.businessNumber} onChange={e => handleInput(e, 'from')} required />
                                <label className="floating-label">Business Phone No.</label>
                            </div>
                        </div>
                        <div className="col-lg-6">
                            <div className="sub-head"><p className="subheading">Bill To</p></div>
                            <div className="floating-label-group mb-3">
                                <input type="text" className="input-form-control" name="name" value={invoice.billTo.name} onChange={e => handleInput(e, 'billTo')} required />
                                <label className="floating-label">Client Name</label>
                            </div>
                            {/* <div className="floating-label-group mb-3">
                                <input type="email" className="input-form-control" name="email" value={invoice.billTo.email} onChange={e => handleInput(e, 'billTo')} required />
                                <label className="floating-label">Email</label>
                            </div> */}

                                    <div className="floating-label-group  mb-3">
                                        <input
                                        type="text"                  
                                        name="email" value={invoice.billTo.email} 
                                        className="input-form-control"
                                        onChange={e => handleInput(e, 'billTo')}
                                        required
                                        />
                                    <label className="floating-label">Email</label>                                 
                                 </div>


                            <div className="floating-label-group mb-3">
                                <input type="text" className="input-form-control" name="address" value={invoice.billTo.address} onChange={e => handleInput(e, 'billTo')} required />
                                <label className="floating-label">Address</label>
                            </div>
                            <div className="floating-label-group mb-3">
                                <input type="text" className="input-form-control" name="phone" value={invoice.billTo.phone} onChange={e => handleInput(e, 'billTo')} required />
                                <label className="floating-label">Phone No.</label>
                            </div>
                            <div className="floating-label-group mb-3">
                                <input type="text" className="input-form-control" name="mobile" value={invoice.billTo.mobile} onChange={e => handleInput(e, 'billTo')} required />
                                <label className="floating-label">Mobile</label>
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-lg-12">
                            <div className="sub-head"><p className="subheading">Invoice Details</p></div>
                        </div>
                        <div className="col-lg-8">
                            <div className="row" style={{ gap: 0 }}>
                                <div className="col-md-6">
                                    <div className="floating-label-group mb-3">
                                        <input type="text" className="input-form-control" name="number" value={invoice.number} onChange={handleInput} required />
                                        <label className="floating-label">Invoice Number</label>
                                    </div>
                                </div>
                                <div className="col-md-6">
                                    <div className="floating-label-group mb-3" style={{ position: 'relative' }}>
                                        <input
                                            type="text"
                                            className="input-form-control input-logo"
                                            value={invoice.date}
                                            readOnly
                                            onClick={() => { setShowCalendarStart(true); setShowCalendarDue(false); }}
                                        />
                                        <label className="floating-label">Start Date</label>
                                        <FontAwesomeIcon
                                            className="point-img"
                                            icon={faCalendarDays}
                                            onClick={() => { setShowCalendarStart(!showCalendarStart); setShowCalendarDue(false); }}
                                        />
                                        {showCalendarStart && (
                                            <Calendar
                                                onChange={date => {
                                                    setInvoice(inv => ({ ...inv, date: formatDate(date) }));
                                                    setShowCalendarStart(false);
                                                }}
                                                value={invoice.date ? new Date(invoice.date) : new Date()}
                                            />
                                        )}
                                    </div>
                                </div>
                            </div>
                            <div className="row" style={{ gap: 0 }}>
                                <div className="col-md-6">
                                    <div className="payment-type-dropdown selectAppreanceNone" >
                                         <label className="payment-label">Terms</label>

                                        <select
                                            className="input-form-control"
                                            value={invoice.paymentTerm || ""}
                                            onChange={handleTermChange}
                                            style={{ minWidth: 140 }}
                                        >
                                            {termsOptions.map(opt => (
                                                <option key={opt.value} value={opt.value}>{opt.label}</option>
                                            ))}
                                        </select>
                                         <p className="dropdownIcon">
                                                <img src={IMAGE.dropdownColor} alt="" />
                                            </p>
                                    </div>

                                     {/* <div className="payment-type-dropdown selectAppreanceNone">
                                            <label className="payment-label"> Terms</label>
                                            <select
                                                className="payment-terms"
                                                id="payterm"

                                                required
                                            >
                                                <option value="">Select Payment Term</option>
                                                <option value="1">Net 30</option>
                                                <option value="1">Net 30</option>

                                            </select>
                                            <p className="dropdownIcon">
                                                <img src={IMAGE.dropdownColor} alt="" />
                                            </p>

                                        </div> */}
                                </div>
                                <div className="col-md-6">
                                    <div className="floating-label-group mb-3" style={{ position: 'relative' }}>
                                        <input
                                            type="text"
                                            className="input-form-control input-logo"
                                            value={invoice.due}
                                            readOnly
                                            onClick={() => setShowCalendarDue(true)}
                                            style={{ marginTop: 0 }}
                                        />
                                        <label className="floating-label">Due Date</label>
                                        <FontAwesomeIcon
                                            className="point-img"
                                            icon={faCalendarDays}
                                            onClick={() => setShowCalendarDue(!showCalendarDue)}
                                            
                                        />
                                        {showCalendarDue && (
                                            <Calendar
                                                onChange={date => {
                                                    setInvoice(inv => ({ ...inv, due: formatDate(date) }));
                                                    setShowCalendarDue(false);
                                                }}
                                                value={invoice.due ? new Date(invoice.due) : new Date()}
                                            />
                                        )}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    {/* Items */}
                    <div className="row">
                        <div className="col-lg-12">
                            <div className="sub-head"><p className="subheading">Items</p></div>
                        </div>
                        {invoice.items.map((item, idx) => (
                            <React.Fragment key={idx}>
                                <div className="col-lg-4">
                                    <h6 className='descriptionName'>Description</h6>
                                    <div className="floating-label-group mb-3">
                                        <input type="text" className="input-form-control" value={item.description} onChange={e => {
                                            const items = [...invoice.items];
                                            items[idx].description = e.target.value;
                                            setInvoice(inv => ({ ...inv, items }));
                                        }} required />
                                        <label className="floating-label">Item Description</label>
                                    </div>
                                </div>
                                <div className="col-lg-3">
                                    <h6 className='descriptionName'>Rate</h6>
                                    <div className="floating-label-group mb-3">
                                        <input type="number" className="input-form-control" value={item.price} onChange={e => {
                                            const items = [...invoice.items];
                                            items[idx].price = e.target.value;
                                            setInvoice(inv => ({ ...inv, items }));
                                        }} required />
                                        {/* <label className="floating-label">Rate</label> */}
                                    </div>
                                </div>
                                <div className="col-lg-3">
                                    <h6 className='descriptionName'>Qty</h6>
                                    <div className="floating-label-group mb-3">
                                        <input type="number" className="input-form-control" value={item.quantity} onChange={e => {
                                            const items = [...invoice.items];
                                            items[idx].quantity = e.target.value;
                                            setInvoice(inv => ({ ...inv, items }));
                                        }} required />
                                        {/* <label className="floating-label">Qty</label> */}
                                    </div>
                                </div>
                                <div className="col-lg-2">
                                    <div className="totalAmountBox">
                                        <h6 className='descriptionName'>Amount</h6>
                                        <div className="totalAmountBox">
                                        <div className="totalAmountBoxinr">
                                            <h6 className='totalAmount'>{symbol} {(item.quantity * item.price).toFixed(2)}</h6>
                                            {invoice.items.length > 1 && (
                                                <button type="button" onClick={() => handleRemoveItem(idx)} className="remove-btn">×</button>
                                            )}
                                        </div>
                                        </div>

                                    </div>
                                </div>
                            </React.Fragment>
                        ))}
                        <div className="col-lg-3">
                            <button className='add-note' type="button" onClick={() => setShow(true)}>
                                <FontAwesomeIcon icon={faSquarePlus} /> Add items
                            </button>
                        </div>
                    </div>
                    {/* Notes */}
                    <div className="row">
                        <div className="col-lg-12">
                            <div className="sub-head"><p className="subheading">Notes</p></div>
                        </div>
                        <div className="col-lg-12">
                            <div className="floating-label-group">
                                <textarea
                                    type="text"
                                    className="input-form-control"
                                    name="notes"
                                    value={invoice.notes}
                                    onChange={handleInput}
                                    required
                                />
                                <label className="floating-label">Description</label>
                            </div>
                        </div>
                    </div>
                    {/* Signature */}
                    <div>
                        <div className="sub-head"><p className="subheading">Signature</p></div>
                        <div className='col-lg-6'>
                            <SignaturePad value={invoice.signatureData ? `data:image/png;base64,${invoice.signatureData}` : ''} onChange={handleSignatureChange} color={invoice.color} />
                        </div>
                    </div>
                </div>
                {/* Item Modal */}
                <Modal show={show} centered onHide={() => setShow(false)}>
                    <Modal.Header closeButton>
                        <Modal.Title>Add Item</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        <div className='row'>
                            <div className='col-lg-12'>
                                <div className="floating-label-group mb-3">
                                    <label className="floating-label">Item Name</label>
                                    <input type="text" className="input-form-control" value={itemModal.description} onChange={e => setItemModal(modal => ({ ...modal, description: e.target.value }))} required />
                                </div>
                                <div className="floating-label-group mb-3">
                                    <label className="floating-label">Item Description</label>
                                    <textarea className="input-form-control modal-textarea" value={itemModal.details} onChange={e => setItemModal(modal => ({ ...modal, details: e.target.value }))} required />
                                </div>
                                <div className="floating-label-group mb-3">
                                    <label className="floating-label">Rate</label>
                                    <input type="number" className="input-form-control" value={itemModal.price} onChange={e => setItemModal(modal => ({ ...modal, price: e.target.value }))} required />
                                </div>
                                <div className="floating-label-group mb-3">
                                    <label className="floating-label">Quantity</label>
                                    <input type="number" className="input-form-control" value={itemModal.quantity} onChange={e => setItemModal(modal => ({ ...modal, quantity: e.target.value }))} required />
                                </div>
                            </div>
                        </div>
                        <button className='modal-btn addBtnn' type="button" onClick={handleAddItem}>Add</button>
                    </Modal.Body>
                </Modal>
                </div>
                </div>
    );
}

function formatDate(dateStr) {
    if (!dateStr) return '';
    const date = new Date(dateStr);
    const dd = String(date.getDate()).padStart(2, '0');
    const mm = String(date.getMonth() + 1).padStart(2, '0');
    const yyyy = date.getFullYear();
    return `${dd}-${mm}-${yyyy}`;
}

// Invoice Preview
// eslint-disable-next-line react/display-name
const InvoicePreview = React.forwardRef(({ invoice, logoFile, photoFiles }, ref) => {
    const symbol = currencySymbols[invoice.currency] || invoice.currency;
    const subtotal = invoice.items.reduce((sum, item) => sum + (Number(item.quantity) * Number(item.price)), 0);
    const discount = invoice.discountType === 'percent'
        ? subtotal * (Number(invoice.discountValue) / 100)
        : Number(invoice.discountValue);
    let tax = 0, total = 0;
    if (invoice.taxInclusive) {
        const divisor = 1 + (Number(invoice.taxRate) / 100);
        const taxable = subtotal - discount;
        tax = taxable - (taxable / divisor);
        total = taxable;
    } else {
        tax = (subtotal - discount) * (Number(invoice.taxRate) / 100);
        total = subtotal - discount + tax;
    }

    const todayFormatted = formatDate(new Date().toISOString());

    return (
        <div className="preview-card" ref={ref}>
            <div className="tableTopContainer" style={{ margin: 0, padding: 0, fontFamily: 'Arial, sans-serif', backgroundColor: '#f5f5f5' }}>
                <table width="100%" cellPadding="0" cellSpacing="0" style={{ backgroundColor: '#fff', padding: '20px' }}>
                    <tbody>
                        <tr>
                            <td align="center">
                                <table width="100%" cellPadding="0" cellSpacing="0" style={{ backgroundColor: '#ffffff', borderRadius: '8px', boxShadow: '0 2px 10px rgba(0,0,0,0.1)' }}>
                                    <tbody>
                                        <tr>
                                            <td style={{ padding: '10px 40px' }}>
                                                <table width="100%" cellPadding="0" cellSpacing="0">
                                                    <tbody>
                                                        <tr>
                                                            <td style={{ fontSize: '22px', fontWeight: 'bold', color: '#2c3e50', textAlign: 'left' }}>
                                                                Invoice #{invoice.number || '0000'}
                                                            </td>
                                                            <td align="right" style={{ verticalAlign: 'top', textAlign: 'right', width: "14%" }}>
                                                                <table cellPadding="0" cellSpacing="0">
                                                                    <tbody>
                                                                        <tr>
                                                                            <td style={{ backgroundColor: '#2c3e50', color: 'white', padding: '8px 12px', borderRadius: '50%', fontWeight: 'bold', fontSize: '14px', marginRight: '10px' }}>
                                                                                {invoice.from.businessName ? invoice.from.businessName[0] : 'E'}
                                                                            </td>
                                                                            <td style={{ paddingLeft: '10px' }}>
                                                                                <div style={{ fontSize: '11px', fontWeight: 'bold', color: '#2c3e50' }}>{invoice.from.businessName || 'Business Name'}</div>
                                                                                <div style={{ fontSize: '9px', color: '#7f8c8d' }}>{invoice.billTo.name || 'Contact Name'}</div>
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                                {logoFile && (
                                                                    <div style={{ marginTop: 8 }}>
                                                                        <img src={getImageSrc(logoFile)} alt="Logo" style={{ maxWidth: 60, maxHeight: 40, objectFit: 'contain', borderRadius: 8, border: '1px solid #e2e8f0' }} />
                                                                    </div>
                                                                )}
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style={{ padding: '0 40px' }}>
                                                <hr style={{ border: 'none', borderTop: '2px solid #2c3e50', margin: 0 }} />
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style={{ padding: '10px 40px' }}>
                                                <div style={{ fontSize: '13px', fontWeight: 'bold', color: '#2c3e50', marginBottom: '15px' }}>Bill to: {invoice.billTo.name || 'Contact Name'}</div>
                                                <table width="100%" cellPadding="0" cellSpacing="0">
                                                    <tbody>
                                                        <tr>
                                                            <td width="25%" style={{ fontSize: '10px', color: '#2c3e50', paddingBottom: '5px', textAlign: 'left' }}>
                                                                <strong>Client Name</strong><br />
                                                                {invoice.billTo.name || '-'}
                                                            </td>
                                                            <td width="25%" style={{ fontSize: '10px', color: '#2c3e50', paddingBottom: '5px', textAlign: 'left' }}>
                                                                <strong>Company Name</strong><br />
                                                                {invoice.billTo.businessName || '-'}
                                                            </td>
                                                            <td width="25%" style={{ fontSize: '10px', color: '#2c3e50', paddingBottom: '5px', textAlign: 'left' }}>
                                                                <strong>Client Address</strong><br />
                                                                {invoice.billTo.address || '-'}
                                                            </td>
                                                            <td width="25%" style={{ fontSize: '10px', color: '#2c3e50', paddingBottom: '5px', textAlign: 'left' }}>
                                                                <strong>Phone Number</strong><br />
                                                                {invoice.billTo.phone || '-'}
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style={{ padding: '20px 40px' }}>
                                                <table width="100%" cellPadding="0" cellSpacing="0" style={{ borderCollapse: 'collapse' }}>
                                                    <tbody>
                                                        <tr style={{ backgroundColor: '#ecf0f1' }}>
                                                            <td style={{ border: '1px solid #bdc3c7', padding: '5px', fontWeight: 'bold', textAlign: 'center', width: '15%', fontSize: '12px' }}>Quantity</td>
                                                            {/* <td style={{ border: '1px solid #bdc3c7', padding: '5px', fontWeight: 'bold', textAlign: 'center', width: '15%', fontSize: '12px' }}>Item #</td> */}
                                                            <td style={{ border: '1px solid #bdc3c7', padding: '5px', fontWeight: 'bold', textAlign: 'center', width: '15%', fontSize: '12px' }}>Description</td>
                                                            <td style={{ border: '1px solid #bdc3c7', padding: '5px', fontWeight: 'bold', textAlign: 'center', width: '15%', fontSize: '12px' }}>Unit Price</td>
                                                            <td style={{ border: '1px solid #bdc3c7', padding: '5px', fontWeight: 'bold', textAlign: 'center', width: '15%', fontSize: '12px' }}>Total</td>
                                                        </tr>
                                                        {invoice.items.map((item, idx) => (
                                                            <tr key={idx}>
                                                                <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>{item.quantity}</td>
                                                                {/* <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>{invoice.number || '0000'}</td> */}
                                                                <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>{item.description}</td>
                                                                <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>{symbol}{Number(item.price).toFixed(2)}</td>
                                                                <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>{symbol}{(item.quantity * item.price).toFixed(2)}</td>
                                                            </tr>
                                                        ))}
                                                        <tr>
                                                            <td colSpan="2" style={{ padding: '5px', textAlign: 'center', fontSize: '10px', border: 0 }}>&nbsp;</td>
                                                            <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>&nbsp; Subtotal:</td>
                                                            <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>{symbol}{subtotal.toFixed(2)}</td>
                                                        </tr>
                                                        <tr>
                                                            <td colSpan="2" style={{ padding: '5px', textAlign: 'center', fontSize: '10px', border: 0 }}>&nbsp;</td>
                                                            <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>&nbsp; Discount:</td>
                                                            <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>{symbol}{discount.toFixed(2)}</td>
                                                        </tr>
                                                        <tr>
                                                            <td colSpan="2" style={{ padding: '5px', textAlign: 'center', fontSize: '10px', border: 0 }}>&nbsp;</td>
                                                            <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>&nbsp; Sale Tax:</td>
                                                            <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>{symbol}{tax.toFixed(2)}</td>
                                                        </tr>
                                                        <tr>
                                                            <td colSpan="2" style={{ padding: '5px', textAlign: 'center', fontSize: '10px', border: 0 }}>&nbsp;</td>
                                                            <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>&nbsp; Total:</td>
                                                            <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>{symbol}{total.toFixed(2)}</td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style={{ padding: '10px 40px' }}>
                                                <table width="100%" cellPadding="0" cellSpacing="0">
                                                    <tbody>
                                                        <tr>
                                                            <td width="20%" style={{ paddingRight: '20px' }}>
                                                                {invoice.signatureData && (
                                                                    <div style={{ marginTop: 8 }}>
                                                                        <img
                                                                            src={`data:image/png;base64,${invoice.signatureData}`}
                                                                            alt="Signature"
                                                                            width={120}
                                                                            height={32}
                                                                            style={{ maxWidth: 120, maxHeight: 32, border: '1px solid #cbd5e1', borderRadius: 6, background: '#fff', height: 'auto', width: 'auto' }}
                                                                        />
                                                                    </div>
                                                                )}
                                                                <div style={{ borderBottom: '1px solid #2c3e50', marginBottom: '5px', height: '16px' }}></div>
                                                                
                                                                <div style={{ fontSize: '10px', color: '#7f8c8d' }}>Signature</div>
                                                                
                                                                <br />
                                                                <div style={{ fontSize: '10px', color: '#34495e' }}>{todayFormatted}</div>
                                                                <div style={{ borderBottom: '1px solid #2c3e50', marginBottom: '5px', height: '16px' }}></div>
                                                                <div style={{ fontSize: '10px', color: '#7f8c8d' }}>Date</div>
                                                                
                                                            </td>
                                                            <td width="20%" style={{ paddingLeft: '20px' }}>
                                                                <div style={{ borderBottom: '1px solid #2c3e50', marginBottom: '5px', height: '16px' }}></div>
                                                                <div style={{ fontSize: '10px', color: '#7f8c8d' }}>Printed Name</div>
                                                                <br />
                                                                <div style={{ borderBottom: '1px solid #2c3e50', marginBottom: '5px', height: '16px' }}></div>
                                                                <div style={{ fontSize: '10px', color: '#7f8c8d' }}>Payment method</div>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style={{ padding: '20px 40px 0 40px' }}>
                                                <hr style={{ border: 'none', borderTop: '2px solid #2c3e50', margin: 0 }} />
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style={{ padding: '20px 40px 20px 40px' }}>
                                                <div style={{ fontSize: '12px', fontWeight: 'bold', color: '#2c3e50', marginBottom: '10px', textAlign: 'left' }}>Notes</div>
                                                <div style={{ fontSize: '9px', color: '#7f8c8d', lineHeight: 1.4, textAlign: 'left' }}>
                                                    {invoice.notes || 'No additional notes.'}
                                                </div>
                                                {photoFiles && photoFiles.length > 0 && (
                                                    <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginTop: 10 }}>
                                                        {photoFiles.map((photo, idx) => (
                                                            <img key={idx} src={getImageSrc(photo)} alt={`Photo ${idx + 1}`} style={{ maxWidth: 60, maxHeight: 60, borderRadius: 6, border: '1px solid #cbd5e1', objectFit: 'cover' }} />
                                                        ))}
                                                    </div>
                                                )}
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    );
});

// Main Page
export default function InvoicePage() {
    const [ip, setIP] = useState('');
    const [invoices, setInvoices] = useState([]);
    const [selectedIdx, setSelectedIdx] = useState(null);
    const [invoice, setInvoice] = useState(defaultInvoice);
    const [tab, setTab] = useState(1);
    const [showCalendarStart, setShowCalendarStart] = useState(false);
    const [showCalendarDue, setShowCalendarDue] = useState(false);
    const [logoFile, setLogoFile] = useState(null);
    const [photoFiles, setPhotoFiles] = useState([]);
    const [mode, setMode] = useState('landing');
    const previewRef = useRef();

    // Fetch IP and invoices
    useEffect(() => {
        fetch('https://api.ipify.org?format=json')
            .then(res => res.json())
            .then(data => {
                setIP(data.ip);
                fetch(`${API_BASE}get-all-anonymous-invoice?ip=${data.ip}`)
                    .then(res => res.json())
                    .then(resData => {
                        const list = Array.isArray(resData.data) ? resData.data.map(inv => ({
                            ...inv,
                            logo: inv.logo || ''
                        })) : [];
                        setInvoices(list);
                    })
                    .catch(() => setInvoices([]));
            })
            .catch(() => setIP(''));
    }, []);

    // Save/Update Invoice
    const handleSave = async () => {
        let payload = {
            ...invoice,
            ip,
            logo: invoice.logo || ''
        };
        if (!payload.uuid) payload.uuid = uuidv4();
        payload.signatureData = invoice.signatureData;
        if (selectedIdx !== null) {
            await fetch(`${API_BASE}update-anonymous-invoice`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ ...payload }),
            });
            const updated = invoices.map((inv, idx) => idx === selectedIdx ? payload : inv);
            setInvoices(updated);
        } else {
            await fetch(`${API_BASE}anonymous-invoice`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload),
            });
            setInvoices([...invoices, payload]);
        }
        setMode('landing');
        setSelectedIdx(null);
        setInvoice(defaultInvoice);
        setLogoFile(null);
        setPhotoFiles([]);
        setTab(1);
    };

    // Edit/View
    const handleEdit = async (idx) => {
        const inv = invoices[idx];
        setSelectedIdx(idx);
        const res = await fetch(`${API_BASE}get-anonymous-invoice?uuid=${inv.uuid}`);
        const data = await res.json();
        const detail = data.data;
        setInvoice({
            ...detail,
            logo: detail.logo || '',
            photos: detail.photos || (detail.photo ? [detail.photo] : []),
            signatureData: typeof detail.signatureData === 'string' ? detail.signatureData : detail.signatureData || '',
        });
        setLogoFile(detail.logo ? `data:image/png;base64,${detail.logo}` : null);
        setPhotoFiles(detail.photos ? detail.photos.map(p => `data:image/png;base64,${p}`) : []);
        setTab(1);
        setMode('form');
    };

    // Delete
    const handleDelete = async (idx) => {
        const inv = invoices[idx];
        if (window.confirm('Delete this invoice?')) {
            await fetch(`${API_BASE}delete-anonymous-invoice`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ uuid: inv.uuid, ip }),
            });
            const updated = invoices.filter((_, i) => i !== idx);
            setInvoices(updated);
            setSelectedIdx(null);
            setInvoice(defaultInvoice);
            setLogoFile(null);
            setPhotoFiles([]);
        }
    };

    // New Invoice
    const handleNew = () => {
        setSelectedIdx(null);
        setInvoice({ ...defaultInvoice, uuid: uuidv4(), ip, items: [{ description: '', details: '', quantity: 0, price: 0 }] });
        setLogoFile(null);
        setPhotoFiles([]);
        setTab(1);
        setMode('form');
    };

    // Preview
    const handlePreview = () => setTab(2);

    // Download (PDF from preview)
    const handleDownload = async () => {

        if (!previewRef.current) return;
        const canvas = await html2canvas(previewRef.current, { scale: 2 });

        const imgData = canvas.toDataURL('image/png');
        const pdf = new jsPDF({
            orientation: 'portrait',
            unit: 'px',
            format: [canvas.width, canvas.height]
        });

        var width = pdf.internal.pageSize.getWidth();
        var height = pdf.internal.pageSize.getHeight();

        pdf.addImage(imgData, 'PNG', 0, 0, width, height);
        pdf.save(`invoice-${invoice.number || 'new'}.pdf`);
    };
    

    // Print (print preview only)
    const handlePrint = async () => {
        if (!previewRef.current) return;
        const printContents = previewRef.current.innerHTML;
        const printWindow = window.open('', '', 'width=900,height=900');
        printWindow.document.write(`
            <html>
                <head>
                    <title>Invoice Print</title>
                    <link rel="stylesheet" href="/anonymousinvoice.css" />
                    <link rel="stylesheet" href="/general.css" />
                </head>
                <body>${printContents}</body>
            </html>
        `);
        printWindow.document.close();
        printWindow.focus();
        setTimeout(() => {
            printWindow.print();
            printWindow.close();
        }, 500);
    };

     // GST/Discount Inline Edit
    const handleTaxRateChange = (e) => setInvoice(inv => ({ ...inv, taxRate: e.target.value }));
    const handleDiscountValueChange = (e) => setInvoice(inv => ({ ...inv, discountValue: e.target.value }));
    const handleDiscountTypeChange = (e) => setInvoice(inv => ({ ...inv, discountType: e.target.value }));

    // Tax Type
    const handleTaxTypeChange = (e) => setInvoice(inv => ({ ...inv, taxInclusive: e.target.value === 'Inclusive' }));

    // Currency
    const handleCurrencyChange = (e) => setInvoice(inv => ({ ...inv, currency: e.target.value }));

    // Sidebar
    const Sidebar = () => {
        const subtotal = invoice.items.reduce((sum, item) => sum + (Number(item.quantity) * Number(item.price)), 0);
        const discount = invoice.discountType === 'percent'
            ? subtotal * (Number(invoice.discountValue) / 100)
            : Number(invoice.discountValue);
        let tax = 0, total = 0;
        if (invoice.taxInclusive) {
            const divisor = 1 + (Number(invoice.taxRate) / 100);
            const taxable = subtotal - discount;
            tax = taxable - (taxable / divisor);
            total = taxable;
        } else {
            tax = (subtotal - discount) * (Number(invoice.taxRate) / 100);
            total = subtotal - discount + tax;
        }
        return (
            <div className='invoiceHeaderLeft'>
                <div className='invoiceBox'>
                    <ul>
                        <li className='borderBottom '>
                            <p>Currency</p>
                            <div className='select listBorder'>
                                <select className="form-select" value={invoice.currency} onChange={handleCurrencyChange}>
                                    {Object.keys(currencySymbols).map(cur => (
                                        <option key={cur} value={cur}>{cur}</option>
                                    ))}
                                </select>
                            </div>
                        </li>
                        <li className='borderBottom '>
                            <p>Tax Type</p>
                            <div className='select listBorder'>
                                <select className="form-select" value={invoice.taxInclusive ? 'Inclusive' : 'None'} onChange={handleTaxTypeChange}>
                                    <option value="None">None</option>
                                    <option value="Inclusive">Inclusive</option>
                                </select>
                            </div>
                        </li>
                        <li className='borderBottom '>
                            <p>Discount Type</p>
                            <div className='select listBorder'>
                                <select className="form-select" value={invoice.discountType} onChange={handleDiscountTypeChange}>
                                    <option value="flat">Flat</option>
                                    <option value="percent">Percentage</option>
                                </select>
                            </div>
                        </li>
                    </ul>
                    <ul className='borderBottom'>
                        <li className='gstSection'>
                            <p className='bold'>GST</p>
                            <div className='gstSectionInner'>
                            <input
                                type="number"
                                value={invoice.taxRate}
                                onChange={handleTaxRateChange}
                                style={{ width: 60, marginLeft: 10, border: '1px solid #cbd5e1', borderRadius: 4, padding: 2 }}
                            />%
                            </div>
                        </li>


                        <li>
                            <p>Discount</p>
                            <div className='gstSectionInner'>
                            <input
                                type="number"
                                value={invoice.discountValue}
                                onChange={handleDiscountValueChange}
                                style={{ width: 60, marginLeft: 10, border: '1px solid #cbd5e1', borderRadius: 4, padding: 2 }}
                            />
                            </div>
                        </li>
                    </ul>
                    <ul className='borderBottom'>
                        <li>
                            <p>Total</p>
                            <span>{currencySymbols[invoice.currency] || invoice.currency}{total.toFixed(2)}</span>
                        </li>
                        <li>
                            <p>Paid</p>
                            <span>{currencySymbols[invoice.currency] || invoice.currency}0.00</span>
                        </li>
                        <li>
                            <p>Balance</p>
                            <span>{currencySymbols[invoice.currency] || invoice.currency}{total.toFixed(2)}</span>
                        </li>
                    </ul>
                </div>
                {mode === 'form' && tab === 2 && (
                <div className='invoiceButtonOptions'>
                    <h6>Options</h6>
                    <button className='getLink' onClick={handleDownload}>Download</button>
                    <button className='printInvoice' onClick={handlePrint}>Print Invoice</button>
                </div>
                )}
            </div>
        );
    };

    // Top Tabs
    const TopTabs = () => (
        <div className='addClientFormTop'>
            <div className='addClientFormTopLeft'>
                <ul>
                    <li className={mode === 'landing' ? "active" : ""} onClick={() => setMode('landing')}>Saved</li>

                    <li className={mode === 'form' && tab === 1 ? "active" : ""} onClick={() => { setMode('form'); setTab(1); }}>Create/Edit</li>
                    <li className={mode === 'form' && tab === 2 ? "active" : ""} onClick={() => { setMode('form'); setTab(2); }}>Preview</li>
                </ul>
            </div>
            <div className='addClientFormTopRight'>
                {mode === 'form' && tab === 1 && (
                    <button className="primary-btn primaryNoBorder" onClick={handleSave}>Save</button>
                )}
            </div>
        </div>
    );

    // Back arrow logic
    const handleBackArrow = () => {
        if (mode === 'landing') {
            window.location.href = '/';
        } else {
            setMode('landing');
            setTab(1);
        }
    };

    return (
        <div className='clientPadding'>
            <div className='addClientForm mb-4'>
                <button className='clientFormBackBtn' onClick={handleBackArrow}>
                    <FontAwesomeIcon icon={faArrowLeft} /> Invoices
                </button>
                <TopTabs />
                <div className='addClientFormInner'>
                    <div className='row'>
                        <div className={mode === 'form' && tab === 0 ? 'col-md-12' : 'col-md-8'}>
                            {mode === 'landing' && (
                                <InvoiceLanding
                                    invoices={invoices}
                                    onEdit={handleEdit}
                                    onDelete={handleDelete}
                                    onCreate={handleNew}
                                    limit={INVOICE_LIMIT}
                                />
                            )}
                            {mode === 'form' && tab === 1 && (
                                <InvoiceForm
                                    invoice={invoice}
                                    setInvoice={setInvoice}
                                    logoFile={logoFile}
                                    setLogoFile={setLogoFile}
                                    photoFiles={photoFiles}
                                    setPhotoFiles={setPhotoFiles}
                                    onSave={handleSave}
                                    tab={tab}
                                    setTab={setTab}
                                    showCalendarStart={showCalendarStart}
                                    setShowCalendarStart={setShowCalendarStart}
                                    showCalendarDue={showCalendarDue}
                                    setShowCalendarDue={setShowCalendarDue}
                                    termsOptions={TERMS_OPTIONS}
                                />
                            )}
                            {mode === 'form' && tab === 2 && (
                                <InvoicePreview ref={previewRef} invoice={invoice} logoFile={logoFile} photoFiles={photoFiles} />
                            )}
                        </div>
                        <div className='col-md-4'>
                            {mode === 'form' && <Sidebar />}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}