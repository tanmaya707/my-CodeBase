import "bootstrap/dist/css/bootstrap.min.css";
import "../general.css";

import DashboardHeader from "@/Components/dashboardheader/dashboardHeader";

export default function authLayout({ children }) {
  return (
    <>
      <DashboardHeader />
      {children}
    </>
  );
}
