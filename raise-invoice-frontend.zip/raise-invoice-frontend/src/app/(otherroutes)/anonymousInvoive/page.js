"use client"


import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faAngleDown, faArrowLeft, faPhone, faEnvelope, faLocationDot, faCircleXmark, faSquarePlus, faPenToSquare, faTrash, faCalendarDays } from '@fortawesome/free-solid-svg-icons';
import Calendar from 'react-calendar';

import Accordion from 'react-bootstrap/Accordion';
import { IMAGE } from '../../../utils/Theme';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';

import './anonymousInvoive.css';
import 'react-calendar/dist/Calendar.css';

import '../../../app/general.css';


// import { IMAGE } from '@/utils/Theme';
// import Pageheader from '@/utils/pageheader';
// import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
// import { faLocationDot, faAngleDown, faSquarePlus } from '@fortawesome/free-solid-svg-icons';
// import Accordion from 'react-bootstrap/Accordion';
// import '../../app/general.css';
// import { useRouter } from 'next/navigation';
// import { fetchMasterData, createClientData, deatilsClientData, updateClientData } from "@/redux/slices/dataSlice";
// import { ToastContainer, toast } from 'react-toastify';



const anonymousInvoive = () => {

    const [tab, setTab] = useState(1);

    const tabListing=[
        {  
            id: 1,
            name: "Create",
        },
        {      
            id: 2,
            name: "Preview",
        },
    ]


    const [showCalendarEnd, setShowCalendarEnd] = useState(false);
    const [showCalendarStart, setShowCalendarStart] = useState(false);

    const [show, setShow] = useState(false);

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    return (
        <div className='clientPadding'>
            <div className='addClientForm  mb-4'>
                <button className='clientFormBackBtn'><FontAwesomeIcon icon={faArrowLeft} /> Create Invoice</button>


                <div className='addClientFormTop'>
                    <div className='addClientFormTopLeft'>

                        <ul> 
                            {tabListing.map(item => (
                                <li 
                                    key={item.id} 
                                    className={tab === item.id ? "active" : ""} 
                                    onClick={() => setTab(item.id)}>
                                    {item.name}
                                </li>
                            ))}
                        </ul>

                    </div>
                    <div className='addClientFormTopRight'>
                        <button>Download</button>
                    </div>

                </div>
                <div className='addClientFormInner'>



                    <div className='row'>
                        <div className='col-md-8'>
                       {tab === 1 ? (
                         <div className='invoiceLeft'>
                            <div className='addClientFormInnerInvoice'>
                                <h6>Invoice</h6>
                                <div className="card image-card pdfParaMargin">
                                    <div className="card-body">
                                        <img src={IMAGE.image} />
                                        <button className='add-photo'><FontAwesomeIcon icon={faSquarePlus} />Add signature</button>
                                    </div>
                                </div>
                            </div>

                            <div className='communication-inner form-input-label'>
                                <div className="row">
                                    <div className="col-lg-6">
                                        <div className="sub-head"><p className="subheading">From</p></div>
                                        <div className="floating-label-group mb-3">
                                            <input
                                                type="text"
                                                id="business"
                                                className="input-form-control"
                                                required

                                            />
                                            <label className="floating-label">Business Name</label>
                                        </div>

                                        <div className="floating-label-group mb-3">
                                            <input
                                                type="email"
                                                id="business"
                                                className="input-form-control"
                                                required

                                            />
                                            <label className="floating-label">Email</label>
                                        </div>

                                        <div className="floating-label-group mb-3">
                                            <input
                                                type="text"
                                                id="business"
                                                className="input-form-control"
                                                required

                                            />
                                            <label className="floating-label">Address</label>
                                        </div>
                                        <div className="floating-label-group mb-3">
                                            <input
                                                type="text"
                                                id="business"
                                                className="input-form-control"
                                                required

                                            />
                                            <label className="floating-label">Phone No.</label>
                                        </div>
                                        <div className="floating-label-group mb-3">
                                            <input
                                                type="text"
                                                id="business"
                                                className="input-form-control"
                                                required

                                            />
                                            <label className="floating-label">Business Phone No.</label>
                                        </div>
                                    </div>

                                    <div className="col-lg-6">
                                        <div className="sub-head"><p className="subheading">Bill To</p></div>
                                        <div className="floating-label-group mb-3">
                                            <input
                                                type="text"
                                                id="business"
                                                className="input-form-control"
                                                required

                                            />
                                            <label className="floating-label">Client Name</label>
                                        </div>

                                        <div className="floating-label-group mb-3">
                                            <input
                                                type="email"
                                                id="business"
                                                className="input-form-control"
                                                required

                                            />
                                            <label className="floating-label">Email</label>
                                        </div>

                                        <div className="floating-label-group mb-3">
                                            <input
                                                type="text"
                                                id="business"
                                                className="input-form-control"
                                                required

                                            />
                                            <label className="floating-label">Address</label>
                                        </div>
                                        <div className="floating-label-group mb-3">
                                            <input
                                                type="text"
                                                id="business"
                                                className="input-form-control"
                                                required

                                            />
                                            <label className="floating-label">Phone No.</label>
                                        </div>
                                        <div className="floating-label-group mb-3">
                                            <input
                                                type="text"
                                                id="business"
                                                className="input-form-control"
                                                required

                                            />
                                            <label className="floating-label">Mobile</label>
                                        </div>



                                    </div>

                                </div>
                                <div className="row">
                                    <div className="col-lg-12">
                                        <div className="sub-head"><p className="subheading">Invoice Details</p></div>
                                    </div>
                                    <div className="col-lg-6">
                                        <div className="floating-label-group mb-3">
                                            <input
                                                type="text"
                                                id="business"
                                                className="input-form-control"
                                                required
                                            />
                                            <label className="floating-label">Invoice Number</label>
                                        </div>
                                    </div>


                                    <div className="col-lg-6">
                                        <div className="floating-label-group mb-3" style={{ position: 'relative' }}>
                                            <input
                                                type="text"
                                                id="start-date"
                                                className="input-form-control input-logo"

                                                readOnly
                                                onClick={() => {
                                                    setShowCalendarStart(true);
                                                    setShowCalendarEnd(false);
                                                }}
                                            />
                                            <label className="floating-label">Start Date</label>
                                            <FontAwesomeIcon
                                                className="point-img"
                                                icon={faCalendarDays}
                                                onClick={() => {
                                                    setShowCalendarStart(!showCalendarStart);
                                                    setShowCalendarEnd(false);
                                                }}
                                            />
                                            {showCalendarStart && (
                                                <Calendar
                                                    onChange={(date) => {
                                                        setStartDate(date);
                                                        setShowCalendarStart(false);
                                                    }}

                                                />
                                            )}
                                        </div>
                                    </div>

                                    <div className="col-lg-6 col-md-6 col-sm-12 mb-3">
                                        <div className="payment-type-dropdown selectAppreanceNone">
                                            <label className="payment-label"> Terms</label>
                                            <select
                                                className="payment-terms"
                                                id="payterm"

                                                required
                                            >
                                                <option value="">Select Payment Term</option>
                                                <option value="1">Net 30</option>
                                                <option value="1">Net 30</option>

                                            </select>
                                            <p className="dropdownIcon">
                                                <img src={IMAGE.dropdownColor} alt="" />
                                            </p>

                                        </div>
                                    </div>

                                </div>

                                <div className="row">
                                    <div className="col-lg-12">
                                        <div className="sub-head">
                                            <p className="subheading">Items</p></div>
                                    </div>
                                    <div className="col-lg-4">
                                        <h6 className='descriptionName'>Description</h6>
                                        <div className="floating-label-group mb-3">
                                            <input
                                                type="text"
                                                id="business"
                                                className="input-form-control"
                                                required
                                            />
                                            <label className="floating-label">Item Description</label>
                                        </div>
                                    </div>
                                    <div className="col-lg-3">
                                        <h6 className='descriptionName'>Rate</h6>
                                        <div className="floating-label-group mb-3">
                                            <input
                                                type="text"
                                                id="business"
                                                className="input-form-control"
                                                required
                                            />
                                            <label className="floating-label">Invoice Number</label>
                                        </div>
                                    </div>

                                    <div className="col-lg-3">
                                        <h6 className='descriptionName'>Qty</h6>
                                        <div className="floating-label-group mb-3">
                                            <input
                                                type="text"
                                                id="business"
                                                className="input-form-control"
                                                required
                                            />
                                            <label className="floating-label">Invoice Number</label>
                                        </div>
                                    </div>

                                    <div className="col-lg-2">
                                        <div className="totalAmountBox">
                                            <h6 className='descriptionName'>Amount</h6>
                                            <h6 className='totalAmount'>$ 0.00</h6>
                                        </div>
                                    </div>

                                    <div className="col-lg-6 col-md-6 col-sm-12">
                                        <div className="floating-label-group">
                                            <textarea
                                                type="text"
                                                id="notes"
                                                className="input-form-control"

                                                required
                                            />
                                            <label className="floating-label">Additional details</label>

                                        </div>
                                    </div>

                                    <div className="row">

                                        <div className="col-lg-3">
                                            <button className='add-note' onClick={handleShow} ><FontAwesomeIcon icon={faSquarePlus} /> Add items</button>
                                        </div>
                                    </div>


                                </div>


                                <div className="row">
                                    <div className="col-lg-12">
                                        <div className="sub-head">
                                            <p className="subheading">Notes</p>
                                        </div>
                                    </div>
                                    <div className="col-lg-12">
                                        <div className="floating-label-group">
                                            <textarea
                                                type="text"
                                                id="notes"
                                                className="input-form-control"

                                                required
                                            />
                                            <label className="floating-label">Description</label>

                                        </div>
                                    </div>
                                </div>




                                <div className="sub-head"><p className="subheading">Signature</p></div>
                                <div className='col-lg-3'>

                                    <div className="card image-card pdfParaMargin">
                                        <div className="card-body">
                                            <img src={IMAGE.image} />
                                            <button className='add-photo'><FontAwesomeIcon icon={faSquarePlus} />Add signature</button>
                                        </div>
                                    </div>
                                </div>


                            </div>
                        </div>
                       ) : tab === 2 ?(
                        // <div className="preview-card">
                        // <div className="card">
                        //     <div className="card-body">
                        //     <div className='card-upper'>
                        //         <div>
                        //         <h4>Invoice</h4>
                        //         <p>Billed To:</p>
                        //         <h6>Client Name</h6>
                        //         <p>Address / Contact Info</p>
                        //         </div>
                        //         <div>
                        //         <p>Invoice No.</p>
                        //         <p className='invoice-num'>#000123</p>
                        //         <p>Issued on</p>
                        //         <p>December 7, 2022.</p>
                        //         <p>Payment Due</p>
                        //         <p>December 22, 2022.</p>
                        //         </div>
                        //     </div>

                        //     <table className="table table-hover preview-invoice mt-4">
                        //         <thead>
                        //         <tr>
                        //             <th colSpan="5" className='left-column'>Services</th>
                        //             <th scope="col">Qty.</th>
                        //             <th scope="col">Price</th>
                        //             <th scope="col">Total</th>
                        //         </tr>
                        //         </thead>
                        //         <tbody>
                        //         <tr>
                        //             <td colSpan="5">Invoice Item 1</td>
                        //             <td className='table-data'>1</td>
                        //             <td className='table-data'>4,000.00</td>
                        //             <td className='table-data total'>4,000.00</td>
                        //         </tr>
                        //         </tbody>
                        //     </table>

                        //     <table className="table table-hover preview-invoice-footer mt-4">
                        //         <tr >
                        //             <td colSpan="2"></td>
                        //             <td colSpan="2">
                        //                 <div className='gstSectionTotal'>
                        //                     <p className='bold'>Total(USD)</p>
                        //                     <span className='totalValue'>4,000.00</span>

                        //                 </div>
                        //             </td>
                        //         </tr>

                        //         <tr>
                        //             <td colSpan="2" >
                                        
                        //                 <div className='companyDetails'>
                        //                     <h6>Company Details</h6>
                        //                     <p className='address'>Address / Contact Info</p>
                        //                     <p className='email'>email@company.com</p>
                        //                     <ul className='gstList'>
                        //                         <li>
                        //                             <span>ID#1 Label</span>
                        //                             <p>1234567890-123</p>
                        //                         </li>
                        //                         <li>
                        //                             <span>ID#1 Label</span>
                        //                             <p>1234567890-123</p>
                        //                         </li>
                        //                     </ul>
                        //                 </div>
                        //             </td>

                        //             <td  colSpan="2" style={{ verticalAlign: 'top' }}>
                                        
                        //                 <div className='additionalNote'>
                        //                     <h6>Additional Notes</h6>
                        //                     <p>Have a great day</p>
                        //                 </div>
                        //             </td>
                        //         </tr>
                        //     </table>

                        //     <div>
                        //     </div>
                        //     </div>
                        // </div>
                        // </div>
                        <div className="preview-card">

                           <div className="tableTopContainer" style={{ margin: 0, padding: 0, fontFamily: 'Arial, sans-serif', backgroundColor: '#f5f5f5' }}>
                            <table width="100%" cellPadding="0" cellSpacing="0" style={{ backgroundColor: '#f5f5f5', padding: '20px' }}>
                                <tbody>
                                    <tr>
                                        <td align="center">
                                            <table width="100%" cellPadding="0" cellSpacing="0" style={{ backgroundColor: '#ffffff', borderRadius: '8px', boxShadow: '0 2px 10px rgba(0,0,0,0.1)' }}>
                                                <tbody>
                                                    <tr>
                                                        <td style={{ padding: '10px 40px' }}>
                                                            <table width="100%" cellPadding="0" cellSpacing="0">
                                                                <tbody>
                                                                    <tr>
                                                                        <td style={{ fontSize: '22px', fontWeight: 'bold', color: '#2c3e50', textAlign:'left' }}>
                                                                            Invoice
                                                                        </td>
                                                                        <td align="right" style={{ verticalAlign: 'top',textAlign:'right',width: "14%" }}>
                                                                            <table cellPadding="0" cellSpacing="0">
                                                                                <tbody>
                                                                                    <tr>
                                                                                        <td style={{ backgroundColor: '#2c3e50', color: 'white', padding: '8px 12px', borderRadius: '50%', fontWeight: 'bold', fontSize: '14px', marginRight: '10px' }}>
                                                                                            E
                                                                                        </td>
                                                                                        <td style={{ paddingLeft: '10px' }}>
                                                                                            <div style={{ fontSize: '11px', fontWeight: 'bold', color: '#2c3e50' }}>Eden</div>
                                                                                            <div style={{ fontSize: '9px', color: '#7f8c8d' }}>Landscaping</div>
                                                                                        </td>
                                                                                    </tr>
                                                                                </tbody>
                                                                            </table>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td style={{ padding: '0 40px' }}>
                                                            <hr style={{ border: 'none', borderTop: '2px solid #2c3e50', margin: 0 }} />
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td style={{ padding: '10px 40px' }}>
                                                            <div style={{ fontSize: '13px', fontWeight: 'bold', color: '#2c3e50', marginBottom: '15px' }}>Bill to:</div>
                                                            <table width="100%" cellPadding="0" cellSpacing="0">
                                                                <tbody>
                                                                    <tr>
                                                                        <td width="25%" style={{ fontSize: '10px', color: '#2c3e50', paddingBottom: '5px', textAlign:'left' }}>
                                                                            <strong>Client Name</strong><br />
                                                                            Mark Thomas
                                                                        </td>
                                                                        <td width="25%" style={{ fontSize: '10px', color: '#2c3e50', paddingBottom: '5px' ,textAlign:'left' }}>
                                                                            <strong>Company Name</strong><br />
                                                                            FusionD Solutions
                                                                        </td>
                                                                        <td width="25%" style={{ fontSize: '10px', color: '#2c3e50', paddingBottom: '5px',textAlign:'left' }}>
                                                                            <strong>Client Address</strong><br />
                                                                            Street X, City X
                                                                        </td>
                                                                        <td width="25%" style={{ fontSize: '10px', color: '#2c3e50', paddingBottom: '5px',textAlign:'left' }}>
                                                                            <strong>Phone Number</strong><br />
                                                                            +00 000 000 000
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td style={{ padding: '20px 40px' }}>
                                                            <table width="100%" cellPadding="0" cellSpacing="0" style={{ borderCollapse: 'collapse' }}>
                                                                <tbody>
                                                                    <tr style={{ backgroundColor: '#ecf0f1' }}>
                                                                        <td style={{ border: '1px solid #bdc3c7', padding: '5px', fontWeight: 'bold', textAlign: 'center', width: '15%', fontSize: '12px' }}>Quantity</td>
                                                                        <td style={{ border: '1px solid #bdc3c7', padding: '5px', fontWeight: 'bold', textAlign: 'center', width: '15%', fontSize: '12px' }}>Item #</td>
                                                                        <td style={{ border: '1px solid #bdc3c7', padding: '5px', fontWeight: 'bold', textAlign: 'center', width: '15%', fontSize: '12px' }}>Description</td>
                                                                        <td style={{ border: '1px solid #bdc3c7', padding: '5px', fontWeight: 'bold', textAlign: 'center', width: '15%', fontSize: '12px' }}>Unit Price</td>
                                                                        <td style={{ border: '1px solid #bdc3c7', padding: '5px', fontWeight: 'bold', textAlign: 'center', width: '15%', fontSize: '12px' }}>Total</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>1</td>
                                                                        <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>0000</td>
                                                                        <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>Seeding</td>
                                                                        <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>$20</td>
                                                                        <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>$20</td>
                                                                    </tr>
                                                                    {/* Additional rows can be added here */}
                                                                    <tr>
                                                                        <td colSpan="3" style={{ padding: '5px', textAlign: 'center', fontSize: '10px', border: 0 }}>&nbsp;</td>
                                                                        <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>&nbsp; Subtotal:</td>
                                                                        <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>&nbsp;</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td colSpan="3" style={{ padding: '5px', textAlign: 'center', fontSize: '10px', border: 0 }}>&nbsp;</td>
                                                                        <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>&nbsp; Sale Tax</td>
                                                                        <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>&nbsp;</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td colSpan="3" style={{ padding: '5px', textAlign: 'center', fontSize: '10px', border: 0 }}>&nbsp;</td>
                                                                        <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>&nbsp; Total</td>
                                                                        <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>&nbsp;</td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td style={{ padding: '10px 40px' }}>
                                                            <table width="100%" cellPadding="0" cellSpacing="0">
                                                                <tbody>
                                                                    <tr>
                                                                        <td width="20%" style={{ paddingRight: '20px' }}>
                                                                            <div style={{ borderBottom: '1px solid #2c3e50', marginBottom: '5px', height: '16px' }}></div>
                                                                            <div style={{ fontSize: '10px', color: '#7f8c8d' }}>Signature</div>
                                                                            <br />
                                                                            <div style={{ borderBottom: '1px solid #2c3e50', marginBottom: '5px', height: '16px' }}></div>
                                                                            <div style={{ fontSize: '10px', color: '#7f8c8d' }}>Date</div>
                                                                        </td>
                                                                        <td width="20%" style={{ paddingLeft: '20px' }}>
                                                                            <div style={{ borderBottom: '1px solid #2c3e50', marginBottom: '5px', height: '16px' }}></div>
                                                                            <div style={{ fontSize: '10px', color: '#7f8c8d' }}>Printed Name</div>
                                                                            <br />
                                                                            <div style={{ borderBottom: '1px solid #2c3e50', marginBottom: '5px', height: '16px' }}></div>
                                                                            <div style={{ fontSize: '10px', color: '#7f8c8d' }}>Payment method</div>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td style={{ padding: '20px 40px 0 40px' }}>
                                                            <hr style={{ border: 'none', borderTop: '2px solid #2c3e50', margin: 0 }} />
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td style={{ padding: '20px 40px 20px 40px' }}>
                                                            <div style={{ fontSize: '12px', fontWeight: 'bold', color: '#2c3e50', marginBottom: '10px',textAlign:'left' }}>Terms & Conditions</div>
                                                            <div style={{ fontSize: '9px', color: '#7f8c8d', lineHeight: 1.4 ,textAlign:'left'}}>
                                                                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.
                                                            </div>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            </div>
                            </div>

                       ) :
                       <></>
                       }     
                       

                        
                        </div>

                        <div className='col-md-4'>
                            <div className='invoiceHeaderLeft'>
                              

                                <div className='invoiceBox'>
                                    <ul >
                                        <li className='borderBottom '>
                                            <p>Cuurency</p>
                                             <div className='select listBorder'>
                                                <select className="form-select" aria-label="Default select example">
                                                    <option defaultValue>INR</option>
                                                    <option value="1">12</option>
                                                    <option value="2">15</option>
                                                    <option value="3">15</option>
                                                </select>
                                            </div>
                                        </li>
                                        <li className='borderBottom '>
                                            <p>Tax Type</p>
                                            <div className='select listBorder'>
                                                <select className="form-select" aria-label="Default select example">
                                                    <option defaultValue>None</option>
                                                    <option value="1">None</option>
                                                    <option value="2">yes</option>
                                                </select>
                                            </div>
                                        </li>
                                        <li className='borderBottom '>
                                            <p>Discount Type</p>
                                            <div className='select listBorder'>
                                                <select className="form-select" aria-label="Default select example">
                                                    <option defaultValue>None</option>
                                                    <option value="1">None</option>
                                                    <option value="2">yes</option>
                                                </select>
                                            </div>
                                        </li>
                                      
                                    </ul>
                               
                                    <ul className='borderBottom'>

                                        <li className='gstSection'>
                                            <p className='bold'>GST</p>
                                            <span className='editGST'>Edit<FontAwesomeIcon icon={faPenToSquare} /></span>
                                        </li>
                                        <li>
                                            <p>Discount</p>
                                            <span>$0.00</span>
                                        </li>
                                    </ul>

                                    <ul className='borderBottom'>
                                        <li>
                                            <p>Total</p>
                                            <span>$0.00</span>
                                        </li>
                                        <li>
                                            <p>Paid</p>
                                            <span>$0.00</span>
                                        </li>
                                        <li>
                                            <p>Balance</p>
                                            <span>$0.00</span>
                                        </li>
                                    </ul>
                                </div>
                               <div className='invoiceButtonOptions'>
                                <h6>Options</h6>
                                    <div className='invoiceButtonOptions'>
                                            <button className='getLink'>Get Link</button>    
                                            <button className='printInvoice'>Print Invoice</button>
                                    </div>    
                                </div>             


                            </div>
                        </div>

                    </div>
                </div>


                <Modal show={show} centered onHide={handleClose}>
                    <Modal.Header closeButton>
                        <Modal.Title>Add Item</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        <div className='row'>
                            <div className='col-lg-12'>

                                <div className="floating-label-group mb-3">
                                    <input type="text" id="name" className="input-form-control" required />
                                    <label className="floating-label">Item Name</label>
                                </div>

                                <div className="floating-label-group mb-3">
                                    <textarea type="text" id="logo" className="input-form-control modal-textarea" required></textarea>
                                    <label className="floating-label">Item Description</label>
                                </div>


                            </div>





                            <Accordion defaultActiveKey="0">
                                <Accordion.Item eventKey="0">
                                    <Accordion.Header>
                                        <p className='accorheading'>GST, days or hours, discount</p>
                                    </Accordion.Header>
                                    <Accordion.Body>
                                        <div className='row'>


                                            <div className='col-lg-12 col-md-12 col-sm-12'>
                                                <div className='payment-type-dropdown'>
                                                    {/* <label className='payment-label'>Payment Terms</label> */}

                                                    <select className="payment-terms" name="cars" id="cars">
                                                        <option value="">select</option>
                                                        <option value="volvo">Volvo</option>
                                                        <option value="saab">Saab</option>
                                                        <option value="mercedes">Mercedes</option>
                                                        <option value="audi">Audi</option>
                                                    </select>


                                                    <p class="dropdownIcon"><img src={IMAGE.dropdownColor} alt="" /></p>
                                                </div>
                                            </div>


                                        </div>

                                    </Accordion.Body>
                                </Accordion.Item>
                            </Accordion>

                            <button className='modal-btn addBtnn'>Add</button>
                        </div>
                    </Modal.Body>

                </Modal>
            </div>
        </div>
    )
}

export default anonymousInvoive;