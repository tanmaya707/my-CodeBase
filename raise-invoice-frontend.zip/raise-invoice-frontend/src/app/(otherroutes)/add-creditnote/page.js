"use client"
import React,{useState} from 'react'
import '../add-invoice/addnote.css';
import '../../general.css';
import Accordion from 'react-bootstrap/Accordion';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { 
    faEnvelope, 
    faPhone,
    faLocationDot,
    faCircleXmark,
    faAngleDown,
    faSquarePlus,
    faArrowLeft
} from '@fortawesome/free-solid-svg-icons';
import { IMAGE } from '@/utils/Theme';
import Link from 'next/link';
import PaymentDetails from '@/Components/payment/paymentDetails';
import Modal from 'react-bootstrap/Modal';

const AddCreditNote = () => {
    const [itemModal, setItemModal] = useState(false);
    const [activetabs, setActivetabs] = useState(0);
    
    const invoiceTabs = ["Create", "Preview", "Send"]

    const handleClose = () => {
        setItemModal(false)
      }
  return (
    <>
        <div className="addNote middle-area-note">
            <Link href={{}} className='go_back mb-5'><FontAwesomeIcon icon={faArrowLeft} /> Add Invoice</Link>
        
            <div className='navbar-tab'>
                <div>
                <ul className="addnote-nav">
                    {invoiceTabs.map((tabs, index) => (
                    <li 
                        className={activetabs === index ? "nav-item-active" : "nav-item"}
                        key={tabs}
                        onClick={()=> setActivetabs(index)}
                    >
                        {tabs}
                    </li>
                    ))}
                </ul>
                </div>

                <button>Save</button>
            </div>

            <div className='container'>
            <div className="row">
                <div className="col-lg-8">
                {/* {activetabs === 0 ? ( */}
                    <div className='PersonCard contentArea-inner'>
                    <Accordion defaultActiveKey="0">
                    <Accordion.Item eventKey="0">
                        <Accordion.Header>
                            <p className='accorheading'>Bill To</p>
                        </Accordion.Header>
                        <Accordion.Body>
                            <div className="row">
                            <div className="col-lg-6">
                                <div className="card details-card">
                                <div className="card-body">
                                    <span className='initials'>PB</span>
                                    <div className='details-card-right'>
                                    <div className='info'>
                                        <h6>Akash Mishra</h6>
                                        <p><FontAwesomeIcon icon={faEnvelope} /> akashmishra@gmail.com</p>
                                        <p><FontAwesomeIcon icon={faPhone} /> +91 91234 65670</p>
                                        <p><FontAwesomeIcon icon={faLocationDot} /> Mumbai, Maharashtra</p>
                                    </div>
                                    <FontAwesomeIcon className="cross-icon" icon={faCircleXmark} />
                                    </div>
                                </div>
                                </div>
                            </div>
                            </div>
                        </Accordion.Body>
                    </Accordion.Item>
                    </Accordion>
                    
                    <Accordion defaultActiveKey="0">
                    <Accordion.Item eventKey="0">
                        <Accordion.Header>
                        <p className='accorheading'>Items</p>
                        </Accordion.Header>
                        <Accordion.Body>
                        <div className="row">
                            <div className="col-lg-3" onClick={()=>setItemModal(true)}><button className='add-note'><FontAwesomeIcon icon={faSquarePlus} /> Add items</button></div>
                            <div className="col-lg-3"><button className='add-note'><FontAwesomeIcon icon={faSquarePlus} /> Add expenses</button></div>
                            <div className="col-lg-3"><button className='add-note'><FontAwesomeIcon icon={faSquarePlus} /> Add appointments</button></div>
                            <div className="col-lg-3"><button className='add-note'><FontAwesomeIcon icon={faSquarePlus} /> Add time entry</button></div>
                        </div>
                        </Accordion.Body>
                    </Accordion.Item>
                    </Accordion>
            
                    <Accordion defaultActiveKey="0">
                    <Accordion.Item eventKey="0">
                        <Accordion.Header>
                            <p className='accorheading'>Attachments</p>
                        </Accordion.Header>
                        <Accordion.Body>
                        <div className="row">
                            <div className="col-lg-3">
                            <div className="card image-card pdfParaMargin">
                                <div className="card-body">
                                <img src={IMAGE.image} />
                                <button className='add-photo'><FontAwesomeIcon icon={faSquarePlus} /> Add photos</button>
                                </div>
                            </div>
                            </div>
                        </div>
                        </Accordion.Body>
                    </Accordion.Item>
                    </Accordion>

                    <Accordion defaultActiveKey="0">
                    <Accordion.Item eventKey="0">
                        <Accordion.Header>
                            <p className='accorheading'>Comments and payment instructions</p>
                        </Accordion.Header>
                        <Accordion.Body>
                            <button className='add-note'><FontAwesomeIcon icon={faSquarePlus} /> Add payment instruction</button>
                            <button className='add-note'><FontAwesomeIcon icon={faSquarePlus} /> Add comments</button>
                        </Accordion.Body>
                    </Accordion.Item>
                    </Accordion>
                </div>
                {/* ): activetabs === 1 ? (
                    <div className="preview-card">
                    <div className="card">
                        <div className="card-body">
                        <div className='card-upper'>
                            <div>
                            <h4>Invoice</h4>
                            <p>Billed To:</p>
                            <h6>Client Name</h6>
                            <p>Address / Contact Info</p>
                            </div>
                            <div>
                            <p>Invoice No.</p>
                            <p className='invoice-num'>#000123</p>
                            <p>Issued on</p>
                            <p>December 7, 2022.</p>
                            <p>Payment Due</p>
                            <p>December 22, 2022.</p>
                            </div>
                        </div>

                        <table className="table table-hover preview-invoice mt-4">
                            <thead>
                            <tr>
                                <th colSpan="5" className='left-column'>Services</th>
                                <th scope="col">Qty.</th>
                                <th scope="col">Price</th>
                                <th scope="col">Total</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td colSpan="5" className='left-column'>Invoice Item 1</td>
                                <td>1</td>
                                <td>4,000.00</td>
                                <td>4,000.00</td>
                            </tr>
                            </tbody>
                        </table>
                        <div>
                        </div>
                        </div>
                    </div>
                    </div>
                ): (
                    <div className='mt-4'>
                    <div className='sub-head'>
                        <p className='subheading'>Bill To</p>
                    </div>
                    <div className='col-lg-12'>
                        <div className='form-group mb-3'>
                        <label>Email Ids</label>
                        <input 
                            type="text"
                            name="email"
                            className='form-control email'
                            placeholder='Email Ids'
                        />
                        <p>CC</p>
                        <p>BCC</p>
                        </div>
                    </div>
                    <div className='sub-head'>
                        <p className='subheading'>Service</p>
                    </div>
                    <div className='col-lg-12'>
                        <div className='form-group mb-3'>
                        <textarea 
                            type="text"
                            name="note"
                            className='form-control'
                            placeholder='Note'
                        />
                        </div>
                    </div>
                    <div className='sub-head'>
                        <p className='subheading'>Attachment</p>
                    </div>
                    <div className="row">
                        <div className="col-lg-3">
                        <div className="card image-card pdfParaMargin">
                            <div className="card-body">
                            <img src={IMAGE.pin} />
                            <button className='add-photo'><FontAwesomeIcon icon={faSquarePlus} /> Add file</button>
                            </div>
                        </div>
                        </div>
                    </div>
                    </div>
                )} */}
                </div>

                <div className="col-lg-4">
                <PaymentDetails activetabs={activetabs}/>
                </div>
            </div>
            </div>
              
        </div>

        <Modal 
            className='form-input-label'
            show={itemModal} 
            onHide={handleClose}
        >
            <Modal.Header closeButton>
            <Modal.Title>Add Item</Modal.Title> 
            </Modal.Header>
            <Modal.Body>
                <div className='row'>
                    <div className='col-lg-12'>
                        
                        <div className="floating-label-group mb-3">
                            <input type="text" id="name" className="input-form-control" required />
                            <label className="floating-label">Item Name</label>
                        </div>

                        <div className="floating-label-group mb-3">
                            <textarea type="text" id="logo" className="input-form-control modal-textarea" required />
                            <label className="floating-label">Item Description</label>
                        </div>
                    </div>

                    <div className='col-lg-6'>
                        <div className="phone-input mb-3">
                            <div className="floating-label-group">
                                <input type="text" className="phone-number" required/>
                                <label className="phone-floating-label">Rate</label>
                            </div>
                            <div className="divider"></div>
                            <div className="country-code">$ <FontAwesomeIcon icon={faAngleDown} className='phone-angle'/></div>
                        </div>
                    </div>

                    <div className='col-lg-6'>
                        <div className="phone-input mb-3">
                            <div className="floating-label-group">
                                <input type="text" className="phone-number" required/>
                                <label className="phone-floating-label">Qty.</label>
                            </div>
                            <div className="divider"></div>
                            <div className="country-code">mtr <FontAwesomeIcon icon={faAngleDown} className='phone-angle'/></div>
                        </div>
                    </div>

                    <Accordion defaultActiveKey="0">
                        <Accordion.Item eventKey="0">
                            <Accordion.Header>
                            <p className='accorheading'>More Details</p>
                            </Accordion.Header>
                            <Accordion.Body>
                            <div className='row'>
                                <div className='col-lg-6 col-md-6 col-sm-12'>
                                    <div className="phone-input mb-3">
                                        <div className="floating-label-group">
                                            <input type="text" className="phone-number" required/>
                                            <label className="phone-floating-label">Tax</label>
                                        </div>
                                        <div className="divider"></div>
                                        <div className="country-code without-icon">%</div>
                                    </div>
                                </div>

                                <div className='col-lg-6 col-md-6 col-sm-12'>
                                    <div className='payment-type-dropdown'>
                                        {/* <label className='payment-label'>Payment Terms</label> */}

                                        <select className="payment-terms" name="cars" id="cars">
                                        <option value="">Days</option>
                                        <option value="volvo">Volvo</option>
                                        <option value="saab">Saab</option>
                                        <option value="mercedes">Mercedes</option>
                                        <option value="audi">Audi</option>
                                        </select>
                                    </div>
                                </div>

                                <div className="seperator-text">
                                    <div className="horizontal-line"></div>
                                    <p>or</p>
                                    <div className="horizontal-line"></div>
                                </div>

                                <div className='multiple-btn'>
                                    <button className='add-note'>Choose multiple</button>
                                </div>
                            </div>

                            </Accordion.Body>
                        </Accordion.Item>
                    </Accordion>

                    <button className='modal-btn my-4'>Add</button> 
                </div>
            </Modal.Body>
        </Modal>
    </>
  )
}

export default AddCreditNote
