export const API_V1_URL = process.env.NEXT_PUBLIC_API_V1_URL;
export const API_URL = process.env.NEXT_PUBLIC_API_URL;

export const GET_FAQS = `${API_V1_URL}get-faq-categories`;
export const GET_PRICING_CATEGORIES = `${API_V1_URL}get-features-categories`;
export const GET_PRICING_SELECTPRICING = `${API_V1_URL}get-plan-list`;
export const GET_PRICING_SELECTPRICING_FEATURES = `${API_V1_URL}get-faq-categories`;
export const GET_CAREER_ = `${API_V1_URL}get-job-categories`;
export const GET_CAREER_JOB_LIST = `${API_V1_URL}get-job-list`;
export const GET_CAREER_JOB_DETAILS = `${API_V1_URL}get-job-list`;
export const CLIENT_REGISTER = `${API_V1_URL}clients/client-register`;
export const CLIENT_COMPANY_CREATE = `${API_V1_URL}clients/create-profile`;
export const CLIENT_PROFILE_DETAILS = `${API_V1_URL}clients/client-profile`;
export const CLIENT_PROFILE_UPDATE = `${API_V1_URL}clients/update-profile`;
export const CLIENT_LOGOUT = `${API_V1_URL}clients/client-logout`;
export const CLIENT_LOGIN = `${API_V1_URL}clients/client-login`;
export const GET_MASTER_DATA = `${API_V1_URL}common/get-master-data`;
export const CREATE_LANGUAGE = `${API_URL}save-language`;
export const LIST_LANGUAGE = `${API_URL}get-language-list`;
export const GET_PROJECT_SETTINGS_DATA = `${API_V1_URL}clients/details-project-settings`;
export const GET_COMMUNICATION_SETTINGS_DATA = `${API_V1_URL}clients/details-communication-settings`;
export const STORE_PROJECT_SETTINGS_DATA = `${API_V1_URL}clients/update-project-settings`;
export const STORE_COMMUNICATION_SETTINGS_DATA = `${API_V1_URL}clients/update-communication-settings`;
export const GET_CLIENT_DATA = `${API_V1_URL}main/clients`;
export const CREATE_CLIENT_DATA = `${API_V1_URL}main/add-client`;
export const SWITCH_ACCOUNT = `${API_V1_URL}switch-accounts`;
export const DETAILS_CLIENT_DATA = `${API_V1_URL}main/client`;
export const GET_ROLE_DATA = `${API_V1_URL}main/roles`;
export const CREATE_ROLE_DATA = `${API_V1_URL}main/add-role`;
export const DETAILS_ROLE_DATA = `${API_V1_URL}main/role`;
export const GET_CLIENT_ADMIN_DATA = `${API_V1_URL}main/client-admins`;
export const CREATE_CLIENT_ADMIN_DATA = `${API_V1_URL}main/add-client-admin`;
export const DETAILS_CLIENT_ADMIN_DATA = `${API_V1_URL}main/client-admin`;
export const DETAILS_CLIENT_ADMIN_DATA_BY_UUID = `${API_V1_URL}main/client-admin-by-uuid`;
export const GET_APPOINTMENT_DATA = `${API_V1_URL}main/appointments`;
export const CREATE_APPOINTMENT_DATA = `${API_V1_URL}main/add-appointment`;
export const GET_SINGLE_APPOINTMENT_DATA = `${API_V1_URL}main/get-appointment`;
export const UPDATE_APPOINTMENT_DATA = `${API_V1_URL}main/update-appointment`;
export const DELETE_APPOINTMENT_DATA = `${API_V1_URL}main/delete-appointment`;
export const GET_PROJECT_DATA = `${API_V1_URL}main/project-list`;
export const GET_CLIENT_PROJECT_DATA = `${API_V1_URL}main/client-project-list`;
export const CREATE_PROJECT_DATA = `${API_V1_URL}main/add-project`;
export const DETAILS_PROJECT_DATA = `${API_V1_URL}main/project-details`;
export const UPDATE_PROJECT_DATA = `${API_V1_URL}main/update-project`;
export const SAVE_PROJECT_FILE = `${API_V1_URL}main/save-files`;
export const GET_PROJECT_FILE = `${API_V1_URL}main/get-files`;
export const DELETE_PROJECT_FILE = `${API_V1_URL}main/remove-files`;
export const DELETE_PROJECT_DATA = `${API_V1_URL}main/delete-project`;
export const CLIENT_SUBSCRIPTION_REG = `${API_V1_URL}main/buy-plan`;
export const PROFILE_PICTURE = `${API_V1_URL}clients/update-profile-image`;

// Items
export const GET_ITEM_DATA = `${API_V1_URL}list-item`;
export const CREATE_ITEM_DATA = `${API_V1_URL}create-item`;
export const DETAILS_ITEM_DATA = `${API_V1_URL}item-details`;
export const UPDATE_ITEM_DATA = `${API_V1_URL}update-item`;
export const DELETE_ITEM_DATA = `${API_V1_URL}delet-item`;

// Invoice
export const CREATE_INVOICE_DATA = `${API_V1_URL}create-invoice`;
export const GET_INVOICE_DATA = `${API_V1_URL}invoice-list`;
export const NEXT_INVOICE_NUMBER = `${API_V1_URL}next-invoice-number`;
export const DETAILS_INVOICE_DATA = `${API_V1_URL}invoice-details`;
export const UPDATE_INVOICE_DATA = `${API_V1_URL}update-invoice`;
export const DELETE_INVOICE_DATA = `${API_V1_URL}delete-invoice`;
export const CREATE_TAX_DATA = `${API_V1_URL}create-tax`;
export const GET_TAX_DATA = `${API_V1_URL}rate-list`;
export const DELETE_TAX_DATA = `${API_V1_URL}delete-tax`;

// Estimate
export const CREATE_ESTIMATE_DATA = `${API_V1_URL}create-estimate`;
export const NEXT_ESTIMATE_NUMBER = `${API_V1_URL}next-estimate-number`;
export const GET_ESTIMATE_DATA = `${API_V1_URL}estimate-list`;
export const DETAILS_ESTIMATE_DATA = `${API_V1_URL}estimate-details`;
export const UPDATE_ESTIMATE_DATA = `${API_V1_URL}update-estimate`;
export const DELETE_ESTIMATE_DATA = `${API_V1_URL}delete-estimate`;

// Expense
export const CREATE_EXPENSE_DATA = `${API_V1_URL}create-expense`;
export const NEXT_EXPENSE_NUMBER = `${API_V1_URL}next-expense-number`;
export const GET_EXPENSE_DATA = `${API_V1_URL}expense-list`;
export const DETAILS_EXPENSE_DATA = `${API_V1_URL}expense-details`;
export const UPDATE_EXPENSE_DATA = `${API_V1_URL}expense-update`;
export const DELETE_EXPENSE_DATA = `${API_V1_URL}delete-expense`;

// Credit Note
export const CREATE_CREDIT_NOTE_DATA = `${API_V1_URL}create-credit-note`;
export const NEXT_CREDIT_NOTE_NUMBER = `${API_V1_URL}next-credit-note-number`;
export const GET_CREDIT_NOTE_DATA = `${API_V1_URL}credit-note-list`;
export const DETAILS_CREDIT_NOTE_DATA = `${API_V1_URL}credit-note-details`;
export const UPDATE_CREDIT_NOTE_DATA = `${API_V1_URL}update-credit-note`;
export const DELETE_CREDIT_NOTE_DATA = `${API_V1_URL}delete-credit-note`;

// Purchase Order
export const CREATE_PURCHASE_ORDER_DATA = `${API_V1_URL}create-purchase-order`;
export const NEXT_PURCHASE_ORDER_NUMBER = `${API_V1_URL}next-purchase-order-number`;
export const GET_PURCHASE_ORDER_DATA = `${API_V1_URL}purchase-order-list`;
export const DETAILS_PURCHASE_ORDER_DATA = `${API_V1_URL}purchase-order-details`;
export const UPDATE_PURCHASE_ORDER_DATA = `${API_V1_URL}update-purchase-order`;
export const DELETE_PURCHASE_ORDER_DATA = `${API_V1_URL}delete-purchase-order`;

// Invoice
export const DELETE_LOGO_DATA = `${API_V1_URL}delete-logo`;
export const LIST_LOGO_DATA = `${API_V1_URL}logo-list`;
export const CREATE_LOGO_DATA = `${API_V1_URL}create-logo`;
export const LIST_COLOR_DATA = `${API_V1_URL}colour-list`;
export const CREATE_WATERMARK_DATA = `${API_V1_URL}create-watermark`;
export const LIST_WATERMARK_DATA = `${API_V1_URL}water-mark-list`;
export const DELETE_WATERMARK_DATA = `${API_V1_URL}delete-water-mark`;
export const CREATE_HEADER_DATA = `${API_V1_URL}create-header`;
export const LIST_HEADER_DATA = `${API_V1_URL}header-list`;
export const DELETE_HEADER_DATA = `${API_V1_URL}delete-header`;

// export const CREATE_CUSTOM_INVOICE_DATA = `${API_V1_URL}get-invoice`;
export const CREATE_CUSTOM_INVOICE_DATA = `${API_V1_URL}create-custom-template`;
export const GET_CUSTOM_INVOICE_DATA = `${API_V1_URL}get-invoice-setting`;

export const CREATE_CUSTOM_INVOICE_OPTION_DATA = `${API_V1_URL}invoice-option-setting`;
export const GET_CUSTOM_INVOICE_OPTION_DATA = `${API_V1_URL}get-invoice-option-setting`;

//project activity
export const SAVE_CONTACT = `${API_V1_URL}main/save-contact`;
export const GET_CONTACTS = `${API_V1_URL}main/get-contacts`;
export const GET_CONTACTS_FOR_APPOINTMENT = `${API_V1_URL}main/get-contacts-for-appointment`;
export const UPDATE_CONTACTS = `${API_V1_URL}main/update-contact`;
export const DELETE_CONTACTS = `${API_V1_URL}main/delete-contact`;
export const SAVE_TASK = `${API_V1_URL}main/save-tasks`;
export const GET_TASKS = `${API_V1_URL}main/get-tasks`;
export const UPDATE_TASKS = `${API_V1_URL}main/update-task`;
export const DELETE_TASKS = `${API_V1_URL}main/delete-task`;
export const SAVE_LOG = `${API_V1_URL}main/upsert-times`
export const GET_LOG = `${API_V1_URL}main/get-all-times`;

//send mail
export const SEND_MAIL = `${API_V1_URL}send-mail`;
export const RESET_PASSWORD_MAIL = `${API_V1_URL}reset-password-mail`;
export const RESET_PASSWORD = `${API_V1_URL}client-reset-password`;

export const GET_DASHBOARD_DATA = `${API_V1_URL}dashboard`;

export const CREATE_INVOICE_SIGNATURE_DATA = `${API_V1_URL}invoice-signature-setting`;
export const GET_INVOICE_SIGNATURE_DATA = `${API_V1_URL}get-invoice-signature`;

//role permission
export const CLIENT_PLAN_DETAILS = `${API_URL}get-features-categories`;