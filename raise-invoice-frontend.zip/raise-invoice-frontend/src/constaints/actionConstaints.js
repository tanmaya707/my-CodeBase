export const IS_LOADING = 'IS_LOADING';
export const SET_USER = 'SET_USER'
export const SET_LOGGED_IN = 'SET_LOGGED_IN'
export const PRODUCT_LIST = 'PRODUCT_LIST'
export const CUSTOMER_SIGNUP = "CUSTOMER_SIGNUP";
export const CUSTOMER_LOGIN = "CUSTOMER_LOGIN";
export const GET_ITEM="GET_ITEM"

export const isLoading = (data) => {
    return {
        type: IS_LOADING,
        payload: data
    };
}                  