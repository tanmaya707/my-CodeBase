export const ROLES = {
    USER: "User",
    ADMIN: "Admin"
}