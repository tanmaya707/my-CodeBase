import React, { createContext, useContext, useState } from 'react';

export const ModalContext = createContext({
    modalType : null,
    openModal : () => {},
    closeModal : () => {},
    parameter : {},
    setParameters : () => {}
});

export const useModal = () => useContext(ModalContext);

export const ModalProvider = ({ children }) => {
    const [modalType, setModalType] = useState(null);
    const [parameter, setParameter] = useState({});

    const openModal = (type) => setModalType(type);
    const closeModal = () => setModalType(null);
    const setParameters = (props) => setParameter(props)

    return (
        <ModalContext.Provider value={{ modalType, openModal, closeModal, parameter, setParameters }}>
            {children}
        </ModalContext.Provider>
    );
};