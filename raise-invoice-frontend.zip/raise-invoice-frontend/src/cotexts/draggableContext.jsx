import React, { createContext, useCallback, useContext, useState } from 'react';

export const DraggableContext = createContext({
    modalType : null,
    openDraggable : () => {},
    closeDraggable : () => {},
    dragParameter : {},
    setDragParameters : () => {}
});

export const useDraggable = () => useContext(DraggableContext);

export const DraggableProvider = ({ children }) => {
    const [modalType, setDraggableType] = useState(null);
    const [dragParameter, setParameter] = useState({});
    const [isMinimized, setIsMinimized] = useState(false);
    const openDraggable = (type) => setDraggableType(type);
    const closeDraggable = useCallback(() => {setDraggableType(null); setIsMinimized(false)}, []);
    const setDragParameters = (props) => setParameter(props)
    const toggleMinimize = (isStart) => setIsMinimized(prev => isStart ? true : !prev);

    return (
        <DraggableContext.Provider value={{ modalType, openDraggable, closeDraggable, dragParameter, setDragParameters, toggleMinimize : toggleMinimize, isMinimized : isMinimized }}>
            {children}
        </DraggableContext.Provider>
    );
};