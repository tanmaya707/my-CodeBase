'use client';

import { useEffect, useRef, useCallback } from 'react';
import { useRouter } from 'next/navigation';

/**
 * Hook to confirm navigation before leaving a route
 * Blocks: <Link> clicks, back/forward, refresh/close tab, and router.push/replace/back calls.
 */
export function useRouteLeaveConfirmation(
  shouldBlock = false,
  message = 'You have unsaved changes. Leave this page?'
) {
  const router = useRouter();
  const shouldBlockRef = useRef(shouldBlock);
  const originalRouterRef = useRef({});
  const confirmingRef = useRef(false);

  useEffect(() => {
    shouldBlockRef.current = shouldBlock;
    if (!shouldBlock) confirmingRef.current = false;
  }, [shouldBlock]);

  // Helper: show confirmation dialog (can replace with modal)
  const confirmLeave = useCallback(() => window.confirm(message), [message]);

  // ---- 1. Patch router.push / replace / back ----
  useEffect(() => {
    // store originals only once
    if (!originalRouterRef.current.push) {
      originalRouterRef.current.push = router.push;
      originalRouterRef.current.replace = router.replace;
      originalRouterRef.current.back = router.back;
    }

    // override methods
    router.push = async (url, options) => {
      if (shouldBlockRef.current && !confirmingRef.current) {
        const confirmed = confirmLeave();
        if (!confirmed) return; // cancel navigation
        confirmingRef.current = true;
      }
      return originalRouterRef.current.push(url, options);
    };

    router.replace = async (url, options) => {
      if (shouldBlockRef.current && !confirmingRef.current) {
        const confirmed = confirmLeave();
        if (!confirmed) return;
        confirmingRef.current = true;
      }
      return originalRouterRef.current.replace(url, options);
    };

    router.back = async () => {
      if (shouldBlockRef.current && !confirmingRef.current) {
        const confirmed = confirmLeave();
        if (!confirmed) return;
        confirmingRef.current = true;
      }
      return originalRouterRef.current.back();
    };

    return () => {
      // restore originals when unmounting
      if (originalRouterRef.current.push) {
        router.push = originalRouterRef.current.push;
        router.replace = originalRouterRef.current.replace;
        router.back = originalRouterRef.current.back;
      }
    };
  }, [router, confirmLeave]);

  // ---- 2. Handle refresh/close tab ----
  useEffect(() => {
    const handleBeforeUnload = (e) => {
      if (shouldBlockRef.current) {
        e.preventDefault();
        e.returnValue = '';
      }
    };
    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, []);

  // ---- 3. Intercept <a>/<Link> clicks ----
  useEffect(() => {
    const onDocumentClick = (e) => {
      if (!shouldBlockRef.current) return;
      if (e.button !== 0 || e.metaKey || e.ctrlKey || e.altKey || e.shiftKey) return;

      let el = e.target;
      while (el && el.tagName !== 'A') {
        el = el.parentElement;
      }
      if (!el) return;
      const href = el.getAttribute('href');
      if (!href || href.startsWith('#') || href.startsWith('mailto:')) return;

      const url = new URL(href, window.location.href);
      if (url.origin !== window.location.origin) return;

      e.preventDefault();
      const confirmed = confirmLeave();
      if (confirmed) {
        confirmingRef.current = true;
        router.push(href);
      }
    };

    document.addEventListener('click', onDocumentClick, true);
    return () => document.removeEventListener('click', onDocumentClick, true);
  }, [router, confirmLeave]);
}
