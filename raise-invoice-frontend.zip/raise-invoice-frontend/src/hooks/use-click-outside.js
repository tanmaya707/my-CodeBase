import { useEffect } from "react";

/**
 * Detects click outside of an element and triggers a callback.
 * @param {object} ref - React ref object pointing to the element.
 * @param {function} callback - Function to run when clicked outside.
 */
export function useClickOutside(ref, callback, isList=true, openRowId = null) {
  useEffect(() => {
    const handleClickOutside = (event) => {
      // console.log("ref?.current ::: ", ref?.current);
      // console.log("event.target ::: ", event.target);
      if(isList) {
        if (ref?.current) {
          for (const key in ref?.current) {
            // console.log("key ::: ", key, openRowId);
            if (Object.hasOwnProperty.call(ref?.current, key)) {
              const element = ref?.current[key];
              if (element && element.contains(event.target)) {
                return;
              }
            }
          }
          callback();
        }
      }
      else if (ref?.current && !ref?.current?.contains(event.target)) {        
        callback();
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [ref, callback]);
  return ref;
}
