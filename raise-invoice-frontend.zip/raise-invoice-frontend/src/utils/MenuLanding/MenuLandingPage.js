import React, { useState } from "react";
import "./landing.css";
import { useRouter } from "next/navigation";

const MenuLandingPage = ({
  Image,
  text,
  label,
  tabs,
  handleState,
  itemType,
  activeTag,
  datas,
  onTabClick, // Accept the handler as a prop
  createRoute
}) => {
  const router = useRouter();
  const [addClientForm, setAddClientForm] = useState(false);
  return (
    <>
          {/* {addClientForm ? (
            <InvoiceForm activeTag={activeTag} />
          ) : ( */}
            <>
              <div className={!addClientForm ? "scrollRightSide" : ""}>
                {tabs ? (
                  <div className="invoice-tabs">
                    {tabs.length > 0 &&
                      tabs.map((tab) => (
                        <span 
                          key={tab.name}
                          style={{ cursor: "pointer" }}
                          onClick={() => onTabClick && onTabClick(tab)}
                        >
                          {tab.name}
                          </span>
                      ))}
                  </div>
                ) : (
                  <></>
                )}
                <div className="invoice-tabs-bottom">
                  <img className="tab" src={Image} />
                  <div className="landing-bottom ">
                     {!datas && <p>{text}</p>}
                    {itemType === "Client" ? (
                    <button
                      onClick={() => setAddClientForm(true)}
                      className="link-btn"
                    >
                      {label}
                    </button>
                  ) : itemType === "Estimate" ? (
                    <button
                      onClick={() => router.push('/estimate/create')}
                      className="create-btn"
                    >
                      {label}
                    </button>
                  ) : (
                    <button
                      onClick={() => createRoute ? router.push(createRoute) : handleState(true)}
                      className="create-btn"
                    >
                      {label}
                    </button>
                  )}
                  </div>
                </div>
              </div>
            </>
          {/* )} */}
        {/* </div> */}
      {/* </div> */}
    </>
  );
};

// const MenuLandingPage = ({
//     Image,
//     text,
//     label,
//     tabs,
//     handleState,
//     itemType,
//     activeTag,
//     datas,
//     onTabClick, // Accept the handler as a prop
// }) => {
//     const [addClientForm, setAddClientForm] = useState(false);

//     return (
//         <>
//             <div className="col-lg-8">
//                 <div className="add-client contentArea">
//                     {addClientForm ? (
//                         <InvoiceForm activeTag={activeTag} />
//                     ) : (
//                         <>
//                             <div className={!addClientForm ? "scrollRightSide" : ""}>
//                                 {tabs ? (
//                                     <div className="invoice-tabs">
//                                         {tabs.length > 0 &&
//                                             tabs.map((tab) => (
//                                                 <span
//                                                     key={tab.name}
//                                                     style={{ cursor: "pointer" }}
//                                                     onClick={() => onTabClick && onTabClick(tab)}
//                                                 >
//                                                     {tab.name}
//                                                 </span>
//                                             ))}
//                                     </div>
//                                 ) : null}
//                                 <div className="invoice-tabs-bottom">
//                                     <img className="tab" src={Image} />
//                                     <div className="landing-bottom ">
//                                         {!datas && <p>{text}</p>}
//                                         {itemType === "Client" ? (
//                                             <button
//                                                 onClick={() => setAddClientForm(true)}
//                                                 className="link-btn"
//                                             >
//                                                 {label}
//                                             </button>
//                                         ) : (
//                                             <button
//                                                 onClick={() => handleState(true)}
//                                                 className="create-btn"
//                                             >
//                                                 {label}
//                                             </button>
//                                         )}
//                                     </div>
//                                 </div>
//                             </div>
//                         </>
//                     )}
//                 </div>
//             </div>
//         </>
//     );
// };
export default MenuLandingPage;
