import React from 'react';
import './toggle.css';
import Form from 'react-bootstrap/Form';
import PropTypes from 'prop-types';

const ToggleButton = (props) => {
  const { isToggled = false, onToggle = () => { }, id = "", heading = "", para = "" } = props;
  return (
    <div className='review'>
      <div className='reviewLeft'>
        <h6>{heading}</h6>
        <p>{para}</p>
      </div>
      <div className='reviewRight'>
        <Form.Check
          type="switch"
          id={id}
          label=""
          checked={isToggled}
          onChange={onToggle}
        />
      </div>
    </div>
  );
}

ToggleButton.defaultProps = {
  isToggled: PropTypes.bool,
  onToggle: PropTypes.func,
  id: PropTypes.number,
  heading: PropTypes.string,
  para: PropTypes.string
};

export default ToggleButton;

