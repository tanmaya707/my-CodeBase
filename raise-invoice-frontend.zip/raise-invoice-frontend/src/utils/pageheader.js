// import React from 'react';

// const Pageheader = ({ label, handleSave, user }) => {

//   return (
//     <div className='navbar-tab mb-4'>
//       <h4>{label}</h4>
//       {user?.userCompany == null && (
//         <button onClick={handleSave}>Save</button>
//       )}
//     </div>
//   );
// }

// export default Pageheader;


import React from 'react';

// const Pageheader = ({ label, handleSave, user, loading, itemToEdit }) => {
//   return (
//     <div className={itemToEdit ? "itemHeder mb-4" : "navbar-tab mb-4"}>
//       <h4>{label}</h4>
//       {user?.userCompany == null && (
//         <button onClick={handleSave} disabled={loading}>
//           {loading ? 'Saving...' : 'Save'}
//         </button>
//       )}
//     </div>
//   );
// }

const Pageheader = ({ label, handleSave, user, loading, itemToEdit }) => {
  const containerClass = `navbar-tab mb-4 ${
    itemToEdit ? "editItemHeader" : "editItemHeader"
  }`;

  return (
    <div className="navbar-tab mb-4 editItemHeader">
      <h4>{label}</h4>
      {user?.userCompany == null && (
        <button onClick={handleSave} disabled={loading}>
          {loading ? "Saving..." : "Save"}
        </button>
      )}
    </div>
  );
};


export default Pageheader;

