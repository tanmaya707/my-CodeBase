// import React from 'react';

// const Pageheader = ({ label, handleSave, user }) => {

//   return (
//     <div className='navbar-tab mb-4'>
//       <h4>{label}</h4>
//       {user?.userCompany == null && (
//         <button onClick={handleSave}>Save</button>
//       )}
//     </div>
//   );
// }

// export default Pageheader;


import React, { useEffect, useState } from 'react';

// const Pageheader = ({ label, handleSave, user, loading, itemToEdit }) => {
//   return (
//     <div className={itemToEdit ? "itemHeder mb-4" : "navbar-tab mb-4"}>
//       <h4>{label}</h4>
//       {user?.userCompany == null && (
//         <button onClick={handleSave} disabled={loading}>
//           {loading ? 'Saving...' : 'Save'}
//         </button>
//       )}
//     </div>
//   );
// }

         // =============stickey top form heafer==========
  
  
      useEffect(() => {
      const handleScroll = () => {
  
        const element = document.querySelector('.addClientFormTop');
        if (!element) return;
  
        const offsetTop = element.offsetTop; // distance from top of document
        const scrollTop = window.scrollY;
  
        setIsSticky(scrollTop > 50);
      };
  
      window.addEventListener('scroll', handleScroll);
      return () => window.removeEventListener('scroll', handleScroll);
    }, []);




const Pageheader = ({ label, handleSave, user, loading, itemToEdit, stickeyHeader }) => {
  const containerClass = `navbar-tab mb-4 ${
    itemToEdit ? "editItemHeader" : "editItemHeader"
  }`;

  
      const [isSticky, setIsSticky] = useState(false);
  
  return (
    // <div className={containerClass} >
    <div className={`containerClass ${stickeyHeader? 'addClientFormTop' : ""}` } >

    <div className="navbar-tab mb-4 editItemHeader" >
      <h4>{label}</h4>
      {user?.userCompany == null && (
        <button onClick={handleSave} disabled={loading}>
          {loading ? "Saving..." : "Save"}
        </button>
      )}
    </div>
    </div>

  );
};


export default Pageheader;

