import { text } from "@fortawesome/fontawesome-svg-core";
import { createSlice } from "@reduxjs/toolkit";

const initialState = {

}

export const authSlice = createSlice({
    name: "auth",
    initialState,
    reducers: {
        login: (state, action) => {
            const login= {
                text: action.payload,
            }
        },
        signup: (state, action) => {
            const signup= {
                text: action.payload,
            }
        }
    }
})

export const {login, signup} = authSlice.actions;
export default authSlice.reducer;