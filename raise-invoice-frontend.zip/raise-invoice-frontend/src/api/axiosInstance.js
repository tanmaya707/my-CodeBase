
import axios from "axios";
import { storage } from "../dependencies/store/storage";
import { setIsLoading } from "../redux/slices/loadingSlice";

export const httpClient = axios.create({
  timeout: 5 * 60 * 1000,
  httpsAgent: {
    rejectUnauthorized: false,
  },
});

let dispatchRef = null; 
export const setDispatch = (dispatch) => {
  dispatchRef = dispatch;
};

httpClient.interceptors.request.use((config) => {
  if (dispatchRef) {
    dispatchRef(setIsLoading(true));
  }
  const token = storage.getToken();
  if (token) {
    config.headers["Authorization"] = `Bearer ${token}`;
  }
  return config;
}, (error) => {
  if (dispatchRef) {
    dispatchRef(setIsLoading(false));
  }
  return Promise.reject(error);
});

httpClient.interceptors.response.use((response) => {
  if (dispatchRef) {
    dispatchRef(setIsLoading(false));
  }
  return response;
}, (error) => {
  if (dispatchRef) {
    dispatchRef(setIsLoading(false));
  }
  return Promise.reject(error);
});

export default httpClient;
