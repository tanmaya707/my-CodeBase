import axios from 'axios';
const authToken = (typeof localStorage !== 'undefined') ? localStorage.getItem("auth-token") : null;
export default axios.create({
    baseURL: process.env.NEXT_PUBLIC_API_URL+'api/',
    headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + authToken
    }
})
