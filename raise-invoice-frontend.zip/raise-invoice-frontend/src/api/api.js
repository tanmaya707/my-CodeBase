import apiConnection from "./apiConnection";

class Api {
  POST(url, payload = {}, config = {}) {
    return apiConnection.post(url, payload, config).catch((error) => error?.response);
  }

  GET(url, config = {}) {
    return apiConnection.get(url, config).catch((error) => error?.response);
  }

  DELETE(url, config = {}) {
    return apiConnection.delete(url, config).catch((error) => error?.response);
  }

  PUT(url, payload = {}, config = {}) {
    return apiConnection.put(url, payload, config).catch((error) => error?.response);
  }
}

const apiInstance = new Api();
export default apiInstance;
