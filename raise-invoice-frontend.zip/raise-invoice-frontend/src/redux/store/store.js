import { configureStore } from "@reduxjs/toolkit";
import authReducer from "../slices/authSlice";
import loadingReducer from "../slices/loadingSlice";
import dataReducer from "../slices/dataSlice";
import projectReducer from "../slices/projectSlice"; // Assuming projectReducer is defined in projectSlice.js
import { createLogger } from 'redux-logger';

// Create a logger middleware
const logger = createLogger();

// Configure the store
const store = configureStore({
  reducer: {
    auth: authReducer,
    loading: loadingReducer,
    dataReducer: dataReducer,
    projectReducer: projectReducer, // Assuming projectReducer is part of dataReducer
  },
  // middleware: (getDefaultMiddleware) => getDefaultMiddleware().concat(logger)
});

export default store;