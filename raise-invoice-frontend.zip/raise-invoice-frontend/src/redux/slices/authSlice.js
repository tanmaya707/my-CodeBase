import { GET_CAREER_, GET_CAREER_JOB_LIST, GET_FAQS, GET_PRICING_CATEGORIES, GET_PRICING_SELECTPRICING, GET_PRICING_SELECTPRICING_FEATURES, CLIENT_REGISTER, CLIENT_LOGOUT, CLIENT_LOGIN, CLIENT_COMPANY_CREATE, CLIENT_PROFILE_DETAILS, CLIENT_PROFILE_UPDATE, CLIENT_PLAN_DETAILS } from "@/constaints/ApplicationUrl";
import Api from "@/dependencies/utils/Api";
import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";

export const signup = createAsyncThunk(
  "auth/signup",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POST(CLIENT_REGISTER, userData);

      if (typeof localStorage !== 'undefined') {
        localStorage.setItem("web-auth-token", response.data.data.deviceToken);
        localStorage.setItem("user-details", JSON.stringify(response.data.data.userDetails))
      }
      return response.data;
    } catch (error) {
      return rejectWithValue({ message: error.response?.data?.message || "Signup failed. Please try again later." });
    }
  }
);

export const signin = createAsyncThunk(
  "auth/signin",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POST(CLIENT_LOGIN, userData);

      // Destructure the response for cleaner access
      const { deviceToken, user } = response?.data?.data || {};

      // Check if deviceToken and user exist before setting them in localStorage
      if (deviceToken) {
        (typeof localStorage !== 'undefined') ? localStorage.setItem("web-auth-token", deviceToken) : '';
      } else {
        // console.error("Device token is missing in the response.");
      }

      if (user) {
        (typeof localStorage !== 'undefined') ? localStorage.setItem("user-details", JSON.stringify(user)) : '';
        (typeof localStorage !== 'undefined') ? localStorage.setItem("CountryId", user.companyTaxDetails.countryId) : '';
        (typeof localStorage !== 'undefined') ? localStorage.setItem("Currency", user.companyTaxDetails.currency) : '';
      } else {
        // console.error("User  details are missing in the response.");
      }

      return response.data;

    } catch (error) {
      return rejectWithValue({ message: error.response?.data?.message || "Signin failed. Please try again later." });
    }
  }
);

export const signout = createAsyncThunk(
  "auth/signout",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POST(CLIENT_LOGOUT, userData);
      if (response) {
        if ((typeof localStorage !== 'undefined')) {
          localStorage.removeItem("web-auth-token");
          localStorage.removeItem("user-details");
          localStorage.removeItem("CountryId");
          localStorage.removeItem("Currency");
        }
        return response.data;
      }
    } catch (error) {
      return rejectWithValue({ message: error ?? "Logout failed. Please try again later." });
    }
  }
);

export const postFaqCategory = createAsyncThunk(
  "auth/postFaqCategory",
  async (_, { rejectWithValue }) => { // Omit faqData argument
    try {
      const response = await Api.POST(GET_FAQS); // Call API without sending data
      return response.data; // Return the response directly
    } catch (error) {
      return rejectWithValue({ message: "Failed to post FAQ category." });
    }
  }
);

export const postFaqCategoryPricing = createAsyncThunk(
  "auth/postFaqCategory",
  async (_, { rejectWithValue }) => {
    try {
      const response = await Api.POST(GET_PRICING_CATEGORIES);
      return response.data;
    } catch (error) {
      const errorMessage = error.message || "Failed to post FAQ category.";
      return rejectWithValue({ error: errorMessage });
    }
  }
);

export const postFaqCategoryEelectPricing = createAsyncThunk(
  "auth/postFaqCategoryEelectPricing",
  async (payload, { rejectWithValue }) => {
    try {
      const response = await Api.POST(GET_PRICING_SELECTPRICING, payload); // Pass the payload for the request
      return response.data;
    } catch (error) {
      const errorMessage = error.message || "Failed to post FAQ category.";
      return rejectWithValue({ error: errorMessage });
    }
  }
);

export const postFaqCategorySelectPricing = createAsyncThunk(
  "auth/postFaqCategorySelectPricing",
  async (payload, { rejectWithValue }) => {
    try {
      const response = await Api.POST(GET_PRICING_SELECTPRICING_FEATURES, payload);
      return response.data;
    } catch (error) {
      const errorMessage = error.message || "Failed to post FAQ select pricing.";
      return rejectWithValue({ error: errorMessage });
    }
  }
);

export const postCarrerHero = createAsyncThunk(
  "auth/postFaqCategorySelectPricing",
  async (payload, { rejectWithValue }) => {
    try {
      const response = await Api.POST(GET_CAREER_, payload);
      return response.data;
    } catch (error) {
      const errorMessage = error.message || "Failed to post FAQ select pricing.";
      return rejectWithValue({ error: errorMessage });
    }
  }
);

export const postCarrerList = createAsyncThunk(
  "auth/postFaqCategorySelectPricing",
  async (payload, { rejectWithValue }) => {
    try {
      const response = await Api.POST(GET_CAREER_JOB_LIST, payload);
      return response.data;
    } catch (error) {
      const errorMessage = error.message || "Failed to post FAQ select pricing.";
      return rejectWithValue({ error: errorMessage });
    }
  }
);

export const postCarrerListDetailsByUuid = createAsyncThunk(
  "auth/postCarrerListDetailsByUuid",
  async (payload, { rejectWithValue }) => {
    try {
      const response = await Api.POST(GET_JOB_CATEGORIES_DETAILS, payload);
      return response.data;
    } catch (error) {
      const errorMessage = error.message || "Failed to fetch job details.";
      return rejectWithValue({ error: errorMessage });
    }
  }
);

export const clientCompanyCreate = createAsyncThunk(
  "data/clientCompanyCreate",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POST(CLIENT_COMPANY_CREATE, userData);
      const companyDetails = response.data?.defaultCurrencyData;
      if(companyDetails){
        localStorage.setItem("CountryId", companyDetails.id);
        localStorage.setItem("Currency", companyDetails.currency_code);
      }
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message: error.response?.data?.message || "Failed to create company account. Please try again later."
      });
    }
  }
);

// CLIENT PROFILE DEATAILS
export const clientProfileDetails = createAsyncThunk(
  "auth/clientProfileDetails",
  async (payload, { rejectWithValue }) => {
    try {
      const response = await Api.POST(CLIENT_PROFILE_DETAILS, payload);
      return response.data;
    } catch (error) {
      const errorMessage = error.message || "Failed to profile details.";
      return rejectWithValue({ error: errorMessage });
    }
  }
);

// CLIENT PROFILE UPDATE
export const clientCompanyUpdate = createAsyncThunk(
  "data/clientCompanyUpdate",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POST(CLIENT_PROFILE_UPDATE, { userData });
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message: error.response?.data?.message || "Failed to update. Please try again later."
      });
    }
  }
);

// CLIENT PLAN DEATAILS
export const clientPlanDetails = createAsyncThunk(
  "auth/clientPlanDetails",
  async (payload, { rejectWithValue }) => {
    try {
      const response = await Api.POST(CLIENT_PLAN_DETAILS, payload);
      return response.data;
    } catch (error) {
      const errorMessage = error.message || "Failed to plan details.";
      return rejectWithValue({ error: errorMessage });
    }
  }
);

// export const sendVerificationCode = createAsyncThunk(
//   "auth/sendVerificationCode",
//   async (payload, { rejectWithValue }) => {
//     try {
//       const response = await Api.POST(GET_CAREER_JOB_DETAILS, payload);
//       return response.data;
//     } catch (error) {
//       const errorMessage = error.message || "Failed to post FAQ select pricing.";
//       return rejectWithValue({ error: errorMessage });
//     }
//   }
// );
// export const resetPasswordClient = createAsyncThunk(
//   "auth/resetPasswordClient",
//   async (payload, { rejectWithValue }) => {
//     try {
//       const response = await Api.POST(GET_CAREER_JOB_DETAILS, payload);
//       return response.data;
//     } catch (error) {
//       const errorMessage = error.message || "Failed to post FAQ select pricing.";
//       return rejectWithValue({ error: errorMessage });
//     }
//   }
// );

const authSlice = createSlice({
  name: "auth",
  initialState: {
    data: null,
    user: null,
    todo: null,
    faqResponse: null,
    faqResponsePricing: null,
    faqResponseSelectPricing: null,
    error: null,
    isLoading: false,
    plan: null,
    permissions: {}
  },
  reducers: {

  },
  extraReducers: (builder) => {
    builder
      // Existing cases...
      .addCase(signup.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(signup.fulfilled, (state, action) => {
        state.isLoading = false;
        state.user = action.payload.data;
      })
      .addCase(signup.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload.message;
      })

      // Signin Client
      .addCase(signin.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(signin.fulfilled, (state, action) => {
        state.isLoading = false;
        state.user = action.payload.data;
      })
      .addCase(signin.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload.message;
      })

      // Signout Client
      .addCase(signout.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(signout.fulfilled, (state, action) => {
        state.isLoading = false;
        state.user = null;
      })
      .addCase(signout.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload.message;
      })

      // New cases for posting FAQ category details
      .addCase(postFaqCategory.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(postFaqCategory.fulfilled, (state, action) => {
        state.isLoading = false;
        state.faqResponse = action.payload; // Store the response
      })
      .addCase(postFaqCategory.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload.message;
      })

      //Client Company Create
      .addCase(clientCompanyCreate.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(clientCompanyCreate.fulfilled, (state, action) => {
        state.isLoading = false;
        state.data = action.payload;
      })
      .addCase(clientCompanyCreate.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload?.message || action.error.message;
      })

      // Client profile details
      .addCase(clientProfileDetails.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(clientProfileDetails.fulfilled, (state, action) => {
        state.isLoading = false;
        state.user = action.payload;
      })
      .addCase(clientProfileDetails.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload.message;
      })
      // Client plan details
      .addCase(clientPlanDetails.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(clientPlanDetails.fulfilled, (state, action) => {
        state.isLoading = false;
        state.plan = action.payload.data;
        action.payload.data?.forEach(permission => {
          // console.log("permission :: ", permission);
          permission.features?.forEach(permission_feature => {
            // console.log("permission_feature :: ", {...state.permissions, [permission_feature?.slug] : permission_feature.plan_features[0]});
            state.permissions = {...state.permissions, [permission_feature?.slug] : permission_feature.plan_features[0]}
          })
        })
      })
      .addCase(clientPlanDetails.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload.message;
      })
      // Client profile update
      .addCase(clientCompanyUpdate.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(clientCompanyUpdate.fulfilled, (state, action) => {
        state.isLoading = false;
        state.faqResponse = action.payload;
      })
      .addCase(clientCompanyUpdate.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload.message;
      })

    // Client send verification code
    // .addCase(sendVerificationCode.pending, (state) => {
    //   state.isLoading = true;
    // })
    // .addCase(sendVerificationCode.fulfilled, (state, action) => {
    //   state.isLoading = false;
    //   state.faqResponse = action.payload;
    // })
    // .addCase(sendVerificationCode.rejected, (state, action) => {
    //   state.isLoading = false;
    //   state.error = action.payload.message;
    // })

    // Client reset password
    // .addCase(resetPasswordClient.pending, (state) => {
    //   state.isLoading = true;
    // })
    // .addCase(resetPasswordClient.fulfilled, (state, action) => {
    //   state.isLoading = false;
    //   state.faqResponse = action.payload;
    // })
    // .addCase(resetPasswordClient.rejected, (state, action) => {
    //   state.isLoading = false;
    //   state.error = action.payload.message;
    // })
  },
});

export default authSlice.reducer;
