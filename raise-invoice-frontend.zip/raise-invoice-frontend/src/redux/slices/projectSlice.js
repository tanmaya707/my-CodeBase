import { DELETE_CONTACTS, DELETE_TASKS, GET_CONTACTS, GET_CONTACTS_FOR_APPOINTMENT, GET_LOG, GET_TASKS, SAVE_CONTACT, SAVE_LOG, SAVE_TASK, UPDATE_CONTACTS, UPDATE_TASKS } from "@/constaints/ApplicationUrl";
import Api from "@/dependencies/utils/Api";
import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";

export const addContactApi = createAsyncThunk(
  "addContact",
  async (payload, { rejectWithValue }) => {
    try {
      const response = await Api.POST(SAVE_CONTACT, payload);
      return response.data;
    } catch (error) {
      const errorMessage = error.message || "Failed to add contact.";
      return rejectWithValue({ error: errorMessage });
    }
  }
);

export const updateContactApi = createAsyncThunk(
  "updateContact",
  async (payload, { rejectWithValue }) => {
    try {
      const response = await Api.POST(UPDATE_CONTACTS, payload);
      return response.data;
    } catch (error) {
      const errorMessage = error.message || "Failed to fetch contacts.";
      return rejectWithValue({ error: errorMessage });
    }
  }
);

export const deleteContactApi = createAsyncThunk(
  "deleteContact",
  async (payload, { rejectWithValue }) => {
    try {
      const response = await Api.POST(DELETE_CONTACTS, payload);
      return response.data;
    } catch (error) {
      const errorMessage = error.message || "Failed to fetch contacts.";
      return rejectWithValue({ error: errorMessage });
    }
  }
);
export const getContactsApi = createAsyncThunk(
  "getContacts",
  async (payload, { rejectWithValue }) => {
    try {
      const response = await Api.POST(GET_CONTACTS, payload);
      return response.data;
    } catch (error) {
      const errorMessage = error.message || "Failed to fetch contacts.";
      return rejectWithValue({ error: errorMessage });
    }
  }
);

export const getContactsForAppointment = createAsyncThunk(
  "getContactsForAppointment",
  async (payload, { rejectWithValue }) => {
    try {
      const response = await Api.POST(GET_CONTACTS_FOR_APPOINTMENT, payload);
      return response.data;
    } catch (error) {
      const errorMessage = error.message || "Failed to fetch contacts.";
      return rejectWithValue({ error: errorMessage });
    }
  }
);

export const addTaskApi = createAsyncThunk(
  "addTask",
  async (payload, { rejectWithValue }) => {
    try {
      const response = await Api.POST(SAVE_TASK, payload);
      return response.data;
    } catch (error) {
      const errorMessage = error.message || "Failed to add task to this project.";
      return rejectWithValue({ error: errorMessage });
    }
  }
);

export const updateTasksApi = createAsyncThunk(
  "updateTasks",
  async (payload, { rejectWithValue }) => {
    try {
      const response = await Api.POST(UPDATE_TASKS, payload);
      return {...response.data, ...payload};
    } catch (error) {
      const errorMessage = error.message || "Failed to add task to this project.";
      return rejectWithValue({ error: errorMessage });
    }
  }
)

export const deleteTasksApi = createAsyncThunk(
  "deleteTasks",
  async (payload, { rejectWithValue }) => {
    try {
      const response = await Api.POST(DELETE_TASKS, payload);
      return {...response.data, ...payload };
    } catch (error) {
      const errorMessage = error.message || "Failed to add task to this project.";
      return rejectWithValue({ error: errorMessage });
    }
  }
)

export const getTasksApi = createAsyncThunk(
  "getTasks",
  async (payload, { rejectWithValue }) => {
    try {
      const response = await Api.POST(GET_TASKS, payload);
      return response.data;
    } catch (error) {
      const errorMessage = error.message || "Failed to get tasks for this project.";
      return rejectWithValue({ error: errorMessage });
    }
  }
);

export const saveTimeAPI = createAsyncThunk(
  "saveLog",
  async (payload, { rejectWithValue }) => {
    try {
      const response = await Api.POST(SAVE_LOG, payload);
      return response.data;
    } catch (error) {
      const errorMessage = error.message || "Failed to get tasks for this project.";
      return rejectWithValue({ error: errorMessage });
    }
  }
);

export const getTimeAPI = createAsyncThunk(
  "getLog",
  async (payload, { rejectWithValue }) => {
    try {
      const response = await Api.POST(GET_LOG, payload);
      return response.data;
    } catch (error) {
      const errorMessage = error.message || "Failed to get tasks for this project.";
      return rejectWithValue({ error: errorMessage });
    }
  }
);

const projectSlice = createSlice({
    name: "project",
    initialState: {
        loading: false,
        error: null,
        success: false,
        contacts: [],
        tasks: [],
        logs: []
    },
    reducers: {},
    extraReducers: (builder) => {
        builder
        .addCase(addContactApi.pending, (state) => {
            state.loading = true;
            state.error = null;
            state.success = false;
        })
        .addCase(addContactApi.fulfilled, (state, action) => {
            state.loading = false;
            state.success = true;
            state.contacts = [ ...state.contacts, action.payload.data ]|| [];
        })
        .addCase(addContactApi.rejected, (state, action) => {
            state.loading = false;
            state.error = action.payload.error || "Failed to add contact.";
        })
        .addCase(getContactsApi.pending, (state) => {
            state.loading = true;
            state.error = null;
        })
        .addCase(getContactsApi.fulfilled, (state, action) => {
            // console.log("Contacts fetched successfully:", action.payload.data);
            
            state.loading = false;
            state.contacts = action.payload.data || [];
        })
        .addCase(getContactsApi.rejected, (state, action) => {
            state.loading = false;
            state.error = action.payload.error || "Failed to fetch contacts.";
        })
        .addCase(updateContactApi.pending, (state) => {
            state.loading = true;
            state.error = null;
            state.success = false;
        })
        .addCase(updateContactApi.fulfilled, (state) => {
            state.loading = false;
            state.success = true;
        })
        .addCase(updateContactApi.rejected, (state, action) => {
            state.loading = false;
            state.error = action.payload.error || "Failed to update contact.";
        })
        .addCase(deleteContactApi.pending, (state) => {
            state.loading = true;
            state.error = null;
            state.success = false;
        })
        .addCase(deleteContactApi.fulfilled, (state) => {
            state.loading = false;
            state.success = true;
        })
        .addCase(deleteContactApi.rejected, (state, action) => {
            state.loading = false;
            state.error = action.payload.error || "Failed to delete contact.";
        })
        .addCase(addTaskApi.pending, (state) => {
            state.loading = true;
            state.error = null;
            state.success = false;
        })
        .addCase(addTaskApi.fulfilled, (state, action) => {
            state.loading = false;
            state.success = true;
            // Assuming tasks are stored in the same way as contacts
            state.tasks = [ ...state.tasks, action.payload.data ] || [];
        })
        .addCase(addTaskApi.rejected, (state, action) => {
            state.loading = false;
            state.error = action.payload.error || "Failed to add task.";
        })
        .addCase(getTasksApi.pending, (state) => {
            state.loading = true;
            state.error = null;
        })
        .addCase(getTasksApi.fulfilled, (state, action) => {
            // console.log("Tasks fetched successfully:", action.payload.data);
            state.loading = false;
            state.tasks = action.payload.data || [];
        })
        .addCase(getTasksApi.rejected, (state, action) => {
            state.loading = false;
            state.error = action.payload.error || "Failed to fetch tasks.";
        })
        .addCase(updateTasksApi.pending, (state) => {
            state.loading = true;
            state.error = null;
            state.success = false;
        })
        .addCase(updateTasksApi.fulfilled, (state) => {
            state.loading = false;
            state.success = true;
        })
        .addCase(updateTasksApi.rejected, (state, action) => {
            state.loading = false;
            state.error = action.payload.error || "Failed to update task.";
        })
        .addCase(deleteTasksApi.pending, (state) => {
            state.loading = true;
            state.error = null;
            state.success = false;
        })
        .addCase(deleteTasksApi.fulfilled, (state, action) => {
            state.loading = false;
            state.success = true;
            // Assuming tasks are stored in the same way as contacts
            const deletedTaskId = action.payload.id;
            // console.log(deletedTaskId);
            
            state.tasks = state.tasks.filter(task => task.id !== deletedTaskId);
        })
        .addCase(deleteTasksApi.rejected, (state, action) => {
            state.loading = false;
            state.error = action.payload.error || "Failed to delete task.";
        })
        .addCase(saveTimeAPI.pending, (state) => {
            state.loading = true;
            state.error = null;
            state.success = false;
        })
        .addCase(saveTimeAPI.fulfilled, (state) => {
            state.loading = false;
            state.error = null;
            state.success = true;
        })
        .addCase(saveTimeAPI.rejected, (state, action) => {
            state.loading = false;
            state.error = action.payload.error || "Failed to save time log for this task.";
        })
        .addCase(getTimeAPI.pending, (state) => {
            state.loading = true;
            state.error = null;
            state.success = false;
        })
        .addCase(getTimeAPI.fulfilled, (state, action) => {
            state.loading = false;
            state.error = null;
            state.success = true;
            state.logs = [...action.payload.data]
        })
        .addCase(getTimeAPI.rejected, (state, action) => {
            state.loading = false;
            state.error = action.payload.error || "Failed to save time log for this task.";
        });
    },
})

export default projectSlice.reducer;