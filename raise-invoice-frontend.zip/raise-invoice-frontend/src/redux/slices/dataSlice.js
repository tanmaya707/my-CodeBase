import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import {
  GET_MASTER_DATA,
  GET_PROJECT_SETTINGS_DATA,
  STORE_PROJECT_SETTINGS_DATA,
  GET_COMMUNICATION_SETTINGS_DATA,
  STORE_COMMUNICATION_SETTINGS_DATA,
  CLIENT_PROFILE_DETAILS,
  SWITCH_ACCOUNT,
  CLIENT_PROFILE_UPDATE,
  GET_CLIENT_DATA,
  CREATE_CLIENT_DATA,
  DETAILS_CLIENT_DATA,
  GET_APPOINTMENT_DATA,
  CREATE_APPOINTMENT_DATA,
  GET_SINGLE_APPOINTMENT_DATA,
  UPDATE_APPOINTMENT_DATA,
  DELETE_APPOINTMENT_DATA,
  GET_PROJECT_DATA,
  SAVE_PROJECT_FILE,
  GET_PROJECT_FILE,
  DELETE_PROJECT_FILE,
  CREATE_PROJECT_DATA,
  DETAILS_PROJECT_DATA,
  UPDATE_PROJECT_DATA,
  DELETE_PROJECT_DATA,
  GET_ROLE_DATA,
  CREATE_ROLE_DATA,
  DETAILS_ROLE_DATA,
  GET_CLIENT_ADMIN_DATA,
  CREATE_CLIENT_ADMIN_DATA,
  DETAILS_CLIENT_ADMIN_DATA,
  DETAILS_CLIENT_ADMIN_DATA_BY_UUID,
  CLIENT_SUBSCRIPTION_REG,
  GET_ITEM_DATA,
  CREATE_ITEM_DATA,
  UPDATE_ITEM_DATA,
  DETAILS_ITEM_DATA,
  CREATE_TAX_DATA,
  GET_TAX_DATA,
  DELETE_TAX_DATA,
  CREATE_INVOICE_DATA,
  GET_INVOICE_DATA,
  NEXT_INVOICE_NUMBER,
  DETAILS_INVOICE_DATA,
  UPDATE_INVOICE_DATA,
  DELETE_INVOICE_DATA,
  LIST_LOGO_DATA,
  DELETE_LOGO_DATA,
  CREATE_LOGO_DATA,
  GET_LOG,
  LIST_COLOR_DATA,
  CREATE_WATERMARK_DATA,
  LIST_WATERMARK_DATA,
  DELETE_WATERMARK_DATA,
  LIST_HEADER_DATA,
  CREATE_HEADER_DATA,
  DELETE_HEADER_DATA,
  CREATE_CUSTOM_INVOICE_DATA,
  GET_CUSTOM_INVOICE_DATA,
  CREATE_CUSTOM_INVOICE_OPTION_DATA,
  GET_CUSTOM_INVOICE_OPTION_DATA,
  DELETE_ITEM_DATA,
  GET_ESTIMATE_DATA,
  NEXT_ESTIMATE_NUMBER,
  CREATE_ESTIMATE_DATA,
  DETAILS_ESTIMATE_DATA,
  UPDATE_ESTIMATE_DATA,
  DELETE_ESTIMATE_DATA,
  CREATE_CREDIT_NOTE_DATA,
  NEXT_CREDIT_NOTE_NUMBER,
  GET_CREDIT_NOTE_DATA,
  DETAILS_CREDIT_NOTE_DATA,
  UPDATE_CREDIT_NOTE_DATA,
  DELETE_CREDIT_NOTE_DATA,
  CREATE_PURCHASE_ORDER_DATA,
  NEXT_PURCHASE_ORDER_NUMBER,
  GET_PURCHASE_ORDER_DATA,
  DETAILS_PURCHASE_ORDER_DATA,
  UPDATE_PURCHASE_ORDER_DATA,
  DELETE_PURCHASE_ORDER_DATA,
  SEND_MAIL,
  RESET_PASSWORD_MAIL,
  RESET_PASSWORD,
  CREATE_EXPENSE_DATA,
  NEXT_EXPENSE_NUMBER,
  GET_EXPENSE_DATA,
  DETAILS_EXPENSE_DATA,
  UPDATE_EXPENSE_DATA,
  DELETE_EXPENSE_DATA,
  GET_CLIENT_PROJECT_DATA,
  GET_DASHBOARD_DATA,
  CREATE_INVOICE_SIGNATURE_DATA,
  GET_INVOICE_SIGNATURE_DATA,
  PROFILE_PICTURE,

} from "@/constaints/ApplicationUrl";
import Api from "@/dependencies/utils/Api";

const token =
  typeof localStorage !== "undefined"
    ? localStorage.getItem("web-auth-token")
    : null;
// Fetch master data
export const fetchMasterData = createAsyncThunk(
  "data/fetchMasterData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.GET(GET_MASTER_DATA, { params: userData });
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to fetch master data. Please try again later.",
      });
    }
  }
);
// Fetch project setting data
export const fetchProjectSettingData = createAsyncThunk(
  "data/fetchProjectSettingData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POST(GET_PROJECT_SETTINGS_DATA, {
        params: userData,
      });
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to fetch project data. Please try again later.",
      });
    }
  }
);

export const sendMail = createAsyncThunk(
  "data/sendMail",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POST(SEND_MAIL, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to send mail data. Please try again later.",
      });
    }
  }
);

export const resetPasswordMail = createAsyncThunk(
  "data/resetPasswordMail",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POST(RESET_PASSWORD_MAIL, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to send mail data. Please try again later.",
      });
    }
  }
);

export const resetPassword = createAsyncThunk(
  "data/resetPassword",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POST(RESET_PASSWORD, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to send mail data. Please try again later.",
      });
    }
  }
);

// Update project setting data
export const updateProjectSettingData = createAsyncThunk(
  "data/updateProjectSettingData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POST(STORE_PROJECT_SETTINGS_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to update project data. Please try again later.",
      });
    }
  }
);

// Create invoice signature data
export const createInvoiceSignature = createAsyncThunk(
  "data/createInvoiceSignature",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POST(CREATE_INVOICE_SIGNATURE_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to create invoice signature. Please try again later.",
      });
    }
  }
);

export const getInvoiceSignature = createAsyncThunk(
  "data/getInvoiceSignature",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POST(GET_INVOICE_SIGNATURE_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to get invoice signature. Please try again later.",
      });
    }
  }
);
// Fetch communication setting data
export const fetchCommunicationSettingData = createAsyncThunk(
  "data/fetchCommunicationSettingData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POST(GET_COMMUNICATION_SETTINGS_DATA, {
        params: userData,
      });
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to fetch communication data. Please try again later.",
      });
    }
  }
);
// Update communication setting data
export const updateCommunicationSettingData = createAsyncThunk(
  "data/updateCommunicationSettingData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POST(
        STORE_COMMUNICATION_SETTINGS_DATA,
        userData
      );
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to update profile data. Please try again later.",
      });
    }
  }
);
// Fetch tax security setting data
export const fetchTaxSecurityData = createAsyncThunk(
  "data/fetchTaxSecurityData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POST(GET_TAX_SECURITY_DATA, {
        params: userData,
      });
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to fetch tax profile data. Please try again later.",
      });
    }
  }
);
// Update tax security setting data
export const updateTaxSecurityData = createAsyncThunk(
  "data/updateTaxSecuritygData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POST(CLIENT_PROFILE_UPDATE, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to update tax and security data. Please try again later.",
      });
    }
  }
);
// Fetch client data
export const fetchClientData = createAsyncThunk(
  "data/fetchClientData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POST(GET_CLIENT_DATA, { params: userData });
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to fetch client data. Please try again later.",
      });
    }
  }
);
// Create client data
export const createClientData = createAsyncThunk(
  "data/createClientData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(CREATE_CLIENT_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Client save failed. Please try again later.",
      });
    }
  }
);

// Switch Account
export const switchAccount = createAsyncThunk(
  "data/switchAccount",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(SWITCH_ACCOUNT, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Switch account failed. Please try again later.",
      });
    }
  }
);

// Switch Account
export const getLog = createAsyncThunk(
  "data/getLog",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(GET_LOG, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Switch account failed. Please try again later.",
      });
    }
  }
);

// Fetch client data
export const deatilsClientData = createAsyncThunk(
  "data/deatilsClientData",
  async (clientId, { rejectWithValue }) => {
    try {
      const response = await Api.GET(`${DETAILS_CLIENT_DATA}/${clientId}`);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to fetch client data. Please try again later.",
      });
    }
  }
);
// Delete client Data
export const deleteClient = createAsyncThunk(
  "data/deleteClient",
  async (clientId, { rejectWithValue }) => {
    try {
      const response = await Api.DELETE(`${DETAILS_CLIENT_DATA}/${clientId}`);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to delete client data. Please try again later.",
      });
    }
  }
);
// Delete client data
export const deleteClientData = createAsyncThunk(
  "data/deleteClientData",
  async ({ clientId }, { rejectWithValue }) => {
    try {
      const response = await Api.DELETE(`${DETAILS_CLIENT_DATA}/${clientId}`);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to delete client data. Please try again later.",
      });
    }
  }
);
// Update project setting data
export const updateClientData = createAsyncThunk(
  "data/updateClientData",
  async ({ clientId, userData }, { rejectWithValue }) => {
    try {
      const response = await Api.PUTDATA(
        `${DETAILS_CLIENT_DATA}/${clientId}`,
        userData
      );
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to update client data. Please try again later.",
      });
    }
  }
);
// Fetch client Appointment data
export const fetchAppointmentData = createAsyncThunk(
  "data/fetchAppointmentData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POST(GET_APPOINTMENT_DATA, userData);
      return response.data.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to fetch appointment data. Please try again later.",
      });
    }
  }
);
// Create client Appointment data
export const createAppointmentData = createAsyncThunk(
  "data/createAppointmentData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(CREATE_APPOINTMENT_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Appointment save failed. Please try again later.",
      });
    }
  }
);

// Fetch client Appointment data
export const updateAppointmentData = createAsyncThunk(
  "data/updateAppointmentData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POST(UPDATE_APPOINTMENT_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to update appointment data. Please try again later.",
      });
    }
  }
);

// get client Appointment data
export const getAppointmentData = createAsyncThunk(
  "data/getAppointmentData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POST(GET_SINGLE_APPOINTMENT_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to update appointment data. Please try again later.",
      });
    }
  }
);
// Fetch client Appointment data
export const deleteAppointmentData = createAsyncThunk(
  "data/deleteAppointmentData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POST(DELETE_APPOINTMENT_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to delete appointment data. Please try again later.",
      });
    }
  }
);

// Fetch client Project data
export const fetchProjectData = createAsyncThunk(
  "data/fetchProjectData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POST(GET_PROJECT_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to fetch project data. Please try again later.",
      });
    }
  }
);

// Fetch client Project data
export const fetchClientProjectData = createAsyncThunk(
  "data/fetchClientProjectData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POST(GET_CLIENT_PROJECT_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to fetch client project data. Please try again later.",
      });
    }
  }
);

// Fetch dashboard data
export const fetchDashboardData = createAsyncThunk(
  "data/fetchDashboardData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POST(GET_DASHBOARD_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to fetch dashboard data. Please try again later.",
      });
    }
  }
);


export const saveProjectFiles = createAsyncThunk(
  "data/saveProjectFiles",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POST(SAVE_PROJECT_FILE, userData, {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `Bearer ${token}`,
        },
      });
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to save project files. Please try again later.",
      });
    }
  }
);

export const getProjectFiles = createAsyncThunk(
  "data/getProjectFiles",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POST(GET_PROJECT_FILE, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to fetch project files. Please try again later.",
      });
    }
  }
);

export const deleteProjectFiles = createAsyncThunk(
  "data/deleteProjectFiles",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POST(DELETE_PROJECT_FILE, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to delete project files. Please try again later.",
      });
    }
  }
);

// Fetch role data
export const fetchRoleData = createAsyncThunk(
  "data/fetchRoleData",
  async (roleData, { rejectWithValue }) => {
    try {
      const response = await Api.POST(GET_ROLE_DATA, { params: roleData });
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to fetch role data. Please try again later.",
      });
    }
  }
);
// Create client project data
export const createProjectData = createAsyncThunk(
  "data/createProjectData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(CREATE_PROJECT_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Project save failed. Please try again later.",
      });
    }
  }
);
// Create role data
export const createRoleData = createAsyncThunk(
  "data/createRoleData",
  async (roleData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(CREATE_ROLE_DATA, roleData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Role save failed. Please try again later.",
      });
    }
  }
);
// Fetch client data
export const deatilsProjectData = createAsyncThunk(
  "data/deatilsProjectData",
  async (userData, { rejectWithValue }) => {
    try {
      // const response = await Api.GET(`${DETAILS_PROJECT_DATA}/${client_id, projectId}`);
      const response = await Api.POST(DETAILS_PROJECT_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to fetch project deatils data. Please try again later.",
      });
    }
  }
);
// Fetch role details
export const deatilsRoleData = createAsyncThunk(
  "data/deatilsRoleData",
  async (roleId, { rejectWithValue }) => {
    try {
      const response = await Api.GET(`${DETAILS_ROLE_DATA}/${roleId}`);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to fetch role data. Please try again later.",
      });
    }
  }
);
// Update project setting data
export const updateProjectData = createAsyncThunk(
  "data/updateProjectData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POST(UPDATE_PROJECT_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to update project data. Please try again later.",
      });
    }
  }
);
// Update role data
export const updateRoleData = createAsyncThunk(
  "data/updateRoleData",
  async ({ roleId, roleData }, { rejectWithValue }) => {
    try {
      const response = await Api.PUTDATA(
        `${DETAILS_ROLE_DATA}/${roleId}`,
        roleData
      );
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to update role data. Please try again later.",
      });
    }
  }
);
// Delete role data
export const deleteRoleData = createAsyncThunk(
  "data/deleteRoleData",
  async ({ roleId }, { rejectWithValue }) => {
    try {
      const response = await Api.DELETE(`${DETAILS_ROLE_DATA}/${roleId}`);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to delete role data. Please try again later.",
      });
    }
  }
);
// Fetch client admin data
export const fetchClientAdminData = createAsyncThunk(
  "data/fetchClientAdminData",
  async (clientAdminData, { rejectWithValue }) => {
    try {
      const response = await Api.POST(GET_CLIENT_ADMIN_DATA, {
        params: clientAdminData,
      });
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to fetch client admin data. Please try again later.",
      });
    }
  }
);
//Fetch profile pic 
export const fetchProfilePicData = createAsyncThunk(
  "data/fetchProfilePicData",
  async (clientAdminData, { rejectWithValue }) => {
    try {
      const response = await Api.POST(PROFILE_PICTURE, clientAdminData);
      return response.data?.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to fetch client admin data. Please try again later.",
      });
    }
  }
);
// Upload profile pic
export const uploadProfilePicData = createAsyncThunk(
  "data/uploadProfilePicData",
  async (clientAdminData, { rejectWithValue }) => {
    try {
      const response = await Api.POST(PROFILE_PICTURE, clientAdminData);
      return response.data.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to fetch client admin data. Please try again later.",
      });
    }
  }
);
// Delete client Data
export const deleteProject = createAsyncThunk(
  "data/deleteProject",
  async (userData, { rejectWithValue }) => {
    try {

      const response = await Api.POST(DELETE_PROJECT_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to delete project data. Please try again later.",
      });
    }
  }
);
// Create client admin data
export const createClientAdminData = createAsyncThunk(
  "data/createClientAdminData",
  async (clientAdminData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(
        CREATE_CLIENT_ADMIN_DATA,
        clientAdminData
      );
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Client admin save failed. Please try again later.",
      });
    }
  }
);
// Fetch client admin details
export const deatilsClientAdminData = createAsyncThunk(
  "data/deatilsClientAdminData",
  async (clientAdminId, { rejectWithValue }) => {
    try {
      const response = await Api.GET(
        `${DETAILS_CLIENT_ADMIN_DATA}/${clientAdminId}`
      );
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to fetch client admin data. Please try again later.",
      });
    }
  }
);
export const deatilsClientAdminDataByUuid = createAsyncThunk(
  "data/deatilsClientAdminDataByUuid",
  async (uuid, { rejectWithValue }) => {
    try {
      const response = await Api.GET(
        `${DETAILS_CLIENT_ADMIN_DATA_BY_UUID}/${uuid}`
      );
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to fetch client admin data. Please try again later.",
      });
    }
  }
);
// Update client admin data
export const updateClientAdminData = createAsyncThunk(
  "data/updateClientAdminData",
  async ({ clientAdminId, clientAdminData }, { rejectWithValue }) => {
    try {
      const response = await Api.PUTDATA(
        `${DETAILS_CLIENT_ADMIN_DATA}/${clientAdminId}`,
        clientAdminData
      );
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to update client admin data. Please try again later.",
      });
    }
  }
);
// Delete client admin data
export const deleteClientAdminData = createAsyncThunk(
  "data/deleteClientAdminData",
  async ({ clientAdminId }, { rejectWithValue }) => {
    try {
      const response = await Api.DELETE(
        `${DETAILS_CLIENT_ADMIN_DATA}/${clientAdminId}`
      );
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to delete client admin data. Please try again later.",
      });
    }
  }
);
// Company Subscription Request
export const addSubscriptionRequest = createAsyncThunk(
  "data/addSubscriptionRequest",
  async (clientSubscriptionData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(
        CLIENT_SUBSCRIPTION_REG,
        clientSubscriptionData
      );
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to register client subscription. Please try again later.",
      });
    }
  }
);

// Fetch item data
export const fetchItemData = createAsyncThunk(
  "data/fetchItemData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POST(GET_ITEM_DATA, { params: userData });
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to fetch client data. Please try again later.",
      });
    }
  }
);
// Create item data
export const createItemData = createAsyncThunk(
  "data/createItemData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(CREATE_ITEM_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Client save failed. Please try again later.",
      });
    }
  }
);
// Fetch item data
export const deatilsItemData = createAsyncThunk(
  "data/deatilsItemData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(DETAILS_ITEM_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to fetch client data. Please try again later.",
      });
    }
  }
);
// Update client admin data
export const updateItemData = createAsyncThunk(
  "data/updateItemData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(UPDATE_ITEM_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to update client admin data. Please try again later.",
      });
    }
  }
);
// Delete item Data
export const deleteItem = createAsyncThunk(
  "data/deleteItem",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(DELETE_ITEM_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to delete client data. Please try again later.",
      });
    }
  }
);

//---------------------------------------------------------------------------------------------
// Fetch logos data
export const listLogosData = createAsyncThunk(
  "data/listLogosData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(LIST_LOGO_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to fetch client data. Please try again later.",
      });
    }
  }
);

export const deleteLogosData = createAsyncThunk(
  "data/deleteLogosData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(DELETE_LOGO_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to delete logo data. Please try again later.",
      });
    }
  }
);

// Fetch logos data
export const createLogosData = createAsyncThunk(
  "data/createLogosData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(CREATE_LOGO_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to create logo data. Please try again later.",
      });
    }
  }
);
// Fetch colors data
export const listColorsData = createAsyncThunk(
  "data/listColorsData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(LIST_COLOR_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to fetch client data. Please try again later.",
      });
    }
  }
);
// Fetch water mark data
export const listWaterMarksData = createAsyncThunk(
  "data/listWaterMarksData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(LIST_WATERMARK_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to fetch client data. Please try again later.",
      });
    }
  }
);

export const deleteWaterMarksData = createAsyncThunk(
  "data/deleteWaterMarksData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(DELETE_WATERMARK_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to delete watermark data. Please try again later.",
      });
    }
  }
);

export const uploadWatermark = createAsyncThunk(
  "data/uploadWatermark",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(CREATE_WATERMARK_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to upload water mark data. Please try again later.",
      });
    }
  }
);
// Fetch header data
export const listHeadersData = createAsyncThunk(
  "data/listHeadersData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(LIST_HEADER_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to fetch client data. Please try again later.",
      });
    }
  }
);

export const deleteHeaderData = createAsyncThunk(
  "data/deleteHeaderData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(DELETE_HEADER_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to delete header data. Please try again later.",
      });
    }
  }
);

export const uploadHeader = createAsyncThunk(
  "data/uploadHeader",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(CREATE_HEADER_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to upload header data. Please try again later.",
      });
    }
  }
);
//Create invoice Data
export const createInvoiceData = createAsyncThunk(
  "data/createInvoice",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(CREATE_INVOICE_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to create invoice data. Please try again later.",
      });
    }
  }
);

//Get invoice Data
export const getInvoiceData = createAsyncThunk(
  "data/getInvoice",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(GET_INVOICE_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to get invoice data. Please try again later.",
      });
    }
  }
);

// Next invoice details
export const fetchNextInvoiceNumber = createAsyncThunk(
  "data/fetchNextInvoiceNumber",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(NEXT_INVOICE_NUMBER, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to fetch invoice data. Please try again later.",
      });
    }
  }
);

// Get invoice details
export const detailsInvoiceData = createAsyncThunk(
  "data/detailsInvoiceData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(DETAILS_INVOICE_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to fetch invoice data. Please try again later.",
      });
    }
  }
);
// Update client admin data
export const updateInvoiceData = createAsyncThunk(
  "data/updateInvoiceData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(UPDATE_INVOICE_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to update invoice data. Please try again later.",
      });
    }
  }
);
// Delete item Data
export const deleteInvoice = createAsyncThunk(
  "data/deleteInvoice",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(DELETE_INVOICE_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to delete invoice data. Please try again later.",
      });
    }
  }
);


//Create expense Data
export const createExpenseData = createAsyncThunk(
  "data/createExpense",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(CREATE_EXPENSE_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to create expense data. Please try again later.",
      });
    }
  }
);

export const getExpenseData = createAsyncThunk(
  "data/getExpense",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(GET_EXPENSE_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to get expense data. Please try again later.",
      });
    }
  }
);

export const detailsExpenseData = createAsyncThunk(
  "data/detailsExpenseData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(DETAILS_EXPENSE_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to fetch estimate data. Please try again later.",
      });
    }
  }
);

export const fetchNextExpenseNumber = createAsyncThunk(
  "data/fetchNextExpenseNumber",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(NEXT_EXPENSE_NUMBER, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to fetch expense data. Please try again later.",
      });
    }
  }
);

export const updateExpenseData = createAsyncThunk(
  "data/updateExpenseData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(UPDATE_EXPENSE_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to update expense data. Please try again later.",
      });
    }
  }
);

export const deleteExpense = createAsyncThunk(
  "data/deleteExpense",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(DELETE_EXPENSE_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to delete expense data. Please try again later.",
      });
    }
  }
);


//Create estimate Data
export const createEstimateData = createAsyncThunk(
  "data/createEstimate",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(CREATE_ESTIMATE_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to create estimate data. Please try again later.",
      });
    }
  }
);

//Get Estimate Data
export const getEstimateData = createAsyncThunk(
  "data/getEstimate",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(GET_ESTIMATE_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to get estimate data. Please try again later.",
      });
    }
  }
);

// Get Estimate details
export const detailsEstimateData = createAsyncThunk(
  "data/detailsEstimateData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(DETAILS_ESTIMATE_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to fetch estimate data. Please try again later.",
      });
    }
  }
);

export const fetchNextEstimateNumber = createAsyncThunk(
  "data/fetchNextEstimateNumber",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(NEXT_ESTIMATE_NUMBER, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to fetch estimate data. Please try again later.",
      });
    }
  }
);
// Update Estimate data
export const updateEstimateData = createAsyncThunk(
  "data/updateEstimateData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(UPDATE_ESTIMATE_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to update invoice data. Please try again later.",
      });
    }
  }
);
// Delete Estimate Data
export const deleteEstimate = createAsyncThunk(
  "data/deleteEstimate",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(DELETE_ESTIMATE_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to delete estimate data. Please try again later.",
      });
    }
  }
);


//Credit Note
//Create Credit Note Data
export const createCreditNoteData = createAsyncThunk(
  "data/createCreditNote",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(CREATE_CREDIT_NOTE_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to create credit note data. Please try again later.",
      });
    }
  }
);
//Get Credit Note Data
export const getCreditNoteData = createAsyncThunk(
  "data/getCreditNote",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(GET_CREDIT_NOTE_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to get credit note data. Please try again later.",
      });
    }
  }
);
// Get Credit Note details
export const detailsCreditNoteData = createAsyncThunk(
  "data/detailsCreditNoteData",
  async (userData, { rejectWithValue }) => {
    try {
      
      const response = await Api.POSTDATA(DETAILS_CREDIT_NOTE_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to fetch credit note data. Please try again later.",
      });
    }
  }
);
// Update Credit Note data
export const updateCreditNoteData = createAsyncThunk(
  "data/updateCreditNoteData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(UPDATE_CREDIT_NOTE_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to update credit note data. Please try again later.",
      });
    }
  }
);
// Delete Credit Note Data
export const deleteCreditNote = createAsyncThunk(
  "data/deleteCreditNote",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(DELETE_CREDIT_NOTE_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to delete estimate data. Please try again later.",
      });
    }
  }
);
export const fetchNextCreditNoteNumber = createAsyncThunk(
  "data/fetchNextCreditNoteNumber",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(NEXT_CREDIT_NOTE_NUMBER, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to fetch credit note data. Please try again later.",
      });
    }
  }
);


//Purchase Order
//Create Purchase Order Data
export const createPurchaseOrderData = createAsyncThunk(
  "data/createPurchaseOrder",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(CREATE_PURCHASE_ORDER_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to create purchase order data. Please try again later.",
      });
    }
  }
);
//Get Purchase Order Data
export const getPurchaseOrderData = createAsyncThunk(
  "data/getPurchaseOrder",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(GET_PURCHASE_ORDER_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to get purchase order data. Please try again later.",
      });
    }
  }
);
// Get Purchase Order details
export const detailsPurchaseOrderData = createAsyncThunk(
  "data/detailsPurchaseOrderData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(DETAILS_PURCHASE_ORDER_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to fetch purchase order data. Please try again later.",
      });
    }
  }
);
// Update Purchase Order data
export const updatePurchaseOrderData = createAsyncThunk(
  "data/updatePurchaseOrderData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(UPDATE_PURCHASE_ORDER_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to update purchase order data. Please try again later.",
      });
    }
  }
);
// Delete Purchase Order Data
export const deletePurchaseOrder = createAsyncThunk(
  "data/deletePurchaseOrder",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(DELETE_PURCHASE_ORDER_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to delete purchase order data. Please try again later.",
      });
    }
  }
);
export const fetchNextPurchaseOrderNumber = createAsyncThunk(
  "data/fetchNextPurchaseOrderNumber",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(NEXT_PURCHASE_ORDER_NUMBER, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to fetch purchase order data. Please try again later.",
      });
    }
  }
);

// Delete item Data
export const createTaxData = createAsyncThunk(
  "data/createTaxData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(CREATE_TAX_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to create tax data. Please try again later.",
      });
    }
  }
);
// Delete item Data
export const fetchTaxData = createAsyncThunk(
  "data/fetchTaxData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(GET_TAX_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to fetch tax data. Please try again later.",
      });
    }
  }
);
export const fetchDeleteTaxData = createAsyncThunk(
  "data/fetchDeleteTaxData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(DELETE_TAX_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to delete tax data. Please try again later.",
      });
    }
  }
);
// Create Custom Invoice Data
export const createCustomInvoiceData = createAsyncThunk(
  "data/createCustomInvoiceData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(CREATE_CUSTOM_INVOICE_DATA, userData);
      return response.data;
    } catch (error) {
      console.log(error, "error");
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to create tax data. Please try again later.",
      });
    }
  }
);
// Get Custom Invoice Data
export const getCustomInvoiceData = createAsyncThunk(
  "data/getCustomInvoiceData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(GET_CUSTOM_INVOICE_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to create tax data. Please try again later.",
      });
    }
  }
);

//Invoice Option Settings
// Create Custom Invoice Data
export const createCustomInvoiceOptionData = createAsyncThunk(
  "data/createCustomInvoiceOptionData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(CREATE_CUSTOM_INVOICE_OPTION_DATA, userData);
      return response.data;
    } catch (error) {
      console.log(error, "error");
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to create tax data. Please try again later.",
      });
    }
  }
);
// Get Custom Invoice Data
export const getCustomInvoiceOptionData = createAsyncThunk(
  "data/getCustomInvoiceOptionData",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(GET_CUSTOM_INVOICE_OPTION_DATA, userData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to create tax data. Please try again later.",
      });
    }
  }
);

// Create a slice
const dataSlice = createSlice({
  name: "data",
  initialState: {
    items: [],
    customInvoiceOptions: [],
    clients: [],
    projects: [],
    estimate: [],
    appointments: [],
    projectItems: [],
    expenses: [],
    logos: [],
    colors: [],
    waterMarks: [],
    headers: [],
    project: null,
    client: null,
    invoice: null,
    loading: false,
    error: null,
    invoices: [],
    estimates: [],
    customTemplates: [],
    currentMiddleTab : '',
    invoiceDetails : null,
    estimateDetails : null,
    creditNotes : [],
    purchaseOrders: [],
    profilePic: null
  },
  reducers: {
    setActiveMidTab: (state, action) => {
        state.currentMiddleTab = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder
      // Fetch master data
      .addCase(fetchMasterData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchMasterData.fulfilled, (state, action) => {
        state.loading = false;
        state.items = action.payload;
      })
      .addCase(fetchMasterData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      // Fetch Project Settings
      .addCase(fetchProjectSettingData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchProjectSettingData.fulfilled, (state, action) => {
        state.loading = false;
        state.items = action.payload;
      })
      .addCase(fetchProjectSettingData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      // Update project settings
      .addCase(updateProjectSettingData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateProjectSettingData.fulfilled, (state, action) => {
        state.loading = false;
        state.items = action.payload;
      })
      .addCase(updateProjectSettingData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })

      //estimate
      .addCase(getEstimateData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(getEstimateData.fulfilled, (state, action) => {
        state.loading = false;
        state.estimate = action.payload;
        state.estimates = [...action.payload.data]
      })
      .addCase(getEstimateData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })

      //expense
      .addCase(getExpenseData.pending, (state) => {
        state.loading = true;
      })
      .addCase(getExpenseData.fulfilled, (state, action) => {
        state.loading = false;
        // console.log(action.payload, "action.payload");
        state.expenses = action.payload.data;
      })
      .addCase(getExpenseData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })

      // Fetch Communication Settings
      .addCase(fetchCommunicationSettingData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchCommunicationSettingData.fulfilled, (state, action) => {
        state.loading = false;
        state.items = action.payload;
      })
      .addCase(fetchCommunicationSettingData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      // Update communication settings
      .addCase(updateCommunicationSettingData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateCommunicationSettingData.fulfilled, (state, action) => {
        state.loading = false;
        state.items = action.payload;
      })
      .addCase(updateCommunicationSettingData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      // Fetch Tax and Security settings
      .addCase(fetchTaxSecurityData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchTaxSecurityData.fulfilled, (state, action) => {
        state.loading = false;
        state.items = action.payload;
      })
      .addCase(fetchTaxSecurityData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      // Update Tax and Security settings
      .addCase(updateTaxSecurityData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateTaxSecurityData.fulfilled, (state, action) => {
        state.loading = false;
        state.items = action.payload;
      })
      .addCase(updateTaxSecurityData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      // Fetch Client Data
      .addCase(fetchClientData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchClientData.fulfilled, (state, action) => {
        state.loading = false;
        state.clients = action.payload;
      })
      .addCase(fetchClientData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      // Create Client Data
      .addCase(createClientData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createClientData.fulfilled, (state, action) => {
        state.loading = false;
        state.items = action.payload;
      })
      .addCase(createClientData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      // Details Client Data
      .addCase(deatilsClientData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deatilsClientData.fulfilled, (state, action) => {
        state.loading = false;
        state.client = action.payload;
      })
      .addCase(deatilsClientData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      // Delete Client Data
      .addCase(deleteClient.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteClient.fulfilled, (state, action) => {
        state.loading = false;
        state.client = action.payload;
      })
      .addCase(deleteClient.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      // Update Client Data
      .addCase(updateClientData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateClientData.fulfilled, (state, action) => {
        state.loading = false;
        state.client = action.payload;
      })
      .addCase(updateClientData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      // Delete Client Data
      .addCase(deleteClientData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteClientData.fulfilled, (state, action) => {
        state.loading = false;
        state.client = action.payload;
      })
      .addCase(deleteClientData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      // Create Client Appointment Data
      .addCase(fetchAppointmentData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchAppointmentData.fulfilled, (state, action) => {
        state.loading = false;
        state.appointments = action.payload;
      })
      .addCase(fetchAppointmentData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      // Create Client Appointment Data
      .addCase(createAppointmentData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createAppointmentData.fulfilled, (state, action) => {
        state.loading = false;
      })
      .addCase(createAppointmentData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      // Create Client Project Data
      .addCase(fetchProjectData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchProjectData.fulfilled, (state, action) => {
        state.loading = false;
        state.projects = action.payload;
      })
      .addCase(fetchProjectData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      // Create Client Project Data
      .addCase(createProjectData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createProjectData.fulfilled, (state, action) => {
        state.loading = false;
      })
      .addCase(createProjectData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      // Details Project Data
      .addCase(deatilsProjectData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deatilsProjectData.fulfilled, (state, action) => {
        state.loading = false;
        state.project = action.payload;
      })
      .addCase(deatilsProjectData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      // Update Project Data
      .addCase(updateProjectData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateProjectData.fulfilled, (state, action) => {
        state.loading = false;
        state.project = action.payload;
      })
      .addCase(updateProjectData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      // Delete Project Data
      .addCase(deleteProject.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteProject.fulfilled, (state, action) => {
        state.loading = false;
        state.project = action.payload;
      })
      .addCase(deleteProject.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      // Fetch Role Data
      .addCase(fetchRoleData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchRoleData.fulfilled, (state, action) => {
        state.loading = false;
        state.roles = action.payload;
      })
      .addCase(fetchRoleData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      // Create Role Data
      .addCase(createRoleData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createRoleData.fulfilled, (state, action) => {
        state.loading = false;
        state.items = action.payload;
      })
      .addCase(createRoleData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      // Details Role Data
      .addCase(deatilsRoleData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deatilsRoleData.fulfilled, (state, action) => {
        state.loading = false;
        state.role = action.payload;
      })
      .addCase(deatilsRoleData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      // Update Role Data
      .addCase(updateRoleData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateRoleData.fulfilled, (state, action) => {
        state.loading = false;
        state.role = action.payload;
      })
      .addCase(updateRoleData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      // Delete Role Data
      .addCase(deleteRoleData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteRoleData.fulfilled, (state, action) => {
        state.loading = false;
        state.role = action.payload;
      })
      .addCase(deleteRoleData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      // Fetch Client Admin Data
      .addCase(fetchClientAdminData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchClientAdminData.fulfilled, (state, action) => {
        state.loading = false;
        state.clientAdmins = action.payload;
      })
      .addCase(fetchClientAdminData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      .addCase(fetchProfilePicData.pending, state => {
        state.loading = true,
        state.error= null
      })
      .addCase(fetchProfilePicData.fulfilled, (state, action) => {
        state.loading = false;
        state.profilePic = action.payload;
      })
      .addCase(fetchProfilePicData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      .addCase(uploadProfilePicData.pending, state => {
        state.loading = true,
        state.error= null
      })
      .addCase(uploadProfilePicData.fulfilled, (state, action) => {
        state.loading = false;
        state.profilePic = action.payload;
      })
      .addCase(uploadProfilePicData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      // Create Client Admin Data
      .addCase(createClientAdminData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createClientAdminData.fulfilled, (state, action) => {
        state.loading = false;
        state.items = action.payload;
      })
      .addCase(createClientAdminData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      // Details Client Admin Data
      .addCase(deatilsClientAdminData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deatilsClientAdminData.fulfilled, (state, action) => {
        state.loading = false;
        state.clientAdmin = action.payload;
      })
      .addCase(deatilsClientAdminData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      // Details Client Admin Data
      .addCase(deatilsClientAdminDataByUuid.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deatilsClientAdminDataByUuid.fulfilled, (state, action) => {
        state.loading = false;
        state.clientAdmin = action.payload;
      })
      .addCase(deatilsClientAdminDataByUuid.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      // Update Client Admin Data
      .addCase(updateClientAdminData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateClientAdminData.fulfilled, (state, action) => {
        state.loading = false;
        state.clientAdmin = action.payload;
      })
      .addCase(updateClientAdminData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      // Delete Client Admin Data
      .addCase(deleteClientAdminData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteClientAdminData.fulfilled, (state, action) => {
        state.loading = false;
        state.clientAdmin = action.payload;
      })
      .addCase(deleteClientAdminData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      // Client Subscription
      .addCase(addSubscriptionRequest.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(addSubscriptionRequest.fulfilled, (state, action) => {
        state.loading = false;
        state.items = action.payload;
      })
      .addCase(addSubscriptionRequest.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })

      // Fetch Item Data
      .addCase(fetchItemData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchItemData.fulfilled, (state, action) => {
        state.loading = false;
        state.projectItems = action.payload;
      })
      .addCase(fetchItemData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      // Create Client Admin Data
      .addCase(createItemData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createItemData.fulfilled, (state, action) => {
        state.loading = false;
        // state.projectItems = action.payload;
      })
      .addCase(createItemData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      // Details Client Admin Data
      .addCase(deatilsItemData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deatilsItemData.fulfilled, (state, action) => {
        state.loading = false;
        // state.projectItems = action.payload;
      })
      .addCase(deatilsItemData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      // Update Client Admin Data
      .addCase(updateItemData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateItemData.fulfilled, (state, action) => {
        state.loading = false;
        // state.projectItems = action.payload;
      })
      .addCase(updateItemData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      // Delete Client Admin Data
      .addCase(deleteItem.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteItem.fulfilled, (state, action) => {
        state.loading = false;
        state.projectItems = action.payload;
      })
      .addCase(deleteItem.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })

      //-----------------------------------------------------------------------------------------
      // List Logos Data
      .addCase(listLogosData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(listLogosData.fulfilled, (state, action) => {
        state.loading = false;
        state.logos = action.payload;
      })
      .addCase(listLogosData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })

      //custom template data
      .addCase(getCustomInvoiceData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(getCustomInvoiceData.fulfilled, (state, action) => {
        state.loading = false;
        state.customTemplates = action.payload;
      })
      .addCase(getCustomInvoiceData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })

      //custom template option data
      .addCase(getCustomInvoiceOptionData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(getCustomInvoiceOptionData.fulfilled, (state, action) => {
        state.loading = false;
        state.customInvoiceOptions = action.payload;
      })
      .addCase(getCustomInvoiceOptionData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })


      // List Colors Data
      .addCase(listColorsData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(listColorsData.fulfilled, (state, action) => {
        state.loading = false;
        state.colors = action.payload;
      })
      .addCase(listColorsData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })

      // List Watermark Data
      .addCase(listWaterMarksData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(listWaterMarksData.fulfilled, (state, action) => {
        state.loading = false;
        state.waterMarks = action.payload;
      })
      .addCase(listWaterMarksData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })

      // List Headers Data
      .addCase(listHeadersData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(listHeadersData.fulfilled, (state, action) => {
        state.loading = false;
        state.headers = action.payload;
      })
      .addCase(listHeadersData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })

      // List Headers Data
      .addCase(createTaxData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createTaxData.fulfilled, (state, action) => {
        state.loading = false;
        state.headers = action.payload;
      })
      .addCase(createTaxData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })

      // List Headers Data
      .addCase(fetchTaxData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchTaxData.fulfilled, (state, action) => {
        state.loading = false;
        state.headers = action.payload;
      })
      .addCase(fetchTaxData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })

      // List Headers Data
      .addCase(fetchDeleteTaxData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchDeleteTaxData.fulfilled, (state, action) => {
        state.loading = false;
        state.headers = action.payload;
      })
      .addCase(fetchDeleteTaxData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })

      // Create Custom Invoice Data
      .addCase(createCustomInvoiceData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createCustomInvoiceData.fulfilled, (state, action) => {
        state.loading = false;
        state.items = action.payload;
      })
      .addCase(createCustomInvoiceData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })

      // Create Custom Invoice Option Data
      .addCase(createCustomInvoiceOptionData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createCustomInvoiceOptionData.fulfilled, (state, action) => {
        state.loading = false;
        state.customInvoiceOptions = action.payload;
      })
      .addCase(createCustomInvoiceOptionData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      // List Headers Data
      // .addCase(getCustomInvoiceData.pending, (state) => {
      //   state.loading = true;
      //   state.error = null;
      // })
      // .addCase(getCustomInvoiceData.fulfilled, (state, action) => {
      //   state.loading = false;
      //   state.invoice = action.payload;
      // })
      // .addCase(getCustomInvoiceData.rejected, (state, action) => {
      //   state.loading = false;
      //   state.error = action.payload?.message || action.error.message;
      // })
      .addCase(getInvoiceData.pending, (state, action) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(getInvoiceData.fulfilled, (state, action) => {
        state.loading = false;
        state.invoices = [...action.payload.data];
      })
      .addCase(getInvoiceData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      .addCase(detailsInvoiceData.pending, (state, action) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(detailsInvoiceData.fulfilled, (state, action) => {
        state.loading = false;
        state.invoiceDetails = {...action.payload.data};
      })
      .addCase(detailsInvoiceData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      .addCase(detailsEstimateData.pending, (state, action) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(detailsEstimateData.fulfilled, (state, action) => {
        state.loading = false;
        state.estimateDetails = {...action.payload.data};
      })
      .addCase(detailsEstimateData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      .addCase(getCreditNoteData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(getCreditNoteData.fulfilled, (state, action) => {
        state.loading = false;
        state.creditNotes = action.payload;
      })
      .addCase(getCreditNoteData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      .addCase(getPurchaseOrderData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(getPurchaseOrderData.fulfilled, (state, action) => {
        state.loading = false;
        state.purchaseOrders = action.payload;
      })
      .addCase(getPurchaseOrderData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
  },
});

// Export the reducer
export const { setActiveMidTab } = dataSlice.actions;
export default dataSlice.reducer;
