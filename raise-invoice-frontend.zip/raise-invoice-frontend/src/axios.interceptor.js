import { httpClient } from './dependencies/utils/Api';
import { storage } from "./dependencies/store/storage";
// import { toast } from 'react-toastify';

const interceptors = {
  setupInterceptors: () => {
    httpClient.interceptors.request.use(function (config) {
      const token = storage.getJwtToken();
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
      return config;
    }, function (err) {
      return Promise.reject(err);
    });

    httpClient.interceptors.response.use(
      response => {
        return response;
      },
      error => {
      if (error.response && (error.response.status === 401 || error.response.status === 403)) {
        localStorage.clear();
        sessionStorage.clear();
        window.location.href = '/';
      }
      // if (error.response && error.response.status === 403) {
      //   localStorage.clear();
      //   sessionStorage.clear();
      //   window.location.href = '/';
      //   // toast.error('')
      // }
      // if (error.response && error.response.status === 422) {
      //   // toast.error(error.message)
      //   return true
      //   // if(error && error.message !== 'Request aborted' && error.message !== 'Operation canceled') {
      //   //   history.push(PATHS.SERVER_ERROR);
      //   // }
      // }
      return Promise.reject(error);
    });
  },
};

export default interceptors;
