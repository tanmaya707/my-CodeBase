import React from 'react'
import './digitalmarketing.css';
import { IMAGE } from '@/utils/Theme';

const DigitalMarketing = () => {
  return (
    <>
        <div className='navbar-tab export-btn digital-marketing-container'>
            <h4>Digital Marketing</h4>
            <button className='export-btn'>
                <p>Export Data</p> 
                <img src={IMAGE.white_download}/>
            </button>
        </div>
        <div className='marketing-container'>
            <div className='row'>
                <div className='col-lg-4'>
                    <div className='sub-head'>
                        <p className='subheading digital'>Start Date</p>
                    </div>
                    <p className='marketing-text'>12 Nov, 2024</p>

                    <div className='sub-head'>
                        <p className='subheading digital'>Category</p>
                    </div>
                    <p className='marketing-text'>Car Rental</p>
                </div>
                <div className='col-lg-4'>
                    <div className='sub-head'>
                        <p className='subheading digital'>Merchant</p>
                    </div>
                    <p className='marketing-text'>Bajaj</p>
                </div>

            </div>
            <div className='row'>
                <div className='col-lg-4'>
                    <div className='sub-head'>
                        <p className='subheading digital'>Total</p>
                    </div>
                    <p className='marketing-text'>$1200</p>

                    <div className='sub-head'>
                        <p className='subheading digital'>Project</p>
                    </div>
                    <p className='marketing-text'>Project 1</p>
                    <p className='user-name'>Akash Mishra</p>
                </div>
                <div className='col-lg-4'>
                    <div className='sub-head'>
                        <p className='subheading digital'>Tax</p>
                    </div>
                    <p className='marketing-text'>$10</p>

                </div>
                <div className='col-lg-4'>
                    <div className='sub-head'>
                        <p className='subheading digital'>Tip</p>
                    </div>
                    <p className='marketing-text'>NA</p>
                </div>
            </div>

        </div>
    </>
  )
}

export default DigitalMarketing
