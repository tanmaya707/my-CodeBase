import React from 'react'

import './invoicePdf.css'
import Link from 'next/link'


const invoicePdf=()=> {

  return (
    <div className='invoice'>
        <div className='table-responsive'>
            <table>
                <thead className='table-head'>
                    <tr>
                        <td>
                            <div className='text-left'>
                                <h3>Invoice</h3>
                            </div>
                        </td>
                        <td>
                        <div className='text-right'>
                            <p>Invoice No.</p>
                            <h5>#000123</h5>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <div className='clientName text-left'>
                                <p>Billed To:</p>
                                <h5 className='clientBold'>Client Name</h5>
                                <h6>Address / Contact Info</h6>
                            </div>
                        </td>
                        <td>
                            <div className='clientName'>
                                <p>Issued on</p>
                                <h5>December 7, 2022.</h5>                          
                            </div>
                            <div className='clientName'>
                                <p>Payment Due</p>
                                <h5>December 22, 2022.</h5>                          
                            </div>
                        </td>
                    </tr>
                </thead>

                <tbody className='table-tbody'>
                    <tr>
                        <td colSpan={2}>
                            <table>
                                <tbody>
                                    <tr>
                                        <td><h6>Services</h6></td>
                                        <td><p>Qty.</p></td>
                                        <td><p>Price</p></td>
                                        <td><p>Total</p></td>
                                    </tr>
                                    <tr>
                                        <td><p>Invoice Item 1</p></td>
                                        <td><p>1</p></td>
                                        <td><p>4,000.00</p></td>
                                        <td><p>4,000.00</p></td>
                                    </tr>
                                </tbody>
                            </table>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
  )
}

export default invoicePdf