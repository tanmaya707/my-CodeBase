"use client"

import { useState } from "react"
import { Dropdown, Container, Row, Col } from "react-bootstrap"
import "bootstrap/dist/css/bootstrap.min.css"
import "./reportGraph.css"

const monthlyData = [
  { month: "Jan", value: 500, color: "#0d6efd" },
  { month: "Feb", value: 450, color: "#0d6efd" },
  { month: "Mar", value: 380, color: "#0d6efd" },
  { month: "Apr", value: 480, color: "#adb5bd" },
  { month: "May", value: 300, color: "#0d6efd" },
  { month: "Jun", value: 500, color: "#0d6efd" },
  { month: "Jul", value: 500, color: "#adb5bd" },
  { month: "Aug", value: 380, color: "#0d6efd" },
  { month: "Sep", value: 480, color: "#adb5bd" },
  { month: "Oct", value: 300, color: "#0d6efd" },
  { month: "Nov", value: 500, color: "#0d6efd" },
  { month: "Dec", value: 500, color: "#adb5bd" },
]

const maxValue = 500

const ReportGraph =()=> {
  const [activeTab, setActiveTab] = useState("By Month")

  return (
    <Container fluid className="dashboard-container">
      {/* Header */}
      <Row className="header-row">
        <Col className="d-flex justify-content-between align-items-center ">
          <Dropdown>
            <Dropdown.Toggle className="dropdown-custom">Tax Year 2025 Sales</Dropdown.Toggle>
            <Dropdown.Menu>
              <Dropdown.Item>Tax Year 2025 Sales</Dropdown.Item>
              <Dropdown.Item>Tax Year 2024 Sales</Dropdown.Item>
              <Dropdown.Item>Tax Year 2023 Sales</Dropdown.Item>
            </Dropdown.Menu>
          </Dropdown>
          <span className="header-amount">$125</span>
        </Col>
      </Row>

      {/* Subheader */}
      <Row className="subheader-row">
        <Col className="d-flex justify-content-between align-items-center">
          <span className="invoices-text">15 Invoices</span>
          <span className="total-amount">$125</span>
        </Col>
      </Row>

      {/* Tabs */}
      <Row className="tabs-row">
        <Col>
          <div className="custom-tabs">
            {["By Month", "By Quarter", "By Year"].map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`tab-button ${activeTab === tab ? "active" : ""}`}
              >
                {tab}
              </button>
            ))}
          </div>
        </Col>
      </Row>

      {/* Chart */}
      <Row className="chart-row">
        <Col>
          <div className="chart-container">
            {/* Y-axis labels */}
            <div className="y-axis">
              <span>$500</span>
              <span>$400</span>
              <span>$300</span>
              <span>$200</span>
              <span>$100</span>
              <span>$0</span>
            </div>

            {/* Chart bars */}
            <div className="chart-bars">
              {monthlyData.map((data, index) => (
                <div key={data.month} className="bar-container">
                  <div
                    className="bar"
                    style={{
                      height: `${(data.value / maxValue) * 100}%`,
                      backgroundColor: data.color,
                    }}
                  />
                </div>
              ))}
            </div>
          </div>

          {/* X-axis labels */}
          <div className="x-axis">
            {monthlyData.map((data) => (
              <div key={data.month} className="month-label">
                {data.month}
              </div>
            ))}
          </div>
        </Col>
      </Row>

      {/* Footer link */}
      <Row className="footer-row">
        <Col>
          <button className="report-link">Show Detailed Report</button>
        </Col>
      </Row>
    </Container>
  )
}


export default ReportGraph;