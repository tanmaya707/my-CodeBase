"use client"
import React, { useState, useEffect } from 'react';
import './footer.css';
import Link from 'next/link';
import { IMAGE } from '@/utils/Theme';
import Api from "../../api/api";
import { Form } from "react-bootstrap";
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { useForm } from 'react-hook-form';

const Footer = () => {
    const [error, setError] = useState(null);
    const [isLoading, setIsLoading] = useState(true);
    const [productMenuList, setProductMenuList] = useState([]);
    const [exploreMenuList, setExploreMenuList] = useState([]);
    const [communityMenuList, setCommunityMenuList] = useState([]);
    const [companyMenuList, setCompanyMenuList] = useState([]);
    useEffect(() => {
        getFooterMenus();
    }, []);
    const getFooterMenus = async () => {
        setIsLoading(true);
        setError(null);
        try {
            const footerMenuResponse = await Api.POST('get-menu-list', { menu_type: 2 });
            let menuList = footerMenuResponse.data.data;
            setProductMenuList(menuList.filter(o => o.menu_group === 1));
            setExploreMenuList(menuList.filter(o => o.menu_group === 2));
            setCommunityMenuList(menuList.filter(o => o.menu_group === 3));
            setCompanyMenuList(menuList.filter(o => o.menu_group === 4));
        } catch (err) {
            setError("Failed to fetch menu list.");
        } finally {
            setIsLoading(false);
        }
    };
    const [newletterSuccessMessage, setNewletterSuccessMessage] = useState('');
    const [newletterErrorMessage, setNewletterErrorMessage] = useState('');
    var [state, setState] = useState({
        newsletter_email: '',
    });
    var { newsletter_email } = state;
    const handleNewsletterChange = (event) => {
        const { name, value } = event.target;
        setState(prevState => ({
            ...prevState,
            [name]: value,
        }));
        trigger(name);
    };
    var validationSchema = Yup.object().shape({
        newsletter_email: Yup.string()
            .required('Email is required'),
    });
    var formOptions = { defaultValues: state, resolver: yupResolver(validationSchema), };
    var { register, handleSubmit, reset, formState: { errors }, clearErrors, trigger } = useForm(formOptions);

    const submitNewletterForm = () => {
        clearErrors()
        reset(state)
    }
    const onNewletterSubmit = async (formData) => {
        try {
            const response = await Api.POST('subscribe-newletter', { email: formData.newsletter_email })
            if (response.status === 200) {
                if (response.data.status) {
                    setNewletterSuccessMessage(response.data.message);
                    resetNewletterForm();
                } else {
                    setNewletterErrorMessage(response.data.message);
                }
                setTimeout(() => {
                    setNewletterSuccessMessage('');
                    setNewletterErrorMessage('');
                }, 4000)
            }
        } catch (error) {
            setNewletterErrorMessage(error?.response?.data?.message);
            setTimeout(() => {
                setNewletterSuccessMessage('');
                setNewletterErrorMessage('');
            }, 4000)
        }
    };
    const resetNewletterForm = () => {
        clearErrors();
        setState(prevState => ({
            ...prevState,
            newsletter_email: '',
        }));
    }
    return (
        <>
            <div className='startInvoice'>
                <div className='container'>
                    <div className='invoice-bg'>
                        <img className='component' src={IMAGE.component} alt='Image broken' />
                        <p className='invoice-title'>Start Invoicing Now</p>
                       
                        <img 
                            className='uparrow' 
                            src={IMAGE.uparrow} 
                            alt='Scroll to top' 
                            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} 
                            style={{ cursor: 'pointer' }} // Optional: shows hand cursor on hover
                            />
                        <div className='container subscribe'>
                            <div className='subs-input row'>
                                <div className='col-lg-5'>
                                    <div className='subs-input-left'>   
                                        <p>Subscribe Newsletters</p>
                                    </div>
                                </div>
                                <div className='col-lg-7'>
                                    <Form onSubmit={handleSubmit(onNewletterSubmit)}>
                                        <div className='subs-input-right-cntnt'>
                                            <Form.Control
                                                type="email"
                                                {...register('newsletter_email', { onChange: handleNewsletterChange })}
                                                value={newsletter_email}
                                                className={`form-control ${errors.newsletter_email ? 'is-invalid' : (newsletter_email ? 'is-valid' : '')}`}
                                                placeholder="Enter your email"
                                                aria-label="Enter your email"
                                            />
                                            <button className='subscribe-btn' type="submit" onClick={submitNewletterForm}>
                                                Subcribe Now
                                            </button>
                                        </div>
                                    </Form>
                                </div>
                                <div className='col-lg-5'></div>
                                <div className='col-lg-7'>
                                    {errors.newsletter_email ?
                                        <div className="invalid-feedback d-block">{errors.newsletter_email?.message?.toString()}</div>
                                        : ''}
                                    {newletterSuccessMessage ?
                                        <div className="valid-feedback d-block">{newletterSuccessMessage}</div>
                                        : ''}
                                    {newletterErrorMessage ?
                                        <div className="invalid-feedback d-block">{newletterErrorMessage}</div>
                                        : ''}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div className="footer-list">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-3 col-md-3 col-6">
                            <div className="quick-return">
                                <h4>Product</h4>
                                <ul>
                                    {(productMenuList && productMenuList.length) ?
                                        productMenuList.map((productMenu, i) => (
                                            <li key={i} className="active">
                                                <Link href={(productMenu.link_type == 1) ? `/${productMenu.slug}` : productMenu.menu_link} target={(productMenu.link_type == 1) ? `_self` : `_blank`}>{productMenu.menu_title}</Link>
                                            </li>
                                        ))
                                        : ''
                                    }
                                </ul>
                            </div>
                        </div>
                        <div className="col-lg-3 col-md-3 col-6">
                            <div className="quick-return">
                                <h4>Explore</h4>
                                <ul>
                                    {(exploreMenuList && exploreMenuList.length) ?
                                        exploreMenuList.map((exploreMenu, j) => (
                                            <li key={j} className="active">
                                                <Link href={(exploreMenu.link_type == 1) ? `/${exploreMenu.slug}` : exploreMenu.menu_link} target={(exploreMenu.link_type == 1) ? `_self` : `_blank`}>{exploreMenu.menu_title}</Link>
                                            </li>
                                        ))
                                        : ''
                                    }
                                </ul>
                            </div>
                        </div>
                        <div className="col-lg-3 col-md-3 col-6">
                            <div className="quick-return">
                                <h4>Community</h4>
                                <ul>
                                    {(communityMenuList && communityMenuList.length) ?
                                        communityMenuList.map((communityMenu, k) => (
                                            <li key={k} className="active">
                                                <Link href={(communityMenu.link_type == 1) ? `/${communityMenu.slug}` : communityMenu.menu_link} target={(communityMenu.link_type == 1) ? `_self` : `_blank`}>{communityMenu.menu_title}</Link>
                                            </li>
                                        ))
                                        : ''
                                    }
                                </ul>
                            </div>
                        </div>
                        <div className="col-lg-3 col-md-3 col-6">
                            <div className="quick-return quick-left">
                                <h4>Company</h4>
                                <ul>
                                    {(companyMenuList && companyMenuList.length) ?
                                        companyMenuList.map((companyMenu, l) => (
                                            <li key={l} className="active">
                                                <Link href={(companyMenu.link_type == 1) ? `/${companyMenu.slug}` : companyMenu.menu_link} target={(companyMenu.link_type == 1) ? `_self` : `_blank`}>{companyMenu.menu_title}</Link>
                                            </li>
                                        ))
                                        : ''
                                    }
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="footer-bottom">
                    <div className="copyright">
                        <p>&copy; {new Date().getFullYear()} RaiseInvoice. All rights reserved. </p>
                    </div>
                    {/* <div className='icons'>
                        <Link href={{}}><img src={IMAGE.facebook} /></Link>
                        <Link href={{}}><img src={IMAGE.twitter} /></Link>
                        <Link href={{}}><img src={IMAGE.insta} /></Link>
                    </div> */}
                    <div className='icons'>
                        <Link href="https://www.facebook.com" target="_blank" rel="noopener noreferrer">
                            <img src={IMAGE.facebook} alt="Facebook" />
                        </Link>
                        <Link href="https://twitter.com" target="_blank" rel="noopener noreferrer">
                            <img src={IMAGE.twitter} alt="Twitter" />
                        </Link>
                        <Link href="https://www.instagram.com" target="_blank" rel="noopener noreferrer">
                            <img src={IMAGE.insta} alt="Instagram" />
                        </Link>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Footer
