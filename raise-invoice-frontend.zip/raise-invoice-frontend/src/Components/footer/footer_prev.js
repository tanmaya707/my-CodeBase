import React from 'react'
import './footer.css';
import Link from 'next/link';
import { IMAGE } from '@/utils/Theme';

const Footer = () => {
    return (
        <>
            <div className='startInvoice'>
                <div className='container'>
                    <div className='invoice-bg'>
                        <img className='component' src={IMAGE.component} alt='Image broken' />
                        <p className='invoice-title'>Start Invoicing Now</p>
                        <img className='uparrow' src={IMAGE.uparrow} alt='Image broken' />
                        <div className='container subscribe'>
                            <div className='subs-input row'>
                                <div className='col-lg-5'>

                                    <div className='subs-input-left'>
                                        <p>Subscribe Newsletters</p>
                                    </div>
                                </div>

                                <div className='col-lg-7'>
                                    <div className='subs-input-right-cntnt'>
                                        <input className="form-control" type="text" placeholder="Enter your email" aria-label=".form-control-lg example" />
                                        <button className='subscribe-btn'>Subcribe Now</button>
                                    </div>
                                </div>
                            </div>


                        </div>
                    </div>
                </div>
            </div>

            <div className="footer-list">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-3 col-md-3 col-6">
                            <div className="quick-return">
                                <h4>Product</h4>
                                <ul>
                                    <li><a href="#">Autocapture</a></li>
                                    <li><a href="#">Data Governance</a></li>
                                    <li><a href="#">Virtual Events</a></li>
                                    <li><a href="#">Virtual Users</a></li>
                                    <li><a href="#">Behavioral Analytics</a></li>
                                    <li><a href="#">Connect</a></li>
                                </ul>

                            </div>
                        </div>
                        <div className="col-lg-3 col-md-3 col-6">
                            <div className="quick-return">
                                <h4>Explore</h4>
                                <ul>
                                    <li><a href="">Resources</a></li>
                                    <li><a href="/blog">Blog</a></li>
                                    <li><a href="">Documents</a></li>
                                </ul>
                            </div>
                        </div>
                        <div className="col-lg-3 col-md-3 col-6">
                            <div className="quick-return">
                                <h4>Community</h4>
                                <ul>
                                    <li><a href="">Community Central</a></li>
                                    <li><a href="">Support</a></li>
                                    <li><a href="">Help</a></li>
                                    <li><a href="">My info</a></li>
                                </ul>
                            </div>
                        </div>
                        <div className="col-lg-3 col-md-3 col-6">
                            <div className="quick-return quick-left">
                                <h4>Company</h4>
                                <ul>
                                    <li><a href="">About us</a></li>
                                    <li><a href="">Partners</a></li>
                                    <li><a href="">Customers</a></li>
                                    <li><a href="">Contact us</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>

                </div>
                <div className="footer-bottom">
                    <div className="copyright">
                        <p>© 2024 RaiseInvoice. All rights reserved. </p>
                    </div>
                    <div className='icons'>
                        <Link href={{}}><img src={IMAGE.facebook} /></Link>
                        <Link href={{}}><img src={IMAGE.twitter} /></Link>
                        <Link href={{}}><img src={IMAGE.insta} /></Link>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Footer