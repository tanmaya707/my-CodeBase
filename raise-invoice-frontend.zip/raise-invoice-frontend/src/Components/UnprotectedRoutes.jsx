'use client'

import { useRouter } from "next/navigation";
import { useEffect } from "react";

const UnprotectedRoute = ( {isAuthenticated, children} ) => {
    const router = useRouter();

    useEffect(() => {
        // console.log("isAuthenticated ::: ", isAuthenticated);
        
        if(isAuthenticated) {
            router.push('/dashboard')
        }
    }, [isAuthenticated, router])
    
    return isAuthenticated ?  null : <>{children}</>
}

export default UnprotectedRoute;