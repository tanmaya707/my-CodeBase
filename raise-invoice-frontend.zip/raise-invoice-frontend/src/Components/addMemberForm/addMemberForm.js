"use client"
import React, {useState, useEffect} from 'react'
import './addMemberForm.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { 
    faLongArrowLeft
} from '@fortawesome/free-solid-svg-icons';
import { IMAGE } from '@/utils/Theme';
import { ToastContainer, toast } from 'react-toastify';
import { useDispatch } from 'react-redux';
import { createClientAdminData, updateClientAdminData, fetchRoleData, deatilsClientAdminDataByUuid } from "@/redux/slices/dataSlice";
import Link from 'next/link';
import { useRouter } from 'next/navigation';

const AddMemberForm = ({uuid}) => {
    const dispatch = useDispatch();
    const [loading, setLoading] = useState(false);
    const [errors, setErrors] = useState({});
    const [isRoleDisabled, setIsRoleDisabled] = useState(false);
    const [isFieldDisabled, setIsFieldDisabled] = useState(false);
    const [formTitle, setFormTitle] = useState('Add Account');
    const [formSubTitle, setFormSubTitle] = useState('Add other contacts to this account');
    const [formData, setFormData] = useState({
        id: null,
        roleId: '',
        name: '',
        email: '',
        password: '',
    });
    const [roles, setRoles] = useState([]);
    const router = useRouter();
    const resetFormData = () => {
        setFormData({
            id: null,
            roleId: '',
            name: '',
            email: '',
            password: '',
        });
        setErrors({});
        setIsRoleDisabled(false);
        setIsFieldDisabled(false);
    }
    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };
    const validateForm = () => {
        const newErrors = {};
        // console.log(formData)
        if (!formData.name) newErrors.name = 'Client Name is required';
        if (!formData.roleId) newErrors.roleId = 'Role is required';
        if (!formData.email) newErrors.email = 'Email is required';
        if (formData.id == 'null' && !formData.password) newErrors.password = 'Password is required';
        
        // Password validation
        if (!formData.password) {
            newErrors.password = "Password is required";
        } else if (formData.password.length < 6) {
            newErrors.password = "Password must be at least 6 characters long";
        } else if (!/[A-Z]/.test(formData.password)) {
            newErrors.password = "Password must contain at least one uppercase letter";
        } else if (!/[a-z]/.test(formData.password)) {
            newErrors.password = "Password must contain at least one lowercase letter";
        } else if (!/[0-9]/.test(formData.password)) {
            newErrors.password = "Password must contain at least one number";
        } else if (!/[!@#$%^&*]/.test(formData.password)) {
            newErrors.password = "Password must contain at least one special character";
        }
        return newErrors;
    };
    const handleSave = async () => {
        const validationErrors = validateForm();
        if (Object.keys(validationErrors).length > 0) {
            setErrors(validationErrors);
            return;
        }
    
        const formDataToSubmit = new FormData();
        formDataToSubmit.append('name', formData.name);
        formDataToSubmit.append('roleId', formData.roleId);
        formDataToSubmit.append('email', formData.email);
        if(formData.password){
            formDataToSubmit.append('password', formData.password);
        }        
        setLoading(true);
        try {
            let clientSave;
            if (formData.id) {
                // Update existing client
                clientSave = await dispatch(updateClientAdminData({ clientAdminId: formData.id, clientAdminData: formDataToSubmit })).unwrap();
            } else {
                // Create new client
                clientSave = await dispatch(createClientAdminData(formDataToSubmit)).unwrap();
            }        
            clientSave.status ? toast.success(clientSave.message) : toast.error(clientSave.message);
            resetFormData();
            router.push(`/team-members`);
        } catch (error) {
            console.error('Error saving client data:', error);
        } finally {
            setLoading(false);
        }
    };
    const fetchRoles = async () => {
        try {
          // Fetch role details
          const roleData = await dispatch(fetchRoleData()).unwrap(); 
          // Set form data with the fetched role details
          if(roleData.status){
              setRoles(roleData.data);
          }                
        } catch (error) {
          console.error('Error fetching role details:', error);
        }
    };
    const fetchMemberDetails = async (uuid) => {
        try {
          // Fetch member details
          const memberData = await dispatch(deatilsClientAdminDataByUuid(uuid)).unwrap(); 
          // Set form data with the fetched member details
          if(memberData){
              setIsFieldDisabled(true);
              if(memberData.userRole[0].roleSlug == 'super-admin'){
                  setIsRoleDisabled(true);
              }            
              
              setFormData({
                  id: memberData.id,
                  name: memberData.name,
                  roleId: memberData.userRole[0].id,
                  email: memberData.email,
                  password: '',
              });
              setFormTitle('Edit Account');
              setFormSubTitle('Update contacts to this account');
          }                
        } catch (error) {
          console.error('Error fetching role details:', error);
        }
    };
    useEffect(() => {
      fetchRoles();
      if(uuid){
        fetchMemberDetails(uuid);
      }   
    }, [dispatch]);
  return (
    <>
      <div className='all-member-container'>                
        <div className='management-container'>
            <div className='account-container form-input-label'>
                <div className='navbar-tab'>
                    <Link href="/team-members">
                        <FontAwesomeIcon icon={faLongArrowLeft} />
                    </Link>
                </div>
                <div className='account-container-head'>
                    <img className="quote-image" src={IMAGE.quoteimg} alt="quoteimg" />
                    <h4>{formTitle}</h4>
                    <p>{formSubTitle}</p>
                </div>                
                <div className='field-group'>        
                    <div className="floating-label-group mt-5 mb-4">
                        <input type="text" id="name" name="name" className="input-form-control" value={formData.name} onChange={handleChange} required />
                        <label className="floating-label">Name</label>
                        {errors.name && <span className="text-danger">{errors.name}</span>}
                    </div>
                    <div className='payment-type-dropdown mb-4'>
                        <label className='payment-label'>User role</label>            
                        <select id="roleId" name="roleId" value={formData.roleId} onChange={handleChange} className="payment-terms mb-0" disabled={isRoleDisabled}>
                            <option value="">Select user role</option>
                            {
                              roles.map(role => (
                                (role.roleSlug == 'super-admin' && role.id == formData.roleId) || role.roleSlug != 'super-admin' ? 
                                <option value={role.id} key={role.id}>{role.roleName}</option>
                                : ''
                              ))
                            }
                        </select>
                        {errors.roleId && <span className="text-danger">{errors.roleId}</span>}
                    </div>
                    <div className="floating-label-group mb-4">
                        <input type="text" id="email" name="email" className="input-form-control" value={formData.email} onChange={handleChange} required disabled={isFieldDisabled} />
                        <label className="floating-label">Email</label>
                        {errors.email && <span className="text-danger">{errors.email}</span>}
                    </div>
                    <div className="floating-label-group">
                        <input type="password" id="password" name="password" className="input-form-control" value={formData.password} onChange={handleChange} required />
                        <label className="floating-label">Password</label>
                        {errors.password && <span className="text-danger">{errors.password}</span>}
                    </div>
                    <div className="text-center">
                        <button className='save-btn mt-4 mb-5' onClick={handleSave} disabled={loading}>
                            {loading ? 'Saving...' : 'Save'}
                        </button>
                    </div>
                </div>  
                
            </div>
          </div>
      </div>
      <ToastContainer />
    </>    
  )
}

export default AddMemberForm
