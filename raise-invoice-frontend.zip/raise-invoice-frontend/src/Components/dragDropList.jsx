"use client";
import { useEffect } from "react";
import {
  DndContext,
  closestCenter,
  PointerSensor,
  useSensor,
  useSensors,
} from "@dnd-kit/core";
import {
  arrayMove,
  SortableContext,
  useSortable,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { IMAGE } from "@/utils/Theme";
import { formatCurrency } from "@/dependencies/utils/helper";

function SortableItem({ item, handleDeleteItem, handleEditItem, idx, currencyList }) {
  const { attributes, listeners, setNodeRef, transform, transition } =
    useSortable({ id: item.drag_id }); // ✅ FIXED

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  const maxLen = 30;

  const description =
      item?.item_Description ?? item?.description ?? '';
  const shortDescription =
      description.length > maxLen
          ? description.slice(0, maxLen) + '...'
          : description;

  return (
    <div
      className="productName"
      ref={setNodeRef}
      style={style}
      {...attributes}
      {...listeners}
    >
      <div className="productNameLeftDot">
        <img src={IMAGE.dotted} alt="" />
      </div>
      <div className="productNameLeft">
        <h6>
          {item.code || ""}
          {item.code ? " - " : ""}
          {item.name}
        </h6>
        <p>
          {shortDescription ||
            "Add a description so your client understands the product or service you provided."}
        </p>
      </div>
      <div className="productNameRight">
        {/* {console.log("item.rate*item.quantity -----------------> ", item)} */}
        <h6>{formatCurrency(parseFloat((item.unitTypes ? (item.rate / item.quantity || 0) : item.rate) * item.quantity || 0), currencyList)}</h6>
        <p>
          {item.quantity} X {item.unitTypes ? (item.rate / item.quantity || 0) : item.rate || 0}
        </p>
        {(item.gstChecked === true || item.gstChecked === "true") &&
          item.gstValue && <span>{Number(item.gstValue)}% GST</span>}
        {(item.discountChecked === true ||
          item.discountChecked === "true") && (
          <span>
            Discount:{" "}
            {item.discountType === "percentage"
              ? `${item.discountValue}%`
              : formatCurrency(parseFloat(item.discountValue || 0), currencyList)}
          </span>
        )}
      </div>
      <div className="editDelete">
        <span
          className="edit"
          style={{ cursor: "pointer" }}
          onClick={() => handleEditItem(idx)}
        >
          <img src={IMAGE.editBtn} alt="" />
        </span>
        <span
          className="delete"
          style={{ cursor: "pointer" }}
          onClick={() => handleDeleteItem(idx)}
        >
          <img src={IMAGE.DeleteBtn} alt="" />
        </span>
      </div>
    </div>
  );
}

export default function DndKitList({
  items,
  setItems,
  handleDeleteItem,
  handleEditItem,
  currencyList
}) {
  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 5 } })
  );

  const handleDragEnd = (event) => {
    const { active, over } = event;
    if (!over || active.id === over.id) return;

    setItems((items) => {
      const oldIndex = items.findIndex((i) => i.drag_id === active.id);
      const newIndex = items.findIndex((i) => i.drag_id === over.id);
      return arrayMove(items, oldIndex, newIndex);
    });
  };

  // useEffect(() => {
  //   console.log("items :: ", items);
  // }, [items]);

  return (
    <div className="max-w-md mx-auto mt-10">
      <DndContext
        sensors={sensors}
        collisionDetection={closestCenter}
        onDragEnd={handleDragEnd}
      >
        <SortableContext
          items={items.map((i) => i.drag_id)} // ✅ FIXED
          strategy={verticalListSortingStrategy}
        >
          {items.map((item, idx) => (
            <SortableItem
              key={item.drag_id}
              item={item}
              idx={idx}
              handleDeleteItem={handleDeleteItem}
              handleEditItem={handleEditItem}
              currencyList={currencyList}
            />
          ))}
        </SortableContext>
      </DndContext>
    </div>
  );
}