import React from 'react'
import { IMAGE } from '../../utils/Theme';
import Link from 'next/link';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faArrowLeft } from '@fortawesome/free-solid-svg-icons';
import './authHead.css';

const Header = () => {
    return (
        <div className='header'>
            <div className='container'>
                <div className='auth-header'>
                    <div className='logo'>
                        <Link href="/">
                            <img src={IMAGE.logo} />
                        </Link>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Header
