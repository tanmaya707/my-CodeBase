import React, { useEffect, useState } from 'react';
import '../newExpense/newexpense.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { useDispatch } from 'react-redux';
import { deleteItem, fetchMasterData } from "@/redux/slices/dataSlice";
import { formatCurrency } from '@/dependencies/utils/helper';
import { faPenToSquare, faTrashCan } from '@fortawesome/free-solid-svg-icons';
import Link from 'next/link';


const ItemList = ({ label, itemss = [], onEditItem }) => {
    const [AddItemForm, setAddItemForm] = useState(false);
    const [currencyList, setCurrencyList] = useState([]);
    const dispatch = useDispatch();

    const handleEditItem = (itemId) => {
        setAddItemForm(true);
        if (label === 'Items') {
            onEditItem(itemId);
        }
    };

    const handleDeleteItem = async (uuid) => {
        let deleteData = '';
        if (label === 'Items') {
            console.log('Deleting item with ID:', uuid);
            deleteData = dispatch(deleteItem(uuid));
        }
        if (deleteData) {
            window.location.href = `/${label.toLowerCase()}`;
        }
    };

    
    useEffect(() => {
    async function fetchData() {
        try {
        const data = await dispatch(fetchMasterData()).unwrap();
        setCurrencyList(data.currencyData || []);
        } catch (err) {
        console.error("Failed to fetch master data", err);
        }
    }
    fetchData();
    }, [dispatch]);

    const maxLen = 30; 

    return (
        <div className='expense-middle mt-2'>
            <div className='sub-head'>
                <p>{label}</p>
                <p>{itemss.length}</p>
            </div>

            <div className="invoice-list-all">
                {itemss.map((item, index) => {
                    const description =
                        item?.item_Description ?? item?.description ?? '';
                    const shortDescription =
                        description.length > maxLen
                            ? description.slice(0, maxLen) + '...'
                            : description;
                    const rate = item?.rate ?? item?.price ?? 0;
                    return (
                        <div className="invoice-list" key={index}>
                            <div className='invoice-left'>
                                <p className="text-start">{item.item_name}</p>
                                <p>{shortDescription}</p>
                            </div>
                        <div className='invoice-right'>
                            <p className="invoice-price">{formatCurrency(item.rate, currencyList)}</p>
                            <div className='group-icon'>
                                <Link href="#" onClick={(e) => { e.preventDefault(); handleEditItem(item); }}>
                                    <FontAwesomeIcon icon={faPenToSquare} />
                                </Link>

                                <Link href="#" onClick={() => handleDeleteItem({ uuid: item.uuid })}>
                                    <FontAwesomeIcon icon={faTrashCan} />
                                </Link>
                            </div>
                        </div>
                    </div>
                    );
                })}
                {itemss?.length === 0 && <p>No {label?.toLowerCase()} available.</p>}
            </div>
        </div>
    );
}

export default ItemList;
