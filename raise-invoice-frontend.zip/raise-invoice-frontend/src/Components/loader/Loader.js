// components/Loader.js
import React from "react";
import styles from "./Loader.module.css"; // Import CSS module for styling

const Loader = () => {
  return (
    <div className={styles.loaderContainer}>
      <div className={styles.loader}>
        <center>
          <p>
            We're creating your profile and securely preparing your company's
            database.{" "}
          </p>
          <p>
            This usually takes just a moment. Hang tight — your new workspace
            will be ready shortly!
          </p>
        </center>
      </div>
    </div>
  );
};

export default Loader;
