"use client"
import React from 'react'
import './leftpanel.css';
import { IMAGE } from '@/utils/Theme';
import '../leftpanel/leftpanel.css'
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';

import img from 'next/image';

const Leftpanel = () => {
  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: false, 
    autoplay: false, 
    autoplaySpeed: 2000,

};


  return (
    <div className='leftpanel'>
    

      <Slider {...settings}>
      <div className='leftpanel-content-carousel'>

      <div className='ellipse-img'>
        <img className='ellipse' src={IMAGE.ellipse} alt='Image broken' />
      </div>
      <div className='leftpanel__content'>
        <h1>Welcome to RaiseInvoice</h1>
        <img className="quote" src={IMAGE.quoteimg} alt='Image broken' />
      </div>

      <p>Thank you for choosing us. Your free <br />30 days trial has started </p>

      </div>

      <div className='leftpanel-content-carousel'>

        <div className='ellipse-img'>
          <img className='ellipse' src={IMAGE.ellipse} alt='Image broken' />
        </div>
        <div className='leftpanel__content'>
          <h1>Login to see more details</h1>
          <img className="quote" src={IMAGE.quoteimg} alt='Image broken' />
        </div>

        <p>Thank you for choosing us. Your free <br />30 days trial has started </p>

      </div>


      </Slider>


    </div>


  )
}

export default Leftpanel
