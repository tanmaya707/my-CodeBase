
import React, { useState, useEffect } from 'react';
import Pageheader from '@/utils/pageheader';
import './addItemForm.css'
import '../../app/general.css';
import { faAngleDown, faCalendarDays, faSquarePlus } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import ToggleButton from '@/utils/ToggleButton/toggleButton';


const AddItemForm = (onItemAdded) => {
  const [loading, setLoading] = useState(false);
  const [value, setValue] = useState(false);
  const [value2, setValue2] = useState(false);

  const handleTips = (e) => {
    setValue(e.target.checked);
  }
  const handleAdvice = (e) => {
    setValue2(e.target.checked);
  }
  const handleSave = async () => {
    alert("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
  }

  return (
    <>
      <Pageheader label="Add New Item" handleSave={handleSave} loading={loading} />
      <div className='contentArea-inner form-input-label'>
        <h5 className="headline mb-3">Description1</h5>

        <form>
          <div className='row'>
            <div className='col-lg-6 col-md-6 col-sm-12'>

              <div className="floating-label-group mb-3">
                <input
                  type="text"
                  id="billingName"
                  className="input-form-control"
                  required
                />
                <label className="floating-label">Billing Name</label>
              </div>
            </div>

            <div className='col-lg-12 col-md-12 col-sm-12'>
              <div className="floating-label-group mb-3">
                <textarea
                  id="description"
                  className="input-form-control"
                  required
                  style={{ minHeight: '70px', resize: 'vertical' }}
                />
                <label className="floating-label">Description</label>
              </div>
            </div>

            <div className='col-lg-4 col-md-6 col-sm-12'>
              <div className="phone-input mb-3">
                <div className="floating-label-group">
                  <input type="text" className="small-input" required />
                  <label className="small-input-floating">Rate</label>
                </div>
                <div className="smallinput-divider"></div>
                <div className="country-code-small">$ <FontAwesomeIcon icon={faAngleDown} className='phone-angle' /></div>
              </div>
            </div>

            <div className='col-lg-4 col-md-6 col-sm-12'>
              <div className="phone-input mb-3">
                <div className="floating-label-group">
                  <input type="text" className="small-input" required />
                  <label className="small-input-floating">Cost</label>
                </div>
                <div className="smallinput-divider"></div>
                <div className="country-code-small">$ <FontAwesomeIcon icon={faAngleDown} className='phone-angle' /></div>
              </div>
            </div>
            <div className='col-lg-4 col-md-6 col-sm-12'>
              <div className='payment-type-dropdown'>

                <select className="payment-terms" name="cars" id="cars">
                  <option value="">Unit Type</option>
                  <option value="volvo">Volvo</option>
                  <option value="saab">Saab</option>
                  <option value="mercedes">Mercedes</option>
                  <option value="audi">Audi</option>
                </select>
              </div>
            </div>


            <div className='col-lg-12 '>
              <h5 className="headline mb-3">Taxes</h5>
              <div className='default-taxes'>
                <p>Default taxes will be applied to this item.</p>

                <ToggleButton
                  isToggled={value2}
                  onToggle={handleAdvice}

                />
              </div>

            </div>
          </div>

        </form>
      </div>
    </>
  )
}

export default AddItemForm;