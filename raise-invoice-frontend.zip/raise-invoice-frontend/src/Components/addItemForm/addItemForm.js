import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { toast } from 'react-toastify';
import Pageheader from '@/utils/pageheader';
import './addItemForm.css';
import '../../app/general.css';
import { faAngleDown } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import ToggleButton from '@/utils/ToggleButton/toggleButton';
import { fetchMasterData, createItemData, fetchItemData, deatilsItemData, updateItemData } from '@/redux/slices/dataSlice';

import clsx from "clsx";
import route from 'use-router/dist/route';

const AddItemForm = ({ itemToEdit,itemsheader }) => {
  const dispatch = useDispatch();
  const [loading, setLoading] = useState(false);
  const [value2, setValue2] = useState(false);
  const [unsaved, setUnsaved] = useState(false);
  const [modalType, setModalType] = useState('reload');
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({
    itemName: '',
    itemDescription: '',
    rate: '',
    cost: '',
    unitType: '',
  });

  const { items } = useSelector((state) => state.dataReducer);

    // useEffect(() => {
    //     if (!itemToEdit) {
    //         const hasUnsavedChanges =
    //                 formData.itemName ||
    //                 formData.itemDescription ||
    //                 formData.rate ||
    //                 formData.cost ||
    //                 formData.unitType
    //         setUnsaved(hasUnsavedChanges);
    //     } else {
    //         setUnsaved(false);
    //     }
    // }, [formData, itemToEdit]);

    // useEffect(() => {
    //     const handleBeforeUnload = (e) => {
    //         if (!itemToEdit && unsaved) {
    //             e.preventDefault();
    //             e.returnValue = '';
    //             setModalType('close');
    //             setShowModal(true);
    //             return '';
    //         }
    //     };
    //     window.addEventListener('beforeunload', handleBeforeUnload);
    //     return () => window.removeEventListener('beforeunload', handleBeforeUnload);
    // }, [unsaved, itemToEdit]);

    // useEffect(() => {
    //     const handleKeyDown = (e) => {
    //         if (!itemToEdit && unsaved && (e.key === 'F5' || (e.ctrlKey && e.key === 'r'))) {
    //             e.preventDefault();
    //             setModalType('reload');
    //             setShowModal(true);
    //         }
    //     };
    //     window.addEventListener('keydown', handleKeyDown);
    //     return () => window.removeEventListener('keydown', handleKeyDown);
    // }, [unsaved, itemToEdit]);

  // Fetch item details if editing
  useEffect(() => {
    const fetchItemDetails = async () => {
      if (itemToEdit && itemToEdit.id) {
        try {
          const itemDetails = await dispatch(deatilsItemData({ id: itemToEdit.id })).unwrap();
          setFormData({
            itemName: itemDetails?.data?.item_name || '',
            itemDescription: itemDetails?.data?.item_Description || '',
            rate: itemDetails?.data?.rate || '',
            cost: itemDetails?.data?.qty || '',
            unitType: itemDetails?.data?.unit_code || '',
          });
          setValue2(itemDetails?.data?.tax === 1); // Set tax toggle based on item details
        } catch (error) {
          console.error('Error fetching item details:', error);
          toast.error("Failed to fetch item details.");
        }
      }
    };
    fetchItemDetails();
  }, [dispatch, itemToEdit]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleAdvice = (e) => {
    setValue2(e.target.checked);
  };

  const handleSave = async (e) => {
    e.preventDefault();
    const { itemName, itemDescription, rate, cost, unitType } = formData;

    // Basic validation
    if ( !itemName || !itemDescription || !rate || !cost ) {
      toast.error("Please fill in all fields.");
      return;
    }

    // Validate numeric fields
    if (isNaN(rate) || isNaN(cost)) {
      toast.error("Rate and Quantity must be valid numbers.");
      return;
    }

    setLoading(true);
    const payload = {
      item_name: itemName,
      item_Description: itemDescription,
      rate: parseFloat(rate),
      currency: 1, // Assuming a default currency
      qty: parseFloat(cost), // Assuming cost is the quantity
      unit_code: unitType, // Use unitType as unit_code
      tax: value2 ? 1 : 0, // Example tax logic
    };

    try {
      let response;
      if (itemToEdit && itemToEdit.id) {
        // Update existing item
        response = await dispatch(updateItemData({ id: itemToEdit.id, ...payload })).unwrap();
      } else {
        // Create new item
        response = await dispatch(createItemData(payload)).unwrap();
      }

      toast.success(response.message);
      window.location.reload();
      // Reset form
      setFormData({
        itemName: '',
        itemDescription: '',
        rate: '',
        cost: '',
        unitType: '',
      });
      setValue2(false);
    } catch (error) {
      toast.error("Failed to save item. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    dispatch(fetchMasterData());
  }, [dispatch]);

  return (
    <>
      <Pageheader className="itemHeder" label={itemToEdit ? "Edit Item" : "Add New Item"} handleSave={handleSave} loading={loading} />

      <div className='contentArea-inner form-input-label'>
        <h5 className="headline mb-3">Description</h5>

        <form onSubmit={handleSave}>
          <div className='row'>
            <div className='col-lg-6 col-md-6 col-sm-12'>
              <div className="floating-label-group mb-3">
                <input
                  type="text"
                  name="itemName"
                  value={formData.itemName}
                  onChange={handleChange}
                  className="input-form-control"
                  required
                />
                <label className="floating-label">Items Name</label>
              </div>
            </div>

            <div className='col-lg-12 col-md-12 col-sm-12'>
              <div className="floating-label-group mb-3">
                <textarea
                  name="itemDescription"
                  value={formData.itemDescription}
                  onChange={handleChange}
                  className="input-form-control"
                  required
                  style={{ minHeight: '70px', resize: 'vertical' }}
                />
                <label className="floating-label">Description</label>
              </div>
            </div>

            <div className='col-lg-4 col-md-6 col-sm-12'>
              <div className="phone-input mb-3">
                <div className="floating-label-group">
                  <input
                    type="text"
                    name="rate"
                    value={formData.rate}
                    onChange={handleChange}
                    className="small-input"
                    required
                  />
                  <label className="small-input-floating">Rate</label>
                </div>
                <div className="smallinput-divider"></div>
                <div className="country-code-small">$ <FontAwesomeIcon icon={faAngleDown} className='phone-angle' /></div>
              </div>
            </div>

            <div className='col-lg-4 col-md-6 col-sm-12'>
              <div className="phone-input mb-3">
                <div className="floating-label-group">
                  <input
                    type="text"
                    name="cost"
                    value={formData.cost}
                    onChange={handleChange}
                    className="small-input"
                    required
                  />
                  <label className="small-input-floating">Qty</label>
                </div>
                {/* <div className="smallinput-divider"></div> */}
                {/* <div className="country-code-small">mtr <FontAwesomeIcon icon={faAngleDown} className='phone-angle' /></div> */}
              </div>
            </div>

            <div className='col-lg-4 col-md-6 col-sm-12'>
              <div className='payment-type-dropdown'>
                <select
                  name="unitType"
                  value={formData.unitType}
                  onChange={handleChange}
                  className="payment-terms"
                  required
                >
                  <option value="">Unit Type</option>
                  {items?.productUnitTypes?.map((unitType) => (
                    <option key={unitType.value} value={unitType.value}>
                      {unitType.title}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className='col-lg-12 '>
              <h5 className="headline mb-3">Taxes</h5>
              <div className='default-taxes'>
                <p>Default taxes will be applied to this item.</p>
                <ToggleButton
                  isToggled={value2}
                  onToggle={handleAdvice}
                />
              </div>
            </div>
          </div>
        </form>
      </div>
    </>
  );
};

export default AddItemForm;
