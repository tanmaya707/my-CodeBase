"use client";
import React, { useState, useEffect, useRef } from "react";
import Accordion from "react-bootstrap/Accordion";
import Pageheader from "@/utils/pageheader";
import { useDispatch } from "react-redux";
import { useRouter } from "next/navigation";
import "../../app/general.css";
import Modal from "react-bootstrap/Modal";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faLocationDot, faCalendarDays } from "@fortawesome/free-solid-svg-icons";
import Calendar from "react-calendar";
import "react-calendar/dist/Calendar.css";
import { ToastContainer, toast } from "react-toastify";
import {
    fetchProjectData,
    createProjectData,
    fetchClientData,
    deatilsProjectData,
    updateProjectData,
} from "@/redux/slices/dataSlice";
import GooglePlacesAutocomplete from "react-google-places-autocomplete";
import DropdownIndicator from "@/Components/dropdownIndicator/dropdownIndicator";

const formatDateDisplay = (date) => {
    if (!date) return "";
    const d = new Date(date);
    const day = String(d.getDate()).padStart(2, "0");
    const month = String(d.getMonth() + 1).padStart(2, "0");
    const year = d.getFullYear();
    return `${day}-${month}-${year}`;
};

const formatDateForInput = (date) => {
    // For react-calendar value prop (should be Date object)
    if (!date) return null;
    return new Date(date);
};

const NewProject = ({ projectToEdit }) => {
    const dispatch = useDispatch();
    const router = useRouter();
    const [show, setShow] = useState(false);
    const [loading, setLoading] = useState(false);

    const [selectedProject, setSelectedClient] = useState(null);
    const [showCalendarStart, setShowCalendarStart] = useState(false);
    const [showCalendarEnd, setShowCalendarEnd] = useState(false);
    const [startDate, setStartDate] = useState(null);
    const [endDate, setEndDate] = useState(null);
    const [clients, setClients] = useState([]);
    const [location, setLocation] = useState(null);
    const [projectName, setProjectName] = useState("");
    const [projectDescription, setProjectDescription] = useState("");

    // Calendar refs for outside click
    const calendarStartRef = useRef(null);
    const calendarEndRef = useRef(null);

    // // Unsaved changes and modal states
    // const [unsaved, setUnsaved] = useState(false);

    // // Track unsaved changes
    // useEffect(() => {
    //     if (!projectToEdit) {
    //         const hasUnsavedChanges =
    //             !!selectedProject ||
    //             !!location ||
    //             !!projectName ||
    //             !!projectDescription ||
    //             !!startDate ||
    //             !!endDate;
    //         setUnsaved(hasUnsavedChanges);
    //     } else {
    //         setUnsaved(false);
    //     }
    // }, [
    //     selectedProject,
    //     location,
    //     projectName,
    //     projectDescription,
    //     startDate,
    //     endDate,
    //     projectToEdit,
    // ]);

    // // Handle browser/tab close
    // useEffect(() => {
    //     const handleBeforeUnload = (e) => {
    //         if (!projectToEdit && unsaved) {
    //             e.preventDefault();
    //             e.returnValue = "";
    //             return "";
    //         }
    //     };
    //     window.addEventListener("beforeunload", handleBeforeUnload);
    //     return () =>
    //         window.removeEventListener("beforeunload", handleBeforeUnload);
    // }, [unsaved, projectToEdit]);

    // // Intercept reload (F5 or Ctrl+R)
    // useEffect(() => {
    //     const handleKeyDown = (e) => {
    //         if (
    //             !projectToEdit &&
    //             unsaved &&
    //             (e.key === "F5" || (e.ctrlKey && e.key === "r"))
    //         ) {
    //             e.preventDefault();
    //         }
    //     };
    //     window.addEventListener("keydown", handleKeyDown);
    //     return () => window.removeEventListener("keydown", handleKeyDown);
    // }, [unsaved, projectToEdit]);

    // Fetch clients and project details
    useEffect(() => {
        const fetchClients = async () => {
            const clientData = await dispatch(fetchClientData()).unwrap();
            setClients(clientData.data);
            if (projectToEdit && projectToEdit.id) {
                try {
                    const projectDetails = await dispatch(
                        deatilsProjectData({
                            client_id: projectToEdit.client_id,
                            projectId: projectToEdit.id,
                        })
                    ).unwrap();

                    setSelectedClient(projectDetails.data.enrichedProject.client || "");
                    setStartDate(
                        projectDetails.data.enrichedProject.start_date
                            ? new Date(projectDetails.data.enrichedProject.start_date)
                            : null
                    );
                    setEndDate(
                        projectDetails.data.enrichedProject.end_date
                            ? new Date(projectDetails.data.enrichedProject.end_date)
                            : null
                    );
                    setLocation({
                        label: projectDetails.data.enrichedProject.project_location,
                        value: projectDetails.data.enrichedProject.project_location,
                        place_id: "initial" || "",
                    });
                    setProjectName(
                        projectDetails.data.enrichedProject.project_name || ""
                    );
                    setProjectDescription(
                        projectDetails.data.enrichedProject.project_desc || ""
                    );
                } catch (error) {
                    console.error("Error fetching client details:", error);
                }
            } else {
                setSelectedClient(null);
                setStartDate(null);
                setEndDate(null);
                setLocation(null);
                setProjectName("");
                setProjectDescription("");
            }
        };
        fetchClients();
    }, [dispatch, projectToEdit]);

    // Calendar outside click handler
    useEffect(() => {
        const handleClickOutside = (event) => {
            if (
                showCalendarStart &&
                calendarStartRef.current &&
                !calendarStartRef.current.contains(event.target)
            ) {
                setShowCalendarStart(false);
            }
            if (
                showCalendarEnd &&
                calendarEndRef.current &&
                !calendarEndRef.current.contains(event.target)
            ) {
                setShowCalendarEnd(false);
            }
        };
        if (showCalendarStart || showCalendarEnd) {
            document.addEventListener("mousedown", handleClickOutside);
        }
        return () => {
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, [showCalendarStart, showCalendarEnd]);

    const handleClientSelect = (client) => {
        setSelectedClient(client);
        setShow(false);
    };

    const validateForm = () => {
        if (!selectedProject) {
            toast.error("Please select a client.");
            return false;
        }
        if (!location) {
            toast.error("Please select a location.");
            return false;
        }
        if (!projectName) {
            toast.error("Please enter a project name.");
            return false;
        }
        if (!projectDescription) {
            toast.error("Please enter a project description.");
            return false;
        }
        if (!startDate || !endDate) {
            toast.error("Please select both start and end dates.");
            return false;
        }
        if (startDate >= endDate) {
            toast.error("End date must be after start date.");
            return false;
        }
        return true;
    };

    const handleSave = async () => {
        if (!validateForm()) return;

        setLoading(true);
        try {
            const formDataToSubmit = new FormData();
            formDataToSubmit.append(
                "client_id",
                selectedProject ? selectedProject.id : null
            );
            formDataToSubmit.append("project_name", projectName);
            formDataToSubmit.append(
                "project_location",
                location ? location.label : ""
            );
            // Format as yyyy-mm-dd for backend
            const formatForBackend = (date) => {
                if (!date) return "";
                const d = new Date(date);
                const day = String(d.getDate()).padStart(2, "0");
                const month = String(d.getMonth() + 1).padStart(2, "0");
                const year = d.getFullYear();
                return `${year}-${month}-${day}`;
            };
            formDataToSubmit.append(
                "start_date",
                startDate ? formatForBackend(startDate) : ""
            );
            formDataToSubmit.append(
                "end_date",
                endDate ? formatForBackend(endDate) : ""
            );
            formDataToSubmit.append("project_desc", projectDescription);
            formDataToSubmit.append("status", 1);
            if (location) {
                formDataToSubmit.append(
                    "latitude",
                    location?.value?.geometry?.location?.lat?.()
                );
                formDataToSubmit.append(
                    "longitude",
                    location?.value?.geometry?.location?.lng?.()
                );
            }

            if (projectToEdit?.id) {
                formDataToSubmit.append(
                    "projectId",
                    selectedProject ? projectToEdit.id : null
                );
            }

            let projectCreate;

            if (projectToEdit && projectToEdit.id) {
                projectCreate = await dispatch(updateProjectData(formDataToSubmit)).unwrap();
            } else {
                projectCreate = await dispatch(createProjectData(formDataToSubmit)).unwrap();
            }

            if (projectCreate.status) {
                toast.success(projectCreate.message);
                dispatch(fetchProjectData());
                router.push("/project");
            } else {
                toast.error(projectCreate.message);
            }
        } catch (error) {
            console.error("Error saving project:", error);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div>
            <Pageheader
                label={projectToEdit ? "Edit Project" : "Add Project"}
                handleSave={handleSave}
                loading={loading}
            />
            <div className="contentArea-inner form-input-label">
                <Accordion defaultActiveKey="0">
                    <Accordion.Item eventKey="0">
                        <Accordion.Header>
                            <p className="accorheading">Client</p>
                        </Accordion.Header>
                        <Accordion.Body>
                            <button className="choose-contact" onClick={() => setShow(true)}>
                                {selectedProject ? selectedProject.name : "Choose From Existing Client"}
                            </button>
                        </Accordion.Body>
                    </Accordion.Item>
                </Accordion>

                <Accordion defaultActiveKey="0">
                    <Accordion.Item eventKey="0">
                        <Accordion.Header>
                            <p className="accorheading">Other Details</p>
                        </Accordion.Header>
                        <Accordion.Body>
                            <div className="row">
                                <div className="col-lg-6">
                                    <div className="floating-label-group mb-3">
                                        <input
                                            type="text"
                                            id="project-name"
                                            className="input-form-control"
                                            required
                                            value={projectName}
                                            onChange={(e) => setProjectName(e.target.value)}
                                        />
                                        <label className="floating-label">Project Name</label>
                                    </div>
                                </div>
                                <div className="col-lg-6">
                                    <div className="floating-label-group">
                                        <label className="floating-label">Project Location</label>
                                        <div className="floating-label-group borderHover">
                                            <GooglePlacesAutocomplete
                                                apiKey={process.env.NEXT_PUBLIC_GOOGLE_MAP_KEY}
                                                selectProps={{
                                                    value: location,
                                                    onChange: (selected) => {
                                                        setLocation(selected ?? "");
                                                    },
                                                    placeholder: "Project Location",
                                                    components: { DropdownIndicator },
                                                }}
                                            />
                                            <FontAwesomeIcon className="point-img" icon={faLocationDot} />
                                        </div>
                                    </div>
                                </div>
                                <div className="col-lg-12">
                                    <div className="floating-label-group mb-3">
                                        <textarea
                                            type="text"
                                            id="description"
                                            className="input-form-control"
                                            required
                                            value={projectDescription}
                                            onChange={(e) => setProjectDescription(e.target.value)}
                                        />
                                        <label className="floating-label">Project Description</label>
                                    </div>
                                </div>
                                <div className="col-lg-6">
                                    <div className="floating-label-group mb-3" style={{ position: "relative" }}>
                                        <input
                                            type="text"
                                            id="start-date"
                                            className="input-form-control input-logo"
                                            required
                                            value={startDate ? formatDateDisplay(startDate) : ""}
                                            readOnly
                                            onClick={() => setShowCalendarStart((v) => !v)}
                                        />
                                        <label className="floating-label">Start Date</label>
                                        <FontAwesomeIcon
                                            className="point-img"
                                            icon={faCalendarDays}
                                            onClick={() => setShowCalendarStart((v) => !v)}
                                        />
                                        {showCalendarStart && (
                                            <div
                                                ref={calendarStartRef}
                                            >
                                                <Calendar
                                                    onChange={(date) => {
                                                        setStartDate(date);
                                                        setShowCalendarStart(false);
                                                        if (endDate && date >= endDate) setEndDate(null);
                                                    }}
                                                    value={formatDateForInput(startDate)}
                                                />
                                            </div>
                                        )}
                                    </div>
                                </div>
                                <div className="col-lg-6">
                                    <div className="floating-label-group mb-3" style={{ position: "relative" }}>
                                        <input
                                            type="text"
                                            id="end-date"
                                            className="input-form-control input-logo"
                                            required
                                            value={endDate ? formatDateDisplay(endDate) : ""}
                                            readOnly
                                            onClick={() => setShowCalendarEnd((v) => !v)}
                                        />
                                        <label className="floating-label">End Date</label>
                                        <FontAwesomeIcon
                                            className="point-img"
                                            icon={faCalendarDays}
                                            onClick={() => setShowCalendarEnd((v) => !v)}
                                        />
                                        {showCalendarEnd && (
                                            <div
                                                ref={calendarEndRef}
                                            >
                                                <Calendar
                                                    onChange={(date) => {
                                                        setEndDate(date);
                                                        setShowCalendarEnd(false);
                                                    }}
                                                    value={formatDateForInput(endDate)}
                                                    minDate={startDate ? new Date(startDate.getTime() + 24 * 60 * 60 * 1000) : undefined}
                                                />
                                            </div>
                                        )}
                                    </div>
                                </div>
                            </div>
                        </Accordion.Body>
                    </Accordion.Item>
                </Accordion>
            </div>

            {/* Client Modal */}
            <Modal show={show} centered onHide={() => setShow(false)}>
                <Modal.Header closeButton>
                    <Modal.Title>Choose Client</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <div className="row">
                        {clients.map((client) => (
                            <div
                                className="col-lg-12"
                                key={client.id}
                                style={{ cursor: "pointer" }}
                                onClick={() => handleClientSelect(client)}
                            >
                                <button
                                    className="client-btn btn"
                                    style={{ width: "100%", textAlign: "left", pointerEvents: "none" }}
                                    tabIndex={-1}
                                >
                                    {client.name}
                                </button>
                                <hr />
                            </div>
                        ))}
                    </div>
                </Modal.Body>
            </Modal>

            <ToastContainer />

            {/* Calendar selected date style */}
            <style jsx global>{`
                .calendar-selected-date {
                    background: #007bff !important;
                    color: #fff !important;
                    border-radius: 50% !important;
                }
                .react-calendar__tile--active {
                    background: #007bff !important;
                    color: #fff !important;
                }
                .react-calendar__tile--now {
                    background: #e6f0ff !important;
                }
            `}</style>
        </div>
    );
};

export default NewProject;
