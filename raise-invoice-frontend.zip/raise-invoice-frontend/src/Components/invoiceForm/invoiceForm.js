import React from 'react'
import { useState } from 'react';

import './invoiceForm.css';
import Link from 'next/link';
import { IMAGE } from '@/utils/Theme';
// import Pageheader from '@/utils/pageheader';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faLocationDot, faAngleDown, faSquarePlus, faArrowRight, faCalendarDays, faCheck } from '@fortawesome/free-solid-svg-icons';
// import Accordion from 'react-bootstrap/Accordion';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';

// import { PiPrinterBold } from "react-icons/pi";

import InvoicePdf from '@/Components/InvoicePDF/invoicePdf';

import '../../app/general.css';
import ModalCommon from '../modalCommon/modalCommon';

const InvoiceForm = ({ activeTag }) => {
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const [isVisible, setIsVisible] = useState(false);

  const handleButtonClick = () => {
    {
      if (activeTag !== 0) {
        setIsVisible(false);
      }
    }
  };

  // =========calendar==========
  const [showCalendarStart, setShowCalendarStart] = useState(false);
  const [showCalendarEnd, setShowCalendarEnd] = useState(false);
  const [value, onChange] = useState(new Date());

  return (
    <>
      <div className='contentInvoice-inner' style={{ 'width': '100%' }}>
        {isVisible && (
          <div className='contentInvoice-inner-top'>
            <div className='contentInvoice-top-left'>
              <h3>Invoice 4</h3>
              <h5>Akash Mishra</h5>
              <p className='unset'>Unsent</p>
            </div>
            <div className='contentInvoice-top-left'>
              <h3>Oct 23, 2024</h3>
              <h5 className='sent'>Due in 2 days</h5>
              <p>$125</p>
            </div>
          </div>
        )}

        <div className='preview-content-all'>
          <div className='preview-content'>
            <InvoicePdf />
            <div className="booking-btns">
              <button className='bookThemeBtn' > <img src={IMAGE.eye} alt="" /> Preview</button>
              {activeTag === 0 ?
                <button className='bookThemeBtn'> <img src={IMAGE.eye} alt="" /> Preview as PDF</button>
                : ""}
            </div>
          </div>
          <div className='submit-btns'>
            <button className='ThemeBtnBgNone'> <img src={IMAGE.file} alt="" /> Attach File</button>
            <button className='ThemeBtn'>Send</button>
          </div>
          <div className='payemnet-details'>
            <h5>Payment</h5>
            {activeTag === 0 ? <button className='ThemeBtnBordered'> Mark as Fully Paid</button>
              :
              <div className='payment-paid-top'>
                <div className='payment-paid'>
                  <img src={IMAGE.done} alt="" />
                  <h6>$120.00 Paid</h6>
                </div>

                <div className='payemnet-method'>
                  <p>Payment Method : Cash</p>
                  <p> Transaction Id : TRN-123456456</p>
                </div>
              </div>
            }
            <ul className="payment-info">
              <li onClick={handleShow}>
                <Link href='' >
                  <div className='link-left'>
                    <img src={IMAGE.payment_status1} alt="" /> Record Payment
                  </div>
                  <div className='image-right'>
                    <FontAwesomeIcon icon={faArrowRight} />
                  </div>
                </Link>
              </li>
              <li>
                <Link href=''>
                  <div className='link-left'>
                    <img src={IMAGE.payment_status2} alt="" />Show QR Code
                  </div>
                  <div className='image-right'>
                    <FontAwesomeIcon icon={faArrowRight} />
                  </div>
                </Link>
              </li>
            </ul>

          </div>
          <div className='payemnet-details'>
            <h5>More</h5>
            <ul className="payment-info">
              {activeTag === 0 ?
                <li>
                  <Link href=''>
                    <div className='link-left'>
                      <img src={IMAGE.payment_status3} alt="" /> <p>   Recurring Invoice <span>Off</span></p>
                    </div>

                  </Link>
                </li>

                : ""}
              <li>
                <Link href=''>
                  <div className='link-left'>
                    <img src={IMAGE.payment_status4} alt="" />Print
                  </div>
                  <div className='image-right'>
                    <FontAwesomeIcon icon={faArrowRight} />
                  </div>
                </Link>
              </li>

              <li>
                <Link href=''>
                  <div className='link-left'>
                    <img src={IMAGE.payment_status5} alt="" />Copy
                  </div>
                  <div className='image-right'>
                    <FontAwesomeIcon icon={faArrowRight} />
                  </div>
                </Link>
              </li>

              <li>
                <Link href=''>
                  <div className='link-left'>
                    <img src={IMAGE.payment_status6} alt="" />Export as PDF
                  </div>
                  <div className='image-right'>
                    <FontAwesomeIcon icon={faArrowRight} />
                  </div>
                </Link>
              </li>
              {/* {activeTag === 0 ?
                <li>
                  <Link href=''>
                    <div className='link-left'>
                      <img src={IMAGE.payment_status7} alt="" />Sign
                    </div>
                    <div className='image-right'>
                      <FontAwesomeIcon icon={faArrowRight} />
                    </div>
                  </Link>
                </li>
                : ""} */}
            </ul>


            <button className='ThemeBtnBordered' onClick={handleButtonClick}> Mark as Sent</button>



          </div>
        </div>
      </div>

      <Modal show={show} centered onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Record Payment</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div className='payment-header'>
            <span><FontAwesomeIcon icon={faCheck} /></span>  Mark as Fully Paid
          </div>
          <form>
            <div className='form-input-label'>
              <div className="form-group mb-3">
                <div className="phone-input  mb-3">
                  <div className="floating-label-group ">
                    <input type="text" className="phone-number" placeholder='100' required />
                    <label className="phone-floating-label label-custum">Amount</label>
                  </div>
                  <div className="divider"></div>
                  <div className="country-code">$ <FontAwesomeIcon icon={faAngleDown} className='phone-angle' /></div>
                </div>
              </div>
              <div className="form-group mb-3">
                <div className="floating-label-group">
                  <input type="text" className="input-form-control" required />
                  <label className="floating-label"> Method</label>
                </div>
              </div>
              <div className="form-group mb-3">
                <div className="floating-label-group">
                  <input type="text" className="input-form-control" required />
                  <FontAwesomeIcon
                    className="point-img"
                    icon={faCalendarDays}
                    onClick={() => setShowCalendarStart(!showCalendarStart)}
                  />
                  <label className="floating-label"> Date</label>
                </div>
              </div>
              <div className='form-group mb-3'>
                <div className="floating-label-group mb-3">
                  <textarea type="text" id="logo" className="input-form-control" required />
                  <label className="floating-label">Details</label>
                </div>
              </div>
            </div>
            <div className='checkbox-previewmail'>
              <div className='checkbox-custom'>
                <input type="checkbox" id="preview-mail" />
                <label className="preview-mail">Send receipt</label>
              </div>
              <Link className='preview-mail' href="#">Get a preview email</Link>
            </div>
          </form>
        </Modal.Body>
        <Modal.Footer>
          <Button className='modelThemeBtn' variant="primary" onClick={handleClose}>
            Record Payment
          </Button>
        </Modal.Footer>
      </Modal>
    </>

  )
}

export default InvoiceForm
