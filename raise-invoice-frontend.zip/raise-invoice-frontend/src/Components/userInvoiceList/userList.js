import React, { useEffect, useMemo, useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPenToSquare, faTrashCan } from '@fortawesome/free-solid-svg-icons';
import './userList.css';
import { IMAGE } from '@/utils/Theme';
import { useDispatch, useSelector } from 'react-redux';
import { fetchClientData, deleteClient, fetchProjectData, deleteProject, fetchItemData, deleteItem, getExpenseData, deleteExpense, fetchMasterData } from '@/redux/slices/dataSlice';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { formatCurrency } from '@/dependencies/utils/helper';

function getInitials(name = "") {
    const [first = "", second = ""] = name.trim().split(" ");
    return second[0] ? (first[0] || "").toUpperCase() + (second[0] || "").toUpperCase() : first ? first.slice(0, 2).toLocaleUpperCase() : "U";
}

const UserList = ({ label, projectss = [], onEditProject, clientss = [], onEditClient, itemss = [], expensess = [], onEditItem, sortDirection }) => {
    const dispatch = useDispatch();
    const router = useRouter();
    const [addClientForm, setAddClientForm] = useState(false);
    const { clients, projects, projectItems, expenses } = useSelector((state) => state.dataReducer);
    const [loading, setLoading] = useState(false);
    const [activeItemId, setActiveItemId] = useState(null);
    const [currencyList, setCurrencyList] = useState([]);
    // Fetch data based on the label
    useEffect(() => {
        const fetchData = async () => {
            setLoading(true);
            if (label === 'Client' && clients.length === 0) {
                dispatch(fetchClientData());
            } else if (label === 'Project' && projects.length === 0) {
                dispatch(fetchProjectData());
            } else if (label === 'Item' && projectItems.length === 0) {
                dispatch(fetchItemData());
            } else if (label === 'Invoice' && projectItems.length === 0) {
                dispatch(fetchItemData());
            } else if (label === 'Expense' && expenses.length === 0) {
                dispatch(getExpenseData());
            }
            setLoading(false);
        };

        fetchData();
    }, [label, clients.length, projects.length, dispatch]);

    useEffect(() => {
    async function fetchData() {
        try {
        const data = await dispatch(fetchMasterData()).unwrap();
        setCurrencyList(data.currencyData || []);
        } catch (err) {
        console.error("Failed to fetch master data", err);
        }
    }
    fetchData();
    }, [dispatch]);

    // const itemList =
    //     label === 'Client'
    //         ? (clientss.length > 0 ? clientss : clients?.data || [])
    //         : label === 'Project'
    //             ? (projectss.length > 0 ? projectss : projects?.data || [])
    //             : label === 'Item'
    //                 ? (itemss.length > 0 ? itemss : projectItems?.data || [])
    //                 : [];
    const itemList =
        label === 'Client' ? (clientss.length > 0 ? clientss : [])
            : label === 'Project' ? (projectss.length > 0 ? projectss : []) : label === 'Item'
                ? (itemss.length > 0 ? itemss : []) : label === 'Expense'
                    ? (expensess.length > 0 ? expensess : []) : [];

    const groupAndSortItems = (items, sortDirection = 'asc') => {
        const grouped = items.reduce((acc, item) => {
            const name = item.name || item.project_name || item.merchant || '';
            const firstLetter = name.charAt(0).toUpperCase();

            if (!acc[firstLetter]) {
                acc[firstLetter] = [];
            }
            acc[firstLetter].push(item);
            return acc;
        }, {});

        const groupedArray = Object.entries(grouped);

        groupedArray.sort((a, b) => {
            const aName = (a[1][0].name || a[1][0].project_name || a[1][0].merchant || '').toLowerCase();
            const bName = (b[1][0].name || b[1][0].project_name || b[1][0].merchant || '').toLowerCase();

            return sortDirection === 'asc'
                ? aName.localeCompare(bName)
                : bName.localeCompare(aName);
        });

        return Object.fromEntries(groupedArray);
    };

    const groupAndSortExpenses = (items, sortDirection = 'asc') => {
        const groupedArray = [...items];

        groupedArray.sort((a, b) => {
            const aName = (a.catagory || '').toLowerCase();
            const bName = (b.catagory || '').toLowerCase();

            return sortDirection === 'asc'
                ? aName.localeCompare(bName)
                : bName.localeCompare(aName);
        });

        return groupedArray;
    };

    const groupedItems = label === 'Expense' ? groupAndSortExpenses(itemList, sortDirection) : groupAndSortItems(itemList, sortDirection);

    // Called when user clicks the edit icon
    const handleEditItem = (item) => {
        setAddClientForm(true);
        if (label === 'Project') {
            router.push("/project/edit/" + item?.id)
            // onEditProject(item);
        } else if (label === 'Client') {
            router.push("/client/edit/" + item?.id)
        } else if (label === 'Item') {
            onEditItem(item);
        } else if (label === 'Expense') {
            router.push("/expense/edit/" + item?.id)
        }

    };

    const handleDeleteItem = async (itemId) => {
        let deleteData = '';
        if (label === 'Client') {
            deleteData = await dispatch(deleteClient(itemId)).unwrap();
            dispatch(fetchClientData())
        } else if (label === 'Project') {
            deleteData = dispatch(deleteProject(itemId));
        } else if (label === 'Item') {
            deleteData = dispatch(deleteItem(itemId));
        } else if (label === 'Expense') {
            await dispatch(deleteExpense({ id: itemId })).unwrap();
            await dispatch(getExpenseData()).unwrap()
            router.push("/expense")
        }
        if (deleteData) {
            window.location.href = `/${label.toLowerCase()}`;
        }
    };

    if (label === 'Expense') {
        return (
            <div className='userlist-header'>
                {loading && <p>Loading...</p>}
                {Array.isArray(groupedItems) && groupedItems.length > 0 ? (
                    groupedItems.map(group => (
                        <div key={group.catagory} className="userlist-group">
                            <h6 className="userlist-group-letter" style={{ textAlign: 'left', margin: '8px 0' }}>
                                {group.catagory}
                                <span className='amount'>{formatCurrency(group.totalAmount, currencyList)}</span>
                            </h6>
                            <ul className={`userlist${group.expenses.length > 2 ? ' userListScroll' : ''}`}>
                                {group.expenses.map(item => (
                                    <li key={item.id} className={activeItemId === item.id ? 'active' : ''} onClick={() => setActiveItemId(item.id)}>
                                        <div className='userlist-left'>
                                            {item.profileImage ?
                                                <img src={item.profileImage ?? IMAGE.profile} alt="" />
                                                :
                                                <div className='userlist-no-image'>
                                                    {(item?.merchant?.charAt(0)?.toUpperCase() || 'U')}
                                                </div>
                                            }
                                            <div className='userlist-left-content'>
                                                {item.merchant && <h6 style={{ color: 'rgba(4, 127, 255, 1)' }}>{item.merchant}</h6>}
                                                <span>{item?.description || ''}</span>
                                            </div>
                                        </div>
                                        <div className='invoice-right'>
                                            <div className='invoice-right'>
                                                <p className="invoice-price">{formatCurrency(item.rate, currencyList)}</p>
                                            </div>
                                            <div className='group-icon'>
                                                <Link href="#" onClick={(e) => { e.preventDefault(); handleEditItem(item); }}>
                                                    <FontAwesomeIcon icon={faPenToSquare} />
                                                </Link>
                                                <Link href="#" onClick={() => handleDeleteItem(item.id)}>
                                                    <FontAwesomeIcon icon={faTrashCan} />
                                                </Link>
                                            </div>
                                        </div>
                                    </li>
                                ))}
                            </ul>
                        </div>
                    ))
                ) : (
                    !loading && <p>No {label.toLowerCase()}s available.</p>
                )}
            </div>
        );
    }



    return (
        <div className='userlist-header'>
            {loading && <p>Loading...</p>}
            {Object.keys(groupedItems).map(letter => (
                <div key={letter} className="userlist-group">
                    <h6 className="userlist " style={{ textAlign: 'left', margin: '8px 0' }}>{letter}</h6>
                    <ul className={`userlist${groupedItems[letter].length > 2 ? ' userListScroll' : ''}`}>
                        {groupedItems[letter].map(item => (
                            <li key={item.id} className={activeItemId === item.id ? 'active' : ''} onClick={() => setActiveItemId(item.id)}>
                                <div className='userlist-left'>
                                    {item.profileImage ?
                                        <img src={item.profileImage ?? IMAGE.profile} alt="" />
                                        :
                                        <div className='userlist-no-image'>
                                            {getInitials(item?.name ? item?.name : item?.project_name)}
                                        </div>
                                    }
                                    <div className='userlist-left-content'>
                                        {item.name && <h6><Link href={`/client/${item.id}`}>{item.name}</Link></h6>}
                                        {item.project_name && <h6 className='text-primary'><Link href={`/project/${item.id}/${item.client_id}`}>{item.project_name}</Link></h6>}
                                        <span>{item.email ?? item.client?.name}</span>
                                    </div>
                                </div>
                                <div className='invoice-right'>
                                    <div className='group-icon'>
                                        <Link href="#" onClick={(e) => { e.preventDefault(); handleEditItem(item); }}>
                                            <FontAwesomeIcon icon={faPenToSquare} />
                                        </Link>
                                        {label === "Project" &&
                                            <Link href="#" onClick={() => handleDeleteItem({ client_id: item.client_id, projectId: item.id })}>
                                                <FontAwesomeIcon icon={faTrashCan} />
                                            </Link>}
                                        {label === "Client" &&
                                            <Link href="#" onClick={() => handleDeleteItem(item.id)}>
                                                <FontAwesomeIcon icon={faTrashCan} />
                                            </Link>}
                                    </div>
                                    {label === "Project" && (
                                        <div className="created-at-date" style={{ marginLeft: '2px', fontSize: '11px', color: '#888' }}>
                                            {item.createdAt && (
                                                new Date(item.createdAt).toLocaleDateString('en-GB', {
                                                    day: 'numeric',
                                                    month: 'short',
                                                    year: 'numeric'
                                                })
                                            )}
                                        </div>
                                    )}
                                </div>
                            </li>
                            )
                        )}
                    </ul>
                </div>
            ))}
            {itemList.length === 0 && !loading && <p>No {label.toLowerCase()}s available.</p>}
        </div>
    );
};

export default UserList;