import React,{ useState } from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { 
    faPenToSquare,
    faSquarePlus,
    faAngleDown
} from '@fortawesome/free-solid-svg-icons';
import Modal from 'react-bootstrap/Modal';
import './paymentdetails.css';

const PaymentDetails = ({activetabs}) => {

    const [gstModal, setGstModal] = useState(false);
    const [activeTab, setActiveTab] = useState("Inclusive");

    const gstTabs = ['Inclusive', 'Exclusive'];
    
    const handleClose = () => {
        setGstModal(false)
    }
    const handleActiveTab = (tab) => {
        setActiveTab(tab)
    }
  return (
    <>
        <div className='invoice-bill'>
            <h6>Invoice</h6>
            <div className='bill-no'>
                <p className='number'>#6</p>
                <FontAwesomeIcon icon={faPenToSquare} />
            </div>
            <p className='unsent'>Unsent</p>

            <div className="card">
                <div className="card-body bill-card">
                    <div className='bill-card-details'>
                        <p className='bill-left'>Date</p>
                        <p className="bill-right highlight">Dec 11,2024</p>
                    </div>

                    <div className='bill-card-details'>
                        <p className='bill-left'>Terms</p>
                        <p className="bill-right highlight">Same day <FontAwesomeIcon style={{color:"#047FFF"}} icon={faAngleDown} /></p>
                    </div>

                    <div className='bill-card-details'>
                        <p className='bill-left'>Due-Date</p>
                        <p className="bill-right highlight">Dec20, 2024s</p>
                    </div>
                    <hr className='payment-divider'/>
                    <div className='bill-card-details'>
                        <p className='bill-left'>Sub Total</p>
                        <p className="bill-right">$0.00</p>
                    </div>
                    <div className='bill-card-details'>
                        <p className='bill-left'>Discount</p>
                        <p className="bill-right highlight">$0.00</p>
                    </div>
                    <hr className='payment-divider'/>
                    <div className='bill-card-details'>
                        <p className='gst'>GST</p>
                        <p className="edit" onClick={() => setGstModal(true)}>Edit <FontAwesomeIcon icon={faPenToSquare} /></p>
                    </div>
                    <div className='bill-card-details'>
                        <p className='bill-left'>Discount</p>
                        <p className="bill-right highlight">$0.00</p>
                    </div>
                    <hr className='payment-divider'/>
                    <div className='bill-card-details'>
                        <p className='bill-left'>Total</p>
                        <p className="bill-right">$0.00</p>
                    </div>
                    <div className='bill-card-details'>
                        <p className='bill-left'>Paid</p>
                        <p className="bill-right">$0.00</p>
                    </div>
                    <div className='bill-card-details'>
                        <p className='bill-left'>Balance</p>
                        <p className="bill-right">$0.00</p>
                    </div>
                </div>
            </div>

            <button className='add-note'><FontAwesomeIcon icon={faSquarePlus} /> Add deposit request</button>
            {/* {activetabs !== "Create" ? (
                <>
                    <div className='payment-btns'>

                        <Link href={{}}>Send Invoice</Link>
                        <Link href={{}}>Download Slip</Link>
                    </div>
                    <div className="card payment-card mt-3">
                        <div className="card-body">
                            <h6>Payment Methods</h6>
                            <div className='paypal'>
                                <img src={IMAGE.paypal}/>
                                <p>Paypal <FontAwesomeIcon icon={faCircleInfo} /></p>
                            </div>
                            <div>
                                <input type="checkbox" id="vehicle1" name="vehicle1" value="Bike" />
                                <label> Send payment reminders</label>
                                <Link href={{}}>view</Link>
                            </div>

                            <h6>Recurring Invoice</h6>
                            <div>
                                <p>Due-Date</p>
                                <select name="date" id="date">
                                    <option value="Off">Off</option>
                                    <option value="On">On</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </>
            ): <></>} */}
        </div>

        <Modal show={gstModal} onHide={handleClose}>
            <Modal.Header closeButton>
                <Modal.Title>
                    <h4 className='title-modal'>Edit GST</h4>
                </Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <div className='gst-modal'>
                    <p>Changes to this tax will be applied to all items it’s currently assigned to.</p>
                    <hr className="payment-divider"/>
                    <h4>Tax Calculation</h4>
                    <div className="tab-heading">
                        {gstTabs.map(tabs => (
                            <span
                                key={tabs}
                                className={`tag ${activeTab === tabs ? "active" : ""}`}
                                onClick={() => handleActiveTab(tabs)}
                            >
                                {tabs}
                            </span>
                        ))}
                    </div>
                    <p>Tax is calculated as part of the total amount (inclusive) or in addition to it (exclusive).</p>
                    <hr className="payment-divider"/>
                </div>
                <div className='rate-chart'>
                    <h6>Tax Rates</h6>
                    <div className='gst-values'>
                        <p>Rate1</p>
                        <p>18%</p>
                    </div>

                    <div className='gst-values'>
                        <p>Rate1</p>
                        <p>18%</p>
                    </div>

                    <div className='gst-values'>
                        <p>Rate1</p>
                        <p>18%</p>
                    </div>

                    <div className='gst-values'>
                        <p>Rate1</p>
                        <p>18%</p>
                    </div>
                </div>
                <div className='btn-grp'>
                    <button className='add-rate'><FontAwesomeIcon icon={faSquarePlus} /> Add new rate</button>
                    <button className='modal-btn'>Save</button>
                </div>
                
            </Modal.Body>
        </Modal>
    </>

  )
}

export default PaymentDetails
