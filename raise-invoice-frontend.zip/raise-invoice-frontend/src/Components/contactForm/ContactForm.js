'use client'
import React, { useState, useEffect } from 'react';
import './contactForm.css'
import { Form, Toast } from "react-bootstrap";
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { useForm } from 'react-hook-form';
import Select from 'react-select';
import Api from "../../api/api";
import Link from "next/link";

const ContactForm = () => {
  const [countries, setCountries] = useState([]);
  const [show, setShow] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  var [state, setState] = useState({
    name: '',
    email: '',
    message: '',
    companyName: '',
    countryId: null,
    userId: null
  });
  var { name, email, message, companyName, countryId, userId } = state;
  const handleChange = (event) => {
    const { name, value } = event.target;
    setState(prevState => ({
      ...prevState,
      [name]: value,
    }));
    trigger(name);
  };
  var validationSchema = Yup.object().shape({
    name: Yup.string()
      .required('Name is required'),
    email: Yup.string()
      .required('Email is required'),
    message: Yup.string()
      .required('Message is required'),
  });
  var formOptions = { defaultValues: state, resolver: yupResolver(validationSchema), };
  var { register, handleSubmit, reset, formState: { errors }, clearErrors, trigger } = useForm(formOptions);

  const submitForm = () => {
    clearErrors()
    reset(state)
  }
  const onSubmit = async (formData) => {
    // setShow(true);
    try {
      const response = await Api.POST('submit-enquiry', formData)
      if (response.status === 200) {
        resetForm();
        setSuccessMessage(response.data.message);
        setShow(true);
      }
    } catch (error) {
      setSuccessMessage(error?.response?.data?.message);
      setShow(true);
    }
  };
  const resetForm = () => {
    clearErrors();
    setState(prevState => ({
      ...prevState,
      name: '',
      email: '',
      message: '',
      companyName: '',
      countryId: null,
      userId: null
    }));
  }

  const getCountryList = async () => {
    try {
      const response = await Api.GET('get-country-list');
      setCountries(response?.data?.data);
    } catch (error) {
      console.log('error', error);
    }
  };
  const changeCountry = (data) => {
    setState(prevState => ({
      ...prevState,
      countryId: data?.value,
    }))
  };

  useEffect(() => {
    getCountryList()
  }, [])

  return (
    <>
      <Toast
        onClose={() => setShow(false)}
        show={show}
        delay={5000}
        autohide
      >
        <Toast.Header>
          <strong className="me-auto">{successMessage}</strong>
        </Toast.Header>
      </Toast>
      <Form onSubmit={handleSubmit(onSubmit)}>
        <div className="row">
          <div className="col-lg-6 mb-20">
            <Form.Control
              type="text"
              {...register('name', { onChange: handleChange })}
              value={name}
              className={`form-control mb-0 ${errors.name ? 'is-invalid' : (name ? 'is-valid' : '')}`}
              placeholder="Name"
              aria-label="Name"
            />
            <div className="invalid-feedback">{errors.name?.message?.toString()}</div>
          </div>
          <div className="col-lg-6 mb-20">
            <Form.Control
              type="email"
              {...register('email', { onChange: handleChange })}
              value={email}
              className={`form-control mb-0 ${errors.email ? 'is-invalid' : (email ? 'is-valid' : '')}`}
              placeholder="Email Address"
              aria-label="Email Address"
            />
            <div className="invalid-feedback">{errors.email?.message?.toString()}</div>
          </div>
          <div className="col-lg-6 mb-20">
            <Form.Control
              type="text"
              {...register('companyName', { onChange: handleChange })}
              value={companyName}
              className={`form-control mb-0 ${errors.companyName ? 'is-invalid' : (companyName ? 'is-valid' : '')}`}
              placeholder="Company"
              aria-label="Company"
            />
            <div className="invalid-feedback">{errors.companyName?.message?.toString()}</div>
          </div>
          {countries ?
            <div className="col-lg-6 mb-20">
              <Select
                instanceId="countryId"
                id="countryId"
                className={`${errors.countryId ? 'is-invalid' : (countryId ? 'is-valid' : '')}`}
                options={countries}
                value={countries.find(({ value }) => value === countryId)}
                onChange={changeCountry}
                placeholder="Select country"
                isClearable={true}
              />
              <div className="invalid-feedback">{errors.countryId?.message?.toString()}</div>
            </div>
            : ''}
          <div className='col-lg-12 mb-20'>
            <Form.Control
              as="textarea"
              {...register('message', { onChange: handleChange })}
              value={message}
              rows={8}
              placeholder="Type your message..."
              className={`form-control mb-0 ${errors.message ? 'is-invalid' : (message ? 'is-valid' : '')}`}
            />
            <div className="invalid-feedback">{errors.message?.message?.toString()}</div>
          </div>
        </div>
        <div className='mb-5'>
          <p>By submitting this form you agree to our <Link href="/terms-and-conditions">Terms and Conditions</Link> and our <Link href="/privacy-policy">Privacy Policy</Link> which explains
            how we may collect, use and disclose your personal information including to third parties.
          </p>
          <div className='contact-btn'>
            <button type="submit" onClick={submitForm}>
              Contact Us
            </button>
          </div>
        </div>
      </Form>
    </>
  )
}

export default ContactForm