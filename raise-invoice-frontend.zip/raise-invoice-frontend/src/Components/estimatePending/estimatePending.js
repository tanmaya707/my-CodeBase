
"use client";
import React, { useState, useRef, useEffect } from "react";
import Pageheader from "@/utils/pageheader";
import Accordion from "react-bootstrap/Accordion";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import Modal from "react-bootstrap/Modal";
import { useRouter, useSearchParams } from "next/navigation";
import { useDispatch } from "react-redux";
import html2pdf from 'html2pdf.js';
import {
    fetchClientData, deatilsClientData, fetchItemData,
    fetchTaxData, createEstimateData, updateEstimateData, fetchNextEstimateNumber,
    sendMail,
    getCustomInvoiceOptionData, getCustomInvoiceData, getInvoiceSignature, fetchMasterData

} from "@/redux/slices/dataSlice";
import {
    faEnvelope,
    faPhone,
    faLocationDot,
    faCircleXmark,
    faSquarePlus,
    faTrash,
    faArrowLeft,
    faFilePdf,
    faPenToSquare,
    faFileImage,
} from "@fortawesome/free-solid-svg-icons";
import "./estimatepend.css";
import { IMAGE } from "@/utils/Theme";
import Button from "react-bootstrap/Button";
import "../../app/general.css";
import '../../app/(privateroutes)/addInvoice/addInvoice.css';
import '../../app/(privateroutes)/addInvoice/invoice.css';
import '../../Components/addItemForm/addItemForm.css';

// PDF generation and download helpers
import jsPDF from "jspdf";
import html2canvas from "html2canvas";
import DatePicker from 'react-datepicker';
import "react-datepicker/dist/react-datepicker.css";
import { differenceInMinutes, format } from 'date-fns';
// import { saveTimeAPI } from '@/redux/slices/projectSlice';
// import DndKitList from '@/Components/dragDropList';
import { formatCurrency } from '@/dependencies/utils/helper';
import { toast } from 'react-toastify';
import CustomInvoiceImpact from "@/Components/templates/impact";
import ToggleButton from "@/utils/ToggleButton/toggleButton";
import Link from "next/link";
import { useModal } from "@/cotexts/modalContext";
import DndKitList from "../dragDropList";
import { useRouteLeaveConfirmation } from "@/hooks/useRouteLeaveConfirmation";


const DiscountModal = ({
    isOpen,
    onClose,
    discountType,
    discountInputValue,
    setDiscountType,
    setDiscountInputValue,
    onSave,
}) => {
    // const searchParams = useSearchParams();


    // When modal opens, set input value to previous saved value
    useEffect(() => {
        if (isOpen) {
            setDiscountInputValue(discountInputValue || "");
        }
        // eslint-disable-next-line
    }, [isOpen]);

    if (!isOpen) return null;
    return (
        <Modal show={isOpen} onHide={onClose} centered>
            <Modal.Header closeButton>
                <Modal.Title>Edit discount</Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <p className="text-sm text-gray-600 mb-4">
                    The discount will be applied to the subtotal. This does not include discounts added to specific items.
                </p>
                <div className="flex items-center mb-4">
                    <input
                        type="number"
                        value={discountInputValue}
                        min="0"
                        onChange={(e) => {
                            let v = e.target.value.replace(/[^0-9.]/g, "");
                            setDiscountInputValue(v);
                        }}
                        className="border rounded-l px-4 py-2 w-full"
                    />
                    <button
                        onClick={() => setDiscountType("%")}
                        className={`px-4 py-2 border ${discountType === "%" ? "bg-primary text-white" : "bg-light"}`}
                    >
                        %
                    </button>
                    <button
                        onClick={() => setDiscountType("$")}
                        className={`px-4 py-2 border rounded-r ${discountType === "$" ? "bg-primary text-white" : "bg-light"}`}
                    >
                        $
                    </button>
                </div>
            </Modal.Body>
            <Modal.Footer>
                <Button variant="outline-primary" onClick={onClose}>Cancel</Button>
                <Button
                    variant="primary"
                    onClick={onSave}
                >
                    Save
                </Button>
            </Modal.Footer>
        </Modal>
    );
};
const TERMS_OPTIONS = [
    { value: "", label: "None", days: 0 },
    { value: "1", label: "Custom", days: 0 },
    { value: "2", label: "Next Day", days: 1 },
    { value: "3", label: "2 Days", days: 2 },
    { value: "4", label: "3 Days", days: 3 },
    { value: "5", label: "4 Days", days: 4 },
    { value: "6", label: "5 Days", days: 5 },
    { value: "7", label: "10 Days", days: 10 },
    { value: "8", label: "30 Days", days: 30 },
    { value: "9", label: "90 Days", days: 90 },
    { value: "10", label: "180 Days", days: 180 },
    { value: "11", label: "365 Days", days: 365 },
];

const EstimatePending = (est) => {
    const [isSticky, setIsSticky] = useState(false);
    const TABS = [est?.type, 'Preview', 'Send'];
    const searchParams = useSearchParams();
    const sendText = searchParams.get('send');
    const { parameter } = useModal();
    const [activeTab, setActiveTab] = useState(est?.type === "Edit" ? sendText ? 'Send' : 'Preview' : 'Create');

    const estimateToEdit = est.estimateToEdit || null

    const [loading, setLoading] = useState(false);
    const [showClientModal, setShowClientModal] = useState(false);
    const [clientList, setClientList] = useState([]);
    const [clientDropdown, setClientDropdown] = useState([]);
    const [showClientDropdown, setShowClientDropdown] = useState(false);
    const [selectedClient, setSelectedClient] = useState(null);
    const [sentStatus, setSentStatus] = useState("unsent");
    const [clientForm, setClientForm] = useState({
        id: null,
        name: "",
        email: "",
        phone: "",
        address: "",
    });
    const [clientFormErrors, setClientFormErrors] = useState({
        name: "",
        email: "",
        phone: "",
        address: "",
    });

    const [unitTypes, setUnitTypes] = useState([]);
    const [currencyList, setCurrencyList] = useState([]);

    // Items
    const [items, setItems] = useState([]);
    const [showItemModal, setShowItemModal] = useState(false);
    const [editItemIndex, setEditItemIndex] = useState(null);
    const [customTemplates, setCustomTemplates] = useState(null);
    const [itemForm, setItemForm] = useState({
        id: null,
        code: '',
        name: '',
        description: '',
        rate: '',
        quantity: '',
        unitTypes: '',
        gstChecked: false,
        gstValue: '',
        discountChecked: false,
        discountType: 'flat',
        discountValue: '',
    });
    const [itemFormErrors, setItemFormErrors] = useState({
        name: "",
        rate: "",
        quantity: "",
    });

    const [optionData, setOptionData] = useState({
        id: null,
        shippingDetails: false,
        due_date: false,
        payment_terms: false,
        itemCode: false,
        quantityAndRate: false,
        pTax: false,
        tax_amounts: false,
        includeSignatureLine: false,
        invoicePrifix: "",
    });

    const [gstModal, setGstModal] = useState(false);
    const [taxRates, setTaxRates] = useState([]);

    // Discount
    const [discountModalOpen, setDiscountModalOpen] = useState(false);
    const [discountType, setDiscountType] = useState("%");
    const [discountInputValue, setDiscountInputValue] = useState(""); // What user types in modal
    const [discountValue, setDiscountValue] = useState("0"); // Raw value from DB, string
    const [discountAmount, setDiscountAmount] = useState(0); // Always amount, for Bill Cost

    // Payment Instruction & Notes
    const [showPaymentInstructionInput, setShowPaymentInstructionInput] = useState(false);
    const [paymentInstruction, setPaymentInstruction] = useState("");
    const [showCommentInput, setShowCommentInput] = useState(false);
    const [comment, setComment] = useState("");

    // Discount
    const [invoiceDiscount, setInvoiceDiscount] = useState('');
    const [invoiceDiscountEditable, setInvoiceDiscountEditable] = useState(true);
    const [showDiscountInput, setShowDiscountInput] = useState(false);

    const [invoiceGstRate, setInvoiceGstRate] = useState(null);
    const [invoiceGstType, setInvoiceGstType] = useState("Exclusive");


    // Choose Item Modal
    const [showChooseItemModal, setShowChooseItemModal] = useState(false);
    const [chooseItemList, setChooseItemList] = useState([]);
    const [chooseSelectedItems, setChooseSelectedItems] = useState([]);
    const [itemSearch, setItemSearch] = useState("");

    // Attachments & Logo
    const [attachments, setAttachments] = useState([]);
    const fileInputRef = useRef();
    const [logo, setLogo] = useState("");
    const logoInputRef = useRef();

    // console.log(estimateToEdit, "estimateToEdit", est.estimateNumber)

    // Invoice fields
    const [invoiceNumber, setInvoiceNumber] = useState('');
    const [invoiceDate, setInvoiceDate] = useState("");
    const [note, setNote] = useState("");

    // console.log(invoiceNumber, "invoiceNumber in estimate pending");


    // Invoice number
    const [editInvoiceNumber, setEditInvoiceNumber] = useState(false);
    const [invoiceNumberInput, setInvoiceNumberInput] = useState('');


    const dispatch = useDispatch();
    const router = useRouter();
    const estimateId = searchParams.get("id");
    const [formData, setFormData] = useState({
        id: null,
        templateName: "impact",
        logoId: "",
        logoImage: "",
        logoSize: "medium",
        logoPosition: "center",
        colourId: "",
        colourCode: "",
        customColour: "",
        headerId: "",
        headerImg: "",
        waterMarkId: "",
        waterMarkImg: "",
    });
    //Email state
    const [sendToEmails, setSendToEmails] = useState(selectedClient?.email ? [selectedClient.email] : []);
    const [sendCcEmails, setSendCcEmails] = useState([]);
    const [sendBccEmails, setSendBccEmails] = useState([]);
    const [showCc, setShowCc] = useState(false);
    const [showBcc, setShowBcc] = useState(false);
    const [sendToInput, setSendToInput] = useState('');
    const [sendCcInput, setSendCcInput] = useState('');
    const [sendBccInput, setSendBccInput] = useState('');
    const [sendNotes, setSendNotes] = useState('');

    const [value, setValue] = useState(false);
    const [value2, setValue2] = useState(false);

    const DISCOUNT_TYPE_OPTIONS = [
        { value: "flat", label: "Flat" },
        { value: "percentage", label: "Percentage" }
    ];

    const [unsaved, setUnsaved] = useState(false);
    const [modalType, setModalType] = useState('reload');
    const [showModal, setShowModal] = useState(false);

    // --- Unsaved Changes Protection ---
    useRouteLeaveConfirmation(unsaved, 'You have unsaved changes. Leave anyway?');
    useEffect(() => {
        if (!estimateToEdit) {
            const hasUnsavedChanges =
                clientForm.name ||
                clientForm.email ||
                clientForm.phone ||
                clientForm.address ||
                items.length > 0 ||
                invoiceDiscount ||
                paymentInstruction ||
                comment;
            setUnsaved(hasUnsavedChanges);
        } else {
            setUnsaved(false);
        }
    }, [clientForm, items, invoiceDiscount, paymentInstruction, comment, estimateToEdit]);

    // useEffect(() => {
    //     const handleBeforeUnload = (e) => {
    //         if (!estimateToEdit && unsaved) {
    //             e.preventDefault();
    //             e.returnValue = '';
    //             setModalType('close');
    //             setShowModal(true);
    //             return '';
    //         }
    //     };
    //     window.addEventListener('beforeunload', handleBeforeUnload);
    //     return () => window.removeEventListener('beforeunload', handleBeforeUnload);
    // }, [unsaved, estimateToEdit]);

    // useEffect(() => {
    //     const handleKeyDown = (e) => {
    //         if (!estimateToEdit && unsaved && (e.key === 'F5' || (e.ctrlKey && e.key === 'r'))) {
    //             e.preventDefault();
    //             setModalType('reload');
    //             setShowModal(true);
    //         }
    //     };
    //     window.addEventListener('keydown', handleKeyDown);
    //     return () => window.removeEventListener('keydown', handleKeyDown);
    // }, [unsaved, estimateToEdit]);

    useEffect(() => {
        async function fetchData() {
            try {
                const data = await dispatch(fetchMasterData()).unwrap();
                setUnitTypes(data.productUnitTypes || []);
                setCurrencyList(data.currencyData || []);
            } catch (err) {
                console.error("Failed to fetch master data", err);
            }
        }
        fetchData();
    }, [dispatch]);

    const [sigEstimate, setEstimateInvoice] = useState(true);
    const [error, setError] = useState({});

    // Signature states
    const [signatureType, setSignatureType] = useState("pad");
    const [padSignature, setPadSignature] = useState("");
    const [uploadSignature, setUploadSignature] = useState("");
    const [signatureText, setSignatureText] = useState("");

    useEffect(() => {
        const fetchSignature = async () => {
            try {
                const result = await dispatch(getInvoiceSignature()).unwrap();
                if (result && result.data) {
                    const data = result.data;
                    setEstimateInvoice(data.estimate);
                    setSignatureType(data.signatureType || "pad");
                    setPadSignature(data.signature || "");
                    setUploadSignature(data.signatureData || "");
                    setSignatureText(data.signatureText || "");
                }
            } catch (err) {
                // No existing signature, keep defaults
            }
        };
        fetchSignature();
    }, [dispatch]);


    // Prefill logic for edit mode
    useEffect(() => {
        // console.log(estimateToEdit, "estimateToEdit in useEffect");
        if (estimateToEdit !== null) {
            // Prefill client
            if (estimateToEdit?.client) {
                setSelectedClient(estimateToEdit.client);
                setClientForm({
                    id: estimateToEdit.client.id || null,
                    name: estimateToEdit.client.name || "",
                    email: estimateToEdit.client.email || "",
                    phone: estimateToEdit.client.phone || "",
                    address: estimateToEdit.client.address || "",
                });
            }
            else if (estimateToEdit?.clientId) {
                // console.log("estimateToEdit in useEffect ::: ", estimateToEdit.clientId);
                dispatch(deatilsClientData(estimateToEdit.clientId)).then(result => {
                    const data = result?.payload;
                    const profileImage = process.env.NEXT_PUBLIC_API_URL + 'uploads/' + (data.profileImage || '');
                    if (data) {
                        setSelectedClient({ ...data , profileImage } || null);
                        setClientForm({
                            id: data.id || null,
                            name: data.name || '',
                            email: data.email || '',
                            phone: data.phone || '',
                            address: data.address || ''
                        });
                    }
                });
            }
            // Prefill items
            if (Array.isArray(estimateToEdit?.items)) {
                setItems(estimateToEdit.items.map((item, idx) => ({
                    id: item.id || null,
                    drag_id: `${items?.length + idx}`,
                    code: item.code || '',
                    name: item.name || '',
                    description: item.description || '',
                    rate: item.rate || '',
                    quantity: item.quantity || '',
                    unitTypes: item.unitTypes || '',
                    gstChecked: item.gstChecked || false,
                    gstValue: item.gstValue || '',
                    discountChecked: item.discountChecked || false,
                    discountType: item.discountType || 'flat',
                    discountValue: item.discountValue || '',
                })));
            }
            // Prefill discount
            if (estimateToEdit?.discount) {
                setDiscountType(estimateToEdit?.discount.type || "%");
                setDiscountAmount(estimateToEdit?.discount.amount || 0);
                setInvoiceDiscount(estimateToEdit?.discount.amount?.toString() || "0");
                setDiscountValue(estimateToEdit?.discount.value?.toString() || "0");
            }
            // Prefill payment instruction & note
            setPaymentInstruction(estimateToEdit?.paymentInstruction || "");
            setComment(estimateToEdit?.note || "");
            setShowPaymentInstructionInput(!!estimateToEdit?.paymentInstruction);
            setShowCommentInput(!!estimateToEdit?.note);
            // Prefill logo
            setLogo(estimateToEdit?.logo || "");
            setAttachments(estimateToEdit?.attachments || []);
            // Prefill invoice fields
            setInvoiceDate(estimateToEdit?.date || "");
            // setInvoiceNumber(estimateToEdit?.invoiceNumber || "");
        }
        dispatch(getCustomInvoiceOptionData()).then((res) => {
            const data = res?.payload?.data;
            if (data) {
                setOptionData({
                    id: data.id || null,
                    shippingDetails: !!data.shippingDetails,
                    due_date: !!data.due_date,
                    payment_terms: !!data.payment_terms,
                    itemCode: !!data.itemCode,
                    quantityAndRate: !!data.quantityAndRate,
                    pTax: !!data.pTax,
                    tax_amounts: !!data.tax_amounts,
                    includeSignatureLine: !!data.includeSignatureLine,
                    invoicePrifix: data.invoicePrifix || "",
                });
            }
        });
    }, [estimateToEdit, dispatch]);

    useEffect(() => {
        if (items?.some(item => (item?.discountChecked == 'true' || item?.discountChecked == true))) {
            setInvoiceDiscountEditable(false);
        } else {
            setInvoiceDiscountEditable(true);
        }
    }, [items]);

    useEffect(() => {
        if (estimateToEdit) return;
        dispatch(getCustomInvoiceData()).then((res) => {
            const data = res?.payload?.data;
            if (data) {
                setFormData({
                    id: data.id || null,
                    templateName: data.templateName || "impact",
                    logoId: data.logoDetails?.id || "",
                    logoImage: data.logoDetails?.logoImage || "",
                    logoSize: data.logoSize || "medium",
                    logoPosition: data.logoPosition || "center",
                    colourId: data.colourDetails?.id || "",
                    colourCode: data.colourDetails?.colourCode || "",
                    customColour: data.colourDetails?.customColour || "",
                    headerId: data.headerDetails?.id || "",
                    headerImg: data.headerDetails?.headerImg || "",
                    waterMarkId: data.waterMarkDetails?.id || "",
                    waterMarkImg: data.waterMarkDetails?.waterMarkImg || "",
                });
                setCustomTemplates(res?.payload);
            }
        });
        dispatch(getCustomInvoiceOptionData()).then((res) => {
            const data = res?.payload?.data;
            if (data) {
                setOptionData({
                    id: data.id || null,
                    shippingDetails: !!data.shippingDetails,
                    due_date: !!data.due_date,
                    payment_terms: !!data.payment_terms,
                    itemCode: !!data.itemCode,
                    quantityAndRate: !!data.quantityAndRate,
                    pTax: !!data.pTax,
                    tax_amounts: !!data.tax_amounts,
                    includeSignatureLine: !!data.includeSignatureLine,
                    invoicePrifix: data.invoicePrifix || "",
                });
            }
        });
        // eslint-disable-next-line
    }, [dispatch]);

    function formatDate(date) {
        if (!date) return '';
        const d = new Date(date);
        const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
        return `${months[d.getMonth()]} ${d.getDate()},${d.getFullYear()}`;
    }

    // function formatCurrency(val) {
    //     const abs = Math.abs(val).toFixed(2);
    //     return val < 0 ? `-$${abs}` : `$${abs}`;
    // }

    const clientId = searchParams.get('cId');
    const invoiceId = searchParams.get('id');
    const [isFocused, setFocused] = useState(false);

    const handleBackClick = () => {
        setShowChooseItemModal(false);
        setShow(true);
    };

    // let TABS;
    // if(invoiceId){
    //     TABS = ['Edit', 'Preview', 'Send'];
    // }else{
    //     TABS = ['Create', 'Preview', 'Send'];
    // }

    // Tabs
    // const [activeTab, setActiveTab] = useState(invoiceId ? 'Preview' : 'Create');
    const [gstTab, setGstTab] = useState('Exclusive'); // Default to Exclusive



    function handleTabChange(tab) {
        setActiveTab(tab);
        if (tab === "Send") {
            generatePreviewPdf();
        }
    }


    // State
    const [show, setShow] = useState(false);
    const [showCalendarStart, setShowCalendarStart] = useState(false);
    const [terms, setTerms] = useState("");
    const [dueDate, setDueDate] = useState(new Date());
    const [showDueDateCalendar, setShowDueDateCalendar] = useState(false);


    // Button state
    const [isUpdateMode, setIsUpdateMode] = useState(false);

    // Deposit Modal
    const [showDepositModal, setShowDepositModal] = useState(false);
    const [depositTab, setDepositTab] = useState('percent');
    const [depositPercentage, setDepositPercentage] = useState('');
    const [depositFixedAmount, setDepositFixedAmount] = useState('');
    const [depositDueDate, setDepositDueDate] = useState(format(new Date(), 'yyyy-MM-dd'));
    const [depositAddToFuture, setDepositAddToFuture] = useState(false);
    const [depositPaid, setDepositPaid] = useState(0);
    const [deposit, setDeposit] = useState(null);

    // Time Entry Modal
    const [showTimeEntryModal, setShowTimeEntryModal] = useState(false);
    const [timeEntryList, setTimeEntryList] = useState([]);
    const [timeEntrySelected, setTimeEntrySelected] = useState([]);
    const [timeEntrySearch, setTimeEntrySearch] = useState('');
    const [timeEntryFlatList, setTimeEntryFlatList] = useState([]);
    const [allTimeEntries, setAllTimeEntries] = useState([]);
    const [addMoreLog, setAddMoreLog] = useState({
        client_id: selectedClient?.id, start_time: new Date(), end_time: new Date(), notes: ""
    })
    const [addMoretime, setAddMoreTime] = useState(false)
    // PDF preview state for Send tab
    const [previewPdfFile, setPreviewPdfFile] = useState(null);

    // --- PDF Generation ---
    const previewRef = useRef();

    // async function generatePreviewPdf() {
    useEffect(() => {
        if (!previewRef.current) return;
        const element = previewRef.current;
        setPreviewPdfFile(element);
        // }
    }, [previewRef, activeTab])

    // Download PDF
    function handleDownloadPdf() {
        if (!previewPdfFile) return;

        const element = previewPdfFile;

        const options = {
            margin: 0,
            filename: `Estimate_${invoiceNumber || 'preview'}.pdf`,
            image: { type: 'png', quality: 1.0 },
            html2canvas: {
                scale: 3,
                useCORS: true,
                backgroundColor: '#ffffff',
            },
            jsPDF: { unit: 'pt', format: 'a4', orientation: 'portrait' },
        };

        html2pdf()
            .set(options)
            .from(element)
            .save()
            .catch((err) => {
                console.error('PDF generation failed:', err);
            });
    }

    // Send PDF via email
    async function handleSendPdf() {
        if (!previewPdfFile) return;
        if (sendToEmails.length === 0) {
            toast.error("Please enter recipient email address.");
            return;
        }
        const element = previewPdfFile;
        let htmlContent = "";
        if (element && element.outerHTML) {
            htmlContent = element.outerHTML;
        } else if (element && element.current && element.current.outerHTML) {
            htmlContent = element.current.outerHTML;
        }

        htmlContent = htmlContent.replace(/<img([^>]+)src=["']data:image\/[^"']+["']([^>]*)>/gi, '');

        const body = {
            to: sendToEmails,
            cc: sendCcEmails,
            bcc: sendBccEmails,
            invoiceNumber: invoiceNumber || 'Preview',
            name: 'Estimate',
            filename: 'Estimate.pdf',
            subject: `Estimate from RaiseInvoice #${invoiceNumber}`,
            notes: sendNotes,
            html: htmlContent,
            attachments: attachments
        };
        if (parameter?.attachmentName) {
            await fetchBlobAsBase64(parameter?.blobUrl).then((base64Data) => {
                body.content = base64Data.replace(/^data:application\/pdf;base64,/, '')
                body.filename = parameter?.attachmentName;
            });
        }

        let formData = new FormData();
        for (let [key, val] of Object.entries(body)) {
            // If value is array, append each value
            if (Array.isArray(val)) {
                val.forEach(v => formData.append(key, v));
            } else {
                formData.append(key, val);
            }
        }
        try {
            const result = await dispatch(sendMail(formData)).unwrap();
            if (result && result.status == true) {
                setSentStatus("sent");
                toast.success("Estimate sent successfully!");
            } else {
                toast.error("Failed to send estimate.");
            }
        } catch (err) {
            toast.error("Failed to send estimate.");
        }
    }

    // Add/Remove email chips
    function handleAddEmail(type, value) {
        const email = value.trim();
        if (!email) return;
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return;
        if (type === 'to') {
            if (!sendToEmails.includes(email)) setSendToEmails([...sendToEmails, email]);
            setSendToInput('');
        } else if (type === 'cc') {
            if (!sendCcEmails.includes(email)) setSendCcEmails([...sendCcEmails, email]);
            setSendCcInput('');
        } else if (type === 'bcc') {
            if (!sendBccEmails.includes(email)) setSendBccEmails([...sendBccEmails, email]);
            setSendBccInput('');
        }
    }
    function handleRemoveEmail(type, idx) {
        if (type === 'to') setSendToEmails(sendToEmails.filter((_, i) => i !== idx));
        if (type === 'cc') setSendCcEmails(sendCcEmails.filter((_, i) => i !== idx));
        if (type === 'bcc') setSendBccEmails(sendBccEmails.filter((_, i) => i !== idx));
    }
    function handleEmailInputKeyDown(e, type) {
        if (e.key === 'Enter' || e.key === ',' || e.key === 'Tab') {
            e.preventDefault();
            if (type === 'to') handleAddEmail('to', sendToInput);
            if (type === 'cc') handleAddEmail('cc', sendCcInput);
            if (type === 'bcc') handleAddEmail('bcc', sendBccInput);
        }
    }

    // Update sendToEmails when selectedClient changes
    useEffect(() => {
        if (selectedClient?.email) setSendToEmails([selectedClient.email]);
    }, [selectedClient]);

    useEffect(() => {
        setTimeEntryFlatList(
            allTimeEntries.filter(
                entry => !items.some(i => i.isTimeEntry && (
                    (i.timeEntryTaskId && i.timeEntryTaskId === entry.task_id) ||
                    (!i.timeEntryTaskId && entry.task_id === null && i._originalTimeEntry && i._originalTimeEntry.logs && entry.logs && i._originalTimeEntry.logs[0]?.id === entry.logs[0]?.id)
                ))
            )
        );
    }, [allTimeEntries, items]);


    // Subtotal, GST, Discount, Total calculations
    const hasItemLevelGst = items.some(item => item.gstChecked == 'true' || item.gstChecked == true);

    function getItemBaseAndGst(item) {
        const itemTotal = parseFloat(item.rate || 0) * parseFloat(item.quantity || 0);

        // Calculate discount first
        let discountedTotal = itemTotal;
        if (item.discountChecked == 'true' || item.discountChecked == true) {
            if (item.discountType === "percentage") {
                discountedTotal = itemTotal - (itemTotal * (parseFloat(item.discountValue || 0) / 100));
            } else {
                discountedTotal = itemTotal - parseFloat(item.discountValue || 0);
            }
        }

        // Then calculate GST
        if (item.gstChecked == 'true' || item.gstChecked == true && item.gstValue) {
            const gstPerc = parseFloat(item.gstValue || 0);
            if (invoiceGstType === "Inclusive") {
                const base = discountedTotal / (1 + gstPerc / 100);
                const gst = discountedTotal - base;
                return { base, total: discountedTotal, gst };
            } else {
                const gst = discountedTotal * (gstPerc / 100);
                return { base: discountedTotal, gst, total: discountedTotal + gst };
            }
        } else {
            return { base: discountedTotal, gst: 0, total: discountedTotal };
        }
    }

    function getInvoiceGst(baseTotal) {
        if (!invoiceGstRate || !invoiceGstRate.percentage) return { base: baseTotal, gst: 0, total: baseTotal };
        const gstPerc = parseFloat(invoiceGstRate.percentage);
        if (invoiceGstType === "Inclusive") {
            const base = baseTotal / (1 + gstPerc / 100);
            const gst = baseTotal - base;
            return { base, gst, total: baseTotal };
        } else {
            const gst = baseTotal * (gstPerc / 100);
            return { base: baseTotal, gst, total: baseTotal + gst };
        }
    }

    let subtotal = 0, gstTotal = 0, discountTotal = 0, total = 0;

    if (hasItemLevelGst) {
        // Calculate item-level GST
        subtotal = items.reduce((sum, item) => {
            const { base } = getItemBaseAndGst(item);
            return sum + base;
        }, 0);

        gstTotal = items.reduce((sum, item) => {
            const { gst } = getItemBaseAndGst(item);
            return sum + gst;
        }, 0);

        discountTotal = 0;
        if (invoiceDiscountEditable || estimateToEdit != null) {
            discountTotal = parseFloat(invoiceDiscount || 0);
        }

        total = subtotal + gstTotal - discountTotal;
    } else {
        // Calculate invoice-level GST
        subtotal = items.reduce((sum, item) => {
            const itemTotal = parseFloat(item.rate || 0) * parseFloat(item.quantity || 0);

            // Apply item-level discount if any
            if (item.discountChecked == 'true' || item.discountChecked == true) {
                if (item.discountType === "percentage") {
                    return sum + (itemTotal - (itemTotal * (parseFloat(item.discountValue || 0) / 100)));
                } else {
                    return sum + (itemTotal - parseFloat(item.discountValue || 0));
                }
            }

            return sum + itemTotal;
        }, 0);
        if (invoiceDiscountEditable || estimateToEdit != null) {
            discountTotal = parseFloat(invoiceDiscount || 0);
        } else {

            discountTotal = items.reduce((sum, item) => {
                const itemTotal = parseFloat(item.rate || 0) * parseFloat(item.quantity || 0);
                if (item.discountChecked == 'false' || item.discountChecked == false) return sum;
                if (item.discountType === "percentage") {
                    return sum + (itemTotal * (parseFloat(item.discountValue || 0) / 100));
                } else {
                    return sum + parseFloat(item.discountValue || 0);
                }
            }, 0);
        }

        const gstResult = getInvoiceGst(subtotal);
        gstTotal = gstResult.gst;
        total = gstResult.total - discountTotal;
    }


    // Handlers
    const handleBack = () => router.push('/estimate');

    // Client Modal
    const handleShowClientModal = async () => {
        setShowClientModal(true);
        const result = await dispatch(fetchClientData());
        if (result && result.payload && result.payload.data) {
            setClientList(result.payload.data);
            setClientDropdown(result.payload.data);
            setShowClientDropdown(true);
        }
        setClientForm({ id: null, name: '', email: '', phone: '', address: '' });
        setClientFormErrors({ name: '', email: '', phone: '' });
    };
    const handleCloseClientModal = () => {
        setShowClientModal(false);
        setShowClientDropdown(false);
        setClientDropdown([]);
        setClientForm({ id: null, name: '', email: '', phone: '', address: '' });
        setClientFormErrors({ name: '', email: '', phone: '' });
    };
    const handleClearClient = () => {
        setSelectedClient(null);
        setClientForm({ id: null, name: '', email: '', phone: '', address: '' });
        setClientFormErrors({ name: '', email: '', phone: '' });
    };

    const validateClientForm = (field, value) => {
        let error = "";
        if (field === "name") {
            if (!value.trim()) error = "Name is required";
        }
        if (field === "email") {
            if (!value.trim()) error = "Email is required";
            else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) error = "Invalid email";
        }
        if (field === "phone") {
            if (!value.trim()) error = "Phone is required";
            else if (!/^\d{10}$/.test(value.replace(/\D/g, ""))) error = "Phone must be 10 digits";
        }
        return error;
    };

    const validateItemForm = (field, value) => {
        let error = "";
        const val = (value === undefined || value === null) ? "" : String(value);
        if (field === "name") {
            if (!val.trim()) error = "Name is required";
        }
        if (field === "rate") {
            if (!val.trim()) error = "Rate is required";
            else if (isNaN(val) || parseFloat(val) <= 0) error = "Rate must be positive";
        }
        if (field === "quantity") {
            if (!val.trim()) error = "Qty is required";
            else if (!/^\d+$/.test(val) || parseInt(val) < 1) error = "Qty must be at least 1";
        }
        return error;
    };

    const handleClientFormChange = (e) => {
        const { name, value } = e.target;
        let v = value;
        if (name === "phone") {
            v = v.replace(/\D/g, "").slice(0, 10);
        }
        setClientForm((prev) => ({
            ...prev,
            [name]: v,
        }));
        setClientFormErrors((prev) => ({
            ...prev,
            [name]: validateClientForm(name, v),
        }));
        if (name === "name") {
            if (v.trim().length > 0) {
                const filtered = clientList.filter((client) =>
                    client.name?.toLowerCase().includes(v.toLowerCase())
                );
                setClientDropdown(filtered);
                setShowClientDropdown(true);
            } else {
                setShowClientDropdown(true);
                setClientDropdown(clientList);
            }
        }
    };

    const handleClientDropdownSelect = (client) => {
        setClientForm({
            id: client.id || null,
            name: client.name || '',
            email: client.email || '',
            phone: client.phone || '',
            address: client.address || ''
        });
        setShowClientDropdown(false);
        setClientDropdown([]);
        setClientFormErrors({ name: '', email: '', phone: '' });
    };

    const handleAddClientFromModal = async (e) => {
        const errors = {
            name: validateClientForm('name', clientForm.name),
            email: validateClientForm('email', clientForm.email),
            phone: validateClientForm('phone', clientForm.phone)
        };
        setClientFormErrors(errors);
        if (errors.name || errors.email || errors.phone) return;

        const match = clientList.find(
            c => c.name?.toLowerCase() === clientForm.name.trim().toLowerCase()
        );
        if (match) {
            setSelectedClient(match);
            setShowClientModal(false);
            return;
        }
        if (clientForm) {
            setSelectedClient(clientForm);
            setShowClientModal(false);
            setClientList(prev => [...prev, clientForm]);
            setClientForm({
                id: clientForm.id || null,
                name: clientForm.name || '',
                email: clientForm.email || '',
                phone: clientForm.phone || '',
                address: clientForm.address || ''
            });
            setClientFormErrors({ name: '', email: '', phone: '' });
        }
    };

    const handleShow = () => {
        setShow(true);
        setEditItemIndex(null);
        setItemFormErrors({ name: "", rate: "", quantity: "" });
        setItemForm({
            id: null,
            code: '',
            name: '',
            description: '',
            rate: '',
            quantity: '',
            gstChecked: false,
            gstValue: '',
            discountChecked: false,
            discountType: 'flat',
            discountValue: '',
            isAppointment: false,
            appointmentId: null
        });
    };
    const handleClose = () => setShow(false);

    const handleItemFormChange = (e) => {
        const { name, value, type, checked } = e.target;
        setItemForm(prev => ({
            ...prev,
            [name]: type === "checkbox" ? checked : value
        }));
        let v = value;
        if (name === "quantity") {
            v = v.replace(/\D/g, "").slice(0, 10);
        }
        setItemForm((prev) => ({
            ...prev,
            [name]: v,
        }));
        setItemFormErrors((prev) => ({
            ...prev,
            [name]: validateItemForm(name, v),
        }));
    };

    const handleItemGstCheck = (e) => {
        setItemForm(prev => ({
            ...prev,
            gstChecked: e.target.checked,
            gstValue: e.target.checked ? (prev.gstValue || '') : ''
        }));
    };

    const handleItemDiscountCheck = (e) => {
        setItemForm(prev => ({
            ...prev,
            discountChecked: e.target.checked,
            discountType: prev.discountType,
            discountValue: e.target.checked ? prev.discountValue : ''
        }));
    };

    const handleSaveItem = () => {
        const errors = {
            name: validateItemForm("name", itemForm.name),
            rate: validateItemForm("rate", itemForm.rate),
            quantity: validateItemForm("quantity", itemForm.quantity),
        };
        setItemFormErrors(errors);
        if (errors.name || errors.rate || errors.quantity) return;
        const newItem = { ...itemForm, drag_id: `${items?.length + items?.length}`, };
        let updatedItems;
        if (editItemIndex !== null) {
            updatedItems = [...items];
            updatedItems[editItemIndex] = newItem;
        } else {
            updatedItems = [...items, newItem];
        }
        setItems(updatedItems);
        setShow(false);
    };

    const handleEditItem = (idx) => {
        setEditItemIndex(idx);
        setItemForm(items[idx]);
        setItemFormErrors({
            name: "",
            rate: "",
            quantity: "",
        });
        setShow(true);
    };

    const handleDeleteItem = (idx) => {
        const deletedItem = items[idx];
        setItems(items.filter((_, i) => i !== idx));
        if (deletedItem.isAppointment && deletedItem.appointmentId) {
            setAppointmentFlatList(prev => [...prev, deletedItem._originalAppointment]);
        }
    };

    const handleChooseItemOpen = async () => {
        setShow(false);
        setShowChooseItemModal(true);
        const result = await dispatch(fetchItemData());
        if (result && result.payload && Array.isArray(result.payload.data)) {
            setChooseItemList(result.payload.data);
        } else {
            setChooseItemList([]);
        }
        setChooseSelectedItems([]);
    };
    const handleChooseItemClose = () => {
        setItemSearch("");
        setShowChooseItemModal(false);
    }

    const handleChooseItemToggle = (item) => {
        setChooseSelectedItems(prev => {
            const exists = prev.find(i => i.id === item.id);
            if (exists) {
                return prev.filter(i => i.id !== item.id);
            } else {
                return [...prev, item];
            }
        });
    };

    const handleChooseItemSave = () => {
        const mapped = chooseSelectedItems.map(item => ({
            id: item.id || null,
            code: item.code || '',
            name: item.name || item.item_name || '',
            description: item.description || item.item_Description || '',
            rate: item?.rate || '',
            quantity: item.quantity || item.qty || 1,
            unitTypes: item.unitTypes || item.unit_code || '',
            gstChecked: item.gstChecked || false,
            gstValue: item.gstValue || '',
            discountChecked: item.discountChecked || false,
            discountType: item.discountType || 'flat',
            discountValue: item.discountValue || '',
            isAppointment: false,
            appointmentId: null
        }));
        const existingKeys = items.map(i => `${i.name}-${i.rate}-${i.description}`);
        const newItems = mapped.filter(i => !existingKeys.includes(`${i.name}-${i.rate}-${i.description}`));
        setItems([...items, ...newItems]);
        setShowChooseItemModal(false);
    };

    const filteredChooseItemList = chooseItemList.filter(item =>
        (item.name || item.item_name || '').toLowerCase().includes(itemSearch.toLowerCase()) ||
        (item.description || item.item_Description || '').toLowerCase().includes(itemSearch.toLowerCase())
    );

    const calendarRef = useRef();
    const dueDateCalendarRef = useRef();
    const depositDueDateCalendarRef = useRef();
    const [showDepositDueDateCalendar, setShowDepositDueDateCalendar] = useState(false);

    useEffect(() => {
        function handleClickOutside(event) {
            if (
                showCalendarStart &&
                calendarRef.current &&
                !calendarRef.current.contains(event.target)
            ) {
                setShowCalendarStart(false);
            }
            if (
                showDueDateCalendar &&
                dueDateCalendarRef.current &&
                !dueDateCalendarRef.current.contains(event.target)
            ) {
                setShowDueDateCalendar(false);
            }
            if (
                showDepositDueDateCalendar &&
                depositDueDateCalendarRef.current &&
                !depositDueDateCalendarRef.current.contains(event.target)
            ) {
                setShowDepositDueDateCalendar(false);
            }
        }
        if (showCalendarStart || showDueDateCalendar || showDepositDueDateCalendar) {
            document.addEventListener("mousedown", handleClickOutside);
        }
        return () => {
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, [showCalendarStart, showDueDateCalendar, showDepositDueDateCalendar]);


    useEffect(() => {
        if (depositTab === 'percent') {
            setDepositFixedAmount(Math.round((total * depositPercentage) / 100));
        }
    }, [depositTab, depositPercentage, total]);

    // Discount Modal logic
    const handleCloseDiscountModal = () => setDiscountModalOpen(false);
    // Calculate subtotal (after item-level discounts, before GST)
    subtotal = items.reduce((sum, item) => {
        let itemTotal = parseFloat(item.rate || 0) * parseFloat(item.quantity || 1);
        if (item.discountChecked) {
            if (item.discountType === "percentage") {
                itemTotal -= itemTotal * (parseFloat(item.discountValue || 0) / 100);
            } else {
                itemTotal -= parseFloat(item.discountValue || 0);
            }
        }
        return sum + itemTotal;
    }, 0);

    // Calculate GST (sum of all item GSTs)
    gstTotal = items.reduce((sum, item) => {
        if (item.gstChecked && item.gstValue) {
            let itemTotal = parseFloat(item.rate || 0) * parseFloat(item.quantity || 1);
            if (item.discountChecked) {
                if (item.discountType === "percentage") {
                    itemTotal -= itemTotal * (parseFloat(item.discountValue || 0) / 100);
                } else {
                    itemTotal -= parseFloat(item.discountValue || 0);
                }
            }
            return sum + (itemTotal * (parseFloat(item.gstValue) / 100));
        }
        return sum;
    }, 0);

    // Calculate total (subtotal - discountAmount + gstTotal)
    total = subtotal - discountAmount + gstTotal;

    // Open Discount Modal
    const handleOpenDiscountModal = () => {
        setDiscountInputValue(discountType === "%" ? "" : discountAmount.toString());
        setDiscountModalOpen(true);
        setInvoiceDiscountEditable(true);
    };

    // Save Discount from Modal
    const handleSaveDiscount = () => {
        let discValue = parseFloat(discountInputValue) || 0;
        let discAmount = 0;
        if (discountType === "%") {
            discAmount = subtotal * (discValue / 100);
        } else {
            discAmount = discValue;
        }
        setDiscountAmount(discAmount);
        setInvoiceDiscount(discAmount.toFixed(2));
        setDiscountModalOpen(false);
    };

    // Show GST line if any item has GST
    const hasAnyGst = items.some(item => item.gstChecked && item.gstValue);


    function getItemBaseAndGst(item) {
        const itemTotal = parseFloat(item.rate || 0) * parseFloat(item.quantity || 0);

        // Calculate discount first
        let discountedTotal = itemTotal;
        if (item.discountChecked == 'true' || item.discountChecked == true) {
            if (item.discountType === "percentage") {
                discountedTotal = itemTotal - (itemTotal * (parseFloat(item.discountValue || 0) / 100));
            } else {
                discountedTotal = itemTotal - parseFloat(item.discountValue || 0);
            }
        }

        // Then calculate GST
        if (item.gstChecked == 'true' || item.gstChecked == true && item.gstValue) {
            const gstPerc = parseFloat(item.gstValue || 0);
            if (invoiceGstType === "Inclusive") {
                const base = discountedTotal / (1 + gstPerc / 100);
                const gst = discountedTotal - base;
                return { base, total: discountedTotal, gst };
            } else {
                const gst = discountedTotal * (gstPerc / 100);
                return { base: discountedTotal, gst, total: discountedTotal + gst };
            }
        } else {
            return { base: discountedTotal, gst: 0, total: discountedTotal };
        }
    }

    function getInvoiceGst(baseTotal) {
        if (!invoiceGstRate || !invoiceGstRate.percentage) return { base: baseTotal, gst: 0, total: baseTotal };
        const gstPerc = parseFloat(invoiceGstRate.percentage);
        if (invoiceGstType === "Inclusive") {
            const base = baseTotal / (1 + gstPerc / 100);
            const gst = baseTotal - base;
            return { base, gst, total: baseTotal };
        } else {
            const gst = baseTotal * (gstPerc / 100);
            return { base: baseTotal, gst, total: baseTotal + gst };
        }
    }

    if (hasItemLevelGst) {
        // Calculate item-level GST
        subtotal = items.reduce((sum, item) => {
            const { base } = getItemBaseAndGst(item);
            return sum + base;
        }, 0);

        gstTotal = items.reduce((sum, item) => {
            const { gst } = getItemBaseAndGst(item);
            return sum + gst;
        }, 0);

        discountTotal = 0;
        if (invoiceDiscountEditable || estimateToEdit) {
            discountTotal = parseFloat(invoiceDiscount || 0);
        }

        total = subtotal + gstTotal - discountTotal;
    } else {
        // Calculate invoice-level GST
        subtotal = items.reduce((sum, item) => {
            const itemTotal = parseFloat(item.rate || 0) * parseFloat(item.quantity || 0);

            // Apply item-level discount if any
            if (item.discountChecked == 'true' || item.discountChecked == true) {
                if (item.discountType === "percentage") {
                    return sum + (itemTotal - (itemTotal * (parseFloat(item.discountValue || 0) / 100)));
                } else {
                    return sum + (itemTotal - parseFloat(item.discountValue || 0));
                }
            }

            return sum + itemTotal;
        }, 0);

        if (invoiceDiscountEditable || estimateToEdit) {
            discountTotal = parseFloat(invoiceDiscount || 0);
        } else {

            discountTotal = items.reduce((sum, item) => {
                const itemTotal = parseFloat(item.rate || 0) * parseFloat(item.quantity || 0);
                if (item.discountChecked == 'false' || item.discountChecked == false) return sum;
                if (item.discountType === "percentage") {
                    return sum + (itemTotal * (parseFloat(item.discountValue || 0) / 100));
                } else {
                    return sum + parseFloat(item.discountValue || 0);
                }
            }, 0);
        }

        const gstResult = getInvoiceGst(subtotal);
        gstTotal = gstResult.gst;
        total = gstResult.total - discountTotal;
    }

    // Save/Update logic
    const handleSaveOrUpdateEstimate = async () => {
        setLoading(true);
        const clientPayload = selectedClient
            ? { ...selectedClient }
            : { ...clientForm };
        const itemsPayload = items.map((item) => ({
            id: item.id || null,
            name: item.name,
            description: item.description,
            rate: item.rate,
            quantity: item.quantity,
            gstChecked: item.gstChecked,
            gstValue: item.gstChecked ? item.gstValue : '',
            discountChecked: item.discountChecked,
            discountType: item.discountChecked ? item.discountType : 'flat',
            discountValue: item.discountChecked ? item.discountValue : '',
        }));
        const invoicePayload = {
            id: estimateToEdit?.estimate?.id || null,
            estimateNumber: invoiceNumber,
            autosaveEnabled: (typeof localStorage !== 'undefined') ? localStorage.getItem('autosaveEnabled') : false,
            clients: clientPayload,
            items: itemsPayload,
            date: invoiceDate,
            subTotal: subtotal,
            discount: {
                type: discountType,
                value: discountValue,
                amount: discountTotal,
            },
            total: total,
            paid: 0,
            balance: total,
            paymentStatus: "unpaid",
            sentStatus: "unsent",
            logo,
            paymentInstruction,
            note: comment,
            customInvoice: formData,
            customInvoiceOption: optionData,
            attachments: attachments,
        };

        try {
            let result;
            if (estimateToEdit && estimateToEdit.estimate?.id) {
                result = await dispatch(updateEstimateData(invoicePayload)).unwrap();
            } else {
                result = await dispatch(createEstimateData(invoicePayload)).unwrap();
            }
            if (result && result.data) {
                setUnsaved(false)
                setTimeout(() => {
                    router.push('/estimate');
                }, 100)
            } else {
                alert(result.message || "Failed to save estimate");
            }
        } catch (err) {
            alert("Failed to save estimate",);
        } finally {
            setLoading(false);
        }
    };


    function handleAddDepositOpen() {
        setShowDepositModal(true);
        if (deposit) {
            setDepositTab(deposit.type);
            setDepositPercentage(deposit.percentage || '');
            setDepositFixedAmount(deposit.amount || '');
            setDepositDueDate(deposit.dueDate || format(new Date(), 'yyyy-MM-dd'));
            setDepositAddToFuture(deposit.addToFuture || false);
            setDepositPaid(deposit.paid || 0);
        } else {
            setDepositTab('percent');
            setDepositPercentage('');
            setDepositFixedAmount('');
            setDepositDueDate(format(new Date(), 'yyyy-MM-dd'));
            setDepositAddToFuture(false);
            setDepositPaid(0);
        }
    }
    function handleDepositClose() {
        setShowDepositModal(false);
    }
    function handleDepositSave() {
        let amount = depositTab === 'percent'
            ? Math.round((total * depositPercentage) / 100)
            : Number(depositFixedAmount);
        setDeposit({
            type: depositTab,
            percentage: depositTab === 'percent' ? depositPercentage : null,
            amount,
            dueDate: depositDueDate,
            addToFuture: depositAddToFuture,
            paid: depositPaid
        });
        setShowDepositModal(false);
    }
    function handleDepositCancel() {
        setDeposit(null);
        setShowDepositModal(false);
    }
    const handleDateClick = () => setShowCalendarStart(true);
    const handleDateSelect = (date) => {
        setInvoiceDate(date);
        setShowCalendarStart(false);
    };

    const handleTermsChange = (e) => {
        setTerms(e.target.value);
        if (e.target.value !== "1") setShowDueDateCalendar(false);
    };

    const handleDueDateClick = () => {
        setShowDueDateCalendar(true);
    };
    const handleDueDateSelect = (date) => {
        setDueDate(date);
        setShowDueDateCalendar(false);
    };
    const handleChooseSelectedDelete = (itemId) => {
        setChooseSelectedItems(prev => prev.filter(i => i.id !== itemId));
    };

    function handleLogoChange(e) {
        const files = Array.from(e.target.files);
        if (!files.length) return;

        // Helper to compress image using canvas
        function compressImage(file, maxWidth = 800, maxHeight = 800, quality = 0.7) {
            return new Promise((resolve, reject) => {
                const img = new window.Image();
                const reader = new FileReader();
                reader.onload = function (evt) {
                    img.onload = function () {
                        let width = img.width;
                        let height = img.height;

                        // Calculate new size while maintaining aspect ratio
                        if (width > maxWidth || height > maxHeight) {
                            if (width / height > maxWidth / maxHeight) {
                                height = Math.round((height * maxWidth) / width);
                                width = maxWidth;
                            } else {
                                width = Math.round((width * maxHeight) / height);
                                height = maxHeight;
                            }
                        }

                        const canvas = document.createElement('canvas');
                        canvas.width = width;
                        canvas.height = height;
                        const ctx = canvas.getContext('2d');
                        ctx.drawImage(img, 0, 0, width, height);

                        // Compress to JPEG (smaller than PNG)
                        const compressedBase64 = canvas.toDataURL('image/jpeg', quality);
                        resolve(compressedBase64);
                    };
                    img.onerror = reject;
                    img.src = evt.target.result;
                };
                reader.onerror = reject;
                reader.readAsDataURL(file);
            });
        }

        // Compress all images and add to attachments
        Promise.all(
            files.map(file => compressImage(file, 800, 800, 0.7))
        ).then(images => {
            setAttachments(prev => [...prev, ...images]);
        });
    }
    function handleRemoveAttachment(idx) {
        setAttachments(prev => prev.filter((_, i) => i !== idx));
    }

    const handleEditInvoiceNumber = () => {
        setEditInvoiceNumber(true);
        setInvoiceNumberInput(invoiceNumber);
    };

    const handleInvoiceNumberInputChange = (e) => {
        let val = e.target.value.replace(/[^0-9]/g, "");
        setInvoiceNumberInput(val);
    };

    const handleInvoiceNumberInputBlur = () => {
        let num = invoiceNumberInput;
        setInvoiceNumber(num);
        setEditInvoiceNumber(false);
    };

    useEffect(() => {
        setInvoiceNumber(estimateToEdit?.estimate != null ? estimateToEdit.estimate.estimateNumber : est.estimateNumber || "")
    }, [est])

    const handleInvoiceNumberInputKeyDown = (e) => {
        if (e.key === "Enter" || e.key === "Escape") {
            handleInvoiceNumberInputBlur();
        }
    };


    // =============stickey top form heafer==========


    useEffect(() => {
        const handleScroll = () => {
            // Get the element's original position from the top of the page
            const element = document.querySelector('.addClientFormTop');
            if (!element) return;

            const offsetTop = element.offsetTop;
            const scrollTop = window.scrollY;

            setIsSticky(scrollTop > 30);
        };

        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    return (
        <>
            <div className="estimatepending-container">
                <div className="addClientForm mb-4 estimate-back">
                    <button className='clientFormBackBtn mt-2 ml-2' onClick={handleBack} disabled={loading}>
                        <FontAwesomeIcon icon={faArrowLeft} /> {est?.type + " Estimate"}
                    </button>
                    {/* <div className='addClientFormTop'> */}
                    <div className={`addClientFormTop ${isSticky ? 'sticky' : ''}`}>
                        <div className='addClientFormTopLeft'>
                            <ul>
                                {TABS?.map(tab => (
                                    <li
                                        key={tab}
                                        className={activeTab === tab ? 'active' : ''}
                                        style={{ cursor: 'pointer' }}
                                        onClick={() => handleTabChange(tab)}
                                    >{tab}</li>
                                ))}
                                {/* <li>{estimateToEdit ? "Edit Estimate" : "Add Estimate"}</li> */}
                            </ul>
                        </div>
                        <div className="addClientFormTopRight">
                            <button onClick={handleSaveOrUpdateEstimate}>
                                {estimateToEdit ? (loading ? "Updating..." : "Update") : (loading ? "Saving..." : "Save")}
                            </button>
                        </div>
                    </div>
                </div>
                {/* <Pageheader
                    label={est?.type + " Estimate"}
                    handleSave={handleSaveOrUpdateEstimate}
                    loading={loading}
                /> */}
                <div className="contentArea-inners addClientFormInner">
                    {(activeTab === "Edit" || activeTab === "Create") &&
                        // <div className="contentArea-inners">
                        <div className="row">
                            <div className="col-lg-9">
                                <div className="inner-container">
                                    <Accordion defaultActiveKey={['0', '1', '2', '3', '4', '5']} alwaysOpen>
                                        <Accordion.Item eventKey="0">
                                            <Accordion.Header>
                                                <p className="accorheading">Bill To</p>
                                            </Accordion.Header>
                                            <Accordion.Body>
                                                {!selectedClient ? (
                                                    <div className="col-lg-12">
                                                        <button className="add-note" onClick={handleShowClientModal}>
                                                            <FontAwesomeIcon icon={faSquarePlus} /> Add Client
                                                        </button>
                                                    </div>
                                                ) : (
                                                    <div className="contactDetails">
                                                        <div className="contactDetailsLeft">
                                                            <h3>
                                                                {selectedClient.profileImage
                                                                    ? <img src={selectedClient.profileImage} style={{ width: '60px', height: '60px', borderRadius: '60%' }} alt={selectedClient.name} />
                                                                    : selectedClient.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                                                            </h3>
                                                        </div>
                                                        <div className="contactDetailsRight">
                                                            <h4>{selectedClient.name}</h4>
                                                            <ul>
                                                                <li>
                                                                    <FontAwesomeIcon icon={faEnvelope} />
                                                                    {selectedClient.email}
                                                                </li>
                                                                <li>
                                                                    <FontAwesomeIcon icon={faPhone} />
                                                                    {selectedClient.phone}
                                                                </li>
                                                                {selectedClient.address && (
                                                                    <li>
                                                                        <FontAwesomeIcon icon={faLocationDot} />
                                                                        {selectedClient.address}
                                                                    </li>
                                                                )}
                                                            </ul>
                                                        </div>
                                                        <div
                                                            className="crossBtn"
                                                            style={{ cursor: "pointer" }}
                                                            onClick={handleClearClient}
                                                        >
                                                            <FontAwesomeIcon icon={faCircleXmark} />
                                                        </div>
                                                    </div>
                                                )}
                                            </Accordion.Body>
                                        </Accordion.Item>
                                        <Accordion.Item eventKey="1">
                                            <Accordion.Header>
                                                <p className="accorheading">Items</p>
                                            </Accordion.Header>
                                            <Accordion.Body>
                                                <div className="row">
                                                    <div className="col-lg-12">
                                                        {items.length === 0 && (
                                                            <div style={{ color: '#888', marginBottom: 8 }}>No items added yet.</div>
                                                        )}
                                                        <DndKitList handleEditItem={handleEditItem} handleDeleteItem={handleDeleteItem} items={items} setItems={setItems} currencyList={currencyList} />
                                                    </div>
                                                    {/* <div className="col-lg-12">
                                                        {items.length === 0 && (
                                                            <div style={{ color: "#888", marginBottom: 8 }}>No items added yet.</div>
                                                        )}
                                                        {items.map((item, idx) => (
                                                            <div className="productName" key={idx}>
                                                                <div className="productNameLeftDot">
                                                                    <img src={IMAGE.dotted} alt="" />
                                                                </div>
                                                                <div className="productNameLeft">
                                                                    <h6>{item.name}</h6>
                                                                    <p>
                                                                        {item.description ||
                                                                            "Add a description so your client understands the product or service you provided."}
                                                                    </p>
                                                                </div>
                                                                <div className="productNameRight">
                                                                    <h6>{formatCurrency(parseFloat(item.rate || 0))}</h6>
                                                                    <p>
                                                                        {item.quantity} X {item.rate}
                                                                    </p>
                                                                    {(item.gstChecked == 'true' || item.gstChecked == true && item.gstValue) && (
                                                                        <span>{Number(item.gstValue)}% GST</span>
                                                                    )}
                                                                    {(item.discountChecked == 'true' || item.discountChecked == true) && (
                                                                        <span>-{item.discountType === "percentage" ? `${item.discountValue}%` : formatCurrency(parseFloat(item.discountValue || 0))}</span>
                                                                    )}
                                                                </div>
                                                                <div className="editDelete">
                                                                    <span
                                                                        className="edit"
                                                                        style={{ cursor: "pointer" }}
                                                                        onClick={() => handleEditItem(idx)}
                                                                    >
                                                                        <img src={IMAGE.editBtn} alt="" />
                                                                    </span>
                                                                    <span
                                                                        className="delete"
                                                                        style={{ cursor: "pointer" }}
                                                                        onClick={() => handleDeleteItem(idx)}
                                                                    >
                                                                        <img src={IMAGE.DeleteBtn} alt="" />
                                                                    </span>
                                                                </div>
                                                            </div>
                                                        ))}
                                                    </div> */}
                                                </div>
                                                <div className="row">
                                                    <div className="col-lg-3 col-md-4 col-6">
                                                        <button className="add-note" onClick={handleShow}>
                                                            <FontAwesomeIcon icon={faSquarePlus} /> Add items
                                                        </button>
                                                    </div>
                                                </div>
                                            </Accordion.Body>
                                        </Accordion.Item>
                                        <Accordion.Item eventKey="3">
                                            <Accordion.Header>
                                                <p className="accorheading">Payment Methods</p>
                                            </Accordion.Header>
                                            <Accordion.Body>
                                                <div className="col-lg-12">
                                                    {showPaymentInstructionInput ? (
                                                        <>
                                                            <input
                                                                className="input-form-control"
                                                                type="text"
                                                                value={paymentInstruction}
                                                                onChange={(e) => setPaymentInstruction(e.target.value)}
                                                                placeholder="Enter payment instruction"
                                                                autoFocus
                                                            />
                                                            <div style={{ fontSize: 13, color: "#888", marginTop: 4 }}>
                                                                If you have specific comments about payments or instructions, enter them here.
                                                            </div>
                                                        </>
                                                    ) : (
                                                        <button className="add-note" onClick={() => setShowPaymentInstructionInput(true)}>
                                                            <FontAwesomeIcon icon={faSquarePlus} />Add payment instruction
                                                        </button>
                                                    )}
                                                </div>
                                            </Accordion.Body>
                                        </Accordion.Item>
                                        <Accordion.Item eventKey="4">
                                            <Accordion.Header>
                                                <p className="accorheading">More Details</p>
                                            </Accordion.Header>
                                            <Accordion.Body>
                                                <div className="col-lg-12" style={{ display: "flex", flexWrap: "wrap", gap: 16 }}>
                                                    {/* {console.log(attachments, "123456789o")} */}
                                                    {attachments.map((img, idx) => (
                                                        <div key={idx} style={{ position: "relative", marginBottom: 8 }}>
                                                            <img
                                                                src={img}
                                                                alt={`Attachment ${idx + 1}`}
                                                                style={{
                                                                    width: 80,
                                                                    height: 80,
                                                                    objectFit: "cover",
                                                                    borderRadius: 6,
                                                                    border: "1px solid #eee"
                                                                }}
                                                            />
                                                            <span
                                                                style={{
                                                                    position: "absolute",
                                                                    top: 2,
                                                                    right: 2,
                                                                    background: "#fff",
                                                                    borderRadius: "50%",
                                                                    cursor: "pointer",
                                                                    padding: "2px 4px",
                                                                    color: "#047FFF"
                                                                }}
                                                                onClick={() => handleRemoveAttachment(idx)}
                                                            >
                                                                <div className="crossBtn deleteCross" style={{ cursor: "pointer" }} onClick={handleRemoveAttachment}>
                                                                    <FontAwesomeIcon icon={faCircleXmark} />
                                                                </div>
                                                            </span>
                                                        </div>
                                                    ))}

                                                    <div className='addPhotoInput addPhotoCard'>

                                                        <img src={IMAGE.imagePicker} alt="" />
                                                        <input
                                                            type="file"
                                                            accept="image/*"
                                                            ref={logoInputRef}

                                                            multiple
                                                            onChange={handleLogoChange}
                                                        />
                                                        <div className='addPhotoInputButton'>

                                                            <button
                                                                className="add-photo"
                                                                style={{ width: 80, height: 80, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}
                                                                onClick={() => {
                                                                    if (logoInputRef.current) {
                                                                        logoInputRef.current.value = "";
                                                                        logoInputRef.current.click();
                                                                    }
                                                                }}
                                                                onKeyDown={(e) => {
                                                                    if (e.key === 'Enter' || e.key === ' ') {
                                                                        e.preventDefault();
                                                                        if (logoInputRef.current) {
                                                                            logoInputRef.current.value = "";
                                                                            logoInputRef.current.click();
                                                                        }
                                                                    }
                                                                }}
                                                            >
                                                                {/* <img src={IMAGE.imagePicker} alt="" /> */}
                                                                <input
                                                                    type="file"
                                                                    accept="image/*"
                                                                    ref={logoInputRef}
                                                                    multiple
                                                                    onChange={handleLogoChange}
                                                                    style={{ display: 'none' }}
                                                                />
                                                                <div className='addPhotoInputButton'>

                                                                    <button
                                                                        type="button"
                                                                        className="add-photo"
                                                                        style={{ width: 80, height: 80, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", pointerEvents: 'none' }}
                                                                    >
                                                                        <FontAwesomeIcon icon={faSquarePlus} style={{ fontSize: 24 }} />
                                                                        <span style={{ fontSize: 12 }}>Add Photo</span>
                                                                    </button>

                                                                </div>
                                                                </button>
                                                        </div>

                                                </div>
                                                </div>

                                            </Accordion.Body>
                                        </Accordion.Item>
                                        <Accordion.Item eventKey="5">
                                            <Accordion.Header>
                                                <p className="accorheading">Note</p>
                                            </Accordion.Header>
                                            <Accordion.Body>
                                                <div className="col-lg-12" style={{ marginTop: 12 }}>
                                                    {showCommentInput ? (
                                                        <input
                                                            className="input-form-control"
                                                            type="text"
                                                            value={comment}
                                                            onChange={(e) => setComment(e.target.value)}
                                                            placeholder="Enter a notes..."
                                                            autoFocus
                                                        />
                                                    ) : (
                                                        <button className="add-note" onClick={() => setShowCommentInput(true)}>
                                                            <FontAwesomeIcon icon={faSquarePlus} />Add Note
                                                        </button>
                                                    )}
                                                </div>
                                            </Accordion.Body>
                                        </Accordion.Item>
                                    </Accordion>
                                </div>

                            </div>
                            <div className="col-lg-3">
                            <div className="invoiceHeaderLeft">

                                <div className="invoiceSection">
                                    <h5>Estimate</h5>
                                    <div className='invoiceSectionInner'>
                                        {!estimateToEdit?.id && (
                                            <>
                                                <h6 style={{ margin: 0, display: 'inline-block' }}>
                                                    {/* {console.log(invoiceNumber, "invoiceNumber")} */}
                                                    {optionData.invoicePrifix ? optionData.invoicePrifix + '-' : ''}{!estimateToEdit?.id && editInvoiceNumber ? '' : invoiceNumber}

                                                </h6>
                                                {editInvoiceNumber ? (
                                                    <input className='input-form-control'
                                                        type="text"
                                                        value={invoiceNumberInput}
                                                        onChange={handleInvoiceNumberInputChange}
                                                        onBlur={handleInvoiceNumberInputBlur}
                                                        onKeyDown={handleInvoiceNumberInputKeyDown}
                                                        style={{
                                                            width: 60,
                                                            fontSize: 18,
                                                            fontWeight: 600,
                                                            border: '1px solid #047FFF',
                                                            borderRadius: 4,
                                                            padding: '2px 6px'
                                                        }}
                                                        autoFocus />
                                                ) : (
                                                    <>
                                                        {est?.type === "Create" && <span style={{ marginLeft: 8, cursor: 'pointer' }} onClick={handleEditInvoiceNumber}>
                                                            <FontAwesomeIcon icon={faPenToSquare} />
                                                        </span>}
                                                    </>
                                                )}
                                            </>
                                        )}
                                        {/* {console.log(invoiceNumber, "invoiceNumber")} */}
                                        {estimateToEdit?.id && (
                                            <h6 style={{ margin: 0, display: 'inline-block' }}>{optionData.invoicePrifix ? optionData.invoicePrifix + '-' : ''}{invoiceNumber}</h6>
                                        )}
                                    </div>
                                    <p className="unsent">{sentStatus === "sent" ? "Sent" : "Unsent"}</p>
                                </div>
                                <div className="BillCostDiv" style={{marginLeft:"0"}}>
                                    <h4 className="bill" style={{ textAlign: 'left' }}>Bill Cost</h4>
                                    <div className="card amount-card">
                                        <div className="card-body">
                                            <div className="amount">
                                                <p>Sub Total</p>
                                                <h4>{formatCurrency(subtotal, currencyList)}</h4>
                                            </div>
                                            <div
                                                className="amount"
                                                style={{ cursor: "pointer" }}
                                                onClick={handleOpenDiscountModal}
                                            >
                                                <p>Discount</p>
                                                <h4 className="listBorder" style={{ color: "#888" }}>
                                                    {formatCurrency(discountAmount, currencyList)}
                                                </h4>
                                            </div>
                                            {hasAnyGst && (
                                                <div className="amount">
                                                    <p>GST</p>
                                                    <h4>{formatCurrency(gstTotal, currencyList)}</h4>
                                                </div>
                                            )}
                                            <div className="amount">
                                                <p>Total</p>
                                                <h4>{formatCurrency(total, currencyList)}</h4>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            </div>

                        </div>
                    }
                    {activeTab === "Preview" &&
                        <div className='row'>
                            <div className='col-md-8'>
                                <div ref={previewRef}>
                                    {/* {console.log(gstTotal, "gstTotalgstTotalgstTotal")} */}
                                    {formData.templateName === 'impact' && (
                                        <CustomInvoiceImpact
                                            invoice={{
                                                name: "Estimate",
                                                invoiceNumber,
                                                selectedClient,
                                                invoiceDate,
                                                dueDate,
                                                items,
                                                subtotal,
                                                gstTotal,
                                                discountTotal,
                                                invoiceDiscountEditable,
                                                total,
                                                logo,
                                                attachments,
                                                paymentInstruction,
                                                comment,
                                                depositAmount: deposit,
                                                terms
                                            }}
                                            // logoFile={logo}
                                            photoFiles={attachments}
                                            editInvoiceNumber={editInvoiceNumber}
                                            invoiceNumberInput={invoiceNumberInput}
                                            handleInvoiceNumberInputChange={handleInvoiceNumberInputChange}
                                            handleInvoiceNumberInputBlur={handleInvoiceNumberInputBlur}
                                            handleInvoiceNumberInputKeyDown={handleInvoiceNumberInputKeyDown}
                                            handleEditInvoiceNumber={handleEditInvoiceNumber}
                                            handleTermsChange={handleTermsChange}
                                            value2={value2}
                                            setValue2={setValue2}
                                            onBackToEdit={() => { estimateToEdit ? setActiveTab('Edit') : setActiveTab('Create') }}
                                            ref={null}
                                            selectedTemp={formData.templateName}
                                            selectedId={
                                                formData.logoId
                                                    ? { id: formData.logoId, logoImage: formData.logoImage }
                                                    : null
                                            }
                                            selectedSize={formData.logoSize}
                                            alignPos={formData.logoPosition}
                                            selectedColour={
                                                formData.colourId
                                                    ? { id: formData.colourId, colourCode: formData.colourCode }
                                                    : null
                                            }
                                            customColour={formData.customColour}
                                            selectedHeader={
                                                formData.headerId
                                                    ? { id: formData.headerId, headerImg: formData.headerImg }
                                                    : null
                                            }
                                            selectedWatermark={
                                                formData.waterMarkId
                                                    ? {
                                                        id: formData.waterMarkId,
                                                        waterMarkImg: formData.waterMarkImg,
                                                    }
                                                    : null
                                            }
                                            customTemplates={customTemplates}
                                            customOption={optionData}
                                            signatureName={sigEstimate}
                                            signatureType={signatureType}
                                            signature={{
                                                padSignature,
                                                uploadSignature,
                                                signatureText
                                            }}
                                            currencyList={currencyList}
                                        />
                                    )}
                                    {formData.templateName === 'classic' && (
                                        <CustomInvoiceImpact
                                            invoice={{
                                                name: "Estimate",
                                                invoiceNumber,
                                                selectedClient,
                                                invoiceDate,
                                                dueDate,
                                                items,
                                                subtotal,
                                                gstTotal,
                                                discountTotal,
                                                total,
                                                logo,
                                                attachments,
                                                paymentInstruction,
                                                comment,
                                                depositAmount: deposit,
                                                terms
                                            }}
                                            logoFile={logo}
                                            photoFiles={attachments}
                                            editInvoiceNumber={editInvoiceNumber}
                                            invoiceNumberInput={invoiceNumberInput}
                                            handleInvoiceNumberInputChange={handleInvoiceNumberInputChange}
                                            handleInvoiceNumberInputBlur={handleInvoiceNumberInputBlur}
                                            handleInvoiceNumberInputKeyDown={handleInvoiceNumberInputKeyDown}
                                            handleEditInvoiceNumber={handleEditInvoiceNumber}
                                            handleTermsChange={handleTermsChange}
                                            value2={value2}
                                            setValue2={setValue2}
                                            onBackToEdit={() => { estimateToEdit?.id ? setActiveTab('Edit') : setActiveTab('Create') }}
                                            ref={null}
                                            selectedTemp={formData.templateName}
                                            selectedId={
                                                formData.logoId
                                                    ? { id: formData.logoId, logoImage: formData.logoImage }
                                                    : null
                                            }
                                            selectedSize={formData.logoSize}
                                            alignPos={formData.logoPosition}
                                            selectedColour={
                                                formData.colourId
                                                    ? { id: formData.colourId, colourCode: formData.colourCode }
                                                    : null
                                            }
                                            customColour={formData.customColour}
                                            selectedHeader={
                                                formData.headerId
                                                    ? { id: formData.headerId, headerImg: formData.headerImg }
                                                    : null
                                            }
                                            selectedWatermark={
                                                formData.waterMarkId
                                                    ? {
                                                        id: formData.waterMarkId,
                                                        waterMarkImg: formData.waterMarkImg,
                                                    }
                                                    : null
                                            }
                                            customTemplates={customTemplates}
                                            customOption={optionData}
                                            signatureName={sigEstimate}
                                            signatureType={signatureType}
                                            signature={{
                                                padSignature,
                                                uploadSignature,
                                                signatureText
                                            }}
                                            currencyList={currencyList}
                                        />
                                    )}

                                    {formData.templateName === 'modern' && (
                                        <CustomInvoiceImpact
                                            invoice={{
                                                name: "Estimate",
                                                invoiceNumber,
                                                selectedClient,
                                                invoiceDate,
                                                dueDate,
                                                items,
                                                subtotal,
                                                gstTotal,
                                                discountTotal,
                                                total,
                                                logo,
                                                attachments,
                                                paymentInstruction,
                                                comment,
                                                depositAmount: deposit,
                                                terms
                                            }}
                                            logoFile={logo}
                                            photoFiles={attachments}
                                            editInvoiceNumber={editInvoiceNumber}
                                            invoiceNumberInput={invoiceNumberInput}
                                            handleInvoiceNumberInputChange={handleInvoiceNumberInputChange}
                                            handleInvoiceNumberInputBlur={handleInvoiceNumberInputBlur}
                                            handleInvoiceNumberInputKeyDown={handleInvoiceNumberInputKeyDown}
                                            handleEditInvoiceNumber={handleEditInvoiceNumber}
                                            handleTermsChange={handleTermsChange}
                                            value2={value2}
                                            setValue2={setValue2}
                                            onBackToEdit={() => { estimateToEdit?.id ? setActiveTab('Edit') : setActiveTab('Create') }}
                                            ref={null}
                                            selectedTemp={formData.templateName}
                                            selectedId={
                                                formData.logoId
                                                    ? { id: formData.logoId, logoImage: formData.logoImage }
                                                    : null
                                            }
                                            selectedSize={formData.logoSize}
                                            alignPos={formData.logoPosition}
                                            selectedColour={
                                                formData.colourId
                                                    ? { id: formData.colourId, colourCode: formData.colourCode }
                                                    : null
                                            }
                                            customColour={formData.customColour}
                                            selectedHeader={
                                                formData.headerId
                                                    ? { id: formData.headerId, headerImg: formData.headerImg }
                                                    : null
                                            }
                                            selectedWatermark={
                                                formData.waterMarkId
                                                    ? {
                                                        id: formData.waterMarkId,
                                                        waterMarkImg: formData.waterMarkImg,
                                                    }
                                                    : null
                                            }
                                            customTemplates={customTemplates}
                                            customOption={optionData}
                                            signatureName={sigEstimate}
                                            signatureType={signatureType}
                                            signature={{
                                                padSignature,
                                                uploadSignature,
                                                signatureText
                                            }}
                                            currencyList={currencyList}
                                        />
                                    )}

                                </div>
                            </div>
                            <div className='col-md-4 px-3'>
                                <div className='invoiceHeaderLeft'>
                                    <div className="invoiceSection">
                                        <h5>Estimate</h5>
                                        <div className='invoiceSectionInner'>
                                            {!estimateToEdit?.id && (
                                                <>
                                                    <h6 style={{ margin: 0, display: 'inline-block' }}>
                                                        {/* {console.log(invoiceNumber, "invoiceNumber")} */}
                                                        {optionData.invoicePrifix ? optionData.invoicePrifix + '-' : ''}{!estimateToEdit?.id && editInvoiceNumber ? '' : invoiceNumber}

                                                    </h6>
                                                    {editInvoiceNumber ? (
                                                        <input className='input-form-control'
                                                            type="text"
                                                            value={invoiceNumberInput}
                                                            onChange={handleInvoiceNumberInputChange}
                                                            onBlur={handleInvoiceNumberInputBlur}
                                                            onKeyDown={handleInvoiceNumberInputKeyDown}
                                                            style={{
                                                                width: 60,
                                                                fontSize: 18,
                                                                fontWeight: 600,
                                                                border: '1px solid #047FFF',
                                                                borderRadius: 4,
                                                                padding: '2px 6px'
                                                            }}
                                                            autoFocus />
                                                    ) : (
                                                        <>
                                                            {est?.type === "Create" && <span style={{ marginLeft: 8, cursor: 'pointer' }} onClick={handleEditInvoiceNumber}>
                                                                <FontAwesomeIcon icon={faPenToSquare} />
                                                            </span>}
                                                        </>
                                                    )}
                                                </>
                                            )}
                                            {estimateToEdit?.id && (
                                                <h6 style={{ margin: 0, display: 'inline-block' }}>{optionData.invoicePrifix ? optionData.invoicePrifix + '-' : ''}{invoiceNumber}</h6>
                                            )}
                                        </div>
                                        <p className="unsent">{sentStatus === "sent" ? "Sent" : "Unsent"}</p>
                                    </div>
                                    <div className='invoiceBox'>
                                        <ul className='borderBottom'>
                                            <li>
                                                <p>Date</p>
                                                <span>{formatDate(dueDate)}</span>
                                            </li>
                                        </ul>

                                        <div className="amount">
                                            <p>Sub Total</p>
                                            <h4>
                                                {formatCurrency(subtotal.toFixed(2), currencyList)}
                                            </h4>
                                        </div>
                                        {hasAnyGst && (
                                            <div className="amount">
                                                <p>GST</p>
                                                <h4>
                                                    {formatCurrency(gstTotal, currencyList)}
                                                </h4>
                                            </div>
                                        )}
                                        <ul className="borderBottom">
                                            <li>
                                                <p>Discount</p>
                                                <span style={{ color: "#888" }}>{formatCurrency(discountAmount, currencyList)}</span>
                                            </li>
                                        </ul>
                                        <ul className="borderBottom">
                                            <li>
                                                <p>Total</p>
                                                <span>{formatCurrency(total.toFixed(2), currencyList)}</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    }
                    {activeTab === 'Send' && (
                        <div className='row px-3'>
                            <div style={{ position: "absolute", left: "-9999px" }}>
                                <div ref={previewRef}>
                                    {formData.templateName === 'impact' && (
                                        <CustomInvoiceImpact
                                            invoice={{
                                                name: "Invoice",
                                                invoiceNumber,
                                                selectedClient,
                                                invoiceDate,
                                                dueDate,
                                                items,
                                                subtotal,
                                                gstTotal,
                                                discountTotal,
                                                invoiceDiscountEditable,
                                                total,
                                                logo,
                                                attachments,
                                                paymentInstruction,
                                                comment,
                                                depositAmount: deposit,
                                                terms
                                            }}
                                            logoFile={logo}
                                            photoFiles={attachments}
                                            editInvoiceNumber={editInvoiceNumber}
                                            invoiceNumberInput={invoiceNumberInput}
                                            signatureName={sigEstimate}
                                            signatureType={signatureType}
                                            signature={{
                                                padSignature,
                                                uploadSignature,
                                                signatureText
                                            }}
                                            currencyList={currencyList}
                                        // handleInvoiceNumberInputChange={handleInvoiceNumberInputChange}
                                        // handleInvoiceNumberInputBlur={handleInvoiceNumberInputBlur}
                                        // handleInvoiceNumberInputKeyDown={handleInvoiceNumberInputKeyDown}
                                        // handleEditInvoiceNumber={handleEditInvoiceNumber}
                                        // handleTermsChange={handleTermsChange}
                                        // value2={value2}
                                        // setValue2={setValue2}
                                        // onBackToEdit={() => {invoiceId ? setActiveTab('Edit') : setActiveTab('Create')}}
                                        // ref={null}
                                        // selectedTemp={formData.templateName}
                                        // selectedId={
                                        //     formData.logoId
                                        //         ? { id: formData.logoId, logoImage: formData.logoImage }
                                        //         : null
                                        // }
                                        // selectedSize={formData.logoSize}
                                        // alignPos={formData.logoPosition}
                                        // selectedColour={
                                        //     formData.colourId
                                        //         ? { id: formData.colourId, colourCode: formData.colourCode }
                                        //         : null
                                        // }
                                        // customColour={formData.customColour}
                                        // selectedHeader={
                                        //     formData.headerId
                                        //         ? { id: formData.headerId, headerImg: formData.headerImg }
                                        //         : null
                                        // }
                                        // selectedWatermark={
                                        //     formData.waterMarkId
                                        //         ? {
                                        //                 id: formData.waterMarkId,
                                        //                 waterMarkImg: formData.waterMarkImg,
                                        //             }
                                        //         : null
                                        // }
                                        // customTemplates={customTemplates}
                                        // customOption={optionData}
                                        />
                                    )}
                                    {formData.templateName === 'classic' && (
                                        <CustomInvoiceImpact
                                            invoice={{
                                                name: "Invoice",
                                                invoiceNumber,
                                                selectedClient,
                                                invoiceDate,
                                                dueDate,
                                                items,
                                                subtotal,
                                                gstTotal,
                                                discountTotal,
                                                total,
                                                logo,
                                                attachments,
                                                paymentInstruction,
                                                comment,
                                                depositAmount: deposit,
                                                terms
                                            }}
                                            logoFile={logo}
                                            photoFiles={attachments}
                                            editInvoiceNumber={editInvoiceNumber}
                                            invoiceNumberInput={invoiceNumberInput}
                                            handleInvoiceNumberInputChange={handleInvoiceNumberInputChange}
                                            handleInvoiceNumberInputBlur={handleInvoiceNumberInputBlur}
                                            handleInvoiceNumberInputKeyDown={handleInvoiceNumberInputKeyDown}
                                            handleEditInvoiceNumber={handleEditInvoiceNumber}
                                            handleTermsChange={handleTermsChange}
                                            value2={value2}
                                            setValue2={setValue2}
                                            onBackToEdit={() => { invoiceId ? setActiveTab('Edit') : setActiveTab('Create') }}
                                            ref={null}
                                            selectedTemp={formData.templateName}
                                            selectedId={
                                                formData.logoId
                                                    ? { id: formData.logoId, logoImage: formData.logoImage }
                                                    : null
                                            }
                                            selectedSize={formData.logoSize}
                                            alignPos={formData.logoPosition}
                                            selectedColour={
                                                formData.colourId
                                                    ? { id: formData.colourId, colourCode: formData.colourCode }
                                                    : null
                                            }
                                            customColour={formData.customColour}
                                            selectedHeader={
                                                formData.headerId
                                                    ? { id: formData.headerId, headerImg: formData.headerImg }
                                                    : null
                                            }
                                            selectedWatermark={
                                                formData.waterMarkId
                                                    ? {
                                                        id: formData.waterMarkId,
                                                        waterMarkImg: formData.waterMarkImg,
                                                    }
                                                    : null
                                            }
                                            customTemplates={customTemplates}
                                            customOption={optionData}
                                            signatureName={sigEstimate}
                                            signatureType={signatureType}
                                            signature={{
                                                padSignature,
                                                uploadSignature,
                                                signatureText
                                            }}
                                            currencyList={currencyList}
                                        />
                                    )}

                                    {formData.templateName === 'modern' && (
                                        <CustomInvoiceImpact
                                            invoice={{
                                                name: "Invoice",
                                                invoiceNumber,
                                                selectedClient,
                                                invoiceDate,
                                                dueDate,
                                                items,
                                                subtotal,
                                                gstTotal,
                                                discountTotal,
                                                total,
                                                logo,
                                                attachments,
                                                paymentInstruction,
                                                comment,
                                                depositAmount: deposit,
                                                terms
                                            }}
                                            logoFile={logo}
                                            photoFiles={attachments}
                                            editInvoiceNumber={editInvoiceNumber}
                                            invoiceNumberInput={invoiceNumberInput}
                                            handleInvoiceNumberInputChange={handleInvoiceNumberInputChange}
                                            handleInvoiceNumberInputBlur={handleInvoiceNumberInputBlur}
                                            handleInvoiceNumberInputKeyDown={handleInvoiceNumberInputKeyDown}
                                            handleEditInvoiceNumber={handleEditInvoiceNumber}
                                            handleTermsChange={handleTermsChange}
                                            value2={value2}
                                            setValue2={setValue2}
                                            onBackToEdit={() => { invoiceId ? setActiveTab('Edit') : setActiveTab('Create') }}
                                            ref={null}
                                            selectedTemp={formData.templateName}
                                            selectedId={
                                                formData.logoId
                                                    ? { id: formData.logoId, logoImage: formData.logoImage }
                                                    : null
                                            }
                                            selectedSize={formData.logoSize}
                                            alignPos={formData.logoPosition}
                                            selectedColour={
                                                formData.colourId
                                                    ? { id: formData.colourId, colourCode: formData.colourCode }
                                                    : null
                                            }
                                            customColour={formData.customColour}
                                            selectedHeader={
                                                formData.headerId
                                                    ? { id: formData.headerId, headerImg: formData.headerImg }
                                                    : null
                                            }
                                            selectedWatermark={
                                                formData.waterMarkId
                                                    ? {
                                                        id: formData.waterMarkId,
                                                        waterMarkImg: formData.waterMarkImg,
                                                    }
                                                    : null
                                            }
                                            customTemplates={customTemplates}
                                            customOption={optionData}
                                            signatureName={sigEstimate}
                                            signatureType={signatureType}
                                            signature={{
                                                padSignature,
                                                uploadSignature,
                                                signatureText
                                            }}
                                            currencyList={currencyList}
                                        />
                                    )}

                                </div>
                            </div>
                            <div className='col-md-8'>
                                <div className='mt-0 minScrollHeight'>
                                    <div className='sub-head'>
                                        <p className='subheading'>Bill To</p>
                                    </div>
                                      <div className='col-lg-12 px-2'>
                                  
                                                                          <div className='email-setup-top ' style={{ display: 'flex', gap: 0, alignItems: 'center' }}>
                                                                              <div className="floating-label-group" style={{ marginBottom: 8, width: '80%', }}>
                                                                                  <label className="floating-label">To</label>
                                                                                  <div className='selectInputUser' style={{ display: 'flex', flexWrap: 'wrap', gap: 4, alignItems: 'center' }}>
                                                                                      {sendToEmails.map((email, idx) => (
                                                                                          <span key={idx} style={{
                                                                                              background: '#e6f0ff',
                                                                                              borderRadius: 12,
                                                                                              padding: '2px 8px',
                                                                                              marginRight: 4,
                                                                                              marginTop: 0,
                                                                                              display: 'flex',
                                                                                              alignItems: 'center'
                                                                                          }}>
                                                                                              {email}
                                                                                              <span
                                                                                                  style={{ marginLeft: 4, cursor: 'pointer', color: '#047FFF' }}
                                                                                                  onClick={() => handleRemoveEmail('to', idx)}
                                                                                              >
                                                                                                  <FontAwesomeIcon icon={faCircleXmark} />
                                                                                              </span>
                                                                                          </span>
                                                                                      ))}
                                                                                      {/* <input type="text" id="billing-add" className="input-form-control input-logo" required /> */}
                                                                                      <input
                                                                                          type="text"
                                                                                          // id="billing-add"
                                                                                          className="input-form-control input-logo inputBorderNone"
                                                                                          required
                                                                                          style={{ minWidth: 120, flex: 1 }}
                                                                                          value={sendToInput}
                                                                                          onChange={e => setSendToInput(e.target.value)}
                                                                                          onKeyDown={e => handleEmailInputKeyDown(e, 'to')}
                                                                                          onBlur={() => handleAddEmail('to', sendToInput)}
                                                                                          placeholder={sendToEmails.length === 0 ? "Enter email" : ""}
                                                                                      />
                                                                                  </div>
                                                                              </div>
                                                                              <div className='ccbc' style={{ width: '20%', display: 'flex', gap: 8, alignItems: 'center', paddingLeft: "20px", marginTop: "16px" }} >
                                                                                  {/* <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginLeft: 8 }}> */}
                                                                                  {!showCc && (
                                                                                      <span
                                                                                          style={{ cursor: 'pointer', color: '#047FFF', fontWeight: 500 }}
                                                                                          onClick={() => setShowCc(true)}
                                                                                      >Cc</span>
                                                                                  )}
                                                                                  {!showBcc && (
                                                                                      <span
                                                                                          style={{ cursor: 'pointer', color: '#047FFF', fontWeight: 500 }}
                                                                                          onClick={() => setShowBcc(true)}
                                                                                      >Bcc</span>
                                                                                  )}
                                                                              </div>
                                                                          </div>
                                  
                                                                          <div className='bcccTop ' style={{ width: "80%" }}>
                                  
                                                                              {showCc && (
                                                                                  <div className="floating-label-group" style={{ marginBottom: 8 }}>
                                                                                      <label className="floating-label">Cc</label>
                                                                                      <div className="selectInputUser" style={{ display: 'flex', flexWrap: 'wrap', gap: 4, alignItems: 'center' }}>
                                                                                          {sendCcEmails.map((email, idx) => (
                                                                                              <span key={idx} style={{
                                                                                                  background: '#e6f0ff',
                                                                                                  borderRadius: 12,
                                                                                                  padding: '2px 8px',
                                                                                                  marginRight: 4,
                                                                                                  marginTop: 0,
                                                                                                  display: 'flex',
                                                                                                  alignItems: 'center'
                                                                                              }}>
                                                                                                  {email}
                                                                                                  <span
                                                                                                      style={{ marginLeft: 4, cursor: 'pointer', color: '#047FFF' }}
                                                                                                      onClick={() => handleRemoveEmail('cc', idx)}
                                                                                                  >
                                                                                                      <FontAwesomeIcon icon={faCircleXmark} />
                                                                                                  </span>
                                                                                              </span>
                                                                                          ))}
                                                                                          <input
                                                                                              type="text"
                                                                                              className="input-form-control input-logo inputBorderNone"
                                                                                              style={{ minWidth: 120, flex: 1 }}
                                                                                              value={sendCcInput}
                                                                                              onChange={e => setSendCcInput(e.target.value)}
                                                                                              onKeyDown={e => handleEmailInputKeyDown(e, 'cc')}
                                                                                              onBlur={() => handleAddEmail('cc', sendCcInput)}
                                                                                              placeholder={sendCcEmails.length === 0 ? "Enter email" : ""}
                                                                                          />
                                                                                      </div>
                                                                                  </div>
                                                                              )}
                                                                              {showBcc && (
                                                                                  <div className="floating-label-group" style={{ marginBottom: 8 }}>
                                                                                      <label className="floating-label">Bcc</label>
                                                                                      <div className="selectInputUser" style={{ display: 'flex', flexWrap: 'wrap', gap: 4, alignItems: 'center' }}>
                                                                                          {sendBccEmails.map((email, idx) => (
                                                                                              <span key={idx} style={{
                                                                                                  background: '#e6f0ff',
                                                                                                  borderRadius: 12,
                                                                                                  padding: '2px 8px',
                                                                                                  marginRight: 4,
                                                                                                  marginTop: 0,
                                                                                                  display: 'flex',
                                                                                                  alignItems: 'center'
                                                                                              }}>
                                                                                                  {email}
                                                                                                  <span
                                                                                                      style={{ marginLeft: 4, cursor: 'pointer', color: '#047FFF' }}
                                                                                                      onClick={() => handleRemoveEmail('bcc', idx)}
                                                                                                  >
                                                                                                      <FontAwesomeIcon icon={faCircleXmark} />
                                                                                                  </span>
                                                                                              </span>
                                                                                          ))}
                                                                                          <input
                                                                                              type="text"
                                                                                              className="input-form-control input-logo inputBorderNone"
                                                                                              style={{ minWidth: 120, flex: 1 }}
                                                                                              value={sendBccInput}
                                                                                              onChange={e => setSendBccInput(e.target.value)}
                                                                                              onKeyDown={e => handleEmailInputKeyDown(e, 'bcc')}
                                                                                              onBlur={() => handleAddEmail('bcc', sendBccInput)}
                                                                                              placeholder={sendBccEmails.length === 0 ? "Enter email" : ""}
                                                                                          />
                                                                                      </div>
                                                                                  </div>
                                                                              )}
                                                                          </div>
                                  
                                                                      </div>
                                    <div className='sub-head'>
                                        <p className='subheading'>Service</p>
                                    </div>
                                    <div className='col-lg-12 col-md-12 col-sm-12'>
                                        <div className="floating-label-group px-2">
                                            <label className="floating-label">Notes</label>
                                            <textarea
                                                type="text"
                                                id="logo"
                                                className="input-form-control"
                                                required
                                                value={sendNotes}
                                                onChange={e => setSendNotes(e.target.value)}
                                            />
                                        </div>
                                    </div>
                                    <div className='sub-head'>
                                        <p className='subheading'>Attachment</p>
                                    </div>
                                    <div className="row px-2">
                                        <div className="col-lg-3">
                                            <div className="card image-card pdfParaMargin">
                                                <div className="card-body">
                                                    {/* Preview PDF is automatically attached */}
                                                    <div>
                                                        <p>
                                                            <FontAwesomeIcon icon={faFilePdf} style={{ fontSize: 60, color: '#d32f2f', marginBottom: 8, width: 60, height: 60 }} /><br />
                                                            estimate_<span>{invoiceNumber}</span>
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        {sendText === "true" && parameter?.attachmentName && <div className="col-lg-3">
                                            <div className="card image-card pdfParaMargin">
                                                <div className="card-body">
                                                    <div>
                                                        <p>
                                                            {
                                                                parameter?.attachmentType.includes("image") ? <FontAwesomeIcon icon={faFileImage} style={{ fontSize: 60, color: '#d32f2f', marginBottom: 8, width: 60, height: 60 }} />
                                                                    : <FontAwesomeIcon icon={faFilePdf} style={{ fontSize: 60, color: '#d32f2f', marginBottom: 8, width: 60, height: 60 }} />
                                                            }
                                                            <br />
                                                            <span>{parameter?.attachmentName}</span>
                                                        </p>
                                                    </div>

                                                    {/* {parameter?.attachmentName?.type} */}
                                                </div>
                                            </div>
                                        </div>}
                                        {attachments.map((img, idx) => (
                                            <div className="col-lg-3" key={idx}>
                                                <div className="card image-card pdfParaMargin">
                                                    <div className="card-body">
                                                        <img
                                                            src={img}
                                                            alt={`Attachment ${idx + 1}`}
                                                            style={{
                                                                width: 80,
                                                                height: 80,
                                                                objectFit: "cover",
                                                                borderRadius: 6,
                                                                border: "1px solid #eee"
                                                            }}
                                                        />
                                                    </div>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>
                            <div className='col-md-4 px-3'>
                                <div className='invoiceHeaderLeft'>
                                    <div className="invoiceSection">
                                        <h5>Estimate</h5>
                                        <div className='invoiceSectionInner'>
                                            {!estimateToEdit?.id && (
                                                <>
                                                    <h6 style={{ margin: 0, display: 'inline-block' }}>
                                                        {/* {console.log(invoiceNumber, "invoiceNumber")} */}
                                                        {optionData.invoicePrifix ? optionData.invoicePrifix + '-' : ''}{!estimateToEdit?.id && editInvoiceNumber ? '' : invoiceNumber}

                                                    </h6>
                                                    {editInvoiceNumber ? (
                                                        <input className='input-form-control'
                                                            type="text"
                                                            value={invoiceNumberInput}
                                                            onChange={handleInvoiceNumberInputChange}
                                                            onBlur={handleInvoiceNumberInputBlur}
                                                            onKeyDown={handleInvoiceNumberInputKeyDown}
                                                            style={{
                                                                width: 60,
                                                                fontSize: 18,
                                                                fontWeight: 600,
                                                                border: '1px solid #047FFF',
                                                                borderRadius: 4,
                                                                padding: '2px 6px'
                                                            }}
                                                            autoFocus />
                                                    ) : (
                                                        <>
                                                            {est?.type === "Create" && <span style={{ marginLeft: 8, cursor: 'pointer' }} onClick={handleEditInvoiceNumber}>
                                                                <FontAwesomeIcon icon={faPenToSquare} />
                                                            </span>}
                                                        </>
                                                    )}
                                                </>
                                            )}
                                            {estimateToEdit?.id && (
                                                <h6 style={{ margin: 0, display: 'inline-block' }}>{optionData.invoicePrifix ? optionData.invoicePrifix + '-' : ''}{invoiceNumber}</h6>
                                            )}
                                        </div>
                                        <p className="unsent">{sentStatus === "sent" ? "Sent" : "Unsent"}</p>
                                    </div>
                                    <div className='invoiceBox'>
                                        <ul className='borderBottom'>
                                            <li>
                                                <p>Date</p>
                                                <span>{formatDate(dueDate)}</span>
                                            </li>
                                        </ul>

                                        <div className="amount">
                                            <p>Sub Total</p>
                                            <h4>
                                                {formatCurrency(subtotal.toFixed(2), currencyList)}
                                            </h4>
                                        </div>
                                        {hasAnyGst && (
                                            <div className="amount">
                                                <p>GST</p>
                                                <h4>
                                                    {formatCurrency(gstTotal, currencyList)}
                                                </h4>
                                            </div>
                                        )}
                                        <ul className="borderBottom">
                                            <li>
                                                <p>Discount</p>
                                                <span style={{ color: "#888" }}>{formatCurrency(discountAmount, currencyList)}</span>
                                            </li>
                                        </ul>
                                        <ul className="borderBottom">
                                            <li>
                                                <p>Total</p>
                                                <span>{formatCurrency(total.toFixed(2), currencyList)}</span>
                                            </li>
                                        </ul>
                                    </div>
                                    <div style={{ marginTop: 16 }}>
                                        <Button className="add-note" onClick={handleSendPdf} disabled={!previewPdfFile} style={{ width: "100%" }}>
                                            Send Estimate
                                        </Button>
                                        <Button className="add-note" onClick={handleDownloadPdf} disabled={!previewPdfFile} style={{ width: "100%" }}>
                                            Download Estimate
                                        </Button>
                                    </div>

                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </div>

            {/* Add Client Modal */}
            <Modal centered show={showClientModal} onHide={handleCloseClientModal}>
                <Modal.Header closeButton>
                    <Modal.Title>Add Client</Modal.Title>
                </Modal.Header>
                <Modal.Body style={{ marginTop: "0px" }}>
                    <div className="mb-3">
                        <div className="floating-label-group mb-2" style={{ position: "relative" }}>
                            <label className="floating-label">Name</label>
                            <input
                                type="text"
                                name="name"
                                className="input-form-control"
                                required
                                autoComplete="off"
                                autoFocus
                                value={clientForm.name}
                                onChange={handleClientFormChange}
                                onFocus={() => {
                                    setShowClientDropdown(true);
                                    if (clientForm.name.trim().length === 0) setClientDropdown(clientList);
                                }}
                                onBlur={() => setTimeout(() => setShowClientDropdown(false), 200)}
                            />
                            {showClientDropdown && clientDropdown.length > 0 && (
                                <ul
                                    className="list-group"
                                    style={{
                                        position: "absolute",
                                        zIndex: 10,
                                        width: "100%",
                                        top: "100%",
                                        left: 0,
                                        maxHeight: 150,
                                        overflowY: "auto",
                                    }}
                                >
                                    {clientDropdown.map((client, idx) => (
                                        <li
                                            key={client.id || idx}
                                            className="list-group-item"
                                            style={{ cursor: "pointer" }}
                                            onMouseDown={() => {
                                                handleClientDropdownSelect(client);
                                            }}
                                        >
                                            <strong>{client.name}</strong>
                                            <div style={{ fontSize: "0.9em", color: "#888" }}>{client.email}</div>
                                        </li>
                                    ))}
                                </ul>
                            )}
                            {clientFormErrors.name && (
                                <div style={{ color: "red", fontSize: 13, marginTop: 2 }}>{clientFormErrors.name}</div>
                            )}
                        </div>
                        <div className="floating-label-group mb-2">
                            <label className="floating-label">Email</label>
                            <input
                                type="email"
                                name="email"
                                className="input-form-control"
                                required
                                value={clientForm.email}
                                onChange={handleClientFormChange}
                            />
                            {clientFormErrors.email && (
                                <div style={{ color: "red", fontSize: 13, marginTop: 2 }}>{clientFormErrors.email}</div>
                            )}
                        </div>
                        <div className="floating-label-group mb-2">
                            <label className="floating-label">Phone</label>
                            <input
                                type="text"
                                name="phone"
                                className="input-form-control"
                                required
                                value={clientForm.phone}
                                onChange={handleClientFormChange}
                                maxLength={10}
                            />
                            {clientFormErrors.phone && (
                                <div style={{ color: "red", fontSize: 13, marginTop: 2 }}>{clientFormErrors.phone}</div>
                            )}
                        </div>
                        <Button
                            variant="primary"
                            className="modal-btn addBtnn"
                            style={{ marginTop: 25 }}
                            onClick={handleAddClientFromModal}
                        >
                            Add
                        </Button>
                    </div>
                </Modal.Body>
            </Modal>

            {/* Add/Edit Item Modal */}
            <Modal centered
                show={show}
                onHide={handleClose}
                onShow={async () => {
                    const result = await dispatch(fetchTaxData());
                    // console.log(result, "tax result");
                    if (result && result.payload && Array.isArray(result.payload.data)) {
                        setTaxRates(result.payload.data);
                    } else {
                        setTaxRates([]);
                    }
                }}
            >
                <Modal.Header closeButton>
                    <Modal.Title>{editItemIndex !== null ? "Edit Item" : "Add Item"}</Modal.Title>
                </Modal.Header>
                <Modal.Body className='mt-0 mb-0'>
                    <div style={{ textAlign: 'center' }}>
                        <button className='add-note' type="button" onClick={handleChooseItemOpen}>
                            <FontAwesomeIcon icon={faSquarePlus} />Choose Multiple
                        </button>
                    </div>
                    <div style={{ textAlign: 'center', margin: '12px 0 0px' }}>Or</div>
                    <div className="row">
                        <div className="col-lg-12">
                            {optionData.itemCode && (
                                <div className="floating-label-group mb-3">
                                    <label className="floating-label">Item Code</label>
                                    <input
                                        type="text"
                                        name="code"
                                        className="input-form-control"
                                        required
                                        value={itemForm.code}
                                        onChange={handleItemFormChange}
                                    />
                                </div>
                            )}
                            <div className="floating-label-group mb-3">
                                <label className="floating-label">Item Name</label>
                                <input
                                    type="text"
                                    name="name"
                                    className="input-form-control"
                                    required
                                    value={itemForm.name}
                                    onChange={handleItemFormChange}
                                />
                                {itemFormErrors.name && (
                                    <div style={{ color: "red", fontSize: 13, marginTop: 2 }}>{itemFormErrors.name}</div>
                                )}
                            </div>

                            <div className="floating-label-group mb-3">
                                <label className="floating-label">Description</label>
                                <textarea
                                    name="description"
                                    className="input-form-control"
                                    value={itemForm.description}
                                    onChange={handleItemFormChange}
                                    rows="3"
                                />
                            </div>
                            <div style={{ display: 'flex', gap: 16, marginBottom: 16 }}>
                                <div style={{ flex: 1 }}>
                                    <div className="floating-label-group">
                                        <label className="floating-label">Rate</label>
                                        <input
                                            type="number"
                                            name="rate"
                                            className="small-input input-form-control"
                                            required
                                            value={itemForm.rate}
                                            onChange={handleItemFormChange}
                                            min="0"
                                        />
                                        {itemFormErrors.rate && (
                                            <div style={{ color: "red", fontSize: 13, marginTop: 2 }}>{itemFormErrors.rate}</div>
                                        )}
                                    </div>
                                </div>
                                <div style={{ flex: 1 }}>
                                    <div className="floating-label-group">
                                        <label className="floating-label">Qty</label>
                                        <input
                                            type="number"
                                            name="quantity"
                                            className="small-input input-form-control"
                                            required
                                            value={itemForm.quantity}
                                            onChange={handleItemFormChange}
                                            min="1"
                                            max="9999999999"
                                        />
                                        {itemFormErrors.quantity && (
                                            <div style={{ color: "red", fontSize: 13, marginTop: 2 }}>{itemFormErrors.quantity}</div>
                                        )}
                                    </div>
                                </div>
                                <div style={{ flex: 1 }}>
                                <div className="floating-label-group payment-type-dropdown">
                                    <label className="floating-label">Unit</label>

                                    <select
                                        className="small-input input-form-control"
                                        value={itemForm.unitTypes}
                                        onChange={(e) => setItemForm({ ...itemForm, unitTypes: e.target.value })}
                                        style={{ minWidth: 120, marginLeft: 0 }}
                                    >
                                        <option value="">Select Unit</option>
                                        {unitTypes.map((unit) => (
                                            <option key={unit.id} value={unit.value}>
                                                {unit.value}
                                            </option>
                                        ))}
                                    </select>

                                     <p className="dropdownIcon">
                                        <img src={IMAGE.dropdownColor}  />
                                    </p>
          
                                </div>
                            </div>
                            </div>



                            {/* GST Section */}
                            <Accordion defaultActiveKey="0">
                                <Accordion.Item eventKey="0">
                                    <Accordion.Header>
                                        <p className='accorheading'>GST, Discount</p>
                                    </Accordion.Header>
                                    <Accordion.Body>
                                        <div style={{ display: 'flex', gap: 16, alignItems: 'center', marginBottom: 16 }}>
                                            <div className="col-lg-12" style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
                                                <div className='checkboxLeft' style={{ display: 'flex', alignItems: 'center' }}>
                                                    <input
                                                        type="checkbox"
                                                        name="gstChecked"
                                                        checked={(itemForm.gstChecked == 'false' || itemForm.gstChecked == false) ? false : true}
                                                        onChange={handleItemGstCheck}
                                                        id="gstCheck"
                                                    />
                                                    <label htmlFor="gstCheck" style={{ marginLeft: 8 }}>GST</label>
                                                </div>
                                                {(itemForm.gstChecked == 'true' || itemForm.gstChecked == true) && (
                                                    <div className="form-group payment-type-dropdown" style={{ margin: 0 }}>
                                                        <select
                                                            className="small-input input-form-control"
                                                            value={itemForm.gstValue}
                                                            onChange={(e) => setItemForm({ ...itemForm, gstValue: e.target.value })}
                                                            style={{ minWidth: 120, marginLeft: 8 }}
                                                        >
                                                            <option value="">Select Rate</option>
                                                            {/* {console.log(taxRates, "tax rates")} */}
                                                            {taxRates.map((rate) => (
                                                                <option key={rate.id} value={rate.percentage}>
                                                                    {rate.percentage}%
                                                                </option>
                                                            ))}
                                                        </select>
                                                         <p className="dropdownIcon drpdwnLable ">
                                                            <img src={IMAGE.dropdownColor}  />
                                                        </p>
          
                                                    </div>
                                                )}
                                            </div>
                                        </div>

                                        {/* Discount Section */}
                                        {/* <div className="col-lg-12 mt-3"> */}
                                        <div style={{ display: 'flex', gap: 16, alignItems: 'center', marginBottom: 16 }}>
                                            <div className='checkboxLeft'>
                                                <input
                                                    type="checkbox"
                                                    name="discountChecked"
                                                    checked={(itemForm.discountChecked == 'false' || itemForm.discountChecked == false) ? false : true}
                                                    onChange={handleItemDiscountCheck}
                                                    id="discountCheck"
                                                />
                                                <label htmlFor="discountCheck" style={{ marginLeft: 8 }}>Discount</label>
                                            </div>
                                            {(itemForm.discountChecked == 'true' || itemForm.discountChecked == true) && (
                                                <div className='checkboxRight' style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                                                    <div className=" payment-type-dropdown" style={{ margin: 0 }}>
                                                    <select
                                                        name="discountType"
                                                        value={itemForm.discountType}
                                                        onChange={handleItemFormChange}
                                                        style={{ height: 47 }}
                                                        className='input-form-control'
                                                    >
                                                        {DISCOUNT_TYPE_OPTIONS.map(opt => (
                                                            <option key={opt.value} value={opt.value}>{opt.label}</option>
                                                        ))}
                                                    </select>

                                                     <p className="dropdownIcon drpdwnLable flatRate">
                                                    <img src={IMAGE.dropdownColor}  />
                                                    </p>
                                                 </div>            
                                                    <input
                                                        type="number"
                                                        name="discountValue"
                                                        className="small-input input-form-control"
                                                        required
                                                        value={itemForm.discountValue}
                                                        onChange={handleItemFormChange}
                                                        min="0"
                                                        style={{ width: 70 }}
                                                    />
                                                    {itemForm.discountType === "percentage" ? <span>%</span> : <span>₹</span>}
                                                </div>
                                            )}
                                        </div>
                                        {/* </div> */}

                                    </Accordion.Body>
                                </Accordion.Item>
                            </Accordion>
                            <button className='modal-btn addBtnn' onClick={handleSaveItem}>
                                {editItemIndex !== null ? "Update" : "Add"}
                            </button>
                        </div>
                    </div>
                </Modal.Body>
            </Modal>

            {/* Choose Item Modal */}
            <Modal centered show={showChooseItemModal} onHide={handleChooseItemClose}>
                <Modal.Header closeButton>
                    <span
                        style={{ cursor: 'pointer', marginRight: 12 }}
                        onClick={handleBackClick}
                    >
                        <FontAwesomeIcon icon={faArrowLeft} />
                    </span>
                    <Modal.Title>Choose Items</Modal.Title>
                </Modal.Header>
                <Modal.Body style={{ marginTop: "0px" }} className="listingSearchMain">
                    {filteredChooseItemList.length === 0 ? (
                        <div>There are no items added yet. <span style={{ cursor: 'pointer', color: '#007bff' }} onClick={handleBackClick}>Click here</span> to add items.</div>
                    ) : (
                        <>
                            <div className="d-flex justify-content-end mb-3 searchCustom">
                                <input
                                    type="text"
                                    className="search-input-retains-placeholder form-control"
                                    style={{
                                        width: "125px",
                                        borderRadius: "12px",
                                        boxShadow: "0 2px 6px rgba(0,0,0,0.1)",
                                        border: "1px solid #ccc",
                                    }}
                                    placeholder="🔍︎ Search here..."
                                    value={itemSearch}
                                    autoFocus
                                    onChange={(e) => setItemSearch(e.target.value)}
                                />
                            </div>
                            <ul className="list-group" style={{ marginBottom: "20px" }}>
                                {filteredChooseItemList.map((item, idx) => {
                                    const checked = !!chooseSelectedItems.find((i) => i.id === item.id);
                                    return (
                                        <li
                                            key={item.id || idx}
                                            className="list-group-item"
                                            style={{
                                                cursor: "pointer",
                                                display: "flex",
                                                alignItems: "center",
                                                justifyContent: "space-between",
                                            }}
                                        // onClick={() => handleChooseItemToggle(item)}
                                        >
                                            <div className="">
                                                <label htmlFor={'itemOfItems' + idx} className='' style={{ display: "flex", gap: "5px", alignItems: "center", cursor: "pointer" }}>
                                                    <input
                                                        type="checkbox"
                                                        id={'itemOfItems' + idx}
                                                        checked={checked}
                                                        onChange={() => handleChooseItemToggle(item)}
                                                        style={{ marginRight: 8 }}
                                                    />
                                                    <div style={{ display: "flex", flexDirection: "column", gap: "2px", justifyContent: "center" }}>
                                                    <strong>{item.name || item.item_name}</strong>
                                                     <span style={{ fontSize: '0.9em', color: '#888', marginLeft: '0 !important' }}>
                                                            {(() => {
                                                                const maxLen = 40;
                                                                const description = item?.item_Description ?? item?.description ?? '';
                                                                return description.length > maxLen
                                                                    ?  description.slice(0, maxLen) + '...'
                                                                    : description;
                                                            })()}
                                                    </span>
                                                    </div>
                                                </label>
                                            </div>
                                            {checked && (
                                                <span
                                                    style={{ color: "#047FFF", cursor: "pointer", marginLeft: 8 }}
                                                    onClick={(e) => {
                                                        e.stopPropagation();
                                                        handleChooseSelectedDelete(item.id);
                                                    }}
                                                ></span>
                                            )}
                                        </li>
                                    );
                                })}
                            </ul>
                        </>
                    )}
                </Modal.Body>
                <Modal.Footer className="pt-0">
                    {filteredChooseItemList.length > 0 && (
                        <Button
                            variant="primary"
                            className="modal-btn addBtnn mt-0 mb-0"
                            onClick={handleChooseItemSave}
                            disabled={chooseSelectedItems.length === 0}
                        >
                            Add
                        </Button>
                    )}
                </Modal.Footer>
            </Modal>

            {/* Discount Modal */}
            <DiscountModal
                isOpen={discountModalOpen}
                onClose={() => setDiscountModalOpen(false)}
                discountType={discountType}
                discountInputValue={discountInputValue}
                setDiscountType={setDiscountType}
                setDiscountInputValue={setDiscountInputValue}
                onSave={handleSaveDiscount}
            />
        </>
    );
};

export default EstimatePending;
