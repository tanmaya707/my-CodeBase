'use-client'
import { IMAGE } from '@/utils/Theme'
import React from 'react'

const AboutVideo = () => {
 
  return (
    <div className='about-us-custom'>
    <div className='container'>
        <div className='about-video'>
       
        {/* <video  controls autoPlay loop muted>
          <source src={IMAGE.agri_vdo} type="video/mp4"/>
        </video> */}
        <div className="abt-img-all">
          <img src={IMAGE.aboutimg} alt='Image broken' className="abt-img"/>
          <img src={IMAGE.utube} alt='Image broken' className="abt-img-vdo"/>
        </div>
        
          <div className='about-video-text'>
            <h3>One Less Thing to worry About</h3>
          </div>

          <div className='about-video-bottom'>
          </div>
          <img src={IMAGE.aboutbg} className='aboutBg' alt='Image broken' />
        </div>
        </div>
    </div>
  )
}

export default AboutVideo
