"use client";
import { useState, useEffect, useRef, useCallback } from "react";
import Link from "next/link";
import { IMAGE } from "@/utils/Theme";
import "./sidebar.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faAngleRight,
  faAngleLeft,
  faSquarePlus,
  faHouse,
  faUsers,
  faFolder,
  faFileInvoiceDollar,
  faChartPie,
  faCalculator,
  faBoxOpen,
  faCircleDollarToSlot,
  faFileZipper,
  faPuzzlePiece,
} from "@fortawesome/free-solid-svg-icons";
import { usePathname, useRouter } from "next/navigation";
import { faProductHunt, faSteamSymbol } from "@fortawesome/free-brands-svg-icons";

const menues = [
  {
    name: "Home",
    icon: faHouse,
    link: "/dashboard",
    pathNames: ["/dashboard"]
  },
  {
    name: "Clients",
    icon: faUsers,
    link: "/client",
    pathNames: ["/client"]
  },
  {
    name: "Projects",
    icon: faFolder,
    link: "/project",
    pathNames: ["/project"]
  },
  {
    name: "Invoice",
    icon: faFileInvoiceDollar,
    link: "/invoice",
    pathNames: ["/invoice", "/addInvoice"]
  },
  {
    name: "Estimate",
    icon: faChartPie,
    link: "/estimate",
    pathNames: ["/estimate"]
  },
  {
    name: "Purchase Order",
    icon: faProductHunt,
    link: "/purchaseOrder",
    pathNames: ["/purchaseOrder"]
  },
  {
    name: "Credit Note",
    icon: faSteamSymbol,
    link: "/credit-note",
    pathNames: ["/credit-note", "/addCreditNote"]
  },
  {
    name: "Expenses",
    icon: faCalculator,
    link: "/expense",
    pathNames: ["/expense"]
  },
  {
    name: "Items",
    icon: faBoxOpen,
    link: "/items",
    pathNames: ["/items"]
  },
  {
    name: "Cashflow",
    icon: faCircleDollarToSlot,
    link: "/clientpayment-options",
    pathNames: ["/clientpayment-options"]
  },
  {
    name: "Reports",
    icon: faFileZipper,
    link: "/reports",
    pathNames: ["/reports"]
  },
  {
    name: "Integrated Apps",
    icon: faPuzzlePiece,
    link: "/integrated-apps",
    pathNames: ["/integrated-apps"]
  }
];

const addLists = [
  { link: '/addInvoice', name: "Invoice" },
  { link: '/estimate/create', name: "Estimate" },
  { link: '/project/create', name: "Project" },
  { link: '/addCreditNote', name: "Credit Note" },
  { link: '/purchaseOrder/create', name: "Purchase Order" },
  { link: '/client/create', name: "Client" },
  { link: '/items', name: "Item" },
  { link: '/expense/create', name: "Expense" },

]

const Sidebar = ({ sidebarOpen, setSideBarOpen }) => {
  // active menu
  const pathName = usePathname();

  useEffect(() => {
    if (pathName != "/dashboard") {
      setSideBarOpen(false);
    } else {
      localStorage.setItem("activeMenu", 'home');
      setSideBarOpen(true);
    }
  }, [pathName]);

  const handleToggle = () => {
    setSideBarOpen((prev) => !prev);
  };

  const isTabActive = useCallback((allPaths) => {
    // console.log("allPaths ::: ", allPaths);
    
    for (let path of allPaths) {
      if (pathName?.includes(path)) return true;
      return false;
    }
  }, [pathName])


  useEffect(() => {
    localStorage.removeItem("activeMenu")
  }, []);

  // Plus icon dropdown and blur
  const [plusShow, setPlusShow] = useState(false);
  const plusClick = () => setPlusShow(!plusShow);
  const dropdownRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setPlusShow(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);


  return (
    <div className={`dashboard-left ${sidebarOpen ? "" : "sidebar-collapse"}`}>
      <div className="menusidebar">
        <div className="menuBox">
          <div className="menuBox-top" ref={dropdownRef}>
            <Link href="#" onClick={plusClick}>
              <span className="icon">
                <FontAwesomeIcon className="add-icon" icon={faSquarePlus} />
              </span>
              <span className="menuText">Create New</span>
            </Link>

            {plusShow && (
              <ul className='clientActivityDropedown' style={{ position: 'absolute', zIndex: 103 }}>
                {addLists?.map((item, id) =>
                  <li onClick={() => setPlusShow(false)} key={`addList-${id}`}><Link href={item?.link}> {item?.name} <img src={IMAGE.plusDrpdown} alt="" /></Link></li>
                )}
              </ul>
            )}
          </div>
          <ul className="menuScroll">
            {menues?.map((menueItem, indx) =>
              <li key={`mebue-${indx}`} className={`${indx & 1 ? "" : "border-btm"}`}>
                <Link
                  href={menueItem?.link}
                  className={isTabActive(menueItem?.pathNames) ? "active" : ""}
                >
                  <span className="icon">
                    <FontAwesomeIcon icon={menueItem?.icon} />
                  </span>
                  <span className="menuText">{menueItem?.name}</span>
                </Link>
              </li>
            )}
          </ul>
        </div>
      </div>
      <div
        onClick={(e) => {
          handleToggle(e);
        }}
      >
        {sidebarOpen ? (
          <FontAwesomeIcon className="toggle-button" icon={faAngleLeft} />
        ) : (
          <FontAwesomeIcon className="toggle-button" icon={faAngleRight} />
        )}
      </div>
    </div>
  );
};

export default Sidebar;
