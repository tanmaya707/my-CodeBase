"use client"
import React, { useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCirclePlus } from '@fortawesome/free-solid-svg-icons';
import { IMAGE } from '@/utils/Theme';
import './middlesection.css';
import UserList from '../userInvoiceList/userList';
import InvoiceList from '../invoiceList/invoiceList';
import ToggleButton from '@/utils/ToggleButton/toggleButton';
import Searchbar from '../searchbar/Searchbar';

const MiddleSection = ({
  label,
  tabs,
  btnlabel,
  itemType,
  activeTag,
  setActiveTag,
  setAddClientForm,
  clients = [], // Default to an empty array
  onEditClient,
  setAddProjectForm,
  projects = [], // Default to an empty array
  onEditProject,
  setAddItemForm,
  items = [], // Default to an empty array
  onEditItem,
  setAddInvoiceForm,
  invoices = [], // Default to an empty array
  onEditInvoice,
  setAddEstimateForm,
  estimates = [], // Default to an empty array
  handleEditEstimate,
  setAddExpenseForm,
  expenses = [], // Default to an empty array
  handleEditExpense
}) => {
  const [value, setValue] = useState(false);
  const [value2, setValue2] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const handleSearch = (term) => {
    setSearchTerm(term);
  };

  const filterItems = (items, term) => {
    if (!term) return items;

    const searchTerm = term.toLowerCase();

    return items.filter(item => {
      // Check all possible name fields
      const nameMatches =
        (item.name && item.name.toLowerCase().includes(searchTerm)) ||
        (item.project_name && item.project_name.toLowerCase().includes(searchTerm)) ||
        (item.item_name && item.item_name.toLowerCase().includes(searchTerm)) ||
        (item.title && item.title.toLowerCase().includes(searchTerm));

      // Check all possible description fields
      const descriptionMatches =
        (item.description && item.description.toLowerCase().includes(searchTerm)) ||
        (item.project_desc && item.project_desc.toLowerCase().includes(searchTerm)) ||
        (item.item_Description && item.item_Description.toLowerCase().includes(searchTerm)) ||
        (item.notes && item.notes.toLowerCase().includes(searchTerm));

      // Also check other potential fields like ID or unique identifiers
      const otherMatches =
        (item.id && item.id.toString().includes(searchTerm)) ||
        (item.code && item.code.toLowerCase().includes(searchTerm));

      return nameMatches || descriptionMatches || otherMatches;
    });
  };

  // Filtered lists based on search term
  const filteredClients = filterItems(clients, searchTerm);
  const filteredProjects = filterItems(projects, searchTerm);
  const filteredItems = filterItems(items, searchTerm);
  const filteredInvoices = filterItems(invoices, searchTerm);
  const filteredEstimates = filterItems(estimates, searchTerm);
  const filteredExpenses = filterItems(expenses, searchTerm);

  return (
    <div className="middle-area">
      <div className='clients'>
        <div className='clientHead'>
          <h2>{label}</h2>
          <div className='icon-group'>
            <Searchbar
              onSearch={handleSearch}
              placeholder={`Search ${label}...`}
            />
            <FontAwesomeIcon className="icons-add" icon={faCirclePlus} />
          </div>
        </div>

        {tabs && tabs.length > 0 && (
          <div className="tag-container">
            {tabs.map((tab, index) => (
              <span
                key={tab.id}
                className={`tag ${activeTag === index ? 'active' : ''}`}
                onClick={() => setActiveTag(index)}
              >
                {tab.name}
              </span>
            ))}
          </div>
        )}

        {itemType === "Items" && (
          <div className="autosave-item">
            <div className="autosave-itemLeft">
              <h5>Autosave New Items <img src={IMAGE.exclamation} alt="" /></h5>
              <p>Add items to the list here if added elsewhere</p>
            </div>
            <div className="autosave-itemRight">
              <ToggleButton
                isToggled={value2}
                onToggle={setValue2}
              />
            </div>
          </div>
        )}

        {itemType !== "Items" && (
          <div className='sort-client'>
            <div>
              <p className='m-3'>2025 sorted by category</p>
            </div>
            <img className="sort-img" src={IMAGE.up_down_arrow} alt="updownarrow" />
          </div>
        )}
      </div>

      {itemType === "Invoice" ? (
        <button className="create-btn" onClick={() => setAddInvoiceForm(true)}>
          {btnlabel}
        </button>
      ) : (
        btnlabel && (!onEditClient || !onEditProject) && (
          label === "Project" ? (
            <button className="create-btn" onClick={() => setAddProjectForm(true)}>
              {btnlabel}
            </button>
          ) : label === "Estimate" ? (
            <button className="create-btn" onClick={() => setAddEstimateForm(true)}>
              {btnlabel}
            </button>
          ) : label === "Expense" ? (
            <button className="create-btn" onClick={() => setAddExpenseForm(true)}>
              {btnlabel}
            </button>
          ) : label === "Items" ? (
            <button className="create-btn" onClick={() => setAddItemForm(true)}>
              {btnlabel}
            </button>
          ) : (
            <button className="create-btn" onClick={() => setAddClientForm(true)}>
              {btnlabel}
            </button>
          )
        )
      )}

      {itemType === "Invoice" && <InvoiceList invoices={filteredInvoices} />}
      {label === "Estimate" && <InvoiceList invoices={filteredEstimates} />}
      {itemType === "Expense" && <InvoiceList invoices={filteredExpenses} />}

      {label === "Project" && <UserList label={label} projectss={filteredProjects} onEditClient={onEditProject} />}
      {label === "Client" && <UserList label={label} clientss={filteredClients} onEditClient={onEditClient} />}
      {itemType === "Items" && <InvoiceList label={label} itemss={filteredItems} onEditItem={onEditItem} />}
    </div>
  );
}

export default MiddleSection;
