"use client";
import React, { useState, useEffect, useRef } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCirclePlus } from "@fortawesome/free-solid-svg-icons";
import { IMAGE } from "@/utils/Theme";
import "./middlesection.css";
import UserList from "../userInvoiceList/userList";
import InvoiceList from "../invoiceList/invoiceList";
import ItemList from "../itemList/itemList";
import ToggleButton from "@/utils/ToggleButton/toggleButton";
import Searchbar from "../searchbar/Searchbar";
import { useRouter } from "next/navigation";

const MiddleSection = ({
  label,
  tabs,
  btnlabel,
  itemType,
  activeTag,
  setActiveTag,
  onEditClient,
  onEditProject,
  setAddItemForm,
  items = [],
  onEditItem,
  invoices = [],
  // onEditInvoice,
  setAddEstimateForm,
  estimates = [],
  handleEditEstimate,
  // setAddExpenseForm,
  createRoute,
  // expenses = [],
  list=[]
  // clients = [],
  // setAddProjectForm,
  // projects = [],
  // handleCreate,
  // handleEditExpense,
  // setAddInvoiceForm,
  // setAddClientForm,
}) => {
  const router = useRouter();

  // useEffect(() => {
  //   console.log("invoices in middle section ::: ", list);
  // }, [list]);

  const [autosaveEnabled, setAutosaveEnabled] = useState(() => {
    const saved = localStorage.getItem("autosaveEnabled");
    return saved === null ? false : JSON.parse(saved);
  });
  const isFirstRender = useRef(true);

  useEffect(() => {
    if (isFirstRender.current) {
      isFirstRender.current = false;
      return;
    }
    localStorage.setItem("autosaveEnabled", JSON.stringify(autosaveEnabled));
  }, [autosaveEnabled]);

  const [searchTerm, setSearchTerm] = useState("");
  const [sortDirection, setSortDirection] = useState("asc");

  const handleSearch = (term) => setSearchTerm(term);

  const toggleSortDirection = () =>
    setSortDirection((prev) => (prev === "asc" ? "desc" : "asc"));

  const filterItems = (items, term) => {
    if (!term) return items;
    const searchTerm = term.toLowerCase();
    return items.filter((item) => {
      const nameMatches =
        (item.name && item.name.toLowerCase().includes(searchTerm)) ||
        (item.project_name &&
          item.project_name.toLowerCase().includes(searchTerm)) ||
        (item.item_name && item.item_name.toLowerCase().includes(searchTerm)) ||
        (item.title && item.title.toLowerCase().includes(searchTerm)) ||
        (item.client && item.client.name.toLowerCase().includes(searchTerm)) ||
        (item.merchant && item.merchant.toLowerCase().includes(searchTerm))

      // Check all possible description fields
      const descriptionMatches =
        (item.description &&
          item.description.toLowerCase().includes(searchTerm)) ||
        (item.project_desc &&
          item.project_desc.toLowerCase().includes(searchTerm)) ||
        (item.item_Description &&
          item.item_Description.toLowerCase().includes(searchTerm)) ||
        (item.notes && item.notes.toLowerCase().includes(searchTerm));

      // Also check other potential fields like ID or unique identifiers
      const otherMatches =
        (item.id && item.id.toString().includes(searchTerm)) ||
        (item.code && item.code.toLowerCase().includes(searchTerm));

      return nameMatches || descriptionMatches || otherMatches;
    });
  };

  const filterExpense = (items, term) => {
    if (!term) return items;

    const searchTerm = term.toLowerCase();

    return items
      .map((catGroup) => {
        // Case 1: Category name matches
        if (
          catGroup.catagory &&
          catGroup.catagory.toLowerCase().includes(searchTerm)
        ) {
          return catGroup;
        }

        // Case 2: Filter expenses by merchant or description
        const filteredExpenses = (catGroup.expenses || []).filter(
          (expense) =>
            (expense.merchant &&
              expense.merchant.toLowerCase().includes(searchTerm)) ||
            (expense.description &&
              expense.description.toLowerCase().includes(searchTerm))
        );

        if (filteredExpenses.length > 0) {
          return {
            ...catGroup,
            expenses: filteredExpenses,
            totalAmount: filteredExpenses.reduce(
              (sum, exp) => sum + (exp.rate || 0),
              0
            ),
          };
        }

        return null;
      })
      .filter(Boolean);
  };

  const filteredExpenses = filterExpense(list, searchTerm);
  const filteredList = filterItems(list, searchTerm);
  // const filteredClients = filterItems(clients, searchTerm);
  // const filteredProjects = filterItems(projects, searchTerm);
  // const filteredEstimates = filterItems(estimates, searchTerm);
  // const filteredExpenses = filterItems(expenses, searchTerm);
  const filteredInvoices = filterItems(invoices, searchTerm);


  let filteredItems = filterItems(items, searchTerm);
  // if (itemType === "Items" && !autosaveEnabled) {
  //   filteredItems = filteredItems.filter((item) => item.unit_code != null);
  // }


  return (
    <div className="col-lg-4 left-container">
      <div className="middle-area">
        <div className="clients-bg">
        <div className="clients">
          <div className="clientHead">
            <h2>{label}</h2>
            <div className="icon-group">
              <Searchbar
                onSearch={handleSearch}
                placeholder={`Search ${label}...`}
              />
              <FontAwesomeIcon className="icons-add" icon={faCirclePlus} onClick={() => router.push(createRoute || "/")} />
            </div>
          </div>

          {tabs && tabs.length > 0 && (
            <div className="tag-container">
              {tabs.map((tab, index) => (
                <span
                  key={tab.id}
                  className={`tag ${activeTag === index ? "active" : ""}`}
                  onClick={() => setActiveTag(index)}
                >
                  {tab.name}
                </span>
              ))}
            </div>
          )}

          {itemType === "Items" && (
            <div className="autosave-item">
              <div className="autosave-itemLeft">
                <h5>
                  Autosave New Items <img src={IMAGE.exclamation} alt="" />
                </h5>
                <p>Add items to the list here if added elsewhere</p>
              </div>
              <div className="autosave-itemRight">
                <ToggleButton
                  isToggled={autosaveEnabled}
                  onToggle={() => setAutosaveEnabled((prev) => !prev)}
                />
              </div>
            </div>
          )}


          {/* {itemType === "Invoice" && (
            <div className="autosave-item">
              <div className="autosave-itemLeft">
                <h5>
                  Sync New Invoices <img src={IMAGE.exclamation} alt="" />
                </h5>
                <p>New invoices will be synced automatically to all connected integrations.</p>
              </div>
              <div className="autosave-itemRight">
                <ToggleButton
                  isToggled={autosaveEnabled}
                  onToggle={() => setAutosaveEnabled((prev) => !prev)}
                />
              </div>
            </div>
          )}

          {itemType === "client" && (
            <div className="autosave-item">
              <div className="autosave-itemLeft">
                <h5>
                  Sync New Clients <img src={IMAGE.exclamation} alt="" />
                </h5>
                <p>New clients will be synced automatically to all connected integrations.</p>
              </div>
              <div className="autosave-itemRight">
                <ToggleButton
                  isToggled={autosaveEnabled}
                  onToggle={() => setAutosaveEnabled((prev) => !prev)}
                />
              </div>
            </div>
          )} */}

          {itemType !== "Items" && (
            <div className="sort-client">
              <div className="sortedCategory">
                <p className="m-3">2025 sorted by category</p>
                <span className="drpdwnImage"><img src={IMAGE.dropdownColor} alt="" /></span>
              </div>
              <img
                className="sort-img"
                src={itemType === "Invoice" ? IMAGE.filterImage : IMAGE.up_down_arrow}
                alt="updownarrow"
                onClick={toggleSortDirection}
                style={{ cursor: "pointer" }}
              />

            </div>
          )}
        </div>
        </div>
        {(itemType != "Invoice" &&
          btnlabel) &&
          (!onEditClient || !onEditProject) &&
          // (!projects && label === "Project" ? (
          //   <button
          //     className="create-btn"
          //     onClick={() => setAddProjectForm(true)}
          //   >
          //     {btnlabel}
          //   </button>
          // ) : 
          
          ((!estimates && label === "Estimate") ? (
            <button
              className="create-btn"
              onClick={() => setAddEstimateForm(true)}
            >
              {btnlabel}
            </button>
          ) 
          // : /*!expenses &&*/ label === "Expense" ? (
          //   <button
          //     className="create-btn"
          //     onClick={() => setAddExpenseForm(true)}
          //   >
          //     {btnlabel}
          //   </button>
          // )
           : !items && label === "Items" ? (
            <button className="create-btn" onClick={() => setAddItemForm(true)}>
              {btnlabel}
            </button>
          ) 
          // : clients?.length === 0 && label === "Client" ? (
          //   <button
          //     className="create-btn"
          //     onClick={() => router.push(createRoute)}
          //   >
          //     {btnlabel}
          //   </button>
          // )
           : (
            <p></p>
          ))}

        {itemType === "Invoice" && (
          <InvoiceList
            label={itemType}
            itemss={filteredInvoices}
            // onEditInvoice={onEditInvoice}
            sortDirection={sortDirection}
            route="/invoice/"
          />
        )}
        {(itemType === "Credit Note" || itemType === "Purchase Order") && (
          <InvoiceList
            label={itemType}
            itemss={filteredList}
            // onEditInvoice={onEditInvoice}
            sortDirection={sortDirection}
            route={itemType === "Credit Note" ? "/credit-note/" : "/purchaseOrder/"}
          />
        )}
        {label === "Estimate" && (
          <InvoiceList
            label={itemType}
            itemss={filteredList}
            onEditEstimate={handleEditEstimate}
            sortDirection={sortDirection}
            route="/estimate/"
          />
        )}
        {itemType === "Expense" && (
          <UserList
            label={label}
            expensess={filteredExpenses}
            sortDirection={sortDirection}
          />
        )}

        {label === "Project" && (
          <UserList
            label={label}
            projectss={filteredList}
            onEditProject={onEditProject}
            sortDirection={sortDirection}
          />
        )}
        {label === "Client" && (
          <UserList
            label={label}
            clientss={filteredList}
            // onEditClient={onEditClient}
            sortDirection={sortDirection}
          />
        )}
        {itemType === "Items" && (
          <ItemList
            label={label}
            itemss={filteredItems}
            onEditItem={onEditItem}
            sortDirection={sortDirection}
          />
        )}
      </div>
    </div>
  );
};

export default MiddleSection;
