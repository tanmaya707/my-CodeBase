import React, { useEffect, useMemo, useState } from 'react';
import Accordion from 'react-bootstrap/Accordion';
import Dropdown from 'react-bootstrap/Dropdown';
import './list.css';
import moment from 'moment';
import { fetchAppointmentData, updateAppointmentData, deleteAppointmentData, addAppointmentData } from "@/redux/slices/dataSlice";
import { useDispatch, useSelector } from 'react-redux';

const getRangeIndexes = (appointments) => {
    const today = moment.utc();
    for (let i = 0; i < appointments.length; i++) {
        const range = appointments[i].range;
        const [start, end] = range.split(' - ');
        const year = today.year();
        const startDate = moment.utc(`${start}${year}`, 'DDMMMYYYY');
        const endDate = moment.utc(`${end}${year}`, 'DDMMMYYYY').endOf('day');
        if (today.isBetween(startDate, endDate, null, '[]')) {
            return i.toString().trim();
        }
    }
    return "0";
};

const AppointmentList = ({ active, year, onEditAppointment }) => {
    const dispatch = useDispatch();
    const { appointments } = useSelector((state) => state.dataReducer);
    const [defaultActiveKey, setDefaultActiveKey] = useState(null);

    useEffect(() => {
        const payload = {
            month: active ?? 1,
            year: year ?? new Date().getFullYear()
        };
        dispatch(fetchAppointmentData(payload));
    }, [dispatch, active, year]);

    useEffect(() => {
        if (!appointments || appointments.length === 0) setDefaultActiveKey("0");
        const activeIndex = getRangeIndexes(appointments);
        setDefaultActiveKey(activeIndex);
    }, [appointments]);

    const handleDelete = (id) => {
        const deleteAction = dispatch(deleteAppointmentData({ id }));
        if (deleteAction) {
            window.location.href = '/appointment';
        }

    };

    const handleEdit = (appt) => {
        // Call addAppointmentData with id and prefill data in form
        window.location.href = `/addappointment?id=${appt.id}`;
        // dispatch(addAppointmentData({ id: appt.id, ...appt }));
        // if (onEditAppointment) onEditAppointment(appt);
    };

    return (
        <div className='appointment-accordian container'>
            <Accordion activeKey={defaultActiveKey}>
                {appointments && appointments.map((appointment, index) => (
                    <Accordion.Item eventKey={index.toString()} key={index} onClick={() => setDefaultActiveKey(index?.toString())}>
                        <Accordion.Header>
                            <div className='list-count-header'>
                                <span>{appointment.range}</span>
                                <span className="" style={{
                                    display: 'inline-flex',
                                    alignItems: 'center',
                                    marginLeft: 5,
                                    justifyContent: 'center',
                                    width: 15,
                                    height: 15,
                                    borderRadius: '100%',
                                    background: '#007bff',
                                    color: '#fff',
                                    fontWeight: 600,
                                    fontSize: 10,
                                    position: "absolute",
                                    top: 7,
                                }}>
                                    {appointment.appointments.length.toString()}
                                </span>
                            </div>
                        </Accordion.Header>
                        <Accordion.Body>
                            <table className="schedule-grid">
                                <thead>
                                    <tr>
                                        <th style={{ minWidth: "30px", paddingLeft: "20px" }}>Date</th>
                                        <th style={{ minWidth: "150px" }}>Client</th>
                                        <th>Time</th>
                                        <th>Location</th>
                                        <th>ETA</th>
                                        <th style={{ width: "40px" }}></th>
                                    </tr>
                                </thead>
                                <tbody className='table-content'>
                                    {appointment.appointments.length > 0 ? (
                                        appointment.appointments.map((appt, apptIndex) => {
                                            const startTime = moment(appt.start_time, 'HH:mm');
                                            const endTime = moment(appt.end_time, 'HH:mm');
                                            let durationMinutes = endTime.diff(startTime, 'minutes');
                                            if (durationMinutes < 0) {
                                                durationMinutes += 24 * 60;
                                            }
                                            const hours = Math.floor(durationMinutes / 60);
                                            const minutes = durationMinutes % 60;
                                            const durationStr =
                                                (hours > 0 ? `${hours} hr${hours > 1 ? 's' : ''}` : '') +
                                                (hours > 0 && minutes > 0 ? ' ' : '') +
                                                (minutes > 0 ? `${minutes} min` : '') || '0 min';
                                            return (
                                                <tr className='table-row' key={apptIndex}>
                                                    <td>
                                                        <div className="date-cell">
                                                            <span className="date-number">{moment(appt.start_date).utc().date().toString()}</span>
                                                            <span className="date-month">{moment(appt.start_date).utc().format('MMM')}</span>
                                                        </div>
                                                    </td>
                                                    <td className="client-name">{appt?.client?.name}</td>
                                                    <td className="location">{appt.start_time} - {appt?.end_time}</td>
                                                    <td className="location">{appt.location}</td>
                                                    <td className="eta">{durationStr}</td>
                                                    <td>
                                                        <Dropdown align="end">
                                                            <Dropdown.Toggle variant="link" bsPrefix="action-dot-btn" style={{ padding: 0 }}>
                                                                <span style={{ fontSize: 20, cursor: 'pointer' }}>⋮</span>
                                                            </Dropdown.Toggle>
                                                            <Dropdown.Menu>
                                                                <Dropdown.Item onClick={() => handleEdit(appt)}>Edit</Dropdown.Item>
                                                                <Dropdown.Item onClick={() => handleDelete(appt.id)}>Delete</Dropdown.Item>
                                                            </Dropdown.Menu>
                                                        </Dropdown>
                                                    </td>
                                                </tr>
                                            );
                                        })
                                    ) : (
                                        <tr>
                                            <td colSpan="6" style={{ textAlign: 'center' }}>No appointments available</td>
                                        </tr>
                                    )}
                                </tbody>
                            </table>
                        </Accordion.Body>
                    </Accordion.Item>
                ))}
            </Accordion>
        </div>
    );
};

export default AppointmentList;
