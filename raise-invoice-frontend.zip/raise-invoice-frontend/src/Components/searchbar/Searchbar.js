// Searchbar.js
"use client"
import React, { useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import "./Searchbar.css";
import { faMagnifyingGlass, faXmark } from '@fortawesome/free-solid-svg-icons';

const Searchbar = ({ onSearch }) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [isOpen, setIsOpen] = useState(false);

    const handleInputChange = (e) => {
        const value = e.target.value;
        setSearchTerm(value);
        onSearch(value); // Call the onSearch prop with the current input value
    };

    const openSearch = () => {
        setIsOpen(true);
    };

    const closeSearch = () => {
        setIsOpen(false);
        setSearchTerm('');
          // onSearch(''); // Clear the search when closing
    };

    return (
        <>
            <FontAwesomeIcon onClick={openSearch} className="icon-magnify" icon={faMagnifyingGlass} />
            {isOpen && (
                <div className="searchbarContent">
                    <form onSubmit={(e) => e.preventDefault()}>
                        <FontAwesomeIcon onClick={closeSearch} className='crossMark' icon={faXmark} />
                        <input type="text" value={searchTerm} onChange={handleInputChange} />
                        <button type="submit"><FontAwesomeIcon className='magnifingGlass' icon={faMagnifyingGlass} /></button>
                    </form>
                </div>
            )}
        </>
    );
};

export default Searchbar;
