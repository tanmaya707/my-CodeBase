import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faAngleDown } from '@fortawesome/free-solid-svg-icons';

const DropdownIndicator = (props) => {
    const {
        children = <FontAwesomeIcon icon={faAngleDown} />,  // fallback icon
        innerRef,
        innerProps,
    } = props;
    return (
        <>
            <div ref={innerRef} {...innerProps} style={{ padding: '0 10px', display: 'none', alignItems: 'center' }}>
                {children}
            </div>
        </>
    );
};

export default DropdownIndicator