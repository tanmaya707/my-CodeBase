"use client";
import React, { useState, useRef, useEffect } from "react";
import Accordion from "react-bootstrap/Accordion";
import Pageheader from "@/utils/pageheader";
import { useRouter } from 'next/navigation';
import "../../app/general.css";
import "./newexpense.css"; 
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faAngleDown, faCalendarDays, faTrash ,faXmark} from "@fortawesome/free-solid-svg-icons";
import { createExpenseData, updateExpenseData, fetchClientData, fetchClientProjectData, getExpenseData } from '@/redux/slices/dataSlice';
import { IMAGE } from "@/utils/Theme";
import Calendar from "react-calendar";
import { useDispatch } from "react-redux";
import { toast } from 'react-toastify';


const categories = [
    { value: "", label: "Select Category" },
    { value: "accommodation", label: "Accommodation" },
    { value: "advertising", label: "Advertising" },
    { value: "airfare", label: "Airfare" },
    { value: "carrental", label: "Car Rental" },
    { value: "communications", label: "Communications" },
    { value: "other", label: "Other" }
];

const NewExpense = ({ expenseToEdit }) => {
    const dispatch = useDispatch();
    const router = useRouter();
    const fileInputRef = useRef(null);

    const [form, setForm] = useState({
        clientId: expenseToEdit?.clientId || "",
        projectId: expenseToEdit?.projectId || "",
        date: expenseToEdit?.date ? new Date(expenseToEdit.date) : new Date(),
        merchant: expenseToEdit?.merchant || "",
        catagory: expenseToEdit?.catagory || "",
        rate: expenseToEdit?.rate || "",
        tax: expenseToEdit?.tax || "",
        tip: expenseToEdit?.tip || "",
        type: expenseToEdit?.type || "Goods",
        SAC: expenseToEdit?.SAC || "",
        HSN: expenseToEdit?.HSN || "",
        status: expenseToEdit?.status || 1,
        profileImage: expenseToEdit?.profileImage || "",
        description: expenseToEdit?.description || "",
    });

    const [activeTab, setActiveTab] = useState(form.type === "Service" ? "tab2" : "tab1");
    const [showCalendarStart, setShowCalendarStart] = useState(false);
    const [imagePreview, setImagePreview] = useState(expenseToEdit?.profileImage || "");
    const [imageFile, setImageFile] = useState(null);
    const [imageName, setImageName] = useState("");
    const [clients, setClients] = useState([]);
    const [projects, setProjects] = useState([]);
    const [loadingClients, setLoadingClients] = useState(false);
    const [loadingProjects, setLoadingProjects] = useState(false);
    const [errors,  setErrors] = useState({})
    // Fetch clients on mount
    useEffect(() => {
        setLoadingClients(true);
        dispatch(fetchClientData())
            .unwrap()
            .then((data) => {
                // console.log("Fetched Clients: ", data);
                setClients(data || []);
            })
            .catch(() => setClients([]))
            .finally(() => setLoadingClients(false));
    }, [dispatch]);

    // Add these states
    // const [unsaved, setUnsaved] = useState(false);
    // const [modalType, setModalType] = useState('reload');
    // const [showModal, setShowModal] = useState(false);

    // // Track unsaved changes
    // useEffect(() => {
    //     if (!expenseToEdit) {
    //     const hasUnsavedChanges =
    //             form.merchant ||
    //             form.catagory ||
    //             form.rate ||
    //             form.tax ||
    //             form.tip ||
    //             form.description ||
    //             form.HSN ||
    //             form.SAC ||
    //             form.clientId ||
    //             form.projectId ||
    //             imageFile
    //     setUnsaved(hasUnsavedChanges);
    //     } else {
    //         setUnsaved(false);
    //     }
    // }, [form, imageFile, expenseToEdit]);

    // // Handle browser/tab close
    // useEffect(() => {
    //     const handleBeforeUnload = (e) => {
    //         if (!expenseToEdit && unsaved) {
    //             e.preventDefault();
    //             e.returnValue = '';
    //             setModalType('close');
    //             setShowModal(true);
    //             return '';
    //         }
    //     };
    //     window.addEventListener('beforeunload', handleBeforeUnload);
    //     return () => window.removeEventListener('beforeunload', handleBeforeUnload);
    // }, [unsaved, expenseToEdit]);

    // // Intercept reload (F5 or Ctrl+R)
    // useEffect(() => {
    //     const handleKeyDown = (e) => {
    //         if (!expenseToEdit && unsaved && (e.key === 'F5' || (e.ctrlKey && e.key === 'r'))) {
    //             e.preventDefault();
    //             setModalType('reload');
    //             setShowModal(true);
    //         }
    //     };
    //     window.addEventListener('keydown', handleKeyDown);
    //     return () => window.removeEventListener('keydown', handleKeyDown);
    // }, [unsaved, expenseToEdit]);

    // Fetch projects when clientId changes
    useEffect(() => {
        if (form.clientId) {
            setLoadingProjects(true);
            const data = { client_id: form.clientId };
            dispatch(fetchClientProjectData(data))
                .unwrap()
                .then((data) => setProjects(data || []))
                .catch(() => setProjects([]))
                .finally(() => setLoadingProjects(false));
        } else {
            setProjects([]);
        }
    }, [dispatch, form.clientId]);

    // Reset form if editing
    useEffect(() => {
        if (expenseToEdit) {
            setForm({
                clientId: expenseToEdit?.clientId || "",
                projectId: expenseToEdit?.projectId || "",
                date: expenseToEdit?.date ? new Date(expenseToEdit.date) : new Date(),
                merchant: expenseToEdit?.merchant || "",
                catagory: expenseToEdit?.catagory || "",
                rate: expenseToEdit?.rate || "",
                tax: expenseToEdit?.tax || "",
                tip: expenseToEdit?.tip || "",
                type: expenseToEdit?.type || "Goods",
                SAC: expenseToEdit?.SAC || "",
                HSN: expenseToEdit?.HSN || "",
                status: expenseToEdit?.status || 1,
                profileImage: expenseToEdit?.image || "",
                description: expenseToEdit?.description || "",
            });
            setActiveTab(expenseToEdit?.type === "Service" ? "tab2" : "tab1");
            setImagePreview(expenseToEdit?.profileImage || "");
            setImageFile(null);
            setImageName(expenseToEdit?.image || "");
        }
    }, [expenseToEdit]);

    const handleChange = (e) => {
        setErrors({})
        const { name, value } = e.target;
        setForm((prev) => ({
            ...prev,
            [name]: value,
            ...(name === "clientId" ? { projectId: "" } : {}) // Reset projectId if client changes
        }));
    };

    const handleDateChange = (date) => {
        setForm((prev) => ({ ...prev, date }));
        setShowCalendarStart(false);
    };

    const handleTabChange = (tabId) => {
        setActiveTab(tabId);
        setForm((prev) => ({
            ...prev,
            type: tabId === "tab1" ? "Goods" : "Service",
            HSN: tabId === "tab1" ? prev.HSN : "",
            SAC: tabId === "tab2" ? prev.SAC : "",
        }));
    };

    const handleImageUpload = (e) => {
        const file = e.target.files[0];
        if (file) {
            setImageFile(file);
            setImagePreview(URL.createObjectURL(file));
            setImageName(file.name);
            setForm((prev) => ({ ...prev, profileImage: file }));
        }
    };

    const handleImageRemove = () => {
        setImageFile(null);
        setImagePreview("");
        setImageName("");
        setForm((prev) => ({ ...prev, profileImage: "" }));
        if (fileInputRef.current) fileInputRef.current.value = "";
    };

    const saveExpense = async (e) => {
        e.preventDefault();
        if (!form.merchant) {
            setErrors(prev => ({...prev, merchant : "Please fill up this field"}))
            
        }

        if (!form.catagory ) {
            setErrors(prev => ({...prev, catagory : "Please select category"}))
            
        }
        if (!form.rate) {
            setErrors(prev => ({...prev, rate : "Please provide rate"}))
            
        }
        if (!form.tax ) {
            setErrors(prev => ({...prev, tax : "Please provide tax"}))
            
        }
        if (!form.tip) {
            setErrors(prev => ({...prev, tip: "Please provide the tip"}))
            
        }
        if (!form.description) {
            setErrors(prev => ({...prev, description : "Please fill up this description"}))
            
        }
        if (!form.merchant || !form.catagory || !form.rate || !form.tax || !form.tip || !form.description) {
            return;
        }

        const formData = new FormData();
        Object.entries(form).forEach(([key, value]) => {
            if (key === "date") {
                formData.append(key, value.toISOString());
            } else if (key === "profileImage" && imageFile) {
                formData.append(key, imageFile);
            } else {
                formData.append(key, value);
            }
        });

        try {
            if (expenseToEdit && expenseToEdit.id) {
                formData.append("id", expenseToEdit.id)
                await dispatch(updateExpenseData(formData)).unwrap();
                toast.success("Expense updated successfully!");
            } else {
                await dispatch(createExpenseData(formData)).unwrap();
                toast.success("Expense created successfully!");
            }
            dispatch(getExpenseData())
            router.push('/expense');
        } catch (error) {
            toast.error(error || 'Failed to create expense');
        }
    };

    return (
        <div className="communication-container fixHeaderContainer">
            <Pageheader label={expenseToEdit ? "Edit Expense" : "Add Expense"} handleSave={saveExpense} />
            <div className="contentArea-inner form-input-label">
                <Accordion defaultActiveKey="0">
                    <Accordion.Item eventKey="0">
                        <Accordion.Header>
                            <p className="accorheading">Attachment</p>
                        </Accordion.Header>
                        <Accordion.Body>
                            <div style={{ display: "flex", alignItems: "center", gap: "1rem", justifyContent : "center", color: "#047FFF" }}>
                                {!imageName ? (
                                    <button
                                        className="choose-contact"
                                        type="button"
                                        onClick={() => fileInputRef.current.click()}
                                    >
                                        Upload photo
                                        <img className="upload-img" src={IMAGE.upload} alt="upload" />
                                    </button>
                                ) : (
                                    <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
                                        <span style={{ fontWeight: 500 }}>{imageName}</span>
                                        <button
                                            type="button"
                                            style={{
                                                background: "transparent",
                                                border: "none",
                                                cursor: "pointer"
                                            }}
                                            onClick={handleImageRemove}
                                            title="Remove image"
                                        >
                                            {/* <FontAwesomeIcon icon={faTrash} color="#d00" /> */}

                                            <FontAwesomeIcon
                                            className="picCancel"
                                            icon={faXmark}
                                            // onClick={handleRemoveImage}
                                            />

                                        </button>
                                    </div>
                                )}
                                <input
                                    type="file"
                                    accept="image/*"
                                    style={{ display: "none" }}
                                    ref={fileInputRef}
                                    onChange={handleImageUpload}
                                />
                                {/* {imagePreview && (
                                    <div style={{ position: "relative" }}>
                                        <img
                                            src={imagePreview}
                                            alt="Preview"
                                            style={{ width: 60, height: 60, objectFit: "cover", borderRadius: 8 }}
                                        />
                                    </div>
                                )} */}
                            </div>
                        </Accordion.Body>
                    </Accordion.Item>
                </Accordion>

                <Accordion defaultActiveKey="0">
                    <Accordion.Item eventKey="0">
                        <Accordion.Header>
                            <p className='accorheading'>Details</p>
                        </Accordion.Header>
                        <Accordion.Body>
                            <div className='row'>
                                <div className='col-lg-12 col-md-12 col-sm-12'>
                                    <div className="row mb-4">
                                        <div className="col-lg-12 col-md-12 col-sm-12">
                                            <div className="d-flex flex-wrap gap-4 align-items-center">
                                                <div className="goodsServiceLeft d-flex align-items-center">
                                                    <div className='tabHeading'>Type of Expense</div>
                                                </div>
                                                <div className='goodsService d-flex align-items-center gap-4'>
                                                    <label className="d-flex align-items-center cursor-pointer">
                                                        <input
                                                            type="radio"
                                                            name="tabs"
                                                            value="tab1"
                                                            checked={activeTab === 'tab1'}
                                                            onChange={() => handleTabChange('tab1')}
                                                            className="me-2"
                                                            style={{ cursor: 'pointer' }}
                                                        />
                                                        <span>Goods</span>
                                                    </label>
                                                    <label className="d-flex align-items-center cursor-pointer">
                                                        <input
                                                            type="radio"
                                                            name="tabs"
                                                            value="tab2"
                                                            checked={activeTab === 'tab2'}
                                                            onChange={() => handleTabChange('tab2')}
                                                            className="me-2"
                                                            style={{ cursor: 'pointer' }}
                                                        />
                                                        <span>Service</span>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 col-sm-12">
                                            {activeTab === 'tab1' && (
                                                <div className="row pb-3 rounded ">
                                                    <div className="col-lg-6 col-md-6 col-sm-12">
                                                        <div className="floating-label-group">
                                                            <input
                                                                type="text"
                                                                name="HSN"
                                                                className="input-form-control"
                                                                required
                                                                value={form.HSN}
                                                                onChange={handleChange}
                                                            />
                                                            <label className="floating-label">HSN</label>
                                                        </div>
                                                    </div>
                                                    <div className='col-lg-6 col-md-6 col-sm-12'>
                                                        <div className='form-group mb-3'>
                                                            <input
                                                                type="text"
                                                                name="date"
                                                                className='input-form-control date-time'
                                                                placeholder='Date'
                                                                value={form.date.toLocaleDateString()}
                                                                readOnly
                                                                onClick={() => setShowCalendarStart(!showCalendarStart)}
                                                            />
                                                            <FontAwesomeIcon
                                                                className="point-img"
                                                                icon={faCalendarDays}
                                                                onClick={() => setShowCalendarStart(!showCalendarStart)}
                                                            />
                                                            {showCalendarStart && (
                                                                <Calendar
                                                                    onChange={handleDateChange}
                                                                    value={form.date}
                                                                />
                                                            )}
                                                        </div>
                                                    </div>
                                                </div>
                                            )}
                                            {activeTab === 'tab2' && (
                                                <div className="row pb-3 rounded ">
                                                    <div className="col-lg-6 col-md-6 col-sm-12">
                                                        <div className="floating-label-group">
                                                            <input
                                                                type="text"
                                                                name="SAC"
                                                                className="input-form-control"
                                                                required
                                                                value={form.SAC}
                                                                onChange={handleChange}
                                                            />
                                                            <label className="floating-label">SAC</label>
                                                        </div>
                                                    </div>
                                                    <div className='col-lg-6 col-md-6 col-sm-12'>
                                                        <div className='form-group mb-3'>
                                                            <input
                                                                type="text"
                                                                name="date"
                                                                className='input-form-control date-time'
                                                                placeholder='Date'
                                                                value={form.date.toLocaleDateString()}
                                                                readOnly
                                                                onClick={() => setShowCalendarStart(!showCalendarStart)}
                                                            />
                                                            <FontAwesomeIcon
                                                                className="point-img"
                                                                icon={faCalendarDays}
                                                                onClick={() => setShowCalendarStart(!showCalendarStart)}
                                                            />
                                                            {showCalendarStart && (
                                                                <Calendar
                                                                    onChange={handleDateChange}
                                                                    value={form.date}
                                                                />
                                                            )}
                                                        </div>
                                                    </div>
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                </div>
                                <div className='col-lg-6 col-md-6 col-sm-12 text-start mb-3'>
                                    <div className="floating-label-group">
                                        <input
                                            type="text"
                                            name="merchant"
                                            className="input-form-control"
                                            required
                                            value={form.merchant}
                                            onChange={handleChange}
                                        />
                                        <label className="floating-label">Merchant</label>
                                    </div>
                                    {errors?.merchant && <small style={{color : "red", fontSize : "12px", paddingInline : "10px", marginBlock: "5px"}}>{errors?.merchant}</small>}
                                </div>
                                <div className='col-lg-6 col-md-6 col-sm-12 mb-3 text-start mb-3'>
                                    <div className='payment-type-dropdown'>
                                        <select
                                            className="payment-terms"
                                            name="catagory"
                                            value={form.catagory}
                                            onChange={handleChange}
                                        >
                                            {categories.map(cat => (
                                                <option key={cat.value} value={cat.value}>
                                                    {cat.label}
                                                </option>
                                            ))}
                                        </select>
                                        <p className="dropdownIcon">
                                            <img className="upload-img" src={IMAGE.dropdownColor} alt="upload" />
                                        </p>
                                    </div>
                                    {errors?.catagory && <small style={{color : "red", fontSize : "12px", paddingInline : "10px", marginBlock: "5px"}}>{errors?.catagory}</small>}
                                </div>
                                <div className='col-lg-4 col-md-6 col-sm-12 text-start mb-3'>
                                    <div className="phone-input">
                                        <div className="floating-label-group">
                                            <input
                                                type="text"
                                                name="rate"
                                                className="small-input"
                                                required
                                                value={form.rate}
                                                onChange={handleChange}
                                            />
                                            <label className="small-input-floating">Rate</label>
                                        </div>
                                        <div className="smallinput-divider"></div>
                                        <div className="country-code-small">$ <FontAwesomeIcon icon={faAngleDown} className='phone-angle' /></div>
                                    </div>
                                    {errors?.rate && <small style={{color : "red", fontSize : "12px", paddingInline : "10px", marginBlock: "5px"}}>{errors?.rate}</small>}
                                </div>
                                <div className='col-lg-4 col-md-6 col-sm-12 text-start mb-3'>
                                    <div className="phone-input">
                                        <div className="floating-label-group">
                                            <input
                                                type="text"
                                                name="tax"
                                                className="small-input"
                                                required
                                                value={form.tax}
                                                onChange={handleChange}
                                            />
                                            <label className="small-input-floating">Tax</label>
                                        </div>
                                        <div className="smallinput-divider"></div>
                                        <div className="country-code-small">$ <FontAwesomeIcon icon={faAngleDown} className='phone-angle' /></div>
                                    </div>
                                    {errors?.tax && <small style={{color : "red", fontSize : "12px", paddingInline : "10px", marginBlock: "5px"}}>{errors?.tax}</small>}
                                </div>
                                <div className='col-lg-4 col-md-6 col-sm-12 text-start mb-3'>
                                    <div className="phone-input ">
                                        <div className="floating-label-group">
                                            <input
                                                type="text"
                                                name="tip"
                                                className="small-input"
                                                required
                                                value={form.tip}
                                                onChange={handleChange}
                                            />
                                            <label className="small-input-floating">Tip</label>
                                        </div>
                                        <div className="smallinput-divider"></div>
                                        <div className="country-code-small">$ <FontAwesomeIcon icon={faAngleDown} className='phone-angle' /></div>
                                    </div>
                                    {errors?.tip && <small style={{color : "red", fontSize : "12px", paddingInline : "10px", marginBlock: "5px"}}>{errors?.tip}</small>}
                                </div>
                                <div className='col-lg-12 col-md-12 col-sm-12 text-start mb-3'>
                                    <div className="floating-label-group">
                                        <textarea
                                            type="text"
                                            name="description"
                                            className="input-form-control"
                                            required
                                            value={form.description}
                                            onChange={handleChange}
                                        />
                                        <label className="floating-label">Description</label>
                                    </div>
                                    {errors?.description && <small style={{color : "red", fontSize : "12px", paddingInline : "10px"}}>{errors?.description}</small>}
                                </div>
                            </div>
                        </Accordion.Body>
                    </Accordion.Item>
                </Accordion>

                <Accordion defaultActiveKey="0">
                    <Accordion.Item eventKey="0">
                        <Accordion.Header>
                            <p className='accorheading'>Project</p>
                        </Accordion.Header>
                        <Accordion.Body>
                            <div className='row ' style={{ width: '100%', alignItems: 'center', gap: '0px' }}>
                                <div className='col-lg-6 col-md-6 col-sm-12'>
                                        <div className="payment-type-dropdown">
                                            <select
                                                name="clientId"
                                                className="payment-terms"
                                                required
                                                value={form.clientId}
                                                onChange={handleChange}
                                            >
                                                <option value="">Select Client</option>
                                                {loadingClients && <option>Loading...</option>}
                                                {clients && clients.data?.map((client) => (
                                                    <option key={client.id || client._id} value={client.id || client._id}>
                                                        {client.name || client.clientName}
                                                    </option>
                                                ))}
                                            </select>
                                              <p className="dropdownIcon">
                                            <img className="upload-img" src={IMAGE.dropdownColor} alt="upload" />
                                        </p>
                                        </div>
                                </div>
                                <div className='col-lg-6 col-md-6 col-sm-12'>
                                        <div className="payment-type-dropdown">
                                            <select
                                                name="projectId"
                                               className="payment-terms"
                                                required
                                                value={form.projectId}
                                                onChange={handleChange}
                                                disabled={!form.clientId || loadingProjects}
                                            >
                                                <option value="">Select Project</option>
                                                {loadingProjects && <option>Loading...</option>}
                                                {projects && projects.data?.map((project) => (
                                                    <option key={project.id || project._id} value={project.id || project._id}>
                                                        {project.project_name || project.project_desc }
                                                    </option>
                                                ))}
                                            </select>
                                                <p className="dropdownIcon">
                                            <img className="upload-img" src={IMAGE.dropdownColor} alt="upload" />
                                        </p>
                                        </div>
                                </div>
                            </div>
                        </Accordion.Body>
                    </Accordion.Item>
                </Accordion>
            </div>
        </div>
    );
};

export default NewExpense;
