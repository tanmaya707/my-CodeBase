import React, { useState } from 'react';
import './newproject.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import {
  faEnvelope,
  faPhone,
  faLocationDot,
  faCalendarDays
} from '@fortawesome/free-solid-svg-icons';
import { IMAGE } from '@/utils/Theme';
import '../../app/general.css';
import Calendar from 'react-calendar';
import 'react-calendar/dist/Calendar.css';

const projectTask = ({ selectedOption }) => {
  const [showCalendarStart, setShowCalendarStart] = useState(false);
  const [showCalendarEnd, setShowCalendarEnd] = useState(false);
  const [value, onChange] = useState(new Date());
  return (
    <div>
      <div className='details-accordian'>
        {selectedOption === "Active" ? (
          <div className='form-input-label'>
            <div className='input-group'>
              <div className="floating-label-group mb-3">
                <input type="text" id="email" className="input-form-control" required />
                <label className="floating-label">Task Name</label>
              </div>
            </div>

            <div className="floating-label-group mb-3">
              <textarea type="text" id="logo" className="input-form-control" required />
              <label className="floating-label">Task Description</label>
            </div>

            <div className='input-group'>
              <div className="floating-label-group mb-3">
                <input type="text" id="date" className="input-form-control input-logo" required />
                <label className="floating-label">Start Date</label>
                <FontAwesomeIcon
                  className="point-img"
                  icon={faCalendarDays}
                  onClick={() => setShowCalendarStart(!showCalendarStart)}
                />
                {showCalendarStart && <Calendar onChange={onChange} value={value} />}
              </div>
              <div className="floating-label-group mb-3">
                <input type="text" id="date" className="input-form-control input-logo" required />
                <label className="floating-label">End Date</label>
                <FontAwesomeIcon
                  className="point-img"
                  icon={faCalendarDays}
                  onClick={() => setShowCalendarEnd(!showCalendarEnd)}
                />
                {showCalendarEnd && <Calendar onChange={onChange} value={value} />}
              </div>
            </div>

          </div>
        ) : (
          <p className='notes-text'>Lorem ipsum dolor sit amet consectetur. Commodo diam interdum egestas amet suscipit ut mauris. Vulputate maecenas vitae morbi at. Mattis pharetra consequat ut faucibus quam consectetur. Arcu sed risus mus nibh in fames ac.</p>
        )}
      </div>
    </div>
  )
}

export default projectTask
