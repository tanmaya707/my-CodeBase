import React from 'react'
import './newproject.css';

const ProjectNote = ({ selectedOption, project }) => {

  return (

    <div >
      {selectedOption === "Active" ? (
        <div className='form-input-label my-5'>
          <div className="floating-label-group mynote my-3">
            <textarea type="text" id="logo" className="input-form-control" required />
            <label className="floating-label">Notes</label>
          </div>
          {/* <button className='save-btn'>Save</button> */}

        </div>
      ) : (
        <p className='notes-text'>Lorem ipsum dolor sit amet consectetur. Commodo diam interdum egestas amet suscipit ut mauris. Vulputate maecenas vitae morbi at. Mattis pharetra consequat ut faucibus quam consectetur. Arcu sed risus mus nibh in fames ac.</p>
      )}

    </div>
  )
}

export default ProjectNote
