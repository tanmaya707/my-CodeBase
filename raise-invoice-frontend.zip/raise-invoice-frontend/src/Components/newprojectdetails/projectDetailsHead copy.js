import React, { useState } from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import {
    faSquarePlus,
    faPenToSquare,
    faLocationDot
} from '@fortawesome/free-solid-svg-icons';
import Dropdown from 'react-bootstrap/Dropdown';
import './newproject.css';

const ProjectDetailsHead = ({ handleDropdown, selectedTab, projectDetails, handleSave, loading }) => {

    console.log(handleSave,loading);
    
    const [dropdownvalue, setDropdownvalue] = useState("Active")
    const [activeTag, setActiveTag] = useState('Files');

    const projectTags = ['Files', 'Details', 'Contacts', 'Note', 'Task'];

    const handleTagClick = (tag) => {
        setActiveTag(tag);
        selectedTab(tag);
    };

    const handleDropdownValue = (eventKey) => {
        setDropdownvalue(eventKey)
        handleDropdown(eventKey)
    };

    return (
        <>
            <div className='project-details'>
                <div className='project-details-left'>
                    <h4>{projectDetails?.project_name} <FontAwesomeIcon className="font" icon={faPenToSquare} /></h4>
                    <h6>{projectDetails?.client?.name}</h6>
                    {dropdownvalue === "Active" ? (
                        <p className='mb-3'><FontAwesomeIcon className="font" icon={faLocationDot} /> Add Location</p>
                    ) : (
                        <p style={{ color: "#344054" }} className='mb-3'><FontAwesomeIcon className="font" icon={faLocationDot} /> {projectDetails?.project_location}</p>
                    )}
                </div>
                <div className='date'>
                    <Dropdown onSelect={handleDropdownValue}>
                        <Dropdown.Toggle id="dropdown-basic">
                            {dropdownvalue}
                        </Dropdown.Toggle>

                        <Dropdown.Menu>
                            <Dropdown.Item eventKey="Active">Active</Dropdown.Item>
                            <Dropdown.Item eventKey="Completed">Completed</Dropdown.Item>
                        </Dropdown.Menu>
                    </Dropdown>
                    <div>
                        {dropdownvalue === "Active" ? (
                            <>
                                {projectDetails?.start_date}
                                <p>Start Date : 1 Nov,2024 <FontAwesomeIcon className="font" icon={faPenToSquare} /></p>
                                <p><FontAwesomeIcon className="font" icon={faSquarePlus} /> Add End Date</p>
                            </>
                        ) : (
                            <>
                                <p>Start Date : 1 Nov,2024 <FontAwesomeIcon className="font" icon={faPenToSquare} /></p>
                                <p style={{ color: "#344054" }}>End Date : 1 Dec,2024 <FontAwesomeIcon className="font" icon={faPenToSquare} /></p>
                            </>
                        )}
                    </div>
                </div>
            </div>
            <div className='tag-header'>
                <div className="tag-container">
                    {projectTags.map(tags => (
                        <span
                            key={tags}
                            className={`tag ${activeTag === tags ? "active" : ""}`}
                            onClick={() => handleTagClick(tags)}>
                            {tags}
                        </span>
                    ))}
                </div>
                <button onClick={handleSave} disabled={loading}>
                    {loading ? 'Saving...' : 'Save'}
                </button>
            </div>
        </>
    )
}

export default ProjectDetailsHead
