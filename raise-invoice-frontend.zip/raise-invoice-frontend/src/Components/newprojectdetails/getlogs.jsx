import { useDraggable } from "@/cotexts/draggableContext";
import { useModal } from "@/cotexts/modalContext";
import { deleteTasksApi, getTimeAPI } from "@/redux/slices/projectSlice";
import {  faCalendar, faChargingStation, faClock, faDeleteLeft, faEdit, faNotesMedical, faSpinner, faStickyNote, faStopwatch } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useDispatch, useSelector } from "react-redux";
import { toast } from "react-toastify";

const { memo, useState, useEffect } = require("react");
// const dropdownMenu = [
//     { icon: faEdit, label: "Edit" },
//     { icon: faChargingStation, label: "Change Status" },
//     { icon: faClock, label: "Log Time" },
//     { icon: faDeleteLeft, label: "Delete" },
// ];

const Logs = memo(({ project }) => {
    const dispatch = useDispatch();
    const { logs, loading } = useSelector((state) => state.projectReducer);
    const { openModal, setParameters } = useModal();
    const { openDraggable, setDragParameters } = useDraggable();
    const [isOpen, setIsOpen] = useState(null);
    const [timer, setTimer] = useState(0)
    const [tasksWithTimer, setTasksWithTimer] = useState([])
    // const [loading, setLoading] = useState(false);
    // const [isModalOpen, setIsModalOpen] = useState(false);

    useEffect(() => {
        if(project?.data?.enrichedProject?.client_id) {
            dispatch(getTimeAPI({
                client_id: project?.data?.enrichedProject?.client_id,
            }));
        }
    }, [project]);

    useEffect(() => {
        if (logs.length === 0) return;
        console.log("logs :: ", logs);
        
    }, [logs]);


    // const handleAddTask = () => {
    //     openModal("addTask");
    //     setParameters({
    //         client_id: project?.data?.enrichedProject?.client_id,
    //         project_id: project?.data?.enrichedProject?.id,
    //         header: "Add Task",
    //     });
    // };

    // const openDrawer = (id) => {
    //     setIsOpen(isOpen === null ? id : isOpen === id ? null : id);
    // };

    const handleChange = (value, payload) => {
        switch (value) {
            case "edit":
                openModal("addTask");
                setParameters({
                    ...payload,
                    header: "Edit Task",
                });
                break;
            case "change-status":
                openModal("changeStatus");
                setParameters({
                    ...payload,
                    header: "Change Task Status",
                });
                break;
            case "log-time":
                // setIsModalOpen(true)
                openDraggable('task');
                setDragParameters({
                    title: "Log Time",
                    payload: payload,
                })
                break;
            case "delete":
                dispatch(deleteTasksApi({
                    id: payload.id
                }));
                toast.success( `This task deleted successfully` );
                break;
            default:
                break;
        }
    }

    return (
        <div className="task-list-container paddingAccordianLogs">
        {/* //     <div className="task-list-header">
        //         <h3>Tasks for {project?.data?.enrichedProject?.project_name}</h3>
        //     </div> */}
            <div className='contact-cards log-cards'>
              <div className='grid-container'>
                
                {loading ? 
                <div className="loading-spinner">
                  <FontAwesomeIcon icon={faSpinner} />
                </div> :
                <>
                  {/* <div className="card details-card cursor-pointer" onClick={handleAddTask}>
                    <div className="card-body add-contact">
                      <div className='info'>
                        <FontAwesomeIcon className="addcontact" icon={faSquarePlus} />
                        <p>Add Task</p>
                      </div>
                    </div>
                  </div> */}
                    {logs.map((log, idx) => (
                    <div className="card details-card" key={`log-${log?.id}`}>
                        <div className="card-body">
                        <span className='initials'>{idx + 1}</span>
                        <div className='info details-info'>
                            {/* <div className="d-flex justify-content-between align-items-center">
                                <h6>{task.taskName}</h6>
                                <div className="card-actions" onClick={() => openDrawer(task.id)}>
                                    <FontAwesomeIcon className="vertical-ellipse" icon={faEllipsisV} />
                                    {isOpen === task.id && <div className="card-dropdown show-dropdown">
                                        <ul>
                                            {dropdownMenu.map((item, index) => (
                                                <li key={index} onClick={() => {
                                                        handleChange(item.label.toLowerCase().replace(" ", "-"), task);
                                                    }}>
                                                    <FontAwesomeIcon icon={item.icon} />
                                                    <span>{item.label}</span>
                                                </li>
                                            ))}
                                        </ul>
                                    </div>}
                                </div>
                            </div> */}
                            {log?.task_name && (
                                <p>
                                    <FontAwesomeIcon icon={faNotesMedical} />
                                    <strong>Task: </strong>{log.task_name}
                                </p>
                            )}
                            {log.notes && (
                                <p><FontAwesomeIcon icon={faStickyNote} /> <span className="taskDescription"><strong>Note: </strong>{log.notes}</span></p>
                            )}
                            
                            {(log?.updatedAt ) && (
                                <>
                                    <p>
                                        <FontAwesomeIcon icon={faCalendar} /> <strong>Date: </strong> {log.updatedAt.split('T')[0].split('-').reverse().join('-')}
                                    </p>
                                    <p>
                                        <FontAwesomeIcon icon={faClock} /> <strong>Time: </strong> {log.updatedAt.split('T')[1].split(".000Z")[0]}
                                    </p>
                                </>
                            )}
                            { log?.end_time && 
                                <p>
                                    <FontAwesomeIcon icon={faStopwatch} /> <strong>Time logged:</strong> {log?.end_time}
                                </p>
                            }
                        </div>
                        </div>
                    </div>
                    ))}
                </>}
              </div>
            </div>
        </div>
    );
}
);

export default Logs;