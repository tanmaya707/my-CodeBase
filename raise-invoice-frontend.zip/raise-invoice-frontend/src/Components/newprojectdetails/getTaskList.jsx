import { useDraggable } from "@/cotexts/draggableContext";
import { useModal } from "@/cotexts/modalContext";
import { convertTime, formatTime } from "@/dependencies/utils/helper";
import { deleteTasksApi, getTasksApi, getTimeAPI } from "@/redux/slices/projectSlice";
import { faArrowDown, faArrowRight, faArrowUp, faCalendar, faChargingStation, faCirclePlus, faClock, faDeleteLeft, faEdit, faEllipsisH, faEllipsisV, faEnvelope, faLocationDot, faPhone, faSquarePlus, faStickyNote } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useDispatch, useSelector } from "react-redux";
import { toast } from "react-toastify";

const { memo, useState, useEffect, useRef } = require("react");
const dropdownMenu = [
    { icon: faEdit, label: "Edit" },
    { icon: faChargingStation, label: "Change Status" },
    { icon: faClock, label: "Log Time" },
    { icon: faDeleteLeft, label: "Delete" },
];

const TaskList = memo(({ project }) => {
    const dispatch = useDispatch();
    const { tasks, loading } = useSelector((state) => state.projectReducer);
    const { openModal, setParameters } = useModal();
    const { openDraggable, setDragParameters } = useDraggable();
    const [isOpen, setIsOpen] = useState(null);
    const [timer, setTimer] = useState(0)
    const [tasksWithTimer, setTasksWithTimer] = useState([])
    // const [loading, setLoading] = useState(false);
    // const [isModalOpen, setIsModalOpen] = useState(false);
    const actionRef = useRef(null);

    const handleClickOutside = (event) => {
        if (actionRef.current && !actionRef.current.contains(event.target)) {
            setIsOpen(null);
        }
    };

      useEffect(() => {
        document.addEventListener('mousedown', handleClickOutside);
        return () => {
          document.removeEventListener('mousedown', handleClickOutside);
        };
      }, []);

    useEffect(() => {
        if(project?.data?.enrichedProject?.id !== null) {
            dispatch(getTasksApi({
                projectId: project?.data?.enrichedProject?.id,
            }));
        }
    }, [project]);

    useEffect(() => {
        if (tasks.length === 0) return;
        // console.log("==============================================", tasks);
        setTasksWithTimer([])
        setTasksWithTimer(prevTimers => {
            const updatedTimers = [...prevTimers]; // copy to avoid mutation
            // console.log("prevTimers ::: ", prevTimers);
            
            tasks.forEach(task => {
                task?.projectTimes?.forEach(time => {
                    const existingIndex = updatedTimers.findIndex(el => el.id === time.task_id);
                    const prevTime = existingIndex !== -1 ? updatedTimers[existingIndex].time : 0;
                    // console.log("time?.end_time :: ", time?.end_time);
                    // console.log("time?.end_time convertTime :: ", convertTime(time?.end_time));
                    // console.log("prevTime ::: ", prevTime);
                    
                    const totalSeconds = prevTime + convertTime(time?.end_time);
                    // console.log("totalSeconds ::: ", totalSeconds);

                    if (existingIndex !== -1) {
                        updatedTimers[existingIndex] = { id: time.task_id, time: totalSeconds };
                    } else {
                        updatedTimers.push({ id: time.task_id, time: totalSeconds });
                    }
                });
            });

            return updatedTimers;
        });
}, [tasks]);


    const handleAddTask = () => {
        openModal("addTask");
        setParameters({
            client_id: project?.data?.enrichedProject?.client_id,
            project_id: project?.data?.enrichedProject?.id,
            header: "Add Task",
        });
    };

    const openDrawer = (id) => {
        setIsOpen(isOpen === null ? id : isOpen === id ? null : id);
    }

    const handleChange = (value, payload) => {
        switch (value) {
            case "edit":
                openModal("addTask");
                setParameters({
                    ...payload,
                    header: "Edit Task",
                });
                break;
            case "change-status":
                openModal("changeStatus");
                setParameters({
                    ...payload,
                    header: "Change Task Status",
                });
                break;
            case "log-time":
                // setIsModalOpen(true)
                openDraggable('task');
                setDragParameters({
                    title: "Log Time",
                    payload: payload,
                })
                break;
            case "delete":
                dispatch(deleteTasksApi({
                    id: payload.id
                }));
                toast.success( `This task deleted successfully` );
                break;
            default:
                break;
        }
    }

    return (
        <div className="task-list-container paddingAccordianLogs">
        {/* //     <div className="task-list-header">
        //         <h3>Tasks for {project?.data?.enrichedProject?.project_name}</h3>
        //     </div> */}
            <div className='contact-cards mx-5'>
              <div className='grid-container'>
                
                {loading ? 
                <div className="loading-spinner">
                  <FontAwesomeIcon icon={faCirclePlus} spin />
                </div> :
                <>
                  <div className="card details-card cursor-pointer addTask" onClick={handleAddTask}>
                    <div className="card-body add-contact">
                      <div className='info '>
                        <FontAwesomeIcon className="addcontact" icon={faSquarePlus} />
                        <p>Add Task1</p>
                      </div>
                    </div>
                  </div>
                    {tasks.map((task, idx) => (
                    <div className="card details-card" key={`task-${idx}`}>
                        <div className="card-body">
                        <span className='initials'>{idx + 1}</span>
                        <div className='info details-info'>
                            <div className="d-flex justify-content-between align-items-center w-100">
                                <h6>{task.taskName}</h6>
                                <div className="card-actions" onClick={() => openDrawer(task.id)}>
                                    <FontAwesomeIcon className="vertical-ellipse" icon={faEllipsisV} />
                                    {isOpen === task.id && <div ref={actionRef} className="card-dropdown show-dropdown">
                                        <ul>
                                            {dropdownMenu.map((item, index) => (
                                                <li key={index} onClick={() => {
                                                        handleChange(item.label.toLowerCase().replace(" ", "-"), task);
                                                    }}>
                                                    <FontAwesomeIcon icon={item.icon} />
                                                    <span>{item.label}</span>
                                                </li>
                                            ))}
                                        </ul>
                                    </div>}
                                </div>
                            </div>
                            {task.taskDescription && (
                            <p><FontAwesomeIcon icon={faStickyNote} /> <span className="taskDescription">{task.taskDescription}</span></p>
                            )}
                            {task.taskPriority && (
                            <p><FontAwesomeIcon icon={task.taskPriority === "high" ? faArrowUp : task.taskPriority === "low" ? faArrowDown : faArrowRight} /> 
                                <span 
                                    className={task.taskPriority === "high" ? "high-priority" : task.taskPriority === "low" ? "low-priority" : "medium-priority"}>
                                    {task.taskPriority}
                                </span>
                            </p>
                            )}
                            {(task.taskStartDate && task.taskEndDate) && (
                            <p>
                                <FontAwesomeIcon icon={faCalendar} /> {task.taskStartDate.split('T')[0].split('-').reverse().join('-')} -
                                <FontAwesomeIcon icon={faCalendar} /> {task.taskEndDate.split('T')[0].split('-').reverse().join('-')}
                            </p>
                            )}
                            { tasksWithTimer?.filter(el => el.id === task.id).length > 0 && 
                                <p>
                                    <FontAwesomeIcon icon={faClock} /> Time logged : {formatTime(tasksWithTimer?.filter(el => el.id === task.id)[0]?.time)}
                                </p>
                            }
                        </div>
                        </div>
                    </div>
                    ))}
                </>}
              </div>
            </div>
        </div>
    );
}
);

export default TaskList;