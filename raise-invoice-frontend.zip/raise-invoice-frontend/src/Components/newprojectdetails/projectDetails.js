import React, { useState } from 'react';
import Accordion from 'react-bootstrap/Accordion';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import {
  faEnvelope,
  faPhone,
  faLocationDot,
  faCalendarDays
} from '@fortawesome/free-solid-svg-icons';
import { IMAGE } from '@/utils/Theme';
import '../../app/general.css';
import Calendar from 'react-calendar';
import 'react-calendar/dist/Calendar.css';

import "./newproject.css"

const ProjectDetails = ({ selectedOption, project }) => {
  const client = project?.data?.enrichedProject?.client || {};
  const [showCalendarStart, setShowCalendarStart] = useState(false);
  const [showCalendarEnd, setShowCalendarEnd] = useState(false);
  const [startDate, setStartDate] = useState(project?.data?.enrichedProject?.start_date ? new Date(project.data.enrichedProject.start_date) : new Date());
  const [endDate, setEndDate] = useState(project?.data?.enrichedProject?.end_date ? new Date(project.data.enrichedProject.end_date) : new Date());

  const formatDate = (dateStr) => {
    if (!dateStr) return '';
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
  };

  const getInitials = (name) => {
    if (!name) return '';
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  return ( 
    <div className='details-accordian my-5 paddingAccordian'>
      <Accordion defaultActiveKey={['0', '1', '2', '3', '4', '5']} alwaysOpen>
        <Accordion.Item eventKey="0">
          <Accordion.Header>
            <p className='accorheading'>Client</p>
          </Accordion.Header>
          <Accordion.Body>
            <div className="card details-card">
              <div className="card-body">
                <span className='initials'>{getInitials(client.name)}</span>
                <div className='info'>
                  <h6>{client.name}</h6>
                  <p><FontAwesomeIcon icon={faEnvelope} /> {client.email || '-'}</p>
                  <p><FontAwesomeIcon icon={faPhone} /> {client.phone || '-'}</p>
                  <p><FontAwesomeIcon icon={faLocationDot} /> {client.address || '-'}</p>
                </div>
              </div>
            </div>
          </Accordion.Body>
        </Accordion.Item>
        
        <Accordion.Item eventKey="1">
          <Accordion.Header>
            <p className='accorheading'>Project</p>
          </Accordion.Header>
          <Accordion.Body>
            {selectedOption === "Active" ? (
              <div className='project-details-complete'>
                <div className='row'>
                  <div className='col-lg-6'>
                    <div className="submittedInputData">
                      <h4>{project?.data?.enrichedProject?.project_name || ''}</h4>
                      <p>Project Name</p>
                    </div>
                  </div>

                  <div className='col-lg-6'>
                    <div className="submittedInputData">
                      <h4>{project?.data?.enrichedProject?.project_location || ''}</h4>    
                      <p> <FontAwesomeIcon className="point-img" icon={faLocationDot} />Project Location</p>
                    </div>
                  </div>
                  <div className='col-lg-12'>
                    <div className="submittedInputData">

                        <div className='description'>
                            <h4>Project Description</h4>
                      <p> {project?.data?.enrichedProject?.project_desc || ''}</p>
                          </div>  
                    </div>
                  </div>
                  <div className='col-lg-6'>
                
                      <div className="submittedInputData dateTime">
                          <div className='time'>
                            <p>Start Date </p>
                            <h4>{formatDate(project?.data?.enrichedProject?.start_date)}</h4>
                        </div>
                        <div className='time'>
                            <p>End Date  </p>
                            <h4>{formatDate(project?.data?.enrichedProject?.end_date)}</h4>
                        </div>
                      </div>
                        
                    </div>
              
                  
                </div>
              </div>
            ) : (
              <div className='project-details-complete'>
                <div className='row'>
                  <div className='col-lg-6'>
                    <div className='submittedInputData'>
                      <h4>Project Name</h4>
                      <p>{project?.data?.enrichedProject?.project_name || '-'}</p>
                    </div>

                  </div>
                  <div className='col-lg-6'>
                    <div className='submittedInputData'>
                      <h4>Project Location1</h4>
                      <p className='loactionProject'>
                        <FontAwesomeIcon icon={faLocationDot} /> {project?.data?.enrichedProject?.project_location || '-'}
                      </p>
                    </div>
                  </div>
                  <div className='col-lg-12'>
                    <div className='submittedInputData'>
                      <div className='description'>
                        <h4>Project Description</h4>
                        <p>{project?.data?.enrichedProject?.project_desc || '-'}</p>
                      </div>
                    </div>
                  </div>
                  <div className='col-lg-6'>
                    <div className='submittedInputData dateTime'>
                      <div className='time'>
                        <h4>Start Date :</h4>
                        <p>{formatDate(project?.data?.enrichedProject?.start_date)}</p>
                      </div>
                    </div>
                    <div className='submittedInputData dateTime'>
                      <div className='time'>
                        <h4>End Date :</h4>
                        <p>{formatDate(project?.data?.enrichedProject?.end_date)}</p>
                      </div>
                    </div>
                  </div>

                </div>
              </div>
            )}
          </Accordion.Body>
        </Accordion.Item>
      </Accordion>
    </div>
  );
};

export default ProjectDetails
