import React, { useEffect, useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  faEnvelope,
  faPhone,
  faLocationDot,
  faSquarePlus,
  faEdit,
  faDeleteLeft,
  faEllipsisV,
  faCalendar,
} from '@fortawesome/free-solid-svg-icons';
import { useModal } from '@/cotexts/modalContext';
import { deleteContactApi, getContactsApi } from '@/redux/slices/projectSlice';
import { useDispatch, useSelector } from 'react-redux';
import { toast } from 'react-toastify';

const getInitials = (name) => {
  if (!name) return '';
  const names = name.split(' ');
  return names.map(n => n[0]).join('').toUpperCase();
};

const dropdownMenu = [
  { icon: faEdit, label: "Edit" },
  { icon: faDeleteLeft, label: "Delete" },
];

const ProjectContacts = ({ selectedOption, project }) => {
  const dispatch = useDispatch();
  const { contacts } = useSelector((state) => state.projectReducer);
  const [client_id] = useState(project?.data?.enrichedProject?.client_id || null);
  const [project_id] = useState(project?.data?.enrichedProject?.id || null);
  const { openModal, setParameters } = useModal();
  const [isOpen, setIsOpen] = useState(null);
  // const contacts = project?.data?.ProjectContacts || [];
  const fallbackContact = project?.data?.enrichedProject?.client;

  const displayContacts = contacts.length > 0
    ? contacts.filter(contact => contact.is_primary === true)[0]
    : [];

  // useEffect(() => {
  //   console.log("fallbackContact ---> ", fallbackContact);

  // }, [fallbackContact])

  const addContact = () => {
    // Logic to add a new contact
    // console.log("Add Contact Clicked ::: ", project, project?.data?.enrichedProject?.client_id, project?.data?.enrichedProject?.id);
    openModal('addContact');
    setParameters({
      client_id: client_id,
      project_id: project_id,
      name: '',
      header: 'Add Contact',
    });
  }

  useEffect(() => {
    (async () => {
      // Fetch contacts if needed
      dispatch(getContactsApi({ client_id: client_id }));
      // setContacts(response.data);
    })();
  }, [client_id]);


  const handleChange = async (value, payload) => {
    console.log(payload);
    switch (value) {

      case "edit":
        openModal("addContact");
        setParameters({
          ...payload,
          header: "Edit Task",
        });
        break;
      case "delete":
        await dispatch(deleteContactApi({
          id: payload.id
        })).unwrap();
        dispatch(getContactsApi({ client_id: client_id }));
        toast.success(`This contact deleted successfully`);
        break;
      default:
        break;
    }
  }

  const openDrawer = (id) => {
    setIsOpen(isOpen === null ? id : isOpen === id ? null : id);
  }

  return (
    <div className='project-contact-container'>
      <div>
        <h2>Primary Contact</h2>
        <div className='contact-cards'>
          <div className='grid-container'>
            <div className="card details-card" key={`contact-${-1}`}>
              <div className="card-body">
                <span className='initials'>{getInitials(displayContacts?.contact_name)}</span>
                <div className='info w-100'>
                  <div className="d-flex justify-content-between align-items-center">
                    <h6>{displayContacts?.contact_name}</h6>
                    <div className="card-actions" onClick={() => openDrawer(-1)}>
                      <FontAwesomeIcon className="vertical-ellipse" icon={faEllipsisV} />
                      {isOpen === -1 && <div className="card-dropdown show-dropdown">
                        <ul>
                          {[{ icon: faEdit, label: "Edit" }].map((item, index) => (
                            <li key={index} onClick={() => {
                              handleChange(item.label.toLowerCase().replace(" ", "-"), { ...displayContacts, contact_email: displayContacts?.contact_email, contact_phone: displayContacts?.contact_phone, isPrimary : true });
                            }}>
                              <FontAwesomeIcon icon={item.icon} />
                              <span>{item.label}</span>
                            </li>
                          ))}
                        </ul>
                      </div>}
                    </div>
                  </div>
                  {displayContacts?.contact_email && (
                    <p><FontAwesomeIcon icon={faEnvelope} /> {displayContacts?.contact_email}</p>
                  )}
                  {displayContacts?.contact_phone && (
                    <p><FontAwesomeIcon icon={faPhone} /> {displayContacts?.contact_phone}</p>
                  )}
                  {(displayContacts?.location || displayContacts?.address) && (
                    <p>
                      <FontAwesomeIcon icon={faLocationDot} /> {displayContacts?.location || displayContacts?.address}
                    </p>
                  )}
                  {(displayContacts?.createdAt) && (
                    <p>
                      <FontAwesomeIcon icon={faCalendar} /> {displayContacts?.createdAt?.split("T")[0]?.split("-")?.reverse()?.join("/")}
                    </p>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div>
        <h2>{contacts?.length > 1 ? "Secondary Contacts" : "Secondary Contact"}
          {!contacts.some(contact => contact.is_primary === false) && <small>( No secondary contact available )</small>}
        </h2>
        {/* {!contacts?.length && <div>
              No secondary contact availables   
            </div>} */}
        <div className='contact-cards'>
          <div className='grid-container'>
            {!!contacts?.length && contacts
              .filter(contact => contact.is_primary === false)
              .map((contact, idx) => (
                <div className="card details-card" key={`contact-${idx}`}>
                  <div className="card-body">
                    <span className='initials'>{getInitials(contact.contact_name)}</span>
                    <div className='info w-100'>
                      <div className="d-flex justify-content-between align-items-center">
                        <h6>{contact.contact_name}</h6>
                        <div className="card-actions" onClick={() => openDrawer(contact?.id)}>
                          <FontAwesomeIcon className="vertical-ellipse" icon={faEllipsisV} />
                          {isOpen === contact?.id && <div className="card-dropdown show-dropdown">
                            <ul>
                              {dropdownMenu.map((item, index) => (
                                <li key={index} onClick={() => {
                                  handleChange(item.label.toLowerCase().replace(" ", "-"), {...contact, isPrimary : false});
                                }}>
                                  <FontAwesomeIcon icon={item.icon} />
                                  <span>{item.label}</span>
                                </li>
                              ))}
                            </ul>
                          </div>}
                        </div>
                      </div>
                      {contact.contact_email && (
                        <p><FontAwesomeIcon icon={faEnvelope} /> {contact.contact_email}</p>
                      )}
                      {contact.contact_phone && (
                        <p><FontAwesomeIcon icon={faPhone} /> {contact.contact_phone}</p>
                      )}
                      {(contact.location || contact.address) && (
                        <p>
                          <FontAwesomeIcon icon={faLocationDot} /> {contact.location || contact.address}
                        </p>
                      )}
                      {(contact.createdAt) && (
                        <p>
                          <FontAwesomeIcon icon={faCalendar} /> {contact?.createdAt?.split("T")[0]?.split("-")?.reverse()?.join("/")}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              ))
            }
            {selectedOption !== "Completed" && (
              <div className="card details-card cursor-pointer" onClick={addContact}>
                <div className="card-body add-contact">
                  <div className='info'>
                    <FontAwesomeIcon className="addcontact" icon={faSquarePlus} />
                    <p>Add Contact</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>

  );
};

export default ProjectContacts;
