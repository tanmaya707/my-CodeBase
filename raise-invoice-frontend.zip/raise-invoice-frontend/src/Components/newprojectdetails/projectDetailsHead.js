import React, { useState } from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import {
    faSquarePlus,
    faPenToSquare,
    faLocationDot
} from '@fortawesome/free-solid-svg-icons';
import Dropdown from 'react-bootstrap/Dropdown';
import './newproject.css';

const ProjectDetailsHead = ({ handleDropdown, selectedTab, projectDetails, handleSave, loading, updateProjectStatus }) => {

    const getStatusLabel = (status) => {
        if (status === 3) return "Completed";
        return "Active";
    };

    const [dropdownvalue, setDropdownvalue] = useState(getStatusLabel(projectDetails?.status));
    const [activeTag, setActiveTag] = useState('Files');
    const [statusMessage, setStatusMessage] = useState('');

    const projectTags = ['Files', 'Details', 'Contacts', 'Note', 'Task', 'Logs'];

    const handleTagClick = (tag) => {
        setActiveTag(tag);
        selectedTab(tag);
    };

    const handleDropdownValue = (eventKey) => {
       
        if (dropdownvalue === eventKey) return;

        setDropdownvalue(eventKey);
        handleDropdown(eventKey);

        if (updateProjectStatus) {
            const statusCode = eventKey === "Completed" ? 3 : 1;
            updateProjectStatus(statusCode);
        }

        let timeoutId;

        const showMessage = (msg) => {
            setStatusMessage(msg);
            if (timeoutId) clearTimeout(timeoutId);

            timeoutId = setTimeout(() => {
                setStatusMessage('');
            }, 3000);
        };

        if (eventKey === "Active") {
            showMessage("Project reactivated. To find it, go to the Active tab in your projects list.");
        } else if (eventKey === "Completed") {
            showMessage("Project complete. To find it, go to the Complete tab in your projects list.");
        } else {
            setStatusMessage('');
        }
    };

    React.useEffect(() => {
        setDropdownvalue(getStatusLabel(projectDetails?.status));
    }, [projectDetails?.status]);

    const formatDate = (dateString) => {
        if (!dateString) return '';
        const date = new Date(dateString);
        const day = date.getDate();
        const month = date.toLocaleString('default', { month: 'short' });
        const year = date.getFullYear();
        return `${day} ${month},${year}`;
    };

    return (
        <>
            {statusMessage && (
                <div className="status-message" style={{ background: "#e6f4ea", color: "#155724", padding: "8px 16px", borderRadius: "4px", marginBottom: "12px" }}>
                    {statusMessage}
                </div>
            )}
            <div className='project-details'>
                <div className='project-details-left'>
                    <h4>{projectDetails?.project_name}</h4>
                    <h6>{projectDetails?.client?.name}</h6>
                    <p style={{ color: "#344054" }} className='mb-3'><FontAwesomeIcon className="font" icon={faLocationDot} /> {projectDetails?.project_location}</p>
                </div>
                <div className='date'>
                    <Dropdown onSelect={handleDropdownValue}>
                        <Dropdown.Toggle id="dropdown-basic">
                            {dropdownvalue}
                        </Dropdown.Toggle>

                        <Dropdown.Menu>
                            <Dropdown.Item eventKey="Active">Active</Dropdown.Item>
                            <Dropdown.Item eventKey="Completed">Completed</Dropdown.Item>
                        </Dropdown.Menu>
                    </Dropdown>
                    <div>
                        <p>
                            Start Date : {formatDate(projectDetails?.start_date)}
                        </p>
                        <p> End Date : {formatDate(projectDetails?.end_date)}</p>
                    </div>
                </div>
            </div>
            <div className='tag-header projectTagHeader' >
                <div className="tag-container">
                    {projectTags.map(tags => (
                        <span 
                            key={tags}
                            className={`tag ${activeTag === tags ? "active" : ""}`}
                            onClick={() => handleTagClick(tags)}>
                            {tags}
                        </span>
                    ))}
                </div>
                {/* <button onClick={handleSave} disabled={loading}>
                    {loading ? 'Saving...' : 'Save'}
                </button> */}
            </div>
        </>
    )
}

export default ProjectDetailsHead
