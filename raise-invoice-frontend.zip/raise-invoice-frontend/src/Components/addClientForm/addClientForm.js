"use client"
import React, { useState, useEffect, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import "./addClientForm.css";
import { IMAGE } from "@/utils/Theme";
import Pageheader from "@/utils/pageheader";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faLocationDot,
  faAngleDown,
  faArrowLeft,
  faSquarePlus,
  faSquareMinus,
  faXmark,
} from "@fortawesome/free-solid-svg-icons";
import Accordion from "react-bootstrap/Accordion";
import "../../app/general.css";
import { useRouter } from "next/navigation";
import {
  fetchMasterData,
  createClientData,
  deatilsClientData,
  updateClientData,
  fetchClientData,
} from "@/redux/slices/dataSlice";
import { ToastContainer, toast } from "react-toastify";
import PhoneExtensionDropdown from "../phoneExtension";
import CustomDropDown from "../ui/DropDown";
import { useClickOutside } from "@/hooks/use-click-outside";

const employeeCounts = [
  {
    id: 0,
    value: '0-19',
    content: '0 - 19'
  },
  {
    id: 1,
    value: '20-49',
    content: '20 - 49'
  },
  {
    id: 2,
    value: '50-99',
    content: '50 - 99'
  },
  {
    id: 3,
    value: '100-199',
    content: '100 - 199'
  },
  {
    id: 4,
    value: '200-499',
    content: '200 - 499'
  },
  {
    id: 5,
    value: '500-999',
    content: '500 - 999'
  },
  {
    id: 6,
    value: '1000+',
    content: '1000+'
  }
]

const AddClientForm = ({ clientToEdit }) => {
  const dropdownRef = useRef(null);
  const dispatch = useDispatch();
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [showAlternateEmail, setShowAlternateEmail] = useState(false);
  const [formData, setFormData] = useState({
    billingName: "",
    phoneNumber: "",
    email: "",
    alternateEmail: "",
    billingAddress: "",
    contactName: "",
    billingPhone: "",
    website: "",
    payterm: "",
    taxNo: "",
    notes: "",
    logo: null,
  });
  const [errors, setErrors] = useState({});
  const { items } = useSelector((state) => state.dataReducer);
  const [openCountryCodes, setOpenCountryCodes] = useState(false);
  const [openCountryCodesContact, setOpenCountryCodesContact] = useState(false);
  const [countryCode, setCountryCode] = useState("+91")
  const [countryCodeContact, setCountryCodeContact] = useState("+91")
  const [paymentTermList, setPaymentTermList] = useState([]);

  useEffect(() => {
    console.log("items ::: ", items);
    
  }, [items])

  // Refs for each field
  const refs = {
    billingName: useRef(),
    phoneNumber: useRef(),
    email: useRef(),
    alternateEmail: useRef(),
    billingAddress: useRef(),
    contactName: useRef(),
    billingPhone: useRef(),
    website: useRef(),
    payterm: useRef(),
    taxNo: useRef(),
    notes: useRef(),
    logo: useRef(),
  };

  // Refs for dropdown containers to detect outside clicks
  const countryCodeRef = useRef(null);
  const countryCodeContactRef = useRef(null);

  const toggleAlternateEmail = () => {
    setShowAlternateEmail((prev) => !prev);
  };

  const [unsaved, setUnsaved] = useState(false);
  const [modalType, setModalType] = useState('reload');
  const [showModal, setShowModal] = useState(false);
  const [label, setLabel] = useState("");
  const [open, setOpen] =useState(false)
  useClickOutside(dropdownRef, () => setOpen(false), false);
  
  useEffect(() => {
    const fetchData = async () => {
      // Fetch master data
      await dispatch(fetchMasterData()).unwrap();

      // Check if clientToEdit is defined and has an id
      if (clientToEdit && clientToEdit.id) {
        try {
          // Fetch client details
          const clientDetails = await dispatch(
            deatilsClientData(clientToEdit.id)
          ).unwrap();

          // Set form data with the fetched client details
          setFormData({
            billingName: clientDetails?.name || "",
            phoneNumber: clientDetails?.phone || "",
            email: clientDetails?.email || "",
            alternateEmail: clientDetails?.alt_email || "",
            billingAddress: clientDetails?.address || "",
            contactName: clientDetails?.contacts?.contact_name || "",
            billingPhone: clientDetails?.contacts?.phone || "",
            website: clientDetails?.contacts?.website || "",
            payterm: clientDetails?.otherDetails?.payment_term || "",
            taxNo: clientDetails?.otherDetails?.tax_no || "",
            notes: clientDetails?.otherDetails?.notes || "",
            logo: clientDetails?.profileImage || "",
          });
        } catch (error) {
          console.error("Error fetching client details:", error);
        }
      } else {
        setFormData({
          billingName: "",
          phoneNumber: "",
          email: "",
          alternateEmail: "",
          billingAddress: "",
          contactName: "",
          billingPhone: "",
          website: "",
          payterm: "",
          taxNo: "",
          notes: "",
          logo: null,
        });
      }
    };
    fetchData();
  }, [dispatch, clientToEdit]);

  // Close the country code dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      const target = event.target;
      if (openCountryCodes && countryCodeRef.current && !countryCodeRef.current.contains(target)) {
        setOpenCountryCodes(false);
      }
      if (openCountryCodesContact && countryCodeContactRef.current && !countryCodeContactRef.current.contains(target)) {
        setOpenCountryCodesContact(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [openCountryCodes, openCountryCodesContact]);

  const validateForm = () => {
    const newErrors = {};
    if (!formData.billingName)
      newErrors.billingName = "Billing Name is required";
    if (!formData.phoneNumber)
      newErrors.phoneNumber = "Phone Number is required";
    if (!formData.email) newErrors.email = "Email is required";
    if (!formData.billingAddress)
      newErrors.billingAddress = "Billing Address is required";
    if (!formData.contactName)
      newErrors.contactName = "Contact Name is required";
    if (!formData.billingPhone)
      newErrors.billingPhone = "Billing Phone Number is required";
    if (!formData.website) newErrors.website = "Website is required";
    if (!formData.payterm) newErrors.payterm = "Payment terms is required";
    if (!formData.taxNo) newErrors.taxNo = "Tax No. is required";
    if (!formData.notes) newErrors.notes = "Notes are required";
    return newErrors;
  };

  const handleInputChange = (e) => {
    const { id, value } = e.target;
    if (id === "phoneNumber" || id === "billingPhone") {
      const digits = value.replace(/\D/g, "");
      if (digits.length <= 10) {
        setFormData((prev) => ({ ...prev, [id]: digits }));
      }
    } else {
      setFormData((prev) => ({ ...prev, [id]: value }));
    }
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];

    if (file) {
      setFormData((prev) => ({ ...prev, logo: file }));
    }
  };

  const handleRemoveImage = () => {
    setFormData((prev) => ({ ...prev, logo: null }));
    if (refs.logo.current) refs.logo.current.value = "";
  };

  const handleSave = async () => {
    const validationErrors = validateForm();
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length > 0) {
      // Scroll to first error field
      const firstErrorKey = Object.keys(validationErrors)[0];
      if (refs[firstErrorKey] && refs[firstErrorKey].current) {
        refs[firstErrorKey].current.scrollIntoView({ behavior: "smooth", block: "center" });
        refs[firstErrorKey].current.focus();
      }
      return;
    }

    const formDataToSubmit = new FormData();
    formDataToSubmit.append("name", formData.billingName);
    formDataToSubmit.append("email", formData.email);
    formDataToSubmit.append("alt_email", formData.alternateEmail);
    formDataToSubmit.append("address", formData.billingAddress);
    formDataToSubmit.append("dialCode", 91);
    formDataToSubmit.append("phone", formData.phoneNumber);
    formDataToSubmit.append("contact_name", formData.contactName);
    formDataToSubmit.append("contactdialCode", 91);
    formDataToSubmit.append("contactPhone", formData.billingPhone);
    formDataToSubmit.append("contactWebsite", formData.website);
    formDataToSubmit.append("payment_term", formData.payterm);
    formDataToSubmit.append("tax_no", formData.taxNo);
    formDataToSubmit.append("notes", formData.notes);
    if (formData.logo) {
      formDataToSubmit.append("profileImage", formData.logo);
    }
    // return;
    setLoading(true);
    try {
      let clientSave;
      if (clientToEdit && clientToEdit.id) {
        // Update existing client
        clientSave = await dispatch(
          updateClientData({
            clientId: clientToEdit.id,
            userData: formDataToSubmit,
          })
        ).unwrap();
      } else {
        // Create new client
        clientSave = await dispatch(
          createClientData(formDataToSubmit)
        ).unwrap();
      }

      clientSave.status
        ? toast.success(clientSave.message)
        : toast.error(clientSave.message);
      // Redirect to the client list page after saving
     router.push(`/client`);
    } catch (error) {
      console.error("Error saving client data:", error);
    } finally {
      setLoading(false);
      dispatch(fetchClientData())
    }
  };


  const previousPage = () => {
    router.push(`/client`);
  };
  const btnLabel = 
  
    <>
      <button onClick={previousPage} className="btnBgNone"><FontAwesomeIcon icon={faArrowLeft} className="me-2" /> Add Client</button>  
    </>
  

  const handleAction = (e, item) => {
      console.log("form data :", formData);
      console.log("item ::: ", item);
      
      setFormData((prev) => ({ ...prev, payterm: item?.value }));
  }

  return (
    <>
      <Pageheader label={btnLabel} handleSave={handleSave} loading={loading} />
      <div className="contentArea-inner form-input-label">
        <Accordion defaultActiveKey="0">
          <Accordion.Item eventKey="0">
            <Accordion.Header>
              <p className="accorheading">Billing Details</p>
            </Accordion.Header>
            <Accordion.Body>
              <div className="row">
                <div className="col-lg-6 col-md-6 col-sm-12">
                  <div className="floating-label-group">
                    <input
                      type="text"
                      id="billingName"
                      ref={refs.billingName}
                      className="input-form-control"
                      value={formData.billingName}
                      onChange={handleInputChange}
                      required
                    />
                    <label className="floating-label">Billing Name</label>
                    {errors.billingName && (
                      <span className="text-danger">{errors.billingName}</span>
                    )}
                  </div>
                </div>

                <div className="col-lg-6 col-md-6 col-sm-12 mb-3">
                  <div className="phone-input ">
                    <div
                      className="country-code country-code"
                      ref={countryCodeRef}
                      onClick={() => setOpenCountryCodes(prev => !prev)}
                    >
                      {countryCode + " "}
                      <FontAwesomeIcon
                        icon={faAngleDown}
                        className="phone-angle"
                      />
                      {openCountryCodes && <div className="phone-extension">
                        <PhoneExtensionDropdown handleCountryCode={setCountryCode} />
                      </div>}
                    </div>
                    <div className="divider"></div>
                    <div className="floating-label-group">
                      <input
                        type="text"
                        id="phoneNumber"
                        ref={refs.phoneNumber}
                        className="phone-number"
                        value={formData.phoneNumber}
                        onChange={handleInputChange}
                        required
                        maxLength={10}
                        title="Please enter a valid 10-digit phone number"
                      />
                      <label className="phone-floating-label">Phone No.</label>
                    </div>
                  </div>
                  {errors.phoneNumber && (
                    <span className="text-danger">{errors.phoneNumber}</span>
                  )}
                </div>

                <div className="col-lg-6 col-md-6 col-sm-12">
                  <div className="floating-label-group">
                    <input
                      type="text"
                      id="email"
                      ref={refs.email}
                      className="input-form-control"
                      value={formData.email}
                      onChange={handleInputChange}
                      required
                    />
                    <label className="floating-label">Email</label>
                    {errors.email && (
                      <span className="text-danger">{errors.email}</span>
                    )}
                  </div>
                </div>

                <div className="col-lg-6 col-md-6 col-sm-12">
                  <div className="floating-label-group fileInput">
                    <input
                      type="file"
                      id="logo"
                      ref={refs.logo}
                      className="input-form-control input-logo"
                      accept="image/*"
                      onChange={handleFileChange}
                    />
                    <label className="floating-label">Logo (if any)</label>
                    <img
                      className="upload-img"
                      src={IMAGE.upload}
                      alt="upload"
                    />
                    {formData.logo && (
                      <p
                        title={
                          formData.logo?.name
                            ? formData.logo.name
                            : String(formData.logo)
                        }
                      >
                        {(() => {
                          const name = formData.logo?.name
                            ? formData.logo.name
                            : String(formData.logo);
                          const maxLen = 25; // display limit
                          return name.length > maxLen
                            ? name.slice(0, maxLen) + "..."
                            : name;
                        })()}
                        <FontAwesomeIcon
                          className="picCancel"
                          icon={faXmark}
                          onClick={handleRemoveImage}
                        />
                      </p>
                    )}
                  </div>
                </div>

                <div className="row align-items-center ">
                  {showAlternateEmail && (
                    <div className="col-lg-6 col-md-6 col-sm-12 addALternate align-items-center">
                      <div className="floating-label-group">
                        <input
                          type="text"
                          id="alternateEmail"
                          ref={refs.alternateEmail}
                          className="input-form-control"
                          value={formData.alternateEmail}
                          onChange={handleInputChange}
                          required
                        />
                        <label className="floating-label">
                          Alternate Email
                        </label>
                        {errors.alternateEmail && (
                          <span className="text-danger">
                            {errors.alternateEmail}
                          </span>
                        )}
                      </div>
                    </div>
                  )}
                  <div className=" col-lg-4 col-md-6 col-sm-12">
                    <div
                      className="addALternate"
                      onClick={toggleAlternateEmail}
                      role="button"
                      tabIndex={0}
                      onKeyPress={(e) => {
                        if (e.key === "Enter" || e.key === " ")
                          toggleAlternateEmail();
                      }}
                    >
                      <div className="link-text ">
                        <FontAwesomeIcon
                          icon={
                            showAlternateEmail
                              ? require("@fortawesome/free-solid-svg-icons")
                                  .faSquareMinus
                              : faSquarePlus
                          }
                        />
                        <p
                          style={{
                            margin: 0,
                            userSelect: "none",
                            fontWeight: "600",
                          }}
                        >
                          {showAlternateEmail
                            ? "Remove alternate email id"
                            : "Add alternate email id"}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-lg-12 col-md-12 col-sm-12">
                  <div className="floating-label-group">
                    <input
                      type="text"
                      id="billingAddress"
                      ref={refs.billingAddress}
                      className="input-form-control input-logo"
                      value={formData.billingAddress}
                      onChange={handleInputChange}
                      required
                    />
                    <label className="floating-label">Billing Address</label>
                    <FontAwesomeIcon
                      className="point-img"
                      icon={faLocationDot}
                    />
                    {errors.billingAddress && (
                      <span className="text-danger">
                        {errors.billingAddress}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </Accordion.Body>
          </Accordion.Item>
        </Accordion>
        <Accordion defaultActiveKey="0">
          <Accordion.Item eventKey="0">
            <Accordion.Header>
              <p className="accorheading">Contact Details</p>
            </Accordion.Header>
            <Accordion.Body>
              <div className="row">
                <div className="col-lg-6 col-md-6 col-sm-12">
                  <div className="floating-label-group">
                    <input
                      type="text"
                      id="contactName"
                      ref={refs.contactName}
                      className="input-form-control"
                      value={formData.contactName}
                      onChange={handleInputChange}
                      required
                    />
                    <label className="floating-label">Contact Name</label>
                    {errors.contactName && (
                      <span className="text-danger">{errors.contactName}</span>
                    )}
                  </div>
                </div>
                <div className="col-lg-6 col-md-6 col-sm-12 mb-3">
                  <div className="phone-input  ">
                    <div
                      className="country-code relative"
                      ref={countryCodeContactRef}
                      onClick={() => setOpenCountryCodesContact(prev => !prev)}
                    >
                      {countryCodeContact + " "}
                      <FontAwesomeIcon
                        icon={faAngleDown}
                        className="phone-angle"
                      />
                      {openCountryCodesContact && <div className="phone-extension">
                        <PhoneExtensionDropdown handleCountryCode={setCountryCodeContact} />
                      </div>}
                    </div>
                    <div className="divider"></div>
                    <div className="floating-label-group">
                      <input
                        type="text"
                        id="billingPhone"
                        ref={refs.billingPhone}
                        className="phone-number"
                        value={formData.billingPhone}
                        onChange={handleInputChange}
                        required
                        maxLength={10}
                        title="Please enter a valid 10-digit phone number"
                      />
                      <label className="phone-floating-label">Phone No.</label>
                    </div>
                  </div>
                  {errors.billingPhone && (
                    <span className="text-danger">{errors.billingPhone}</span>
                  )}
                </div>
                <div className="col-lg-12 col-md-12 col-sm-12">
                  <div className="floating-label-group">
                    <input
                      type="text"
                      id="website"
                      ref={refs.website}
                      className="input-form-control"
                      value={formData.website}
                      onChange={handleInputChange}
                      required
                    />
                    <label className="floating-label">Website</label>
                    {errors.website && (
                      <span className="text-danger">{errors.website}</span>
                    )}
                  </div>
                </div>
              </div>
            </Accordion.Body>
          </Accordion.Item>
        </Accordion>
        <Accordion defaultActiveKey="0">
          <Accordion.Item eventKey="0">
            <Accordion.Header>
              <p className="accorheading">Other Details</p>
            </Accordion.Header>
            <Accordion.Body>
              <div className="row">
                <div className="col-lg-6 col-md-6 col-sm-12 mb-3">
                  <div className="payment-type-dropdown">
                    {!!(formData?.payterm && !open) && <label className="payment-label">Payment Terms</label>}
                    {/* <select
                      className="payment-terms"
                      id="payterm"
                      ref={refs.payterm}
                      value={formData.payterm}
                      onChange={handleInputChange}
                      required
                    >
                      <option value="">Select Payment Term</option>
                      {items?.paymentTerms?.map((payterm) => (
                        <option key={payterm.value} value={payterm.value}>
                          {payterm.title}
                        </option>
                      ))}
                    </select> */}
                    <CustomDropDown dropDownText="Select Payment Term" list={items?.paymentTerms || []} className="" handleAction={handleAction} open={open} setOpen={setOpen} selectedItem={formData?.payterm} dropdownRef={dropdownRef} />
                    {/* <p className="dropdownIcon">
                      <img src={IMAGE.dropdownColor} alt="" />
                    </p> */}
                    {errors.payterm && (
                      <span className="text-danger">{errors.payterm}</span>
                    )}
                  </div>
                </div>
                <div className="col-lg-6 col-md-6 col-sm-12 mb-3">
                  <div className="floating-label-group">
                    <input
                      type="text"
                      id="taxNo"
                      ref={refs.taxNo}
                      className="input-form-control"
                      value={formData.taxNo}
                      onChange={handleInputChange}
                      required
                    />
                    <label className="floating-label">Tax No.</label>
                    {errors.taxNo && (
                      <span className="text-danger">{errors.taxNo}</span>
                    )}
                  </div>
                </div>
                <div className="col-lg-12 col-md-12 col-sm-12">
                  <div className="floating-label-group">
                    <textarea
                      type="text"
                      id="notes"
                      ref={refs.notes}
                      className="input-form-control"
                      value={formData.notes}
                      onChange={handleInputChange}
                      required
                      placeholder="note"
                    />
                    <label className="floating-label">Notes</label>
                    {errors.notes && (
                      <span className="text-danger">{errors.notes}</span>
                    )}
                  </div>
                </div>
              </div>
            </Accordion.Body>
          </Accordion.Item>
        </Accordion>
      </div>
      <ToastContainer />
    </>
  );
};

export default AddClientForm;
