'use client'

import { useRouter } from "next/navigation";
import { useEffect } from "react";

const ProtectedRoute = ( {isAuthenticated, children} ) => {
    const router = useRouter();

    useEffect(() => {
        if(!isAuthenticated) {
            router.push('/')
        }
    }, [isAuthenticated, router])
    
    return !isAuthenticated ?  null : <>{children}</>
}

export default ProtectedRoute;