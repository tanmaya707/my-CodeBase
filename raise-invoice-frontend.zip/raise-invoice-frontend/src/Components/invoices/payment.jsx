import { useModal } from '@/cotexts/modalContext';
import { IMAGE } from '@/utils/Theme';
import { faArrowRight } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import Link from 'next/link';

const Payment = ({isNonPaid }) => {
    const { openModal, setParameters } = useModal()
    return (
        <div className='payemnet-details'>
            <h5>Payment</h5>
            {isNonPaid ? <button className='ThemeBtnBordered'> Mark as Fully Paid</button>
              :
              <div className='payment-paid-top'>
                <div className='payment-paid'>
                  <img src={IMAGE.done} alt="" />
                  <h6>$120.00 Paid</h6>
                </div>

                <div className='payemnet-method'>
                  <p>Payment Method : Cash</p>
                  <p> Transaction Id : TRN-123456456</p>
                </div>
              </div>
            }

            <ul className="payment-info">
              <li onClick={(e)=> {
              e.preventDefault();
              setParameters({header : "Record Payment"})
              openModal('recordPayment')}}>
                <Link href='' >
                  <div className='link-left'>
                    <img src={IMAGE.payment_status1} alt="" /> Record Payment
                  </div>
                  <div className='image-right'>
                    <FontAwesomeIcon icon={faArrowRight} />
                  </div>
                </Link>
              </li>
              <li>
                <Link href=''>
                  <div className='link-left'>
                    <img src={IMAGE.payment_status2} alt="" />Show QR Code
                  </div>
                  <div className='image-right'>
                    <FontAwesomeIcon icon={faArrowRight} />
                  </div>
                </Link>
              </li>
            </ul>

          </div>
    )
}

export default Payment;