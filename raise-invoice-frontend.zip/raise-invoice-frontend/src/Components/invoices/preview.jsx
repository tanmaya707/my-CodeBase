"use client";
import { IMAGE } from '@/utils/Theme';
import CustomInvoiceImpact from "@/Components/templates/impact";
import { useRouter } from 'next/navigation';
import { useEffect, useRef, useState } from 'react';
import { useModal } from '@/cotexts/modalContext';

const InvoicePreview = ({
    invoice,
    setPreviewRef,
    previewRef,
    customInvoice,
    customInvoiceOption,
    route = "invoice",
    addRoute = "/addInvoice"
}) => {
    const { setParameters } = useModal();
    const router = useRouter();
    const componentRef = useRef();
    const [attachedFile, setAttachedFile] = useState(null);
    const [blobUrl, setBlobUrl] = useState(null);

    useEffect(() => {
        if (componentRef && setPreviewRef) setPreviewRef(componentRef);
    }, [componentRef, setPreviewRef]);

    const handlePrint = () => {
        const printContent = previewRef.current.innerHTML;
        const printWindow = window.open("", "", "width=800,height=600");
        printWindow.document.write(`
            <html>
                <head>
                    <title>Print</title>
                    <style>
                        body { font-family: sans-serif; padding: 20px; }
                    </style>
                </head>
                <body>${printContent}</body>
            </html>
        `);
        printWindow.document.close();
        printWindow.focus();
        printWindow.print();
    };

    const handleFileChange = (e) => {
        const file = e.target.files[0];
        if (file) {
            setAttachedFile(file);
            const url = URL.createObjectURL(file);
            setBlobUrl(url);
        }
    };

    const handleSend = (e) => {
        e.preventDefault();

        // Store file metadata and blob URL in context
        if (attachedFile && blobUrl) {
            setParameters({
                attachmentName: attachedFile.name,
                attachmentType: attachedFile.type,
                blobUrl: blobUrl
            });
        } else {
            setParameters({});
        }

        const params = new URLSearchParams();
        params.append('send', 'true');
        params.append('id', invoice?.id);

        if (addRoute === "/addInvoice") {
            router.push(`${addRoute}?${params.toString()}`);
        } else {
            router.push(`/${addRoute}/${invoice?.id}?${params.toString()}`);
        }
    };

    return (
        <div>
            <div className="preview-container">
                <div className='preview-content'>
                    <CustomInvoiceImpact
                        ref={componentRef}
                        invoice={{ ...invoice }}
                        selectedTemp={customInvoice?.templateName || 'Impact'}
                        selectedId={
                            customInvoice?.logoId
                                ? { id: customInvoice?.logoId, logoImage: customInvoice?.logoImage || '' }
                                : null
                        }
                        selectedSize={customInvoice?.logoSize || ''}
                        alignPos={customInvoice?.logoPosition || ''}
                        selectedColour={
                            customInvoice?.colourId
                                ? { id: customInvoice?.colourId, colourCode: customInvoice?.colourCode }
                                : null
                        }
                        customColour={customInvoice?.customColour}
                        selectedHeader={
                            customInvoice?.headerId
                                ? { id: customInvoice?.headerId, headerImg: customInvoice?.headerImg }
                                : null
                        }
                        selectedWatermark={
                            customInvoice?.waterMarkId
                                ? {
                                    id: customInvoice?.waterMarkId,
                                    waterMarkImg: customInvoice?.waterMarkImg,
                                }
                                : null
                        }
                        customOption={customInvoiceOption || {}}
                    />
                    <div className="booking-btns">
                        <button
                            onClick={(e) => {
                                e.preventDefault();
                                router.push(`/${route}/${invoice?.id}/preview`);
                            }}
                            className='bookThemeBtn'
                        >
                            <img src={IMAGE.eye} alt="" /> Preview
                        </button>
                        <button onClick={handlePrint} className='bookThemeBtn'>
                            <img src={IMAGE.eye} alt="" /> Preview as PDF
                        </button>
                    </div>
                </div>
            </div>
            <div className='submit-container'>
                <div></div>
                <div className='submit-btns'>
                    <label className='ThemeBtnBgNone' style={{ cursor: 'pointer' }}>
                        <input
                            type="file"
                            accept="image/*,application/pdf"
                            style={{ display: 'none' }}
                            onChange={handleFileChange}
                        />
                        <img src={IMAGE.file} alt="" />
                        {attachedFile ? attachedFile.name : "Attach File"}
                    </label>
                    <button className='ThemeBtn' onClick={handleSend}>Send</button>
                </div>
            </div>
        </div>
    );
};

export default InvoicePreview;