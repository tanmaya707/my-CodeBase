import { useModal } from '@/cotexts/modalContext';
import { IMAGE } from '@/utils/Theme';
import { faArrowRight } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import html2pdf from 'html2pdf.js';
import Link from 'next/link';
import { useEffect } from 'react';

const MoreDetails = ({ isNonPaid, previewRef, invoiceNumber, type = "Invoice", id, route }) => {
  const { openModal, setParameters } = useModal();


  function handleDownloadPdf() {
    if (!previewRef?.current) return;

    const element = previewRef?.current;

    const options = {
      margin: 0,
      filename: `Invoice_${invoiceNumber || 'preview'}.pdf`,
      image: { type: 'png', quality: 1.0 },
      html2canvas: {
        scale: 3,
        useCORS: true,
        backgroundColor: '#ffffff',
      },
      jsPDF: { unit: 'pt', format: 'a4', orientation: 'portrait' },
    };

    html2pdf()
      .set(options)
      .from(element)
      .save()
      .catch((err) => {
        console.error('PDF generation failed:', err);
      });
  }

  const handleCopy = () => {
    openModal('copy')
    setParameters({ header: `Copy ${type}`, type: type, route: route + '?copy=' + id })
  }

  const handlePrint = () => {
    const printContent = previewRef.current.innerHTML;
    const printWindow = window.open("", "", "width=800,height=600");
    const styles = Array.from(document.styleSheets)
    .map((styleSheet) => {
      try {
        return [...styleSheet.cssRules]
          .map((rule) => rule.cssText)
          .join("\n");
      } catch (e) {
        return ""; // Ignore CORS issues for external styles
      }
    })
    .join("\n");
    printWindow.document.write(`
      <html>
        <head>
          <title>Print</title>
          <style>${styles}</style>
        </head>
        <body>${printContent}</body>
      </html>
    `);
    printWindow.document.close();
    // printWindow.focus();
    // printWindow.print();
    // printWindow.close();
    printWindow.onload = () => {
      printWindow.focus();
      printWindow.print();
      printWindow.close();
    };
  }
    return (
      <div className='payemnet-details more-details'>
        <h5>More</h5>
        <ul className="payment-info">
          {isNonPaid ?
            <li >
              <Link href=''>
                <div className='link-left'>
                  <img src={IMAGE.payment_status3} alt="" />
                  <p> Recurring Invoice <span>Off</span></p>
                </div>

              </Link>
            </li>

            : ""}
          <li onClick={handlePrint}>
            <Link href=''>
              <div className='link-left'>
                <img src={IMAGE.payment_status4} alt="" />Print
              </div>
              <div className='image-right'>
                <FontAwesomeIcon icon={faArrowRight} />
              </div>
            </Link>
          </li>

          <li onClick={handleCopy}>
            <Link href=''>
              <div className='link-left'>
                <img src={IMAGE.payment_status5} alt="" />Copy
              </div>
              <div className='image-right'>
                <FontAwesomeIcon icon={faArrowRight} />
              </div>
            </Link>
          </li>

          <li onClick={handleDownloadPdf}>
            <Link href=''>
              <div className='link-left'>
                <img src={IMAGE.payment_status6} alt="" />Export as PDF
              </div>
              <div className='image-right'>
                <FontAwesomeIcon icon={faArrowRight} />
              </div>
            </Link>
          </li>
          {/* {isNonPaid ?
            <li onClick={() => { setParameters({ header: "Signature" }); openModal('eSign') }}>
              <Link href=''>
                <div className='link-left'>
                  <img src={IMAGE.payment_status7} alt="" />Sign
                </div>
                <div className='image-right'>
                  <FontAwesomeIcon icon={faArrowRight} />
                </div>
              </Link>
            </li>
            : ""} */}
        </ul>

        <button className='ThemeBtnBordered' onClick={() => { }}> Mark as Sent</button>



      </div>
    )
  }

  export default MoreDetails;