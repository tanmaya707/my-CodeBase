const InvoiceHeader = ({headerInfo}) => {
    // console.log("headerInfo ::: ", headerInfo);
    
    const {name, date, paymentStatus, dueDate, amount, type} = headerInfo
    return(
        <div className="header-container">
            <div className="header-left header-section">
                <h4>{type || "Invoice"} {headerInfo?.invoiceNumber}</h4>
                <div className="client">{name}</div>
                <div className={`common-details ${paymentStatus === "unpaid" ? "error" : "active"}`}>{paymentStatus?.charAt(0).toUpperCase() + paymentStatus?.slice(1)}</div>
            </div>
            <div className="header-right header-section">
                <div className="common-details">{date}</div>
                {dueDate && <div className={`common-details ${dueDate?.includes('-') ? "active" : "error"}`}>Due in {dueDate?.includes('-') ? dueDate?.slice(1) : dueDate}</div>}
                <h4>${amount}</h4>
            </div>
        </div>
    )
}

export default InvoiceHeader;