import React from 'react';
import '../../app/general.css';
import '../../Components/addItemForm/addItemForm.css';
import ToggleButton from '@/utils/ToggleButton/toggleButton';
import Link from 'next/link';
import {
    faAngleDown, faArrowLeft, faPhone, faEnvelope, faLocationDot,
    faCircleXmark, faSquarePlus, faPenToSquare, faTrash,
    faPercentage
} from '@fortawesome/free-solid-svg-icons';

import { IMAGE } from '../../utils/Theme';

// Helper: currency symbols
const currencySymbols = {
  INR: "₹",
  USD: "$",
  EUR: "€",
  GBP: "£",
  JPY: "¥",
  AUD: "A$",
  CAD: "C$",
  SGD: "S$",
  CNY: "¥",
};

const TERMS_OPTIONS = [
    { value: "", label: "None", days: 0 },
    { value: "1", label: "Custom", days: 0 },
    { value: "2", label: "Next Day", days: 1 },
    { value: "3", label: "2 Days", days: 2 },
    { value: "4", label: "3 Days", days: 3 },
    { value: "5", label: "4 Days", days: 4 },
    { value: "6", label: "5 Days", days: 5 },
    { value: "7", label: "10 Days", days: 10 },
    { value: "8", label: "30 Days", days: 30 },
    { value: "9", label: "90 Days", days: 90 },
    { value: "10", label: "180 Days", days: 180 },
    { value: "11", label: "365 Days", days: 365 },
];

// Helper: get image src from file object or string
function getImageSrc(file) {
    if (!file) return '';
    if (typeof file === 'string') return file;
    if (file.preview) return file.preview;
    if (file.url) return file.url;
    return '';
}

// Helper: format date as dd-mm-yyyy
function formatDate(dateStr) {
    if (!dateStr) return '';
    const date = new Date(dateStr);
    const dd = String(date.getDate()).padStart(2, '0');
    const mm = String(date.getMonth() + 1).padStart(2, '0');
    const yyyy = date.getFullYear();
    return `${dd}-${mm}-${yyyy}`;
}
import Accordion from 'react-bootstrap/Accordion';
import Calendar from 'react-calendar';
import "react-calendar/dist/Calendar.css";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'

// Main template function
function invoiceTemplate({ invoices, ref }) {
    // Adapt to new data structure
    const invoice = invoices.invoice || invoices;
    const symbol = currencySymbols[invoice.currency] || "$";
    const items = invoice.items || [];
    const subtotal = typeof invoice.subtotal === "number"
        ? invoice.subtotal
        : items.reduce((sum, item) => sum + ((Number(item.quantity) || 0) * (Number(item.rate) || 0)), 0);
    const discount = typeof invoice.discountTotal === "number"
        ? invoice.discountTotal
        : 0;
    const tax = typeof invoice.gstTotal === "number"
        ? invoice.gstTotal
        : 0;
    const total = typeof invoice.total === "number"
        ? invoice.total
        : subtotal - discount + tax;

    const todayFormatted = formatDate(new Date().toISOString());

    return (
        <div ref={ref}>
            <div className='row'>
            <div className='col-md-12'>
                <div className="preview-card" style={{ padding : '0px' }}>
                    <div className="tableTopContainer" style={{ margin: 0, padding: 0, fontFamily: 'Arial, sans-serif', backgroundColor: '#f5f5f5' }}>
                        <table width="100%" cellPadding="0" cellSpacing="0" style={{ backgroundColor: '#f5f5f5', padding: '20px' }}>
                            <tbody>
                                <tr>
                                    <td align="center">
                                        <table width="100%" cellPadding="0" cellSpacing="0" style={{ backgroundColor: '#ffffff', borderRadius: '8px', boxShadow: '0 2px 10px rgba(0,0,0,0.1)' }}>
                                            <tbody>
                                                <tr>
                                                    <td style={{ padding: '10px 40px' }}>
                                                        <table width="100%" cellPadding="0" cellSpacing="0">
                                                            <tbody>
                                                                <tr>
                                                                    <td style={{ fontSize: '22px', fontWeight: 'bold', color: '#2c3e50', textAlign: 'left' }}>
                                                                        Invoice #{invoice.invoiceNumber || '0000'}
                                                                    </td>
                                                                    <td align="right" style={{ verticalAlign: 'top', textAlign: 'right', width: "14%" }}>
                                                                        <table cellPadding="0" cellSpacing="0">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td style={{ backgroundColor: '#2c3e50', color: 'white', padding: '8px 12px', borderRadius: '50%', fontWeight: 'bold', fontSize: '14px', marginRight: '10px' }}>
                                                                                        {invoice.selectedClient?.name ? invoice.selectedClient.name[0] : 'C'}
                                                                                    </td>
                                                                                    <td style={{ paddingLeft: '10px' }}>
                                                                                        <div style={{ fontSize: '11px', fontWeight: 'bold', color: '#2c3e50' }}>{invoice.selectedClient?.name || 'Client Name'}</div>
                                                                                        <div style={{ fontSize: '9px', color: '#7f8c8d' }}>{invoice.selectedClient?.email || 'Email'}</div>
                                                                                    </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                        {invoice.logo && (
                                                                            <div style={{ marginTop: 8 }}>
                                                                                <img src={invoice.logo} alt="Logo" style={{ maxWidth: 60, maxHeight: 40, objectFit: 'contain', borderRadius: 8, border: '1px solid #e2e8f0' }} />
                                                                            </div>
                                                                        )}
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style={{ padding: '0 40px' }}>
                                                        <hr style={{ border: 'none', borderTop: '2px solid #2c3e50', margin: 0 }} />
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style={{ padding: '10px 40px' }}>
                                                        <div style={{ fontSize: '13px', fontWeight: 'bold', color: '#2c3e50', marginBottom: '15px' }}>Bill to: {invoice.selectedClient?.name || 'Client Name'}</div>
                                                        <table width="100%" cellPadding="0" cellSpacing="0">
                                                            <tbody>
                                                                <tr>
                                                                    <td width="25%" style={{ fontSize: '10px', color: '#2c3e50', paddingBottom: '5px', textAlign: 'left' }}>
                                                                        <strong>Client Name</strong><br />
                                                                        {invoice.selectedClient?.name || '-'}
                                                                    </td>
                                                                    <td width="25%" style={{ fontSize: '10px', color: '#2c3e50', paddingBottom: '5px', textAlign: 'left' }}>
                                                                        <strong>Email</strong><br />
                                                                        {invoice.selectedClient?.email || '-'}
                                                                    </td>
                                                                    <td width="25%" style={{ fontSize: '10px', color: '#2c3e50', paddingBottom: '5px', textAlign: 'left' }}>
                                                                        <strong>Client Address</strong><br />
                                                                        {invoice.selectedClient?.address || '-'}
                                                                    </td>
                                                                    <td width="25%" style={{ fontSize: '10px', color: '#2c3e50', paddingBottom: '5px', textAlign: 'left' }}>
                                                                        <strong>Phone Number</strong><br />
                                                                        {invoice.selectedClient?.phone || '-'}
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style={{ padding: '20px 40px' }}>
                                                        <table width="100%" cellPadding="0" cellSpacing="0" style={{ borderCollapse: 'collapse' }}>
                                                            <tbody>
                                                                <tr style={{ backgroundColor: '#ecf0f1' }}>
                                                                    <td style={{ border: '1px solid #bdc3c7', padding: '5px', fontWeight: 'bold', textAlign: 'center', width: '15%', fontSize: '12px' }}>Quantity</td>
                                                                    <td style={{ border: '1px solid #bdc3c7', padding: '5px', fontWeight: 'bold', textAlign: 'center', width: '15%', fontSize: '12px' }}>Description</td>
                                                                    <td style={{ border: '1px solid #bdc3c7', padding: '5px', fontWeight: 'bold', textAlign: 'center', width: '15%', fontSize: '12px' }}>Unit Price</td>
                                                                    <td style={{ border: '1px solid #bdc3c7', padding: '5px', fontWeight: 'bold', textAlign: 'center', width: '15%', fontSize: '12px' }}>Total</td>
                                                                </tr>
                                                                {items.map((item, idx) => (
                                                                    <tr key={idx}>
                                                                        <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>{item.quantity || 0}</td>
                                                                        <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>{item.description || item.name || '-'}</td>
                                                                        <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>
                                                                            {symbol}{(Number(item.rate) || 0).toFixed(2)}
                                                                        </td>
                                                                        <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>
                                                                            {symbol}{((Number(item.quantity) || 0) * (Number(item.rate) || 0)).toFixed(2)}
                                                                        </td>
                                                                    </tr>
                                                                ))}
                                                                <tr>
                                                                    <td colSpan="2" style={{ padding: '5px', textAlign: 'center', fontSize: '10px', border: 0 }}>&nbsp;</td>
                                                                    <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>&nbsp; Subtotal:</td>
                                                                    <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>
                                                                        {symbol}{subtotal ? subtotal.toFixed(2) : '0.00'}
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td colSpan="2" style={{ padding: '5px', textAlign: 'center', fontSize: '10px', border: 0 }}>&nbsp;</td>
                                                                    <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>&nbsp; Discount:</td>
                                                                    <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>
                                                                        {symbol}{discount ? discount.toFixed(2) : '0.00'}
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td colSpan="2" style={{ padding: '5px', textAlign: 'center', fontSize: '10px', border: 0 }}>&nbsp;</td>
                                                                    <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>&nbsp; Tax:</td>
                                                                    <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>
                                                                        {symbol}{tax ? tax.toFixed(2) : '0.00'}
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td colSpan="2" style={{ padding: '5px', textAlign: 'center', fontSize: '10px', border: 0 }}>&nbsp;</td>
                                                                    <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>&nbsp; Total:</td>
                                                                    <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>
                                                                        {symbol}{total ? total.toFixed(2) : '0.00'}
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style={{ padding: '10px 40px' }}>
                                                        <table width="100%" cellPadding="0" cellSpacing="0">
                                                            <tbody>
                                                                <tr>
                                                                    <td width="20%" style={{ paddingRight: '20px' }}>
                                                                        <div style={{ borderBottom: '1px solid #2c3e50', marginBottom: '5px', height: '16px' }}></div>
                                                                        <div style={{ fontSize: '10px', color: '#7f8c8d' }}>Signature</div>
                                                                        <br />
                                                                        <div style={{ fontSize: '10px', color: '#34495e' }}>{todayFormatted}</div>
                                                                        <div style={{ borderBottom: '1px solid #2c3e50', marginBottom: '5px', height: '16px' }}></div>
                                                                        <div style={{ fontSize: '10px', color: '#7f8c8d' }}>Date</div>
                                                                    </td>
                                                                    <td width="20%" style={{ paddingLeft: '20px' }}>
                                                                        <div style={{ borderBottom: '1px solid #2c3e50', marginBottom: '5px', height: '16px' }}></div>
                                                                        <div style={{ fontSize: '10px', color: '#7f8c8d' }}>Printed Name</div>
                                                                        <br />
                                                                        <div style={{ borderBottom: '1px solid #2c3e50', marginBottom: '5px', height: '16px' }}></div>
                                                                        <div style={{ fontSize: '10px', color: '#7f8c8d' }}>Payment method</div>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style={{ padding: '20px 40px 0 40px' }}>
                                                        <hr style={{ border: 'none', borderTop: '2px solid #2c3e50', margin: 0 }} />
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style={{ padding: '20px 40px 20px 40px' }}>
                                                        <div style={{ fontSize: '12px', fontWeight: 'bold', color: '#2c3e50', marginBottom: '10px', textAlign: 'left' }}>Notes</div>
                                                        <div style={{ fontSize: '9px', color: '#7f8c8d', lineHeight: 1.4, textAlign: 'left' }}>
                                                            {invoice.comment || 'No additional notes.'}
                                                        </div>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            </div>
        </div>
    );
}

// Export 3 functions using the same template
function Classic(invoices, ref) {
    return invoiceTemplate({ invoices, ref });
}

export default Classic;