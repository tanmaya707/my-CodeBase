/* eslint-disable @next/next/no-img-element */
import React, { use, useEffect } from 'react';
import '../../app/general.css';
import '../../Components/addItemForm/addItemForm.css';
import { formatCurrency } from '@/dependencies/utils/helper';


// Helper: currency symbols
const currencySymbols = {
    INR: "₹",
    USD: "$",
    EUR: "€",
    GBP: "£",
    JPY: "¥",
    AUD: "A$",
    CAD: "C$",
    SGD: "S$",
    CNY: "¥",
};

// Helper: format date as dd-mm-yyyy
function formatDate(dateStr) {
    if (!dateStr) return '';
    const date = new Date(dateStr);
    const dd = String(date.getDate()).padStart(2, '0');
    const mm = String(date.getMonth() + 1).padStart(2, '0');
    const yyyy = date.getFullYear();
    return `${dd}-${mm}-${yyyy}`;
}

function Impact({
    selectedTemp = "Your",
    selectedId = { logoImage: "" },
    selectedSize,
    alignPos = "center",
    selectedColour,
    customColour,
    selectedHeader = "Invoice",
    selectedWatermark = "Paid",
    customTemplates = [],
    customOption = {},
    signatureName = "none",
    signatureType = "none",
    signature,
    currencyList = [],
    invoice: invoiceProp = {},
    termsInfo = {},
    ref
}) {
    const {
        due_date,
        payment_terms,
        itemCode,
        quantityAndRate,
        pTax,
        tax_amounts,
        includeSignatureLine,
        invoicePrifix
    } = customOption;

    console.log("currencyList ::: ", currencyList);

    const invoice = invoiceProp.invoice || invoiceProp;
    const _formatted = formatCurrency(0, currencyList) || '$0.00';
    const symbol = (_formatted.match(/^([^\d\.\s-]+)/) || [null, '$'])[1];

    let items;
    if (typeof invoice?.items === "string") {
        try {
            items = JSON.parse(invoice.items) || [
                { quantity: 2, description: "Consulting Services", rate: 150, taxPercent: 18 },
            ];
        } catch (err) {
            console.error("Error parsing items JSON:", err);
            items = [];
        }
    } else {
        items = invoice?.items || [
            { quantity: 2, description: "Consulting Services", rate: 150, taxPercent: 18 },
        ];
    }


    // if(signature && signatureType !== "none") {
    //     if (signatureType === "pad") {
    //         invoice.companySignature = signature.padSignature;
    //     } else if (signatureType === "upload") {
    //         invoice.companySignature = signature.uploadSignature;
    //     } else if (signatureType === "text") {
    //         invoice.companySignature = signature.signatureText;
    //     }
    // }

    let signatureContent = null;

    if (signatureName  && signatureName != "none") {
        if (signatureType === "pad") {
            if (signature.padSignature) {
                signatureContent = (
                    <img
                        src={`data:image/png;base64,${signature.padSignature}`}
                        alt="Signature"
                        width={120}
                        height={32}
                        style={{ maxWidth: 120, maxHeight: 32, borderRadius: 6, background: '#fff', height: 'auto', width: 'auto' }}
                    />
                );
            }
        } else if(signatureType === "upload"){
            if (signature.uploadSignature) {
                signatureContent = (
                    <img
                        src={`data:image/png;base64,${signature.uploadSignature}`}
                        alt="Signature"
                        width={120}
                        height={32}
                        style={{ maxWidth: 120, maxHeight: 32, borderRadius: 6, background: '#fff', height: 'auto', width: 'auto' }}
                    />
                );
            }
        } else if (signatureType === "text" && signature.signatureText) {
            signatureContent = (
                <span style={{ fontFamily: "cursive", fontSize: 24, color: "#222" }}>
                    {signature.signatureText}
                </span>
            );
        }
    }
    
    const subtotal = typeof invoice.subtotal === "number"
        ? invoice.subtotal
        : items?.reduce((sum, item) => sum + ((Number(item.quantity) || 0) * (Number(item.rate) || 0)), 0);
    const discount = typeof invoice.discountTotal === "number"
        ? invoice.discountTotal
        : 0;
    const tax = typeof invoice.gstTotal === "number"
        ? invoice.gstTotal
        : ((subtotal - discount) * (items[0]?.taxPercent || 0)) / 100;
    const total = typeof invoice.total === "number"
        ? invoice.total
        : subtotal - discount + tax;

    const taxAmount = tax_amounts ? (subtotal - discount) : null;

    const todayFormatted = formatDate(new Date().toISOString());
    const invoiceDate = formatDate(invoice.invoiceDate);
    const dueDate = formatDate(invoice.dueDate);

    const headerColor = selectedColour?.colourCode || selectedColour || customColour || '#ecf0f1';
    const logoUrl = selectedId?.logoImage;
    const headerImg = selectedHeader?.headerImg || '';
    const logoAlign = alignPos || 'center';
    const watermarkImg = selectedWatermark?.waterMarkImg || '';

    let logoFontSize;
    switch (selectedSize) {
        case "small":
            logoFontSize = "80px";
            break;
        case "large":
            logoFontSize = "140px";
            break;
        default:
            logoFontSize = "110px";
    }

    // Invoice number with prefix
    const invoiceNumber = `${invoicePrifix || ''}${invoice.invoiceNumber || invoice.creditMemoNumber || invoice.poNumber || '0000'}`;

    // Table columns logic
    const showItemCode = !!itemCode;
    const showQuantityAndRate = !!quantityAndRate;
    const showPTax = !!pTax;

    // Table header columns
    const tableHeaders = [];
    if (showItemCode) tableHeaders.push({ label: "Item Code", style: { width: '10%' } });
    if (showQuantityAndRate) tableHeaders.push({ label: "Quantity", style: { width: '15%' } });
    tableHeaders.push({ label: "Description", style: { width: '35%' } });
    if (showQuantityAndRate) tableHeaders.push({ label: "Unit Price", style: { width: '15%' } });
    if (showPTax) tableHeaders.push({ label: "Tax", style: { width: '10%' } });
    tableHeaders.push({ label: "Amount", style: { width: '15%' } });

    // useEffect(() => {
    //     console.log("invoice in impact ::: ", invoiceProp);
    // }, [invoiceProp]);

    return (
        <div ref={ref} className='row ' style={{ margin: 0, padding: 0, height: '100%', minHeight: '100vh' }}>
            <div className='col-md-12' style={{ margin: 0, padding: 0, height: '100%' }}>
                <div
                    className="preview-card"
                    style={{
                        padding: 0,
                        margin: 0,
                        position: 'relative',
                        overflow: 'hidden',
                        height: '100%',
                        minHeight: '100vh',
                        boxSizing: 'border-box',
                        background: '#f5f5f5'
                    }}
                >
                    <div
                        className="tableTopContainer "
                        style={{
                            margin: 0,
                            padding: 0,
                            fontFamily: 'Arial, sans-serif',
                            backgroundColor: '#f5f5f5',
                            position: 'relative',
                            zIndex: 3,
                            minHeight: 'calc(100vh - 80px)'
                        }}
                    >
                        <table className='customisePdfCssOnly'
                            width="100%"
                            cellPadding="0"
                            cellSpacing="0"
                            style={{
                                backgroundColor: '#f5f5f5',
                             
                                paddingRight: 2,
                                margin: 0,
                                height: '100%',
                                borderCollapse: 'separate'
                            }}
                        >
                            <tbody>
                                <tr>
                                    <td align="center" style={{ padding: 0, margin: 0 }}>
                                        <table
                                            width="100%"
                                            cellPadding="0"
                                            cellSpacing="0"
                                            style={{
                                                backgroundColor: '#ffffff',
                                                borderRadius: '8px',
                                                boxShadow: '0 2px 10px rgba(0,0,0,0.1)',
                                                position: 'relative',
                                                margin: 0,
                                                padding: 0,
                                                height: '100%'
                                            }}
                                        >
                                            <tbody>
                                                {watermarkImg && <img src={watermarkImg} alt="Watermark" style={{
                                                    position: 'absolute',
                                                    top: '50%',
                                                    left: '50%',
                                                    transform: 'translate(-50%, -50%)',
                                                    opacity: 0.12,
                                                    zIndex: 1,
                                                    pointerEvents: 'none',
                                                    width: '60%',
                                                    maxWidth: '400px',
                                                }} />}
                                                {headerImg && <img src={headerImg} alt="Header Image" style={{
                                                    width: '100%',
                                                    height: 80,
                                                    background: `url(${headerImg}) center center / cover no-repeat`,
                                                    margin: 0,
                                                    padding: 0,
                                                    borderTopLeftRadius: 8,
                                                    borderTopRightRadius: 8
                                                }} />}
                                                <tr>
                                                    <td style={{ padding: '10px 40px 0 40px' }}>
                                                        <table width="100%" cellPadding="0" cellSpacing="0">
                                                            <tbody>
                                                                <tr>
                                                                    {/* Invoice ID */}
                                                                    <td style={{
                                                                        fontSize: '16px',
                                                                        fontWeight: 'bold',
                                                                        color: '#2c3e50',
                                                                        textAlign: 'left',
                                                                        verticalAlign: 'middle',
                                                                        width: '33%',
                                                                        paddingRight: 10
                                                                    }}>
                                                                        {invoice.name} #{invoiceNumber}
                                                                    </td>
                                                                    {/* Logo */}
                                                                    <td style={{
                                                                        textAlign: logoAlign,
                                                                        width: '33%',
                                                                        verticalAlign: 'middle',
                                                                        padding: 0
                                                                    }}>
                                                                        {logoUrl && (
                                                                            <img
                                                                                src={logoUrl}
                                                                                alt="Logo"
                                                                                style={{
                                                                                    width: logoFontSize,
                                                                                    objectFit: 'contain',
                                                                                    borderRadius: 8,
                                                                                    border: '1px solid #e2e8f0',
                                                                                    display: 'inline-block',
                                                                                    verticalAlign: 'middle'
                                                                                }}
                                                                            />
                                                                        )}
                                                                    </td>
                                                                    <td style={{
                                                                        textAlign: 'right',
                                                                        width: '33%',
                                                                        verticalAlign: 'middle',
                                                                        paddingLeft: 10
                                                                    }}>
                                                                        <div style={{ fontSize: '13px', fontWeight: 'bold', color: '#2c3e50' }}>
                                                                            {invoice.selectedClient?.name || 'Client Name'}
                                                                        </div>
                                                                        <div style={{ fontSize: '10px', color: '#7f8c8d' }}>
                                                                            {invoice.selectedClient?.email || 'Email'}
                                                                        </div>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td colSpan={3} style={{ paddingTop: 8, paddingBottom: 8 }}>
                                                                        <div style={{
                                                                            textAlign: 'end',
                                                                            display: 'flex',
                                                                            flexDirection: 'column',
                                                                            fontSize: '12px',
                                                                            color: '#34495e',
                                                                            fontWeight: 500,
                                                                            lineHeight: '18px'
                                                                        }}>
                                                                            <div><strong>Date:</strong> {formatDate(new Date().toISOString())}</div>
                                                                        {invoice.name == "Invoice" && (
                                                                            <>
                                                                                {payment_terms && <div><strong>Terms:</strong> {invoice.paymentTerms || '0'}</div>}
                                                                                {due_date && <div><strong>Due Date:</strong> {dueDate || todayFormatted}</div>}
                                                                            </>
                                                                        )}
                                                                        </div>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style={{ padding: '10px 40px' }}>
                                                        <hr style={{ border: 'none', borderTop: `2px solid black`, margin: 0 }} />
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style={{ padding: '10px 40px' }}>
                                                        <div style={{ fontSize: '13px', fontWeight: 'bold', color: '#2c3e50', marginBottom: '15px', textAlign: 'left' }}>
                                                            Bill to: {invoice.selectedClient?.name || 'Client Name'}
                                                        </div>
                                                        <table width="100%" cellPadding="0" cellSpacing="0">
                                                            <tbody>
                                                                <tr>
                                                                    <td width="25%" style={{ fontSize: '10px', color: '#2c3e50', paddingBottom: '5px', textAlign: 'left' }}>
                                                                        <strong>Client Name</strong><br />
                                                                        {invoice.selectedClient?.name || '-'}
                                                                    </td>
                                                                    <td width="25%" style={{ fontSize: '10px', color: '#2c3e50', paddingBottom: '5px', textAlign: 'left' }}>
                                                                        <strong>Email</strong><br />
                                                                        {invoice.selectedClient?.email || '-'}
                                                                    </td>
                                                                    <td width="25%" style={{ fontSize: '10px', color: '#2c3e50', paddingBottom: '5px', textAlign: 'left' }}>
                                                                        <strong>Client Address</strong><br />
                                                                        {invoice.selectedClient?.address || '-'}
                                                                    </td>
                                                                    <td width="25%" style={{ fontSize: '10px', color: '#2c3e50', paddingBottom: '5px', textAlign: 'left' }}>
                                                                        <strong>Phone Number</strong><br />
                                                                        {invoice.selectedClient?.phone || '-'}
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style={{ padding: '20px 40px' }}>
                                                        <table width="100%" cellPadding="0" cellSpacing="0" style={{ borderCollapse: 'collapse' }}>
                                                            <thead>
                                                                <tr style={{ backgroundColor: headerColor }}>
                                                                    {tableHeaders.map((th, idx) => (
                                                                        <td
                                                                            key={idx}
                                                                            style={{
                                                                                border: '1px solid #bdc3c7',
                                                                                padding: '5px',
                                                                                fontWeight: 'bold',
                                                                                textAlign: 'center',
                                                                                fontSize: '12px',
                                                                                ...(tableHeaders.length === 2 ? { width: '50%' } : th.style)
                                                                            }}
                                                                        >
                                                                            {th.label}
                                                                        </td>
                                                                    ))}
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                {items.map((item, idx) => {
                                                                      const maxLen = 30;
                                                                      const description =
                                                                          item?.item_Description ?? item?.description ?? '';
                                                                      const shortDescription =
                                                                          description.length > maxLen
                                                                              ? description.slice(0, maxLen) + '...'
                                                                              : description;
                                                                      return (
                                                                          <tr key={idx}>
                                                                              {showItemCode && (
                                                                                  <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>
                                                                                      {item.code || ''}
                                                                                  </td>
                                                                              )}
                                                                              {showQuantityAndRate && (
                                                                                  <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>
                                                                                      {item.quantity || 0}
                                                                                  </td>
                                                                              )}
                                                                              <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>
                                                                                  {shortDescription || item.name || '-'}
                                                                              </td>
                                                                              {showQuantityAndRate && (
                                                                                  <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>
                                                                                      {symbol}{(Number(item.rate) || 0).toFixed(2)}
                                                                                  </td>
                                                                              )}
                                                                              {showPTax && (
                                                                                  <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>
                                                                                      {item.gstValue || 0}%
                                                                                  </td>
                                                                              )}
                                                                              <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>
                                                                                  {symbol}{((Number(item.quantity) || 0) * (Number(item.rate) || 0) - (Number(item.discountValue) || 0)).toFixed(2)}
                                                                                  {item.discountValue ? (
                                                                                      <span style={{ color: '#e74c3c', fontSize: '9px' }}>
                                                                                          &nbsp;(-{symbol}{(Number(item.discountValue) || 0).toFixed(2)})
                                                                                      </span>
                                                                                  ) : null}
                                                                              </td>
                                                                          </tr>
                                                                      );
                                                                  })}
                                                                {/* Subtotal, Discount, Tax, Total */}
                                                                {(() => {
                                                                    if (tableHeaders.length === 2) {
                                                                        return (
                                                                            <>
                                                                                <tr>
                                                                                    <td style={{ padding: '5px', textAlign: 'right', fontSize: '10px' }}>&nbsp; Subtotal:</td>
                                                                                    <td style={{ padding: '5px', textAlign: 'left', fontSize: '10px' }}>
                                                                                        {symbol}{subtotal ? subtotal.toFixed(2) : '0.00'}
                                                                                    </td>
                                                                                </tr>                                                                   <tr>
                                                                                    <td style={{ padding: '5px', textAlign: 'right', fontSize: '10px' }}>&nbsp; Discount:</td>
                                                                                    <td style={{ padding: '5px', textAlign: 'left', fontSize: '10px' }}>
                                                                                        -{symbol}{discount ? discount.toFixed(2) : '0.00'}
                                                                                    </td>
                                                                                    </tr>
                                                                                {tax_amounts && (
                                                                                        <tr>
                                                                                        <td style={{ padding: '5px', textAlign: 'right', fontSize: '10px', borderBottom: '1px solid #2c3e50' }}>&nbsp; Tax</td>
                                                                                        <td style={{ padding: '5px', textAlign: 'left', fontSize: '10px', borderBottom: '1px solid #2c3e50' }}>
                                                                                        {symbol}{tax ? tax.toFixed(2) : '0.00'}
                                                                                        </td>
                                                                                        </tr>
                                                                                    )}
                                                                                {!tax_amounts && (
                                                                                        <tr>
                                                                                        <td style={{ padding: '5px', textAlign: 'right', fontSize: '10px', borderBottom: '1px solid #2c3e50' }}></td>
                                                                                        <td style={{ padding: '5px', textAlign: 'left', fontSize: '10px', borderBottom: '1px solid #2c3e50' }}>
                                                                                        </td>
                                                                                        </tr>
                                                                                    )}
                                                                                <tr>
                                                                                    <td style={{ padding: '5px', textAlign: 'right', fontSize: '10px' }}>&nbsp; Total:</td>
                                                                                    <td style={{ padding: '5px', textAlign: 'left', fontSize: '10px' }}>
                                                                                        {symbol}{total ? total.toFixed(2) : '0.00'}
                                                                                    </td>
                                                                                </tr>
                                                                            </>
                                                                        );
                                                                    }
                                                                    return (
                                                                        <>
                                                                            <tr>
                                                                                <td colSpan={tableHeaders.length - 2} style={{ padding: '5px', textAlign: 'center', fontSize: '10px', border: 0 }}>&nbsp;</td>
                                                                                <td style={{ padding: '5px', textAlign: 'end', fontSize: '10px' }}>&nbsp; Subtotal:</td>
                                                                                <td style={{ padding: '5px', textAlign: 'center', fontSize: '10px' }}>
                                                                                    {symbol}{subtotal ? subtotal.toFixed(2) : '0.00'}
                                                                                </td>
                                                                            </tr>
                                                                                    <tr>
                                                                                        <td colSpan={tableHeaders.length - 2} style={{ padding: '5px', textAlign: 'center', fontSize: '10px', border: 0 }}>&nbsp;</td>
                                                                                        <td style={{ padding: '5px', textAlign: 'end', fontSize: '10px' }}>&nbsp; Discount:</td>
                                                                                        <td style={{ padding: '5px', textAlign: 'center', fontSize: '10px' }}>
                                                                                            -{symbol}{discount ? discount.toFixed(2) : '0.00'}
                                                                                        </td>
                                                                                    </tr>
                                                                            
                                                                             {tax_amounts && (
                                                                                    <tr>
                                                                                    <td colSpan={tableHeaders.length - 2} style={{ padding: '5px', textAlign: 'center', fontSize: '10px', border: 0 }}>&nbsp;</td>
                                                                                <td style={{ padding: '5px', textAlign: 'end', fontSize: '10px', borderBottom: '1px solid #2c3e50' }}>&nbsp; Tax:</td>
                                                                                <td style={{ padding: '5px', textAlign: 'center', fontSize: '10px', borderBottom: '1px solid #2c3e50' }}>
                                                                                    {symbol}{tax ? tax.toFixed(2) : '0.00'}
                                                                                </td>
                                                                                </tr>
                                                                            )}

                                                                            {!tax_amounts && (
                                                                                    <tr>
                                                                                    <td colSpan={tableHeaders.length - 2} style={{ padding: '5px', textAlign: 'center', fontSize: '10px', border: 0 }}></td>
                                                                                <td style={{ padding: '5px', textAlign: 'end', fontSize: '10px', borderBottom: '1px solid #2c3e50' }}></td>
                                                                                <td style={{ padding: '5px', textAlign: 'center', fontSize: '10px', borderBottom: '1px solid #2c3e50' }}>
                                                    
                                                                                </td>
                                                                                </tr>
                                                                            )}
                                                                            <tr>
                                                                                <td colSpan={tableHeaders.length - 2} style={{ padding: '5px', textAlign: 'center', fontSize: '10px', border: 0 }}>&nbsp;</td>
                                                                                <td style={{ padding: '5px', textAlign: 'end', fontSize: '10px' }}>&nbsp; Total:</td>
                                                                                <td style={{ padding: '5px', textAlign: 'center', fontSize: '10px' }}>
                                                                                    {symbol}{total ? total.toFixed(2) : '0.00'}
                                                                                </td>
                                                                            </tr>
                                                                        </>
                                                                    );
                                                                })()}
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                                {/* Deposit Amount */}
                                                {invoice.depositAmount && (
                                                    <tr>
                                                        <td colSpan={tableHeaders.length} style={{ padding: '5px 40px', textAlign: 'center', fontSize: '10px' }}>
                                                            Deposit Due {formatDate(invoice.depositAmount?.dueDate)} &nbsp;&nbsp; {symbol}{invoice.depositAmount?.amount ? Number(invoice.depositAmount.amount).toFixed(2) : '0.00'}
                                                        </td>
                                                    </tr>
                                                )}
                                                {/* Signature & Payment Info */}
                                                <tr>
                                                    <td style={{ padding: '10px 40px' }}>
                                                        <table width="100%" cellPadding="0" cellSpacing="0">
                                                            <tbody>
                                                                <tr>
                                                                    <td width="20%" style={{ paddingRight: '20px' }}>
                                                                        {includeSignatureLine && (
                                                                            <>
                                                                            <>
                                                                                {signatureContent}
                                                                                    <div style={{ borderBottom: '1px solid #2c3e50', marginBottom: '5px', height: '16px' }}></div>
                                                                                </>
                                                                                {/* <div style={{ borderBottom: '1px solid #2c3e50', marginBottom: '5px', height: '16px' }}></div> */}
                                                                                <div style={{ fontSize: '10px', color: '#7f8c8d' }}>Raise Invoice</div>
                                                                                <br />
                                                                            </>
                                                                        )}
                                                                        <div style={{ fontSize: '10px', color: '#34495e' }}>{todayFormatted}</div>
                                                                        <div style={{ borderBottom: '1px solid #2c3e50', marginBottom: '5px', height: '16px' }}></div>
                                                                        <div style={{ fontSize: '10px', color: '#7f8c8d' }}>Date</div>
                                                                    </td>
                                                                    <td width="20%" style={{ paddingLeft: '20px',verticalAlign: 'top' }}>
                                                                        {includeSignatureLine && (
                                                                            <>
                                                                                <div style={{ borderBottom: '1px solid #2c3e50', marginBottom: '5px', height: '16px' }}></div>
                                                                                <div style={{ fontSize: '10px', color: '#7f8c8d' }}>Client&apos;s Signature</div>
                                                                                <br />
                                                                            </>
                                                                        )}
                                                                        <div style={{ borderBottom: '1px solid #2c3e50', marginBottom: '5px', height: '31px' }}></div>
                                                                        <div style={{ fontSize: '10px', color: '#7f8c8d' }}>Payment method</div>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                                {/* Notes */}
                                                <tr>
                                                    <td style={{ padding: '20px 40px 0 40px' }}>
                                                        <hr style={{ border: 'none', borderTop: `2px solid #2c3e50`, margin: 0 }} />
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style={{ padding: '20px 40px 20px 40px' }}>
                                                        <div style={{ fontSize: '12px', fontWeight: 'bold', color: '#2c3e50', marginBottom: '10px', textAlign: 'left' }}>Notes</div>
                                                        <div style={{ fontSize: '9px', color: '#7f8c8d', lineHeight: 1.4, textAlign: 'left' }}>
                                                            {invoice.comment || 'No additional notes.'}
                                                        </div>
                                                    </td>
                                                </tr>
                                                {/* watermark removed from preview */}
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Impact;