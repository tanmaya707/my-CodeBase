import React from 'react';

// Helper: currency symbols
const currencySymbols = {
  INR: "₹",
  USD: "$",
  EUR: "€",
  GBP: "£",
  JPY: "¥",
  AUD: "A$",
  CAD: "C$",
  SGD: "S$",
  CNY: "¥",
};

// Helper: get image src from file object or string
function getImageSrc(file) {
    if (!file) return '';
    if (typeof file === 'string') return file;
    if (file.preview) return file.preview;
    if (file.url) return file.url;
    return '';
}

// Helper: format date as dd-mm-yyyy
function formatDate(dateStr) {
    if (!dateStr) return '';
    const date = new Date(dateStr);
    const dd = String(date.getDate()).padStart(2, '0');
    const mm = String(date.getMonth() + 1).padStart(2, '0');
    const yyyy = date.getFullYear();
    return `${dd}-${mm}-${yyyy}`;
}

// Main template function
function invoiceTemplate({ invoice, logoFile, photoFiles, onBackToEdit, ref}) {
    const symbol = currencySymbols[invoice.currency] || invoice.currency;
    const subtotal = invoice.items.reduce((sum, item) => sum + (Number(item.quantity) * Number(item.price)), 0);
    const discount = invoice.discountType === 'percent'
        ? subtotal * (Number(invoice.discountValue) / 100)
        : Number(invoice.discountValue);
    let tax = 0, total = 0;
    if (invoice.taxInclusive) {
        const divisor = 1 + (Number(invoice.taxRate) / 100);
        const taxable = subtotal - discount;
        tax = taxable - (taxable / divisor);
        total = taxable;
    } else {
        tax = (subtotal - discount) * (Number(invoice.taxRate) / 100);
        total = subtotal - discount + tax;
    }
    const todayFormatted = formatDate(new Date().toISOString());

    let signatureContent = null;
    if (invoice.signatureType === "pad" || invoice.signatureType === "upload") {
        if (invoice.signatureData) {
            signatureContent = (
                <img
                    src={`data:image/png;base64,${invoice.signatureData}`}
                    alt="Signature"
                    width={120}
                    height={32}
                    style={{ maxWidth: 120, maxHeight: 32, border: '1px solid #cbd5e1', borderRadius: 6, background: '#fff', height: 'auto', width: 'auto' }}
                />
            );
        }
    } else if (invoice.signatureType === "text" && invoice.signatureText) {
        signatureContent = (
            <span style={{ fontFamily: "cursive", fontSize: 24, color: "#222" }}>
                {invoice.signatureText}
            </span>
        );
    }

    return (
        <div ref={ref}>
        <div>
             <div className="preview-card" style={{ backgroundColor: '#f2fafe' }}>
                <div className="tableTopContainer" style={{ margin: 0, padding: 0, fontFamily: 'Arial, sans-serif', backgroundColor: '#f5f5f5' }}>
                    <table width="100%" cellPadding="0" cellSpacing="0" style={{ backgroundColor: '#f5f5f5', padding: '20px' }}>
                        <tbody>
                            <tr>
                                <td align="center">
                                    <table width="100%" cellPadding="0" cellSpacing="0" style={{ backgroundColor: '#ffffff', borderRadius: '8px', boxShadow: '0 2px 10px rgba(0,0,0,0.1)' }}>
                                        <tbody>
                                            <tr>
                                                <td style={{ padding: '10px 40px' }}>
                                                    <table width="100%" cellPadding="0" cellSpacing="0">
                                                        <tbody>
                                                            <tr>
                                                                <td style={{ fontSize: '22px', fontWeight: 'bold', color: '#2c3e50', textAlign: 'left' }}>
                                                                    Invoice #{invoice.number || '0000'}
                                                                </td>
                                                                <td align="right" style={{ verticalAlign: 'top', textAlign: 'right', width: "14%" }}>
                                                                    <table cellPadding="0" cellSpacing="0">
                                                                        <tbody>
                                                                            <tr>
                                                                                {!logoFile && (
                                                                                <td style={{ backgroundColor: '#2c3e50', color: 'white', padding: '8px 22px', borderRadius: '50%', fontWeight: 'bold', fontSize: '14px', marginRight: '10px' }}>
                                                                                    {invoice.from.businessName ? invoice.from.businessName[0] : 'E'}
                                                                                </td>
                                                                                )}
                                                                                {logoFile && (
                                                                                    <div style={{ marginTop: 8 }}>
                                                                                        <img src={getImageSrc(logoFile)} alt="Logo" style={{ maxWidth: 60, maxHeight: 40, objectFit: 'contain', borderRadius: 8, border: '1px solid #e2e8f0' }} />
                                                                                    </div>
                                                                                )}
                                                                                <td style={{ paddingLeft: '10px' }}>
                                                                                    <div style={{ fontSize: '11px', fontWeight: 'bold', color: '#2c3e50' }}>{invoice.from.businessName || 'Business Name'}</div>
                                                                                    <div style={{ fontSize: '9px', color: '#7f8c8d' }}>{invoice.billTo.name || 'Contact Name'}</div>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style={{ padding: '0 40px' }}>
                                                    <hr style={{ border: 'none', borderTop: '2px solid #2c3e50', margin: 0 }} />
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style={{ padding: '10px 40px' }}>
                                                    <div style={{ fontSize: '13px', fontWeight: 'bold', color: '#2c3e50', marginBottom: '15px' }}>Bill to: {invoice.billTo.name || 'Contact Name'}</div>
                                                    <table width="100%" cellPadding="0" cellSpacing="0">
                                                        <tbody>
                                                            <tr>
                                                                <td width="25%" style={{ fontSize: '10px', color: '#2c3e50', paddingBottom: '5px', textAlign: 'left' }}>
                                                                    <strong>Client Name</strong><br />
                                                                    {invoice.billTo.name || '-'}
                                                                </td>
                                                                <td width="25%" style={{ fontSize: '10px', color: '#2c3e50', paddingBottom: '5px', textAlign: 'left' }}>
                                                                    <strong>Company Name</strong><br />
                                                                    {invoice.billTo.businessName || '-'}
                                                                </td>
                                                                <td width="25%" style={{ fontSize: '10px', color: '#2c3e50', paddingBottom: '5px', textAlign: 'left' }}>
                                                                    <strong>Client Address</strong><br />
                                                                    {invoice.billTo.address || '-'}
                                                                </td>
                                                                <td width="25%" style={{ fontSize: '10px', color: '#2c3e50', paddingBottom: '5px', textAlign: 'left' }}>
                                                                    <strong>Phone Number</strong><br />
                                                                    {invoice.billTo.phone || '-'}
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style={{ padding: '20px 40px' }}>
                                                    <table width="100%" cellPadding="0" cellSpacing="0" style={{ borderCollapse: 'collapse' }}>
                                                        <tbody>
                                                            <tr style={{ backgroundColor: '#ecf0f1' }}>
                                                                <td style={{ border: '1px solid #bdc3c7', padding: '5px', fontWeight: 'bold', textAlign: 'center', width: '15%', fontSize: '12px' }}>Quantity</td>
                                                                {/* <td style={{ border: '1px solid #bdc3c7', padding: '5px', fontWeight: 'bold', textAlign: 'center', width: '15%', fontSize: '12px' }}>Item #</td> */}
                                                                <td style={{ border: '1px solid #bdc3c7', padding: '5px', fontWeight: 'bold', textAlign: 'center', width: '15%', fontSize: '12px' }}>Description</td>
                                                                <td style={{ border: '1px solid #bdc3c7', padding: '5px', fontWeight: 'bold', textAlign: 'center', width: '15%', fontSize: '12px' }}>Unit Price</td>
                                                                <td style={{ border: '1px solid #bdc3c7', padding: '5px', fontWeight: 'bold', textAlign: 'center', width: '15%', fontSize: '12px' }}>Total</td>
                                                            </tr>
                                                            {invoice.items.map((item, idx) => (
                                                                <tr key={idx}>
                                                                    <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>{item.quantity}</td>
                                                                    {/* <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>{invoice.number || '0000'}</td> */}
                                                                    <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>{item.description}</td>
                                                                    <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>{symbol}{Number(item.price).toFixed(2)}</td>
                                                                    <td style={{ border: '1px solid #bdc3c7', padding: '5px', textAlign: 'center', fontSize: '10px' }}>{symbol}{(item.quantity * item.price).toFixed(2)}</td>
                                                                </tr>
                                                            ))}
                                                            <tr>
                                                                <td colSpan="2" style={{ padding: '5px', textAlign: 'center', fontSize: '10px', border: 0 }}>&nbsp;</td>
                                                                <td style={{ padding: '5px', textAlign: 'end', fontSize: '10px' }}>&nbsp; Subtotal:</td>
                                                                <td style={{ padding: '5px', textAlign: 'center', fontSize: '10px' }}>{symbol}{subtotal.toFixed(2)}</td>
                                                            </tr>
                                                            <tr>
                                                                <td colSpan="2" style={{ padding: '5px', textAlign: 'center', fontSize: '10px', border: 0 }}>&nbsp;</td>
                                                                <td style={{ padding: '5px', textAlign: 'end', fontSize: '10px' }}>&nbsp; Discount:</td>
                                                                <td style={{ padding: '5px', textAlign: 'center', fontSize: '10px' }}>{symbol}{discount.toFixed(2)}</td>
                                                            </tr>
                                                            <tr>
                                                                <td colSpan="2" style={{ padding: '5px', textAlign: 'center', fontSize: '10px', border: 0 }}>&nbsp;</td>
                                                                <td style={{ padding: '5px', textAlign: 'end', fontSize: '10px',borderBottom: '1px solid #2c3e50' }}>&nbsp; {invoice.taxLabel}:</td>
                                                                <td style={{ padding: '5px', textAlign: 'center', fontSize: '10px',borderBottom: '1px solid #2c3e50' }}>{symbol}{tax.toFixed(2)}</td>
                                                            </tr>
                                                            <tr>
                                                                <td colSpan="2" style={{ padding: '5px', textAlign: 'center', fontSize: '10px', border: 0 }}>&nbsp;</td>
                                                                <td style={{ padding: '5px', textAlign: 'end', fontSize: '10px' }}>&nbsp; Total:</td>
                                                                <td style={{ padding: '5px', textAlign: 'center', fontSize: '10px' }}>{symbol}{total.toFixed(2)}</td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style={{ padding: '10px 40px' }}>
                                                    <table width="100%" cellPadding="0" cellSpacing="0">
                                                        <tbody>
                                                            <tr>
                                                                <td width="20%" style={{ paddingRight: '20px' }}>
                                                                    {invoice.signatureData && (
                                                                    <>
                                                                    <div style={{ marginTop: 8 }}>
                                                                            <img
                                                                                src={`data:image/png;base64,${invoice.signatureData}`}
                                                                                alt="Signature"
                                                                                width={120}
                                                                                height={32}
                                                                                style={{ maxWidth: 120, maxHeight: 32, border: '1px solid #cbd5e1', borderRadius: 6, background: '#fff', height: 'auto', width: 'auto' }}
                                                                            />
                                                                        </div>
                                                                        <div style={{ borderBottom: '1px solid #2c3e50', marginBottom: '5px', height: '16px' }}></div>
                                                                    </>
                                                                    )}
                                                                    {!invoice.signatureData && (
                                                                    <>
                                                                    {signatureContent}
                                                                        <div style={{ borderBottom: '1px solid #2c3e50', marginBottom: '5px', height: '16px' }}></div>
                                                                    </>
                                                                    )}
                                                                    <div style={{ fontSize: '10px', color: '#7f8c8d' }}>Signature</div>
                                                                <br />
                                                                <div style={{ fontSize: '10px', color: '#34495e' }}>{todayFormatted}</div>
                                                                <div style={{ borderBottom: '1px solid #2c3e50', marginBottom: '5px', height: '16px' }}></div>
                                                                <div style={{ fontSize: '10px', color: '#7f8c8d' }}>Date</div>
                                                                    
                                                                </td>
                                                                <td width="20%" style={{ paddingLeft: '20px' }}>
                                                                    <div style={{ borderBottom: '1px solid #2c3e50', marginBottom: '5px', height: '16px' }}></div>
                                                                    <div style={{ fontSize: '10px', color: '#7f8c8d' }}>Printed Name</div>
                                                                    <br />
                                                                    <div style={{ borderBottom: '1px solid #2c3e50', marginBottom: '5px', height: '16px' }}></div>
                                                                    <div style={{ fontSize: '10px', color: '#7f8c8d' }}>Payment method</div>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style={{ padding: '20px 40px 0 40px' }}>
                                                    <hr style={{ border: 'none', borderTop: '2px solid #2c3e50', margin: 0 }} />
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style={{ padding: '20px 40px 20px 40px' }}>
                                                    <div style={{ fontSize: '12px', fontWeight: 'bold', color: '#2c3e50', marginBottom: '10px', textAlign: 'left' }}>Notes</div>
                                                    <div style={{ fontSize: '9px', color: '#7f8c8d', lineHeight: 1.4, textAlign: 'left' }}>
                                                        {invoice.notes || 'No additional notes.'}
                                                    </div>
                                                    {photoFiles && photoFiles.length > 0 && (
                                                        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginTop: 10 }}>
                                                            {photoFiles.map((photo, idx) => (
                                                                <img key={idx} src={getImageSrc(photo)} alt={`Photo ${idx + 1}`} style={{ maxWidth: 60, maxHeight: 60, borderRadius: 6, border: '1px solid #cbd5e1', objectFit: 'cover' }} />
                                                            ))}
                                                        </div>
                                                    )}
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        </div>
    );
}

// Export 3 functions using the same template
export function impact(invoice, logoFile, photoFiles, onBackToEdit, ref) {
    return invoiceTemplate({ invoice, logoFile, photoFiles, onBackToEdit, ref});
}

export function modern(invoice, logoFile, photoFiles, onBackToEdit) {
    return invoiceTemplate({ invoice, logoFile, photoFiles, onBackToEdit });
}

export function classic(invoice, logoFile, photoFiles, onBackToEdit) {
    return invoiceTemplate({ invoice, logoFile, photoFiles, onBackToEdit });
}