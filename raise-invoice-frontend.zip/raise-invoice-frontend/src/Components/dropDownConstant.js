
export const employeeCounts = [
  {
    id: 0,
    value: '0-19',
    title: '0 - 19'
  },
  {
    id: 1,
    value: '20-49',
    title: '20 - 49'
  },
  {
    id: 2,
    value: '50-99',
    title: '50 - 99'
  },
  {
    id: 3,
    value: '100-199',
    title: '100 - 199'
  },
  {
    id: 4,
    value: '200-499',
    title: '200 - 499'
  },
  {
    id: 5,
    value: '500-999',
    title: '500 - 999'
  },
  {
    id: 6,
    value: '1000+',
    title: '1000+'
  }
];

export const carList = [
    {
    id: 0,
    value: 'saab',
    title: 'Saab'
  },
  {
    id: 1,
    value: 'opel',
    title: 'Opel'
  },
  {
    id: 2,
    value: 'audi',
    title: 'Audi'
  }
];