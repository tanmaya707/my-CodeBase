"use client"
import React, { useState } from 'react'
import './cards.css';
import { IMAGE } from '@/utils/Theme';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faCircleCheck } from '@fortawesome/free-solid-svg-icons';
import {
    CircularProgressbar,
    buildStyles
} from "react-circular-progressbar";
import "react-circular-progressbar/dist/styles.css";
import Link from 'next/link';

const percentage = 76;


const Cards = () => {

    const [random, setRandom] = useState({
        percentage: 50,
        colour: "#34A853"
    });

    return (
        <>
            <div className='contentArea dashboard-contentArea'>
                <div className='locationQuerySec'>
                    <div className='row'>
                        <div className='col-lg-7 col-md-7 col-sm-12'>
                            <div className="card">
                                <div className="card-body">
                                    <h5 className="card-title headline">Overview   </h5>
                                    <div className="row">
                                        <div className="col-lg-6">
                                            <div className="card">
                                                <div className="card-body">
                                                    <div className='card-details'>
                                                        <div className='left'>
                                                            <p>Unsent Invoices</p>
                                                            <h4>$125</h4>
                                                        </div>
                                                        <div className='right'>
                                                            <h6>+ $500.00</h6>
                                                            <p>This Month</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-lg-6">
                                            <div className="card">
                                                <div className="card-body">
                                                    <div className='card-details'>
                                                        <div className='left'>
                                                            <p>Unsent Invoices</p>
                                                            <h4>$125</h4>
                                                        </div>
                                                        <div className='right'>
                                                            <h6>+ $500.00</h6>
                                                            <p>This Month</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-lg-6">
                                            <div className="card">
                                                <div className="card-body">
                                                    <div className='card-details'>
                                                        <div className='left'>
                                                            <p>Unsent Invoices</p>
                                                            <h4>$125</h4>
                                                        </div>
                                                        <div className='right'>
                                                            <h6>+ $500.00</h6>
                                                            <p>This Month</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-lg-6">
                                            <div className="card">
                                                <div className="card-body">
                                                    <div className='card-details'>
                                                        <div className='left'>
                                                            <p>Unsent Invoices</p>
                                                            <h4>$125</h4>
                                                        </div>
                                                        <div className='right'>
                                                            <h6>+ $500.00</h6>
                                                            <p>This Month</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-lg-6">
                                            <div className="card">
                                                <div className="card-body">
                                                    <div className='card-details'>
                                                        <div className='left'>
                                                            <p>Unsent Invoices</p>
                                                            <h4>$125</h4>
                                                        </div>
                                                        <div className='right'>
                                                            <h6>+ $500.00</h6>
                                                            <p>This Month</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div className="card">
                                <div className="card-body">
                                    <h5 className="card-title headline">Money (In Last 30 Days)</h5>
                                    <div className="row">
                                        <div className="col-lg-12">
                                            <div className="card">
                                                <div className="card-body">
                                                    <div className='card-details'>
                                                        <div className='left'>
                                                            <p>Overdue Invoices</p>
                                                            <h4>$125</h4>
                                                        </div>
                                                        <div className='right'>
                                                            <h6 className="lightDoller">+ $500.00</h6>
                                                            <p>This Month</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-lg-6">
                                            <div className="card">
                                                <div className="card-body money">
                                                    <img className="image-icon" src={IMAGE.cards} />
                                                    <div className='left'>
                                                        <p>Credit/Debit Cards</p>
                                                        <h4>$125</h4>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-lg-6">
                                            <div className="card">
                                                <div className="card-body money">
                                                    <img className="image-icon" src={IMAGE.bank} />
                                                    <div className='left'>
                                                        <p>Bank Transfer</p>
                                                        <h4>$125</h4>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-lg-6">
                                            <div className="card">
                                                <div className="card-body money">
                                                    <img className="image-icon" src={IMAGE.paypal} />
                                                    <div className='left'>
                                                        <p>PayPal</p>
                                                        <h4>$125</h4>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className='col-lg-5 col-md-5 col-sm-12'>
                            <div className='locationQuerySecRight'>

                                <img src={IMAGE.wallet} className='w-100' />
                                <div className='querySidebar'>
                                    <div className="card">
                                        <div className="card-body">
                                            <div className="card-title setup-guide">
                                                <div style={{ width: 60, height: 60 }}>
                                                    <CircularProgressbar
                                                        value={percentage}
                                                        text={`${percentage}%`}
                                                        strokeWidth={10}
                                                        styles={buildStyles({
                                                            textColor: "black",
                                                            pathColor: "#34A853",
                                                            trailColor: "white",
                                                        })}
                                                    />
                                                </div>
                                                <div className='setup-guide-text'>
                                                    <h4>Complete Your Setup guide</h4>
                                                    <h6>Your profile completion is at 50%</h6>
                                                    <p>You are so close! Complete Now</p>
                                                </div>
                                            </div>
                                            <div className='listPanel'>
                                                <div className='panel'>

                                                    <FontAwesomeIcon className="check_tick" icon={faCircleCheck} />
                                                    <span className="text-checked">Send your first invoice</span>

                                                </div>
                                                <div className='panel'>

                                                    <FontAwesomeIcon className="check_tick" icon={faCircleCheck} />
                                                    <span className="text-checked">Choose how to get paid</span>

                                                </div>
                                                <div className='panel'>
                                                    {/* /company-details */}
                                                    <Link href="/company-details" className="d-flex align-items-center text-decoration-none">
                                                        <FontAwesomeIcon className="check_tick_disabled" icon={faCircleCheck} />
                                                        <span className="ms-2">Set up your account</span>
                                                    </Link>
                                                </div>

                                                <div className='panel'>

                                                    <FontAwesomeIcon className="check_tick_disabled" icon={faCircleCheck} />
                                                    <span>Get started with invoicing</span>

                                                </div>
                                                <div className='panel'>

                                                    <FontAwesomeIcon className="check_tick_disabled" icon={faCircleCheck} />
                                                    <span>See our plans and pricing</span>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Cards
