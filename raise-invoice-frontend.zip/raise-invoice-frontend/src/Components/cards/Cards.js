"use client";
import React, { useState, useEffect } from "react";
import "./cards.css";
import { IMAGE } from "@/utils/Theme";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCircleCheck } from "@fortawesome/free-solid-svg-icons";
import { fetchDashboardData, fetchMasterData } from "@/redux/slices/dataSlice";
import { CircularProgressbar, buildStyles } from "react-circular-progressbar";
import { formatCurrency } from '@/dependencies/utils/helper';
import "react-circular-progressbar/dist/styles.css";
import { useDispatch } from 'react-redux';
import Link from "next/link";

const SETUP_GUIDE_ITEMS = [
  { key: "generalAccount", label: "Set up your general account", link: null },
  { key: "companyAccount", label: "Set up your company account", link: null },
  // { key: "templates", label: "Set up your Currency, Payment and Invoice Templates", link: "/company-details" },
  { key: "firstClient", label: "Create Your First Client", link: null },
  { key: "firstInvoice", label: "Create Your First Invoice", link: null },
];

const Cards = () => {
  const dispatch = useDispatch();
  const [isCardVisible, setIsCardVisible] = useState(true);
  const [isMoneyVisible, setIsMoneyVisible] = useState(true);
  const [isSectionVisible, setSectionVisible] = useState(true);
  const [currencyList, setCurrencyList] = useState([]);
  const [setupGuide, setSetupGuide] = useState({
    generalAccount: false,
    companyAccount: false,
    firstClient: false,
    firstInvoice: false,
  });
  const [invoiceStats, setInvoiceStats] = useState({
    totalSentAmount: 0,
    totalUnsentAmount: 0,
    totalAmount: 0,
    thisMonthSentAmount: 0,
    thisMonthUnsentAmount: 0,
    thisMonthTotalAmount: 0,
    totalPaidAmount: 0,
    thisMonthPaidAmount: 0,
    totalOverDueAmount: 0,
    thisMonthOverDueAmount: 0,
  });

    useEffect(() => {
    async function fetchData() {
        try {
        const data = await dispatch(fetchMasterData()).unwrap();
        setCurrencyList(data.currencyData || []);
        } catch (err) {
        console.error("Failed to fetch master data", err);
        }
    }
    fetchData();
    }, [dispatch]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await dispatch(fetchDashboardData({})).unwrap();
        const res = response?.data;
        setSetupGuide({
          generalAccount: !!res.isVerified,
          companyAccount: !!res.userCompany,
          // templates: !!res.InvoiceOptionSetting || !!res.InvoiceSetting,
          firstClient: !!res.clientCreation,
          firstInvoice: !!res.invoiceCreation,
        });
        setInvoiceStats(res.invoiceStats || {});
      } catch (e) {
        setSetupGuide({
          generalAccount: false,
          companyAccount: false,
          // templates: false,
          firstClient: false,
          firstInvoice: false,
        });
        setInvoiceStats({
          totalSentAmount: 0,
          totalUnsentAmount: 0,
          totalAmount: 0,
          thisMonthSentAmount: 0,
          thisMonthUnsentAmount: 0,
          thisMonthTotalAmount: 0,
          totalPaidAmount: 0,
          thisMonthPaidAmount: 0,
          totalOverDueAmount: 0,
          thisMonthOverDueAmount: 0,
        });
      }
    };
    fetchData();
  }, [dispatch]);

  const checkedCount = Object.values(setupGuide).filter(Boolean).length;
  // console.log("checkedCount ::: ", checkedCount);
  
  const percentage = checkedCount * 25;

  const toggleVisibility = (section) => {
    if (section === "Card") setIsCardVisible(!isCardVisible);
    else if (section === "Money") setIsMoneyVisible(!isMoneyVisible);
  };

  const closeSection = () => setSectionVisible(false);

  return (
    <>
      <div className="contentArea dashboard-contentArea">
        <img className="dashbaordBgImage" src={IMAGE.dahbordRight} alt="" />
        <div className="locationQuerySec">
          <div className="row">
            <div className={`col-xl-${isSectionVisible ? "7" : "12"} col-md-${isSectionVisible ? "7" : "12"} col-sm-12`}>
              <div className="card">
                <div className="card-body" style={{ width: "100%" }}>
                  <div
                    className="d-flex justify-content-between align-items-center card-title headline"
                    onClick={() => toggleVisibility("Card")}
                    style={{ cursor: "pointer" }}
                  >
                    <h5 className="card-title">Overview</h5>
                    <div className="toggleBtn text d-flex align-items-center">
                      {isCardVisible ? (
                        <>Hide&nbsp;<img src={IMAGE.dropDownTop} /></>
                      ) : (
                        <>Show&nbsp;<img src={IMAGE.dropDownDown} /></>
                      )}
                    </div>
                  </div>
                  {isCardVisible && (
                    <div className="overviewCard">
                      <div className="row pt-3">
                        <div className="col-xxl-4 col-lg-6 col-md-6 col-sm-12 mb-3">
                          <div className="card">
                            <div className="card-body">
                              <div className="card-details">
                                <div className="left">
                                  <p>Sent Invoices</p>
                                  <h4>{formatCurrency(invoiceStats.totalSentAmount ?? 0, currencyList)}</h4>
                                </div>
                                <div className="right">
                                  <h6>+ {formatCurrency(invoiceStats.thisMonthSentAmount ?? 0, currencyList)}</h6>
                                  <p>This Month</p>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="col-xxl-4 col-lg-6 col-md-6 col-sm-12 mb-3">
                          <div className="card">
                            <div className="card-body">
                              <div className="card-details">
                                <div className="left">
                                  <p>Unsent Invoices</p>
                                  <h4>{formatCurrency(invoiceStats.totalUnsentAmount ?? 0, currencyList)}</h4>
                                </div>
                                <div className="right">
                                  <h6>+ {formatCurrency(invoiceStats.thisMonthUnsentAmount ?? 0, currencyList)}</h6>
                                  <p>This Month</p>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="col-xxl-4 col-lg-6 col-md-6 col-sm-12 mb-3">
                          <div className="card">
                            <div className="card-body">
                              <div className="card-details">
                                <div className="left">
                                  <p>Total Invoices</p>
                                  <h4>{formatCurrency(invoiceStats.totalAmount ?? 0, currencyList)}</h4>
                                </div>
                                <div className="right">
                                  <h6>+ {formatCurrency(invoiceStats.thisMonthTotalAmount ?? 0, currencyList)}</h6>
                                  <p>This Month</p>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        {/* Add more cards as needed */}
                      </div>
                    </div>
                  )}
                </div>  
              </div>

              <div className="card cardFadeColor" style={isMoneyVisible ? { marginTop: "30px" } : {}}>
                <div className="card-body" style={{ width: "100%" }}>
                  <div
                    className="d-flex justify-content-between align-items-center card-title headline"
                    onClick={() => toggleVisibility("Money")}
                    style={{ cursor: "pointer" }}
                  >
                    <h5 className="card-title">Money (In Last 30 Days)</h5>
                    <a className="toggleBtn text d-flex align-items-center">
                      {isMoneyVisible ? (
                        <>Hide&nbsp;<img src={IMAGE.dropDownTop} /></>
                      ) : (
                        <>Show&nbsp;<img src={IMAGE.dropDownDown} /></>
                      )}
                    </a>
                  </div>
                  {isMoneyVisible && (
                    <div className="row pt-3">
                      <div className="col-lg-12">
                        <div className="card">
                          <div className="card-body">
                            <div className="card-details">
                              <div className="left">
                                <p>Overdue Invoices</p>
                                <h4>{formatCurrency(invoiceStats.totalOverDueAmount ?? 0, currencyList)}</h4>
                              </div>
                              <div className="right">
                                <h6 className="lightDoller">+ {formatCurrency(invoiceStats.thisMonthOverDueAmount ?? 0, currencyList)}</h6>
                                <p className="lightText">This Month</p>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="col-lg-12">
                        <div className="card">
                          <div className="card-body">
                            <div className="card-details">
                              <div className="left">
                                <p>Total Paid</p>
                                <h4>{formatCurrency(invoiceStats.totalPaidAmount ?? 0, currencyList)}</h4>
                              </div>
                              <div className="right">
                                <h6 className="lightDoller">+ {formatCurrency(invoiceStats.thisMonthPaidAmount ?? 0, currencyList)}</h6>
                                <p className="lightText">This Month</p>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      {/* Payment method cards (static, as no data in invoiceStats) */}
                      <div className={`col-lg-${isSectionVisible ? "6" : "4"} col-md-${isSectionVisible ? "6" : "6"} col-sm-6 col-xxl-4`}>
                        <div className="card">
                          <div className="card-body money">
                            <img className="image-icon" src={IMAGE.cards} alt="Credit/Debit Cards" />
                            <div className="left">
                              <p>Credit/Debit Cards</p>
                              <h4>{formatCurrency(125, currencyList)}</h4>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={`col-lg-${isSectionVisible ? "6" : "4"} col-md-${isSectionVisible ? "6" : "6"} col-sm-6 col-xxl-4`}>
                        <div className="card">
                          <div className="card-body money">
                            <img className="image-icon" src={IMAGE.bank} alt="Bank Transfer" />
                            <div className="left">
                              <p>Bank Transfer</p>
                              <h4>{formatCurrency(125, currencyList)}</h4>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={`col-lg-${isSectionVisible ? "6" : "4"} col-md-${isSectionVisible ? "6" : "6"} col-sm-6 col-xxl-4`}>
                        <div className="card">
                          <div className="card-body money">
                            <img className="image-icon" src={IMAGE.paypal} alt="PayPal" />
                            <div className="left">
                              <p>PayPal</p>
                              <h4>{formatCurrency(125, currencyList)}</h4>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {isSectionVisible && (
              <div className="col-5">
                <div className="locationQuerySecRight">
                  <div className="locationQuerySecRightCard">
                    <div className="locationQuerySecRightLeft">
                      <h2>RaiseInvoice Money</h2>
                      <h5>a service for faster payment and cash flow management</h5>
                    </div>
                    <div className="locationQuerySecRightImg">
                      <button onClick={closeSection} className="close-button btn btn-primary">
                        Close <img src={IMAGE.cross} alt="" />
                      </button>
                    </div>
                    <img src={IMAGE.wallet3} className="w-100" alt="Wallet" />
                    <div className="tellMeMore">
                      <a href="#">Tell Me More</a>
                    </div>
                    <div className="coloredBg">
                      <img src={IMAGE.whiteBg} alt="" />
                    </div>
                    <div className="walletImage">
                      <img src={IMAGE.walletColored} alt="" />
                    </div>
                  </div>
                  <div className="querySidebar">
                    <div className="card">
                      <div className="card-body">
                        <div className="card-title setup-guide">
                          <div style={{ width: 60, height: 60 }}>
                            <CircularProgressbar
                              value={percentage}
                              text={`${percentage}%`}
                              strokeWidth={10}
                              styles={buildStyles({
                                textColor: "black",
                                pathColor: "#34A853",
                                trailColor: "white",
                              })}
                            />
                          </div>
                          <div className="setup-guide-text">
                            <h4>Complete Your Setup guide</h4>
                            <h6>Your profile completion is at {percentage}%</h6>
                            <p>
                              {checkedCount === 4
                                ? "All steps completed!"
                                : "You are so close! Complete Now"}
                            </p>
                          </div>
                        </div>
                        <div className="listPanel">
                          {SETUP_GUIDE_ITEMS.map((item) => {
                            const checked = setupGuide[item.key];
                            const iconClass = checked ? "check_tick" : "check_tick_disabled";
                            const iconColor = checked ? "#047FFF" : "#ccc";
                            const content = (
                              <>
                                <FontAwesomeIcon
                                  className={iconClass}
                                  icon={faCircleCheck}
                                  style={{ color: iconColor }}
                                />
                                <span className={checked ? "text-checked ms-2" : "ms-2"}>
                                  {item.label}
                                </span>
                              </>
                            );
                            return (
                              <div className="panel" key={item.key}>
                                {item.link ? (
                                  <Link
                                    href={item.link}
                                    className="d-flex align-items-center text-decoration-none"
                                  >
                                    {content}
                                  </Link>
                                ) : (
                                  content
                                )}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
};

export default Cards;
