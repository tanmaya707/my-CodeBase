'use client'
import React from 'react'
import { IMAGE } from '../../utils/Theme';


import './banner.css'

import Link from 'next/link';
import Accordion from 'react-bootstrap/Accordion';


const Banner = () => {
  return (
    <div className="banner banner-addon-class">
      <div className="container">
        <div className="row no-gutters ">
          <div className="col-lg-4 col-md-5 col-12 p-0">
            <div className='container px-0'>
              <div className='banner-left'>
                <h4 className='banner-heading'>We Provide <span className="colored-text">Payment & Invoicing</span> that are Fast in Services</h4>
                <p className='banner-text'>Professional invoicing, estimate management, <span> and seamless payment solutions—all in one place</span> </p>
                <Link className='getstarted' href={{}}><span>Get Started </span><img className='bluearrow' src={IMAGE.blue_arrow} alt='Image broken' /></Link>
                <div className='app-buttons'>
                  <Link href="#"> <img src={IMAGE.appstore} alt='Image broken' /></Link>
                  <Link href="#">  <img src={IMAGE.playstore} alt='Image broken' /></Link>
                </div>
              </div>
            </div>
          </div>
          <div className='col-lg-1 col-md-1 col-3 arrow'>
            <img src={IMAGE.arrow} alt='Image broken' />
          </div>
          <div className="col-lg-7 col-md-6 col-12">
            <div className="banner-right">

              <img className="background" src={IMAGE.bannerback} alt='Image broken' />

              <div className="container banner-img">
                <img className="back-img" src={IMAGE.bannerImg} alt='Image broken' />
                <div className="banner-right-gif">
                  <img className="banner-gif" src={IMAGE.banner_gif} alt='Image broken' />
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  )
}

export default Banner