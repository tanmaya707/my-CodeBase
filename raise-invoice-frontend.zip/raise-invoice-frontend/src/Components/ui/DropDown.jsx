import React from "react";
// import * as DropdownMenu from "@radix-ui/react-dropdown-menu";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faChevronDown } from "@fortawesome/free-solid-svg-icons";
import "./ui.css"

export default function CustomDropDown({search = false, dropDownText = "-- Select --",  dropdownRef, className, list, handleAction, open, setOpen, selectedItem, position="top" }) {
    return (
        <div className="dropdown-container" ref={dropdownRef}  onClick={() => setOpen((prev) => !prev)}>
            <div
                className={"dropdown-trigger " }
               
            >
                <span>{selectedItem || dropDownText}</span>
                <span><FontAwesomeIcon icon={faChevronDown} className={open ? "openDropDown" : ""} /></span>
            </div>
            {open &&
                <div className={`${className} dropdown-custom-content ${position === "top" ? "top-possition" : "bottom-possition"}`}>
                    <ul className="">
                        <div>{dropDownText}</div>
                        {
                            list?.map((item, idx) => (
                                item?.value !== selectedItem && <li onClick={(e) => handleAction(e, item)} key={item?.id || idx} className="">
                                    {/* <Icon name={item?.icon} className={`w-4 h-4 `} stroke={item?.name === "Active" ? "#27DF89" : ""} /> */}
                                    <span className={item?.class ? item?.class : ""}>
                                        {item?.title}
                                    </span>
                                </li>
                            ))
                        }
                    </ul>
                </div>}
        </div>
    );
}
