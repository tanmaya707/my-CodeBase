// 📁 File: components/templates/ModernTemplate.js

function ModernTemplate({
  selectedTemp,
  selectedId,
  selectedSize,
  alignPos,
  selectedColour,
  selectedHeader,
  selectedWatermark,
}) {
  return (
    <div style={{ fontFamily: "Arial", padding: 40, color: "blue" }}>
      <div style={{ borderBottom: "4px solid red", marginBottom: 20 }} />
      <h1>{selectedTemp} Company</h1> <p>India</p>
      <h2>Invoice</h2>{" "}
      <p>
        <strong>Invoice #: </strong>INV001
      </p>{" "}
      <p>
        <strong>Date: </strong>
        {new Date().toLocaleDateString()}
      </p>
      <table
        style={{ width: "100%", marginTop: 20, borderCollapse: "collapse" }}
      >
        <thead>
          <tr style={{ background: selectedColour?.colourCode ?? "#f0f0f0" }}>
            <th>Item</th>
            <th>Qty</th>
            <th>Price</th>
            <th>Total</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Web Development</td>
            <td>1</td>
            <td>$1000</td>
            <td>$1000</td>
          </tr>
          <tr>
            <td>SEO</td>
            <td>1</td>
            <td>$500</td>
            <td>$500</td>
          </tr>
        </tbody>
      </table>
      <div style={{ textAlign: "right", marginTop: 30 }}>
        <p>
          <strong>Total:</strong> $1500
        </p>
      </div>
      <div
        style={{
          textAlign: "center",
          marginTop: 30,
          fontStyle: "italic",
          color: "#aaa",
        }}
      >
        <img
          src={`data:image/png;base64,${selectedWatermark?.imageBase64}`}
          alt="Watermark"
          style={{
            width: "30%",
            height: "200px",
          }}
        />
      </div>
      <footer style={{ marginTop: 50, fontSize: 14, color: "#888" }}>
        FOOTER
      </footer>
    </div>
  );
}

export default ModernTemplate;
