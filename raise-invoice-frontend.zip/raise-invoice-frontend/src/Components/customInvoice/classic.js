// 📁 File: components/templates/ClassicTemplate.js
function ClassicTemplate({
  selectedTemp,
  selectedId,
  selectedSize,
  alignPos,
  selectedColour,
  selectedHeader,
  selectedWatermark,
}) {
  return (
    <div style={{ fontFamily: "Times New Roman", padding: 40 }}>
      {" "}
      <div style={{ background: selectedColour?.colourCode ?? "#343a40", color: "#fff", padding: 20 }}>   
        {" "}
        <h1>{selectedTemp} Company</h1> <p>India</p>{" "}
      </div>
      <div style={{ marginTop: 30 }}>
        <p>
          <strong>Client:</strong> Test Customer
        </p>
        <p>
          <strong>Email:</strong> customer@gmail.com
        </p>
      </div>
      <table
        style={{ width: "100%", marginTop: 20, borderCollapse: "collapse" }}
      >
        <thead>
          <tr style={{ background: "#e9ecef" }}>
            <th>Item</th>
            <th>Qty</th>
            <th>Rate</th>
            <th>Amount</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Consulting</td>
            <td>2</td>
            <td>$300</td>
            <td>$600</td>
          </tr>
        </tbody>
      </table>
      <div style={{ textAlign: "right", marginTop: 20 }}>
        <p>
          <strong>Total:</strong> $600
        </p>
      </div>
      <div style={{ textAlign: "center", marginTop: 30, fontStyle: "italic", color: "#aaa" }}>
        <img src={`data:image/png;base64,${selectedWatermark?.imageBase64}`} alt="Watermark" style={{
          width: "30%",
          height:"200px"
        }}/>
      </div>
      <p style={{ marginTop: 40 }}>FOOTER</p>
    </div>
  );
}

export default ClassicTemplate;
