"use client"
import React, { useState, useRef, useEffect } from 'react'
import { IMAGE } from '@/utils/Theme';
import Link from 'next/link';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faAngleDown, faBell, faRightFromBracket, faUser } from "@fortawesome/free-solid-svg-icons";
import './dashboardHeader.css';
import { signout } from "@/redux/slices/authSlice";
import { useDispatch, useSelector } from 'react-redux';
import { ToastContainer, toast } from "react-toastify"
import { useRouter } from 'next/navigation';
import { fetchProfilePicData } from '@/redux/slices/dataSlice';

const DashboardHeader = () => {

  const dispatch = useDispatch();
  const router = useRouter();
  const { user } = useSelector((state) => state.auth);
  // const userDetails = (typeof localStorage !== 'undefined') ? JSON.parse(localStorage.getItem("user-details")) : {};
  // console.log('userDetails', userDetails);
  // Logout function
  const logoutClient = async (event, deviceType) => {
    event.preventDefault();
    try {
      const isLogout = await dispatch(signout({ deviceType: deviceType })).unwrap();
      if (isLogout) {
        toast.success("Logout successfully");
        router.push(`/`);
      } else {
        toast.error("Logout failed. Please try again.");
      }
    } catch (error) {
      toast.error("Logout failed. Please try again.");
      console.error("Logout error:", error);
    }
  }

  // ======================dropdown starts====================x`x`

  const [dropdowns, setDropdowns] = useState({
    settings: false,
    anotherDropdown: false, // Add more dropdowns as needed
  });

  const dropdownRefs = {
    settings: useRef(null),
    anotherDropdown: useRef(null), // Add more refs as needed
  };

  const toggleDropdown = (dropdown) => {
    setDropdowns((prev) => ({
      ...prev,
      [dropdown]: !prev[dropdown],
    }));
  };

  const handleClickOutside = (event) => {
    Object.keys(dropdowns).forEach((dropdown) => {
      if (dropdownRefs[dropdown].current && !dropdownRefs[dropdown].current.contains(event.target)) {
        setDropdowns((prev) => ({
          ...prev,
          [dropdown]: false,
        }));
      }
    });
  };

  useEffect(() => {
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const { profilePic } = useSelector(state => state?.dataReducer)

  // ======================dropdown ends====================
  useEffect(() => {
    // console.log("user : ", user);

    dispatch(fetchProfilePicData({ id: user?.data?.id, profileImage: null }))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dispatch, user?.data]);


  // useEffect(() => {
  //   console.log("profilePic ::: ", profilePic);

  // }, [profilePic]) 

  return (
    <div className='header login-header'>
      <div className='container-fluid head-section'>
        <div className='logo'>
          <img src={IMAGE.logo} alt="Logo" style={{ cursor: 'pointer' }} onClick={() => window.location.href = `/dashboard`} />
        </div>

        {user?.data?.name && (
          <div className='right-section'>
            <Link className='upgrade' href="/pricing">Upgrade Now</Link>
            <div className='profileDrpdwn' ref={dropdownRefs.anotherDropdown}>
              <div className='profilePic' onClick={() => toggleDropdown('anotherDropdown')}>
                <img src={profilePic?.profileImage || IMAGE.noUser} className='header-profile-image' /> <span className='elipseText'>Hi {user?.data?.name ?? "Digitrix Admin"} </span>
                <span><FontAwesomeIcon icon={faAngleDown} className='angle' /></span>
              </div>
              {dropdowns.anotherDropdown && (
                <div className="profilefdrpcntnt dropdown-content">
                  <Link href="/profile" onClick={() => setDropdowns(prev => ({ ...prev, anotherDropdown: false }))}>
                    <FontAwesomeIcon icon={faUser} />Profile
                  </Link>
                  <Link
                    href="javascript:void(0)"
                    onClick={(event) => {
                      setDropdowns(prev => ({ ...prev, anotherDropdown: false }));
                      logoutClient(event, 2);
                    }}
                  >
                    <FontAwesomeIcon icon={faRightFromBracket} /> Logout
                  </Link>
                </div>
              )}
            </div>
            <div className='notification-drpdown'>
              <Link href=""><img src={IMAGE.bell} />
                <span className='notification-count'>2</span>
              </Link>
            </div>

            <div className='setting-drpdown' ref={dropdownRefs.settings}>
              <img
                className='settings'
                src={IMAGE.setting}
                alt="Settings"
                onClick={() => toggleDropdown('settings')}
                aria-haspopup="true"
                aria-expanded={dropdowns.settings}
              />
              {dropdowns.settings && (
                <div className="dropdown-content">
                  <Link href="/language" onClick={() => setDropdowns(prev => ({ ...prev, settings: false }))}>Language</Link>
                  <Link href="/security" onClick={() => setDropdowns(prev => ({ ...prev, settings: false }))}>Security</Link>
                  <Link href="/tax-settings" onClick={() => setDropdowns(prev => ({ ...prev, settings: false }))}>Tax & Currency</Link>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div >
  )
}

export default DashboardHeader