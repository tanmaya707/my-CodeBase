/* eslint-disable @next/next/no-img-element */
"use client"
import React, { useState, useEffect, useRef } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { IMAGE } from '@/utils/Theme';
import './middlesection.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
    faCircleArrowRight,
    faSquarePlus,
    faCircleInfo,
    faEdit
} from '@fortawesome/free-solid-svg-icons';
import Modal from 'react-bootstrap/Modal';
import Link from 'next/link';
import { fetchClientAdminData, fetchProfilePicData, switchAccount, uploadProfilePicData } from "@/redux/slices/dataSlice";
import CustomDropDown from '../ui/DropDown';
import { carList } from '../dropDownConstant';
import { useClickOutside } from '@/hooks/use-click-outside';

const ProfileMiddleSection = () => {
    const dropdownRef = useRef(null);
    const [open, setOpen] = useState(false)
    const { profilePic } = useSelector(state => state?.dataReducer)
    const imgRef = useRef(null)
    const [selectedAccount, setSelectedAccount] = useState(null);
    const [addAccModal, setAddAccModal] = useState(false);
    const [exportDataModal, setExportDataModal] = useState(false);
    const [addPersonalInfoModal, setPersonalInfoModal] = useState(false);
    const [selectedCar, setSelectedCar] = useState("")
    const [preSnap, setPreSnap] = useState("");
    // const [traineeData, setTraineeData] = useState(null);
    useClickOutside(dropdownRef, () => setOpen(false), false);
 
    const { user } = useSelector((state) => state.auth);
    // console.log('SSSSSSS', user);
    const dispatch = useDispatch();
    const [clients, setClients] = useState([]);

    const handleClose = () => {
        setAddAccModal(false);
        setExportDataModal(false);
        setPersonalInfoModal(false);
    };

    const fetchClients = async () => {
        try {
            // Fetch client details
            const clientAdminData = await dispatch(fetchClientAdminData()).unwrap();
            // Set form data with the fetched client details
            if (clientAdminData.status) {
                // console.log('clientAdminData', clientAdminData.data)
                setClients(clientAdminData.data);
            }
        } catch (error) {
            console.error('Error fetching client details:', error);
        }
    };

    const handleSwitchAccount = async () => {
        if (!selectedAccount) return;
        try {
            const deviceType = 2;
            const selectedClient = clients.find(c => c.uuid === selectedAccount);
            const res = await dispatch(switchAccount({ email: selectedClient.email, deviceType })).unwrap();
            const data = res.data;
            if (res.status && data.deviceToken) {

                // Remove old tokens
                if (typeof localStorage !== 'undefined') {
                    localStorage.removeItem('web-auth-token');
                    localStorage.removeItem('user-details');
                    localStorage.removeItem("CountryId");
                    localStorage.removeItem("Currency");
                    localStorage.setItem('web-auth-token', data.deviceToken);
                    if (data.user) {
                        localStorage.setItem('user-details', JSON.stringify(data.user));
                        (typeof localStorage !== 'undefined') ? localStorage.setItem("CountryId", data.user.companyTaxDetails.countryId) : '';
                        (typeof localStorage !== 'undefined') ? localStorage.setItem("Currency", data.user.companyTaxDetails.currency) : '';
                    }
                }
                setAddAccModal(false);
                if (data && data.user.database_name) {
                    window.location.href = `/dashboard`;
                    toast.success("Login successful.");

                } else {
                    window.location.href = `/company-details`;
                    toast.info("Please complete your company details.");
                }
            } else {
                alert('Switch account failed');
            }
        } catch (error) {
            console.error('Error switching accounts:', error);
        }
    };

    useEffect(() => {
        fetchClients();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [dispatch]);

    useEffect(() => {
        // console.log("user : ", user);

        dispatch(fetchProfilePicData({ id: user?.data?.id, profileImage: null }))
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [dispatch, user?.data]);

    const handleImageChange = (e) => {
        if (imgRef?.current) {
            imgRef?.current?.click();
        }
    }

    // useEffect(() => {
    //     console.log("profilePic ::: ", profilePic);

    // }, [profilePic])

    const uploadImage = (e) => {
        const file = e.target.files?.[0];
        if (!file) return;
        const localUrl = URL.createObjectURL(file);
        setPreSnap(localUrl);
        const formData = new FormData();
        formData.append('id', user?.data?.id)
        formData.append('profileImage', file)
        // console.log("formData : ", formData, {id: user?.data?.id, profileImage : file?.name});

        dispatch(uploadProfilePicData(formData))
        return;
    }

    const handleAction = (e, item) => {
        setSelectedCar(item?.value)
    }

    return (
        <>
            <div className="col-lg-4">
                <div className="profile-middle-area">
                    <div className="user-card">
                        <div className='img-container'>
                            <img src={preSnap || profilePic?.profileImage || IMAGE.noUser} alt="Profile Image" className="profile-image" />
                            <input ref={imgRef} type='file' accept='image/*' onChange={uploadImage} style={{ display: 'none' }} />
                            <span className='img-upload' onClick={handleImageChange}>
                                <FontAwesomeIcon icon={faEdit} />
                            </span>
                        </div>
                        <h4>{user?.data?.name || 'Loading...'}</h4>
                        <p>{user?.data?.userCompany?.companyName}</p>
                        {/* <button className="upgrade-button">Upgrade Plan</button> */}
                        <Link className="upgrade-button" href="/pricing">Upgrade Plan</Link>
                    </div>
                    <div className="profile-middle-bottom">
                        <div className='sub-head'>
                            <p className='subheading'>Account</p>
                        </div>
                        <div className='account'>
                            <p>Account ID</p>
                            <p>{user?.data?.account_id || 'Loading...'}</p>
                        </div>
                        <div className='subs'>
                            <div className="manageSub">
                                <p>Manage Subscription</p>
                                <span>{user?.data?.isSubscribed ? user?.data?.planDetails?.name : "None"}</span>
                            </div>
                            <Link href={'/pricing'}><FontAwesomeIcon className="" icon={faCircleArrowRight} /></Link>
                        </div>
                        <div className='profile-info' onClick={() => setAddAccModal(true)}>
                            <img src={IMAGE.direction} alt="Switch Account" className="profile-icon" />
                            <p>Switch or Add Account</p>
                        </div>
                        <div className='profile-info' onClick={() => setPersonalInfoModal(true)}>
                            <img src={IMAGE.exclamation} alt="Personal Info" className="profile-icon prsnlInfo" />
                            <p>Personal Info</p>
                        </div>
                        <div className='profile-info'>
                            <Link className="profile-info-link" href='/team-members'>
                                <img src={IMAGE.users} alt="Team Members" className="profile-icon imageFilter" />
                                <p>Team Members</p>
                            </Link>
                        </div>
                        <div className='profile-info' onClick={() => setExportDataModal(true)}>
                            <img src={IMAGE.fileexport} alt="Export Data" className="profile-icon" />
                            <p>Export Data</p>
                        </div>
                        <div className='profile-info'>
                            <Link className="profile-info-link" href='/role-management'>
                                <img src={IMAGE.userSettings} alt="User  Roles Management" className="profile-icon" />
                                <p>User Roles Management</p>
                            </Link>
                        </div>
                    </div>
                </div>
            </div>
            {/* Add Account Modal */}
            <Modal show={addAccModal} onHide={handleClose}>
                <Modal.Header closeButton>
                    <Modal.Title>
                        <div className='addmodalhead'>
                            <h6 className='add-acc-header'>Add or Switch Account</h6>
                            <Link href="/team-members/add">Add<FontAwesomeIcon icon={faSquarePlus} /></Link>
                        </div>
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    {
                        clients && clients.map(client => (
                            <div key={client.uuid} style={{ display: 'flex', alignItems: 'center', marginBottom: '10px' }}>
                                <input
                                    type="radio"
                                    name="account"
                                    value={client.uuid}
                                    checked={
                                        selectedAccount
                                            ? selectedAccount === client.uuid
                                            : user?.data?.uuid === client.uuid
                                    }
                                    onChange={() => setSelectedAccount(client.uuid)}
                                    style={{ marginRight: '10px', marginTop: '-20px' }}
                                />
                                <div style={{ display: 'flex', flexDirection: 'column' }}>
                                    <label style={{ marginBottom: 0, fontWeight: 600, color: '#222' }}>{client.name}</label>
                                    <p style={{ marginBottom: 0, fontSize: '0.9em', color: '#888' }}>{client.email}</p>
                                </div>
                            </div>
                        ))
                    }
                    <button className='btn-switch' onClick={handleSwitchAccount}>Switch Account</button>
                </Modal.Body>
            </Modal>

            {/* Export Data Modal */}
            <Modal show={exportDataModal} onHide={handleClose}>
                <Modal.Header closeButton>
                    <Modal.Title>
                        <div className='addmodalhead'>
                            <h6 className='add-acc-header'>Export Data</h6>
                        </div>
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <div>
                        {/* <select className='input-form' name="cars" id="cars">
                            <option value="">Select what you want to export</option>
                            <option value="saab">Saab</option>
                            <option value="opel">Opel</option>
                            <option value="audi">Audi</option>
                        </select> */}
                        <CustomDropDown dropDownText="Select what you want to export" list={carList} className="" handleAction={handleAction} open={open} setOpen={setOpen} selectedItem={selectedCar} dropdownRef={dropdownRef} position={"bottom"} />

                    </div>
                    <div className='button-continer'>
                        <button className='save-btn'>Export</button>
                    </div>
                </Modal.Body>
            </Modal>

            {/* Personal Info Modal */}
            <Modal show={addPersonalInfoModal} onHide={handleClose}>
                <Modal.Header closeButton>
                    <Modal.Title>
                        <div className='addmodalhead'>
                            <h6 className='add-acc-header'>Personal Info</h6>
                        </div>
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <div className='info'>
                        <FontAwesomeIcon className="info-icon" icon={faCircleInfo} />
                        <p>Personal info is private and only used for security or to verify.</p>
                    </div>
                    <div className="input-container mt-3">
                        <span className="country-code">+{user?.data?.dialCode || ''}</span>
                        <hr className="divider" />
                        <input
                            type="text"
                            className="phone-number input-form-control"
                            placeholder=""
                            value={user?.data?.phone || ''}
                            onChange={(e) => {/* Handle change if needed */ }}
                        />
                    </div>
                    <p>Used for verification codes when you log in.</p>
                    <div className='button-continer'>
                        <button className='save-btn'>Update</button>
                    </div>
                </Modal.Body>
            </Modal>
        </>
    );
}

export default ProfileMiddleSection;