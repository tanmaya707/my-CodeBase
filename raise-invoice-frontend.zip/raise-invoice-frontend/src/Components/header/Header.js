"use client"
import React, { useState, useEffect } from 'react';
import { IMAGE } from '../../utils/Theme';
import Link from 'next/link';
import './header.css';
// import Accordion from 'react-bootstrap/Accordion';
import Api from "../../api/api";
import { usePathname, useRouter } from 'next/navigation';
import { faAngleDown, faRightFromBracket, faUser } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

const Header = () => {
    const pathname = usePathname();
    const authToken = (typeof localStorage !== 'undefined' && localStorage.getItem("web-auth-token") !== "undefined") ? localStorage.getItem("web-auth-token") : null;
    const userDetails = (typeof localStorage !== 'undefined' && localStorage.getItem("user-details") !== "undefined") ? JSON.parse(localStorage.getItem("user-details")) : {};
    const [openMenu, setOpenMenu] = useState(false);

    const [closeApp, setCloseApp] = useState(false);
    const [showDropdown, setShowDropdown] = useState(false);

    const toggleClassApp = () => {
        setCloseApp(prevState => !prevState);
    };
    const [error, setError] = useState(null);
    const [isLoading, setIsLoading] = useState(true);
    const [menuList, setMenuList] = useState([]);
    const router = useRouter();
    useEffect(() => {
        getHeaderMenus();
    }, []);
    const getHeaderMenus = async () => {
        setIsLoading(true);
        setError(null);
        try {
            const headerMenuResponse = await Api.POST('get-menu-list', { menu_type: 1 });
            setMenuList(headerMenuResponse.data.data);
        } catch (err) {
            setError("Failed to fetch menu list.");
        } finally {
            setIsLoading(false);
        }
    };
    const toggleDropdown = () => {
        setShowDropdown(!showDropdown);
    };
    // Logout function
    const logoutClient = async (event, deviceType) => {
        event.preventDefault();
        try {
            const axiosConfig = {
                headers: {
                    "Content-Type": "application/json",
                    "Access-Control-Allow-Origin": "*",
                    'Authorization': `Bearer ${authToken}`,
                },
            };
            const isLogout = await Api.POST('client-logout', { deviceType: deviceType }, axiosConfig);
            if (isLogout) {
                if ((typeof localStorage !== 'undefined')) {
                    localStorage.removeItem("web-auth-token");
                    localStorage.removeItem("user-details");
                    localStorage.removeItem("CountryId");
                    localStorage.removeItem("Currency");
                }
                router.push(`/`);
            }
        } catch (error) {
            console.error("Logout error:", error);
        }
    }

    return (
        <>
            {!isLoading ?
                <div className='header'>
                    <div className='container'>
                        <div className='navigation-bar'>
                            <div className='right-side'>
                                <div className='logo'>
                                    <Link href="/">
                                        <img src={IMAGE.logo} alt="Logo" />
                                    </Link>
                                </div>

                                {/* ===================new-nav-bar-code================ */}
                                <div className='tabs'>
                                    <div className="navbar ">
                                        <div className="navbar-header">

                                        </div>
                                        <div className="nav-list-all">
                                            <ul className="nav-list">
                                                {(menuList && menuList.length) ?
                                                    menuList.map((menu, i) => (
                                                        <li key={i} className={`nav-item ${(pathname == ((menu.link_type == 1) ? `/${menu.slug}` : menu.menu_link) ? 'active' : '')}`}>
                                                            <Link className="nav-link" href={(menu.link_type == 1) ? `/${menu.slug}` : menu.menu_link} key={`${menu.id}-link`} target={(menu.link_type == 1) ? `_self` : `_blank`} >{menu.menu_title}</Link>
                                                        </li>
                                                    ))
                                                    : ''
                                                }
                                                {/* Remove after dynamic Start */}
                                                {/* <li className="nav-item active">
                                                    <Link className="nav-link" href="/aboutUs">About Us</Link>
                                                </li>
                                                <li className="nav-item dropdown">
                                                    <Link className="nav-link" href="/features">Features</Link>
                                                </li>
                                                <li className="nav-item">
                                                    <Link className="nav-link" href="/subscription">Pricing</Link>
                                                </li>
                                                <li className="nav-item">
                                                    <Link className="nav-link" href="/faqs">FAQ</Link>
                                                </li>
                                                <li className="nav-item">
                                                    <Link className="nav-link" href="/careers">Career</Link>
                                                </li>
                                                <li className="nav-item">
                                                    <Link className="nav-link" href="/contactus">Contact Us</Link>
                                                </li> */}
                                                {/* Remove after dynamic End */}
                                            </ul>
                                        </div>
                                        <div className={`mobile-overlay ${openMenu ? 'active-overlay' : ''}`}></div>
                                        <div className={`mobile-menu ${openMenu ? 'open-menu' : ''}`}>
                                            <div className="mobile-logo">

                                                <div className='logo'>
                                                    <Link href="/">
                                                        <img src={IMAGE.logo} alt="Logo" />
                                                    </Link>
                                                </div>
                                                <span onClick={() => setOpenMenu(false)}>&#10006;</span>
                                            </div>

                                            <div className="mobile-scroll">
                                                <div className="mobile-menu-list">

                                                    {/* ===================new-navigation 20/2=========== */}
                                                    <nav>
                                                        <ul className={`nav-list ${closeApp ? 'nav-height-max' : ''}`}>
                                                            {(menuList && menuList.length) ?
                                                                menuList.map((menu, i) => (
                                                                    <li key={i} className={`nav-item ${(pathname == ((menu.link_type == 1) ? `/${menu.slug}` : menu.menu_link) ? 'active' : '')}`}>
                                                                        <Link className="nav-link" href={(menu.link_type == 1) ? `/${menu.slug}` : menu.menu_link} key={`${menu.id}-link`} target={(menu.link_type == 1) ? `_self` : `_blank`} >{menu.menu_title}</Link>
                                                                    </li>
                                                                ))
                                                                : ''
                                                            }
                                                            {/* <li className="nav-item">
                                                                <Link className="nav-link" href="/aboutUs">About Us</Link>
                                                            </li>
                                                            <li className="nav-item" >
                                                                <Accordion onClick={toggleClassApp}>
                                                                    <Accordion.Item eventKey="0">
                                                                        <Accordion.Header>Features</Accordion.Header>
                                                                        <Accordion.Body>
                                                                            <div className='inner-nav-link'>

                                                                                <div className='paid-faster'>
                                                                                    <h6>Get Paid Faster</h6>
                                                                                    <ul className="nav-list-inr">
                                                                                        <li className="nav-item">
                                                                                            <Link href="#">Invoice</Link>
                                                                                        </li>
                                                                                        <li className="nav-item">
                                                                                            <Link href="#">Payments</Link>
                                                                                        </li>
                                                                                        <li className="nav-item">
                                                                                            <Link href="#">Invoice App</Link>
                                                                                        </li>
                                                                                    </ul>
                                                                                </div>
                                                                                <div className='paid-faster'>
                                                                                    <h6>Get Organized</h6>
                                                                                    <ul className="nav-list-inr">
                                                                                        <li className="nav-item">
                                                                                            <Link href="#">Projects</Link>
                                                                                        </li>
                                                                                        <li className="nav-item">
                                                                                            <Link href="#">Report</Link>
                                                                                        </li>
                                                                                        <li className="nav-item">
                                                                                            <Link href="#">Integration</Link>
                                                                                        </li>
                                                                                    </ul>
                                                                                </div>
                                                                                <div className='paid-faster'>
                                                                                    <h6>Win More Work</h6>
                                                                                    <ul className="nav-list-inr">
                                                                                        <li className="nav-item">
                                                                                            <Link href="#">Estimates</Link>
                                                                                        </li>
                                                                                        <li className="nav-item">
                                                                                            <Link href="#">Customer Review</Link>
                                                                                        </li>

                                                                                    </ul>
                                                                                </div>

                                                                            </div>


                                                                        </Accordion.Body>
                                                                    </Accordion.Item>
                                                                </Accordion>
                                                            </li>
                                                            <li className="nav-item">
                                                                <Link className="nav-link" href="/subscription">Pricing</Link>
                                                            </li>
                                                            <li className="nav-item">
                                                                <Link className="nav-link" href="/faqs">FAQ</Link>
                                                            </li>
                                                            <li className="nav-item">
                                                                <Link className="nav-link" href="/careers">Career</Link>
                                                            </li>
                                                            <li className="nav-item">
                                                                <Link className="nav-link" href="/contactus">Contact Us</Link>
                                                            </li> */}
                                                        </ul>
                                                    </nav>

                                                    <div className={`free-trial-version ${closeApp ? 'close-free-trail' : ''}`}>
                                                        <h5>Checkout Our
                                                            Free Trial Version
                                                        </h5>
                                                        <p><span>For 30 Days</span><span> Web & Mobile App</span></p>

                                                        <div className='play-store-version app-buttons'>
                                                            <Link href="#"> <img src={IMAGE.appstore} alt='Image broken' /></Link>
                                                            <Link href="#">  <img src={IMAGE.playstore} alt='Image broken' /></Link>
                                                        </div>
                                                    </div>
                                                </div>


                                            </div>

                                            { !authToken ?
                                                            
                                                <div className='link-buttons mblsidebar-link'>
                                                    <Link className='Signup' href="/signup">Signup</Link>
                                                    <Link className='Login' href="/login">Login</Link>
                                                </div>
                                            :
                                                <div className='profileDrpdwn mblsidebar-link'>  
                                                    <div className="profilefdrpcntnt dropdown-content">
                                                        <a href="/profile"><FontAwesomeIcon icon={faUser} />Profile</a>
                                                        <a href="javascript:void(0)" onClick={(event) => logoutClient(event, 2)}><FontAwesomeIcon icon={faRightFromBracket} /> Logout</a>
                                                    </div>                                        
                                                </div>
                                            } 

                                        </div>

                                    </div>
                                </div>




                            </div>

                            <div className='left-side'>
                                <button
                                    className="navbar-toggle"
                                    type="button" onClick={() => setOpenMenu(true)}>
                                    <span className="navbar-toggle-icon">&#9776;</span>
                                </button>

                                { !authToken ?
                                    <div className='link-buttons'>
                                        <Link className='Login' href="/login">Login</Link>
                                        <Link className='Signup' href="/signup">Signup</Link>
                                    </div>
                                    :
                                    <div className='profileDrpdwn'>
                                        <div className='profilePic' onClick={() => toggleDropdown()}>
                                            <img src={IMAGE.user} /> <span className='elipseText'>Hi {userDetails?.name ?? "Digitrix Admin"} </span>
                                            <span><FontAwesomeIcon icon={faAngleDown} className='angle' /></span>
                                        </div> 
                                        {showDropdown && (                                       
                                            <div className="profilefdrpcntnt dropdown-content">
                                                <a href="/profile"><FontAwesomeIcon icon={faUser} />Profile</a>
                                                <a href="javascript:void(0)" onClick={(event) => logoutClient(event, 2)}><FontAwesomeIcon icon={faRightFromBracket} /> Logout</a>
                                            </div> 
                                        )}                                       
                                    </div>
                                }
                            </div>
                        </div>
                    </div>
                </div>
            : ''}
        </>
    );
}

export default Header;
