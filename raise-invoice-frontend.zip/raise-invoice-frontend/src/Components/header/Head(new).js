"use client"
import React, { useState, useEffect } from 'react';
import { IMAGE } from '../../utils/Theme';
import Link from 'next/link';
import './header.css';
import Accordion from 'react-bootstrap/Accordion';
import Api from "../../api/api";


const Header = () => {

  const [openMenu, setOpenMenu] = useState(false);

  const [closeApp, setCloseApp] = useState(false);

  const toggleClassApp = () => {
    setCloseApp(prevState => !prevState);
  };
  const [error, setError] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [menuList, setMenuList] = useState([]);
  useEffect(() => {
    getHeaderMenus();
  }, []);
  const getHeaderMenus = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const headerMenuResponse = await Api.POST('get-menu-list', { menu_type: 1 });
      setMenuList(headerMenuResponse.data.data);
    } catch (err) {
      setError("Failed to fetch menu list.");
    } finally {
      setIsLoading(false);
    }
  };
  return (
    <div className='header'>
      <div className='container'>
        <div className='navigation-bar'>
          <div className='right-side'>
            <div className='logo'>
              <Link href="/">
                <img src={IMAGE.logo} alt="Logo" />
              </Link>
            </div>

            {/* ===================new-nav-bar-code================ */}
            <div className='tabs'>
              <div className="navbar ">
                <div className="navbar-header">

                </div>
                <div className="nav-list-all">
                  <ul className="nav-list">
                    {(menuList && menuList.length) ?
                      menuList.map((menu, i) => (
                        <li key={i} className="nav-item dropdown active">
                          <Link className="nav-link" href={(menu.link_type == 1) ? `/${menu.page?.slug}` : menu.menu_link} target={(menu.link_type == 1) ? `_self` : `_blank`}>{menu.menu_title}</Link>
                        </li>
                      ))
                      : ''
                    }
                    {/* <li className="nav-item active">
                      <Link className="nav-link" href="/about-us">About Us</Link>
                    </li>
                    <li className="nav-item dropdown">
                      <Link className="nav-link" href="/features">Features</Link>
                    </li>
                    <li className="nav-item">
                      <Link className="nav-link" href="/pricing">Pricing</Link>
                    </li>
                    <li className="nav-item">
                      <Link className="nav-link" href="/faqs">FAQ</Link>
                    </li>
                    <li className="nav-item">
                      <Link className="nav-link" href="/careers">Career</Link>
                    </li>
                    <li className="nav-item">
                      <Link className="nav-link" href="/contact-us">Contact Us</Link>
                    </li> */}


                  </ul>
                </div>
                <div className={`mobile-overlay ${openMenu ? 'active-overlay' : ''}`}></div>
                <div className={`mobile-menu ${openMenu ? 'open-menu' : ''}`}>
                  <div className="mobile-logo">

                    <div className='logo'>
                      <Link href="/">
                        <img src={IMAGE.logo} alt="Logo" />
                      </Link>
                    </div>
                    <span onClick={() => setOpenMenu(false)}>&#10006;</span>
                  </div>



                  <div className="mobile-scroll">
                    <div className="mobile-menu-list">



                      {/* ===================new-navigation 20/2=========== */}
                      <nav>
                        <ul className={`nav-list ${closeApp ? 'nav-height-max' : ''}`}>

                          <li className="nav-item">
                            <Link className="nav-link" href="/about-us">About Us</Link>
                          </li>
                          <li className="nav-item" >
                            {/* <Link className="nav-link" href="/features">Features</Link> */}
                            <Accordion onClick={toggleClassApp}>
                              <Accordion.Item eventKey="0">
                                <Accordion.Header>Features</Accordion.Header>
                                <Accordion.Body>
                                  <div className='inner-nav-link'>

                                    <div className='paid-faster'>
                                      <h6>Get Paid Faster</h6>
                                      <ul className="nav-list-inr">
                                        <li className="nav-item">
                                          <a href="#">Invoice</a>
                                        </li>
                                        <li className="nav-item">
                                          <a href="#">Payments</a>
                                        </li>
                                        <li className="nav-item">
                                          <a href="#">Invoice App</a>
                                        </li>
                                      </ul>
                                    </div>
                                    <div className='paid-faster'>
                                      <h6>Get Organized</h6>
                                      <ul className="nav-list-inr">
                                        <li className="nav-item">
                                          <a href="#">Projects</a>
                                        </li>
                                        <li className="nav-item">
                                          <a href="#">Report</a>
                                        </li>
                                        <li className="nav-item">
                                          <a href="#">Integration</a>
                                        </li>
                                      </ul>
                                    </div>
                                    <div className='paid-faster'>
                                      <h6>Win More Work</h6>
                                      <ul className="nav-list-inr">
                                        <li className="nav-item">
                                          <a href="#">Estimates</a>
                                        </li>
                                        <li className="nav-item">
                                          <a href="#">Customer Review</a>
                                        </li>

                                      </ul>
                                    </div>

                                  </div>


                                </Accordion.Body>
                              </Accordion.Item>
                            </Accordion>
                          </li>
                          <li className="nav-item">
                            <Link className="nav-link" href="/pricing">Pricing</Link>
                          </li>
                          <li className="nav-item">
                            <Link className="nav-link" href="/faqs">FAQ</Link>
                          </li>
                          <li className="nav-item">
                            <Link className="nav-link" href="/careers">Career</Link>
                          </li>
                          <li className="nav-item">
                            <Link className="nav-link" href="/contact-us">Contact Us</Link>
                          </li>
                        </ul>
                      </nav>

                      <div className={`free-trial-version ${closeApp ? 'close-free-trail' : ''}`}>
                        <h5>Checkout Our
                          Free Trial Version
                        </h5>
                        <p><span>For 30 Days</span><span> Web & Mobile App</span></p>

                        <div className='play-store-version app-buttons'>
                          <Link href="#"> <img src={IMAGE.appstore} alt='Image broken' /></Link>
                          <Link href="#">  <img src={IMAGE.playstore} alt='Image broken' /></Link>
                        </div>
                      </div>
                    </div>


                  </div>


                  <div className='link-buttons mblsidebar-link'>
                    <Link className='Signup' href="/signup">Signup</Link>
                    <Link className='Login' href="/login">Login</Link>
                  </div>



                </div>

              </div>
            </div>

          </div>

          <div className='left-side'>
            <button
              className="navbar-toggle"
              type="button" onClick={() => setOpenMenu(true)}>
              <span className="navbar-toggle-icon">&#9776;</span>
            </button>

            <div className='link-buttons'>
              <Link className='Login' href="/login">Login</Link>
              <Link className='Signup' href="/signup">Signup</Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Header;
