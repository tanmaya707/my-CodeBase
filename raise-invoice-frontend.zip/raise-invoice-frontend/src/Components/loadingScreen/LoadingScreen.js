import Image from "next/image";
import './loadingScreen.css';
export default function LoadingScreen() { 
  return (
    <>
      <div className="preloader" id="preloader">
        <div className="preloader">
          <div className="waviy position-relative">
            <span className="d-inline-block">
              <Image
                src="/images/raise_invoice.png"
                className="wh-70"
                alt=""
                width={70}
                height={70}
              />
            </span>
            <span className="d-inline-block">R</span>
            <span className="d-inline-block">a</span>
            <span className="d-inline-block">i</span>
            <span className="d-inline-block">s</span>
            <span className="d-inline-block">e</span>
            <span className="d-inline-block">&nbsp;</span>
            <span className="d-inline-block">I</span>
            <span className="d-inline-block">n</span>
            <span className="d-inline-block">v</span>
            <span className="d-inline-block">o</span>
            <span className="d-inline-block">i</span>
            <span className="d-inline-block">c</span>
            <span className="d-inline-block">e</span>
          </div>
        </div>
      </div>
    </>
  )
}