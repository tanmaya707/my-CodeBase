import { useModal } from "@/cotexts/modalContext";
import { useImperativeHandle } from "react";

const AddInvoiceTime = ({ parameter }, ref ) => {
    const {closeModal} = useModal()
    useImperativeHandle(ref, () => ({
            handleSave,
        }));
    
        const handleSave = async () => {
            closeModal()
        };
    return (
        <div></div>
    )
}

export default AddInvoiceTime