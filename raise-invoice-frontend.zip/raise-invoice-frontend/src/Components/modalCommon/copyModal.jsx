import { useModal } from "@/cotexts/modalContext";
import { useRouter } from "next/navigation";
import { forwardRef, useImperativeHandle, useState } from "react";

const CopyAndCreate = forwardRef(({ parameter }, ref) => {
    const {closeModal, setParameters} = useModal()
    const route = useRouter();
    const [selectedOptions, setSelectedOptions] = useState({
        client: true,
        items: true,
        attachment: true,
    });

    useImperativeHandle(ref, () => ({
        handleSave,
    }));

    const handleSave = async (e) => {
        setParameters({...selectedOptions, route : parameter?.route});
        // console.log(parameter?.route, "parameter?.route ::: ");
        
        route.push(parameter?.route)
        closeModal()
    };

    const handleSelect = (e) => {
        console.log("e.target.checked ::: ", e.target.checked);
        const { name, checked } = e.target;
        setSelectedOptions((prev) => ({
            ...prev,
            [name]: checked,
        }));
    }

    return (
        <div>
            <form>
                <div className='checkbox-copy' style={{display: 'flex', flexDirection: 'column', gap: '15px'}}>
                    <div className='checkbox-custom'>
                        <input checked={selectedOptions?.client} onChange={handleSelect} name="client" type="checkbox" id="copy-client" />
                        <label htmlFor="copy-client" className="preview-mail" style={{fontSize : "16px"}}>Copy Client</label>
                    </div>
                    <div className='checkbox-custom'>
                        <input checked={selectedOptions?.items} onChange={handleSelect} name="items" type="checkbox" id="copy-items" />
                        <label htmlFor="copy-items" className="preview-mail" style={{fontSize : "16px"}}>Copy Items</label>
                    </div>
                    <div className='checkbox-custom'>
                        <input checked={selectedOptions?.attachment} onChange={handleSelect} name="attachment" type="checkbox" id="copy-attachment" />
                        <label htmlFor="copy-attachment" className="preview-mail" style={{fontSize : "16px"}}>Copy Attachment</label>
                    </div>
                </div>
            </form>
        </div>
    )
})

export default CopyAndCreate;