import { useModal } from "@/cotexts/modalContext";
import { addContactApi, getContactsApi, updateContactApi } from "@/redux/slices/projectSlice";
import { forwardRef, useEffect, useImperativeHandle, useState } from "react";
import GooglePlacesAutocomplete from "react-google-places-autocomplete";
import { useDispatch } from "react-redux";
import { toast } from "react-toastify";
import z from "zod";
import "./modalCommon.css"
const addContactSchema = z.object({
    contact_name: z.string().min(1, "Contact name is required"),
    contact_email: z.string().email("Invalid email address"),
    contact_phone: z.string().min(10, "Contact phone is required").max(15, "Contact phone must be between 10 and 15 digits"),
    address: z.string().min(1, "Adress is required")
});

const initialErrors = {
        contact_name: '',
        contact_email: '',
        contact_phone: '',
        address: '',
    }

const AddContact = forwardRef(( { parameter }, ref ) => {
    const dispatch = useDispatch();
    const { closeModal } = useModal();
    const [contactPayload, setContactPayload] = useState({
        contact_name: parameter?.name || parameter?.contact_name || '',
        contact_email: parameter?.contact_email || '',
        contact_phone: parameter?.contact_phone || '',
        address: parameter?.address || '',
    });
    const [errors, setErrors] = useState(initialErrors);
    const [location, setLocation] = useState(parameter?.address ? { label: parameter?.address, value: parameter.address, place_id: 'initial' || null} : '' );

    useEffect(() => {
        console.log(location);
        
    }, [location]);

    useImperativeHandle(ref, () => ({
        handleSave,
    }));

    const handleSave = async () => {
        // Logic to save the contact details
        setErrors(initialErrors);
        console.log("Contact saved with parameters:", contactPayload);
        const isValidated = validationCheck();
        if(!isValidated) return;
        try {
            if(parameter?.id) {                     
                await dispatch(updateContactApi ({
                    ...contactPayload,
                    id : parameter?.id,
                    client_id: parameter?.client_id,
                    projectId: parameter?.project_id,
                })).unwrap();
                dispatch(getContactsApi({client_id: parameter?.client_id}))
                toast.success( `This contact has been updated successfully` );
                
                closeModal();
                return;
            }
            dispatch(addContactApi({
                ...contactPayload, 
                client_id: parameter?.client_id, 
                projectId: parameter?.project_id
            }));
            toast.success( `A new contact created successfully`);
            // console.log("Contact saved successfully");
            // toast.success("Contact saved successfully");
            closeModal();
        } catch (error) {
            console.error("Error saving contact:", error);
            toast.error( `${contactPayload?.contact_name} failed to save or update. Please try again.`);

        }
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setContactPayload((prev) => ({ ...prev, [name]: value }));
    }

    const validationCheck = () => {
        const validation = addContactSchema.safeParse(contactPayload);
        
        if (!validation.success) {
            const fieldErrors = {};
            JSON.parse(validation?.error)?.forEach(err => {
                const field = err.path[0] ;
                fieldErrors[field] = err.message;
            });
            setErrors(prev => ({
                ...prev,
                ...fieldErrors
            }));
            return false;
        }
        return true
    }

  return (
    <div>
      <div className='details-accordian'>
            <div className='form-input-label contact-container'>
                <div className='input-group error-wrapper'>
                    <div className="floating-label-group">
                        <input disabled={parameter?.isPrimary} type="text" id="contact_name" onChange={handleChange} value={contactPayload?.contact_name} name="contact_name" className="input-form-control" required />
                        <label htmlFor="contact_name" className="floating-label">Contact Name</label>
                    </div>
                    {errors.contact_name && <span className="error-text">{errors.contact_name}</span>}
                </div>
                <div className='input-group error-wrapper'>
                    <div className="floating-label-group">
                        <input type="text" id="contact_email" onChange={handleChange} value={contactPayload?.contact_email} name="contact_email" className="input-form-control" required />
                        <label htmlFor="contact_email" className="floating-label">Contact Email</label>
                    </div>
                    {errors.contact_email && <span className="error-text">{errors.contact_email}</span>}
                </div>
                <div className='input-group error-wrapper'>
                    <div className="floating-label-group">
                        <input onChange={handleChange} value={contactPayload?.contact_phone} name="contact_phone" type="number" id="contact_phone" className="input-form-control" required />
                        <label htmlFor="contact_phone" className="floating-label">Contact Phone</label>
                    </div>
                    {errors.contact_phone && <span className="error-text">{errors.contact_phone}</span>}
                </div>
                <div className='input-group error-wrapper'>
                    <div className="floating-label-group">
                        <GooglePlacesAutocomplete
                            id="address"
                            apiKey={process.env.NEXT_PUBLIC_GOOGLE_MAP_KEY}
                            className="input-form-control"
                            selectProps={{
                                value: location,
                                onChange: (selected) => {
                                    setLocation(selected ?? '');
                                    setContactPayload(prev => ({...prev, address : selected?.label ?? ''}));
                                },
                                placeholder: 'Select Location',
                                // components: { DropdownIndicator },
                            }}
                        />
                        <label htmlFor="address" className="floating-label"></label>
                    </div>
                    {errors.address && <span className="error-text">{errors.address}</span>}
                </div>
            </div>
      </div>
    </div>
  )
})

export default AddContact;