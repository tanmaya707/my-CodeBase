import { useModal } from "@/cotexts/modalContext";
import { addTaskApi, getTasksApi, updateTasksApi } from "@/redux/slices/projectSlice";
import { IMAGE } from "@/utils/Theme";
import { faCalendarDays } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { forwardRef, useImperativeHandle, useState } from "react";
import Calendar from "react-calendar";
import { useDispatch } from "react-redux";
import { toast } from "react-toastify";
import z from "zod";

// Helper to format date as dd-mm-yyyy
const formatDate = (date) => {
    if (!date) return "";
    if (typeof date === "string") date = new Date(date);
    const d = date.getDate().toString().padStart(2, "0");
    const m = (date.getMonth() + 1).toString().padStart(2, "0");
    const y = date.getFullYear();
    return `${d}-${m}-${y}`;
};

// Helper to parse dd-mm-yyyy to Date
const parseDate = (str) => {
    if (!str) return "";
    if (str instanceof Date) return str;
    const [d, m, y] = str.split("-");
    if (!d || !m || !y) return "";
    return new Date(`${y}-${m}-${d}`);
};

const addTakSchema = z.object({
    taskName: z.string().min(1, "Task name is required"),
    taskDescription: z.string().min(1, "Task description is required"),
    taskStartDate: z.string().refine(
        (val) => /^\d{2}-\d{2}-\d{4}$/.test(val) && !isNaN(parseDate(val)),
        "Please enter a valid date"
    ),
    taskEndDate: z.string().refine(
        (val) => /^\d{2}-\d{2}-\d{4}$/.test(val) && !isNaN(parseDate(val)),
        "Please enter a valid date"
    ),
    taskPriority: z.enum(["low", "medium", "high"], { message: "Please enter your priority among low | medium | high" }).optional(),
});

const initialErrors = {
    taskName: "",
    taskDescription: "",
    taskPriority: "",
    taskStartDate: "",
    taskEndDate: "",
};

const AddTask = forwardRef(({ parameter }, ref) => {
    const dispatch = useDispatch();
    const { closeModal } = useModal();
    const [taskPayload, setTaskPayload] = useState({
        taskName: parameter?.taskName || "",
        taskDescription: parameter?.taskDescription || "",
        taskPriority: parameter?.taskPriority || "",
        taskStartDate: parameter?.taskStartDate
            ? formatDate(new Date(parameter?.taskStartDate))
            : "",
        taskEndDate: parameter?.taskEndDate
            ? formatDate(new Date(parameter?.taskEndDate))
            : "",
    });
    const [errors, setErrors] = useState(initialErrors);
    const [showCalendarStart, setShowCalendarStart] = useState(false);
    const [showCalendarEnd, setShowCalendarEnd] = useState(false);

    useImperativeHandle(ref, () => ({
        handleSave,
    }));

    const handleSave = async () => {
        setErrors(initialErrors);
        const isValidated = validationCheck();
        if (!isValidated) return;
        try {
            if (parameter?.id) {
                await dispatch(
                    updateTasksApi({
                        ...taskPayload,
                        id: parameter?.id,
                        client_id: parameter?.client_id,
                        projectId: parameter?.project_id,
                        taskStartDate: parseDate(taskPayload.taskStartDate),
                        taskEndDate: parseDate(taskPayload.taskEndDate),
                    })
                ).unwrap();
                dispatch(getTasksApi({ projectId: parameter?.project_id }));
                toast.success(`${taskPayload?.taskName} updated successfully`);
                closeModal();
                return;
            }
            dispatch(
                addTaskApi({
                    ...taskPayload,
                    client_id: parameter?.client_id,
                    projectId: parameter?.project_id,
                    taskStartDate: parseDate(taskPayload.taskStartDate),
                    taskEndDate: parseDate(taskPayload.taskEndDate),
                })
            );
            toast.success(`${taskPayload?.taskName} created successfully`);
            closeModal();
        } catch (error) {
            toast.error(
                `${taskPayload?.taskName} failed to save or update. Please try again.`
            );
            console.error("Error saving task:", error);
        }
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setErrors(initialErrors);
        setTaskPayload((prev) => ({ ...prev, [name]: value }));
    };

    const validationCheck = () => {
        const validation = addTakSchema.safeParse(taskPayload);

        if (!validation.success) {
            const fieldErrors = {};
            validation.error.errors.forEach((err) => {
                const field = err.path[0];
                fieldErrors[field] = err.message;
            });
            setErrors((prev) => ({
                ...prev,
                ...fieldErrors,
            }));
            return false;
        }
        if (taskPayload.taskStartDate && taskPayload.taskEndDate) {
            const start = parseDate(taskPayload.taskStartDate);
            const end = parseDate(taskPayload.taskEndDate);
            if (start > end) {
                setErrors((prev) => ({
                    ...prev,
                    taskEndDate: "End date cannot be before start date.",
                }));
                return false;
            } else {
                setErrors((prev) => ({
                    ...prev,
                    taskEndDate: "",
                }));
            }
        }
        return true;
    };

    return (
        <div>
            <div className="details-accordian">
                <div className="form-input-label contact-container">
                    <div className="input-group error-wrapper">
                        <div className="floating-label-group">
                            <input
                                type="text"
                                id="taskName"
                                onChange={handleChange}
                                value={taskPayload?.taskName}
                                name="taskName"
                                className="input-form-control"
                                required
                            />
                            <label htmlFor="taskName" className="floating-label">
                                Task Name
                            </label>
                        </div>
                        {errors.taskName && (
                            <span className="error-text">{errors.taskName}</span>
                        )}
                    </div>
                    <div className="input-group error-wrapper">
                        <div className="floating-label-group priority-select">
                            <label className="payment-label">Priority</label>
                            <select
                                type="text"
                                name="taskPriority"
                                className="input-form-control task-priority-select"
                                value={taskPayload.taskPriority}
                                onChange={handleChange}
                                required
                            >
                                <option value="">Select Priority</option>
                                <option value="low">Low</option>
                                <option value="medium">Medium</option>
                                <option value="high">High</option>
                            </select>
                            <div className="dropdown-arrow">
                                <img src={IMAGE.dropdownColor} alt="Dropdown Arrow" />
                            </div>
                        </div>
                        {errors.taskPriority && (
                            <span className="error-text">{errors.taskPriority}</span>
                        )}
                    </div>
                    <div className="input-group error-wrapper">
                        <div className="floating-label-group">
                            <textarea
                                id="taskDescription"
                                onChange={handleChange}
                                value={taskPayload?.taskDescription}
                                name="taskDescription"
                                className="input-form-control"
                                required
                            />
                            <label
                                htmlFor="taskDescription"
                                className="floating-label"
                            >
                                Task Description
                            </label>
                        </div>
                        {errors.taskDescription && (
                            <span className="error-text">{errors.taskDescription}</span>
                        )}
                    </div>
                    <div className="input-group error-wrapper">
                        <div className="floating-label-group ">
                            <input
                                type="text"
                                id="start-date"
                                className="input-form-control input-logo"
                                value={taskPayload.taskStartDate}
                                name="taskStartDate"
                                onChange={handleChange}
                                required
                                readOnly
                            />
                            <label htmlFor="start-date" className="floating-label">
                                Start Date
                            </label>
                            <FontAwesomeIcon
                                className="point-img"
                                icon={faCalendarDays}
                                onClick={() => setShowCalendarStart(!showCalendarStart)}
                            />
                            {showCalendarStart && (
                                <Calendar
                                    onChange={(date) => {
                                        setTaskPayload((prev) => ({
                                            ...prev,
                                            taskStartDate: formatDate(date),
                                        }));
                                        setShowCalendarStart(false);
                                    }}
                                    value={
                                        taskPayload?.taskStartDate
                                            ? parseDate(taskPayload?.taskStartDate)
                                            : null
                                    }
                                />
                            )}
                        </div>
                        {errors.taskStartDate && (
                            <span className="error-text">{errors.taskStartDate}</span>
                        )}
                    </div>
                    <div className="input-group error-wrapper">
                        <div className="floating-label-group ">
                            <input
                                type="text"
                                id="end-date"
                                name="taskEndDate"
                                value={taskPayload.taskEndDate}
                                className="input-form-control input-logo"
                                onChange={handleChange}
                                required
                                readOnly
                            />
                            <label htmlFor="end-date" className="floating-label">
                                End Date
                            </label>
                            <FontAwesomeIcon
                                className="point-img"
                                icon={faCalendarDays}
                                onClick={() => setShowCalendarEnd(!showCalendarEnd)}
                            />
                            {showCalendarEnd && (
                                <Calendar
                                    onChange={(date) => {
                                        setTaskPayload((prev) => ({
                                            ...prev,
                                            taskEndDate: formatDate(date),
                                        }));
                                        setShowCalendarEnd(false);
                                    }}
                                    value={
                                        taskPayload?.taskEndDate
                                            ? parseDate(taskPayload?.taskEndDate)
                                            : null
                                    }
                                />
                            )}
                        </div>
                        {errors.taskEndDate && (
                            <span className="error-text">{errors.taskEndDate}</span>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
});

export default AddTask;