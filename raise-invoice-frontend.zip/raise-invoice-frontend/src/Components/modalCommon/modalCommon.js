import { useModal } from '@/cotexts/modalContext';
import React, { useEffect, useRef } from 'react'
import { useState } from 'react';
import Button from 'react-bootstrap/Button';

import Modal from 'react-bootstrap/Modal';
import AddContact from './addContact';
import AddTask from './addtask';
import AddInvoiceTime from './addTimeInvoice';
import RecordPayment from './recordPayment';
import ESign from './eSign';
import CopyAndCreate from './copyModal';


const ModalCommon = () => {
    const {modalType, closeModal, parameter} = useModal();
    
    const show = modalType !== null;
    const saveref = useRef();

    const handleSave = async () => {        
        if (saveref.current?.handleSave) {
            await saveref.current.handleSave()
        }
    }
    
    // useEffect(() => {
    //     modalType && console.log("modalType ::: ", modalType);
    // }, [modalType]);

    return(
            <>
              <Modal show={show} centered onHide={closeModal}>
                <Modal.Header closeButton>
                <Modal.Title>{parameter?.header}</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    {modalType === 'addContact' && <AddContact ref={saveref} parameter={parameter} />}
                    {modalType === 'addTask' && <AddTask ref={saveref} parameter={parameter} />}
                    {modalType === 'addTimes' && <AddInvoiceTime ref={saveref} parameter={parameter} />}
                    {modalType === 'recordPayment' && <RecordPayment ref={saveref} parameter={parameter} />}
                    {modalType === 'eSign' && <ESign ref={saveref} parameter={parameter} />}
                    {modalType === 'copy' && <CopyAndCreate ref={saveref} parameter={parameter} />}
                </Modal.Body>
                <Modal.Footer className='flex justify-content-center'>
                    <Button variant="primary" onClick={handleSave}>
                        {modalType === "copy" ? "Copy" : "Save"}
                    </Button>
                </Modal.Footer>
            </Modal>
            </>
    )

}

export default ModalCommon;