import { IMAGE } from "@/utils/Theme";
import { faTimes } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { forwardRef, useEffect, useRef, useState } from "react";

const ESign = forwardRef(() => {
  const [sigType, setSigType] = useState("pad");
  const [sigText, setSigText] = useState("");

  const handleSignatureChange = () => { };

  //   useEffect(() => {
  //     setSigType(invoice.signatureType || "pad");
  //     setSigText(invoice.signatureText || "");
  //   }, [invoice.signatureType, invoice.signatureText]);

  //   const getError = (field) => errors && errors[field];


  return (
    <div>
      {/* <div className="sub-head">
            <p className="subheading">Signature</p>
          </div> */}
      <div className="col-lg-12">
        <SignatureField
          //   value={
          //     invoice.signatureType === "pad" || invoice.signatureType === "upload"
          //       ? invoice.signatureData
          //         ? `data:image/png;base64,${invoice.signatureData}`
          //         : ""
          //       : ""
          //     }
          onChange={handleSignatureChange}
          color={"#0d6efd"}
          //   error={
          //     sigType === "text"
          //       ? getError("signatureText")
          //       : getError("signatureData")
          //   }
          type={sigType}
          setType={(t) => {
            setSigType(t);
          }}
          textValue={sigText}
          setTextValue={setSigText}
        />
      </div>
    </div>
  )
})

export default ESign;

function SignatureField({ value, onChange, color, error, type, setType, textValue, setTextValue }) {
  const canvasRef = useRef(null);
  const [drawing, setDrawing] = useState(false);
  const [uploadFile, setUploadFile] = useState(null);

  useEffect(() => {
    if (type === "pad" && value && canvasRef.current) {
      const ctx = canvasRef.current.getContext("2d");
      const img = new window.Image();
      img.onload = () => {
        ctx.clearRect(0, 0, 600, 160);
        ctx.drawImage(img, 0, 0, 600, 160);
      };
      img.src = value.startsWith("data:image")
        ? value
        : `data:image/png;base64,${value}`;
    } else if (type === "pad" && canvasRef.current) {
      const ctx = canvasRef.current.getContext("2d");
      ctx.clearRect(0, 0, 600, 160);
    }
  }, [value, type]);

  const getPos = (e) => {
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    // let x, y;
    // console.log("e.touches ::: ", e.clientX, e.clientY);
    const x = (e.clientX - rect.left) * (canvas.width / rect.width);
    const y = (e.clientY - rect.top) * (canvas.height / rect.height);

    return { x, y };
    if (e.touches && e.touches.length) {
      console.log("e.touches ::: ", e.touches, e.touches[0], e);

      console.log("e.touches[0].clientX ::: ", e.touches[0].clientX, "rect.left :::", rect.left);
      console.log("e.touches[0].clientX ::: ", e.touches[0].clientY, "rect.top", rect.top);
      x = e.touches[0].clientX - rect.left;
      y = e.touches[0].clientY - rect.top;
    } else {
      console.log("e.nativeEvent ::: ", e.nativeEvent);

      // console.log("e.nativeEvent X ::: ", e.nativeEvent.clientX, "rect.left :::", rect.left);
      // console.log("e.nativeEvent Y ::: ", e.nativeEvent.clientY, "rect.top :::", rect.top);
      x = e.nativeEvent.clientX - rect.left;
      y = e.nativeEvent.clientY - rect.top;

      // x =
      //   e.nativeEvent.offsetX !== undefined
      //     ? e.nativeEvent.offsetX
      //     : e.nativeEvent.layerX;
      // y =
      //   e.nativeEvent.offsetY !== undefined
      //     ? e.nativeEvent.offsetY
      //     : e.nativeEvent.layerY;
    }
    return { x, y };
  };

  const handleStart = (e) => {
    e.preventDefault();
    setDrawing(true);
    const { x, y } = getPos(e);
    const ctx = canvasRef.current.getContext("2d");
    ctx.strokeStyle = color || "#222";
    ctx.lineWidth = 2.5;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(x, y);
  };

  const handleMove = (e) => {
    if (!drawing) return;
    e.preventDefault();
    const { x, y } = getPos(e);
    const ctx = canvasRef.current.getContext("2d");
    ctx.lineTo(x, y);
    ctx.stroke();
    // ctx.beginPath();
    // ctx.moveTo(x, y);
  };

  const handleEnd = () => {
    if (!drawing) return;
    setDrawing(false);
    const canvas = canvasRef.current;
    const data = canvas.toDataURL();
    onChange(data, "pad");
  };

  const clearPad = () => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    ctx.clearRect(0, 0, 600, 160);
    onChange("", "pad");
  };

  const handleUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      setUploadFile(file);
      const reader = new FileReader();
      reader.onload = () => {
        onChange(reader.result, "upload");
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDeleteUpload = () => {
    setUploadFile(null);
    onChange("", "upload");
  };

  const handleTextChange = (e) => {
    setTextValue(e.target.value);
    onChange(e.target.value, "text");
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
      <div style={{ marginBottom: 8 }} className="DrawUploadType">
        <label>
          <input
            type="radio"
            name="sigtype"
            checked={type === "pad"}
            onChange={() => setType("pad")}
          />{" "}
          Draw
        </label>
        <label style={{ marginLeft: 16 }}>
          <input
            type="radio"
            name="sigtype"
            checked={type === "upload"}
            onChange={() => setType("upload")}
          />{" "}
          Upload
        </label>

        {/* ==========uploadImage======= */}

        <label style={{ marginLeft: 16 }}>
          <input
            type="radio"
            name="sigtype"
            checked={type === "text"}
            onChange={() => setType("text")}
          />{" "}
          Type
        </label>
      </div>
      {type === "pad" && (
        <>
          <canvas
            ref={canvasRef}
            width={700}
            height={200}
            style={{
              border: "1.5px solid #cbd5e1",
              borderRadius: 8,
              background: "#fff",
              touchAction: "none",
              cursor: "url('https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.2/svgs/solid/pencil.svg') 0 16, pointer",
            }}
            onMouseDown={handleStart}
            onMouseUp={handleEnd}
            onMouseOut={handleEnd}
            onMouseMove={handleMove}
            onTouchStart={handleStart}
            onTouchEnd={handleEnd}
            onTouchCancel={handleEnd}
            onTouchMove={handleMove}
          />
          <button
            type="button"
            onClick={clearPad}
            style={{
              background: "#edf2f7",
              color: color,
              border: "1px solid #cbd5e1",
              borderRadius: 8,
              padding: "0.3rem 1rem",
              fontSize: "1rem",
              fontWeight: 500,
              cursor: "pointer",
              width: 120,
            }}
          >
            Clear
          </button>
        </>
      )}
      {type === "upload" && (
        <div className="ImageUpload">
          {value ? (
            <div style={{ position: "relative", display: "inline-block" }}>
              <img
                src={getImageSrc(value)}
                alt="Signature"
                style={{
                  maxWidth: 200,
                  maxHeight: 60,
                  border: "1px solid #cbd5e1",
                  borderRadius: 6,
                  marginTop: 8,
                }}
              />
              <button
                type="button"
                onClick={handleDeleteUpload}
                style={{
                  position: "absolute",
                  top: 0,
                  right: 0,
                  background: "#fff",
                  border: "1px solid #cbd5e1",
                  borderRadius: "50%",
                  cursor: "pointer",
                  padding: 2,
                  margin: 2,
                }}
                title="Remove"
              >
                <FontAwesomeIcon icon={faTimes} />
              </button>
            </div>
          ) : (
            <>
              <input
                type="file"
                accept="image/*"
                onChange={handleUpload}
                style={{ marginBottom: 8 }}
              />

              <div className="uploadImage">
                <img src={IMAGE.upload} alt="" />
              </div>
            </>
          )}
        </div>
      )}
      {type === "text" && (
        <input
          type="text"
          value={textValue}
          onChange={handleTextChange}
          placeholder="Type your signature"
          style={{
            border: "1.5px solid #cbd5e1",
            borderRadius: 8,
            padding: "0.5rem",
            fontSize: "1.2rem",
            width: 300,
          }}
        />
      )}
      {error && <div className="error-msg">{error}</div>}
    </div>
  );
}