import { useModal } from "@/cotexts/modalContext";
import { faAngleDown, faCalendarDays, faCheck } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import Link from "next/link";
import { forwardRef, useImperativeHandle } from "react";
import '../../Components/invoiceForm/invoiceForm.css';

const RecordPayment = forwardRef(({ parameter }, ref) => {
  const {closeModal, setParameters} = useModal()

  useImperativeHandle(ref, () => ({
    handleSave,
  }));

  const handleSave = async () => {
    closeModal()
  };

  return (
      <>
      <div className='payment-header'>
          <span><FontAwesomeIcon icon={faCheck} /></span>  Mark as Fully Paid
        </div>
        <form>
          <div className='form-input-label'>
            <div className="form-group mb-3">
              <div className="phone-input  mb-3">
                <div className="floating-label-group ">
                  <input type="text" className="phone-number" placeholder='100' required />
                  <label className="phone-floating-label label-custum">Amount</label>
                </div>
                <div className="divider"></div>
                <div className="country-code">$ <FontAwesomeIcon icon={faAngleDown} className='phone-angle' /></div>
              </div>
            </div>
            <div className="form-group mb-3">
              <div className="floating-label-group">
                <input type="text" className="input-form-control" required />
                <label className="floating-label"> Method</label>
              </div>
            </div>
            <div className="form-group mb-3">
              <div className="floating-label-group">
                <input type="text" className="input-form-control" required />
                <FontAwesomeIcon
                  className="point-img"
                  icon={faCalendarDays}
                  onClick={() => setShowCalendarStart(!showCalendarStart)}
                />
                <label className="floating-label"> Date</label>
              </div>
            </div>
            <div className='form-group mb-3'>
              <div className="floating-label-group mb-3">
                <textarea type="text" id="logo" className="input-form-control" required />
                <label className="floating-label">Details</label>
              </div>
            </div>
          </div>
          <div className='checkbox-previewmail'>
            <div className='checkbox-custom'>
              <input type="checkbox" id="preview-mail" />
              <label className="preview-mail">Send receipt</label>
            </div>
            <Link className='preview-mail' href="#">Get a preview email</Link>
          </div>
        </form>
        </>
  )})

export default RecordPayment;