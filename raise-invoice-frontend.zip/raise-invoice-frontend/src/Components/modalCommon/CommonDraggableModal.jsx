import React, { useState, useRef, useEffect } from 'react';
import Draggable from 'react-draggable';
import './DraggableModal.css';
import { useDraggable } from '@/cotexts/draggableContext';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faClose, faDownLeftAndUpRightToCenter, faMaximize, faMinimize, faUpRightAndDownLeftFromCenter, faWindowMaximize, faWindowMinimize } from '@fortawesome/free-solid-svg-icons';
import { isLoading } from '@/constaints/actionConstaints';
import { useDispatch, useSelector } from 'react-redux';
import { getTasksApi, saveTimeAPI } from '@/redux/slices/projectSlice';
import { formatTime } from '@/dependencies/utils/helper';

const CommonDraggableModal = () => {

  const nodeRef = useRef(null);
  const dispatch = useDispatch();
  const { modalType, isMinimized, closeDraggable, toggleMinimize, dragParameter } = useDraggable();
  const { loading } = useSelector(state => state.projectReducer)
  const [isOpen, setIsOpen] = useState(modalType !== null);
  const [modalSize, setModalSize] = useState({ width: 590, height: 485 });
  const [position, setPosition] = useState({ x: 0 , y: 0 });
  const [hasMoved, setHasMoved] = useState(false);
  const [isStarted, setIsStarted] = useState(false);
  const [time, setTime] = useState(0);
  const [timerInterval, setTimerInterval] = useState(null);
  const [timerPayload, setTimerPayload] = useState({
                      id: '',
                      client_id: dragParameter?.payload?.client_id,
                      project_id: dragParameter?.payload?.project_id,
                      notes: '',
                      start_time: '00:00:00',
                      end_time: '',
                      task_id: dragParameter?.payload?.id,
                    });
  const [errors, setErrors] = useState({});
  
  useEffect(() => {
    setIsOpen(modalType !== null);
  }, [modalType])

  useEffect(() => {
    // console.log("dragParameter ::: ", dragParameter?.payload, dragParameter?.payload?.client_id, dragParameter?.payload?.id, dragParameter?.payload?.project_id);
    setTimerPayload(prev => ({...prev,
      client_id : dragParameter?.payload?.client_id,
      project_id : dragParameter?.payload?.project_id,
      task_id : dragParameter?.payload?.id}))
  }, [dragParameter]);

  useEffect(() => {
    const screenWidth = window.innerWidth;
    const screenHeight = window.innerHeight;

    if ( !isMinimized ) {
      // console.log("screenWidth, screenHeight ::: ", (screenWidth - 590), (screenHeight - 485));
      setPosition({
          x: (screenWidth - 590) / 2,
          y: (screenHeight - 485) / 2, 
        });
      setModalSize({ width: 590, height: 485 });
      setHasMoved(false)
    }
    if ( isMinimized ) {
      setModalSize({ width: 300, height: 100 });
      if (!hasMoved) {
        console.log("hasMoved ::: ", screenWidth, screenHeight, hasMoved);
        setPosition(prev => ({
          ...prev,
          x: (screenWidth - 300 - 15),
          y: (screenHeight - 100 - 15)
        }));
      }
    }
    
    
  }, [isOpen, isMinimized, hasMoved]);

  // useEffect(() => {
  //   console.log("position ::: ", position);
    
  // }, [position])

  const startTimer = async () => {
    if( timerPayload?.notes?.trim()?.length === 0 ) {
      setErrors(prev => ({...prev, notes : "Please enter the note to start the timer."}))
      return;
    }
    // await dispatch(saveTimeAPI(timerPayload)).unwrap()
    const interval = setInterval(() => {
      setTime((prev) => prev + 1);
    }, 1000);
    setTimerInterval(interval)
    setIsStarted(true);
    toggleMinimize(true);
  }

  const stopTimer = async ( isClose = false ) => {
    clearInterval(timerInterval);
    const stopPayload = {...timerPayload, end_time : formatTime(time)}
    if(!isClose){
      await dispatch(saveTimeAPI(stopPayload)).unwrap()
      await dispatch(getTasksApi({projectId : dragParameter?.payload?.project_id})).unwrap()
    }
    setIsStarted(false);
    setTime(0)
    setTimerPayload(prev => ({...prev, end_time : '', notes : ''}))
    closeDraggable();
  };


  const handleChange = (e) => {
    setTimerPayload({...timerPayload, [e.target.name] : e.target.value})
    setErrors(prev => {
        const { [e.target.name]: removed, ...rest } = prev;
        return rest;
      })
  }

  useEffect(() => {
    // console.log("dragParameter ::: ", dragParameter);
  }, [dragParameter])

  if (!isOpen) return null;

  return (
      <Draggable
        handle=".modal-header"
        position={position}
        onDrag={(e, data) => {
          setHasMoved(true);
          setPosition({ x: data.x, y: data.y });
        }}
        nodeRef={nodeRef}
      >
        <div 
          ref={nodeRef}
          className={`draggable-modal `}
          style={{
            width: modalSize.width,
            height: modalSize.height,
          }}
        >
          <div className="modal-header">
            <span className="modal-title">{isMinimized ? formatTime(time) : `${dragParameter?.title} of ${dragParameter?.payload?.taskName}`}</span>
            <div className="modal-controls">
              <button 
                className="control-btn" 
                onClick={() => toggleMinimize()}
                title="Minimize"
              >
                <FontAwesomeIcon icon={isMinimized ? faUpRightAndDownLeftFromCenter :  faDownLeftAndUpRightToCenter } />
              </button>
              <button 
                className="control-btn close-btn" 
                onClick={() => stopTimer(true)}
                title="Close"
              >
                <FontAwesomeIcon icon={faClose} />
              </button>
            </div>
          </div>
          {!isMinimized && (
            <div className="modal-content dragable-content">
              {/* {modalType === "task" && <div>Task</div>} */}
              <div className='time-content'>
                <div className='time-label'>Time</div>
                <div className='timer'>{formatTime(time)}</div>
              </div>
              <div className='note-content'>
                <div className='modal-header'>
                  <span>Note</span>
                </div>
                <div className='note-description'>
                  <textarea placeholder='Description' name="notes" value={timerPayload.notes} onChange={ handleChange } />
                  {errors?.notes && <div className="error-message">{errors.notes}</div>}
                </div>
                <button onClick={() => isStarted ? stopTimer() : startTimer()}> <span>{loading ? (isStarted ? "Stoping..." : "Starting") : (isStarted ? "Stop" : "Start")}</span> </button>
              </div>
            </div>
          )}
          {isMinimized && (
            <div className="modal-content minimized dragable-content">
              <div className='note-content'>
                <button onClick={() => isStarted ? stopTimer() : startTimer()}> <span>{loading ? (isStarted ? "Stoping..." : "Starting") : (isStarted ? "Stop" : "Start")}</span> </button>
              </div>
            </div>
          )}
        </div>
      </Draggable>
  );
};

export default CommonDraggableModal;
