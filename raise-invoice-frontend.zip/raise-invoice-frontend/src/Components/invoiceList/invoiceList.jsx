import '../newExpense/newexpense.css';
import React, { useEffect, useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPenToSquare, faTrashCan } from '@fortawesome/free-solid-svg-icons';
import { formatCurrency } from '@/dependencies/utils/helper';
import { deleteInvoice, deleteEstimate, deleteCreditNote, getCreditNoteData, deletePurchaseOrder, getPurchaseOrderData, fetchMasterData } from '@/redux/slices/dataSlice';
import Link from 'next/link';
import { useDispatch } from 'react-redux';
import { useRouter } from 'next/navigation';
import { useModal } from '@/cotexts/modalContext';

const InvoiceList = ({ label, itemss = [], onEditItem, onEditEstimate, sortDirection, route }) => {
    const dispatch = useDispatch();
    const { setParameters } = useModal();
    // const [addEstimateForm, setAddEstimateForm] = useState(false);
    const router = useRouter()
    const [currencyList, setCurrencyList] = useState([]);
    const handleEditItem = (item) => {
        
        if (label === 'Invoice') {
            router.push(`/addInvoice?id=${item.id}`);
        } else {
            router.push(`${route}edit/${item.id}`);
        }
    };

    useEffect(() => {
    async function fetchData() {
        try {
        const data = await dispatch(fetchMasterData()).unwrap();
        setCurrencyList(data.currencyData || []);
        } catch (err) {
        console.error("Failed to fetch master data", err);
        }
    }
    fetchData();
    }, [dispatch]);


    const handleDeleteItem = async (itemId) => {
        const body = { id: itemId.item_id };
        let deleteData = '';
        if (label === 'Invoice') {
            deleteData = await dispatch(deleteInvoice(body)).unwrap();
        }
        if (label === 'Estimate') {
            deleteData = await dispatch(deleteEstimate(body)).unwrap();
        }
        if(label === 'Credit Note') {
            await dispatch(deleteCreditNote(body)).unwrap();
            dispatch(getCreditNoteData());
        }
        if(label === 'Purchase Order') {
            await dispatch(deletePurchaseOrder(body)).unwrap();
            dispatch(getPurchaseOrderData());
        }
        if (deleteData) {
            window.location.href = `/${label.toLowerCase()}`;
        }
    };

    const sortItems = itemss.length > 0  ? [...itemss]?.sort((a, b) => {
        const aName = (a.client?.name || '').toLowerCase();
        const bName = (b.client?.name || '').toLowerCase();

        return sortDirection === 'asc'
            ? aName.localeCompare(bName)
            : bName.localeCompare(aName);
    }) : [];

    // Helper to format date and calculate days left
    const formatDueDate = (dueDateStr) => {
        if (!dueDateStr) return '';
        const dueDate = new Date(dueDateStr);
        const today = new Date();
        dueDate.setHours(0, 0, 0, 0);
        today.setHours(0, 0, 0, 0);

        const diffTime = dueDate - today;
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

        const day = dueDate.getDate();
        const month = dueDate.toLocaleString('en-US', { month: 'short' });
        const formattedDate = `${day} ${month}`;

        let dueText = '';
        if (diffDays > 0) {
            dueText = `Due in ${diffDays} day${diffDays > 1 ? 's' : ''}`;
        } else if (diffDays === 0) {
            dueText = 'Due today';
        } else {
            dueText = `Overdue by ${Math.abs(diffDays)} day${Math.abs(diffDays) > 1 ? 's' : ''}`;
        }

        return `${formattedDate}, ${dueText}`;
    };

    // Helper to format created date
    const formatCreatedDate = (createdDateStr) => {
        if (!createdDateStr) return '';
        const createdDate = new Date(createdDateStr);
        const day = createdDate.getDate();
        const month = createdDate.toLocaleString('en-US', { month: 'short' });
        return `${day} ${month}`;
    };

    // useEffect(() => {
    //     console.log("label ::: ", label);
    // }, [label]);

    return (
        <div className='expense-middle mt-2'>
            <div className='sub-head'>
                <p>{label}</p>
                <p>{sortItems.length}</p>
            </div>
            <div className="invoice-list-all invoiceListing-scroll">
                {sortItems.map((item, index) => (
                    <div className="invoice-list" key={index}>
                        <div className='invoice-left'>
                            {/* <p className="text-start">{item.client?.name}</p> */}
                            <div className='userlist-left-content'>
                                <h6><Link href={`${route}${item.id}`}>{item.client?.name}</Link></h6>
                                {label === 'Invoice' && (
                                    <p>
                                        {item.dueDate && (
                                            <span>
                                                {formatDueDate(item.dueDate)}
                                            </span>
                                        )}
                                    </p>
                                )}
                            </div>
                            {!!(label === 'Estimate' || label === 'Purchase Order' || label === 'Credit Note') && (
                                <p>
                                    {item?.createdAt && (
                                        <span>
                                            {formatCreatedDate(item.createdAt)}
                                        </span>
                                    )}
                                </p>
                            )}

                        </div>
                        <div className='invoice-right-icon'>
                            <div className='invoice-right'>
                                <p className="invoice-price">{formatCurrency(item.total, currencyList)}</p>
                                <p style={{ color: item.paymentStatus == 'unpaid' ? '#F35B04' : 'green' }}>{item.sentStatus == 'unsent' ? 'Unsent' : 'Sent'}</p>
                            </div>
                            <div className='group-icon'>
                                <a href="#" onClick={e => { e.preventDefault(); handleEditItem(item); }}>
                                    <FontAwesomeIcon icon={faPenToSquare} />
                                </a>
                                <a href="#" onClick={e => { e.preventDefault(); handleDeleteItem({ item_id: item.id }); }}>
                                    <FontAwesomeIcon icon={faTrashCan} />
                                </a>
                            </div>
                        </div>
                    </div>
                ))}
                {itemss?.length === 0 && <p>No {label?.toLowerCase()} available.</p>}
            </div>
        </div>
    );
};

export default InvoiceList;
