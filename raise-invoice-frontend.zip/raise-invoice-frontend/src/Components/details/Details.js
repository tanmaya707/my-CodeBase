'use client'
import React, { useEffect, useState } from 'react'
import './details.css';
import AboutVideo from '../AboutVideo';
import { IMAGE } from '../../utils/Theme';
import Link from 'next/link';
import Accordion from 'react-bootstrap/Accordion';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faFireFlameCurved, faUserCheck, faEnvelope, faFlag, faHeart } from '@fortawesome/free-solid-svg-icons';

// import Slider from "react-slick";
// import Script from 'next/script';


import Api from "../../api/api";
import Testimonial from "@/Components/testimonial/Testimonial";
import LoadingScreen from "@/Components/loadingScreen/LoadingScreen";

const Details = () => {
    const [error, setError] = useState(null);
    const [isLoading, setIsLoading] = useState(true);
    const [pagecontent, setPagecontent] = useState([]);
    const [testimonials, setTestimonials] = useState([]);
    const [faqs, setFaqs] = useState([]);
    useEffect(() => {
        getPagecontent();
    }, []);
    const getPagecontent = async () => {
        setIsLoading(true);
        setError(null);
        try {
            const pagecontentResponse = await Api.POST('get-pagecontent-by-slug', { slug: 'home' });
            setPagecontent(pagecontentResponse.data.data);
            let blocks = pagecontentResponse?.data?.data?.blocks;
            var testimonialIndex = blocks && blocks.findIndex(b => b.section_type == 2);
            let testimonialIds = (testimonialIndex >= 0) && blocks[testimonialIndex].testimonial_ids ? blocks[testimonialIndex].testimonial_ids.split(',').map(Number) : [];
            getTestimonials(testimonialIds);
            const faqIndex = blocks && blocks.findIndex(b => b.section_type == 1);
            let faqIds = (faqIndex >= 0) && blocks[faqIndex].faq_ids ? blocks[faqIndex].faq_ids.split(',').map(Number) : [];
            getFaqList(faqIds);
        } catch (err) {
            setError("Failed to fetch page content.");
        } finally {
            setIsLoading(false);
        }
    };
    const getTestimonials = async (testimonialIds = []) => {
        setIsLoading(true);
        setError(null);
        try {
            const testimonialResponse = await Api.POST('get-testimonial-list', { testimonialIds: testimonialIds });
            setTestimonials(testimonialResponse.data.data);
        } catch (err) {
            setError("Failed to fetch testimonial list.");
        } finally {
            setIsLoading(false);
        }
    };
    const getFaqList = async (faqIds = []) => {
        setIsLoading(true);
        setError(null);
        try {
            const faqResponse = await Api.POST('get-faq-list', { searchText: '', faqIds: faqIds });
            setFaqs(faqResponse.data.data);
        } catch (err) {
            setError("Failed to fetch Faq list.");
        } finally {
            setIsLoading(false);
        }
    }

    const renderBlock = (data, i) => {
        // console.log("data", data);
        
        switch (data.section_type) {
            case 1:            
                return <div className='faqs faq-home' key={i}>
                    <div className='container'>
                        <div className="row">
                            <div className="col-lg-6 col-md-6 col-12">
                                <h2 className='faqs-title'>{data.title}</h2>
                                <Accordion defaultActiveKey={0}>
                                    {faqs &&
                                        faqs.map((faq, j) => (
                                            <Accordion.Item eventKey={j} key={j}>
                                                <Accordion.Header>{faq.question}</Accordion.Header>
                                                <Accordion.Body>
                                                    <div key={j} dangerouslySetInnerHTML={{ __html: faq.answer }} />
                                                </Accordion.Body>
                                            </Accordion.Item>
                                        ))}
                                </Accordion>
                            </div>
                            <div className="col-lg-6 col-md-6 col-12 h-100">
                                <div className="faq-right">
                                    <img className="woman" src={IMAGE.woman} alt='Image broken' />
                                </div>
                            </div>
                        </div>

                    </div>
                </div>;
            case 2:
                return <div className='testimonials' key={i}>
                    <div className='container'>
                        <p className='loved'><FontAwesomeIcon icon={faHeart} /> Loved by experts</p>
                        <h2>{data.title}</h2>
                        <p className="paratext">{data.subtitle}</p>
                        {testimonials && testimonials?.length && <Testimonial testimonials={testimonials} />}
                    </div>
                </div>;
            case 3:
                return <div key={i} dangerouslySetInnerHTML={{ __html: data.template }} />;
        }
    }

    return (
        <>
            {
                (!isLoading && pagecontent && pagecontent.blocks) ?
                    pagecontent.blocks.length &&
                    pagecontent.blocks.map((block, i) => (
                        renderBlock(block, i)
                    ))
                    : <LoadingScreen />
            }
            {/* <div className="body-details">
            <div className="container">
                <div className="row text-center">
                    <div className="col-lg-4 col-md-4 col-12 ">
                    <div className="details">
                        
                        <h4>Handle all your <span>admin work</span>  in minutes</h4>
                        <p>Easy-to-use tools to attach expenses, schedule appointments, and track & bill hours.</p>
                    </div>
                </div>

                    <div className="col-lg-4 col-md-4 col-12 ">
                    <div className="details">
                        <h4>See the big picture with <span>business reports</span> </h4>
                        <p>Track how your business is doing and get critical insights with easy-to-use charts and graphs.</p>
                    </div>
                    </div>

                    <div className="col-lg-4 col-md-4 col-12 ">
                    <div className="details">
                        <h4> <span >Spend less time</span> managing your books</h4>
                        
                        <p>Sync all of your invoicing and payments data to QuickBooks or Xero for your tax preparer.</p>
                    </div>
                    </div>

                </div>


            </div>
        </div>
        <AboutVideo/>

        <div className='howtoinvoice'>
            <div className='container'>
           
                    <h2 className='text-center mb-5'>How to use RaiseInvoice?</h2>
                    <div className="container">
                        <div className="row">
                            <div className="col-lg-4 col-md-6 col-12">
                                <div className="invoice-box">
                                    <span className="badge badge-primary">STEP 1</span>
                                    <h4 >Handle all your admin work in minutes+</h4>
                                    <p >Easy-to-use tools to attach expenses, schedule appointments, and track & bill hours.</p>
                                </div>
                            </div>
                            <div className="col-lg-4 col-md-6 col-12">
                            <div className="invoice-box">
                                    <span className="badge badge-primary">STEP 2</span>
                                    <h4>See the big picture with business reports</h4>
                                    <p>Track how your business is doing and get critical insights with easy-to-use charts and graphs.</p>
                                </div>
                            </div>
                            <div className="col-lg-4 col-md-6 col-12">
                            <div className="invoice-box">
                                    <span className="badge badge-primary">STEP 3</span>
                                    <h4>Spend less time managing your books</h4>
                                    <p>Sync all of your invoicing and payments data to QuickBooks or Xero for your tax preparer.</p>
                                </div>
                            </div>
                        </div>
                        </div>
              
            </div>
            <img className="comment" src={IMAGE.comment} alt='Image broken'/>
            <img className="binarybg" src={IMAGE.binary} alt='Image broken'/>
        </div>

        <div className='typeofbusiness'>
            <div className='container'>
                <div className='bussiness-head'>
                    <h4>All type of business can use our app</h4>
                    <span>RaiseInvoice</span>
                </div>
          </div>
                <div className="image-container-background carpenter paddng-top">
                    <div className='container'>
                        <div className="row align-items-center">
                            <div className="col-lg-5 col-md-6 col-12">
                                <img className="businness-img" src={IMAGE.carpenter} alt="Card image cap" />
                            </div>
                            <div className="col-lg-7 col-md-6 col-12">
                                <div className="business-text padding-left">
                                    <h2>Carpenter</h2>
                                    <img src={IMAGE.line} alt='Image broken'/>
                                    <p>Lorem ipsum dolor sit amet consectetur. Egestas sem arcu tincidunt nisl in cursus. Est sollicitudin interdum nulla in. Aliquet vitae aliquam ridiculus nec quis luctus. Justo suspendisse libero vulputate sapien.</p>
                                    <h4>What We Offer</h4>
                                    <ul>
                                        <li><img src={IMAGE.tick} alt="j" /><p>Luxury escapes to exotic destinations</p></li>
                                        <li><img src={IMAGE.tick} alt="k" /><p>Budget-friendly adventures for solo travelers and families</p></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="image-container-background freelancer cmn-padding">
                <div className='container'>
                    <div className="row align-items-center">
                        <div className="col-lg-5 col-md-6 col-12">
                            <img className="businness-img" src={IMAGE.freelance} alt="Card image cap" />
                        </div>
                        <div className="col-lg-7 col-md-6 col-12">
                            <div className="business-text padding-right">
                                <h2>Freelancers</h2>
                                <img src={IMAGE.line} alt='Image broken'/>
                                <p>Lorem ipsum dolor sit amet consectetur. Egestas sem arcu tincidunt nisl in cursus. Est sollicitudin interdum nulla in. Aliquet vitae aliquam ridiculus nec quis luctus. Justo suspendisse libero vulputate sapien.</p>
                                <h4>What We Offer</h4>
                                <ul>
                                    <li><img src={IMAGE.tick} alt="fcdf" /><p>Luxury escapes to exotic destinations</p></li>
                                    <li><img src={IMAGE.tick} alt="vcvc" /><p>Budget-friendly adventures for solo travelers and families</p></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                </div>
         
                <div className="image-container-background plumber">
                <div className='container '>
                    <div className="row align-items-center">
                        <div className="col-lg-5 col-md-6 col-12">
                            <img className="businness-img " src={IMAGE.plumber} alt="Card image cap" />
                        </div>
                        <div className="col-lg-7 col-md-6 col-12">
                            <div className="business-text padding-left">
                                <h2>Plumbers</h2>
                                <img src={IMAGE.line} alt='Image broken'/>
                                <p>Lorem ipsum dolor sit amet consectetur. Egestas sem arcu tincidunt nisl in cursus. Est sollicitudin interdum nulla in. Aliquet vitae aliquam ridiculus nec quis luctus. Justo suspendisse libero vulputate sapien.</p>
                                <h4>What We Offer</h4>
                                <ul>
                                    <li><FontAwesomeIcon icon={faCircleCheck} /><p>Luxury escapes to exotic destinations</p></li>
                                    <li><FontAwesomeIcon icon={faCircleCheck} /><p>Budget-friendly adventures for solo travelers and families</p></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div className='features'>
            <div className='container'>
                <div className='feature-list'>
                <h2 className='checkout mobile-chkout'>Checkout Our Features</h2>

                <div className="row">
                    <div className="col-lg-6 col-md-6 col-12">
                        <h2 className='checkout desktop-chkout'>Checkout Our Features</h2>
                        <div className='feature-point'>
                            <ul>
                                <li>
                                    <div className='key-points'>
                                        <img src={IMAGE.pink_btn} alt="" />
                                        <div>
                                            <h4>Reports</h4>
                                            <p>The world&apos;s simplest way to invoice customers, from your phone or laptop. Save time, stay organized</p>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div className='key-points'>
                                        <img src={IMAGE.blue_btn} alt="" />
                                        <div>
                                            <h4>Integrations</h4>
                                            <p>The world&apos;s simplest way to invoice customers, from your phone or laptop. Save time, stay organized</p>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                            <Link href="#" className='tryit m-0'><span> Try it for free</span>  <img className='whitearrow' src={IMAGE.white_arrow} alt='Image broken'/></Link>
                        </div>
                    </div>
                    <div className="col-lg-6 col-md-6 col-12 my-5 feature-point">
                        <ul>
                            <li>
                                <div className='key-points'>
                                    <img src={IMAGE.seagreen_btn} alt="" />
                                    <div>
                                        <h4>Invoice</h4>
                                        <p>The world&apos;s simplest way to invoice customers, from your phone or laptop. Save time, stay organized</p>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div className='key-points'>
                                    <img src={IMAGE.pink_btn} alt="" />
                                    <div>
                                        <h4>Payment</h4>
                                        <p>The world&apos;s simplest way to invoice customers, from your phone or laptop. Save time, stay organized</p>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div className='key-points'>
                                    <img src={IMAGE.green_btn} alt="" />
                                    <div>
                                        <h4>Business Account
                                        </h4>
                                        <p>The world&apos;s simplest way to invoice customers, from your phone or laptop. Save time, stay organized</p>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div className='key-points'>
                                    <img src={IMAGE.blue_btn} alt="" />
                                    <div>
                                        <h4>Invoice App</h4>
                                        <p>The world&apos;s simplest way to invoice customers, from your phone or laptop. Save time, stay organized</p>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div className='key-points'>
                                    <img src={IMAGE.seagreen_btn} alt="" />
                                    <div>
                                        <h4>Project</h4>
                                        <p>The world&apos;s simplest way to invoice customers, from your phone or laptop. Save time, stay organized</p>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                </div>
            </div>
            <div className='pos-img'>
                <img className="commentblue" src={IMAGE.quoteimg}/>
            </div>
        

            
        </div>

        <div className='trialversion'>
            <div className='container'>
                <div className="row basecolor my-5">
                    <div className="col-lg-6 col-md-12 col-12 basecolor-left">
                    <div className="basecolor-img">
                        <img className="laptop-img" src={IMAGE.laptop} alt='Image broken'/>
                        <img className="phone-img" src={IMAGE.Iphone} alt='Image broken'/>
                    </div>

                    </div>
                    <div className="col-lg-6 col-md-12 col-12 my-2">
                  
                    <div className=" trial-right">

                        <h2 className='trialhead'>Checkout Our Free Trial Version</h2>
                        <img className='underarrow' src={IMAGE.underarrow} alt='Image broken'/>
                        <h4 className='trialsubhead'>For 30 Days | Web & Mobile App</h4>
                        <p className='trialdetails'>Sync all of your invoicing and payments data to QuickBooks or Xero for your tax preparer.</p>
                        <div className='buttons my-5'>
                        <Link className="lognow" href={{}}><span>Login Now</span> <img className='whitearrow' src={IMAGE.white_arrow} alt='Image broken'/></Link>
                        <Link className="download" href={{}}><span>Download Now</span> <img className='bluearrow' src={IMAGE.blue_arrow} alt='Image broken'/></Link>
                        </div>
                        <img className="commentblue dsktop-commentblue" src={IMAGE.quoteimg}/>
                        </div>

                    </div>
                </div>
            </div>
            <img className="commentblue mbl-commentblue" src={IMAGE.quoteimg}/>

        </div>

        <div className='faqs faq-home'>
            <div className='container'>
                <div className="row">
                    <div className="col-lg-6 col-md-6 col-12">
                        <h2 className='faqs-title'>Our FAQ’s</h2>
                        <Accordion defaultActiveKey="0">
                        <Accordion.Item eventKey="0">
                            <Accordion.Header>Who can use RaiseInvoice?</Accordion.Header>
                            <Accordion.Body>
                            The world&apos;s simplest way to invoice customers, from your phone or laptop. Save time, stay organized and look professional.
                            </Accordion.Body>
                        </Accordion.Item>
                        <Accordion.Item eventKey="1">
                            <Accordion.Header>Who can use RaiseInvoice?</Accordion.Header>
                            <Accordion.Body>
                            The world&apos;s simplest way to invoice customers, from your phone or laptop. Save time, stay organized and look professional.
                            </Accordion.Body>
                        </Accordion.Item>
                        <Accordion.Item eventKey="2">
                            <Accordion.Header>Who can use RaiseInvoice?</Accordion.Header>
                            <Accordion.Body>
                            The world&apos;s simplest way to invoice customers, from your phone or laptop. Save time, stay organized and look professional.
                            </Accordion.Body>
                        </Accordion.Item>
                        <Accordion.Item eventKey="3">
                            <Accordion.Header>Who can use RaiseInvoice?</Accordion.Header>
                            <Accordion.Body>
                            The world&apos;s simplest way to invoice customers, from your phone or laptop. Save time, stay organized and look professional.
                            </Accordion.Body>
                        </Accordion.Item>
                        </Accordion>
                    </div>
                    <div className="col-lg-6 col-md-6 col-12 h-100">
                    <div className="faq-right">

                        <img className="woman" src={IMAGE.woman} alt='Image broken'/>
                        </div>
                    </div>
                </div>
              
            </div>
        </div>

        <div className='testimonials'>
            <div className='container'>
                <div>
                    <p className='loved'><FontAwesomeIcon icon={faHeart} /> Loved by experts</p>
                    <h2>Our Testimonials</h2>
                    <p className="paratext">Join us now and see what the hype is all about.</p>

                    <div>
                    <Slider {...settings}>
                        <div>
                            <div className="card-body">
        
                                <p className="card-text">Cardinal ensures we&apos;re making decisions based on data we
                                can trust and gives stakeholders visibility into results without 
                                constant back and forth among teams. Cardinal solves that
                                for us and provides a central place for our whole company to 
                                see the true impact of our entire product strategy as a whole.
                                </p>
                                <div className='card-footer'>
                                    <div className='user-details'>
                                        <h4>Christopher Byrum</h4>
                                        <p>VP Product</p>
                                        <p>Puls</p>
                                    </div>
                                    <div>
                                     <div className='client-img'>
                                        <img src={IMAGE.profile} alt='Image broken'/>
                                    </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div>
                            <div className="card-body">
        
                                <p className="card-text">Cardinal ensures we&apos;re making decisions based on data we
                                can trust and gives stakeholders visibility into results without 
                                constant back and forth among teams. Cardinal solves that
                                for us and provides a central place for our whole company to 
                                see the true impact of our entire product strategy as a whole.
                                </p>
                                <div className='card-footer'>
                                    <div className='user-details'>
                                        <h4>Christopher Byrum</h4>
                                        <p>VP Product</p>
                                        <p>Puls</p>
                                    </div>
                                    <div>
                                     <div className='client-img'>
                                        <img src={IMAGE.profile} alt='Image broken'/>
                                    </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div>
                            <div className="card-body">
        
                                <p className="card-text">Cardinal ensures we&apos;re making decisions based on data we
                                can trust and gives stakeholders visibility into results without 
                                constant back and forth among teams. Cardinal solves that
                                for us and provides a central place for our whole company to 
                                see the true impact of our entire product strategy as a whole.
                                </p>
                                <div className='card-footer'>
                                    <div className='user-details'>
                                        <h4>Christopher Byrum</h4>
                                        <p>VP Product</p>
                                        <p>Puls</p>
                                    </div>
                                    <div>
                                    <div className='client-img'>
                                        <img src={IMAGE.profile} alt='Image broken'/>
                                    </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div>
                            <div className="card-body">
        
                                <p className="card-text">Cardinal ensures we&apos;re making decisions based on data we
                                can trust and gives stakeholders visibility into results without 
                                constant back and forth among teams. Cardinal solves that
                                for us and provides a central place for our whole company to 
                                see the true impact of our entire product strategy as a whole.
                                </p>
                                <div className='card-footer'>
                                    <div className='user-details'>
                                        <h4>Christopher Byrum</h4>
                                        <p>VP Product</p>
                                        <p>Puls</p>
                                    </div>
                                    <div>
                                    <div className='client-img'>
                                        <img src={IMAGE.profile} alt='Image broken'/>
                                    </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div>
                            <div className="card-body">
        
                                <p className="card-text">Cardinal ensures we&apos;re making decisions based on data we
                                can trust and gives stakeholders visibility into results without 
                                constant back and forth among teams. Cardinal solves that
                                for us and provides a central place for our whole company to 
                                see the true impact of our entire product strategy as a whole.
                                </p>
                                <div className='card-footer'>
                                    <div className='user-details'>
                                        <h4>Christopher Byrum</h4>
                                        <p>VP Product</p>
                                        <p>Puls</p>
                                    </div>
                                    <div>
                                    <div className='client-img'>
                                        <img src={IMAGE.profile} alt='Image broken'/>
                                    </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div>
                            <div className="card-body">
        
                                <p className="card-text">Cardinal ensures we&apos;re making decisions based on data we
                                can trust and gives stakeholders visibility into results without 
                                constant back and forth among teams. Cardinal solves that
                                for us and provides a central place for our whole company to 
                                see the true impact of our entire product strategy as a whole.
                                </p>
                                <div className='card-footer'>
                                    <div className='user-details'>
                                        <h4>Christopher Byrum</h4>
                                        <p>VP Product</p>
                                        <p>Puls</p>
                                    </div>
                                    <div>
                                    <div className='client-img'>
                                        <img src={IMAGE.profile} alt='Image broken'/>
                                    </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div>
                            <div className="card-body">
        
                                <p className="card-text">Cardinal ensures we&apos;re making decisions based on data we
                                can trust and gives stakeholders visibility into results without 
                                constant back and forth among teams. Cardinal solves that
                                for us and provides a central place for our whole company to 
                                see the true impact of our entire product strategy as a whole.
                                </p>
                                <div className='card-footer'>
                                    <div className='user-details'>
                                        <h4>Christopher Byrum</h4>
                                        <p>VP Product</p>
                                        <p>Puls</p>
                                    </div>
                                    <div>
                                    <div className='client-img'>
                                        <img src={IMAGE.profile} alt='Image broken'/>
                                    </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div>
                            <div className="card-body">
        
                                <p className="card-text">Cardinal ensures we&apos;re making decisions based on data we
                                can trust and gives stakeholders visibility into results without 
                                constant back and forth among teams. Cardinal solves that
                                for us and provides a central place for our whole company to 
                                see the true impact of our entire product strategy as a whole.
                                </p>
                                <div className='card-footer'>
                                    <div className='user-details'>
                                        <h4>Christopher Byrum</h4>
                                        <p>VP Product</p>
                                        <p>Puls</p>
                                    </div>
                                    <div>
                                    <div className='client-img'>
                                        <img src={IMAGE.profile} alt='Image broken'/>
                                    </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </Slider>
                    </div>
                </div>
            </div>
        </div>
        
        <div className='make-invoicing'>
         <div className='container'>
            <h2 className='my-5'>Make Invoicing Simple with us</h2>
            <div className='make-invoicing-body'>
                <div className='simple-invoice'>
                    <h2>01</h2>
                    <h4>Handle all your admin work in minutes</h4>
                    <p>Easy-to-use tools to attach expenses, schedule appointments, and track & bill hours.</p>
                </div>
                <div className='simple-invoice'>
                    <h2>02</h2>
                    <h4>See the big picture with business reports</h4>
                    <p>Track how your business is doing and get critical insights with easy-to-use charts and graphs.</p>
                </div>
                <div className='simple-invoice'>
                    <h2>03</h2>
                    <h4>Spend less time managing your books</h4>
                    <p>Sync all of your invoicing and payments data to QuickBooks or Xero for your tax preparer.</p>
                </div>
                <div className='simple-invoice'>
                    <h2>04</h2>
                    <h4>Take care of business on the spot</h4>
                    <p>With the&nbsp;Invoice2go&nbsp;app (available on the web, iOS, and Android) all of your information is synced&nbsp;</p>
                </div>
            </div>
        <img className='methods' src={IMAGE.paymentmethods} alt='Image broken'/>

        </div>
        </div> */}




        </>
    )
}

export default Details


