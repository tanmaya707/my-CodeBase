import axios from "axios";

export const httpClient = axios.create();
httpClient.defaults.timeout = 5 * 60 * 1000;

httpClient.defaults.httpsAgent = new (require("https").Agent)({
  rejectUnauthorized: false,
});

// Function to get the auth token dynamically
const getAuthToken = () => (typeof localStorage !== 'undefined') ? localStorage.getItem("web-auth-token") : null;

const axiosConfig = {
  headers: {
    // "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    'Authorization': `Bearer ${getAuthToken()}`,
  },
};

const configData = {
  headers: {
    "Content-Type": "multipart/form-data",
    "Access-Control-Allow-Origin": "*",
    'Authorization': `Bearer ${getAuthToken()}`,
  },
};

const downloadHeader = {
  headers: {
    Accept: "text/csv",
  },
};

const downloadHeaderPDF = {
  headers: {
    Accept: "application/pdf",
  },
};

const downloadHeaderEXCEL = {
  headers: {
    Accept: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  },
};

class Api {
  async POST(url, payload = {}, config = axiosConfig) {
    try {
      return await httpClient.post(url, payload, config);
    } catch (error) {
      console.error("Error in POST request:", error);
      if (error.response) {
        if (error.response && (error.response.status === 401 || error.response.status === 403)) {
          localStorage.clear();
          sessionStorage.clear();
          window.location.href = '/';
        }
          throw error.response;
      }
      throw error;
    }
  }

  async GET(url, config = axiosConfig) {
    try {
      const response = await httpClient.get(url, config);
      return response.data;
    } catch (error) {
      console.error("Error in GET request:", error);
      throw error;
    }
  }

  async POSTDATA(url, payload = {}, config = configData) {
    try {
      return await httpClient.post(url, payload, config);
    } catch (error) {
      console.error("Error in POSTDATA request:", error);
      throw error;
    }
  }

  async DELETE(url, config = axiosConfig) {
    try {
      return await httpClient.delete(url, config);
    } catch (error) {
      console.error("Error in DELETE request:", error);
      throw error;
    }
  }

  async PUT(url, payload = {}, config = axiosConfig) {
    try {
      return await httpClient.put(url, payload, config);
    } catch (error) {
      console.error("Error in PUT request:", error);
      throw error;
    }
  }

  async PUTDATA(url, payload = {}, config = configData) {
    try {
      return await httpClient.put(url, payload, config);
    } catch (error) {
      console.error("Error in PUT request:", error);
      throw error;
    }
  }

  async DOWNLOADGETCSV(url, config = downloadHeader) {
    try {
      return await httpClient.get(url, config);
    } catch (error) {
      console.error("Error in CSV Download:", error);
      throw error;
    }
  }

  async DOWNLOADGETPDF(url) {
    try {
      return await httpClient({
        url,
        method: "GET",
        responseType: "blob",
        headers: downloadHeaderPDF.headers,
      });
    } catch (error) {
      console.error("Error in PDF Download:", error);
      throw error;
    }
  }

  async DOWNLOADGETEXCEL(url, config = downloadHeaderEXCEL) {
    try {
      return await httpClient.get(url, config);
    } catch (error) {
      console.error("Error in Excel Download:", error);
      throw error;
    }
  }
}

// Assign to variable before export
const apiInstance = new Api();
export default apiInstance;