import axios from "axios";

// var authToken = (typeof localStorage !== 'undefined') ? localStorage.getItem("web-auth-token") : null;

export const httpClient = axios.create();
httpClient.defaults.timeout = 5 * 60 * 1000;


httpClient.defaults.httpsAgent = new (require("https").Agent)({
  rejectUnauthorized: false,
});

const axiosConfig = {
  headers: {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    // 'Authorization': 'Bearer ' + authToken
  },
};

const configData = {
  headers: {
    "Content-Type": "multipart/form-data",
  },
};

const downloadHeader = {
  headers: {
    Accept: "text/csv",
    "Access-Control-Allow-Origin": "*",
  },
};
const downloadHeaderPDF = {
  headers: {
    Accept: "application/pdf",
    "Access-Control-Allow-Origin": "*",
  },
};
const downloadHeaderEXCEL = {
  headers: {
    Accept: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "Access-Control-Allow-Origin": "*",
  },
};

class Api {
  POST(url, payload = {}, config = axiosConfig) {
    return httpClient.post(url, payload, config).catch((error) => {
      console.error("Error in POST request:", error);
      return error && error.response;
    });
  }

  GET(url, config = axiosConfig) {
    return httpClient.get(url, config).then((response) => response.data)
      .catch((error) => {
        console.error("Error in GET request:", error);
        throw error;
      });
  }

  POSTDATA(url, payload = {}, config = configData) {
    return httpClient.post(url, payload, config).catch((error) => {
      console.error("Error in POSTDATA request:", error);
      return error && error.response;
    });
  }

  DELETE(url, config = axiosConfig) {
    return httpClient.delete(url, config).catch((error) => {
      console.error("Error in DELETE request:", error);
      return error && error.response;
    });
  }

  PUT(url, payload = {}, config = axiosConfig) {
    return httpClient.put(url, payload, config).catch((error) => {
      console.error("Error in PUT request:", error);
      return error && error.response;
    });
  }

  DOWNLOADGETCSV(url, config = downloadHeader) {
    return httpClient.get(url, config).catch((error) => {
      console.error("Error in CSV Download:", error);
      return error && error.response;
    });
  }

  DOWNLOADGETPDF(url) {
    return httpClient({
      url,
      method: "GET",
      responseType: "blob",
      headers: downloadHeaderPDF.headers,
    }).catch((error) => {
      console.error("Error in PDF Download:", error);
      return error && error.response;
    });
  }

  DOWNLOADGETEXCEL(url, config = downloadHeaderEXCEL) {
    return httpClient.get(url, config).catch((error) => {
      console.error("Error in Excel Download:", error);
      return error && error.response;
    });
  }
}

// Assign to variable before export
const apiInstance = new Api();
export default apiInstance;
