import { storage } from "../store/storage";

export const isUserloggedIn = () => {
  if (storage.isLoggedIn()) {
    return true;
  }
  return false;
};


export const formatTime = (seconds) => {
  const hrs = String(Math.floor(seconds / 3600)).padStart(2, "0");
  const mins = String(Math.floor((seconds % 3600) / 60)).padStart(2, "0");
  const secs = String(seconds % 60).padStart(2, "0");
  return `${hrs}:${mins}:${secs}`;
};

export const convertTime = (time) => {
  const [hours, minutes, seconds] = time.split(":").map(Number);  
  const totalSeconds = (hours ? hours * 3600 : 0) + (minutes ? minutes * 60 : 0) + (seconds || 0);
  // console.log("totalSeconds --------------------->  ", totalSeconds);
  
  return totalSeconds;
};

export const dateFormater = (date) => {
  const newDate = new Date(date);
  const formattedDate = newDate.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
  return formattedDate
}

export const differentOfDate = ( date ) => {
  const currentDate = new Date();
  const newDate = new Date(date);
  
  currentDate.setHours(0, 0, 0, 0);
  newDate.setHours(0, 0, 0, 0);

  const diffTime = currentDate.getTime() - newDate.getTime();
  const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));

  const years = Math.floor(diffDays / 365);  // rough
  const months = Math.floor(diffDays / 30);  // rough

  if (years > 0) return years === 1 ? "1 year" : `${years} years`;
  if (months > 0) return months === 1 ? "1 month" : `${months} months`;
  return diffDays === 1 ? "1 day" : `${diffDays} days`;
}

export const getCurrencySymbol = (currencyCode = (typeof localStorage !== "undefined" && localStorage.getItem("Currency")) || "USD", currencyList = []) => {
  const code = (currencyCode || "USD").toUpperCase();
  const list = currencyList || [];
  let match = list.find(c => (c.currency_code || "").toUpperCase() === code);
  const symbol = match?.symbol || list.find(c => (c.currency_code || "").toUpperCase() === "USD")?.symbol || "";
  return symbol;
};

export const formatCurrency = (val, currencyList = []) => {
  const symbolToUse = getCurrencySymbol(undefined, currencyList);
  const abs = Math.abs(val).toFixed(2);
  return val < 0 ? `-${symbolToUse}${abs}` : `${symbolToUse}${abs}`;
};