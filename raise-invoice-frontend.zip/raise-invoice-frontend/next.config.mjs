/** @type {import('next').NextConfig} */
const nextConfig = {
  // async headers() {
  //     return [
  //         {
  //             source: '/:path*', // Match all routes
  //             headers: [
  //                 { key: 'Cache-Control', value: 'no-store, no-cache, must-revalidate, proxy-revalidate' },
  //                 { key: 'Pragma', value: 'no-cache' },
  //                 { key: 'Expires', value: '0' },
  //             ],
  //         },
  //     ];
  // },
  // experimental: {
  //     disableRouterCache: true,
  // },

  images: {
    domains: ["127.0.0.1", "3.108.121.124"],
  },
  typescript: {
    ignoreBuildErrors: true,
  },
  eslint: {
    ignoreDuringBuilds: true,
  },
  assetPrefix: "",
  env: {
    // serverUrl: "http://3.108.121.124:4001/",
    serverUrl: "http://127.0.0.1:4001/",
  },
};

export default nextConfig;
