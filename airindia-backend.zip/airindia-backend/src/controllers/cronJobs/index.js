import * as cron from "node-cron";
import * as schedule from "./schedule/index.js";

export const schedulers = () => {
  // cron.schedule("*/1 * * * * *", () => {
  //   console.log("cron runs in each 1 sec");
  
  // });

};
