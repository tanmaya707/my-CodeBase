import model from "../../../models/index.js";
import { envs, StatusError } from "../../../config/index.js";
import { Op, fn, col } from "sequelize";

/**
 *get blog page details
 * @param req
 * @param res
 * @param next
 */
export const blogDetails = async (req, res, next) => {
  try {
    const reqBody = req.params;
    const uuid = reqBody.id ? reqBody.id : "";
    if (!uuid) throw StatusError.badRequest(res.__("Invalid success story"));
    const checkRecordId = await model.blog.count({
      where: { slug_name: uuid, status: "active" },
    });
    if (checkRecordId == 0) throw StatusError.badRequest(res.__("Invalid success story"));
    let getBlog = await model.blog.findOne({
      where: {
        status: "active",
        slug_name: uuid,
      },
      attributes: [
        "uuid",
        "blog_title",
        "slug_name",
        "blog_short_description",
        "blog_description",
        "website_link",
        "published_at",
      ],
      include: [
        {
          attributes: [
            [fn("REPLACE", col("blogImages.file_path"), `public/uploads/`, `public/`), "file_path"],
          ],
          model: model.blogImage,
          where: { status: "active" },
          required: false,
        },
      ],
    });
    if (getBlog) {
      getBlog.dataValues.blog_images =
        getBlog.dataValues.blogImages.length > 0 ? getBlog.dataValues.blogImages : [];
      delete getBlog.dataValues.blogImages;
      res.ok(getBlog);
    } else {
      throw StatusError.notFound(res.__("data not found"));
    }
  } catch (error) {
    next(error);
  }
};
