import model from "../../../models/index.js";
import { StatusError, envs } from "../../../config/index.js";
import { Op, fn, col } from "sequelize";
import { generalHelper } from "../../../helpers/index.js";

/**
 *get blog list page details
 * @param req
 * @param res
 * @param next
 */
export const blogList = async (req, res, next) => {
  try {
    let blogs = await await model.blog.findAll({
      where: {
        status: "active",
      },
      attributes: [
        "uuid",
        "blog_title",
        "slug_name",
        "blog_short_description",
        "blog_description",
        "website_link",
        "published_at",
      ],
      include: [
        {
          attributes: [
            [fn("REPLACE", col("blogImages.file_path"), `public/uploads/`, `public/`), "file_path"],
          ],
          model: model.blogImage,
          where: { status: "active" },
          required: false,
        },
      ],
      order: [
        ["published_at", "desc"],
        ["id", "desc"],
      ],
    });

    if (blogs && blogs.length > 0) {
      blogs = blogs.map((record) => {
        record.dataValues.blog_description = !record.dataValues.blog_description
          ? ""
          : generalHelper.stripHtmlAndLimit(record.dataValues.blog_description);
        record.dataValues.blog_images =
          record.dataValues.blogImages.length > 0 ? record.dataValues.blogImages : [];
        delete record.dataValues.blogImages;
        return record;
      });
      res.ok({ results: blogs });
    } else {
      throw StatusError.notFound(res.__("data not found"));
    }
  } catch (error) {
    console.log(error);
    next(error);
  }
};
