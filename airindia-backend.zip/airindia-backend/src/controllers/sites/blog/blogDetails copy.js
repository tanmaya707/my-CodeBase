import model from "../../../models/index.js";
import { envs, StatusError } from "../../../config/index.js";
import { Op, fn, col } from "sequelize";

/**
 *get blog page details
 * @param req
 * @param res
 * @param next
 */
export const blogDetails = async (req, res, next) => {
  try {
    const blogUuId = req.query.blog_id;
    let getBlog = await model.blog.findOne({
      where: {
        status: "active",
        uuid: blogUuId,
      },
      attributes: ["uuid", "blog_title", "slug_name", "blog_short_description", "blog_description"],
      include: [
        {
          attributes: [
            [fn("REPLACE", col("blogImages.file_path"), `public/uploads/`, `public/`), "file_path"],
          ],
          model: model.blogImage,
          where: { status: "active" },
          required: false,
        },
      ],
    });
    if (getBlog) {
      getBlog.dataValues.blog_images =
        getBlog.dataValues.blogImages.length > 0 ? getBlog.dataValues.blogImages : [];
      delete getBlog.dataValues.blogImages;
      res.ok(getBlog);
    } else {
      throw StatusError.notFound(res.__("data not found"));
    }
  } catch (error) {
    next(error);
  }
};
