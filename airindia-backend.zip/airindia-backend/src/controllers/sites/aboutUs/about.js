import model from "../../../models/index.js";
import { StatusError, envs } from "../../../config/index.js";
import { Op, fn, col } from "sequelize";

/**
 *get about page details
 * @param req
 * @param res
 * @param next
 */
export const about = async (req, res, next) => {
  try {
    const keyName = "about_us.";
    let getInfo = await model.sitePage.findAll({
      where: {
        page_name: "about_us",
        key_name: { [Op.like]: `%${keyName}%` },
        status: "active",
      },
      attributes: ["key_name", "page_value"],
    });
    let data = {};
    if (getInfo && getInfo.length > 0) {
      for (const row of getInfo) {
        let pVa = row.page_value ? JSON.parse(row.page_value) : "";

        if (row.key_name == "about_us.banner") {
          if (pVa && pVa.file_path) {
            pVa.file_path = pVa.file_path.replace(`public/uploads/`, `public/`);
          }
        }
        if (row.key_name == "about_us.about_text") {
          if (pVa && pVa.file_path) {
            pVa.file_path = pVa.file_path.replace(`public/uploads/`, `public/`);
          }
        }
        if (row.key_name == "about_us.main_content") {
          if (pVa && pVa.file_path) {
            pVa.file_path = pVa.file_path.replace(`public/uploads/`, `public/`);
          }
          if (pVa && pVa.file_path_1) {
            pVa.file_path_1 = pVa.file_path_1.replace(`public/uploads/`, `public/`);
          }
        }
        if (row.key_name == "about_us.career_cta") {
          if (pVa && pVa.files && pVa.files.length) {
            pVa.files = pVa.files.map((record) => {
              record.file_path = record.file_path.replace(`public/uploads/`, `public/`);
              return record;
            });
          }
        }
        data[row.key_name.replace(keyName, "")] = pVa;
      }
    }
    // news section
    if (data?.news_event && data?.news_event?.length > 0) {
      let getNews = await model.news.findAll({
        where: {
          status: "active",
          id: { [Op.in]: data?.news_event },
        },
        attributes: [
          "uuid",
          ["title", "news_title"],
          "slug_name",
          ["short_description", "news_short_description"],
          "website_link",
          ["published_at", "news_date"],
        ],
        include: [
          {
            attributes: [
              [
                fn("REPLACE", col("newsImages.file_path"), `public/uploads/`, `public/`),
                "file_path",
              ],
            ],
            model: model.newsImage,
            where: { status: "active" },
            required: false,
          },
        ],
        //order: [["id", "desc"]],
        limit: 3,
      });
      if (getNews && getNews.length > 0) {
        getNews = getNews.map((record) => {
          record.dataValues.news_images =
            record.dataValues.newsImages.length > 0 ? record.dataValues.newsImages : [];
          delete record.dataValues.newsImages;
          return record;
        });
        data.news = getNews;
      }
    } else {
      data.news = [];
    }

    //partner
    if (data?.partner_text) {
      const assignPartner =
        data?.partner_text?.partner_list && data?.partner_text?.partner_list.length > 0
          ? data?.partner_text?.partner_list
          : [];
      if (assignPartner && assignPartner.length > 0) {
        let getPartner = await model.client.findAll({
          where: {
            status: "active",
            id: { [Op.in]: assignPartner },
          },
          attributes: [
            "id",
            "uuid",
            "client_name",
            "company_name",
            "slug_name",
            [fn("REPLACE", col("file_path"), `public/uploads/`, `public/`), "file_path"],
          ],
          order: [["id", "desc"]],
          limit: 4,
        });
        delete data?.partner_text?.partner_list;
        data.partner = { ...data.partner_text, list: getPartner ? getPartner : [] };
      }
    } else {
      data.partner = {};
    }

    delete data?.news_event;
    delete data?.partner_text;
    delete data?.partner_text?.partner_list;
    if (data) {
      res.ok(data);
    } else {
      throw StatusError.notFound(res.__("data not found"));
    }
  } catch (error) {
    console.log(error);
    next(error);
  }
};
