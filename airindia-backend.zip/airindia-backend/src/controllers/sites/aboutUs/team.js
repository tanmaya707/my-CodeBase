import model from "../../../models/index.js";
import { StatusError } from "../../../config/index.js";
import { fn, col } from "sequelize";
import { generalHelper } from "../../../helpers/index.js";

/**
 *get team for about page details
 * @param req
 * @param res
 * @param next
 */
export const team = async (req, res, next) => {
  try {
    let teams = await model.team.findAll({
      where: {
        status: "active",
      },
      attributes: [
        "id",
        "uuid",
        "member_name",
        "designation",
        "description",
        "slug_name",
        "facebook_link",
        "linkedin_link",
        "twitter_link",
        [fn("REPLACE", col("file_path"), `public/uploads/`, `public/`), "file_path"],
      ],
    });
    if (teams && teams.length > 0) {
      teams = teams.map((item) => {
        item.dataValues.description = !item.dataValues.description
          ? ""
          : generalHelper.stripHtmlAndLimit(item.dataValues.description);
        return item;
      });
      res.ok({ results: teams });
    } else {
      throw StatusError.notFound(res.__("data not found"));
    }
  } catch (error) {
    console.log(error);
    next(error);
  }
};
