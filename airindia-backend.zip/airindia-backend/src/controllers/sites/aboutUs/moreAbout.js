import model from "../../../models/index.js";
import { StatusError, envs } from "../../../config/index.js";
import { Op, fn, col } from "sequelize";

/**
 *get more about page details
 * @param req
 * @param res
 * @param next
 */
export const moreAbout = async (req, res, next) => {
  try {
    const keyName = "more_about_us.";
    let getInfo = await model.sitePage.findAll({
      where: {
        page_name: "more_about_us",
        key_name: { [Op.like]: `%${keyName}%` },
        status: "active",
      },
      attributes: ["key_name", "page_value"],
    });
    let data = {};
    if (getInfo && getInfo.length > 0) {
      for (const row of getInfo) {
        let pVa = row.page_value ? JSON.parse(row.page_value) : "";
        if (row.key_name == "more_about_us.banner") {
          if (pVa && pVa.file_path) {
            pVa.file_path = pVa.file_path.replace(`public/uploads/`, `public/`);
          }
        }
        if (row.key_name == "more_about_us.about_text") {
          if (pVa && pVa.file_path) {
            pVa.file_path = pVa.file_path.replace(`public/uploads/`, `public/`);
          }
          if (pVa && pVa.file_path_1) {
            pVa.file_path_1 = pVa.file_path_1.replace(`public/uploads/`, `public/`);
          }
        }
        if (row.key_name == "more_about_us.certificate") {
          if (pVa && pVa.file_path) {
            pVa.file_path = pVa.file_path.replace(`public/uploads/`, `public/`);
          }
        }
        data[row.key_name.replace(keyName, "")] = pVa;
      }
    }
    if (data) {
      delete data.our_reviews;
      delete data.clients;
      res.ok(data);
    } else {
      throw StatusError.notFound(res.__("data not found"));
    }
  } catch (error) {
    console.log(error);
    next(error);
  }
};
