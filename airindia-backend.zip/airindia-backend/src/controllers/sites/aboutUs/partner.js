import model from "../../../models/index.js";
import { StatusError, envs } from "../../../config/index.js";
import { Op, fn, col } from "sequelize";

/**
 *get partner for about page details
 * @param req
 * @param res
 * @param next
 */
export const partner = async (req, res, next) => {
  try {
    const getSetPartner = await model.sitePage.findOne({
      where: {
        key_name: "about_us.partner_text",
        status: "active",
      },
      attributes: ["page_value"],
    });
    let getPartnerTxt = {};
    let partners = [];
    if (getSetPartner && JSON.parse(getSetPartner.page_value)) {
      const getPartner = JSON.parse(getSetPartner.page_value);
      getPartnerTxt =
        getPartner && getPartner.display_text
          ? { display_text: getPartner.display_text }
          : { display_text: "" };
      if (getPartner.partner_list && getPartner.partner_list.length > 0) {
        partners = await model.client.findAll({
          where: {
            status: "active",
            id: { [Op.in]: getPartner.partner_list },
          },
          attributes: [
            "id",
            "uuid",
            "client_name",
            "company_name",
            "slug_name",
            [fn("REPLACE", col("file_path"), `public/uploads/`, `public/`), "file_path"],
          ],
        });
        // partners = await model.partner.findAll({
        //   where: {
        //     status: "active",
        //     id: { [Op.in]: getPartner.partner_list },
        //   },
        //   attributes: [
        //     "id",
        //     "uuid",
        //     "partner_name",
        //     "slug_name",
        //     [fn("REPLACE", col("file_path"), `public/uploads/`, `public/`), "file_path"],
        //   ],
        // });
      }
    }

    if (partners && partners.length > 0) {
      res.ok({ ...getPartnerTxt, results: partners });
    } else {
      throw StatusError.notFound(res.__("data not found"));
    }
  } catch (error) {
    console.log(error);
    next(error);
  }
};
