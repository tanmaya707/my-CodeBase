import model from "../../../models/index.js";
import { StatusError, envs } from "../../../config/index.js";
import { Op, fn, col } from "sequelize";

/**
 *get clientReview for more about page details
 * @param req
 * @param res
 * @param next
 */
export const clientReview = async (req, res, next) => {
  try {
    const getSetReview = await model.sitePage.findOne({
      where: {
        key_name: "more_about_us.our_reviews",
        status: "active",
      },
      attributes: ["page_value"],
    });
    let clientReview = [];
    if (getSetReview && JSON.parse(getSetReview.page_value)) {
      const getReview = JSON.parse(getSetReview.page_value);
      if (getReview && getReview.length > 0) {
        clientReview = await model.client.findAll({
          where: {
            status: "active",
            id: { [Op.in]: getReview },
          },
          attributes: [
            "id",
            "uuid",
            "client_name",
            "company_name",
            "designation",
            "slug_name",
            "description",
            "client_feedback",
            [fn("REPLACE", col("file_path"), `public/uploads/`, `public/`), "file_path"],
          ],
        });
      }
    }
    if (clientReview && clientReview.length > 0) {
      res.ok({ results: clientReview });
    } else {
      throw StatusError.notFound(res.__("data not found"));
    }
  } catch (error) {
    console.log(error);
    next(error);
  }
};
