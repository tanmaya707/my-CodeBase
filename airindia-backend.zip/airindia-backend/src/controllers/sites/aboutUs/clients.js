import model from "../../../models/index.js";
import { StatusError, envs } from "../../../config/index.js";
import { Op, fn, col } from "sequelize";

/**
 *get clients for more about page details
 * @param req
 * @param res
 * @param next
 */
export const clients = async (req, res, next) => {
  try {
    const getSetClient = await model.sitePage.findOne({
      where: {
        key_name: "more_about_us.clients",
        status: "active",
      },
      attributes: ["page_value"],
    });
    let clients = [];
    if (getSetClient && JSON.parse(getSetClient.page_value)) {
      const getClient = JSON.parse(getSetClient.page_value);
      if (getClient && getClient.length > 0) {
        clients = await model.client.findAll({
          where: {
            status: "active",
            id: { [Op.in]: getClient },
          },
          attributes: [
            "uuid",
            "client_name",
            "company_name",
            "slug_name",
            [fn("REPLACE", col("file_path"), `public/uploads/`, `public/`), "file_path"],
          ],
        });
      }
    }

    if (clients && clients.length > 0) {
      res.ok({ results: clients });
    } else {
      throw StatusError.notFound(res.__("data not found"));
    }
  } catch (error) {
    console.log(error);
    next(error);
  }
};
