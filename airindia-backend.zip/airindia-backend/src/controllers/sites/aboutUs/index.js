import { about } from "./about.js";
import { team } from "./team.js";
import { partner } from "./partner.js";
import { moreAbout } from "./moreAbout.js";
import { clients } from "./clients.js";
import { clientReview } from "./clientReview.js";

export { about, team, partner, moreAbout, clients, clientReview };
