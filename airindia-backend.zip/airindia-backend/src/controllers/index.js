import * as adminController from "./admin/index.js";
import * as siteController from "./sites/index.js";

export { siteController, adminController };
