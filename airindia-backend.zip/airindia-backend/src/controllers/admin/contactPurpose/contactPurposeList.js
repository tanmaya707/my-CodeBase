import model from "../../../models/index.js";
import { PAGINATION_LIMIT } from "../../../utils/constants.js";
import { paginationService } from "../../../services/index.js";
import { Sequelize, Op } from "sequelize";

/**
 * contactPurposeList
 * @param req
 * @param res
 */
export const contactPurposeList = async (req, res, next) => {
  try {
    const loginUserId = req.userDetails.userId;
    if (!loginUserId) throw StatusError.badRequest(res.__("Invalid user id"));
    const reqBody = req.query;
    const searchName = reqBody.name ? reqBody.name.trim() : "";
    let resultData = [];
    const defautlPageNo = 1;
    const page = reqBody.page ? reqBody.page : defautlPageNo;
    const limit = reqBody.limit ? reqBody.limit : PAGINATION_LIMIT;

    const sortOrder = reqBody.sort_order ? reqBody.sort_order : "desc";
    const sortBy = reqBody.sort_by ? reqBody.sort_by : "";

    const searchParams = {
      page: page,
      limit: limit,
    };

    let condition = {};
    const attributes = ["id", "uuid", "name", "status", "created_at"];
    searchParams.sortOrderObj = [[Sequelize.literal("created_at"), sortOrder]];
    const includeQuery = [];
    if (searchName) {
      const arrName = searchName.split(" ");
      let orArr = [{ name: { [Op.like]: `%${searchName}%` } }];
      if (arrName.length > 1) {
        arrName.map((name) => {
          if (name) {
            orArr.push({ name: { [Op.like]: `%${name}%` } });
          }
        });
      }
      condition[Op.or] = orArr;
    }

    resultData = await paginationService.pagination(
      searchParams,
      model.contactPurpose,
      includeQuery,
      condition,
      attributes,
    );
    res.ok({
      page: page,
      limit: limit,
      total_records: resultData.count,
      total_pages: resultData.count > 0 ? Math.ceil(resultData.count / limit) : 0,
      results: resultData.rows,
    });
  } catch (error) {
    console.log(error);
    next(error);
  }
};
