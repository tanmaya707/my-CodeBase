import { contactPurposeDetails } from "./contactPurposeDetails.js";
import { deleteContactPurpose } from "./deleteContactPurpose.js";
import { addContactPurpose } from "./addContactPurpose.js";
import { editContactPurpose } from "./editContactPurpose.js";
import { contactPurposeList } from "./contactPurposeList.js";

export {
  contactPurposeDetails,
  deleteContactPurpose,
  addContactPurpose,
  editContactPurpose,
  contactPurposeList,
};
