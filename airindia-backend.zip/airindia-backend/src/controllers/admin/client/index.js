import { addClient } from "./addClient.js";
import { clientList } from "./clientList.js";
import { editClient } from "./editClient.js";
import { deleteClient } from "./deleteClient.js";
import { clientDetails } from "./clientDetails.js";

export { addClient, clientList, editClient, deleteClient, clientDetails };
