import model from "../../../models/index.js";
import { StatusError } from "../../../config/index.js";
import {
  contentModificationService,
  notificationService,
  userPermissionService,
} from "../../../services/index.js";

/**
 * deleteClient
 * @param req
 * @param res
 */
export const deleteClient = async (req, res, next) => {
  try {
    const reqBody = req.body;
    const loginUserId = req.userDetails.userId;
    if (!loginUserId) {
          throw StatusError.badRequest(res.__("Invalid user id"));
    }
    const delId = reqBody.id ? reqBody.id : "";
    if (!delId) throw StatusError.badRequest(res.__("Invalid id"));

    const userRole = req.userDetails.user_type ?? "";
    const roleId = req.userDetails.user_role_id ?? "";
    if (!userRole) {
      throw StatusError.badRequest(res.__("Invalid user role"));
    }

    const checkId = await model.client.count({
      where: { id: delId },
    });
    if (checkId == 0) throw StatusError.badRequest(res.__("Invalid id"));
    let desRes;
    let sucMess = "success";
    if (userRole == "superadmin" || userRole == "administrator" || userRole == "approver") {
      const check = await userPermissionService.checkUserPermission(roleId, loginUserId, [
        "clientele.delete",
      ]);
      if (check) {
        desRes = await model.client.destroy({
          where: { id: delId },
        });
      } else {
        desRes = 0;
      }
    } else {
      const checkForPendingRequest = await contentModificationService.checkForPendingRequest({
        id: delId,
        request_for: "clients",
        action_type: "delete",
      });
      if (checkForPendingRequest) {
        throw StatusError.badRequest(
          res.__(
            "A modification request is already in progress. Please wait for the approval response and try again later.",
          ),
        );
      } else {
        const detail = await model.client.findOne({ where: { id: delId } });
        detail.client_id = detail.id;
        delete detail.id;
        const insRes = await model.tempClient.create(detail);
        if (insRes && insRes.id > 0) {
          desRes = 1;
          sucMess = "Your delete request has been save successfully. Please wait for approval!";
          await contentModificationService.addRequest({
            temp_id: insRes.id,
            request_for: "clients",
            action_type: "delete",
            created_at: detail.created_at,
            created_by: detail.created_by,
          });
          await notificationService.generateNotificationForContentApproval(
            {
              created_by: loginUserId,
              notification_type: "content_approval",
              type: "update",
              title: `A clientele delete requested`,
              item_id: detail.id,
              item_description: `A clientele "${detail.clientele_name}" delete requested by publisher`,
              item: detail,
            },
            null,
            ["clientele.status_change"],
          );
        }
      }
    }
    if (desRes > 0) {
      res.ok({
        message: res.__(sucMess),
      });
    } else {
      throw StatusError.badRequest(res.__("SomeThingWentWrong"));
    }
  } catch (error) {
    console.log(error);
    next(error);
  }
};
