import model from "../../../models/index.js";
import { customDateTimeHelper, customFileHelper, generalHelper } from "../../../helpers/index.js";
import { StatusError, envs } from "../../../config/index.js";
import { v4 as uuidv4 } from "uuid";
import fs from "fs";
import {
  contentModificationService,
  notificationService,
  userPermissionService,
} from "../../../services/index.js";

/**
 * addClient
 * @param req
 * @param res
 */
export const addClient = async (req, res, next) => {
  try {
    const reqBody = req.body;
    const loginUserId = req.userDetails.userId;
    if (!loginUserId) {
      if (req.file && req.file.path) customFileHelper.customFileUnlink(fs, req.file.path);
      throw StatusError.badRequest(res.__("Invalid user id"));
    }

    const userRole = req.userDetails.user_type ?? "";
    const roleId = req.userDetails.user_role_id ?? "";
    if (!userRole) {
      if (req.file && req.file.path) customFileHelper.customFileUnlink(fs, req.file.path);
      throw StatusError.badRequest(res.__("Invalid user role"));
    }

    const totalRecord = await model.client.max("list_order");

    const whl = true;
    let slugName = "";
    let rslug = reqBody.client_name;
    let regenarate = false;
    while (whl) {
      const generatedSlug = await generalHelper.generateSlugName(rslug, regenarate);
      // check for slug name existance in tag category table
      const isExists = await model.client.findOne({
        where: { slug_name: generatedSlug },
        attributes: ["id", "slug_name"],
      });
      if (!isExists) {
        regenarate = false;
        slugName = generatedSlug;
        break;
      } else {
        regenarate = true;
        rslug = generatedSlug;
      }
    }

    let listOrder = (totalRecord ?? 0) + 1;

    let fileLocation = "";
    let fileName = "";
    if (req.file) {
      const fileDetails = req.file;
      fileName = fileDetails.filename ? fileDetails.filename : "";
      fileLocation = fileDetails.destination ? fileDetails.destination + "/" + fileName : "";
    }

    // add details
    const inputDetails = {
      uuid: uuidv4(),
      client_name: reqBody.client_name ?? null,
      company_name: reqBody.company_name ?? null,
      designation: reqBody.designation ?? null,
      description: reqBody.description ?? null,
      client_feedback: reqBody.client_feedback ?? null,
      file_path: fileLocation,
      list_order: listOrder,
      slug_name: slugName,
      status: reqBody.status,
      created_at: await customDateTimeHelper.getCurrentDateTime(),
      created_by: loginUserId,
    };
    let insRes;
    let sucMess = "success";
    if (userRole == "superadmin" || userRole == "administrator" || userRole == "approver") {
      const check = await userPermissionService.checkUserPermission(roleId, loginUserId, [
        "clientele.add",
      ]);
      if (check) {
        insRes = await model.client.create(inputDetails);
      } else {
        insRes = null;
      }
    } else {
      insRes = await model.tempClient.create(inputDetails);
      if (insRes && insRes.id > 0) {
        sucMess = "Your addition request has been save successfully. Please wait for approval!";
        await contentModificationService.addRequest({
          temp_id: insRes.id,
          request_for: "clients",
          action_type: "add",
          created_at: inputDetails.created_at,
          created_by: inputDetails.created_by,
        });
        await notificationService.generateNotificationForContentApproval(
          {
            created_by: loginUserId,
            notification_type: "content_approval",
            type: "update",
            title: `A new clientele addition requested`,
            item_id: insRes.id,
            item_description: `A new clientele "${inputDetails.client_name}" addition requested by publisher`,
            item: inputDetails,
          },
          null,
          ["clientele.status_change"],
        );
      }
    }

    if (insRes && insRes.id > 0) {
      res.ok({
        message: res.__(sucMess),
      });
    } else {
      if (req.file && req.file.path) customFileHelper.customFileUnlink(fs, req.file.path);
      throw StatusError.badRequest(res.__("SomeThingWentWrong"));
    }
  } catch (error) {
    console.log(error);
    if (req.file && req.file.path) customFileHelper.customFileUnlink(fs, req.file.path);
    next(error);
  }
};
