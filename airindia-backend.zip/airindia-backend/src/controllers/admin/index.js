import * as authController from "./auth/index.js";
import * as user from "./user/index.js";
import * as setting from "./setting/index.js";
import * as menuController from "./menu/index.js";
import * as serviceController from "./service/index.js";
import * as certificateController from "./certificate/index.js";
import * as dashboardController from "./dashboard/index.js";
import * as newsController from "./news/index.js";
import * as cmsController from "./cms/index.js";
import * as myProfileController from "./myProfile/index.js";
import * as faqController from "./faq/index.js";
import * as faqCategoryController from "./faqCategory/index.js";
import * as homeController from "./home/index.js";
import * as awardController from "./award/index.js";
import * as blogController from "./blog/index.js";
import * as inquiryController from "./inquiry/index.js";
import * as clientController from "./client/index.js";
import * as tenderController from "./tender/index.js";
import * as galleryController from "./gallery/index.js";
import * as aboutController from "./about/index.js";
import * as teamController from "./team/index.js";
import * as contactPurposeController from "./contactPurpose/index.js";
import * as careerController from "./career/index.js";
import * as pageContentController from "./pageContent/index.js";
import * as roleController from "./role/index.js";
import * as rolePermissionController from "./rolePermission/index.js";
import * as customPageController from "./customPage/index.js";
import * as credentialCategoryController from "./credentialCategory/index.js";
import * as credentialController from "./credential/index.js";
import * as notificationController from "./notification/index.js";
import * as contentApprovalController from "./contentApproval/index.js";
import * as activityLogController from "./activityLog/index.js";

export {
  authController,
  user,
  setting,
  menuController,
  serviceController,
  certificateController,
  dashboardController,
  newsController,
  cmsController,
  myProfileController,
  faqController,
  faqCategoryController,
  homeController,
  awardController,
  blogController,
  inquiryController,
  clientController,
  tenderController,
  galleryController,
  aboutController,
  teamController,
  contactPurposeController,
  careerController,
  pageContentController,
  roleController,
  rolePermissionController,
  customPageController,
  credentialCategoryController,
  credentialController,
  notificationController,
  contentApprovalController,
  activityLogController,
};
