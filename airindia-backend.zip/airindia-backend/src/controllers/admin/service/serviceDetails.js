import model from "../../../models/index.js";
import { Op, col, fn } from "sequelize";
import { StatusError, envs } from "../../../config/index.js";

/**
 * serviceDetails
 * @param req
 * @param res
 */
export const serviceDetails = async (req, res, next) => {
  try {
    const reqBody = req.params;
    const id = reqBody.id ? reqBody.id : "";
    if (!id) throw StatusError.badRequest(res.__("Invalid id"));

    const checkServiceId = await model.service.count({
      where: { id: id },
    });
    if (checkServiceId == 0) throw StatusError.badRequest(res.__("Invalid id"));

    let resultData = {};
    const condition = { id: id };
    const attributes = [
      "id",
      "uuid",
      "name",
      "description",
      "caption_text",
      [fn("REPLACE", col("file_path"), `public/uploads/`, `public/`), "file_path"],
      [fn("REPLACE", col("detail_file_path"), `public/uploads/`, `public/`), "detail_file_path"],
      "why_caption",
      "why_introduction",
      "why_description",
      "why_reason_list",
      [fn("REPLACE", col("why_file_path"), `public/uploads/`, `public/`), "why_file_path"],
      "status",
      "list_order",
      "created_at",
    ];

    const includeQuery = [];

    resultData = await model.service.findOne({
      attributes: attributes,
      include: includeQuery,
      where: condition,
    });
    if (resultData?.dataValues?.why_reason_list) {
      resultData.dataValues.why_reason_list = JSON.parse(resultData.dataValues.why_reason_list);
    }
    res.ok(resultData ? resultData : {});
  } catch (error) {
    next(error);
  }
};
