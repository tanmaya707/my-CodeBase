import model from "../../../models/index.js";
import { customDateTimeHelper, customFileHelper, generalHelper } from "../../../helpers/index.js";
import { StatusError } from "../../../config/index.js";
import fs from "fs";
import {
  contentModificationService,
  notificationService,
  userPermissionService,
} from "../../../services/index.js";

/**
 * editService
 * @param req
 * @param res
 */
export const editService = async (req, res, next) => {
  try {
    const reqBody = req.body;
    const loginUserId = req.userDetails.userId;
    const id = reqBody.id ? reqBody.id : "";
    let isdFileDeleted = reqBody.is_fdel_d ? reqBody.is_fdel_d : "";
    isdFileDeleted = isdFileDeleted == "" ? "n" : isdFileDeleted;

    let iswFileDeleted = reqBody.is_fdel_w ? reqBody.is_fdel_w : "";
    iswFileDeleted = iswFileDeleted == "" ? "n" : iswFileDeleted;

    const userRole = req.userDetails.user_type ?? "";
    const roleId = req.userDetails.user_role_id ?? "";
    if (!userRole) {
      if (req.files && req.files.file && req.files.file.length > 0 && req.files.file[0].path)
        customFileHelper.customFileUnlink(fs, req.files.file[0].path);
      if (
        req.files &&
        req.files.detail_file &&
        req.files.detail_file.length > 0 &&
        req.files.detail_file[0].path
      )
        customFileHelper.customFileUnlink(fs, req.files.detail_file[0].path);
      if (
        req.files &&
        req.files.why_file &&
        req.files.why_file.length > 0 &&
        req.files.why_file[0].path
      )
        customFileHelper.customFileUnlink(fs, req.files.why_file[0].path);
      throw StatusError.badRequest(res.__("Invalid user role"));
    }

    // check for service id existance in table
    const isExistsService = await model.service.findOne({
      //attributes: ["id", "name", "created_by", "file_path"],
      where: {
        id: id,
      },
    });
    if (!isExistsService) {
      if (req.files && req.files.file && req.files.file.length > 0 && req.files.file[0].path)
        customFileHelper.customFileUnlink(fs, req.files.file[0].path);
      if (
        req.files &&
        req.files.detail_file &&
        req.files.detail_file.length > 0 &&
        req.files.detail_file[0].path
      )
        customFileHelper.customFileUnlink(fs, req.files.detail_file[0].path);
      if (
        req.files &&
        req.files.why_file &&
        req.files.why_file.length > 0 &&
        req.files.why_file[0].path
      )
        customFileHelper.customFileUnlink(fs, req.files.why_file[0].path);
      throw StatusError.badRequest(res.__("Invalid id"));
    }

    const whl = true;
    let slugName = "";
    let rslug = reqBody.name;
    let regenarate = false;
    if (isExistsService.name != rslug) {
      while (whl) {
        const generatedSlug = await generalHelper.generateSlugName(rslug, regenarate);
        // check for slug name existance in award table
        const isExists = await model.service.findOne({
          where: { slug_name: generatedSlug },
          attributes: ["id", "slug_name"],
        });
        if (!isExists) {
          regenarate = false;
          slugName = generatedSlug;
          break;
        } else {
          regenarate = true;
          rslug = generatedSlug;
        }
      }
    } else {
      slugName = isExistsService.slug_name;
    }

    let fileLocation = "";
    let fileName = "";
    if (req.files && req.files.file && req.files.file.length > 0) {
      const fileDetails = req.files.file[0];
      fileName = fileDetails.filename ? fileDetails.filename : "";
      fileLocation = fileDetails.destination ? fileDetails.destination + "/" + fileName : "";
    }

    let dfileLocation = "";
    let dfileName = "";
    if (req.files && req.files.detail_file && req.files.detail_file.length > 0) {
      const fileDetails = req.files.detail_file[0];
      dfileName = fileDetails.filename ? fileDetails.filename : "";
      dfileLocation = fileDetails.destination ? fileDetails.destination + "/" + dfileName : "";
    }

    let wfileLocation = "";
    let wfileName = "";
    if (req.files && req.files.why_file && req.files.why_file.length > 0) {
      const fileDetails = req.files.why_file[0];
      wfileName = fileDetails.filename ? fileDetails.filename : "";
      wfileLocation = fileDetails.destination ? fileDetails.destination + "/" + wfileName : "";
    }

    let fpath = fileLocation ? fileLocation : isExistsService?.file_path;

    let fpathd = dfileLocation ? dfileLocation : isExistsService?.detail_file_path;
    if (isdFileDeleted == "y") {
      fpathd = "";
    }

    let fpathw = wfileLocation ? wfileLocation : isExistsService?.why_file_path;
    if (iswFileDeleted == "y") {
      fpathw = "";
    }

    let requestDetails = {
      name: reqBody.name ?? null,
      slug_name: slugName,
      file_path: fpath,
      description: reqBody.description ?? null,
      caption_text: reqBody.caption_text ?? null,
      detail_file_path: fpathd,
      why_caption: reqBody.why_caption ?? null,
      why_introduction: reqBody.why_introduction ?? null,
      why_description: reqBody.why_description ?? null,
      // why_reason_list: !reqBody.why_reason_list ? null : JSON.stringify(reqBody.why_reason_list),
      why_reason_list: !reqBody.why_reason_list ? null : reqBody.why_reason_list,
      why_file_path: fpathw,
      status: reqBody.status,
      updated_at: await customDateTimeHelper.getCurrentDateTime(),
      updated_by: loginUserId,
    };
    let updt = 0;
    let sucMess = "success";
    if (userRole == "superadmin" || userRole == "administrator" || userRole == "approver") {
      const check = await userPermissionService.checkUserPermission(roleId, loginUserId, [
        "service.edit",
      ]);
      if (check) {
        requestDetails.updated_at = await customDateTimeHelper.getCurrentDateTime();
        requestDetails.updated_by = loginUserId;
        const [upResp] = await model.service.update(requestDetails, {
          where: { id: id },
        });
        if (upResp > 0) {
          updt = 1;
        }
      }
    } else {
      const checkForPendingRequest = await contentModificationService.checkForPendingRequest({
        id: id,
        request_for: "services",
        action_type: "edit",
      });
      if (checkForPendingRequest) {
        if (req.files && req.files.file && req.files.file.length > 0 && req.files.file[0].path)
          customFileHelper.customFileUnlink(fs, req.files.file[0].path);
        if (
          req.files &&
          req.files.detail_file &&
          req.files.detail_file.length > 0 &&
          req.files.detail_file[0].path
        )
          customFileHelper.customFileUnlink(fs, req.files.detail_file[0].path);
        if (
          req.files &&
          req.files.why_file &&
          req.files.why_file.length > 0 &&
          req.files.why_file[0].path
        )
          customFileHelper.customFileUnlink(fs, req.files.why_file[0].path);
        throw StatusError.badRequest(
          res.__(
            "A modification request is already in progress. Please wait for the approval response and try again later.",
          ),
        );
      } else {
        requestDetails.service_id = id;
        requestDetails.earlier_data = isExistsService ? JSON.stringify(isExistsService) : null;
        requestDetails.uuid = isExistsService.uuid;
        requestDetails.list_order = isExistsService.list_order;
        requestDetails.created_at = requestDetails.updated_at;
        requestDetails.created_by = requestDetails.updated_by;
        const insRes = await model.tempService.create(requestDetails);

        if (insRes && insRes.id > 0) {
          sucMess =
            "Your modification request has been save successfully. Please wait for approval!";
          await contentModificationService.addRequest({
            temp_id: insRes.id,
            request_for: "services",
            action_type: "edit",
            created_at: requestDetails.updated_at,
            created_by: requestDetails.updated_by,
          });
          await notificationService.generateNotificationForContentApproval(
            {
              created_by: loginUserId,
              notification_type: "content_approval",
              type: "update",
              title: `A service modification requested`,
              item_id: insRes.id,
              item_description: `A service "${insRes.name}" modification requested by publisher`,
              item: insRes,
            },
            null,
            ["service.status_change"],
          );
          updt = 1;
        }
      }
    }
    if (updt > 0) {
      // if (req.file && req.file.path && isExistsService.file_path) {
      //   customFileHelper.customFileUnlink(fs, isExistsService.file_path);
      // }
      res.ok({
        message: res.__(sucMess),
      });
    } else {
      if (req.files && req.files.file && req.files.file.length > 0 && req.files.file[0].path)
        customFileHelper.customFileUnlink(fs, req.files.file[0].path);
      if (
        req.files &&
        req.files.detail_file &&
        req.files.detail_file.length > 0 &&
        req.files.detail_file[0].path
      )
        customFileHelper.customFileUnlink(fs, req.files.detail_file[0].path);
      if (
        req.files &&
        req.files.why_file &&
        req.files.why_file.length > 0 &&
        req.files.why_file[0].path
      )
        customFileHelper.customFileUnlink(fs, req.files.why_file[0].path);
      throw StatusError.badRequest(res.__("SomeThingWentWrong"));
    }
  } catch (error) {
    console.log(error);
    if (req.files && req.files.file && req.files.file.length > 0 && req.files.file[0].path)
      customFileHelper.customFileUnlink(fs, req.files.file[0].path);
    if (
      req.files &&
      req.files.detail_file &&
      req.files.detail_file.length > 0 &&
      req.files.detail_file[0].path
    )
      customFileHelper.customFileUnlink(fs, req.files.detail_file[0].path);
    if (
      req.files &&
      req.files.why_file &&
      req.files.why_file.length > 0 &&
      req.files.why_file[0].path
    )
      customFileHelper.customFileUnlink(fs, req.files.why_file[0].path);
    next(error);
  }
};
