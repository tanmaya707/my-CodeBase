import { addService } from "./addService.js";
import { serviceList } from "./serviceList.js";
import { editService } from "./editService.js";
import { deleteService } from "./deleteService.js";
import { serviceDetails } from "./serviceDetails.js";

export { addService, serviceList, editService, deleteService, serviceDetails };
