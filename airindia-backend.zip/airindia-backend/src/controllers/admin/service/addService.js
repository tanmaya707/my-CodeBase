import model from "../../../models/index.js";
import { customDateTimeHelper, customFileHelper, generalHelper } from "../../../helpers/index.js";
import { StatusError, envs } from "../../../config/index.js";
import { v4 as uuidv4 } from "uuid";
import fs from "fs";
import {
  contentModificationService,
  notificationService,
  userPermissionService,
} from "../../../services/index.js";

/**
 * addService
 * @param req
 * @param res
 */
export const addService = async (req, res, next) => {
  try {
    const reqBody = req.body;
    const loginUserId = req.userDetails.userId;
    if (!loginUserId) {
      if (req.files && req.files.file && req.files.file.length > 0 && req.files.file[0].path)
        customFileHelper.customFileUnlink(fs, req.files.file[0].path);
      if (
        req.files &&
        req.files.detail_file &&
        req.files.detail_file.length > 0 &&
        req.files.detail_file[0].path
      )
        customFileHelper.customFileUnlink(fs, req.files.detail_file[0].path);
      if (
        req.files &&
        req.files.why_file &&
        req.files.why_file.length > 0 &&
        req.files.why_file[0].path
      )
        customFileHelper.customFileUnlink(fs, req.files.why_file[0].path);
      throw StatusError.badRequest(res.__("Invalid user id"));
    }
    const userRole = req.userDetails.user_type ?? "";
    const roleId = req.userDetails.user_role_id ?? "";
    if (!userRole) {
      if (req.files && req.files.file && req.files.file.length > 0 && req.files.file[0].path)
        customFileHelper.customFileUnlink(fs, req.files.file[0].path);
      if (
        req.files &&
        req.files.detail_file &&
        req.files.detail_file.length > 0 &&
        req.files.detail_file[0].path
      )
        customFileHelper.customFileUnlink(fs, req.files.detail_file[0].path);
      if (
        req.files &&
        req.files.why_file &&
        req.files.why_file.length > 0 &&
        req.files.why_file[0].path
      )
        customFileHelper.customFileUnlink(fs, req.files.why_file[0].path);
      throw StatusError.badRequest(res.__("Invalid user role"));
    }

    const totalRecord = await model.service.max("list_order");
    const whl = true;
    let slugName = "";
    let rslug = reqBody.name;
    let regenarate = false;
    while (whl) {
      const generatedSlug = await generalHelper.generateSlugName(rslug, regenarate);
      // check for slug name existance in tag category table
      const isExists = await model.service.findOne({
        where: { slug_name: generatedSlug },
        attributes: ["id", "slug_name"],
      });
      if (!isExists) {
        regenarate = false;
        slugName = generatedSlug;
        break;
      } else {
        regenarate = true;
        rslug = generatedSlug;
      }
    }
    let listOrder = (totalRecord ?? 0) + 1;

    let fileLocation = "";
    let fileName = "";
    if (req.files && req.files.file && req.files.file.length > 0) {
      const fileDetails = req.files.file[0];
      fileName = fileDetails.filename ? fileDetails.filename : "";
      fileLocation = fileDetails.destination ? fileDetails.destination + "/" + fileName : "";
    }

    let dfileLocation = "";
    let dfileName = "";
    if (req.files && req.files.detail_file && req.files.detail_file.length > 0) {
      const fileDetails = req.files.detail_file[0];
      dfileName = fileDetails.filename ? fileDetails.filename : "";
      dfileLocation = fileDetails.destination ? fileDetails.destination + "/" + dfileName : "";
    }

    let wfileLocation = "";
    let wfileName = "";
    if (req.files && req.files.why_file && req.files.why_file.length > 0) {
      const fileDetails = req.files.why_file[0];
      wfileName = fileDetails.filename ? fileDetails.filename : "";
      wfileLocation = fileDetails.destination ? fileDetails.destination + "/" + wfileName : "";
    }

    // add details
    const inputDetails = {
      uuid: uuidv4(),
      name: reqBody.name ?? null,
      slug_name: slugName,
      description: reqBody.description ?? null,
      caption_text: reqBody.caption_text ?? null,
      file_path: fileLocation,
      list_order: listOrder,
      detail_file_path: dfileLocation,
      why_caption: reqBody.why_caption ?? null,
      why_introduction: reqBody.why_introduction ?? null,
      why_description: reqBody.why_description ?? null,
      //why_reason_list: !reqBody.why_reason_list ? null : JSON.stringify(reqBody.why_reason_list),
      why_reason_list: !reqBody.why_reason_list ? null : reqBody.why_reason_list,
      why_file_path: wfileLocation,
      status: reqBody.status,
      created_at: await customDateTimeHelper.getCurrentDateTime(),
      created_by: loginUserId,
    };
    let insRes;
    let sucMess = "success";
    if (userRole == "superadmin" || userRole == "administrator" || userRole == "approver") {
      const check = await userPermissionService.checkUserPermission(roleId, loginUserId, [
        "service.add",
      ]);
      if (check) {
        insRes = await model.service.create(inputDetails);
      } else {
        insRes = null;
      }
    } else {
      insRes = await model.tempService.create(inputDetails);
      if (insRes && insRes.id > 0) {
        sucMess = "Your addition request has been save successfully. Please wait for approval!";
        await contentModificationService.addRequest({
          temp_id: insRes.id,
          request_for: "services",
          action_type: "add",
          created_at: inputDetails.created_at,
          created_by: inputDetails.created_by,
        });
        await notificationService.generateNotificationForContentApproval(
          {
            created_by: loginUserId,
            notification_type: "content_approval",
            type: "update",
            title: `A new service addition requested`,
            item_id: insRes.id,
            item_description: `A new service "${inputDetails.name}" addition requested by publisher`,
            item: inputDetails,
          },
          null,
          ["service.status_change"],
        );
      }
    }
    if (insRes && insRes.id > 0) {
      res.ok({
        message: res.__(sucMess),
      });
    } else {
      if (req.files && req.files.file && req.files.file.length > 0 && req.files.file[0].path)
        customFileHelper.customFileUnlink(fs, req.files.file[0].path);
      if (
        req.files &&
        req.files.detail_file &&
        req.files.detail_file.length > 0 &&
        req.files.detail_file[0].path
      )
        customFileHelper.customFileUnlink(fs, req.files.detail_file[0].path);
      if (
        req.files &&
        req.files.why_file &&
        req.files.why_file.length > 0 &&
        req.files.why_file[0].path
      )
        customFileHelper.customFileUnlink(fs, req.files.why_file[0].path);
      throw StatusError.badRequest(res.__("SomeThingWentWrong"));
    }
  } catch (error) {
    console.log(error);
    if (req.files && req.files.file && req.files.file.length > 0 && req.files.file[0].path)
      customFileHelper.customFileUnlink(fs, req.files.file[0].path);
    if (
      req.files &&
      req.files.detail_file &&
      req.files.detail_file.length > 0 &&
      req.files.detail_file[0].path
    )
      customFileHelper.customFileUnlink(fs, req.files.detail_file[0].path);
    if (
      req.files &&
      req.files.why_file &&
      req.files.why_file.length > 0 &&
      req.files.why_file[0].path
    )
      customFileHelper.customFileUnlink(fs, req.files.why_file[0].path);
    next(error);
  }
};
