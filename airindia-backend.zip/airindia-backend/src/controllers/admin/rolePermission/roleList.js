import model from "../../../models/index.js";
import { Op } from "sequelize";

/**
 * roleList
 * @param req
 * @param res
 */
export const roleList = async (req, res, next) => {
  try {
    const reqBody = req.query;
    let condition = { status: "active", defaults: 0 };
    if (reqBody.search_name) {
      condition.role_display_name = { [Op.like]: `%${reqBody.search_name}%` };
    }
    const list = await model.role.findAll({
      attributes: ["id", ["role_display_name", "role_name"]],
      where: condition,
    });
    res.ok({
      results: list,
    });
  } catch (error) {
    next(error);
  }
};
