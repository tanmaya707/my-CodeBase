import model from "../../../models/index.js";
import { Op } from "sequelize";
import { StatusError } from "../../../config/index.js";
import { userRoleService } from "../../../services/index.js";
import { customDateTimeHelper } from "../../../helpers/index.js";

/**
 * editPermission
 * @param req
 * @param res
 */
export const editPermission = async (req, res, next) => {
  try {
    const reqBody = req.body;
    const roleId = reqBody.role_id;
    const roleUserId = reqBody.user_id;
    const loginUserId = req.userDetails.userId;
    if (!loginUserId) {
      throw StatusError.badRequest(res.__("Invalid user id"));
    }

    const permissions = reqBody.permissions ? reqBody.permissions : [];
    const getRole = await userRoleService.getRoleNameByRoleId(roleId);
    if (!getRole) throw StatusError.badRequest(res.__("Please provide a valid role"));
    const getUserRole = await model.userRole.findOne({
      attributes: ["id"],
      where: { role_id: roleId, user_id: roleUserId, status: "active" },
    });
    if (!getUserRole) throw StatusError.badRequest(res.__("Please provide a valid role & user"));
    const userRoleId = getUserRole && getUserRole.id ? getUserRole.id : "";
    let getRolePermissionIds = await model.rolePermission.findAll({
      attributes: ["id"],
      where: { user_role_id: userRoleId },
    });
    if (getRolePermissionIds && getRolePermissionIds.length > 0) {
      getRolePermissionIds = getRolePermissionIds.map((rolePermission) => rolePermission.id);
    }
    if (permissions && permissions.length > 0) {
      for (const eachPermission of permissions) {
        if (eachPermission) {
          const checkper = await model.permission.findOne({
            attributes: ["id"],
            where: { id: eachPermission.permission_id, status: "active" },
          });
          if (checkper) {
            let reqDetails = {
              user_role_id: userRoleId,
              permission_id: eachPermission.permission_id,
            };
            const finRolePer = await model.rolePermission.findOne({
              attributes: ["permission_id", "user_role_id", "id"],
              where: { user_role_id: userRoleId, permission_id: eachPermission.permission_id },
            });
            if (finRolePer) {
              reqDetails.updated_at = await customDateTimeHelper.getCurrentDateTime();
              reqDetails.updated_by = loginUserId;
              const [resInfo] = await model.rolePermission.update(reqDetails, {
                where: { id: finRolePer.id },
              });
              if (resInfo > 0) {
                getRolePermissionIds = getRolePermissionIds.filter((id) => id !== finRolePer.id);
              }
            } else {
              reqDetails.created_at = await customDateTimeHelper.getCurrentDateTime();
              reqDetails.created_by = loginUserId;
              await model.rolePermission.create(reqDetails);
            }
            if (getRolePermissionIds && getRolePermissionIds.length > 0) {
              await model.rolePermission.destroy({
                where: { id: { [Op.in]: getRolePermissionIds } },
              });
            }
          }
        }
      }
    }
    res.ok({
      message: res.__("success"),
    });
  } catch (error) {
    console.log(error);
    next(error);
  }
};
