import { permissionList } from "./permissionList.js";
import { roleList } from "./roleList.js";
import { editPermission } from "./editPermission.js";
import { checkPermission } from "./checkPermission.js";

export { permissionList, roleList, editPermission, checkPermission };
