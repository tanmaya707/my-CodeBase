import model from "../../../models/index.js";
import { userRoleService } from "../../../services/index.js";
import { Sequelize, Op, col } from "sequelize";
import { generalHelper } from "../../../helpers/index.js";
import { StatusError } from "../../../config/index.js";
/**
 * permissionList
 * @param req
 * @param res
 */
export const permissionList = async (req, res, next) => {
  try {
    const reqBody = req.query;
    const actionList = {
      add: "Add",
      edit: "Edit",
      view: "View",
      list: "List",
      delete: "Delete",
      status_change: "Approver",
    };
    //const userRoleId = req.userDetails.user_role_id ? req.userDetails.user_role_id : "";
    const roleUserId = reqBody.user_id ? reqBody.user_id : "";
    const roleId = reqBody.role ? reqBody.role : "";
    const getUserRole = await model.userRole.findOne({
      attributes: ["id"],
      where: { role_id: roleId, user_id: roleUserId, status: "active" },
    });
    if (!getUserRole) throw StatusError.badRequest(res.__("Please provide a valid role & user"));
    const userRoleId = getUserRole && getUserRole.id ? getUserRole.id : "";
    let resultData = [];
    const getRole = await userRoleService.getRoleNameByRoleId(roleId);
    if (getRole) {
      let conditions = { status: "active" };
      // if (getRole == "superadmin" || getRole == "administrator") {
      //   conditions["group_name"] = { [Op.ne]: "activity_log" };
      // } else {
      //   conditions[Op.and] = [
      //     { group_name: { [Op.ne]: "content_approval" } },
      //     {
      //       [Op.or]: [{ sub_group_name: { [Op.ne]: "role_permission" } }, { sub_group_name: null }],
      //     },
      //   ];
      // }
      let getPermission = [];
      // let getPermission = await model.rolePermission.findAll({
      //   attributes: [
      //     "id",
      //     ["user_role_id", "role_id"],
      //     "permission_id",
      //     "permission.group_name",
      //     "permission.sub_group_name",
      //     "permission.action",
      //   ],
      //   raw: true,
      //   include: [
      //     {
      //       model: model.permission,
      //       attributes: [],
      //       where: conditions,
      //       required: true,
      //     },
      //   ],
      //   //logging: console.log,
      //   where: { user_role_id: roleId, status: "active" },
      //   order: [["id"]],
      // });
      if (getPermission && getPermission.length == 0) {
        getPermission = await model.permission.findAll({
          attributes: [
            //[Sequelize.literal("''"), "id"],
            [col("rolePermissions.id"), "id"],
            [Sequelize.literal(roleId), "role_id"],
            [Sequelize.literal(roleUserId), "user_id"],
            [col("permission.id"), "permission_id"],
            "group_name",
            "sub_group_name",
            "action",
          ],
          raw: true,
          include: [
            {
              model: model.rolePermission,
              attributes: [],
              where: { user_role_id: userRoleId, status: "active" },
              required: false,
            },
          ],
          where: conditions,
          //order: [["permission.id"]],
          //logging: console.log,
        });
      }
      // // Grouping function
      const groupBy = async (array) => {
        return array.reduce((acc, item) => {
          // Create a group key based on group_name and sub_group_name
          const groupKey = item.sub_group_name ? item.sub_group_name : "No Sub Group";

          // If the group doesn't exist, create it
          if (!acc[item.group_name]) {
            acc[item.group_name] = {};
          }

          // If the sub-group doesn't exist, create it
          if (!acc[item.group_name][groupKey]) {
            acc[item.group_name][groupKey] = [];
          }

          // Push the item into the corresponding group and sub-group
          acc[item.group_name][groupKey].push({
            id: item.id ?? "",
            role_id: item.role_id,
            user_id: item.user_id,
            permission_id: item.permission_id,
            action: actionList[item.action] ?? "",
          });

          return acc;
        }, {});
      };

      // // Group the data
      const groupedData = await groupBy(getPermission);

      // // Convert to an array format if needed
      const groupedArray = Object.keys(groupedData).map((group) => {
        if (groupedData[group]["No Sub Group"]) {
          return {
            section_name: generalHelper.permissionDisplayNameList(group),
            //section_name: group,
            permissions: groupedData[group]["No Sub Group"],
          };
        } else {
          return {
            section_name: generalHelper.permissionDisplayNameList(group),
            //section_name: group,
            sub_section_name: Object.keys(groupedData[group]).map((subGroup) => ({
              section_name: generalHelper.permissionDisplayNameList(subGroup),
              //section_name: subGroup,
              permissions: groupedData[group][subGroup],
            })),
          };
        }
      });

      resultData = groupedArray;
    }
    res.ok({
      results: resultData,
    });
  } catch (error) {
    console.log(error);
    next(error);
  }
};
