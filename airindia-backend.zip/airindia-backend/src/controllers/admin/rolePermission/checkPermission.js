import model from "../../../models/index.js";
import { userRoleService } from "../../../services/index.js";

/**
 * checkPermission
 * @param req
 * @param res
 */
export const checkPermission = async (req, res, next) => {
  try {
    const reqBody = req.body;
    const roleId = req.userDetails.user_role_id ? req.userDetails.user_role_id : "";
    const loginUserId = req.userDetails.userId;
    if (!loginUserId) {
      throw StatusError.badRequest(res.__("Invalid user"));
    }
    if (!roleId) {
      throw StatusError.badRequest(res.__("Invalid role"));
    }
    const getRole = await userRoleService.getRoleNameByRoleId(roleId, "active");
    if (!getRole) throw StatusError.badRequest(res.__("Invalid role"));
    const section = reqBody.sec ? reqBody.sec : "";
    const subSection = reqBody.sub_sec ? reqBody.sub_sec : "";
    const action = reqBody.action ? reqBody.action : "";
    const getUserRole = await model.userRole.findOne({
      attributes: ["id"],
      where: { role_id: roleId, user_id: loginUserId, status: "active" },
    });
    if (!getUserRole)
      throw StatusError.badRequest(res.__("Please provide a valid role for the user"));
    const userRoleId = getUserRole && getUserRole.id ? getUserRole.id : "";
    let resultData = [];

    let conditions = { status: "active" };
    if (section) {
      conditions.group_name = section;
    }
    if (subSection) {
      conditions.sub_group_name = subSection;
    }
    if (action) {
      conditions.action = action;
    }
    let getPermission = [];
    if (getPermission && getPermission.length == 0) {
      getPermission = await model.permission.findAll({
        attributes: ["group_name", "sub_group_name", "action"],
        raw: true,
        include: [
          {
            model: model.rolePermission,
            attributes: [],
            where: { user_role_id: userRoleId, status: "active" },
            required: true,
          },
        ],
        where: conditions,
        //order: [["permission.id"]],
        //logging: console.log,
      });
      // // Grouping function
      const groupBy = async (array) => {
        return array.reduce((acc, item) => {
          // Create a group key based on group_name and sub_group_name
          const groupKey = item.sub_group_name ? item.sub_group_name : "No Sub Group";

          // If the group doesn't exist, create it
          if (!acc[item.group_name]) {
            acc[item.group_name] = {};
          }

          // If the sub-group doesn't exist, create it
          if (!acc[item.group_name][groupKey]) {
            acc[item.group_name][groupKey] = [];
          }

          // Push the item into the corresponding group and sub-group
          acc[item.group_name][groupKey].push(item.action);

          return acc;
        }, {});
      };

      // // Group the data
      const groupedData = await groupBy(getPermission);
      // // Convert to an array format if needed
      const groupedArray = Object.keys(groupedData).map((group) => {
        if (groupedData[group]["No Sub Group"]) {
          return {
            section_name: group,
            //section_name: group,
            permissions: groupedData[group]["No Sub Group"],
          };
        } else {
          return {
            section_name: group,
            //section_name: group,
            sub_section_name: Object.keys(groupedData[group]).map((subGroup) => ({
              section_name: subGroup,
              //section_name: subGroup,
              permissions: groupedData[group][subGroup],
            })),
          };
        }
      });
      resultData = groupedArray;
    }

    res.ok({
      results: resultData,
    });
  } catch (error) {
    console.log(error);
    next(error);
  }
};
