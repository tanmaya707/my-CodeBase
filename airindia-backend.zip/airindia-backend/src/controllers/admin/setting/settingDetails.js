import model from "../../../models/index.js";
import { Op } from "sequelize";

/**
 * settingDetails
 * @param req
 * @param res
 */
export const settingDetails = async (req, res, next) => {
  try {
    let resultData = {
      name: "",
      email: "",
      mobile: "",
      logo: "",
      address: "",
      gps_coordinates: "",
    };
    const keyName = "site.";
    let getInfo = await model.siteSetting.findAll({
      where: {
        key_name: { [Op.like]: `%${keyName}%` },
      },
      attributes: ["key_name", "setting_value"],
    });
    if (getInfo && getInfo.length > 0) {
      for (const row of getInfo) {
        let pVa = row.setting_value ? row.setting_value : "";
        if (row.key_name == "site.logo") {
          pVa = pVa.replace(`public/uploads/`, `public/`);
        }
        if (row.key_name == "site.gps_coordinates") {
          pVa = row.setting_value ? JSON.parse(row.setting_value) : "";
        }
        resultData[row.key_name.replace(keyName, "")] = pVa;
      }
    }
    res.ok(resultData ? resultData : {});
  } catch (error) {
    console.log(error);
    next(error);
  }
};
