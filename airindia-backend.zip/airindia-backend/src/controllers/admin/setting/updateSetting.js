import model from "../../../models/index.js";
import { customDateTimeHelper, generalHelper, customFileHelper } from "../../../helpers/index.js";
import { StatusError } from "../../../config/index.js";
import { Op } from "sequelize";
import fs from "fs";
import {
  contentModificationService,
  notificationService,
  userPermissionService,
} from "../../../services/index.js";

/**
 * updateSetting
 * @param req
 * @param res
 */
export const updateSetting = async (req, res, next) => {
  try {
    const reqBody = req.body;
    const loginUserId = req.userDetails.userId;

    if (!loginUserId) {
      if (req.file && req.file.path) customFileHelper.customFileUnlink(fs, req.file.path);
      throw StatusError.badRequest(res.__("Invalid user id"));
    }
    const userRole = req.userDetails.user_type ?? "";
    const roleId = req.userDetails.user_role_id ?? "";
    if (!userRole) {
      if (req.file && req.file.path) customFileHelper.customFileUnlink(fs, req.file.path);
      throw StatusError.badRequest(res.__("Invalid user role"));
    }

    let isFileDeleted = reqBody.is_fdel ? reqBody.is_fdel : "";
    isFileDeleted = isFileDeleted == "" ? "n" : isFileDeleted;
    let fileLocation = "";
    let fileName = "";
    if (req.file) {
      const fileDetails = req.file;
      fileName = fileDetails.filename ? fileDetails.filename : "";
      fileLocation = fileDetails.destination ? fileDetails.destination + "/" + fileName : "";
    }

    const keyName = "site.";
    // check for settings id existance in table
    const isExistsRe = await model.siteSetting.findAll({
      where: {
        key_name: { [Op.like]: `%${keyName}%` },
      },
      //attributes: ["key_name", "setting_value"],
    });
    let errRet = [];
    let sucMess = "success";
    let updt = 0;
    let inup = false;
    let tempData = [];
    if (userRole == "superadmin" || userRole == "administrator" || userRole == "approver") {
      const check = await userPermissionService.checkUserPermission(roleId, loginUserId, [
        `setting.site_setting.edit`,
      ]);
      if (check) {
        inup = true;
      }
    }
    if (isExistsRe && isExistsRe.length > 0) {
      //const oldData = isExists.setting_value ? JSON.parse(isExists.setting_value) : "";
      for (const row of isExistsRe) {
        if (row) {
          let reqDetails = {
            updated_at: await customDateTimeHelper.getCurrentDateTime(),
            updated_by: loginUserId,
          };
          let oldImag = "";
          let pVa = "";
          if (row.key_name == "site.gps_coordinates") {
            pVa = JSON.stringify({
              latitude: reqBody.latitude ?? "",
              longitude: reqBody.longitude ?? "",
              embed_link: reqBody.embed_link ?? "",
            });
          } else if (
            row.key_name != "site.gps_coordinates" &&
            row.key_name != "site.logo" &&
            reqBody[row.key_name.replace("site.", "")]
          ) {
            pVa = reqBody[row.key_name.replace("site.", "")];
          } else if (row.key_name == "site.logo") {
            if (row.setting_value) {
              oldImag = row.setting_value;
            }
            // add details
            let fpath = fileLocation ? fileLocation : oldImag;
            if (isFileDeleted == "y") {
              fpath = "";
            }
            pVa = fpath;
          }
          reqDetails.setting_value = pVa;

          if (pVa) {
            //console.log(pVa);
            if (inup) {
              const [resInfo] = await model.siteSetting.update(reqDetails, {
                where: { key_name: row.key_name },
              });
              // if (resInfo > 0 && row.key_name == "site.logo") {
              //   if (((req.file && req.file.path) || isFileDeleted == "y") && oldImag)
              //     customFileHelper.customFileUnlink(fs, oldImag);
              // }
              //
              if (resInfo > 0) {
                updt = 1;
              }
              if (resInfo == 0) {
                errRet.push(row.key_name);
              }
            } else {
              tempData.push({ ...row.dataValues, setting_value: pVa });
            }
          }
        }
      }
    } else {
      if (req.file && req.file.path) customFileHelper.customFileUnlink(fs, req.file.path);
    }
    if (inup == false && tempData && tempData.length > 0 && updt == 0) {
      const checkForPendingRequest = await contentModificationService.checkForPendingRequest({
        id: !isExistsRe[0].id ? "" : isExistsRe[0].id,
        request_for: "site_info",
        action_type: "edit",
      });
      if (checkForPendingRequest) {
        throw StatusError.badRequest(
          res.__(
            "A modification request is already in progress. Please wait for the approval response and try again later.",
          ),
        );
      } else {
        let requestDetails = {};
        requestDetails.setting_id = !isExistsRe[0].id ? "" : isExistsRe[0].id;
        requestDetails.setting_value = tempData ? JSON.stringify(tempData) : null;
        requestDetails.earlier_data = isExistsRe ? JSON.stringify(isExistsRe) : null;
        requestDetails.created_at = await customDateTimeHelper.getCurrentDateTime();
        requestDetails.created_by = loginUserId;
        const insRes = await model.tempSiteSettingInfo.create(requestDetails);

        if (insRes && insRes.id > 0) {
          sucMess =
            "Your modification request has been save successfully. Please wait for approval!";
          await contentModificationService.addRequest({
            temp_id: insRes.id,
            request_for: "site_info",
            action_type: "edit",
            created_at: requestDetails.created_at,
            created_by: requestDetails.created_by,
          });
          await notificationService.generateNotificationForContentApproval(
            {
              created_by: loginUserId,
              notification_type: "content_approval",
              type: "update",
              title: `A site content modification requested`,
              item_id: insRes.id,
              item_description: `A site info modification requested by publisher`,
              item: insRes,
            },
            null,
            [`setting.site_setting.status_change`],
          );
          updt = 1;
        }
      }
    }
    if (updt > 0) {
      res.ok({
        message: res.__(sucMess),
      });
    } else {
      throw StatusError.badRequest(res.__("SomeThingWentWrong"));
    }
  } catch (error) {
    console.log(error);
    if (req.file && req.file.path) customFileHelper.customFileUnlink(fs, req.file.path);
    next(error);
  }
};
