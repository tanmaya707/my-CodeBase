import { settingDetails } from "./settingDetails.js";
import { updateSetting } from "./updateSetting.js";

export { settingDetails, updateSetting };
