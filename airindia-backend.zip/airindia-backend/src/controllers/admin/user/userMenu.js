import model from "../../../models/index.js";
import { SIDEBAR_MENU } from "../../../utils/constants.js";
import { userRoleService } from "../../../services/index.js";
import { StatusError } from "../../../config/index.js";

/**
 * userMenu
 * @param req
 * @param res
 * @param next
 */
export const userMenu = async (req, res, next) => {
  try {
    let menuList = [];
    const userId = req.userDetails.userId; //It will login user id
    const getRole = await userRoleService.getUserRole(userId);
    if (getRole) {
      //if (getRole.role_name == "guests" || getRole.role_name == "users")
      const checkUserRole = await userRoleService.getRoleIdByRoleName(getRole.role_name, "active");
      if (!checkUserRole) throw StatusError.unauthorized("");
      const getPermission = await model.rolePermission.findAll({
        attributes: ["permission.group_name", "permission.sub_group_name"],
        raw: true,
        include: [
          { model: model.permission, attributes: [], where: { status: "active" }, required: true },
        ],
        where: { user_role_id: getRole.id, status: "active" },
        //order: [["id"]],
        group: ["permission.group_name", "permission.sub_group_name"],
        //logging: console.log,
      });
      if (SIDEBAR_MENU.length > 0) {
        let i = 0;
        for (const rMenu of SIDEBAR_MENU) {
          if (rMenu.menuItems && rMenu.menuItems.length > 0) {
            menuList[i] = { title: rMenu.title, description: rMenu.description, menuItems: [] };
            for (const eachMenu of rMenu.menuItems) {
              if (eachMenu) {
                if (getPermission.some((obj) => obj.group_name == eachMenu.u_key)) {
                  let subCategory = [];
                  if (eachMenu.childMenuItems && eachMenu.childMenuItems.length > 0) {
                    for (const eachSubMenu of eachMenu.childMenuItems) {
                      if (eachSubMenu) {
                        if (
                          getPermission.some(
                            (obj) =>
                              obj.group_name == eachMenu.u_key &&
                              obj.sub_group_name == eachSubMenu.u_key,
                          )
                        ) {
                          let subMenu = {
                            //u_key: eachSubMenu.u_key,
                            label: eachSubMenu.label,
                            url: eachSubMenu.url,
                            image_path: eachSubMenu.image_path ?? "",
                            exact: eachSubMenu.exact,
                          };
                          if (eachMenu.u_key == "setting") {
                            subMenu = {
                              //u_key: eachSubMenu.u_key,
                              label: eachSubMenu.label,
                              description: eachSubMenu.description,
                              router_path: eachSubMenu.router_path,
                              icon: eachSubMenu.icon,
                            };
                          }
                          subCategory.push(subMenu);
                        }
                      }
                    }
                  }

                  let menu = {
                    //u_key: eachMenu.u_key,
                    label: eachMenu.label,
                    icon: eachMenu.icon,
                    url: eachMenu.url,
                    image_path: eachMenu.image_path ?? "",
                    exact: eachMenu.exact,
                  };
                  if (subCategory.length > 0) menu.childMenuItems = subCategory;
                  menuList[i].menuItems.push(menu);
                }
              }
            }
          }
          i++;
        }
      }
    }
    res.ok({
      results: menuList ? menuList : [],
    });
  } catch (error) {
    console.log(error);
    next(error);
  }
};
