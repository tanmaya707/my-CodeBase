import model from "../../../models/index.js";
import { Op, col, fn } from "sequelize";
import { StatusError, envs } from "../../../config/index.js";

/**
 * inquiryDetails
 * @param req
 * @param res
 */
export const inquiryDetails = async (req, res, next) => {
  try {
    const reqBody = req.params;
    const id = reqBody.id ? reqBody.id : "";
    if (!id) throw StatusError.badRequest(res.__("Invalid id"));

    const checkId = await model.contactUs.count({
      where: { id: id },
    });
    if (checkId == 0) throw StatusError.badRequest(res.__("Invalid id"));

    let resultData = {};
    const condition = { id: id };
    const attributes = [
      "id",
      "name",
      "email",
      "message",
      "has_read",
      "country_id",
      [col("country.country_name"), "country_name"],
      "purpose_type_id",
      [col("contactPurpose.name"), "purpose_type"],
      "remarks",
      "company_name",
      "created_at",
    ];

    const includeQuery = [
      {
        model: model.country,
        attributes: [],
        //where: { status: "active" },
        required: false,
      },
      {
        model: model.contactPurpose,
        attributes: [],
        required: false,
      },
    ];

    resultData = await model.contactUs.findOne({
      attributes: attributes,
      include: includeQuery,
      where: condition,
    });

    res.ok(resultData ? resultData : {});
  } catch (error) {
    next(error);
  }
};
