import { inquiryList } from "./inquiryList.js";
import { inquiryDetails } from "./inquiryDetails.js";
import { deleteInquiry } from "./deleteInquiry.js";
import { editInquiry } from "./editInquiry.js";

export { inquiryList, inquiryDetails, deleteInquiry, editInquiry };
