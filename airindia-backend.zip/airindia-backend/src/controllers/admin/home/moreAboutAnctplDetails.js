import model from "../../../models/index.js";
import { Sequelize, Op, col } from "sequelize";
import { StatusError, envs } from "../../../config/index.js";

/**
 * moreAboutAnctplDetails
 * @param req
 * @param res
 */
export const moreAboutAnctplDetails = async (req, res, next) => {
  try {
    //const reqBody = req.params;
    //const setId = reqBody.id ? reqBody.id : "";
    //if (!setId) throw StatusError.badRequest(res.__("Invalid id"));
    const checkId = await model.siteSetting.count({
      where: { key_name: "home.page.transport_solutions" },
    });
    if (checkId == 0) throw StatusError.badRequest(res.__("Invalid id"));

    let resultData = {};
    const condition = { key_name: "home.page.transport_solutions" };
    const result = await model.siteSetting.findOne({
      where: condition,
    });

    if (result && result.setting_value) {
      const pData = JSON.parse(result.setting_value);
      resultData.setting_id = result.id ?? "";
      resultData.sec3_main_heading = pData.heading_text_1 ?? "";
      resultData.sec3_sub_heading = pData.heading_text_2 ?? "";
      resultData.sec3_title1 = pData.list[0].name ?? "";
      resultData.sec3_des1 = pData.list[0].short_description ?? "";
      resultData.sec3_link1 = pData.list[0].detail_link ?? "";
      resultData.sec3_title2 = pData.list[1].name ?? "";
      resultData.sec3_des2 = pData.list[1].short_description ?? "";
      resultData.sec3_link2 = pData.list[1].detail_link ?? "";
      resultData.sec3_title3 = pData.list[2].name ?? "";
      resultData.sec3_des3 = pData.list[2].short_description ?? "";
      resultData.sec3_link3 = pData.list[2].detail_link ?? "";
      resultData.homeSec3_image = pData.file_path
        ? pData.file_path.replace(`public/uploads/`, `public/`)
        : "";
    } else {
      resultData.setting_id = "";
      resultData.sec3_main_heading = "";
      resultData.sec3_sub_heading = "";
      resultData.sec3_title1 = "";
      resultData.sec3_des1 = "";
      resultData.sec3_link1 = "";
      resultData.sec3_title2 = "";
      resultData.sec3_des2 = "";
      resultData.sec3_link2 = "";
      resultData.sec3_title3 = "";
      resultData.sec3_des3 = "";
      resultData.sec3_link3 = "";
      resultData.homeSec3_image = "";
    }

    res.ok(resultData ? resultData : {});
  } catch (error) {
    console.log(error);
    next(error);
  }
};
