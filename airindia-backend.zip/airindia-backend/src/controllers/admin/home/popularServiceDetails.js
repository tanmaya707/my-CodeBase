import model from "../../../models/index.js";
import { StatusError } from "../../../config/index.js";
import { Op, fn, col } from "sequelize";

/**
 *get popular service for home page details
 * @param req
 * @param res
 * @param next
 */
export const popularServiceDetails = async (req, res, next) => {
  try {
    const checkId = await model.siteSetting.count({
      where: { key_name: "home.popular_services" },
    });
    if (checkId == 0) throw StatusError.badRequest(res.__("Invalid id"));

    const getSetService = await model.siteSetting.findOne({
      where: {
        key_name: "home.popular_services",
      },
      attributes: ["id", "setting_value"],
    });
    let getServices = [];
    if (getSetService && JSON.parse(getSetService.setting_value).length > 0) {
      getServices = await model.service.findAll({
        where: {
          status: "active",
          id: { [Op.in]: JSON.parse(getSetService.setting_value) },
        },
        attributes: [
          "id",
          "uuid",
          "name",
          [fn("REPLACE", col("file_path"), `public/uploads/`, `public/`), "file_path"],
        ],
        //order: [["id", "desc"]],
      });
    }
    // if (getServices && getServices.length > 0) {
    //   res.ok({ setting_id: !getSetService.id ? "" : getSetService.id, results: getServices });
    // } else {
    //   throw StatusError.notFound(res.__("data not found"));
    // }
    res.ok({ setting_id: !getSetService.id ? "" : getSetService.id, results: getServices ?? [] });
  } catch (error) {
    console.log(error);
    next(error);
  }
};
