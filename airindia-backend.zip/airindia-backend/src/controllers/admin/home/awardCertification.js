import model from "../../../models/index.js";
import { Sequelize, Op, col, fn } from "sequelize";
import { StatusError, envs } from "../../../config/index.js";

/**
 * awardCertification
 * @param req
 * @param res
 */
export const awardCertification = async (req, res, next) => {
  try {
    //const reqBody = req.params;
    //const setId = reqBody.id ? reqBody.id : "";
    //if (!setId) throw StatusError.badRequest(res.__("Invalid id"));
    const checkId = await model.siteSetting.count({
      where: { key_name: "home.page.awards_certificates" },
    });
    if (checkId == 0) throw StatusError.badRequest(res.__("Invalid id"));

    let resultData = {};
    const condition = { key_name: "home.page.awards_certificates" };
    const result = await model.siteSetting.findOne({
      where: condition,
    });

    if (result && result.setting_value) {
      const pData = JSON.parse(result.setting_value);
      resultData.setting_id = result.id ?? "";
      resultData = { ...resultData, ...pData };
    } else {
      resultData.setting_id = "";
    }
    const conditionA = { key_name: "home.award" };
    const resultA = await model.siteSetting.findOne({
      where: conditionA,
    });
    if (resultA && resultA.setting_value) {
      const pData = JSON.parse(resultA.setting_value);
      let getAwards = [];
      if (pData && pData.length > 0) {
        getAwards = await model.award.findAll({
          where: {
            status: "active",
            id: { [Op.in]: pData },
          },
          attributes: ["id", "uuid", "award_title", "slug_name", "award_description"],
          include: [
            {
              attributes: [
                [
                  fn("REPLACE", col("awardImages.file_path"), `public/uploads/`, `public/`),
                  "file_path",
                ],
              ],
              model: model.awardImage,
              where: { status: "active" },
              required: false,
            },
          ],
          //order: [["id", "desc"]],
        });
      }
      if (getAwards && getAwards.length > 0) {
        getAwards = getAwards.map((record) => {
          record.dataValues.award_images =
            record.dataValues.awardImages.length > 0 ? record.dataValues.awardImages : [];
          delete record.dataValues.awardImages;
          return record;
        });
      }
      resultData.award_list = getAwards;
    } else {
      resultData.award_list = [];
    }
    res.ok(resultData ? resultData : {});
  } catch (error) {
    console.log(error);
    next(error);
  }
};
