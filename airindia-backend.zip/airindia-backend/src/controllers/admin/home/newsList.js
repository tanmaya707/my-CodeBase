import model from "../../../models/index.js";
import { Op } from "sequelize";

/**
 * newsList
 * @param req
 * @param res
 */
export const newsList = async (req, res, next) => {
  try {
    const reqBody = req.query;
    let condition = { status: "active" };
    if (reqBody.search_name) {
      condition.title = { [Op.like]: `%${reqBody.search_name}%` };
    }
    const list = await model.news.findAll({
      attributes: ["id", "uuid", "title", "slug_name", "type"],
      where: condition,
      order: [["id", "desc"]],
      //limit: 20,
    });
    res.ok({
      results: list,
    });
  } catch (error) {
    next(error);
  }
};
