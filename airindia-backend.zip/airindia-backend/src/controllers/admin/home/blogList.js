import model from "../../../models/index.js";
import { Op } from "sequelize";

/**
 * blogList
 * @param req
 * @param res
 */
export const blogList = async (req, res, next) => {
  try {
    const reqBody = req.query;
    let condition = { status: "active" };
    if (reqBody.search_name) {
      condition.blog_title = { [Op.like]: `%${reqBody.search_name}%` };
    }
    const list = await model.blog.findAll({
      attributes: ["id", "uuid", "blog_title", "blog_short_description"],
      where: condition,
      order: [["id", "desc"]],
      //limit: 20,
    });
    res.ok({
      results: list,
    });
  } catch (error) {
    next(error);
  }
};
