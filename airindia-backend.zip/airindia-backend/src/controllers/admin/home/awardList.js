import model from "../../../models/index.js";
import { Op } from "sequelize";

/**
 * awardList
 * @param req
 * @param res
 */
export const awardList = async (req, res, next) => {
  try {
    const reqBody = req.query;
    let condition = { status: "active" };
    if (reqBody.search_name) {
      condition.award_title = { [Op.like]: `%${reqBody.search_name}%` };
    }
    const list = await model.award.findAll({
      attributes: ["id", "uuid", "award_title", "slug_name"],
      where: condition,
      order: [["id", "desc"]],
      //limit: 20,
    });
    res.ok({
      results: list,
    });
  } catch (error) {
    next(error);
  }
};
