import model from "../../../models/index.js";
import { Sequelize, Op, col } from "sequelize";
import { StatusError, envs } from "../../../config/index.js";

/**
 * aboutAnctplDetails
 * @param req
 * @param res
 */
export const aboutAnctplDetails = async (req, res, next) => {
  try {
    //const reqBody = req.params;
    //const setId = reqBody.id ? reqBody.id : "";
    //if (!setId) throw StatusError.badRequest(res.__("Invalid id"));
    const checkId = await model.siteSetting.count({
      where: { key_name: "home.page.sat_offer" },
    });
    if (checkId == 0) throw StatusError.badRequest(res.__("Invalid id"));

    let resultData = {};
    const condition = { key_name: "home.page.sat_offer" };
    const result = await model.siteSetting.findOne({
      where: condition,
    });

    if (result && result.setting_value) {
      const pData = JSON.parse(result.setting_value);
      resultData.setting_id = result.id ?? "";
      resultData.homeSec2_main_heading = pData.heading_text_1 ?? "";
      resultData.homeSec2_sub_heading = pData.heading_text_2 ?? "";
      resultData.homeSec2_description = pData.description ?? "";
      resultData.homeSec2_image = pData.file_path
        ? pData.file_path.replace(`public/uploads/`, `public/`)
        : "";
    } else {
      resultData.setting_id = "";
      resultData.homeSec2_main_heading = "";
      resultData.homeSec2_sub_heading = "";
      resultData.homeSec2_description = "";
      resultData.homeSec2_image = "";
    }

    res.ok(resultData ? resultData : {});
  } catch (error) {
    console.log(error);
    next(error);
  }
};
