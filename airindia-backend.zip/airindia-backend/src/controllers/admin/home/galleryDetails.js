import model from "../../../models/index.js";
import { Sequelize, Op, col, fn } from "sequelize";
import { StatusError, envs } from "../../../config/index.js";

/**
 * galleryDetails
 * @param req
 * @param res
 */
export const galleryDetails = async (req, res, next) => {
  try {
    //const reqBody = req.params;
    //const setId = reqBody.id ? reqBody.id : "";
    //if (!setId) throw StatusError.badRequest(res.__("Invalid id"));
    const checkId = await model.siteSetting.count({
      where: { key_name: "home.gallery" },
    });
    if (checkId == 0) throw StatusError.badRequest(res.__("Invalid id"));

    let resultData = {};
    const condition = { key_name: "home.gallery" };
    const result = await model.siteSetting.findOne({
      where: condition,
    });
    if (result && result.setting_value) {
      const pData = JSON.parse(result.setting_value);
      resultData.setting_id = result.id ?? "";
      resultData = { ...resultData, ...pData };
      let getGallery = [];
      if (pData && pData.gallery && pData.gallery.length > 0) {
        getGallery = await model.gallery.findAll({
          where: {
            status: "active",
            id: { [Op.in]: pData.gallery },
          },
          attributes: [
            "id",
            "uuid",
            "title",
            [fn("REPLACE", col("file_path"), `public/uploads/`, `public/`), "file_path"],
            "file_type",
          ],
        });
      }
      resultData.gallery = getGallery;
    } else {
      resultData.setting_id = "";
      resultData.gallery = [];
    }
    res.ok(resultData ? resultData : {});
  } catch (error) {
    console.log(error);
    next(error);
  }
};
