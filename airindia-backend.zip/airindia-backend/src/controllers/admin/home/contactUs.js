import model from "../../../models/index.js";
import { Sequelize, Op, col, fn } from "sequelize";
import { StatusError, envs } from "../../../config/index.js";

/**
 * contactUs
 * @param req
 * @param res
 */
export const contactUs = async (req, res, next) => {
  try {
    const checkId = await model.siteSetting.count({
      where: { key_name: "home.page.contact_us" },
    });
    if (checkId == 0) throw StatusError.badRequest(res.__("Invalid id"));

    let resultData = {};
    const condition = { key_name: "home.page.contact_us" };
    const result = await model.siteSetting.findOne({
      where: condition,
    });

    if (result && result.setting_value) {
      const pData = JSON.parse(result.setting_value);
      resultData.setting_id = result.id ?? "";
      resultData = { ...resultData, ...pData };
    } else {
      resultData.setting_id = "";
    }

    res.ok(resultData ? resultData : {});
  } catch (error) {
    console.log(error);
    next(error);
  }
};
