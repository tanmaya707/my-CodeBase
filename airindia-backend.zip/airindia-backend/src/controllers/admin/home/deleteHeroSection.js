import model from "../../../models/index.js";
import { customDateTimeHelper, customFileHelper } from "../../../helpers/index.js";
import { StatusError } from "../../../config/index.js";
import fs from "fs";
import { GLOBAL_PARAMS } from "../../../utils/constants.js";
import {
  contentModificationService,
  notificationService,
  userPermissionService,
} from "../../../services/index.js";

/**
 * deleteHeroSection
 * @param req
 * @param res
 */
export const deleteHeroSection = async (req, res, next) => {
  try {
    const reqBody = req.body;
    const loginUserId = req.userDetails.userId;
    if (!loginUserId) {
      throw StatusError.badRequest(res.__("Invalid user id"));
    }
    const userRole = req.userDetails.user_type ?? "";
    const roleId = req.userDetails.user_role_id ?? "";
    if (!userRole) {
      throw StatusError.badRequest(res.__("Invalid user role"));
    }
    const setId = reqBody.id ? reqBody.id : "";
    const setnId = reqBody.setting_id ? reqBody.setting_id : "";

    let condition = {
      key_name: "home.page.landing_info",
      id: setnId,
    };
    const pageName = "home";
    // check for settings id existance in table
    const isExists = await model.siteSetting.findOne({
      where: condition,
    });

    if (!isExists) {
      throw StatusError.badRequest(res.__("Invalid id"));
    }

    let oldData = isExists.setting_value ? JSON.parse(isExists.setting_value) : [];
    const oldIdDataChk = oldData.filter((rec) => {
      if (rec.id == setId) {
        return true;
      } else {
        return false;
      }
    });

    if (oldIdDataChk && oldIdDataChk.length == 0) {
      throw StatusError.badRequest(res.__("Invalid id"));
    }

    let oldImag = "";
    const oldDataRes = oldData.filter((rec) => {
      if (rec.id == setId) {
        if (rec.file_path) {
          oldImag = rec.file_path;
        }
        return false;
      } else {
        return true;
      }
    });

    // add details
    let reqDetails = {
      setting_value: JSON.stringify(oldDataRes),
      updated_at: await customDateTimeHelper.getCurrentDateTime(),
      updated_by: loginUserId,
    };
    let updt = 0;
    let sucMess = "success";
    let inup = false;
    if (userRole == "superadmin" || userRole == "administrator" || userRole == "approver") {
      const check = await userPermissionService.checkUserPermission(roleId, loginUserId, [
        `pages.${pageName}.edit`,
      ]);
      if (check) {
        const [upResp] = await model.siteSetting.update(reqDetails, {
          where: condition,
        });
        if (upResp > 0) {
          updt = 1;
        }
        inup = true;
      }
    } else {
      const checkForPendingRequest = await contentModificationService.checkForPendingRequest({
        id: setnId,
        request_for: "home_page",
        action_type: "edit",
      });
      if (checkForPendingRequest) {
        throw StatusError.badRequest(
          res.__(
            "A modification request is already in progress. Please wait for the approval response and try again later.",
          ),
        );
      } else {
        let requestDetails = reqDetails;
        requestDetails.setting_id = setnId;
        requestDetails.setting_name = !isExists.setting_name ? "" : isExists.setting_name;
        requestDetails.key_name = !isExists.key_name ? "" : isExists.key_name;
        requestDetails.earlier_data = isExists ? JSON.stringify(isExists) : null;
        requestDetails.created_at = requestDetails.updated_at;
        requestDetails.created_by = requestDetails.updated_by;
        const insRes = await model.tempSiteSetting.create(requestDetails);

        if (insRes && insRes.id > 0) {
          sucMess =
            "Your modification request has been save successfully. Please wait for approval!";
          await contentModificationService.addRequest({
            temp_id: insRes.id,
            request_for: "home_page",
            action_type: "edit",
            created_at: requestDetails.updated_at,
            created_by: requestDetails.updated_by,
          });
          await notificationService.generateNotificationForContentApproval(
            {
              created_by: loginUserId,
              notification_type: "content_approval",
              type: "update",
              title: `A home content modification requested`,
              item_id: insRes.id,
              item_description: `A ${GLOBAL_PARAMS.SITE_CONTENT_KEY[insRes.key_name]} modification requested by publisher`,
              item: insRes,
            },
            null,
            [`pages.${pageName}.status_change`],
          );
          updt = 1;
        }
      }
    }
    if (updt > 0) {
      //if (inup && oldImag) customFileHelper.customFileUnlink(fs, oldImag);
      res.ok({
        message: res.__(sucMess),
      });
    } else {
      throw StatusError.badRequest(res.__("SomeThingWentWrong"));
    }
  } catch (error) {
    console.log(error);
    next(error);
  }
};
