import model from "../../../models/index.js";
import { Sequelize, Op, col, fn } from "sequelize";
import { StatusError, envs } from "../../../config/index.js";

/**
 * newsEvent
 * @param req
 * @param res
 */
export const newsEvent = async (req, res, next) => {
  try {
    //const reqBody = req.params;
    //const setId = reqBody.id ? reqBody.id : "";
    //if (!setId) throw StatusError.badRequest(res.__("Invalid id"));
    const checkId = await model.siteSetting.count({
      where: { key_name: "home.news_event" },
    });
    if (checkId == 0) throw StatusError.badRequest(res.__("Invalid id"));

    let resultData = {};
    const condition = { key_name: "home.news_event" };
    const result = await model.siteSetting.findOne({
      where: condition,
    });
    if (result && result.setting_value) {
      const pData = JSON.parse(result.setting_value);
      resultData.setting_id = result.id ?? "";
      resultData.title = pData.title ?? "";
      resultData.description = pData.description ?? "";
      let getNews = [];
      if (pData && pData.news && pData.news.length > 0) {
        getNews = await model.news.findAll({
          where: {
            status: "active",
            id: { [Op.in]: pData.news },
          },
          attributes: ["id", "uuid", "title", "short_description", "type"],
          include: [
            {
              attributes: [
                [
                  fn("REPLACE", col("newsImages.file_path"), `public/uploads/`, `public/`),
                  "file_path",
                ],
              ],
              model: model.newsImage,
              where: { status: "active" },
              required: false,
            },
          ],
        });
      }
      if (getNews && getNews.length > 0) {
        getNews = getNews.map((record) => {
          record.dataValues.news_images =
            record.dataValues.newsImages.length > 0 ? record.dataValues.newsImages : [];
          delete record.dataValues.newsImages;
          return record;
        });
      }
      resultData.news = getNews;
      let getClientTele = [];
      if (pData && pData.client_tele && pData.client_tele.length > 0) {
        getClientTele = await model.client.findAll({
          where: {
            status: "active",
            id: { [Op.in]: pData.client_tele },
          },
          attributes: [
            "id",
            "uuid",
            "client_name",
            "company_name",
            "designation",
            [fn("REPLACE", col("file_path"), `public/uploads/`, `public/`), "file_path"],
          ],
          //limit: 4,
        });
      }
      resultData.client_tele = getClientTele;
    } else {
      resultData.setting_id = "";
      resultData.news = [];
      resultData.client_tele = [];
    }
    res.ok(resultData ? resultData : {});
  } catch (error) {
    console.log(error);
    next(error);
  }
};
