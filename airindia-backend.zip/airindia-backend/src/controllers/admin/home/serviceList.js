import model from "../../../models/index.js";
import { Op } from "sequelize";

/**
 * serviceList
 * @param req
 * @param res
 */
export const serviceList = async (req, res, next) => {
  try {
    const reqBody = req.query;
    let condition = { status: "active" };
    if (reqBody.search_name) {
      condition.name = { [Op.like]: `%${reqBody.search_name}%` };
    }
    const list = await model.service.findAll({
      attributes: ["id", "uuid", "name", "description", "caption_text"],
      where: condition,
      order: [["id", "desc"]],
      //limit: 20,
    });
    res.ok({
      results: list,
    });
  } catch (error) {
    next(error);
  }
};
