import model from "../../../models/index.js";
import { envs, StatusError } from "../../../config/index.js";
import { Op, fn, col } from "sequelize";

/**
 *get blog for home page details
 * @param req
 * @param res
 * @param next
 */
export const blogDetails = async (req, res, next) => {
  try {
    const checkId = await model.siteSetting.count({
      where: { key_name: "home.blog" },
    });
    if (checkId == 0) throw StatusError.badRequest(res.__("Invalid id"));

    const getSetBlog = await model.siteSetting.findOne({
      where: {
        key_name: "home.blog",
      },
      attributes: ["id", "setting_value"],
    });
    let getBlog = [];
    if (getSetBlog && getSetBlog.setting_value && JSON.parse(getSetBlog.setting_value).length > 0) {
      getBlog = await model.blog.findAll({
        where: {
          status: "active",
          id: { [Op.in]: JSON.parse(getSetBlog.setting_value) },
        },
        attributes: ["id", "uuid", "blog_title", "slug_name", "blog_short_description"],
        include: [
          {
            attributes: [
              [
                fn("REPLACE", col("blogImages.file_path"), `public/uploads/`, `public/`),
                "file_path",
              ],
            ],
            model: model.blogImage,
            where: { status: "active" },
            required: false,
          },
        ],
        //order: [["id", "desc"]],
      });
    } else {
      getBlog = [];
    }
    if (getSetBlog) {
      if (getBlog && getBlog.length > 0) {
        getBlog = getBlog.map((record) => {
          record.dataValues.blog_images =
            record.dataValues.blogImages.length > 0 ? record.dataValues.blogImages : [];
          delete record.dataValues.blogImages;
          return record;
        });
      }
      res.ok({ setting_id: !getSetBlog.id ? "" : getSetBlog.id, results: getBlog });
    } else {
      throw StatusError.notFound(res.__("data not found"));
    }
  } catch (error) {
    console.log(error);
    next(error);
  }
};
