import { heroSectionDetails } from "./heroSectionDetails.js";
import { saveHeroSection } from "./saveHeroSection.js";
import { aboutAnctplDetails } from "./aboutAnctplDetails.js";
import { saveAboutAnctpl } from "./saveAboutAnctpl.js";
import { moreAboutAnctplDetails } from "./moreAboutAnctplDetails.js";
import { saveMoreAboutAnctpl } from "./saveMoreAboutAnctpl.js";
import { awardList } from "./awardList.js";
import { awardCertification } from "./awardCertification.js";
import { saveAwardCertification } from "./saveAwardCertification.js";
import { blogDetails } from "./blogDetails.js";
import { saveBlog } from "./saveBlog.js";
import { blogList } from "./blogList.js";
import { saveCareer } from "./saveCareer.js";
import { careerDetails } from "./careerDetails.js";
import { deleteHeroSection } from "./deleteHeroSection.js";
import { saveNewsEvent } from "./saveNewsEvent.js";
import { newsEvent } from "./newsEvent.js";
import { newsList } from "./newsList.js";
import { clientList } from "./clientList.js";
import { aboutAirIndiaSats } from "./aboutAirIndiaSats.js";
import { saveAboutAirIndiaSats } from "./saveAboutAirIndiaSats.js";
import { moreAboutAirIndiaSats } from "./moreAboutAirIndiaSats.js";
import { saveMoreAboutAirIndiaSats } from "./saveMoreAboutAirIndiaSats.js";
import { deleteMoreAboutAirIndiaFile } from "./deleteMoreAboutAirIndiaFile.js";
import { savePopularService } from "./savePopularService.js";
import { serviceList } from "./serviceList.js";
import { popularServiceDetails } from "./popularServiceDetails.js";
import { saveGallery } from "./saveGallery.js";
import { galleryDetails } from "./galleryDetails.js";
import { galleryList } from "./galleryList.js";
import { contactUs } from "./contactUs.js";
import { saveContactUs } from "./saveContactUs.js";

export {
  heroSectionDetails,
  saveHeroSection,
  aboutAnctplDetails,
  saveAboutAnctpl,
  moreAboutAnctplDetails,
  saveMoreAboutAnctpl,
  awardList,
  awardCertification,
  saveAwardCertification,
  blogDetails,
  saveBlog,
  blogList,
  saveCareer,
  careerDetails,
  deleteHeroSection,
  saveNewsEvent,
  newsEvent,
  newsList,
  clientList,
  aboutAirIndiaSats,
  saveAboutAirIndiaSats,
  moreAboutAirIndiaSats,
  saveMoreAboutAirIndiaSats,
  deleteMoreAboutAirIndiaFile,
  savePopularService,
  serviceList,
  popularServiceDetails,
  saveGallery,
  galleryDetails,
  galleryList,
  contactUs,
  saveContactUs
};
