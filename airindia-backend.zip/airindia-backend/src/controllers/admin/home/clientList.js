import model from "../../../models/index.js";
import { Op } from "sequelize";

/**
 * clientList
 * @param req
 * @param res
 */
export const clientList = async (req, res, next) => {
  try {
    const reqBody = req.query;
    let condition = { status: "active" };
    if (reqBody.search_name) {
      condition.client_name = { [Op.like]: `%${reqBody.search_name}%` };
    }
    const list = await model.client.findAll({
      attributes: ["id", "uuid", "client_name", "slug_name", "company_name", "designation"],
      where: condition,
      order: [["id", "desc"]],
      //limit: 20,
    });
    res.ok({
      results: list,
    });
  } catch (error) {
    next(error);
  }
};
