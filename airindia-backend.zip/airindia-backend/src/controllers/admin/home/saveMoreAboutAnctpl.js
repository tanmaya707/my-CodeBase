import model from "../../../models/index.js";
import { customDateTimeHelper, generalHelper, customFileHelper } from "../../../helpers/index.js";
import { StatusError, envs } from "../../../config/index.js";
import { Op } from "sequelize";
import fs from "fs";
import { GLOBAL_PARAMS } from "../../../utils/constants.js";
import {
  contentModificationService,
  notificationService,
  userPermissionService,
} from "../../../services/index.js";

/**
 * saveMoreAboutAnctpl
 * @param req
 * @param res
 */
export const saveMoreAboutAnctpl = async (req, res, next) => {
  try {
    const reqBody = req.body;
    const loginUserId = req.userDetails.userId;
    if (!loginUserId) {
      if (req.file && req.file.path) customFileHelper.customFileUnlink(fs, req.file.path);
      throw StatusError.badRequest(res.__("Invalid user id"));
    }
    const userRole = req.userDetails.user_type ?? "";
    const roleId = req.userDetails.user_role_id ?? "";
    if (!userRole) {
      if (req.file && req.file.path) customFileHelper.customFileUnlink(fs, req.file.path);
      throw StatusError.badRequest(res.__("Invalid user role"));
    }
    const setId = reqBody.id ? reqBody.id : "";
    let isFileDeleted = reqBody.is_fdel ? reqBody.is_fdel : "";
    isFileDeleted = isFileDeleted == "" ? "n" : isFileDeleted;
    let fileLocation = "";
    let fileName = "";
    if (req.file) {
      const fileDetails = req.file;
      fileName = fileDetails.filename ? fileDetails.filename : "";
      fileLocation = fileDetails.destination ? fileDetails.destination + "/" + fileName : "";
    }

    let condition = {
      key_name: "home.page.transport_solutions",
    };
    const pageName = "home";
    if (setId) {
      condition.id = setId;
      // if(req.file.path)
      //   customFileHelper.customFileUnlink(fs,req.file.path);
      // throw StatusError.badRequest(res.__("Invalid id"));
    }

    // check for settings id existance in table
    const isExists = await model.siteSetting.findOne({
      where: condition,
    });

    if (!isExists && setId) {
      if (req.file && req.file.path) customFileHelper.customFileUnlink(fs, req.file.path);
      throw StatusError.badRequest(res.__("Invalid id"));
    }

    let oldImag = "";
    if (isExists) {
      const oldData = isExists.setting_value ? JSON.parse(isExists.setting_value) : "";
      if (oldData.file_path) {
        oldImag = oldData.file_path ?? "";
      }
    }
    // add details
    let fpath = fileLocation ? fileLocation : oldImag;
    if (isFileDeleted == "y") {
      fpath = "";
    }
    let reqDetails = {
      setting_value: JSON.stringify({
        heading_text_1: reqBody.sec3_main_heading ?? "",
        heading_text_2: reqBody.sec3_sub_heading ?? "",
        file_path: fpath,
        list: [
          {
            name: reqBody.sec3_title1 ?? "",
            short_description: reqBody.sec3_des1 ?? "",
            description: reqBody.sec3_des1 ?? "",
            detail_link: reqBody.sec3_link1 ?? "",
          },
          {
            name: reqBody.sec3_title2 ?? "",
            short_description: reqBody.sec3_des2 ?? "",
            description: reqBody.sec3_des2 ?? "",
            detail_link: reqBody.sec3_link2 ?? "",
          },
          {
            name: reqBody.sec3_title3 ?? "",
            short_description: reqBody.sec3_des3 ?? "",
            description: reqBody.sec3_des3 ?? "",
            detail_link: reqBody.sec3_link3 ?? "",
          },
        ],
      }),
    };
    if (!isExists && !setId) {
      reqDetails.key_name = "home.page.transport_solutions";
      reqDetails.created_at = await customDateTimeHelper.getCurrentDateTime();
      reqDetails.created_by = loginUserId;
    } else {
      reqDetails.updated_at = await customDateTimeHelper.getCurrentDateTime();
      reqDetails.updated_by = loginUserId;
    }
    let updt = 0;
    let sucMess = "success";
    if (userRole == "superadmin" || userRole == "administrator" || userRole == "approver") {
      const check = await userPermissionService.checkUserPermission(roleId, loginUserId, [
        `pages.${pageName}.edit`,
      ]);
      if (check) {
        const [upResp] = await model.siteSetting.update(reqDetails, {
          where: condition,
        });
        if (upResp > 0) {
          updt = 1;
        }
      }
    } else {
      const checkForPendingRequest = await contentModificationService.checkForPendingRequest({
        id: setId,
        request_for: "home_page",
        action_type: "edit",
      });
      if (checkForPendingRequest) {
        throw StatusError.badRequest(
          res.__(
            "A modification request is already in progress. Please wait for the approval response and try again later.",
          ),
        );
      } else {
        let requestDetails = reqDetails;
        requestDetails.setting_id = setId;
        requestDetails.setting_name = !isExists.setting_name ? "" : isExists.setting_name;
        requestDetails.key_name = "home.page.transport_solutions";
        requestDetails.earlier_data = isExists ? JSON.stringify(isExists) : null;
        requestDetails.created_at = requestDetails.updated_at;
        requestDetails.created_by = requestDetails.updated_by;
        const insRes = await model.tempSiteSetting.create(requestDetails);

        if (insRes && insRes.id > 0) {
          sucMess =
            "Your modification request has been save successfully. Please wait for approval!";
          await contentModificationService.addRequest({
            temp_id: insRes.id,
            request_for: "home_page",
            action_type: "edit",
            created_at: requestDetails.updated_at,
            created_by: requestDetails.updated_by,
          });
          await notificationService.generateNotificationForContentApproval(
            {
              created_by: loginUserId,
              notification_type: "content_approval",
              type: "update",
              title: `A home content modification requested`,
              item_id: insRes.id,
              item_description: `A ${GLOBAL_PARAMS.SITE_CONTENT_KEY[insRes.key_name]} modification requested by publisher`,
              item: insRes,
            },
            null,
            [`pages.${pageName}.status_change`],
          );
          updt = 1;
        }
      }
    }
    if (updt > 0) {
      if (((req.file && req.file.path) || isFileDeleted == "y") && oldImag)
        customFileHelper.customFileUnlink(fs, oldImag);
      res.ok({
        message: res.__(sucMess),
      });
    } else {
      if (req.file && req.file.path) customFileHelper.customFileUnlink(fs, req.file.path);
      throw StatusError.badRequest(res.__("SomeThingWentWrong"));
    }
  } catch (error) {
    console.log(error);
    if (req.file && req.file.path) customFileHelper.customFileUnlink(fs, req.file.path);
    next(error);
  }
};
