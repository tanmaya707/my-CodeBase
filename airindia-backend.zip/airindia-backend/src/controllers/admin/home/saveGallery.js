import model from "../../../models/index.js";
import { customDateTimeHelper } from "../../../helpers/index.js";
import { StatusError } from "../../../config/index.js";
import { Op } from "sequelize";
import { GLOBAL_PARAMS } from "../../../utils/constants.js";
import {
  contentModificationService,
  notificationService,
  userPermissionService,
} from "../../../services/index.js";

/**
 * saveGallery
 * @param req
 * @param res
 */
export const saveGallery = async (req, res, next) => {
  try {
    const reqBody = req.body;
    const loginUserId = req.userDetails.userId;
    if (!loginUserId) {
      throw StatusError.badRequest(res.__("Invalid user id"));
    }
    const userRole = req.userDetails.user_type ?? "";
    const roleId = req.userDetails.user_role_id ?? "";
    if (!userRole) {
      throw StatusError.badRequest(res.__("Invalid user role"));
    }
    const setId = reqBody.id ? reqBody.id : "";
    let condition = {
      key_name: "home.gallery",
    };
    const pageName = "home";
    if (setId) {
      condition.id = setId;
    }

    // check for settings id existance in table
    const isExists = await model.siteSetting.findOne({
      where: condition,
    });
    if (reqBody.gallery) {
      const isExistsA = await model.gallery.count({
        where: { status: "active", id: { [Op.in]: reqBody.gallery } },
      });
      if (isExistsA != reqBody.gallery.length) {
        throw StatusError.badRequest(res.__("Invalid gallery"));
      }
    }

    if (!isExists && setId) {
      throw StatusError.badRequest(res.__("Invalid id"));
    }

    // add details
    let reqDetails = {
      setting_value: JSON.stringify({
        title: reqBody.title ?? "",
        description: reqBody.description ?? "",
        gallery: reqBody.gallery ?? [],
      }),
    };
    if (!isExists && !setId) {
      reqDetails.key_name = "home.gallery";
      reqDetails.created_at = await customDateTimeHelper.getCurrentDateTime();
      reqDetails.created_by = loginUserId;
      let insRes;
      let sucMess = "success";
      if (userRole == "superadmin" || userRole == "administrator" || userRole == "approver") {
        const check = await userPermissionService.checkUserPermission(roleId, loginUserId, [
          `pages.${pageName}.add`,
        ]);
        if (check) {
          insRes = await model.siteSetting.create(reqDetails);
        } else {
          insRes = null;
        }
      } else {
        let inputDetails = reqDetails;
        insRes = await model.tempSiteSetting.create(inputDetails);
        if (insRes && insRes.id > 0) {
          sucMess = "Your addition request has been save successfully. Please wait for approval!";
          await contentModificationService.addRequest({
            temp_id: insRes.id,
            request_for: "home_page",
            action_type: "add",
            created_at: inputDetails.created_at,
            created_by: inputDetails.created_by,
          });
          await notificationService.generateNotificationForContentApproval(
            {
              created_by: loginUserId,
              notification_type: "content_approval",
              type: "update",
              title: `A new home content addition requested`,
              item_id: insRes.id,
              item_description: `A new ${GLOBAL_PARAMS.SITE_CONTENT_KEY[insRes.key_name]} addition requested by publisher`,
              item: inputDetails,
            },
            null,
            [`pages.${pageName}.status_change`],
          );
        }
      }
      if (insRes && insRes.id > 0) {
        res.ok({
          message: res.__(sucMess),
        });
      } else {
        throw StatusError.badRequest(res.__("SomeThingWentWrong"));
      }
    } else {
      reqDetails.updated_at = await customDateTimeHelper.getCurrentDateTime();
      reqDetails.updated_by = loginUserId;
      let updt = 0;
      let sucMess = "success";
      if (userRole == "superadmin" || userRole == "administrator" || userRole == "approver") {
        const check = await userPermissionService.checkUserPermission(roleId, loginUserId, [
          `pages.${pageName}.edit`,
        ]);
        if (check) {
          const [upResp] = await model.siteSetting.update(reqDetails, {
            where: condition,
          });
          if (upResp > 0) {
            updt = 1;
          }
        }
      } else {
        const checkForPendingRequest = await contentModificationService.checkForPendingRequest({
          id: setId,
          request_for: "home_page",
          action_type: "edit",
        });
        if (checkForPendingRequest) {
          throw StatusError.badRequest(
            res.__(
              "A modification request is already in progress. Please wait for the approval response and try again later.",
            ),
          );
        } else {
          let requestDetails = reqDetails;
          requestDetails.setting_id = setId;
          requestDetails.setting_name = !isExists.setting_name ? "" : isExists.setting_name;
          requestDetails.key_name = "home.gallery";
          requestDetails.earlier_data = isExists ? JSON.stringify(isExists) : null;
          requestDetails.created_at = requestDetails.updated_at;
          requestDetails.created_by = requestDetails.updated_by;
          const insRes = await model.tempSiteSetting.create(requestDetails);

          if (insRes && insRes.id > 0) {
            sucMess =
              "Your modification request has been save successfully. Please wait for approval!";
            await contentModificationService.addRequest({
              temp_id: insRes.id,
              request_for: "home_page",
              action_type: "edit",
              created_at: requestDetails.updated_at,
              created_by: requestDetails.updated_by,
            });
            await notificationService.generateNotificationForContentApproval(
              {
                created_by: loginUserId,
                notification_type: "content_approval",
                type: "update",
                title: `A home content modification requested`,
                item_id: insRes.id,
                item_description: `A ${GLOBAL_PARAMS.SITE_CONTENT_KEY[insRes.key_name]} modification requested by publisher`,
                item: insRes,
              },
              null,
              [`pages.${pageName}.status_change`],
            );
            updt = 1;
          }
        }
      }
      if (updt > 0) {
        res.ok({
          message: res.__(sucMess),
        });
      } else {
        throw StatusError.badRequest(res.__("SomeThingWentWrong"));
      }
    }
  } catch (error) {
    console.log(error);
    next(error);
  }
};
