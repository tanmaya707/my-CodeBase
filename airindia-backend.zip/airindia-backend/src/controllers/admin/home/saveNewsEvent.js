import model from "../../../models/index.js";
import { customDateTimeHelper } from "../../../helpers/index.js";
import { StatusError } from "../../../config/index.js";
import { Op } from "sequelize";
import { GLOBAL_PARAMS } from "../../../utils/constants.js";
import {
  contentModificationService,
  notificationService,
  userPermissionService,
} from "../../../services/index.js";

/**
 * saveNewsEvent
 * @param req
 * @param res
 */
export const saveNewsEvent = async (req, res, next) => {
  try {
    const reqBody = req.body;
    const loginUserId = req.userDetails.userId;
    if (!loginUserId) {
      throw StatusError.badRequest(res.__("Invalid user id"));
    }
    const userRole = req.userDetails.user_type ?? "";
    const roleId = req.userDetails.user_role_id ?? "";
    if (!userRole) {
      throw StatusError.badRequest(res.__("Invalid user role"));
    }
    const setId = reqBody.id ? reqBody.id : "";
    let condition = {
      key_name: "home.news_event",
    };
    const pageName = "home";
    if (setId) {
      condition.id = setId;
    }

    // check for settings id existance in table
    const isExists = await model.siteSetting.findOne({
      where: condition,
    });
    if (reqBody.news) {
      const isExistsA = await model.news.count({
        where: { status: "active", id: { [Op.in]: reqBody.news } },
      });
      if (isExistsA != reqBody.news.length) {
        throw StatusError.badRequest(res.__("Invalid News"));
      }
    }

    if (reqBody.client_tele) {
      const isExistsB = await model.client.count({
        where: { status: "active", id: { [Op.in]: reqBody.client_tele } },
      });
      if (isExistsB != reqBody.client_tele.length) {
        throw StatusError.badRequest(res.__("Invalid Client tele"));
      }
    }

    if (!isExists && setId) {
      throw StatusError.badRequest(res.__("Invalid id"));
    }

    // add details
    let reqDetails = {
      setting_value: JSON.stringify({
        title: reqBody.title ?? "",
        description: reqBody.description ?? "",
        news: reqBody.news ?? [],
        client_tele: reqBody.client_tele ?? [],
      }),
    };
    if (!isExists && !setId) {
      reqDetails.key_name = "home.news_event";
      reqDetails.created_at = await customDateTimeHelper.getCurrentDateTime();
      reqDetails.created_by = loginUserId;
    } else {
      reqDetails.updated_at = await customDateTimeHelper.getCurrentDateTime();
      reqDetails.updated_by = loginUserId;
    }
    let updt = 0;
    let sucMess = "success";
    if (userRole == "superadmin" || userRole == "administrator" || userRole == "approver") {
      const check = await userPermissionService.checkUserPermission(roleId, loginUserId, [
        `pages.${pageName}.edit`,
      ]);
      if (check) {
        const [upResp] = await model.siteSetting.update(reqDetails, {
          where: condition,
        });
        if (upResp > 0) {
          updt = 1;
        }
      }
    } else {
      const checkForPendingRequest = await contentModificationService.checkForPendingRequest({
        id: setId,
        request_for: "home_page",
        action_type: "edit",
      });
      if (checkForPendingRequest) {
        throw StatusError.badRequest(
          res.__(
            "A modification request is already in progress. Please wait for the approval response and try again later.",
          ),
        );
      } else {
        let requestDetails = reqDetails;
        requestDetails.setting_id = setId;
        requestDetails.setting_name = !isExists.setting_name ? "" : isExists.setting_name;
        requestDetails.key_name = "home.news_event";
        requestDetails.earlier_data = isExists ? JSON.stringify(isExists) : null;
        requestDetails.created_at = requestDetails.updated_at;
        requestDetails.created_by = requestDetails.updated_by;
        const insRes = await model.tempSiteSetting.create(requestDetails);

        if (insRes && insRes.id > 0) {
          sucMess =
            "Your modification request has been save successfully. Please wait for approval!";
          await contentModificationService.addRequest({
            temp_id: insRes.id,
            request_for: "home_page",
            action_type: "edit",
            created_at: requestDetails.updated_at,
            created_by: requestDetails.updated_by,
          });
          await notificationService.generateNotificationForContentApproval(
            {
              created_by: loginUserId,
              notification_type: "content_approval",
              type: "update",
              title: `A home content modification requested`,
              item_id: insRes.id,
              item_description: `A ${GLOBAL_PARAMS.SITE_CONTENT_KEY[insRes.key_name]} modification requested by publisher`,
              item: insRes,
            },
            null,
            [`pages.${pageName}.status_change`],
          );
          updt = 1;
        }
      }
    }
    if (updt > 0) {
      res.ok({
        message: res.__(sucMess),
      });
    } else {
      throw StatusError.badRequest(res.__("SomeThingWentWrong"));
    }
  } catch (error) {
    console.log(error);
    next(error);
  }
};
