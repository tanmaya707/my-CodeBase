import model from "../../../models/index.js";
import { Sequelize, Op, col } from "sequelize";
import { StatusError, envs } from "../../../config/index.js";

/**
 * heroSectionDetails
 * @param req
 * @param res
 */
export const heroSectionDetails = async (req, res, next) => {
  try {
    //const reqBody = req.params;
    //const setId = reqBody.id ? reqBody.id : "";
    //if (!setId) throw StatusError.badRequest(res.__("Invalid id"));
    const checkId = await model.siteSetting.count({
      where:{key_name:'home.page.landing_info'},
    });
    if (checkId == 0) throw StatusError.badRequest(res.__("Invalid id"));

    let resultData = [];
    const condition = { key_name: 'home.page.landing_info' };
    const result = await model.siteSetting.findOne({
      where: condition,
    });

    if (result && result.setting_value) {
      const pData = result.setting_value?JSON.parse(result.setting_value):[];
      resultData = pData.map((record)=>{
        return { id:record.id??"", setting_id:result.id??"", hero_sec_main_heading:record.heading_text_1??"", hero_sec_sub_heading:record.heading_text_2??"",file_type:record.file_type??"",hero_sec_image_video:record.file_path?record.file_path.replace(`public/uploads/`,`public/`):''};
      });
    }
    //  else {
    //   resultData.setting_id = "";
    //   resultData.hero_sec_main_heading = "";
    //   resultData.hero_sec_sub_heading = "";
    //   resultData.hero_sec_image_video = "";
    // }

    res.ok(resultData ? resultData : []);
  } catch (error) {
    console.log(error);
    next(error);
  }
};
