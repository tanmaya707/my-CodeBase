import model from "../../../models/index.js";
import { Sequelize, Op, col } from "sequelize";
import { StatusError, envs } from "../../../config/index.js";

/**
 * careerDetails
 * @param req
 * @param res
 */
export const careerDetails = async (req, res, next) => {
  try {
    //const reqBody = req.params;
    //const setId = reqBody.id ? reqBody.id : "";
    //if (!setId) throw StatusError.badRequest(res.__("Invalid id"));
    const checkId = await model.siteSetting.count({
      where: { key_name: "home.page.career" },
    });
    if (checkId == 0) throw StatusError.badRequest(res.__("Invalid id"));

    let resultData = {};
    const condition = { key_name: "home.page.career" };
    const result = await model.siteSetting.findOne({
      where: condition,
    });

    if (result && result.setting_value) {
      const pData = JSON.parse(result.setting_value);
      resultData.setting_id = result.id ?? "";
      resultData.title = pData.title ?? "";
      resultData.description = pData.description ?? "";
      resultData.file_path = pData.file_path
        ? pData.file_path.replace(`public/uploads/`, `public/`)
        : "";
      resultData.certifcates =
        pData.certifcates.length > 0
          ? pData.certifcates.map((rec) => {
              rec.file_path = rec.file_path
                ? rec.file_path.replace(`public/uploads/`, `public/`)
                : "";
              return rec;
            })
          : [];
    } else {
      resultData.setting_id = "";
      resultData.title = "";
      resultData.description = "";
      resultData.file_path = "";
      resultData.certifcates = [];
    }

    res.ok(resultData ? resultData : {});
  } catch (error) {
    console.log(error);
    next(error);
  }
};
