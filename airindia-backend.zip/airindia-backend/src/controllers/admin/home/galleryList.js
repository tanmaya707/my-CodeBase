import model from "../../../models/index.js";
import { Sequelize, Op, col, fn } from "sequelize";
import { StatusError, envs } from "../../../config/index.js";

/**
 * galleryList
 * @param req
 * @param res
 */
export const galleryList = async (req, res, next) => {
  try {
    const reqBody = req.query;
    let condition = { status: "active" };
    if (reqBody.search_name) {
      condition.title = { [Op.like]: `%${reqBody.search_name}%` };
    }
    const list = await model.gallery.findAll({
      attributes: [
        "id",
        "uuid",
        "title",
        [fn("REPLACE", col("file_path"), `public/uploads/`, `public/`), "file_path"],
        "file_type",
      ],
      where: condition,
      order: [["id", "desc"]],
      //limit: 20,
    });
    res.ok({
      results: list,
    });
  } catch (error) {
    console.log(error);
    next(error);
  }
};
