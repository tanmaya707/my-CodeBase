import model from "../../../models/index.js";
import { customDateTimeHelper, customFileHelper } from "../../../helpers/index.js";
import { StatusError } from "../../../config/index.js";
import fs from "fs";
import { GLOBAL_PARAMS } from "../../../utils/constants.js";
import {
  contentModificationService,
  notificationService,
  userPermissionService,
} from "../../../services/index.js";

/**
 * saveHeroSection
 * @param req
 * @param res
 */
export const saveHeroSection = async (req, res, next) => {
  try {
    const reqBody = req.body;
    const loginUserId = req.userDetails.userId;
    if (!loginUserId) {
      if (req.file && req.file.path) customFileHelper.customFileUnlink(fs, req.file.path);
      throw StatusError.badRequest(res.__("Invalid user id"));
    }
    const userRole = req.userDetails.user_type ?? "";
    const roleId = req.userDetails.user_role_id ?? "";
    if (!userRole) {
      if (req.file && req.file.path) customFileHelper.customFileUnlink(fs, req.file.path);
      throw StatusError.badRequest(res.__("Invalid user role"));
    }
    const setId = reqBody.id ? reqBody.id : "";
    const setnId = reqBody.setting_id ? reqBody.setting_id : "";
    let fileLocation = "";
    let fileName = "";
    let fileType = "image";
    if (req.file) {
      const fileDetails = req.file;
      fileName = fileDetails.filename ? fileDetails.filename : "";
      if (fileDetails.mimetype && fileDetails.mimetype.startsWith("image/")) {
        fileType = "image";
      } else if (fileDetails.mimetype && fileDetails.mimetype.startsWith("video/")) {
        fileType = "video";
      }
      fileLocation = fileDetails.destination ? fileDetails.destination + "/" + fileName : "";
    }
    if (
      !fileLocation &&
      !reqBody.hero_sec_main_heading &&
      !reqBody.hero_sec_sub_heading &&
      !reqBody.duration
    ) {
      throw StatusError.badRequest(res.__("Please provide a value for at least one field"));
    }
    let condition = {
      key_name: "home.page.landing_info",
    };
    const pageName = "home";
    if (setnId) {
      condition.id = setnId;
      // if(req.file.path)
      //   customFileHelper.customFileUnlink(fs,req.file.path);
      // throw StatusError.badRequest(res.__("Invalid id"));
    }

    // check for settings id existance in table
    const isExists = await model.siteSetting.findOne({
      where: condition,
    });

    if (!isExists && setnId) {
      if (req.file && req.file.path) customFileHelper.customFileUnlink(fs, req.file.path);
      throw StatusError.badRequest(res.__("Invalid id"));
    }
    let oldImag = "";
    let inx = 1;
    let oldDataRes = [];
    if (isExists) {
      const oldData = isExists.setting_value ? JSON.parse(isExists.setting_value) : [];
      if (oldData && oldData.length > 0 && oldData[oldData.length - 1].id) {
        inx = oldData[oldData.length - 1].id + 1;
      }
      oldDataRes = oldData;
      // oldData.map((rec)=>{

      // });
      // if(oldData[0].file_path){
      //   oldImag = oldData[0].file_path??"";
      // }
    }
    if (!setnId && !setId) {
      oldDataRes.push({
        id: inx,
        heading_text_1: reqBody.hero_sec_main_heading ?? "",
        heading_text_2: reqBody.hero_sec_sub_heading ?? "",
        duration: reqBody.duration ?? 0,
        file_path: fileLocation ? fileLocation : "",
        file_type: fileType,
      });
    } else {
      oldDataRes = oldDataRes.map((rec) => {
        if (rec.id == setId && rec.file_path && fileLocation) {
          oldImag = rec.file_path;
        }

        let recNew = rec;
        if (rec.id == setId) {
          recNew = {
            id: rec.id,
            heading_text_1: reqBody.hero_sec_main_heading ?? "",
            heading_text_2: reqBody.hero_sec_sub_heading ?? "",
            duration: reqBody.duration ?? 0,
            file_path: fileLocation ? fileLocation : rec.file_path,
            file_type: fileLocation ? fileType : rec.file_type,
          };
        } else if (rec.id && !setId) {
          recNew = {
            id: inx,
            heading_text_1: reqBody.hero_sec_main_heading ?? "",
            heading_text_2: reqBody.hero_sec_sub_heading ?? "",
            duration: reqBody.duration ?? 0,
            file_path: fileLocation ? fileLocation : rec.file_path,
            file_type: fileLocation ? fileType : rec.file_type,
          };
        }
        return recNew;
      });
    }
    // add details
    let reqDetails = {
      setting_value: JSON.stringify(oldDataRes),
    };
    if (!isExists && !setnId) {
      reqDetails.key_name = "home.page.landing_info";
      reqDetails.created_at = await customDateTimeHelper.getCurrentDateTime();
      reqDetails.created_by = loginUserId;
    } else {
      reqDetails.updated_at = await customDateTimeHelper.getCurrentDateTime();
      reqDetails.updated_by = loginUserId;
    }
    let updt = 0;
    let sucMess = "success";
    if (userRole == "superadmin" || userRole == "administrator" || userRole == "approver") {
      const check = await userPermissionService.checkUserPermission(roleId, loginUserId, [
        `pages.${pageName}.edit`,
      ]);
      if (check) {
        const [upResp] = await model.siteSetting.update(reqDetails, {
          where: condition,
        });
        if (upResp > 0) {
          updt = 1;
        }
      }
    } else {
      const checkForPendingRequest = await contentModificationService.checkForPendingRequest({
        id: setId,
        request_for: "home_page",
        action_type: "edit",
      });
      if (checkForPendingRequest) {
        throw StatusError.badRequest(
          res.__(
            "A modification request is already in progress. Please wait for the approval response and try again later.",
          ),
        );
      } else {
        let requestDetails = reqDetails;
        requestDetails.setting_name = !isExists.setting_name ? "" : isExists.setting_name;
        requestDetails.key_name = "home.page.landing_info";
        requestDetails.setting_id = setId;
        requestDetails.earlier_data = isExists ? JSON.stringify(isExists) : null;
        requestDetails.created_at = requestDetails.updated_at;
        requestDetails.created_by = requestDetails.updated_by;
        const insRes = await model.tempSiteSetting.create(requestDetails);

        if (insRes && insRes.id > 0) {
          sucMess =
            "Your modification request has been save successfully. Please wait for approval!";
          await contentModificationService.addRequest({
            temp_id: insRes.id,
            request_for: "home_page",
            action_type: "edit",
            created_at: requestDetails.updated_at,
            created_by: requestDetails.updated_by,
          });
          await notificationService.generateNotificationForContentApproval(
            {
              created_by: loginUserId,
              notification_type: "content_approval",
              type: "update",
              title: `A home content modification requested`,
              item_id: insRes.id,
              item_description: `A ${GLOBAL_PARAMS.SITE_CONTENT_KEY[insRes.key_name]} modification requested by publisher`,
              item: insRes,
            },
            null,
            [`pages.${pageName}.status_change`],
          );
          updt = 1;
        }
      }
    }
    if (updt > 0) {
      //if (req.file && req.file.path && oldImag) customFileHelper.customFileUnlink(fs, oldImag);
      res.ok({
        message: res.__(sucMess),
      });
    } else {
      if (req.file && req.file.path) customFileHelper.customFileUnlink(fs, req.file.path);
      throw StatusError.badRequest(res.__("SomeThingWentWrong"));
    }
  } catch (error) {
    console.log(error);
    if (req.file && req.file.path) customFileHelper.customFileUnlink(fs, req.file.path);
    next(error);
  }
};
