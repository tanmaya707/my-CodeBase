import model from "../../../models/index.js";
import { PAGINATION_LIMIT } from "../../../utils/constants.js";
import { paginationService } from "../../../services/index.js";
import { Sequelize, Op, col } from "sequelize";

/**
 * credentialCategoryList
 * @param req
 * @param res
 */
export const credentialCategoryList = async (req, res, next) => {
  try {
    const loginUserId = req.userDetails.userId;
    if (!loginUserId) throw StatusError.badRequest(res.__("Invalid user id"));
    const reqBody = req.query;
    const searchName = reqBody.name ? reqBody.name.trim() : "";
    let resultData = [];
    const defautlPageNo = 1;
    const page = reqBody.page ? reqBody.page : defautlPageNo;
    const limit = reqBody.limit ? reqBody.limit : PAGINATION_LIMIT;

    const sortOrder = reqBody.sort_order ? reqBody.sort_order : "desc";
    const sortBy = reqBody.sort_by ? reqBody.sort_by : "";

    let searchDateType = !reqBody.search_date_type ? "" : reqBody.search_date_type;
    const searchStartDate = reqBody.start_date ? reqBody.start_date : "";
    const searchEndDate = reqBody.end_date ? reqBody.end_date : "";

    const searchParams = {
      page: page,
      limit: limit,
    };

    let dateFilter = "credentialCategory.created_at";
    let condition = {};
    if (searchDateType == "created_date") {
      dateFilter = "credentialCategory.created_at";
    }
    let applyMoreand = false;
    // Add extra conditions for Startdate
    if (searchDateType && searchStartDate && !searchEndDate) {
      condition[Op.and] = [
        Sequelize.where(Sequelize.fn("DATE", Sequelize.col(dateFilter)), {
          [Op.gte]: searchStartDate,
        }),
      ];
      applyMoreand = true;
    }
    // Add extra conditions for Enddate
    if (searchDateType && searchEndDate && !searchStartDate) {
      condition[Op.and] = [
        Sequelize.where(Sequelize.fn("DATE", Sequelize.col(dateFilter)), {
          [Op.lte]: searchEndDate,
        }),
      ];
      applyMoreand = true;
    }
    // Add extra conditions for Startdate & EndDate
    if (searchDateType && searchStartDate && searchEndDate) {
      condition[Op.and] = [
        Sequelize.where(Sequelize.fn("DATE", Sequelize.col(dateFilter)), {
          [Op.between]: [searchStartDate, searchEndDate],
        }),
      ];
      applyMoreand = true;
    }

    const attributes = ["id", "uuid", ["name", "category_name"], "status", "created_at"];

    searchParams.sortOrderObj = [[Sequelize.literal("created_at"), sortOrder]];

    const includeQuery = [
      {
        model: model.credential,
        required: false,
      },
    ];
    if (searchName) {
      const arrName = searchName.split(" ");
      let orArr = [{ name: { [Op.like]: `%${searchName}%` } }];
      if (arrName.length > 1) {
        arrName.map((name) => {
          if (name) {
            orArr.push({ name: { [Op.like]: `%${name}%` } });
          }
        });
      }
      condition[Op.or] = orArr;
    }

    resultData = await paginationService.pagination(
      searchParams,
      model.credentialCategory,
      includeQuery,
      condition,
      attributes,
    );
    if (resultData.rows && resultData.rows.length > 0) {
      resultData.rows = resultData.rows.map((record) => {
        record.dataValues.credential_count =
          !record.dataValues &&
          !record.dataValues.credentials &&
          !record.dataValues.credentials.length
            ? 0
            : record.dataValues.credentials.length;
        delete record.dataValues.credentials;
        return record;
      });
    }
    res.ok({
      page: page,
      limit: limit,
      total_records: resultData.count,
      total_pages: resultData.count > 0 ? Math.ceil(resultData.count / limit) : 0,
      results: resultData.rows,
    });
  } catch (error) {
    console.log(error);
    next(error);
  }
};
