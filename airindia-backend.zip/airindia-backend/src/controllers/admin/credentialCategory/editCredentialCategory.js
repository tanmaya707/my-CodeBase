import model from "../../../models/index.js";
import { customDateTimeHelper, generalHelper } from "../../../helpers/index.js";
import { StatusError } from "../../../config/index.js";
import { Op } from "sequelize";
import {
  contentModificationService,
  notificationService,
  userPermissionService,
} from "../../../services/index.js";

/**
 * editCredentialCategory
 * @param req
 * @param res
 */
export const editCredentialCategory = async (req, res, next) => {
  try {
    const reqBody = req.body;
    const loginUserId = req.userDetails.userId;
    const credentialCategoryId = reqBody.id ? reqBody.id : "";

    if (!loginUserId) throw StatusError.badRequest(res.__("Invalid user id"));

    const userRole = req.userDetails.user_type ?? "";
    const roleId = req.userDetails.user_role_id ?? "";
    if (!userRole) {
      throw StatusError.badRequest(res.__("Invalid user role"));
    }

    if (!credentialCategoryId) throw StatusError.badRequest(res.__("Invalid id"));

    // check for credential category id existance in table
    const isExists = await model.credentialCategory.findOne({
      where: {
        id: credentialCategoryId,
      },
    });

    if (!isExists) throw StatusError.badRequest(res.__("Invalid id"));

    const searchName = reqBody.category_name;
    // checking for credentialCategory existance
    const credentialCategory = await model.credentialCategory.findOne({
      where: { name: { [Op.like]: `%${searchName}%` }, id: { [Op.ne]: credentialCategoryId } },
    });
    if (credentialCategory)
      throw StatusError.badRequest(res.__("Credential category is already taken"));

    const whl = true;
    let slugName = "";
    let rslug = searchName;
    let regenarate = false;
    if (isExists.name != rslug) {
      while (whl) {
        const generatedSlug = await generalHelper.generateSlugName(rslug, regenarate);
        // check for slug name existance in credential category table
        const isExists = await model.credentialCategory.findOne({
          where: { slug_name: generatedSlug },
          attributes: ["id", "slug_name"],
        });
        if (!isExists) {
          regenarate = false;
          slugName = generatedSlug;
          break;
        } else {
          regenarate = true;
          rslug = generatedSlug;
        }
      }
    } else {
      slugName = isExists.slug_name;
    }

    // edit details
    let requestDetails = {
      name: searchName,
      slug_name: slugName,
      status: reqBody.status,
      updated_at: await customDateTimeHelper.getCurrentDateTime(),
      updated_by: loginUserId,
    };
    let updt = 0;
    let sucMess = "success";
    if (userRole == "superadmin" || userRole == "administrator" || userRole == "approver") {
      const check = await userPermissionService.checkUserPermission(roleId, loginUserId, [
        "credential.edit",
      ]);
      if (check) {
        requestDetails.updated_at = await customDateTimeHelper.getCurrentDateTime();
        requestDetails.updated_by = loginUserId;
        const [upResp] = await model.credentialCategory.update(requestDetails, {
          where: { id: credentialCategoryId },
        });
        if (upResp > 0) {
          updt = 1;
        }
      }
    } else {
      const checkForPendingRequest = await contentModificationService.checkForPendingRequest({
        id: credentialCategoryId,
        request_for: "credential_categories",
        action_type: "edit",
      });
      if (checkForPendingRequest) {
        throw StatusError.badRequest(
          res.__(
            "A modification request is already in progress. Please wait for the approval response and try again later.",
          ),
        );
      } else {
        requestDetails.credential_category_id = credentialCategoryId;
        requestDetails.earlier_data = isExists ? JSON.stringify(isExists) : null;
        requestDetails.uuid = isExists.uuid;
        requestDetails.list_order = isExists.list_order;
        requestDetails.created_at = requestDetails.updated_at;
        requestDetails.created_by = requestDetails.updated_by;
        const insRes = await model.tempCredentialCategory.create(requestDetails);

        if (insRes && insRes.id > 0) {
          sucMess =
            "Your modification request has been save successfully. Please wait for approval!";
          await contentModificationService.addRequest({
            temp_id: insRes.id,
            request_for: "credential_categories",
            action_type: "edit",
            created_at: requestDetails.updated_at,
            created_by: requestDetails.updated_by,
          });
          await notificationService.generateNotificationForContentApproval(
            {
              created_by: loginUserId,
              notification_type: "content_approval",
              type: "update",
              title: `A credential category modification requested`,
              item_id: insRes.id,
              item_description: `A credential category, ${insRes.name} modification requested by publisher`,
              item: insRes,
            },
            null,
            ["credential.status_change"],
          );
          updt = 1;
        }
      }
    }
    if (updt > 0) {
      res.ok({
        message: res.__(sucMess),
      });
    } else {
      throw StatusError.badRequest(res.__("SomeThingWentWrong"));
    }
  } catch (error) {
    console.log(error);
    next(error);
  }
};
