import model from "../../../models/index.js";
import { StatusError } from "../../../config/index.js";

/**
 * credentialCategoryDetails
 * @param req
 * @param res
 */
export const credentialCategoryDetails = async (req, res, next) => {
  try {
    const loginUserId = req.userDetails.userId;
    if (!loginUserId) throw StatusError.badRequest(res.__("Invalid user id"));
    const reqBody = req.params;
    const credentialCategoryId = reqBody.id ? reqBody.id : "";
    if (!credentialCategoryId) throw StatusError.badRequest(res.__("Invalid id"));

    const checkId = await model.credentialCategory.count({
      where: { id: credentialCategoryId },
    });
    if (checkId == 0) throw StatusError.badRequest(res.__("Invalid id"));

    let resultData = {};
    const condition = { id: credentialCategoryId };
    const attributes = [
      "id",
      "uuid",
      ["name", "category_name"],
      "slug_name",
      "list_order",
      "status",
      "created_by",
      "created_at",
      "updated_by",
      "updated_at",
    ];

    const includeQuery = [
      {
        model: model.credential,
        attributes: ["id"],
        //where: { status: "active" },
        required: false,
      },
    ];

    resultData = await model.credentialCategory.findOne({
      attributes: attributes,
      include: includeQuery,
      where: condition,
    });

    if (resultData && resultData.dataValues && resultData.dataValues.credentials) {
      resultData.dataValues.credential_count = resultData.dataValues.credentials.length ?? 0;
    }
    delete resultData.dataValues.credentials;

    res.ok(resultData ? resultData : {});
  } catch (error) {
    next(error);
  }
};
