import model from "../../../models/index.js";
import { Op } from "sequelize";
import { StatusError } from "../../../config/index.js";
import { customDateTimeHelper, customFileHelper } from "../../../helpers/index.js";
import fs from "fs";

/**
 * deleteProfileImage
 * @param req
 * @param res
 */
export const deleteProfileImage = async (req, res, next) => {
  try {
    const userLogId = req.userDetails.userId?req.userDetails.userId:null;
    if (!userLogId) throw StatusError.badRequest(res.__("Invalid user id"));
    const reqBody = req.body;
    const userId = !reqBody.user_id?userLogId:reqBody.user_id;
    if (!userId) throw StatusError.badRequest(res.__("Invalid id"));

    const checkUserId = await model.user.count({
      where: { id: userId },
    });
    if (checkUserId == 0) throw StatusError.badRequest(res.__("Invalid id"));
    const oldImage = await model.user.findOne({
      attributes: ["id", "avatar"],
      where:{id: userId}
    });
    const result = await model.user.update(
      {
        avatar: null,
        updated_at: await customDateTimeHelper.getCurrentDateTime(),
        updated_by: userLogId,
      },
      { where: { id: userId } },
    );

    if (result && result.length > 0) {
      if(oldImage.avatar){
        customFileHelper.customFileUnlink(fs,oldImage.avatar);
      }
      res.ok({
        message: res.__("profile image removed successfully"),
      });
    } else {
      throw StatusError.serverError(res.__("something went wrong"));
    }
  } catch (error) {
    next(error);
  }
};
