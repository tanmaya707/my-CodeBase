import { profileDetails } from "./profileDetails.js";
import { deleteProfileImage } from "./deleteProfileImage.js";
import { editProfile } from "./editProfile.js";
import { changePassword } from "./changePassword.js";
import { logout } from "./logout.js";

export { profileDetails, deleteProfileImage, editProfile, changePassword, logout };
