import model from "../../../models/index.js";
import { customDateTimeHelper } from "../../../helpers/index.js";
import { StatusError } from "../../../config/index.js";

/**
 * logout
 * @param req
 * @param res
 */
export const logout = async (req, res, next) => {
  try {
    const userLogId = req.userDetails.userId ? req.userDetails.userId : null;
    if (!userLogId) throw StatusError.badRequest(res.__("Invalid user id"));

    const reqBody = req.body;
    const userId = !reqBody.user_id ? userLogId : reqBody.user_id;

    // checking for user existance
    const userDetails = await model.user.findOne({ where: { id: userId } });
    if (!userDetails) throw StatusError.badRequest(res.__("user is not registered"));

    const result = await model.user.update(
      {
        api_token: null,
        updated_at: await customDateTimeHelper.getCurrentDateTime(),
        updated_by: userLogId,
      },
      { where: { id: userId } },
    );

    if (result && result.length > 0) {
      res.ok({
        message: res.__("logged out successfully"),
      });
    } else {
      throw StatusError.serverError(res.__("something went wrong"));
    }
  } catch (error) {
    next(error);
  }
};
