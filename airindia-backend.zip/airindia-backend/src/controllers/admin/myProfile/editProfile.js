import model from "../../../models/index.js";
import { customDateTimeHelper, customFileHelper } from "../../../helpers/index.js";
import { StatusError } from "../../../config/index.js";
import fs from "fs";

/**
 * editProfile
 * @param req
 * @param res
 */
export const editProfile = async(req, res, next) => {
  try {
    const reqBody = req.body;
    const userId = req.userDetails.userId?req.userDetails.userId:null;
    let fileLocation = "";
    let fileName = "";
    if (req.file) {
      const fileDetails = req.file;
      fileName = fileDetails.filename ? fileDetails.filename : "";
      fileLocation = fileDetails.destination ? fileDetails.destination+'/'+fileName : "";
    }
    if (!userId){ 
      if(req.file.path)
        customFileHelper.customFileUnlink(fs,req.file.path);
      throw StatusError.badRequest(res.__("Invalid id")); 
    }
    const fullName = reqBody.name ? reqBody.name : "";
    const firstName = fullName.substring(0, fullName.indexOf(" "))
      ? fullName.substring(0, fullName.indexOf(" "))
      : fullName.substring(fullName.indexOf(" ") + 1);
    const lastName = !fullName.substring(0, fullName.indexOf(" "))
      ? ""
      : fullName.substring(fullName.indexOf(" ") + 1);

    if (!userId){ 
      if(req.file.path)
        customFileHelper.customFileUnlink(fs,req.file.path);
      throw StatusError.badRequest(res.__("Invalid id")); 
    }

    // check for user id existance in table
    const isExistsUser = await model.user.findOne({
      attributes: ["id", "email", "created_by","avatar"],
      where: {
        id: userId,
      },
    });

    if (!isExistsUser){
      if(req.file.path)
        customFileHelper.customFileUnlink(fs,req.file.path);
      throw StatusError.badRequest(res.__("Invalid id"));
    }

    // add details
    let userDetails = {
      first_name: firstName,
      last_name: lastName,
      avatar: fileLocation,
      updated_at: await customDateTimeHelper.getCurrentDateTime(),
      updated_by: userId,
    };
    const [userInformation] = await model.user.update(userDetails, {
      where: { id: userId },
    });

    if (userInformation > 0) {
      if(req.file.path && isExistsUser.avatar){
        customFileHelper.customFileUnlink(fs, isExistsUser.avatar);
      }
      res.ok({
        message: res.__("success"),
      });
    } else {
      if(req.file.path)
        customFileHelper.customFileUnlink(fs, req.file.path);

      throw StatusError.badRequest(res.__("SomeThingWentWrong"));
    }
  } catch (error) {
    if(req.file)
      customFileHelper.customFileUnlink(fs, req.file.path);
    next(error);
  }
};
