import model from "../../../models/index.js";
import { Sequelize, Op, col, fn } from "sequelize";
import { StatusError, envs } from "../../../config/index.js";

/**
 * profileDetails
 * @param req
 * @param res
 */
export const profileDetails = async (req, res, next) => {
  try {
    const userId = req.userDetails.userId?req.userDetails.userId:null;
    if (!userId) throw StatusError.badRequest(res.__("Invalid id"));
    const checkUserId = await model.user.count({
      where: { id: userId },
    });
    if (checkUserId == 0) throw StatusError.badRequest(res.__("Invalid id"));

    let resultData = {};
    const condition = { id: userId };
    const attributes = [
      "id",
      "first_name",
      "last_name",
      [Sequelize.literal(`CONCAT(first_name, ' ', last_name)`), "name"],
      [Sequelize.literal(`"******"`), "password"],
      "email",
      [col("userRole.role.role_name"), "role"],
      [col("userRole.role.id"), "role_id"],
      [col("userRole.role.role_display_name"), "role_name"],
      [
        fn(
        "REPLACE",
        col("avatar"),
        `public/uploads/`,
        `${envs.siteUrl}api/v1/public/`,
        ),
        "user_image",
      ],
      "created_at",
    ];

    const includeQuery = [
      {
        model: model.userRole,
        attributes: [],
        where: { status: "active" },
        required: true,
        include: [
          { model: model.role, attributes: [], where: { status: "active" }, required: true },
        ],
      },
    ];

    resultData = await model.user.findOne({
      attributes: attributes,
      include: includeQuery,
      where: condition,
    });

    if (resultData && resultData.dataValues) {
      resultData.dataValues.role = res.__(resultData.dataValues.role);
    }

    res.ok(resultData ? resultData : {});
  } catch (error) {
    console.log(error);
    next(error);
  }
};
