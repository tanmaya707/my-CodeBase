import model from "../../../models/index.js";
import { customDateTimeHelper } from "../../../helpers/index.js";
import { StatusError } from "../../../config/index.js";
import { Op } from "sequelize";
/**
 * addCertificate
 * @param req
 * @param res
 */
export const addCertificate = async (req, res, next) => {
  try {
    console.log(req.body);

    const { name, description, icon, order_no } = req.body;

    let certificateDetails = {
      name: name,
      description: description,
      // icon:icon,
      order_no: order_no,
      created_at: await customDateTimeHelper.getCurrentDateTime(),
      created_by: req.userDetails.userId,
    };

    // check for certificate  existance in table
    const isExistsService = await model.certificate.findOne({
      attributes: ["id"],
      where: {
        name: name,
        status: { [Op.ne]: "deleted" },
      },
    });

    if (isExistsService) throw StatusError.badRequest(res.__("certificateAlreadyExists"));

    const certificateInformation = await model.certificate.create(certificateDetails);

    if (certificateInformation && certificateInformation.id > 0) {
      res.ok({
        message: res.__("success"),
        data: certificateInformation,
      });
    } else {
      throw StatusError.badRequest(res.__("SomeThingWentWrong"));
    }
  } catch (error) {
    next(error);
  }
};
