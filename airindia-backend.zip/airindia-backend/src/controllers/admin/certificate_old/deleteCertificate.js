import model from "../../../models/index.js";
import { Op } from "sequelize";
import { StatusError } from "../../../config/index.js";
import { customDateTimeHelper } from "../../../helpers/index.js";

/**
 * deleteCertificate
 * @param req
 * @param res
 */
export const deleteCertificate = async (req, res, next) => {
  try {
    const reqBody = req.body;
    const certificateId = reqBody.id ? reqBody.id : "";
    if (!certificateId) throw StatusError.badRequest(res.__("Invalid id"));

    const checkCertificateId = await model.certificate.count({
      where: { status: { [Op.ne]: "deleted" }, id: certificateId },
    });
    if (checkCertificateId == 0) throw StatusError.badRequest(res.__("Invalid id"));

    const certificateDetails = {
      status: "deleted",
      deleted_at: await customDateTimeHelper.getCurrentDateTime(),
      deleted_by: req.userDetails.userId,
    };
    const [certificateInformation] = await model.certificate.update(certificateDetails, {
      where: { id: certificateId },
    });
    if (certificateInformation > 0) {
      res.ok({
        message: res.__("success"),
      });
    } else {
      throw StatusError.badRequest(res.__("SomeThingWentWrong"));
    }
  } catch (error) {
    next(error);
  }
};
