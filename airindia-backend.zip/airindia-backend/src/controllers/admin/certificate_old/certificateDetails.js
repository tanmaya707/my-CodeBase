import model from "../../../models/index.js";
import { Op } from "sequelize";
import { StatusError } from "../../../config/index.js";

/**
 * certificateDetails
 * @param req
 * @param res
 */
export const certificateDetails = async (req, res, next) => {
  try {
    const reqBody = req.params;
    const certificateId = reqBody.id ? reqBody.id : "";
    if (!certificateId) throw StatusError.badRequest(res.__("Invalid id"));

    const checkCertificateId = await model.certificate.count({
      where: { status: { [Op.ne]: "deleted" }, id: certificateId },
    });
    if (checkCertificateId == 0) throw StatusError.badRequest(res.__("Invalid id"));

    let resultData = {};
    const condition = { status: { [Op.ne]: "deleted" }, id: certificateId };
    const attributes = [
      "id",
      "name",
      "description",
      "icon",
      "order_no",
      "created_at",
    ];

    const includeQuery = [];

    resultData = await model.certificate.findOne({
      attributes: attributes,
      include: includeQuery,
      where: condition,
    });

    res.ok(resultData ? resultData : {});
  } catch (error) {
    next(error);
  }
};
