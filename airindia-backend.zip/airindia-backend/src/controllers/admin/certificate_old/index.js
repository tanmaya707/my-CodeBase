import { addCertificate } from "./addCertificate.js";
import { certificateList } from "./certificateList.js";
import { editCertificate } from "./editCertificate.js";
import { deleteCertificate } from "./deleteCertificate.js";
import { certificateDetails } from "./certificateDetails.js";

export { addCertificate, certificateList, editCertificate, deleteCertificate, certificateDetails };
