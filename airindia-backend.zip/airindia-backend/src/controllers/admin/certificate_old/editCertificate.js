import model from "../../../models/index.js";
import { customDateTimeHelper } from "../../../helpers/index.js";
import { StatusError } from "../../../config/index.js";
import { Op } from "sequelize";

/**
 * editCertificate
 * @param req
 * @param res
 */
export const editCertificate = async (req, res, next) => {
  try {
    const loginUserId = req.userDetails.userId;
    const { id, name, description, caption, icon, order_no } = req.body;

    if (!id) throw StatusError.badRequest(res.__("Invalid id"));

    // check for certificate id existance in table
    const isExistsCertificate = await model.certificate.findOne({
      attributes: ["id", "name", "created_by"],
      where: {
        id: id,
        status: { [Op.ne]: "deleted" },
      },
    });

    if (!isExistsCertificate) throw StatusError.badRequest(res.__("Invalid id"));

    let certificateDetails = {
      name: name,
      description: description,
      // icon:icon,
      order_no: order_no,
      updated_at: await customDateTimeHelper.getCurrentDateTime(),
      updated_by: loginUserId,
    };

    const [certificateInformation] = await model.certificate.update(certificateDetails, {
      where: { id: id },
    });

    if (certificateInformation > 0) {
      res.ok({
        message: res.__("success"),
      });
    } else {
      throw StatusError.badRequest(res.__("SomeThingWentWrong"));
    }
  } catch (error) {
    next(error);
  }
};
