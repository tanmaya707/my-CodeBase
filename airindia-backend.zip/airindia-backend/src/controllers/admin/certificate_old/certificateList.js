import model from "../../../models/index.js";
import { PAGINATION_LIMIT } from "../../../utils/constants.js";
import { paginationService } from "../../../services/index.js";
import { Sequelize, Op, col } from "sequelize";

/**
 * certificateList
 * @param req
 * @param res
 */
export const certificateList = async (req, res, next) => {
  try {
    const reqBody = req.query;

    const searchName = reqBody.name ? reqBody.name.trim() : "";
    let resultData = [];
    const defautlPageNo = 1;
    const page = reqBody.page ? reqBody.page : defautlPageNo;
    const limit = reqBody.limit ? reqBody.limit : PAGINATION_LIMIT;

    const sortOrder = reqBody.sort_order ? reqBody.sort_order : "desc";
    const sortBy = reqBody.sort_by ? reqBody.sort_by : "";

    const loginUserId = req.userDetails.userId;
    const searchParams = {
      page: page,
      limit: limit,
    };

    let condition = { status: { [Op.ne]: "deleted" } };

    const attributes = [
      "id",
      "name",
      "description",
      "icon",
      "order_no",
      "created_at",
    ];

    if (sortOrder && sortBy == "name") {
      searchParams.sortOrderObj = [[Sequelize.literal("name"), sortOrder]];
    } else if (sortOrder && sortBy == "created_at") {
      searchParams.sortOrderObj = [[Sequelize.literal("created_at"), sortOrder]];
    } else {
      searchParams.sortOrderObj = [[Sequelize.literal("created_at"), sortOrder]];
    }

    const includeQuery = [];
    if (searchName) {
      let orArr = [{ name: { [Op.like]: `%${searchName}%` } }];

      condition[Op.or] = orArr;
    }

    resultData = await paginationService.pagination(
      searchParams,
      model.certificate,
      includeQuery,
      condition,
      attributes,
    );
    if (resultData.rows && resultData.rows.length > 0) {
      resultData.rows = resultData.rows.map((certificate) => {
        certificate.dataValues.certificate = res.__(certificate.dataValues.certificate);
        return certificate;
      });
    }
    res.ok({
      page: page,
      limit: limit,
      total_records: resultData.count,
      total_pages: resultData.count > 0 ? Math.ceil(resultData.count / limit) : 0,
      results: resultData.rows,
    });
  } catch (error) {    
    next(error);
  }
};
