import { addTeam } from "./addTeam.js";
import { teamList } from "./teamList.js";
import { editTeam } from "./editTeam.js";
import { deleteTeam } from "./deleteTeam.js";
import { teamDetails } from "./teamDetails.js";

export { addTeam, teamList, editTeam, deleteTeam, teamDetails };
