import model from "../../../models/index.js";
import { Op, col, fn } from "sequelize";
import { StatusError, envs } from "../../../config/index.js";

/**
 * teamDetails
 * @param req
 * @param res
 */
export const teamDetails = async (req, res, next) => {
  try {
    const reqBody = req.params;
    const id = reqBody.id ? reqBody.id : "";
    if (!id) throw StatusError.badRequest(res.__("Invalid id"));

    const checkId = await model.team.count({
      where: { id: id },
    });
    if (checkId == 0) throw StatusError.badRequest(res.__("Invalid id"));

    let resultData = {};
    const condition = { id: id };
    const attributes = [
      "id",
      "uuid",
      "member_name",
      "designation",
      "description",
      "slug_name",
      "list_order",
      "facebook_link",
      "linkedin_link",
      "twitter_link",
      [fn("REPLACE", col("file_path"), `public/uploads/`, `public/`), "file_path"],
      "status",
      "created_at",
    ];

    const includeQuery = [];

    resultData = await model.team.findOne({
      attributes: attributes,
      include: includeQuery,
      where: condition,
    });

    res.ok(resultData ? resultData : {});
  } catch (error) {
    next(error);
  }
};
