import model from "../../../models/index.js";
import { PAGINATION_LIMIT } from "../../../utils/constants.js";
import { paginationService, notificationService } from "../../../services/index.js";
import { Sequelize, Op, col, fn } from "sequelize";

/**
 * notificationList
 * @param req
 * @param res
 */
export const notificationList = async (req, res, next) => {
  try {
    const reqBody = req.query;

    const searchName = reqBody.name ? reqBody.name.trim() : "";
    let resultData = [];
    const defautlPageNo = 1;
    const page = reqBody.page ? reqBody.page : defautlPageNo;
    const limit = reqBody.limit ? reqBody.limit : PAGINATION_LIMIT;

    const sortOrder = reqBody.sort_order ? reqBody.sort_order : "desc";
    const sortBy = reqBody.sort_by ? reqBody.sort_by : "";

    const loginUserId = req.userDetails.userId;
    const searchParams = {
      page: page,
      limit: limit,
    };

    let condition = { user_id: loginUserId };

    const attributes = [
      "id",
      "uuid",
      "user_id",
      "type",
      "title",
      "content",
      "is_read",
      "created_at",
    ];

    if (sortOrder && sortBy == "name") {
      searchParams.sortOrderObj = [[Sequelize.literal("title"), sortOrder]];
    } else if (sortOrder && sortBy == "created_at") {
      searchParams.sortOrderObj = [[Sequelize.literal("created_at"), sortOrder]];
    } else {
      searchParams.sortOrderObj = [[Sequelize.literal("created_at"), sortOrder]];
    }

    const includeQuery = [];
    if (searchName) {
      let orArr = [
        { title: { [Op.like]: `%${searchName}%` } },
        { content: { [Op.like]: `%${searchName}%` } },
      ];

      condition[Op.or] = orArr;
    }

    resultData = await paginationService.pagination(
      searchParams,
      model.notification,
      includeQuery,
      condition,
      attributes,
    );

    res.ok({
      page: page,
      limit: limit,
      total_records: resultData.count,
      total_unread_record: await notificationService.userUnreadNotification(loginUserId, "count"),
      total_pages: resultData.count > 0 ? Math.ceil(resultData.count / limit) : 0,
      results: resultData.rows,
    });
  } catch (error) {
    console.log(error);
    next(error);
  }
};
