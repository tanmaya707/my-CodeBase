import model from "../../../models/index.js";
import { StatusError } from "../../../config/index.js";
import { customDateTimeHelper } from "../../../helpers/index.js";

/**
 * markAllReadNotification
 * @param req
 * @param res
 */
export const markAllReadNotification = async (req, res, next) => {
  try {
    const userId = req.userDetails.userId ? req.userDetails.userId : null;
    if (!userId) throw StatusError.badRequest(res.__("Invalid User"));
    const checkUserId = await model.user.count({
      where: { id: userId },
    });
    if (checkUserId == 0) throw StatusError.badRequest(res.__("Invalid User"));

    let resultData = {};
    const condition = { is_read: "n", user_id: userId };
    const attributes = ["id", "user_id"];

    const includeQuery = [];

    resultData = await model.notification.findAll({
      attributes: attributes,
      include: includeQuery,
      where: condition,
    });

    if (resultData && resultData.length > 0) {
      let updateDetails = {
        is_read: "y",
        updated_at: await customDateTimeHelper.getCurrentDateTime(),
        updated_by: userId,
      };
      const [notificationInformation] = await model.notification.update(updateDetails, {
        where: { user_id: userId, is_read: "n" },
      });

      if (notificationInformation > 0) {
        res.ok({
          message: res.__("success"),
        });
      } else {
        throw StatusError.badRequest(res.__("SomeThingWentWrong"));
      }
    } else {
      res.ok({
        message: res.__("success"),
      });
    }
  } catch (error) {
    console.log(error);
    next(error);
  }
};
