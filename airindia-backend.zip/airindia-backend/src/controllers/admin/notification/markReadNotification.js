import model from "../../../models/index.js";
import { StatusError } from "../../../config/index.js";
import { customDateTimeHelper } from "../../../helpers/index.js";

/**
 * markReadNotification
 * @param req
 * @param res
 */
export const markReadNotification = async (req, res, next) => {
  try {
    const userId = req.userDetails.userId ? req.userDetails.userId : null;
    const id = req.body.id ? req.body.id : null;
    if (!userId) throw StatusError.badRequest(res.__("Invalid User"));
    const checkUserId = await model.user.count({
      where: { id: userId },
    });
    if (checkUserId == 0) throw StatusError.badRequest(res.__("Invalid User"));

    const checkNotificationId = await model.notification.count({
      where: { id: id, user_id: userId },
    });
    if (checkNotificationId == 0) throw StatusError.badRequest(res.__("Invalid id"));

    let updateDetails = {
      is_read: "y",
      updated_at: await customDateTimeHelper.getCurrentDateTime(),
      updated_by: userId,
    };
    const [notificationInformation] = await model.notification.update(updateDetails, {
      where: { id: id, user_id: userId },
    });

    if (notificationInformation > 0) {
      res.ok({
        message: res.__("success"),
      });
    } else {
      throw StatusError.badRequest(res.__("SomeThingWentWrong"));
    }
  } catch (error) {
    console.log(error);
    next(error);
  }
};
