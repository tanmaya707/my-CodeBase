import model from "../../../models/index.js";
import { customDateTimeHelper, customFileHelper } from "../../../helpers/index.js";
import { StatusError } from "../../../config/index.js";
import fs from "fs";
import { GLOBAL_PARAMS } from "../../../utils/constants.js";
import {
  contentModificationService,
  notificationService,
  userPermissionService,
} from "../../../services/index.js";

/**
 * deleteCareerCtaImage
 * @param req
 * @param res
 */
export const deleteCareerCtaImage = async (req, res, next) => {
  try {
    const reqBody = req.body;
    const loginUserId = req.userDetails.userId;
    if (!loginUserId) {
      throw StatusError.badRequest(res.__("Invalid user id"));
    }
    const userRole = req.userDetails.user_type ?? "";
    const roleId = req.userDetails.user_role_id ?? "";
    if (!userRole) {
      throw StatusError.badRequest(res.__("Invalid user role"));
    }
    const setId = reqBody.id ? reqBody.id : "";
    const setnId = reqBody.setting_id ? reqBody.setting_id : "";

    let condition = {
      page_name: "about_us",
      key_name: "about_us.career_cta",
      id: setnId,
    };
    const pageName = "about_us";
    // check for settings id existance in table
    const isExists = await model.sitePage.findOne({
      where: condition,
    });

    if (!isExists) {
      throw StatusError.badRequest(res.__("Invalid id"));
    }

    let oldData = isExists.page_value ? JSON.parse(isExists.page_value) : {};
    const oldIdDataChk =
      oldData && oldData.files && oldData.files.length > 0
        ? oldData.files.filter((rec) => {
            if (rec.image_id == setId) {
              return true;
            } else {
              return false;
            }
          })
        : [];

    if (oldIdDataChk && oldIdDataChk.length == 0) {
      throw StatusError.badRequest(res.__("Invalid id"));
    }

    let oldImags = [];
    const oldDataResImgs =
      oldData && oldData.files && oldData.files.length > 0
        ? oldData.files.filter((rec) => {
            if (rec.image_id == setId) {
              if (rec.file_path) {
                oldImags.push({ path: rec.file_path });
              }
              return false;
            } else {
              return true;
            }
          })
        : [];
    // add details
    let reqDetails = {
      page_value: JSON.stringify({
        heading: oldData && oldData.heading ? oldData.heading : "",
        content: oldData && oldData.content ? oldData.content : "",
        botton_txt: oldData && oldData.botton_txt ? oldData.botton_txt : "",
        detail_link: oldData && oldData.detail_link ? oldData.detail_link : "",
        files: oldDataResImgs,
      }),
      updated_at: await customDateTimeHelper.getCurrentDateTime(),
      updated_by: loginUserId,
    };
    let updt = 0;
    let sucMess = "success";
    if (userRole == "superadmin" || userRole == "administrator" || userRole == "approver") {
      const check = await userPermissionService.checkUserPermission(roleId, loginUserId, [
        `pages.${pageName}.edit`,
      ]);
      if (check) {
        const [upResp] = await model.sitePage.update(reqDetails, {
          where: condition,
        });
        if (upResp > 0) {
          updt = 1;
        }
      }
    } else {
      const checkForPendingRequest = await contentModificationService.checkForPendingRequest({
        id: setnId,
        request_for: "page_content",
        action_type: "edit",
      });
      if (checkForPendingRequest) {
        throw StatusError.badRequest(
          res.__(
            "A modification request is already in progress. Please wait for the approval response and try again later.",
          ),
        );
      } else {
        let requestDetails = reqDetails;
        requestDetails.site_page_id = setnId;
        requestDetails.key_name = "about_us.career_cta";
        requestDetails.page_name = "about_us";
        requestDetails.earlier_data = isExists ? JSON.stringify(isExists) : null;
        requestDetails.created_at = requestDetails.updated_at;
        requestDetails.created_by = requestDetails.updated_by;
        const insRes = await model.tempSitePage.create(requestDetails);

        if (insRes && insRes.id > 0) {
          sucMess =
            "Your modification request has been save successfully. Please wait for approval!";
          await contentModificationService.addRequest({
            temp_id: insRes.id,
            request_for: "page_content",
            action_type: "edit",
            created_at: requestDetails.updated_at,
            created_by: requestDetails.updated_by,
          });
          await notificationService.generateNotificationForContentApproval(
            {
              created_by: loginUserId,
              notification_type: "content_approval",
              type: "update",
              title: `A page content modification requested`,
              item_id: insRes.id,
              item_description: `A ${GLOBAL_PARAMS.PAGE_CONTENT_KEY[insRes.key_name]} modification requested by publisher`,
              item: insRes,
            },
            null,
            [`pages.${pageName}.status_change`],
          );
          updt = 1;
        }
      }
    }
    if (updt > 0) {
      // if (oldImags && oldImags.length > 0) {
      //   oldImags.map((eachFile) => {
      //     if (eachFile.path) customFileHelper.customFileUnlink(fs, eachFile.path);
      //   });
      // }
      res.ok({
        message: res.__(sucMess),
      });
    } else {
      throw StatusError.badRequest(res.__("SomeThingWentWrong"));
    }
  } catch (error) {
    console.log(error);
    next(error);
  }
};
