import { aboutUs } from "./aboutUs.js";
import { partnerList } from "./partnerList.js";
import { saveAboutBanner } from "./saveAboutBanner.js";
import { saveNewsEvent } from "./saveNewsEvent.js";
import { saveAboutText } from "./saveAboutText.js";
import { savePartner } from "./savePartner.js";
import { saveBusinessExcellence } from "./saveBusinessExcellence.js";
import { saveCareerCta } from "./saveCareerCta.js";
import { deleteCareerCtaImage } from "./deleteCareerCtaImage.js";
import { moreAboutUs } from "./moreAboutUs.js";
import { saveMoreAboutBanner } from "./saveMoreAboutBanner.js";
import { saveMoreAboutText } from "./saveMoreAboutText.js";
import { saveMoreAboutCompanyInfo } from "./saveMoreAboutCompanyInfo.js";
import { saveMoreAboutMainContent } from "./saveMoreAboutMainContent.js";
import { saveMoreAboutClient } from "./saveMoreAboutClient.js";
import { saveMoreAboutClientReview } from "./saveMoreAboutClientReview.js";

export {
  aboutUs,
  partnerList,
  saveAboutBanner,
  saveNewsEvent,
  saveAboutText,
  savePartner,
  saveBusinessExcellence,
  saveCareerCta,
  deleteCareerCtaImage,
  moreAboutUs,
  saveMoreAboutBanner,
  saveMoreAboutText,
  saveMoreAboutCompanyInfo,
  saveMoreAboutClientReview,
  saveMoreAboutClient,
  saveMoreAboutMainContent,
};
