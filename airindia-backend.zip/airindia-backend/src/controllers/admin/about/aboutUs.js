import model from "../../../models/index.js";
import { StatusError, envs } from "../../../config/index.js";
import { Op, fn, col } from "sequelize";

/**
 *get about us details
 * @param req
 * @param res
 * @param next
 */
export const aboutUs = async (req, res, next) => {
  try {
    const keyName = "about_us.";
    let getInfo = await model.sitePage.findAll({
      where: {
        page_name: "about_us",
        key_name: { [Op.like]: `%${keyName}%` },
        status: "active",
      },
      attributes: ["id", "key_name", "page_value"],
    });
    let data = {};
    if (getInfo && getInfo.length > 0) {
      for (const row of getInfo) {
        let pVa = row.page_value ? JSON.parse(row.page_value) : "";

        if (row.key_name == "about_us.banner") {
          if (pVa && pVa.file_path) {
            pVa.file_path = pVa.file_path.replace(`public/uploads/`, `public/`);
          }
        }
        if (row.key_name == "about_us.about_text") {
          if (pVa && pVa.file_path) {
            pVa.file_path = pVa.file_path.replace(`public/uploads/`, `public/`);
          }
        }
        if (row.key_name == "about_us.main_content") {
          if (pVa && pVa.file_path) {
            pVa.file_path = pVa.file_path.replace(`public/uploads/`, `public/`);
          }
          if (pVa && pVa.file_path_1) {
            pVa.file_path_1 = pVa.file_path_1.replace(`public/uploads/`, `public/`);
          }
        }
        if (row.key_name == "about_us.career_cta") {
          if (pVa && pVa.files && pVa.files.length) {
            pVa.files = pVa.files.map((record) => {
              record.image_id = record.image_id ?? "";
              record.file_path = record.file_path.replace(`public/uploads/`, `public/`);
              return record;
            });
          }
        }
        if (row.key_name == "about_us.news_event") {
          pVa = { list: pVa };
        }
        data[row.key_name.replace(keyName, "")] = { id: row.id, ...pVa };
      }
    }
    if (data) {
      res.ok(data);
    } else {
      throw StatusError.notFound(res.__("data not found"));
    }
  } catch (error) {
    console.log(error);
    next(error);
  }
};
