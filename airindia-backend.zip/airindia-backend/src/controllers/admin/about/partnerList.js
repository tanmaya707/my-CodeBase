import model from "../../../models/index.js";
import { Op, fn, col } from "sequelize";

/**
 * partnerList
 * @param req
 * @param res
 */
export const partnerList = async (req, res, next) => {
  try {
    const reqBody = req.query;
    let condition = { status: "active" };
    if (reqBody.search_name) {
      condition.company_name = { [Op.like]: `%${reqBody.search_name}%` };
    }
    const list = await model.client.findAll({
      attributes: [
        "id",
        "uuid",
        "company_name",
        [fn("REPLACE", col("file_path"), `public/uploads/`, `public/`), "file_path"],
      ],
      where: condition,
      order: [["id", "desc"]],
      //limit: 20,
    });
    res.ok({
      results: list,
    });
  } catch (error) {
    console.log(error);
    next(error);
  }
};
