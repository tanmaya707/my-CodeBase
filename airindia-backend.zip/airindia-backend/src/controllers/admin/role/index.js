import { roleDetails } from "./roleDetails.js";
import { deleteRole } from "./deleteRole.js";
import { addRole } from "./addRole.js";
import { editRole } from "./editRole.js";
import { roleList } from "./roleList.js";

export { roleDetails, deleteRole, addRole, editRole, roleList };
