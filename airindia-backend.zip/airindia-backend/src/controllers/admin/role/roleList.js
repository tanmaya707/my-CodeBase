import model from "../../../models/index.js";
import { PAGINATION_LIMIT } from "../../../utils/constants.js";
import { paginationService } from "../../../services/index.js";
import { Sequelize, Op } from "sequelize";

/**
 * roleList
 * @param req
 * @param res
 */
export const roleList = async (req, res, next) => {
  try {
    const loginUserId = req.userDetails.userId;
    if (!loginUserId) throw StatusError.badRequest(res.__("Invalid user id"));
    const reqBody = req.query;
    const searchName = reqBody.name ? reqBody.name.trim() : "";
    let resultData = [];
    const defautlPageNo = 1;
    const page = reqBody.page ? reqBody.page : defautlPageNo;
    const limit = reqBody.limit ? reqBody.limit : PAGINATION_LIMIT;

    const sortOrder = reqBody.sort_order ? reqBody.sort_order : "desc";
    const sortBy = reqBody.sort_by ? reqBody.sort_by : "id";

    const searchParams = {
      page: page,
      limit: limit,
    };

    let condition = { defaults: 0 };

    const attributes = ["id", "role_display_name", "status", "created_at"];

    searchParams.sortOrderObj = [[Sequelize.literal(sortBy), sortOrder]];

    const includeQuery = [
      {
        model: model.userRole,
        required: false,
      },
    ];
    if (searchName) {
      let orArr = [
        { role_name: { [Op.like]: `%${searchName}%` } },
        { role_display_name: { [Op.like]: `%${searchName}%` } },
      ];
      condition[Op.or] = orArr;
    }

    resultData = await paginationService.pagination(
      searchParams,
      model.role,
      includeQuery,
      condition,
      attributes,
    );
    console.log(resultData);
    if (resultData.rows && resultData.rows.length > 0) {
      resultData.rows = resultData.rows.map((record) => {
        record.dataValues.user_count =
          !record.dataValues && !record.dataValues.userRoles && !record.dataValues.userRoles.length
            ? 0
            : record.dataValues.userRoles.length;
        delete record.dataValues.userRoles;
        return record;
      });
    }
    res.ok({
      page: page,
      limit: limit,
      total_records: resultData.count,
      total_pages: resultData.count > 0 ? Math.ceil(resultData.count / limit) : 0,
      results: resultData.rows,
    });
  } catch (error) {
    console.log(error);
    next(error);
  }
};
