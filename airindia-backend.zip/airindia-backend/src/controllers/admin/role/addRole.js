import model from "../../../models/index.js";
import { customDateTimeHelper } from "../../../helpers/index.js";
import { StatusError } from "../../../config/index.js";
import { Op } from "sequelize";

/**
 * addRole
 * @param req
 * @param res
 */
export const addRole = async (req, res, next) => {
  try {
    const reqBody = req.body;
    const loginUserId = req.userDetails.userId;
    if (!loginUserId) throw StatusError.badRequest(res.__("Invalid user id"));

    const searchName = reqBody.role_name;
    // checking for faqCategory existance
    const role = await model.role.findOne({
      where: { role_name: { [Op.like]: `%${searchName}%` } },
    });
    if (role) throw StatusError.badRequest(res.__("Role is already taken"));

    // add details
    const inputDetails = {
      role_name: reqBody.role_name,
      role_display_name: reqBody.role_display_name,
      defaults: 0,
      status: reqBody.status,
      created_at: await customDateTimeHelper.getCurrentDateTime(),
      created_by: loginUserId,
    };

    const insRes = await model.role.create(inputDetails);

    if (insRes && insRes.id > 0) {
      res.ok({
        message: res.__("success"),
      });
    } else {
      throw StatusError.badRequest(res.__("SomeThingWentWrong"));
    }
  } catch (error) {
    console.log(error);
    next(error);
  }
};
