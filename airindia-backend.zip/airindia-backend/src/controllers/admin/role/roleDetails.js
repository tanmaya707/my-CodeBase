import model from "../../../models/index.js";
import { StatusError } from "../../../config/index.js";

/**
 * roleDetails
 * @param req
 * @param res
 */
export const roleDetails = async (req, res, next) => {
  try {
    const loginUserId = req.userDetails.userId;
    if (!loginUserId) throw StatusError.badRequest(res.__("Invalid user id"));
    const reqBody = req.params;
    const id = reqBody.id ? reqBody.id : "";
    if (!id) throw StatusError.badRequest(res.__("Invalid id"));

    const checkId = await model.role.count({
      where: { id: id },
    });
    if (checkId == 0) throw StatusError.badRequest(res.__("Invalid id"));

    let resultData = {};
    const condition = { id: id };
    const attributes = [
      "id",
      "role_name",
      "role_display_name",
      "defaults",
      "status",
      "created_by",
      "created_at",
      "updated_by",
      "updated_at",
    ];

    const includeQuery = [
      {
        model: model.userRole,
        required: false,
      },
    ];

    resultData = await model.role.findOne({
      attributes: attributes,
      include: includeQuery,
      where: condition,
    });
    if (resultData && resultData.dataValues && resultData.dataValues.userRoles) {
      resultData.dataValues.user_count = resultData.dataValues.userRoles.length ?? 0;
    }
    delete resultData.dataValues.userRoles;
    res.ok(resultData ? resultData : {});
  } catch (error) {
    next(error);
  }
};
