import model from "../../../models/index.js";
import { StatusError } from "../../../config/index.js";

/**
 * deleteRole
 * @param req
 * @param res
 */
export const deleteRole = async (req, res, next) => {
  try {
    const reqBody = req.body;
    const id = reqBody.id ? reqBody.id : "";

    const loginUserId = req.userDetails.userId;
    if (!loginUserId) throw StatusError.badRequest(res.__("Invalid user id"));

    if (!id) throw StatusError.badRequest(res.__("Invalid id"));

    const checkId = await model.role.count({
      where: { id: id },
    });
    if (checkId == 0) throw StatusError.badRequest(res.__("Invalid id"));

    const desRes = await model.role.destroy({
      where: { id: id },
    });

    if (desRes > 0) {
      res.ok({
        message: res.__("success"),
      });
    } else {
      throw StatusError.badRequest(res.__("SomeThingWentWrong"));
    }
  } catch (error) {
    console.log(error);
    next(error);
  }
};
