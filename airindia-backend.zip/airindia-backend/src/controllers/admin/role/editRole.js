import model from "../../../models/index.js";
import { customDateTimeHelper } from "../../../helpers/index.js";
import { StatusError } from "../../../config/index.js";
import { Op } from "sequelize";

/**
 * editRole
 * @param req
 * @param res
 */
export const editRole = async (req, res, next) => {
  try {
    const reqBody = req.body;
    const loginUserId = req.userDetails.userId;
    const id = reqBody.id ? reqBody.id : "";

    if (!loginUserId) throw StatusError.badRequest(res.__("Invalid user id"));

    if (!id) throw StatusError.badRequest(res.__("Invalid id"));

    // check for faq id existance in table
    const isExists = await model.role.findOne({
      attributes: ["id", "role_name", "created_by"],
      where: {
        id: id,
      },
    });

    if (!isExists) throw StatusError.badRequest(res.__("Invalid id"));

    const searchName = reqBody.role_name;
    // checking for faqCategory existance
    const role = await model.role.findOne({
      where: { role_name: { [Op.like]: `%${searchName}%` }, id: { [Op.ne]: id } },
    });
    if (role) throw StatusError.badRequest(res.__("Role is already taken"));

    // edit details
    let reqDetails = {
      role_name: reqBody.role_name,
      role_display_name: reqBody.role_display_name,
      status: reqBody.status,
      updated_at: await customDateTimeHelper.getCurrentDateTime(),
      updated_by: loginUserId,
    };
    const [resUp] = await model.role.update(reqDetails, {
      where: { id: id },
    });

    if (resUp > 0) {
      res.ok({
        message: res.__("success"),
      });
    } else {
      throw StatusError.badRequest(res.__("SomeThingWentWrong"));
    }
  } catch (error) {
    console.log(error);
    next(error);
  }
};
