import model from "../../../models/index.js";
import { customDateTimeHelper } from "../../../helpers/index.js";
import { StatusError } from "../../../config/index.js";
import { v4 as uuidv4 } from "uuid";
import { Op } from "sequelize";
import {
  contentModificationService,
  notificationService,
  userPermissionService,
} from "../../../services/index.js";

/**
 * addCertificate
 * @param req
 * @param res
 */
export const addCertificate = async (req, res, next) => {
  try {
    const reqBody = req.body;
    const loginUserId = req.userDetails.userId;
    if (!loginUserId) throw StatusError.badRequest(res.__("Invalid user id"));
    const userRole = req.userDetails.user_type ?? "";
    const roleId = req.userDetails.user_role_id ?? "";
    if (!userRole) {
      throw StatusError.badRequest(res.__("Invalid user role"));
    }
    const searchName = reqBody.certificate_name;
    // checking for Certificate existance
    const certificate = await model.certificate.findOne({
      where: { name: { [Op.like]: `%${searchName}%` } },
    });
    if (certificate) throw StatusError.badRequest(res.__("Certificate is already taken"));

    const totalRe = await model.certificate.max("list_order");

    let listOrder = (totalRe ?? 0) + 1;
    // add details
    const inputDetails = {
      uuid: uuidv4(),
      name: searchName,
      description: null,
      issue_date: null,
      file_path: null,
      list_order: listOrder,
      status: reqBody.status,
      created_at: await customDateTimeHelper.getCurrentDateTime(),
      created_by: loginUserId,
    };
    let insRes;
    let sucMess = "success";
    if (userRole == "superadmin" || userRole == "administrator" || userRole == "approver") {
      const check = await userPermissionService.checkUserPermission(roleId, loginUserId, [
        "credential.add",
      ]);
      if (check) {
        insRes = await model.certificate.create(inputDetails);
      } else {
        insRes = null;
      }
    } else {
      insRes = await model.tempCertificate.create(inputDetails);
      if (insRes && insRes.id > 0) {
        sucMess = "Your addition request has been save successfully. Please wait for approval!";
        await contentModificationService.addRequest({
          temp_id: insRes.id,
          request_for: "certificates",
          action_type: "add",
          created_at: inputDetails.created_at,
          created_by: inputDetails.created_by,
        });
        await notificationService.generateNotificationForContentApproval(
          {
            created_by: loginUserId,
            notification_type: "content_approval",
            type: "update",
            title: `A new credential certificate addition requested`,
            item_id: insRes.id,
            item_description: `A new credential certificate, ${inputDetails.name} addition requested by publisher`,
            item: inputDetails,
          },
          null,
          ["credential.status_change"],
        );
      }
    }
    if (insRes && insRes.id > 0) {
      res.ok({
        message: res.__(sucMess),
      });
    } else {
      throw StatusError.badRequest(res.__("SomeThingWentWrong"));
    }
  } catch (error) {
    console.log(error);
    next(error);
  }
};
