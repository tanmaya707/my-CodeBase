import { certificateDetails } from "./certificateDetails.js";
import { deleteCertificate } from "./deleteCertificate.js";
import { addCertificate } from "./addCertificate.js";
import { editCertificate } from "./editCertificate.js";
import { certificateList } from "./certificateList.js";

export { certificateDetails, deleteCertificate, addCertificate, editCertificate, certificateList };
