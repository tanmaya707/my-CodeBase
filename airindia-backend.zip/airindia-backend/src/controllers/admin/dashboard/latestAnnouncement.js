import model from "../../../models/index.js";
import { col, fn } from "sequelize";
import { generalHelper } from "../../../helpers/index.js";

/**
 * latestAnnouncement
 * @param req
 * @param res
 */
export const latestAnnouncement = async (req, res, next) => {
  try {
    let list = await model.news.findAll({
      where: {
        status: "active",
      },
      attributes: [
        "id",
        "title",
        "type",
        "short_description",
        "description",
        "website_link",
        "published_at",
        "status",
        "created_at",
      ],
      include: [
        {
          attributes: [
            [fn("REPLACE", col("newsImages.file_path"), `public/uploads/`, `public/`), "file_path"],
          ],
          model: model.newsImage,
          where: { status: "active" },
          required: false,
        },
        {
          attributes: ["id"],
          model: model.usersActivity,
          where: { status: "active", type: "news" },
          required: false,
        },
      ],
      order: [["id", "desc"]],
      limit: 3,
    });
    if (list && list.length > 0) {
      list = await Promise.all(
        list.map(async (record) => {
          record.dataValues.news_images =
            record.dataValues.newsImages.length > 0 ? record.dataValues.newsImages : [];
          record.dataValues.view_count = record.dataValues.usersActivities.length ?? 0;
          record.dataValues.display_type = record.dataValues.type
            ? await generalHelper.announcementTypeList(record.dataValues.type)
            : "";
          delete record.dataValues.newsImages;
          delete record.dataValues.usersActivities;
          return record;
        }),
      );
    }
    res.ok({
      results: list,
    });
  } catch (error) {
    console.log(error);
    next(error);
  }
};
