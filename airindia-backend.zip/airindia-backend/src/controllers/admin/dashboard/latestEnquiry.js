import model from "../../../models/index.js";

/**
 * latestEnquiry
 * @param req
 * @param res
 */
export const latestEnquiry = async (req, res, next) => {
  try {
    let list = await model.contactUs.findAll({
      attributes: ["id", "name", "email", "message", "created_at"],
      order: [["id", "desc"]],
      limit: 10,
    });
    res.ok({
      total_count: list.length ?? 0,
      results: list,
    });
  } catch (error) {
    next(error);
  }
};
