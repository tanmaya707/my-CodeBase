import { StatusError } from "../../../config/index.js";
import { contentModificationService } from "../../../services/index.js";
import model from "../../../models/index.js";

/**
 * activityDetails
 * @param req
 * @param res
 */
export const activityDetails = async (req, res, next) => {
  try {
    const reqBody = req.params;
    const loginUserId = req.userDetails.userId;
    const id = reqBody.id ? reqBody.id : ""; //request id

    if (!id) throw StatusError.badRequest(res.__("Invalid id"));

    const checkId = await model.contentModificationRequest.findOne({
      where: { uuid: id, created_by: loginUserId },
    });
    if (!checkId) throw StatusError.badRequest(res.__("Invalid id"));

    let resultData = {};
    resultData.request_details = checkId ?? {};
    if (checkId.request_for == "teams") {
      const teamContentDetails = await contentModificationService.contentDetails.teamContentDetails(
        checkId.temp_id,
        checkId.action_type,
      );
      resultData = { ...resultData, ...teamContentDetails };
    } else if (checkId.request_for == "clients") {
      const teamContentDetails =
        await contentModificationService.contentDetails.clientContentDetails(
          checkId.temp_id,
          checkId.action_type,
        );
      resultData = { ...resultData, ...teamContentDetails };
    } else if (checkId.request_for == "galleries") {
      const galleryContentDetails =
        await contentModificationService.contentDetails.galleryContentDetails(
          checkId.temp_id,
          checkId.action_type,
        );
      resultData = { ...resultData, ...galleryContentDetails };
    } else if (checkId.request_for == "services") {
      const serviceContentDetails =
        await contentModificationService.contentDetails.serviceContentDetails(
          checkId.temp_id,
          checkId.action_type,
        );
      resultData = { ...resultData, ...serviceContentDetails };
    } else if (checkId.request_for == "enquiry") {
      const enquiryContentDetails =
        await contentModificationService.contentDetails.enquiryContentDetails(
          checkId.temp_id,
          checkId.action_type,
        );
      resultData = { ...resultData, ...enquiryContentDetails };
    } else if (checkId.request_for == "awards") {
      const awardContentDetails =
        await contentModificationService.contentDetails.awardContentDetails(
          checkId.temp_id,
          checkId.action_type,
        );
      resultData = { ...resultData, ...awardContentDetails };
    } else if (checkId.request_for == "news") {
      const newsContentDetails = await contentModificationService.contentDetails.newsContentDetails(
        checkId.temp_id,
        checkId.action_type,
      );
      resultData = { ...resultData, ...newsContentDetails };
    } else if (checkId.request_for == "blogs") {
      const blogContentDetails = await contentModificationService.contentDetails.blogContentDetails(
        checkId.temp_id,
        checkId.action_type,
      );
      resultData = { ...resultData, ...blogContentDetails };
    } else if (checkId.request_for == "tenders") {
      const tenderContentDetails =
        await contentModificationService.contentDetails.tenderContentDetails(
          checkId.temp_id,
          checkId.action_type,
        );
      resultData = { ...resultData, ...tenderContentDetails };
    } else if (checkId.request_for == "jobs") {
      const jobContentDetails = await contentModificationService.contentDetails.jobContentDetails(
        checkId.temp_id,
        checkId.action_type,
      );
      resultData = { ...resultData, ...jobContentDetails };
    } else if (checkId.request_for == "job_applicants") {
      const jobApplicantContentDetails =
        await contentModificationService.contentDetails.jobApplicantContentDetails(
          checkId.temp_id,
          checkId.action_type,
        );
      resultData = { ...resultData, ...jobApplicantContentDetails };
    } else if (checkId.request_for == "credentials") {
      const credentialContentDetails =
        await contentModificationService.contentDetails.credentialContentDetails(
          checkId.temp_id,
          checkId.action_type,
        );
      resultData = { ...resultData, ...credentialContentDetails };
    } else if (checkId.request_for == "credential_categories") {
      const credentialCategoryContentDetails =
        await contentModificationService.contentDetails.credentialCategoryContentDetails(
          checkId.temp_id,
          checkId.action_type,
        );
      resultData = { ...resultData, ...credentialCategoryContentDetails };
    } else if (checkId.request_for == "certificates") {
      const credentialCertificateContentDetails =
        await contentModificationService.contentDetails.credentialCertificateContentDetails(
          checkId.temp_id,
          checkId.action_type,
        );
      resultData = { ...resultData, ...credentialCertificateContentDetails };
    } else if (checkId.request_for == "contact_purposes") {
      const contactPurposeContentDetails =
        await contentModificationService.contentDetails.contactPurposeContentDetails(
          checkId.temp_id,
          checkId.action_type,
        );
      resultData = { ...resultData, ...contactPurposeContentDetails };
    } else if (checkId.request_for == "faqs") {
      const faqContentDetails = await contentModificationService.contentDetails.faqContentDetails(
        checkId.temp_id,
        checkId.action_type,
      );
      resultData = { ...resultData, ...faqContentDetails };
    } else if (checkId.request_for == "faq_categories") {
      const faqCategoryContentDetails =
        await contentModificationService.contentDetails.faqCategoryContentDetails(
          checkId.temp_id,
          checkId.action_type,
        );
      resultData = { ...resultData, ...faqCategoryContentDetails };
    } else if (checkId.request_for == "custom_pages") {
      const cmsPageContentDetails =
        await contentModificationService.contentDetails.cmsPageContentDetails(
          checkId.temp_id,
          checkId.action_type,
        );
      resultData = { ...resultData, ...cmsPageContentDetails };
    } else if (checkId.request_for == "pages") {
      const cmsCustomPageContentDetails =
        await contentModificationService.contentDetails.cmsCustomPageContentDetails(
          checkId.temp_id,
          checkId.action_type,
        );
      resultData = { ...resultData, ...cmsCustomPageContentDetails };
    } else if (checkId.request_for == "page_content") {
      const pageContentDetails = await contentModificationService.contentDetails.pageContentDetails(
        checkId.temp_id,
        checkId.action_type,
      );
      resultData = { ...resultData, ...pageContentDetails };
    } else if (checkId.request_for == "home_page") {
      const homePageContentDetails =
        await contentModificationService.contentDetails.homePageContentDetails(
          checkId.temp_id,
          checkId.action_type,
        );
      resultData = { ...resultData, ...homePageContentDetails };
    } else if (checkId.request_for == "site_info") {
      const siteSettingInfoDetails =
        await contentModificationService.contentDetails.siteSettingInfoDetails(
          checkId.temp_id,
          checkId.action_type,
        );
      resultData = { ...resultData, ...siteSettingInfoDetails };
    }

    res.ok(resultData ? resultData : {});
  } catch (error) {
    console.log(error);
    next(error);
  }
};
