import model from "../../../models/index.js";
import { PAGINATION_LIMIT, GLOBAL_PARAMS } from "../../../utils/constants.js";
import { paginationService, contentModificationService } from "../../../services/index.js";
import { Sequelize, Op } from "sequelize";

/**
 * activityLogList
 * @param req
 * @param res
 */
export const activityLogList = async (req, res, next) => {
  try {
    const reqBody = req.query;

    const searchName = reqBody.name ? reqBody.name.trim() : "";
    let resultData = [];
    const defautlPageNo = 1;
    const page = reqBody.page ? reqBody.page : defautlPageNo;
    const limit = reqBody.limit ? reqBody.limit : PAGINATION_LIMIT;

    const sortOrder = reqBody.sort_order ? reqBody.sort_order : "desc";
    const sortBy = reqBody.sort_by ? reqBody.sort_by : "";

    const loginUserId = req.userDetails.userId;
    const searchParams = {
      page: page,
      limit: limit,
    };

    let condition = { created_by: loginUserId };

    const attributes = [
      "id",
      "uuid",
      "temp_id",
      "request_for",
      "action_type",
      "comment",
      "status",
      "created_at",
    ];

    searchParams.sortOrderObj = [[Sequelize.literal("created_at"), sortOrder]];

    const includeQuery = [
      {
        model: model.user,
        as: "updateBy",
        attributes: ["first_name", "last_name"],
        required: false,
      },
    ];
    if (searchName) {
      let orArr = [
        { comment: { [Op.like]: `%${searchName}%` } },
        { status: { [Op.like]: `%${searchName}%` } },
        { action_type: { [Op.like]: `%${searchName}%` } },
        { request_for: { [Op.like]: `%${searchName}%` } },
      ];

      condition[Op.or] = orArr;
    }

    resultData = await paginationService.pagination(
      searchParams,
      model.contentModificationRequest,
      includeQuery,
      condition,
      attributes,
    );
    let retResult = [];
    if (resultData.rows.length > 0) {
      for (let eachRow of resultData.rows) {
        if (eachRow.dataValues.request_for && eachRow.dataValues.temp_id) {
          eachRow.dataValues.display_request_for = eachRow.dataValues.request_for
            ? (GLOBAL_PARAMS.FOR_LIST[eachRow.dataValues.request_for] ?? "")
            : "";
          if (
            eachRow.dataValues.request_for == "home_page" ||
            eachRow.dataValues.request_for == "page_content" ||
            eachRow.dataValues.request_for == "custom_pages" ||
            eachRow.dataValues.request_for == "pages"
          ) {
            eachRow.dataValues.display_request_for =
              await contentModificationService.getApprovalListType(
                eachRow.dataValues.temp_id,
                eachRow.dataValues.request_for,
              );
          }
        }
        eachRow.dataValues.display_action_type = eachRow.dataValues.action_type
          ? (GLOBAL_PARAMS.ACTION_LIST[eachRow.dataValues.action_type] ?? "")
          : "";
        eachRow.dataValues.approved_by = eachRow?.updateBy
          ? `${eachRow?.updateBy?.first_name} ${eachRow?.updateBy?.last_name}`
          : "";
        delete eachRow?.dataValues?.updateBy;
        retResult.push(eachRow);
      }
    }
    res.ok({
      page: page,
      limit: limit,
      total_records: resultData.count,
      total_pages: resultData.count > 0 ? Math.ceil(resultData.count / limit) : 0,
      results: retResult,
    });
  } catch (error) {
    console.log(error);
    next(error);
  }
};
