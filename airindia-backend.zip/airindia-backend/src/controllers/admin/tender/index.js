import { addTender } from "./addTender.js";
import { tenderList } from "./tenderList.js";
import { editTender } from "./editTender.js";
import { deleteTender } from "./deleteTender.js";
import { tenderDetails } from "./tenderDetails.js";
import { tenderCategoryList } from "./tenderCategoryList.js";

export { addTender, tenderList, editTender, deleteTender, tenderDetails, tenderCategoryList };
