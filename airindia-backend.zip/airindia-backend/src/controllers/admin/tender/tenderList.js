import model from "../../../models/index.js";
import { PAGINATION_LIMIT } from "../../../utils/constants.js";
import { paginationService } from "../../../services/index.js";
import { Sequelize, Op, col, fn } from "sequelize";
import { customDateTimeHelper } from "../../../helpers/index.js";

/**
 * tenderList
 * @param req
 * @param res
 */
export const tenderList = async (req, res, next) => {
  try {
    const reqBody = req.query;
    const currentDate = await customDateTimeHelper.getCurrentDateTime("YYYY-MM-DD");
    const searchName = reqBody.name ? reqBody.name.trim() : "";
    let resultData = [];
    const defautlPageNo = 1;
    const page = reqBody.page ? reqBody.page : defautlPageNo;
    const limit = reqBody.limit ? reqBody.limit : PAGINATION_LIMIT;

    const sortOrder = reqBody.sort_order ? reqBody.sort_order : "desc";
    const sortBy = reqBody.sort_by ? reqBody.sort_by : "";

    const loginUserId = req.userDetails.userId;
    const searchParams = {
      page: page,
      limit: limit,
    };

    let condition = {};

    const attributes = [
      "id",
      "uuid",
      "tender_category_id",
      [col("tenderCategory.name"), "category_name"],
      ["name", "tender_name"],
      "tender_no",
      "description",
      "start_at",
      "end_at",
      [fn("REPLACE", col("attachment"), `public/uploads/`, `public/`), "attachment"],
      "corrigendum_tender",
      "corrigendum_start_at",
      "corrigendum_end_at",
      [
        fn("REPLACE", col("corrigendum_attachment"), `public/uploads/`, `public/`),
        "corrigendum_attachment",
      ],
      //"tender_status",
      [
        Sequelize.literal(
          `CASE 
            WHEN (
                (start_at <= '${currentDate}' AND end_at >= '${currentDate}') AND corrigendum_tender = 'no'
            ) THEN 'Open'
             WHEN (
                (start_at > '${currentDate}') AND corrigendum_tender = 'no'
            ) THEN null
            WHEN (
                (corrigendum_start_at <= '${currentDate}' AND corrigendum_end_at >= '${currentDate}') AND corrigendum_tender = 'yes'
            ) THEN 'Open'
            WHEN (
                (corrigendum_start_at > '${currentDate}') AND corrigendum_tender = 'yes'
            ) THEN null
            ELSE 'Closed'
          END`,
        ),
        "tender_status",
      ],
      "status",
      "list_order",
      "created_at",
    ];

    if (sortOrder && sortBy == "name") {
      searchParams.sortOrderObj = [[Sequelize.literal("name"), sortOrder]];
    } else if (sortOrder && sortBy == "created_at") {
      searchParams.sortOrderObj = [[Sequelize.literal("created_at"), sortOrder]];
    } else {
      searchParams.sortOrderObj = [[Sequelize.literal("created_at"), sortOrder]];
    }

    const includeQuery = [
      {
        model: model.tenderCategory,
        attributes: [],
        //where: { status: "active" },
        required: true,
      },
    ];
    if (searchName) {
      let orArr = [
        { name: { [Op.like]: `%${searchName}%` } },
        { tender_no: { [Op.like]: `%${searchName}%` } },
        { description: { [Op.like]: `%${searchName}%` } },
      ];

      condition[Op.or] = orArr;
    }

    resultData = await paginationService.pagination(
      searchParams,
      model.tender,
      includeQuery,
      condition,
      attributes,
    );

    res.ok({
      page: page,
      limit: limit,
      total_records: resultData.count,
      total_pages: resultData.count > 0 ? Math.ceil(resultData.count / limit) : 0,
      results: resultData.rows,
    });
  } catch (error) {
    console.log(error);
    next(error);
  }
};
