import model from "../../../models/index.js";
import { StatusError } from "../../../config/index.js";
import {
  contentModificationService,
  notificationService,
  userPermissionService,
} from "../../../services/index.js";

/**
 * deleteTender
 * @param req
 * @param res
 */
export const deleteTender = async (req, res, next) => {
  try {
    const reqBody = req.body;
    const delId = reqBody.id ? reqBody.id : "";
    if (!delId) throw StatusError.badRequest(res.__("Invalid id"));
    const loginUserId = req.userDetails.userId;
    if (!loginUserId) {
      throw StatusError.badRequest(res.__("Invalid user id"));
    }
    const userRole = req.userDetails.user_type ?? "";
    const roleId = req.userDetails.user_role_id ?? "";
    if (!userRole) {
      throw StatusError.badRequest(res.__("Invalid user role"));
    }
    const checkId = await model.tender.count({
      where: { id: delId },
    });
    if (checkId == 0) throw StatusError.badRequest(res.__("Invalid id"));
    let desRes;
    let sucMess = "success";
    if (userRole == "superadmin" || userRole == "administrator" || userRole == "approver") {
      const check = await userPermissionService.checkUserPermission(roleId, loginUserId, [
        "tender.delete",
      ]);
      if (check) {
        desRes = await model.tender.destroy({
          where: { id: delId },
        });
      } else {
        desRes = 0;
      }
    } else {
      const checkForPendingRequest = await contentModificationService.checkForPendingRequest({
        id: delId,
        request_for: "tenders",
        action_type: "delete",
      });
      if (checkForPendingRequest) {
        throw StatusError.badRequest(
          res.__(
            "A modification request is already in progress. Please wait for the approval response and try again later.",
          ),
        );
      } else {
        const detail = await model.tender.findOne({ where: { id: delId } });
        detail.tender_id = detail.id;
        delete detail.id;
        const insRes = await model.tempTender.create(detail);
        if (insRes && insRes.id > 0) {
          desRes = 1;
          sucMess = "Your delete request has been save successfully. Please wait for approval!";
          await contentModificationService.addRequest({
            temp_id: insRes.id,
            request_for: "tenders",
            action_type: "delete",
            created_at: detail.created_at,
            created_by: detail.created_by,
          });
          await notificationService.generateNotificationForContentApproval(
            {
              created_by: loginUserId,
              notification_type: "content_approval",
              type: "update",
              title: `A tender delete requested`,
              item_id: detail.id,
              item_description: `A tender "${detail.name}" delete requested by publisher`,
              item: detail,
            },
            null,
            ["tender.status_change"],
          );
        }
      }
    }
    if (desRes > 0) {
      res.ok({
        message: res.__(sucMess),
      });
    } else {
      throw StatusError.badRequest(res.__("SomeThingWentWrong"));
    }
  } catch (error) {
    console.log(error);
    next(error);
  }
};
