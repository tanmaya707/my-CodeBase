import model from "../../../models/index.js";
import { customDateTimeHelper, customFileHelper } from "../../../helpers/index.js";
import { StatusError } from "../../../config/index.js";
import fs from "fs";
import {
  contentModificationService,
  notificationService,
  userPermissionService,
} from "../../../services/index.js";

/**
 * editTender
 * @param req
 * @param res
 */
export const editTender = async (req, res, next) => {
  try {
    const reqBody = req.body;
    const loginUserId = req.userDetails.userId;
    const id = reqBody.id ? reqBody.id : "";
    let isFileDeleted = reqBody.is_fdel ? reqBody.is_fdel : "";
    isFileDeleted = isFileDeleted == "" ? "n" : isFileDeleted;

    let isFileCoDeleted = reqBody.is_fco_del ? reqBody.is_fco_del : "";
    isFileCoDeleted = isFileCoDeleted == "" ? "n" : isFileCoDeleted;

    let fileLocation = "";
    let fileName = "";
    if (req.files && req.files.file && req.files.file[0]) {
      const fileDetails = req.files.file[0];
      fileName = fileDetails.filename ? fileDetails.filename : "";
      fileLocation = fileDetails.destination ? fileDetails.destination + "/" + fileName : "";
    }

    let fileLocationCo = "";
    let fileNameCo = "";
    if (req.files && req.files.file_co && req.files.file_co[0]) {
      const fileDetails = req.files.file_co[0];
      fileNameCo = fileDetails.filename ? fileDetails.filename : "";
      fileLocationCo = fileDetails.destination ? fileDetails.destination + "/" + fileNameCo : "";
    }
    const userRole = req.userDetails.user_type ?? "";
    const roleId = req.userDetails.user_role_id ?? "";
    if (!userRole) {
      if (req.files && req.files.file && req.files.file[0].path)
        customFileHelper.customFileUnlink(fs, req.files.file[0].path);
      if (req.files && req.files.file_co && req.files.file_co[0].path)
        customFileHelper.customFileUnlink(fs, req.files.file_co[0].path);
      throw StatusError.badRequest(res.__("Invalid user role"));
    }
    // check for id existance in table
    const isExists = await model.tender.findOne({
      //attributes: ["id", "name", "created_by", "attachment", "corrigendum_attachment"],
      where: {
        id: id,
      },
    });
    if (!isExists) {
      if (req.files && req.files.file && req.files.file[0].path)
        customFileHelper.customFileUnlink(fs, req.files.file[0].path);
      if (req.files && req.files.file_co && req.files.file_co[0].path)
        customFileHelper.customFileUnlink(fs, req.files.file_co[0].path);
      throw StatusError.badRequest(res.__("Invalid id"));
    }

    let fpath = fileLocation ? fileLocation : isExists?.attachment;
    if (isFileDeleted == "y") {
      fpath = "";
    }
    let fCoPath = fileLocationCo ? fileLocationCo : isExists?.corrigendum_attachment;
    if (isFileCoDeleted == "y") {
      fCoPath = "";
    }

    let requestDetails = {
      tender_category_id: reqBody.tender_category_id ?? null,
      name: reqBody.tender_name ?? null,
      tender_no: reqBody.tender_no ?? null,
      description: reqBody.description ?? null,
      start_at: reqBody.start_at
        ? await customDateTimeHelper.changeDateFormat(reqBody.start_at, "YYYY-MM-DD")
        : null,
      end_at: reqBody.end_at
        ? await customDateTimeHelper.changeDateFormat(reqBody.end_at, "YYYY-MM-DD")
        : null,
      attachment: fpath,
      corrigendum_tender: reqBody.corrigendum_tender ?? "no",
      corrigendum_start_at:
        !reqBody.corrigendum_start_at || reqBody.corrigendum_start_at == "null"
          ? null
          : await customDateTimeHelper.changeDateFormat(reqBody.corrigendum_start_at, "YYYY-MM-DD"),
      corrigendum_end_at:
        !reqBody.corrigendum_end_at || reqBody.corrigendum_end_at == "null"
          ? null
          : await customDateTimeHelper.changeDateFormat(reqBody.corrigendum_end_at, "YYYY-MM-DD"),
      corrigendum_attachment: fCoPath,
      tender_status: reqBody.tender_status,
      status: reqBody.status,
      updated_at: await customDateTimeHelper.getCurrentDateTime(),
      updated_by: loginUserId,
    };
    let updt = 0;
    let sucMess = "success";
    if (userRole == "superadmin" || userRole == "administrator" || userRole == "approver") {
      const check = await userPermissionService.checkUserPermission(roleId, loginUserId, [
        "tender.edit",
      ]);
      if (check) {
        requestDetails.updated_at = await customDateTimeHelper.getCurrentDateTime();
        requestDetails.updated_by = loginUserId;
        const [upResp] = await model.tender.update(requestDetails, {
          where: { id: id },
        });
        if (upResp > 0) {
          updt = 1;
        }
      }
    } else {
      const checkForPendingRequest = await contentModificationService.checkForPendingRequest({
        id: id,
        request_for: "tenders",
        action_type: "edit",
      });
      if (checkForPendingRequest) {
        if (req.file && req.file.path) customFileHelper.customFileUnlink(fs, req.file.path);
        throw StatusError.badRequest(
          res.__(
            "A modification request is already in progress. Please wait for the approval response and try again later.",
          ),
        );
      } else {
        requestDetails.tender_id = id;
        requestDetails.earlier_data = isExists ? JSON.stringify(isExists) : null;
        requestDetails.uuid = isExists.uuid;
        requestDetails.list_order = isExists.list_order;
        requestDetails.created_at = requestDetails.updated_at;
        requestDetails.created_by = requestDetails.updated_by;
        const insRes = await model.tempTender.create(requestDetails);

        if (insRes && insRes.id > 0) {
          sucMess =
            "Your modification request has been save successfully. Please wait for approval!";
          await contentModificationService.addRequest({
            temp_id: insRes.id,
            request_for: "tenders",
            action_type: "edit",
            created_at: requestDetails.updated_at,
            created_by: requestDetails.updated_by,
          });
          await notificationService.generateNotificationForContentApproval(
            {
              created_by: loginUserId,
              notification_type: "content_approval",
              type: "update",
              title: `A tender modification requested`,
              item_id: insRes.id,
              item_description: `A tender, ${insRes.name} modification requested by publisher`,
              item: insRes,
            },
            null,
            ["tender.status_change"],
          );
          updt = 1;
        }
      }
    }
    if (updt > 0) {
      // if (req.files && req.files.file && req.files.file[0].path && isExists.attachment) {
      //   customFileHelper.customFileUnlink(fs, isExists.attachment);
      // }
      // if (
      //   req.files &&
      //   req.files.file_co &&
      //   req.files.file_co[0].path &&
      //   isExists.corrigendum_attachment
      // ) {
      //   customFileHelper.customFileUnlink(fs, isExists.corrigendum_attachment);
      // }
      res.ok({
        message: res.__(sucMess),
      });
    } else {
      if (req.files && req.files.file && req.files.file[0].path)
        customFileHelper.customFileUnlink(fs, req.files.file[0].path);
      if (req.files && req.files.file_co && req.files.file_co[0].path)
        customFileHelper.customFileUnlink(fs, req.files.file_co[0].path);
      throw StatusError.badRequest(res.__("SomeThingWentWrong"));
    }
  } catch (error) {
    console.log(error);
    if (req.files && req.files.file && req.files.file[0].path)
      customFileHelper.customFileUnlink(fs, req.files.file[0].path);
    if (req.files && req.files.file_co && req.files.file_co[0].path)
      customFileHelper.customFileUnlink(fs, req.files.file_co[0].path);
    next(error);
  }
};
