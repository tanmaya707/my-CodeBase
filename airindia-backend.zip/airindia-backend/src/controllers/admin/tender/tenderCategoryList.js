import model from "../../../models/index.js";
import { Op } from "sequelize";

/**
 * tenderCategoryList
 * @param req
 * @param res
 */
export const tenderCategoryList = async (req, res, next) => {
  try {
    const reqBody = req.query;
    let condition = { status: "active" };
    if (reqBody.search_name) {
      condition.name = { [Op.like]: `%${reqBody.search_name}%` };
    }
    const list = await model.tenderCategory.findAll({
      attributes: ["id", "uuid", ["name", "category_name"], "slug_name"],
      where: condition,
      order: [["id", "asc"]],
      //limit: 20,
    });
    res.ok({
      results: list,
    });
  } catch (error) {
    console.log(error);
    next(error);
  }
};
