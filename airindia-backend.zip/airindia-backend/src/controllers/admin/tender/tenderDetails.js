import model from "../../../models/index.js";
import { col, fn } from "sequelize";
import { StatusError } from "../../../config/index.js";

/**
 * tenderDetails
 * @param req
 * @param res
 */
export const tenderDetails = async (req, res, next) => {
  try {
    const reqBody = req.params;
    const id = reqBody.id ? reqBody.id : "";
    if (!id) throw StatusError.badRequest(res.__("Invalid id"));

    const checkId = await model.tender.count({
      where: { id: id },
    });
    if (checkId == 0) throw StatusError.badRequest(res.__("Invalid id"));

    let resultData = {};
    const condition = { id: id };
    const attributes = [
      "id",
      "uuid",
      "tender_category_id",
      [col("tenderCategory.name"), "category_name"],
      ["name", "tender_name"],
      "tender_no",
      "description",
      "start_at",
      "end_at",
      [fn("REPLACE", col("attachment"), `public/uploads/`, `public/`), "attachment"],
      "corrigendum_tender",
      "corrigendum_start_at",
      "corrigendum_end_at",
      [
        fn("REPLACE", col("corrigendum_attachment"), `public/uploads/`, `public/`),
        "corrigendum_attachment",
      ],
      "tender_status",
      "status",
      "list_order",
      "created_at",
    ];

    const includeQuery = [
      {
        model: model.tenderCategory,
        attributes: [],
        //where: { status: "active" },
        required: true,
      },
    ];

    resultData = await model.tender.findOne({
      attributes: attributes,
      include: includeQuery,
      where: condition,
    });

    res.ok(resultData ? resultData : {});
  } catch (error) {
    next(error);
  }
};
