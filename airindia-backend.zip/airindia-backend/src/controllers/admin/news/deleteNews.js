import model from "../../../models/index.js";
import { StatusError } from "../../../config/index.js";
import {
  contentModificationService,
  notificationService,
  userPermissionService,
} from "../../../services/index.js";

/**
 * deleteNews
 * @param req
 * @param res
 */
export const deleteNews = async (req, res, next) => {
  try {
    const reqBody = req.body;
    const newsId = reqBody.id ? reqBody.id : "";
    if (!newsId) throw StatusError.badRequest(res.__("Invalid id"));
    const loginUserId = req.userDetails.userId;
    const userRole = req.userDetails.user_type ?? "";
    const roleId = req.userDetails.user_role_id ?? "";
    if (!userRole) {
      throw StatusError.badRequest(res.__("Invalid user role"));
    }
    const checkNewsId = await model.news.count({
      where: { id: newsId },
    });
    if (checkNewsId == 0) throw StatusError.badRequest(res.__("Invalid id"));
    let desRes;
    let sucMess = "success";
    let delImg = false;
    if (userRole == "superadmin" || userRole == "administrator" || userRole == "approver") {
      const check = await userPermissionService.checkUserPermission(roleId, loginUserId, [
        "news_event.delete",
      ]);
      if (check) {
        desRes = await model.news.destroy({
          where: { id: newsId },
        });
        delImg = true;
      } else {
        desRes = 0;
      }
    } else {
      const checkForPendingRequest = await contentModificationService.checkForPendingRequest({
        id: newsId,
        request_for: "news",
        action_type: "delete",
      });
      if (checkForPendingRequest) {
        throw StatusError.badRequest(
          res.__(
            "A modification request is already in progress. Please wait for the approval response and try again later.",
          ),
        );
      } else {
        const detail = await model.news.findOne({ where: { id: newsId } });
        const oldImage = await model.newsImage.findOne({
          //attributes: ["id", "created_by"],
          where: { news_id: newsId },
        });
        detail.news_id = detail.id;
        detail.news_image = oldImage ?? {};
        delete detail.id;
        const insRes = await model.tempNews.create(detail);
        if (insRes && insRes.id > 0) {
          desRes = 1;
          sucMess = "Your delete request has been save successfully. Please wait for approval!";
          await contentModificationService.addRequest({
            temp_id: insRes.id,
            request_for: "news",
            action_type: "delete",
            created_at: detail.created_at,
            created_by: detail.created_by,
          });
          await notificationService.generateNotificationForContentApproval(
            {
              created_by: loginUserId,
              notification_type: "content_approval",
              type: "update",
              title: `A news & event delete requested`,
              item_id: detail.id,
              item_description: `A new & event "${detail.title}" delete requested by publisher`,
              item: detail,
            },
            null,
            ["news_event.status_change"],
          );
        }
      }
    }

    if (desRes > 0) {
      if (delImg) {
        await model.newsImage.destroy({
          where: { news_id: newsId },
        });
      }
      res.ok({
        message: res.__(sucMess),
      });
    } else {
      throw StatusError.badRequest(res.__("SomeThingWentWrong"));
    }
  } catch (error) {
    next(error);
  }
};
