import model from "../../../models/index.js";
import { Sequelize, Op, col, fn } from "sequelize";
import { StatusError, envs } from "../../../config/index.js";

/**
 * newsDetails
 * @param req
 * @param res
 */
export const newsDetails = async (req, res, next) => {
  try {
    const reqBody = req.params;
    const newsId = reqBody.id ? reqBody.id : "";
    if (!newsId) throw StatusError.badRequest(res.__("Invalid id"));
    const checkNewsId = await model.news.count({
      where: { id: newsId },
    });
    if (checkNewsId == 0) throw StatusError.badRequest(res.__("Invalid id"));

    let resultData = {};
    const condition = { id: newsId };
    const attributes = [
      "id",
      "uuid",
      "title",
      "type",
      "short_description",
      "description",
      "website_link",
      "published_at",
      "status",
    ];

    const includeQuery = [
      {
        model: model.newsImage,
        attributes: [
          ["id", "image_id"],
          "file_name",
          [fn("REPLACE", col("newsImages.file_path"), `public/uploads/`, `public/`), "file_path"],
        ],
        //where: { status: "active" },
        required: false,
      },
    ];

    resultData = await model.news.findOne({
      attributes: attributes,
      include: includeQuery,
      where: condition,
    });

    if (resultData && resultData.dataValues && resultData.dataValues.newsImages) {
      resultData.dataValues.news_images = resultData.dataValues.newsImages;
    }

    res.ok(resultData ? resultData : {});
  } catch (error) {
    next(error);
  }
};
