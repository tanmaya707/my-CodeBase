import model from "../../../models/index.js";
import { customDateTimeHelper, generalHelper, customFileHelper } from "../../../helpers/index.js";
import { StatusError } from "../../../config/index.js";
import fs from "fs";
import {
  contentModificationService,
  notificationService,
  userPermissionService,
} from "../../../services/index.js";

/**
 * editNews
 * @param req
 * @param res
 */
export const editNews = async (req, res, next) => {
  try {
    const reqBody = req.body;
    const loginUserId = req.userDetails.userId;
    const newsId = reqBody.id ? reqBody.id : "";
    let fileLocation = "";
    let fileName = "";
    if (req.file) {
      const fileDetails = req.file;
      fileName = fileDetails.filename ? fileDetails.filename : "";
      fileLocation = fileDetails.destination ? fileDetails.destination + "/" + fileName : "";
    }
    const userRole = req.userDetails.user_type ?? "";
    const roleId = req.userDetails.user_role_id ?? "";
    if (!userRole) {
      if (req.file && req.file.path) customFileHelper.customFileUnlink(fs, req.file.path);
      throw StatusError.badRequest(res.__("Invalid user role"));
    }
    if (!newsId) {
      if (req.file.path) customFileHelper.customFileUnlink(fs, req.file.path);
      throw StatusError.badRequest(res.__("Invalid id"));
    }

    // check for news id existance in table
    const isExistsNews = await model.news.findOne({
      //attributes: ["id", "title", "slug_name", "created_by"],
      where: {
        id: newsId,
      },
      include: [
        {
          model: model.newsImage,
          required: false,
        },
      ],
    });

    if (!isExistsNews) {
      if (req.file.path) customFileHelper.customFileUnlink(fs, req.file.path);
      throw StatusError.badRequest(res.__("Invalid id"));
    }

    const whl = true;
    let slugName = "";
    let rslug = reqBody.title;
    let regenarate = false;
    if (isExistsNews.title != rslug) {
      while (whl) {
        const generatedSlug = await generalHelper.generateSlugName(rslug, regenarate);
        // check for slug name existance in tag category table
        const isExists = await model.news.findOne({
          where: { slug_name: generatedSlug },
          attributes: ["id", "slug_name"],
        });
        if (!isExists) {
          regenarate = false;
          slugName = generatedSlug;
          break;
        } else {
          regenarate = true;
          rslug = generatedSlug;
        }
      }
    } else {
      slugName = isExistsNews.slug_name;
    }

    // add details
    let newsDetails = {
      title: reqBody.title,
      type: reqBody.type,
      short_description: reqBody.short_description ?? null,
      description: reqBody.description ?? null,
      slug_name: slugName,
      website_link: reqBody.website_link,
      status: reqBody.status,
      published_at: await customDateTimeHelper.changeDateFormat(
        reqBody.published_at,
        "YYYY-MM-DD HH:mm:ss",
      ),
      updated_at: await customDateTimeHelper.getCurrentDateTime(),
      updated_by: loginUserId,
    };
    let updt = 0;
    let sucMess = "success";
    let adi = false;
    if (userRole == "superadmin" || userRole == "administrator" || userRole == "approver") {
      const check = await userPermissionService.checkUserPermission(roleId, loginUserId, [
        "news_event.edit",
      ]);
      if (check) {
        const [upResp] = await model.news.update(newsDetails, {
          where: { id: newsId },
        });
        if (upResp > 0) {
          updt = 1;
        }
        adi = true;
      }
    } else {
      const checkForPendingRequest = await contentModificationService.checkForPendingRequest({
        id: newsId,
        request_for: "news",
        action_type: "edit",
      });
      if (checkForPendingRequest) {
        if (req.file && req.file.path) customFileHelper.customFileUnlink(fs, req.file.path);
        throw StatusError.badRequest(
          res.__(
            "A modification request is already in progress. Please wait for the approval response and try again later.",
          ),
        );
      } else {
        let requestDetails = newsDetails;
        if (fileName) {
          const liOrder = await model.newsImage.max("list_order", {
            where: {
              news_id: newsId,
            },
          });
          const uploadImage = {
            news_id: newsId,
            file_name: fileName,
            file_path: fileLocation,
            list_order: (liOrder ?? 0) + 1,
            created_by: loginUserId,
            created_at: await customDateTimeHelper.getCurrentDateTime(),
          };
          requestDetails.news_image = JSON.stringify(uploadImage);
        } else {
          const uploadImage = await model.newsImage.findOne({
            where: {
              news_id: newsId,
            },
          });
          requestDetails.news_image = JSON.stringify(uploadImage);
        }
        requestDetails.news_id = newsId;
        requestDetails.earlier_data = isExistsNews ? JSON.stringify(isExistsNews) : null;
        requestDetails.uuid = isExistsNews.uuid;
        requestDetails.list_order = isExistsNews.list_order;
        requestDetails.created_at = requestDetails.updated_at;
        requestDetails.created_by = requestDetails.updated_by;
        const insRes = await model.tempNews.create(requestDetails);

        if (insRes && insRes.id > 0) {
          sucMess =
            "Your modification request has been save successfully. Please wait for approval!";
          await contentModificationService.addRequest({
            temp_id: insRes.id,
            request_for: "news",
            action_type: "edit",
            created_at: requestDetails.updated_at,
            created_by: requestDetails.updated_by,
          });
          await notificationService.generateNotificationForContentApproval(
            {
              created_by: loginUserId,
              notification_type: "content_approval",
              type: "update",
              title: `A news & event modification requested`,
              item_id: insRes.id,
              item_description: `A news & event "${insRes.title}" modification requested by publisher`,
              item: insRes,
            },
            null,
            ["news_event.status_change"],
          );
          updt = 1;
        }
      }
    }

    if (updt > 0) {
      if (fileName && adi) {
        const oldImage = await model.newsImage.findOne({
          attributes: ["id", "created_by"],
          where: { news_id: newsId },
        });
        const liOrder = await model.newsImage.max("list_order", {
          where: {
            news_id: newsId,
          },
        });
        const uploadImage = {
          news_id: newsId,
          file_name: fileName,
          file_path: fileLocation,
          list_order: (liOrder ?? 0) + 1,
          created_by: loginUserId,
          created_at: await customDateTimeHelper.getCurrentDateTime(),
        };
        const newImg = await model.newsImage.create(uploadImage);
        if (newImg && newImg.id > 0 && oldImage && oldImage.id > 0) {
          const desRes = await model.newsImage.destroy({
            where: { news_id: newsId, id: oldImage.id },
          });
          if (desRes && oldImage.file_path) {
            customFileHelper.customFileUnlink(fs, oldImage.file_path);
          }
        }
      }
      res.ok({
        message: res.__(sucMess),
      });
    } else {
      if (req.file.path) customFileHelper.customFileUnlink(fs, req.file.path);
      throw StatusError.badRequest(res.__("SomeThingWentWrong"));
    }
  } catch (error) {
    console.log(error);
    if (req.file) customFileHelper.customFileUnlink(fs, req.file.path);
    next(error);
  }
};
