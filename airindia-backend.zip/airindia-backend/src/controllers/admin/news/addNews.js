import model from "../../../models/index.js";
import { customDateTimeHelper, generalHelper, customFileHelper } from "../../../helpers/index.js";
import { StatusError } from "../../../config/index.js";
import { v4 as uuidv4 } from "uuid";
import fs from "fs";
import {
  contentModificationService,
  notificationService,
  userPermissionService,
} from "../../../services/index.js";

/**
 * addNews
 * @param req
 * @param res
 */
export const addNews = async (req, res, next) => {
  try {
    const reqBody = req.body;
    const loginUserId = req.userDetails.userId;
    const userRole = req.userDetails.user_type ?? "";
    const roleId = req.userDetails.user_role_id ?? "";
    if (!userRole) {
      if (req.file && req.file.path) customFileHelper.customFileUnlink(fs, req.file.path);
      throw StatusError.badRequest(res.__("Invalid user role"));
    }
    let fileLocation = "";
    let fileName = "";
    if (req.file) {
      const fileDetails = req.file;
      fileName = fileDetails.filename ? fileDetails.filename : "";
      fileLocation = fileDetails.destination ? fileDetails.destination + "/" + fileName : "";
    }

    const totalNews = await model.news.max("list_order");
    const whl = true;
    let slugName = "";
    let rslug = reqBody.title;
    let regenarate = false;
    while (whl) {
      const generatedSlug = await generalHelper.generateSlugName(rslug, regenarate);
      // check for slug name existance in tag category table
      const isExists = await model.news.findOne({
        where: { slug_name: generatedSlug },
        attributes: ["id", "slug_name"],
      });
      if (!isExists) {
        regenarate = false;
        slugName = generatedSlug;
        break;
      } else {
        regenarate = true;
        rslug = generatedSlug;
      }
    }
    let listOrder = (totalNews ?? 0) + 1;
    // add details
    const inputDetails = {
      uuid: uuidv4(),
      title: reqBody.title,
      type: reqBody.type,
      short_description: reqBody.short_description ?? null,
      description: reqBody.description ?? null,
      slug_name: slugName,
      list_order: listOrder,
      website_link: reqBody.website_link,
      status: reqBody.status,
      published_at: await customDateTimeHelper.changeDateFormat(
        reqBody.published_at,
        "YYYY-MM-DD HH:mm:ss",
      ),
      created_at: await customDateTimeHelper.getCurrentDateTime(),
      created_by: loginUserId,
    };
    let insRes;
    let sucMess = "success";
    let isdelimg = false;
    if (userRole == "superadmin" || userRole == "administrator" || userRole == "approver") {
      const check = await userPermissionService.checkUserPermission(roleId, loginUserId, [
        "news_event.add",
      ]);
      if (check) {
        insRes = await model.news.create(inputDetails);
        isdelimg = true;
      } else {
        insRes = null;
      }
    } else {
      if (fileName) {
        const uploadImage = {
          news_id: "",
          file_name: fileName,
          file_path: fileLocation,
          list_order: 1,
          created_by: loginUserId,
          created_at: await customDateTimeHelper.getCurrentDateTime(),
        };
        inputDetails.news_image = JSON.stringify(uploadImage);
      }
      insRes = await model.tempNews.create(inputDetails);
      if (insRes && insRes.id > 0) {
        sucMess = "Your addition request has been save successfully. Please wait for approval!";
        await contentModificationService.addRequest({
          temp_id: insRes.id,
          request_for: "news",
          action_type: "add",
          created_at: inputDetails.created_at,
          created_by: inputDetails.created_by,
        });
        await notificationService.generateNotificationForContentApproval(
          {
            created_by: loginUserId,
            notification_type: "content_approval",
            type: "update",
            title: `A new news & event addition requested`,
            item_id: insRes.id,
            item_description: `A new news & event "${inputDetails.title}" addition requested by publisher`,
            item: inputDetails,
          },
          null,
          ["news_event.status_change"],
        );
      }
    }
    if (insRes && insRes.id > 0) {
      if (fileName && isdelimg) {
        const liOrder = await model.newsImage.max("list_order", {
          where: {
            news_id: insRes.id,
          },
        });
        const uploadImage = {
          news_id: insRes.id,
          file_name: fileName,
          file_path: fileLocation,
          list_order: (liOrder ?? 0) + 1,
          created_by: loginUserId,
          created_at: await customDateTimeHelper.getCurrentDateTime(),
        };
        await model.newsImage.create(uploadImage);
      }
      res.ok({
        message: res.__(sucMess),
      });
    } else {
      if (req.file.path) customFileHelper.customFileUnlink(fs, req.file.path);
      throw StatusError.badRequest(res.__("SomeThingWentWrong"));
    }
  } catch (error) {
    if (req.file) customFileHelper.customFileUnlink(fs, req.file.path);
    console.log(error);
    next(error);
  }
};
