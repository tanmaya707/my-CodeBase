import model from "../../../models/index.js";
import { PAGINATION_LIMIT } from "../../../utils/constants.js";
import { paginationService } from "../../../services/index.js";
import { Sequelize, Op, col, fn } from "sequelize";
import { envs } from "../../../config/envs.js";

/**
 * newsList
 * @param req
 * @param res
 */
export const newsList = async (req, res, next) => {
  try {
    const reqBody = req.query;

    const searchType = reqBody.type ? reqBody.type : "";
    const searchName = reqBody.name ? reqBody.name.trim() : "";
    let resultData = [];
    const defautlPageNo = 1;
    const page = reqBody.page ? reqBody.page : defautlPageNo;
    const limit = reqBody.limit ? reqBody.limit : PAGINATION_LIMIT;

    const sortOrder = reqBody.sort_order ? reqBody.sort_order : "desc";
    const sortBy = reqBody.sort_by ? reqBody.sort_by : "";

    let searchDateType = !reqBody.search_date_type ? "" : reqBody.search_date_type;
    const searchStartDate = reqBody.start_date ? reqBody.start_date : "";
    const searchEndDate = reqBody.end_date ? reqBody.end_date : "";

    const loginUserId = req.userDetails.userId;
    const searchParams = {
      page: page,
      limit: limit,
    };

    let dateFilter = "news.created_at";
    let condition = {};
    if (searchDateType == "created_date") {
      dateFilter = "news.created_at";
    }
    if (searchDateType == "published_date") {
      dateFilter = "news.published_at";
    }
    let applyMoreand = false;
    // Add extra conditions for Startdate
    if (searchDateType && searchStartDate && !searchEndDate) {
      condition[Op.and] = [
        Sequelize.where(Sequelize.fn("DATE", Sequelize.col(dateFilter)), {
          [Op.gte]: searchStartDate,
        }),
      ];
      applyMoreand = true;
    }
    // Add extra conditions for Enddate
    if (searchDateType && searchEndDate && !searchStartDate) {
      condition[Op.and] = [
        Sequelize.where(Sequelize.fn("DATE", Sequelize.col(dateFilter)), {
          [Op.lte]: searchEndDate,
        }),
      ];
      applyMoreand = true;
    }
    // Add extra conditions for Startdate & EndDate
    if (searchDateType && searchStartDate && searchEndDate) {
      condition[Op.and] = [
        Sequelize.where(Sequelize.fn("DATE", Sequelize.col(dateFilter)), {
          [Op.between]: [searchStartDate, searchEndDate],
        }),
      ];
      applyMoreand = true;
    }

    const attributes = [
      "id",
      "title",
      "type",
      "short_description",
      "description",
      "website_link",
      "published_at",
      "status",
      "created_at",
    ];

    if (sortOrder && sortBy == "type") {
      searchParams.sortOrderObj = [[col("type"), sortOrder]];
    } else if (sortOrder && sortBy == "created_at") {
      searchParams.sortOrderObj = [[Sequelize.literal("created_at"), sortOrder]];
    } else {
      searchParams.sortOrderObj = [[Sequelize.literal("created_at"), sortOrder]];
    }

    const includeQuery = [
      {
        model: model.newsImage,
        attributes: [
          [fn("REPLACE", col("newsImages.file_path"), `public/uploads/`, `public/`), "file_path"],
        ],
        //where: { status: "active" },
        required: false,
      },
      {
        model: model.usersActivity,
        attributes: ["id"],
        where: { status: "active", type: "news", event_type: "view" },
        required: false,
      },
    ];
    if (searchType) {
      if (applyMoreand) {
        condition[Op.and].push({ type: searchType });
      } else {
        condition[Op.and] = { type: searchType };
      }
    }
    if (searchName) {
      const arrName = searchName.split(" ");
      let orArr = [
        { title: { [Op.like]: `%${searchName}%` } },
        { short_description: { [Op.like]: `%${searchName}%` } },
      ];
      if (arrName.length > 1) {
        arrName.map((name) => {
          if (name) {
            orArr.push({ title: { [Op.like]: `%${name}%` } });
            orArr.push({ short_description: { [Op.like]: `%${name}%` } });
          }
        });
      }
      condition[Op.or] = orArr;
    }

    resultData = await paginationService.pagination(
      searchParams,
      model.news,
      includeQuery,
      condition,
      attributes,
    );
    if (resultData.rows && resultData.rows.length > 0) {
      resultData.rows = resultData.rows.map((record) => {
        record.dataValues.news_images = record.dataValues.newsImages;
        record.dataValues.view_count = !record.dataValues.usersActivities.length
          ? 0
          : record.dataValues.usersActivities.length;
        delete record.dataValues.newsImages;
        delete record.dataValues.usersActivities;
        return record;
      });
    }
    res.ok({
      page: page,
      limit: limit,
      total_records: resultData.count,
      total_pages: resultData.count > 0 ? Math.ceil(resultData.count / limit) : 0,
      results: resultData.rows,
    });
  } catch (error) {
    console.log(error);
    next(error);
  }
};
