import { announcementTypeList } from "./announcementTypeList.js";
import { newsDetails } from "./newsDetails.js";
import { deleteNews } from "./deleteNews.js";
import { addNews } from "./addNews.js";
import { editNews } from "./editNews.js";
import { newsList } from "./newsList.js";

export { announcementTypeList, newsDetails, deleteNews, addNews, editNews, newsList };
