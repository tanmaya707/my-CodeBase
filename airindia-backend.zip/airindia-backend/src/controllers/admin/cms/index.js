import { cmsList } from "./cmsList.js";
import { cmsAdd } from "./cmsAdd.js";
import { cmsEdit } from "./cmsEdit.js";
import { cmsDetails } from "./cmsDetails.js";
import { cmsStatusChange } from "./cmsStatusChange.js";
import { cmsDelete } from "./cmsDelete.js";

export {
  cmsList,
  cmsAdd,
  cmsEdit,
  cmsDetails,
  cmsStatusChange,
  cmsDelete,
};
