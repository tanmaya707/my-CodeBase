import model from "../../../models/index.js";
import { StatusError } from "../../../config/index.js";
import { customDateTimeHelper } from "../../../helpers/index.js";
import { Op } from "sequelize";
import {
  contentModificationService,
  notificationService,
  userPermissionService,
} from "../../../services/index.js";

/**
 * cmsEdit
 * @param req
 * @param res
 */
export const cmsEdit = async (req, res, next) => {
  try {
    const userId = req.userDetails.userId;
    const reqBody = req.body;
    const pageType = reqBody.page_type ? reqBody.page_type : ""; // allowed values privacy-policy/terms-of-service/about-us
    const pageId = reqBody.page_id ? reqBody.page_id : "";
    const pageContent = reqBody.content ? reqBody.content : "";
    //const language = req.accept_language ?? "en";
    const language = "en";
    const pageTitle = reqBody.title ? reqBody.title : "";
    //const publishedDate = reqBody.date ? reqBody.date : "";
    const loginUserId = req.userDetails.userId;
    if (!loginUserId) throw StatusError.badRequest(res.__("Invalid user id"));
    const userRole = req.userDetails.user_type ?? "";
    const roleId = req.userDetails.user_role_id ?? "";
    if (!userRole) {
      throw StatusError.badRequest(res.__("Invalid user role"));
    }
    // check for page id existance in custom pages table
    const isExists = await model.cmsPage.findOne({
      //attributes: ["id", "title", "slug", "type"],
      where: {
        id: pageId,
        slug: pageType,
        type: "default",
        site_language: language,
      },
    });
    if (!isExists) throw StatusError.badRequest(res.__("Invalid page id or page type"));

    // check duplicate page title exists
    const isExistsTitle = await model.cmsPage.findOne({
      //attributes: ["id", "title", "slug", "type"],
      where: {
        title: pageTitle,
        slug: pageType,
        type: "default",
        id: { [Op.ne]: pageId },
        site_language: language,
      },
    });
    if (isExistsTitle) throw StatusError.badRequest(res.__("This page title is already exist"));

    const requestDetails = {
      title: pageTitle,
      meta: pageTitle,
      body: pageContent,
      // published_at: await customDateTimeHelper.changeDateFormat(
      //   publishedDate,
      //   "YYYY-MM-DD HH:mm:ss",
      // ),
      updated_by: userId,
      updated_at: await customDateTimeHelper.getCurrentDateTime(),
    };
    let updt = 0;
    let sucMess = "success";
    if (userRole == "superadmin" || userRole == "administrator" || userRole == "approver") {
      const check = await userPermissionService.checkUserPermission(roleId, loginUserId, [
        "setting.static_page.edit",
      ]);
      if (check) {
        requestDetails.updated_at = await customDateTimeHelper.getCurrentDateTime();
        requestDetails.updated_by = loginUserId;
        const [upResp] = await model.cmsPage.update(requestDetails, {
          where: { id: pageId },
        });
        if (upResp > 0) {
          updt = 1;
        }
      }
    } else {
      const checkForPendingRequest = await contentModificationService.checkForPendingRequest({
        id: pageId,
        request_for: "custom_pages",
        action_type: "edit",
      });
      if (checkForPendingRequest) {
        throw StatusError.badRequest(
          res.__(
            "A modification request is already in progress. Please wait for the approval response and try again later.",
          ),
        );
      } else {
        requestDetails.cms_id = pageId;
        requestDetails.earlier_data = isExists ? JSON.stringify(isExists) : null;
        requestDetails.created_at = requestDetails.updated_at;
        requestDetails.created_by = requestDetails.updated_by;
        requestDetails.slug = isExists.slug;
        requestDetails.status = isExists.status;
        const insRes = await model.tempCmsPage.create(requestDetails);

        if (insRes && insRes.id > 0) {
          sucMess =
            "Your modification request has been save successfully. Please wait for approval!";
          await contentModificationService.addRequest({
            temp_id: insRes.id,
            request_for: "custom_pages",
            action_type: "edit",
            created_at: requestDetails.updated_at,
            created_by: requestDetails.updated_by,
          });
          await notificationService.generateNotificationForContentApproval(
            {
              created_by: loginUserId,
              notification_type: "content_approval",
              type: "update",
              title: `A CMS modification requested`,
              item_id: insRes.id,
              item_description: `A CMS,${insRes.title} modification requested by publisher`,
              item: insRes,
            },
            null,
            ["setting.static_page.status_change"],
          );
          updt = 1;
        }
      }
    }
    if (updt > 0) {
      res.ok({
        message: res.__(sucMess),
      });
    } else {
      throw StatusError.badRequest(res.__("SomeThingWentWrong"));
    }
  } catch (error) {
    next(error);
  }
};
