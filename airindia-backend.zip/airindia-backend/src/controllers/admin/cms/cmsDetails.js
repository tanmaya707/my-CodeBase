import model from "../../../models/index.js";
import { StatusError } from "../../../config/index.js";

/**
 * cmsDetails
 * @param req
 * @param res
 */
export const cmsDetails = async (req, res, next) => {
  try {
    const reqBody = req.query;
    const pageType = reqBody.page_type ? reqBody.page_type.trim() : ""; // allowed values privacy-policy/terms-of-service/about-us
    //const pageId = reqBody.page_id ? reqBody.page_id : "";
    //const language = req.accept_language ?? "en";
    const language = "en";
    // check for page id existance in custom pages table
    const getInformations = await model.cmsPage.findOne({
      attributes: [
        ["slug", "page_type"],
        ["id", "page_id"],
        ["title", "page_title"],
        ["body", "page_content"],
        "status",
        //["published_at", "date"],
        ["created_at", "date"],
      ],
      where: {
        //id: pageId,
        slug: pageType,
        type: "default",
        site_language: language,
      },
    });
    console.log(getInformations);
    if (!getInformations) throw StatusError.badRequest(res.__("Invalid page type"));

    res.ok(getInformations);
  } catch (error) {
    console.log(error);
    next(error);
  }
};
