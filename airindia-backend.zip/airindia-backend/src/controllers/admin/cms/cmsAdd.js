import model from "../../../models/index.js";
import { StatusError } from "../../../config/index.js";
import { customDateTimeHelper } from "../../../helpers/index.js";
import {
  contentModificationService,
  notificationService,
  userPermissionService,
} from "../../../services/index.js";

/**
 * cmsAdd
 * @param req
 * @param res
 */
export const cmsAdd = async (req, res, next) => {
  try {
    const userId = req.userDetails.userId;
    const reqBody = req.body;
    const pageType = reqBody.page_type ? reqBody.page_type : ""; // allowed values privacy-policy/terms-of-service/about-us
    const pageTitle = reqBody.title ? reqBody.title : "";
    //const publishedDate = reqBody.date ? reqBody.date : "";
    const pageContent = reqBody.content ? reqBody.content : "";
    //const language = req.accept_language ?? "en";
    const language = "en";
    const loginUserId = req.userDetails.userId;
    if (!loginUserId) throw StatusError.badRequest(res.__("Invalid user id"));
    const userRole = req.userDetails.user_type ?? "";
    const roleId = req.userDetails.user_role_id ?? "";
    if (!userRole) {
      throw StatusError.badRequest(res.__("Invalid user role"));
    }
    // check duplicate page title exists
    const isExists = await model.cmsPage.findOne({
      attributes: ["id", "title", "slug", "type"],
      where: {
        title: pageTitle,
        slug: pageType,
        type: "default",
        site_language: language,
        status: "inactive",
      },
    });
    if (isExists) throw StatusError.badRequest(res.__("This page title is already exist"));

    const inputDetails = {
      title: pageTitle,
      body: pageContent,
      slug: pageType,
      site_language: language,
      user_id: userId,
      // published_at: await customDateTimeHelper.changeDateFormat(
      //   publishedDate,
      //   "YYYY-MM-DD HH:mm:ss",
      // ),
      created_at: await customDateTimeHelper.getCurrentDateTime(),
      created_by: userId,
    };
    let insRes;
    let sucMess = "success";
    if (userRole == "superadmin" || userRole == "administrator" || userRole == "approver") {
      const check = await userPermissionService.checkUserPermission(roleId, loginUserId, [
        "setting.static_page.add",
      ]);
      if (check) {
        insRes = await model.cmsPage.create(inputDetails);
      } else {
        insRes = null;
      }
    } else {
      insRes = await model.tempCmsPage.create(inputDetails);
      if (insRes && insRes.id > 0) {
        sucMess = "Your addition request has been save successfully. Please wait for approval!";
        await contentModificationService.addRequest({
          temp_id: insRes.id,
          request_for: "custom_pages",
          action_type: "add",
          created_at: inputDetails.created_at,
          created_by: inputDetails.created_by,
        });
        await notificationService.generateNotificationForContentApproval(
          {
            created_by: loginUserId,
            notification_type: "content_approval",
            type: "update",
            title: `A new CMS addition requested`,
            item_id: insRes.id,
            item_description: `A new CMS,${inputDetails.title} addition requested by publisher`,
            item: inputDetails,
          },
          null,
          ["setting.static_page.status_change"],
        );
      }
    }
    res.ok({
      message: res.__(sucMess),
    });
  } catch (error) {
    next(error);
  }
};
