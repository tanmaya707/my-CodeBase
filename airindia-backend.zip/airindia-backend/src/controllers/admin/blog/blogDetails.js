import model from "../../../models/index.js";
import { Sequelize, Op, col, fn } from "sequelize";
import { StatusError, envs } from "../../../config/index.js";

/**
 * blogDetails
 * @param req
 * @param res
 */
export const blogDetails = async (req, res, next) => {
  try {
    const reqBody = req.params;
    const blogId = reqBody.id ? reqBody.id : "";
    if (!blogId) throw StatusError.badRequest(res.__("Invalid id"));
    const checkId = await model.blog.count({
      where: { id: blogId },
    });
    if (checkId == 0) throw StatusError.badRequest(res.__("Invalid id"));

    let resultData = {};
    const condition = { id: blogId };
    const attributes = [
      "id",
      "uuid",
      "blog_title",
      "blog_short_description",
      "blog_description",
      "website_link",
      "published_at",
      "created_at",
      "status",
    ];

    const includeQuery = [
      {
        model: model.blogImage,
        attributes: [
          ["id", "image_id"],
          "file_name",
          [fn("REPLACE", col("blogImages.file_path"), `public/uploads/`, `public/`), "file_path"],
        ],
        //where: { status: "active" },
        required: false,
      },
    ];

    resultData = await model.blog.findOne({
      attributes: attributes,
      include: includeQuery,
      where: condition,
    });

    if (resultData && resultData.dataValues && resultData.dataValues.blogImages) {
      resultData.dataValues.blog_images = resultData.dataValues.blogImages;
    }

    res.ok(resultData ? resultData : {});
  } catch (error) {
    next(error);
  }
};
