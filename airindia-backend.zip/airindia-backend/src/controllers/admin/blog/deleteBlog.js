import model from "../../../models/index.js";
import { StatusError } from "../../../config/index.js";
import {
  contentModificationService,
  notificationService,
  userPermissionService,
} from "../../../services/index.js";

/**
 * deleteBlog
 * @param req
 * @param res
 */
export const deleteBlog = async (req, res, next) => {
  try {
    const reqBody = req.body;
    const blogId = reqBody.id ? reqBody.id : "";
    if (!blogId) throw StatusError.badRequest(res.__("Invalid id"));

    const checkId = await model.blog.count({
      where: { id: blogId },
    });
    if (checkId == 0) throw StatusError.badRequest(res.__("Invalid id"));
    const loginUserId = req.userDetails.userId;
    const userRole = req.userDetails.user_type ?? "";
    const roleId = req.userDetails.user_role_id ?? "";
    if (!userRole) {
      throw StatusError.badRequest(res.__("Invalid user role"));
    }
    let desRes;
    let sucMess = "success";
    let delImg = false;
    if (userRole == "superadmin" || userRole == "administrator" || userRole == "approver") {
      const check = await userPermissionService.checkUserPermission(roleId, loginUserId, [
        "success_story.delete",
      ]);
      if (check) {
        desRes = await model.blog.destroy({
          where: { id: blogId },
        });
        delImg = true;
      } else {
        desRes = 0;
      }
    } else {
      const checkForPendingRequest = await contentModificationService.checkForPendingRequest({
        id: blogId,
        request_for: "blogs",
        action_type: "delete",
      });
      if (checkForPendingRequest) {
        throw StatusError.badRequest(
          res.__(
            "A modification request is already in progress. Please wait for the approval response and try again later.",
          ),
        );
      } else {
        const detail = await model.blog.findOne({ where: { id: blogId } });
        const oldImage = await model.blogImage.findOne({
          //attributes: ["id", "created_by"],
          where: { blog_id: blogId },
        });
        detail.blog_id = detail.id;
        detail.blog_image = oldImage ?? {};
        delete detail.id;
        const insRes = await model.tempBlog.create(detail);
        if (insRes && insRes.id > 0) {
          desRes = 1;
          sucMess = "Your delete request has been save successfully. Please wait for approval!";
          await contentModificationService.addRequest({
            temp_id: insRes.id,
            request_for: "blogs",
            action_type: "delete",
            created_at: detail.created_at,
            created_by: detail.created_by,
          });
          await notificationService.generateNotificationForContentApproval(
            {
              created_by: loginUserId,
              notification_type: "content_approval",
              type: "update",
              title: `A success story delete requested`,
              item_id: detail.id,
              item_description: `A success story "${detail.blog_title}" delete requested by publisher`,
              item: detail,
            },
            null,
            ["success_story.status_change"],
          );
        }
      }
    }
    if (desRes > 0) {
      if (delImg) {
        await model.blogImage.destroy({
          where: { blog_id: blogId },
        });
      }
      res.ok({
        message: res.__(sucMess),
      });
    } else {
      throw StatusError.badRequest(res.__("SomeThingWentWrong"));
    }
  } catch (error) {
    next(error);
  }
};
