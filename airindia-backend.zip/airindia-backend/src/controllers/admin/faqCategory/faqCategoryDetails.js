import model from "../../../models/index.js";
import { Sequelize, Op, col } from "sequelize";
import { StatusError } from "../../../config/index.js";

/**
 * faqCategoryDetails
 * @param req
 * @param res
 */
export const faqCategoryDetails = async (req, res, next) => {
  try {
    const loginUserId = req.userDetails.userId;    
    if (!loginUserId) throw StatusError.badRequest(res.__("Invalid user id"));
    const reqBody = req.params;
    const faqCategoryId = reqBody.id ? reqBody.id : "";
    if (!faqCategoryId) throw StatusError.badRequest(res.__("Invalid id"));

    const checkId = await model.faqCategory.count({
      where: { id: faqCategoryId },
    });
    if (checkId == 0) throw StatusError.badRequest(res.__("Invalid id"));

    let resultData = {};
    const condition = { id: faqCategoryId };
    const attributes = [
      "id",
      "uuid",
      ["name","category_name"],
      "slug_name",
      "list_order",
      "status",
      "created_by",	
      "created_at",	
      "updated_by",
      "updated_at"
    ];

    const includeQuery = [
      {
        model: model.faq,
        attributes: ["id"],
        //where: { status: "active" },
        required: false,
      },
    ];

    resultData = await model.faqCategory.findOne({
      attributes: attributes,
      include: includeQuery,
      where: condition,
    });

    if (resultData && resultData.dataValues && resultData.dataValues.faqs) {
      resultData.dataValues.faq_count = resultData.dataValues.faqs.length??0;
    }
    delete resultData.dataValues.faqs;
    
    res.ok(resultData ? resultData : {});
  } catch (error) {
    next(error);
  }
};
