import { faqCategoryDetails } from "./faqCategoryDetails.js";
import { deleteFaqCategory } from "./deleteFaqCategory.js";
import { addFaqCategory } from "./addFaqCategory.js";
import { editFaqCategory } from "./editFaqCategory.js";
import { faqCategoryList } from "./faqCategoryList.js";

export { faqCategoryDetails, deleteFaqCategory, addFaqCategory, editFaqCategory, faqCategoryList };
