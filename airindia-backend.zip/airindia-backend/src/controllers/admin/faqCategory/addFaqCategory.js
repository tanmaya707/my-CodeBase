import model from "../../../models/index.js";
import { customDateTimeHelper, generalHelper } from "../../../helpers/index.js";
import { StatusError } from "../../../config/index.js";
import { v4 as uuidv4 } from "uuid";
import { Op } from "sequelize";
import {
  contentModificationService,
  notificationService,
  userPermissionService,
} from "../../../services/index.js";

/**
 * addFaqCategory
 * @param req
 * @param res
 */
export const addFaqCategory = async (req, res, next) => {
  try {
    const reqBody = req.body;
    const loginUserId = req.userDetails.userId;
    if (!loginUserId) throw StatusError.badRequest(res.__("Invalid user id"));
    const userRole = req.userDetails.user_type ?? "";
    const roleId = req.userDetails.user_role_id ?? "";
    if (!userRole) {
      throw StatusError.badRequest(res.__("Invalid user role"));
    }
    const searchName = reqBody.category_name;
    // checking for faqCategory existance
    const faqCategory = await model.faqCategory.findOne({
      where: { name: { [Op.like]: `%${searchName}%` } },
    });
    if (faqCategory) throw StatusError.badRequest(res.__("Faq category is already taken"));

    const totalFaqs = await model.faqCategory.max("list_order");
    const whl = true;
    let slugName = "";
    let rslug = searchName;
    let regenarate = false;
    while (whl) {
      const generatedSlug = await generalHelper.generateSlugName(rslug, regenarate);
      // check for slug name existance in tag category table
      const isExists = await model.faqCategory.findOne({
        where: { slug_name: generatedSlug },
        attributes: ["id", "slug_name"],
      });
      if (!isExists) {
        regenarate = false;
        slugName = generatedSlug;
        break;
      } else {
        regenarate = true;
        rslug = generatedSlug;
      }
    }
    let listOrder = (totalFaqs ?? 0) + 1;
    // add details
    const inputDetails = {
      uuid: uuidv4(),
      name: searchName,
      slug_name: slugName,
      list_order: listOrder,
      status: reqBody.status,
      created_at: await customDateTimeHelper.getCurrentDateTime(),
      created_by: loginUserId,
    };
    let insRes;
    let sucMess = "success";
    if (userRole == "superadmin" || userRole == "administrator" || userRole == "approver") {
      const check = await userPermissionService.checkUserPermission(roleId, loginUserId, [
        "setting.faq.add",
      ]);
      if (check) {
        insRes = await model.faqCategory.create(inputDetails);
      } else {
        insRes = null;
      }
    } else {
      insRes = await model.tempFaqCategory.create(inputDetails);
      if (insRes && insRes.id > 0) {
        sucMess = "Your addition request has been save successfully. Please wait for approval!";
        await contentModificationService.addRequest({
          temp_id: insRes.id,
          request_for: "faq_categories",
          action_type: "add",
          created_at: inputDetails.created_at,
          created_by: inputDetails.created_by,
        });
        await notificationService.generateNotificationForContentApproval(
          {
            created_by: loginUserId,
            notification_type: "content_approval",
            type: "update",
            title: `A new faq category addition requested`,
            item_id: insRes.id,
            item_description: `A new faq category,${inputDetails.name} addition requested by publisher`,
            item: inputDetails,
          },
          null,
          ["setting.faq.status_change"],
        );
      }
    }
    if (insRes && insRes.id > 0) {
      res.ok({
        message: res.__(sucMess),
      });
    } else {
      throw StatusError.badRequest(res.__("SomeThingWentWrong"));
    }
  } catch (error) {
    console.log(error);
    next(error);
  }
};
