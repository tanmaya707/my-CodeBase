import model from "../../../models/index.js";
import { PAGINATION_LIMIT, GLOBAL_PARAMS } from "../../../utils/constants.js";
import {
  paginationService,
  userPermissionService,
  contentModificationService,
} from "../../../services/index.js";
import { Sequelize, Op } from "sequelize";

/**
 * contentApprovalList
 * @param req
 * @param res
 */
export const contentApprovalList = async (req, res, next) => {
  try {
    const reqBody = req.query;

    const searchName = reqBody.name ? reqBody.name.trim() : "";
    let resultData = [];
    const defautlPageNo = 1;
    const page = reqBody.page ? reqBody.page : defautlPageNo;
    const limit = reqBody.limit ? reqBody.limit : PAGINATION_LIMIT;

    const sortOrder = reqBody.sort_order ? reqBody.sort_order : "desc";
    const sortBy = reqBody.sort_by ? reqBody.sort_by : "";

    const loginUserId = req.userDetails.userId;
    const searchParams = {
      page: page,
      limit: limit,
    };

    let condition = {};
    const userRoleId = req.userDetails.user_role_id ?? "";
    const userRole = req.userDetails.user_type ?? "";
    if (!userRoleId) throw StatusError.badRequest(res.__("Invalid user role"));
    if (userRole == "approver" || userRole == "publisher") {
      const findContentApprovalSection = await userPermissionService.findContentApprovalSection(
        loginUserId,
        userRoleId,
      );
      condition = {
        request_for: {
          [Op.or]: [
            {
              [Op.in]:
                findContentApprovalSection.group_name.length > 0
                  ? findContentApprovalSection.group_name
                  : ["none"],
            },
            {
              [Op.in]:
                findContentApprovalSection.sub_group_name.length > 0
                  ? findContentApprovalSection.sub_group_name
                  : ["none"],
            },
          ],
        },
      };
    }
    const attributes = [
      "id",
      "uuid",
      "temp_id",
      "request_for",
      "action_type",
      "comment",
      "status",
      "created_at",
    ];

    searchParams.sortOrderObj = [[Sequelize.literal("created_at"), sortOrder]];

    const includeQuery = [
      {
        model: model.user,
        as: "createdBy",
        attributes: ["first_name", "last_name"],
        required: true,
      },
    ];
    if (searchName) {
      let orArr = [
        { comment: { [Op.like]: `%${searchName}%` } },
        { status: { [Op.like]: `%${searchName}%` } },
        { action_type: { [Op.like]: `%${searchName}%` } },
        { request_for: { [Op.like]: `%${searchName}%` } },
      ];

      condition[Op.or] = orArr;
    }

    resultData = await paginationService.pagination(
      searchParams,
      model.contentModificationRequest,
      includeQuery,
      condition,
      attributes,
    );
    let retResult = [];
    if (resultData.rows.length > 0) {
      for (let eachRow of resultData.rows) {
        if (eachRow.dataValues.request_for && eachRow.dataValues.temp_id) {
          eachRow.dataValues.display_request_for = eachRow.dataValues.request_for
            ? (GLOBAL_PARAMS.FOR_LIST[eachRow.dataValues.request_for] ?? "")
            : "";
          if (
            eachRow.dataValues.request_for == "home_page" ||
            eachRow.dataValues.request_for == "page_content" ||
            eachRow.dataValues.request_for == "custom_pages" ||
            eachRow.dataValues.request_for == "pages"
          ) {
            eachRow.dataValues.display_request_for =
              await contentModificationService.getApprovalListType(
                eachRow.dataValues.temp_id,
                eachRow.dataValues.request_for,
              );
          }
        }
        eachRow.dataValues.display_action_type = eachRow.dataValues.action_type
          ? (GLOBAL_PARAMS.ACTION_LIST[eachRow.dataValues.action_type] ?? "")
          : "";
        eachRow.dataValues.request_from = `${eachRow?.createdBy?.first_name} ${eachRow?.createdBy?.last_name}`;
        delete eachRow.dataValues.createdBy;
        retResult.push(eachRow);
      }
    }
    res.ok({
      page: page,
      limit: limit,
      total_records: resultData.count,
      total_pages: resultData.count > 0 ? Math.ceil(resultData.count / limit) : 0,
      results: retResult,
    });
  } catch (error) {
    console.log(error);
    next(error);
  }
};
