import { StatusError } from "../../../config/index.js";
import { contentModificationService } from "../../../services/index.js";
import model from "../../../models/index.js";

/**
 * contentApproveReject
 * @param req
 * @param res
 */
export const contentApproveReject = async (req, res, next) => {
  try {
    const reqBody = req.body;
    const loginUserId = req.userDetails.userId;
    const id = reqBody.id ? reqBody.id : ""; //request id
    const tempId = reqBody.temp_id ? reqBody.temp_id : ""; //temp id
    const contentStatus = reqBody.content_status ? reqBody.content_status : "";
    if (!id) throw StatusError.badRequest(res.__("Invalid id"));

    const checkId = await model.contentModificationRequest.count({
      where: { id: id, status: "pending" },
    });
    if (checkId == 0) throw StatusError.badRequest(res.__("Invalid id"));
    let contentApproval;
    if (contentStatus == "rejected") {
      contentApproval = await contentModificationService.rejectContent(req);
    } else if (contentStatus == "approved") {
      contentApproval = await contentModificationService.approveContent(req);
    }

    if (contentApproval) {
      res.ok({
        message: res.__("success"),
      });
    } else {
      throw StatusError.badRequest(res.__("SomeThingWentWrong"));
    }
  } catch (error) {
    console.log(error);
    next(error);
  }
};
