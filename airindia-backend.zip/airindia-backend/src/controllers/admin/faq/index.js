import { faqDetails } from "./faqDetails.js";
import { deleteFaq } from "./deleteFaq.js";
import { addFaq } from "./addFaq.js";
import { editFaq } from "./editFaq.js";
import { faqList } from "./faqList.js";
import { faqCategoryList } from "./faqCategoryList.js";

export { faqDetails, deleteFaq, addFaq, editFaq, faqList, faqCategoryList };
