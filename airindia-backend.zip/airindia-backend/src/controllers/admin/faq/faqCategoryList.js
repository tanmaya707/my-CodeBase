import model from "../../../models/index.js";

/**
 * faqCategoryList
 * @param req
 * @param res
 */
export const faqCategoryList = async (req, res, next) => {
  try {
    const list = await model.faqCategory.findAll({
      attributes: ["id","uuid",["name","category_name"]],
      where: { status: "active"},
    });
    res.ok({
      results: list,
    });
  } catch (error) {
    next(error);
  }
};
