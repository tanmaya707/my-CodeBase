import model from "../../../models/index.js";
import { customDateTimeHelper } from "../../../helpers/index.js";
import { StatusError } from "../../../config/index.js";
import { v4 as uuidv4 } from "uuid";
import {
  contentModificationService,
  notificationService,
  userPermissionService,
} from "../../../services/index.js";

/**
 * addFaq
 * @param req
 * @param res
 */
export const addFaq = async (req, res, next) => {
  try {
    const reqBody = req.body;
    const loginUserId = req.userDetails.userId;
    if (!loginUserId) throw StatusError.badRequest(res.__("Invalid user id"));
    const userRole = req.userDetails.user_type ?? "";
    const roleId = req.userDetails.user_role_id ?? "";
    if (!userRole) {
      throw StatusError.badRequest(res.__("Invalid user role"));
    }
    // checking for faqCategory existance
    const faqCategory = await model.faqCategory.findOne({
      where: { id: reqBody.category_id, status: "active" },
    });
    if (!faqCategory) throw StatusError.badRequest(res.__("Faq category is not valid"));

    const totalFaqs = await model.faq.max("list_order", {
      where: { faq_category_id: reqBody.category_id },
    });
    let listOrder = (totalFaqs ?? 0) + 1;
    // add details
    const inputDetails = {
      uuid: uuidv4(),
      faq_category_id: reqBody.category_id,
      question: reqBody.question ?? null,
      answer: reqBody.answer ?? null,
      list_order: listOrder,
      status: reqBody.status,
      created_at: await customDateTimeHelper.getCurrentDateTime(),
      created_by: loginUserId,
    };
    let insRes;
    let sucMess = "success";
    if (userRole == "superadmin" || userRole == "administrator" || userRole == "approver") {
      const check = await userPermissionService.checkUserPermission(roleId, loginUserId, [
        "setting.faq.add",
      ]);
      if (check) {
        insRes = await model.faq.create(inputDetails);
      } else {
        insRes = null;
      }
    } else {
      insRes = await model.tempFaq.create(inputDetails);
      if (insRes && insRes.id > 0) {
        sucMess = "Your addition request has been save successfully. Please wait for approval!";
        await contentModificationService.addRequest({
          temp_id: insRes.id,
          request_for: "faqs",
          action_type: "add",
          created_at: inputDetails.created_at,
          created_by: inputDetails.created_by,
        });
        await notificationService.generateNotificationForContentApproval(
          {
            created_by: loginUserId,
            notification_type: "content_approval",
            type: "update",
            title: `A new faq addition requested`,
            item_id: insRes.id,
            item_description: `A new faq,${inputDetails.question} addition requested by publisher`,
            item: inputDetails,
          },
          null,
          ["setting.faq.status_change"],
        );
      }
    }
    if (insRes && insRes.id > 0) {
      res.ok({
        message: res.__(sucMess),
      });
    } else {
      throw StatusError.badRequest(res.__("SomeThingWentWrong"));
    }
  } catch (error) {
    console.log(error);
    next(error);
  }
};
