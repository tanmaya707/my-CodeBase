import model from "../../../models/index.js";
import { PAGINATION_LIMIT } from "../../../utils/constants.js";
import { paginationService } from "../../../services/index.js";
import { Sequelize, Op, col } from "sequelize";

/**
 * faqList
 * @param req
 * @param res
 */
export const faqList = async (req, res, next) => {
  try {
    const loginUserId = req.userDetails.userId;
    if (!loginUserId) throw StatusError.badRequest(res.__("Invalid user id"));
    const reqBody = req.query;
    const searchType = reqBody.category_id ? reqBody.category_id : "";
    const searchName = reqBody.name ? reqBody.name.trim() : "";
    let resultData = [];
    const defautlPageNo = 1;
    const page = reqBody.page ? reqBody.page : defautlPageNo;
    const limit = reqBody.limit ? reqBody.limit : PAGINATION_LIMIT;

    const sortOrder = reqBody.sort_order ? reqBody.sort_order : "desc";
    const sortBy = reqBody.sort_by ? reqBody.sort_by : "";

    let searchDateType = !reqBody.search_date_type ? "" : reqBody.search_date_type;
    const searchStartDate = reqBody.start_date ? reqBody.start_date : "";
    const searchEndDate = reqBody.end_date ? reqBody.end_date : "";

    
    const searchParams = {
      page: page,
      limit: limit,
    };

    let dateFilter = "faq.created_at";
    let condition = { };
    if (searchDateType == "created_date") {
      dateFilter = "faq.created_at";
    }
    let applyMoreand = false;
    // Add extra conditions for Startdate
    if (searchDateType && searchStartDate && !searchEndDate) {
      condition[Op.and] = [
        Sequelize.where(Sequelize.fn("DATE", Sequelize.col(dateFilter)), {
          [Op.gte]: searchStartDate,
        }),
      ];
      applyMoreand = true;
    }
    // Add extra conditions for Enddate
    if (searchDateType && searchEndDate && !searchStartDate) {
      condition[Op.and] = [
        Sequelize.where(Sequelize.fn("DATE", Sequelize.col(dateFilter)), {
          [Op.lte]: searchEndDate,
        }),
      ];
      applyMoreand = true;
    }
    // Add extra conditions for Startdate & EndDate
    if (searchDateType && searchStartDate && searchEndDate) {
      condition[Op.and] = [
        Sequelize.where(Sequelize.fn("DATE", Sequelize.col(dateFilter)), {
          [Op.between]: [searchStartDate, searchEndDate],
        }),
      ];
      applyMoreand = true;
    }

    const attributes = [
      "id",
      "uuid",
      "faq_category_id",
      "question",
      "answer",
      [col("faqCategory.name"),"category_name"],
      "status",
      "created_at"
    ];

    if (sortOrder && sortBy == "category") {
      searchParams.sortOrderObj = [[col("faqCategory.name"), sortOrder]];
    } else if (sortOrder && sortBy == "question") {
      searchParams.sortOrderObj = [[Sequelize.literal("question"), sortOrder]];
    } else {
      searchParams.sortOrderObj = [[Sequelize.literal("created_at"), sortOrder]];
    }

    const includeQuery = [
      {
        model: model.faqCategory,
        required: true,
      }
    ];
    if (searchType) {
      if (applyMoreand) {
        condition[Op.and].push({ "faq_category_id": searchType });
      } else {
        condition[Op.and] = { "faq_category_id": searchType };
      }
    }
    if (searchName) {
      const arrName = searchName.split(" ");
      let orArr = [
        { question: { [Op.like]: `%${searchName}%` } },
        { answer: { [Op.like]: `%${searchName}%` } },
      ];
      if (arrName.length > 1) {
        arrName.map((name) => {
          if (name) {
            orArr.push({ question: { [Op.like]: `%${name}%` } });
            orArr.push({ answer: { [Op.like]: `%${name}%` } });
          }
        });
      }
      condition[Op.or] = orArr;
    }

    resultData = await paginationService.pagination(
      searchParams,
      model.faq,
      includeQuery,
      condition,
      attributes,
    );
    if (resultData.rows && resultData.rows.length > 0) {
      resultData.rows = resultData.rows.map((record) => {
        delete record.dataValues.faqCategory;
        return record;
      });
    }
    res.ok({
      page: page,
      limit: limit,
      total_records: resultData.count,
      total_pages: resultData.count > 0 ? Math.ceil(resultData.count / limit) : 0,
      results: resultData.rows,
    });
  } catch (error) {
    console.log(error);
    next(error);
  }
};
