import model from "../../../models/index.js";
import { Sequelize, Op, col } from "sequelize";
import { StatusError } from "../../../config/index.js";

/**
 * faqDetails
 * @param req
 * @param res
 */
export const faqDetails = async (req, res, next) => {
  try {
    const loginUserId = req.userDetails.userId;    
    if (!loginUserId) throw StatusError.badRequest(res.__("Invalid user id"));
    const reqBody = req.params;
    const faqId = reqBody.id ? reqBody.id : "";
    if (!faqId) throw StatusError.badRequest(res.__("Invalid id"));

    const checkId = await model.faq.count({
      where: { id: faqId },
    });
    if (checkId == 0) throw StatusError.badRequest(res.__("Invalid id"));

    let resultData = {};
    const condition = { id: faqId };
    const attributes = [
      "id",
      "uuid",
      "faq_category_id",
      "question",
      "answer",
      "list_order",
      "status",
      "created_by",	
      "created_at",	
      "updated_by",
      "updated_at"
    ];

    const includeQuery = [
      {
        model: model.faqCategory,
        //where: { status: "active" },
        required: true,
      },
    ];

    resultData = await model.faq.findOne({
      attributes: attributes,
      include: includeQuery,
      where: condition,
    });

    if (resultData && resultData.dataValues && resultData.dataValues.faqCategory) {
      resultData.dataValues.category_name = resultData.dataValues.faqCategory.name;
    }
    delete resultData.dataValues.faqCategory;
    
    res.ok(resultData ? resultData : {});
  } catch (error) {
    next(error);
  }
};
