import model from "../../../models/index.js";
import { Op, col, fn } from "sequelize";
import { StatusError, envs } from "../../../config/index.js";

/**
 * galleryDetails
 * @param req
 * @param res
 */
export const galleryDetails = async (req, res, next) => {
  try {
    const reqBody = req.params;
    const id = reqBody.id ? reqBody.id : "";
    if (!id) throw StatusError.badRequest(res.__("Invalid id"));

    const checkId = await model.gallery.count({
      where: { id: id },
    });
    if (checkId == 0) throw StatusError.badRequest(res.__("Invalid id"));

    let resultData = {};
    const condition = { id: id };
    const attributes = [
      "id",
      "uuid",
      "file_name",
      "title",
      [fn("REPLACE", col("file_path"), `public/uploads/`, `public/`), "file_path"],
      "status",
      "list_order",
      "created_at",
    ];

    const includeQuery = [];

    resultData = await model.gallery.findOne({
      attributes: attributes,
      include: includeQuery,
      where: condition,
    });

    res.ok(resultData ? resultData : {});
  } catch (error) {
    next(error);
  }
};
