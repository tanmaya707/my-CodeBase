import model from "../../../models/index.js";
import { customDateTimeHelper, customFileHelper } from "../../../helpers/index.js";
import { StatusError, envs } from "../../../config/index.js";
import { v4 as uuidv4 } from "uuid";
import fs from "fs";
import {
  contentModificationService,
  notificationService,
  userPermissionService,
} from "../../../services/index.js";

/**
 * addGallery
 * @param req
 * @param res
 */
export const addGallery = async (req, res, next) => {
  try {
    const reqBody = req.body;
    const loginUserId = req.userDetails.userId;
    if (!loginUserId) {
      if (req.file && req.file.path) customFileHelper.customFileUnlink(fs, req.file.path);
      throw StatusError.badRequest(res.__("Invalid user id"));
    }

    const userRole = req.userDetails.user_type ?? "";
    const roleId = req.userDetails.user_role_id ?? "";
    if (!userRole) {
      if (req.file && req.file.path) customFileHelper.customFileUnlink(fs, req.file.path);
      throw StatusError.badRequest(res.__("Invalid user role"));
    }

    const totalRecord = await model.gallery.max("list_order");
    let listOrder = (totalRecord ?? 0) + 1;

    let fileLocation = "";
    let fileName = "";
    let fileNameOrg = "";
    let fileType = "image";
    if (req.file) {
      const fileDetails = req.file;
      fileName = fileDetails.filename ? fileDetails.filename : "";
      fileNameOrg = fileDetails.originalname ? fileDetails.originalname : "";
      if (fileDetails.mimetype && fileDetails.mimetype.startsWith("image/")) {
        fileType = "image";
      } else if (fileDetails.mimetype && fileDetails.mimetype.startsWith("video/")) {
        fileType = "video";
      }
      fileLocation = fileDetails.destination ? fileDetails.destination + "/" + fileName : "";
    }

    // add details
    const inputDetails = {
      uuid: uuidv4(),
      file_name: fileNameOrg ?? null,
      title: reqBody.title ?? null,
      file_type: fileType,
      file_path: fileLocation,
      list_order: listOrder,
      status: reqBody.status,
      created_at: await customDateTimeHelper.getCurrentDateTime(),
      created_by: loginUserId,
    };
    let insRes;
    let sucMess = "success";
    if (userRole == "superadmin" || userRole == "administrator" || userRole == "approver") {
      const check = await userPermissionService.checkUserPermission(roleId, loginUserId, [
        "gallery.add",
      ]);
      if (check) {
        insRes = await model.gallery.create(inputDetails);
      } else {
        insRes = null;
      }
    } else {
      insRes = await model.tempGallery.create(inputDetails);
      if (insRes && insRes.id > 0) {
        sucMess = "Your addition request has been save successfully. Please wait for approval!";
        await contentModificationService.addRequest({
          temp_id: insRes.id,
          request_for: "galleries",
          action_type: "add",
          created_at: inputDetails.created_at,
          created_by: inputDetails.created_by,
        });
        await notificationService.generateNotificationForContentApproval(
          {
            created_by: loginUserId,
            notification_type: "content_approval",
            type: "update",
            title: `A new gallery addition requested`,
            item_id: insRes.id,
            item_description: `A new gallery "${inputDetails.title}" addition requested by publisher`,
            item: inputDetails,
          },
          null,
          ["gallery.status_change"],
        );
      }
    }

    if (insRes && insRes.id > 0) {
      res.ok({
        message: res.__(sucMess),
      });
    } else {
      if (req.file && req.file.path) customFileHelper.customFileUnlink(fs, req.file.path);
      throw StatusError.badRequest(res.__("SomeThingWentWrong"));
    }
  } catch (error) {
    console.log(error);
    if (req.file && req.file.path) customFileHelper.customFileUnlink(fs, req.file.path);
    next(error);
  }
};
