import { addGallery } from "./addGallery.js";
import { galleryList } from "./galleryList.js";
import { editGallery } from "./editGallery.js";
import { deleteGallery } from "./deleteGallery.js";
import { galleryDetails } from "./galleryDetails.js";

export { addGallery, galleryList, editGallery, deleteGallery, galleryDetails };
