import model from "../../../models/index.js";
import { customDateTimeHelper, customFileHelper } from "../../../helpers/index.js";
import { StatusError } from "../../../config/index.js";
import fs from "fs";
import {
  contentModificationService,
  notificationService,
  userPermissionService,
} from "../../../services/index.js";

/**
 * editGallery
 * @param req
 * @param res
 */
export const editGallery = async (req, res, next) => {
  try {
    const reqBody = req.body;
    const loginUserId = req.userDetails.userId;
    const id = reqBody.id ? reqBody.id : "";
    let fileLocation = "";
    let fileName = "";
    let fileNameOrg = "";
    let fileType = "image";
    if (req.file) {
      const fileDetails = req.file;
      fileName = fileDetails.filename ? fileDetails.filename : "";
      fileNameOrg = fileDetails.originalname ? fileDetails.originalname : "";
      if (fileDetails.mimetype && fileDetails.mimetype.startsWith("image/")) {
        fileType = "image";
      } else if (fileDetails.mimetype && fileDetails.mimetype.startsWith("video/")) {
        fileType = "video";
      }
      fileLocation = fileDetails.destination ? fileDetails.destination + "/" + fileName : "";
    }
    const userRole = req.userDetails.user_type ?? "";
    const roleId = req.userDetails.user_role_id ?? "";
    if (!userRole) {
      if (req.file && req.file.path) customFileHelper.customFileUnlink(fs, req.file.path);
      throw StatusError.badRequest(res.__("Invalid user role"));
    }

    // check for id existance in table
    const isExists = await model.gallery.findOne({
      //attributes: ["id", "title", "file_name", "file_type", "created_by", "file_path"],
      where: {
        id: id,
      },
    });
    if (!isExists) {
      if (req.file && req.file.path) customFileHelper.customFileUnlink(fs, req.file.path);
      throw StatusError.badRequest(res.__("Invalid id"));
    }
    let fpath = fileLocation ? fileLocation : isExists?.file_path;
    let fname = fileLocation ? fileNameOrg : isExists?.file_name;
    let ftype = fileLocation ? fileType : isExists?.file_type;
    let requestDetails = {
      file_name: fname ?? null,
      title: reqBody.title ?? null,
      file_type: ftype,
      file_path: fpath,
      status: reqBody.status,
      updated_at: await customDateTimeHelper.getCurrentDateTime(),
      updated_by: loginUserId,
    };
    let updt = 0;
    let sucMess = "success";
    if (userRole == "superadmin" || userRole == "administrator" || userRole == "approver") {
      const check = await userPermissionService.checkUserPermission(roleId, loginUserId, [
        "gallery.edit",
      ]);
      if (check) {
        requestDetails.updated_at = await customDateTimeHelper.getCurrentDateTime();
        requestDetails.updated_by = loginUserId;
        const [upResp] = await model.gallery.update(requestDetails, {
          where: { id: id },
        });
        if (upResp > 0) {
          updt = 1;
        }
      }
    } else {
      const checkForPendingRequest = await contentModificationService.checkForPendingRequest({
        id: id,
        request_for: "galleries",
        action_type: "edit",
      });
      if (checkForPendingRequest) {
        if (req.file && req.file.path) customFileHelper.customFileUnlink(fs, req.file.path);
        throw StatusError.badRequest(
          res.__(
            "A modification request is already in progress. Please wait for the approval response and try again later.",
          ),
        );
      } else {
        requestDetails.gallery_id = id;
        requestDetails.earlier_data = isExists ? JSON.stringify(isExists) : null;
        requestDetails.uuid = isExists.uuid;
        requestDetails.list_order = isExists.list_order;
        requestDetails.created_at = requestDetails.updated_at;
        requestDetails.created_by = requestDetails.updated_by;
        const insRes = await model.tempGallery.create(requestDetails);

        if (insRes && insRes.id > 0) {
          sucMess =
            "Your modification request has been save successfully. Please wait for approval!";
          await contentModificationService.addRequest({
            temp_id: insRes.id,
            request_for: "galleries",
            action_type: "edit",
            created_at: requestDetails.updated_at,
            created_by: requestDetails.updated_by,
          });
          await notificationService.generateNotificationForContentApproval(
            {
              created_by: loginUserId,
              notification_type: "content_approval",
              type: "update",
              title: `A gallery modification requested`,
              item_id: insRes.id,
              item_description: `A gallery "${insRes.title}" modification requested by publisher`,
              item: insRes,
            },
            null,
            ["gallery.status_change"],
          );
          updt = 1;
        }
      }
    }

    if (updt > 0) {
      // if (req.file && req.file.path && isExists.file_path) {
      //   customFileHelper.customFileUnlink(fs, isExists.file_path);
      // }
      res.ok({
        message: res.__(sucMess),
      });
    } else {
      if (req.file && req.file.path) customFileHelper.customFileUnlink(fs, req.file.path);
      throw StatusError.badRequest(res.__("SomeThingWentWrong"));
    }
  } catch (error) {
    console.log(error);
    if (req.file && req.file.path) customFileHelper.customFileUnlink(fs, req.file.path);
    next(error);
  }
};
