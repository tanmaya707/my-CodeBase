import model from "../../../models/index.js";
import { Op } from "sequelize";
import { StatusError } from "../../../config/index.js";

/**
 * menuDetails
 * @param req
 * @param res
 */
export const menuDetails = async (req, res, next) => {
  try {
    const reqBody = req.params;
    const menuId = reqBody.id ? reqBody.id : "";
    if (!menuId) throw StatusError.badRequest(res.__("Invalid id"));

    const checkMenuId = await model.menu.count({
      where: { status: { [Op.ne]: "deleted" }, id: menuId },
    });
    if (checkMenuId == 0) throw StatusError.badRequest(res.__("Invalid id"));

    let resultData = {};
    const condition = { status: { [Op.ne]: "deleted" }, id: menuId };
    const attributes = ["id", "name", "type", "parent_id", "created_at"];

    const includeQuery = [];

    resultData = await model.menu.findOne({
      attributes: attributes,
      include: includeQuery,
      where: condition,
    });

    res.ok(resultData ? resultData : {});
  } catch (error) {
    next(error);
  }
};
