import { addMenu } from "./addMenu.js";
import { menuList } from "./menuList.js";
import { editMenu } from "./editMenu.js";
import { deleteMenu } from "./deleteMenu.js";
import { menuDetails } from "./menuDetails.js";

export { addMenu, menuList, editMenu, deleteMenu, menuDetails };
