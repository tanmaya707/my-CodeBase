import model from "../../../models/index.js";
import { customDateTimeHelper } from "../../../helpers/index.js";
import { StatusError } from "../../../config/index.js";
import { Op } from "sequelize";

/**
 * editMenu
 * @param req
 * @param res
 */
export const editMenu = async (req, res, next) => {
  try {
    const reqBody = req.body;
    const loginUserId = req.userDetails.userId;
    const { id, name, type, ...otherFields } = req.body;

    if (!id) throw StatusError.badRequest(res.__("Invalid id"));

    // check for menu id existance in table
    const isExistsMenu = await model.menu.findOne({
      attributes: ["id", "name", "created_by"],
      where: {
        id: id,
        status: { [Op.ne]: "deleted" },
      },
    });

    if (!isExistsMenu) throw StatusError.badRequest(res.__("Invalid id"));

    let menuDetails = {
      id,
      name,
      type,
      ...otherFields,
      updated_at: await customDateTimeHelper.getCurrentDateTime(),
      updated_by: loginUserId,
    };

    const [userInformation] = await model.menu.update(menuDetails, {
      where: { id: id },
    });

    if (userInformation > 0) {
      res.ok({
        message: res.__("success"),
      });
    } else {
      throw StatusError.badRequest(res.__("SomeThingWentWrong"));
    }
  } catch (error) {
    next(error);
  }
};
