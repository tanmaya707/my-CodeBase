import model from "../../../models/index.js";
import { customDateTimeHelper } from "../../../helpers/index.js";
import { StatusError } from "../../../config/index.js";
import { Op } from "sequelize";
/**
 * addMenu
 * @param req
 * @param res
 */
export const addMenu = async (req, res, next) => {
  try {
    const { name, type, ...otherFields } = req.body;

    let menuDetails = {
      name,
      type,
      ...otherFields,
      created_at: await customDateTimeHelper.getCurrentDateTime(),
      created_by: req.userDetails.userId,
    };

    // check for menu email existance in table
    const isExistsMenu = await model.menu.findOne({
      attributes: ["id"],
      where: {
        name: name,
        type: type,
        status: { [Op.ne]: "deleted" },
      },
    });

    if (isExistsMenu) throw StatusError.badRequest(res.__("menuAlreadyExists"));

    const newMenuInformation = await model.menu.create(menuDetails);

    if (newMenuInformation && newMenuInformation.id > 0) {
      res.ok({
        message: res.__("success"),
        data: newMenuInformation,
      });
    } else {
      throw StatusError.badRequest(res.__("SomeThingWentWrong"));
    }
  } catch (error) {
    next(error);
  }
};
