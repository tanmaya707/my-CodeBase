import model from "../../../models/index.js";
import { Op } from "sequelize";
import { StatusError } from "../../../config/index.js";
import { customDateTimeHelper } from "../../../helpers/index.js";

/**
 * deleteMenu
 * @param req
 * @param res
 */
export const deleteMenu = async (req, res, next) => {
  try {
    const reqBody = req.body;
    const menuId = reqBody.id ? reqBody.id : "";
    if (!menuId) throw StatusError.badRequest(res.__("Invalid id"));

    const checkUserId = await model.menu.count({
      where: { status: { [Op.ne]: "deleted" }, id: menuId },
    });
    if (checkUserId == 0) throw StatusError.badRequest(res.__("Invalid id"));

    const menuDetails = {
      status: "deleted",
      deleted_at: await customDateTimeHelper.getCurrentDateTime(),
      deleted_by: req.userDetails.userId,
    };
    const [menuInformation] = await model.menu.update(menuDetails, {
      where: { id: menuId },
    });
    if (menuInformation > 0) {
      res.ok({
        message: res.__("success"),
      });
    } else {
      throw StatusError.badRequest(res.__("SomeThingWentWrong"));
    }
  } catch (error) {
    next(error);
  }
};
