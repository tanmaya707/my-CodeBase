import model from "../../../models/index.js";
import { StatusError } from "../../../config/index.js";
import { customDateTimeHelper } from "../../../helpers/index.js";
import { Op } from "sequelize";
import {
  contentModificationService,
  notificationService,
  userPermissionService,
} from "../../../services/index.js";

/**
 * cmsEdit
 * @param req
 * @param res
 */
export const cmsEdit = async (req, res, next) => {
  try {
    const loginUserId = req.userDetails.userId;
    if (!loginUserId) {
      if (req.files && req.files.file && req.files.file[0] && req.files.file[0].path)
        customFileHelper.customFileUnlink(fs, req.files.file[0].path);
      if (
        req.files &&
        req.files.blone_file_rec &&
        req.files.blone_file_rec[0] &&
        req.files.blone_file_rec[0].path
      )
        customFileHelper.customFileUnlink(fs, req.files.blone_file_rec[0].path);
      if (
        req.files &&
        req.files.blone_file_sqa_up &&
        req.files.blone_file_sqa_up[0] &&
        req.files.blone_file_sqa_up[0].path
      )
        customFileHelper.customFileUnlink(fs, req.files.blone_file_sqa_up[0].path);
      if (
        req.files &&
        req.files.blone_file_sqa_dn &&
        req.files.blone_file_sqa_dn[0] &&
        req.files.blone_file_sqa_dn[0].path
      )
        customFileHelper.customFileUnlink(fs, req.files.blone_file_sqa_dn[0].path);
      if (
        req.files &&
        req.files.bltwo_strip_file &&
        req.files.bltwo_strip_file[0] &&
        req.files.bltwo_strip_file[0].path
      )
        customFileHelper.customFileUnlink(fs, req.files.bltwo_strip_file[0].path);
      if (
        req.files &&
        req.files.blfour_file &&
        req.files.blfour_file[0] &&
        req.files.blfour_file[0].path
      )
        customFileHelper.customFileUnlink(fs, req.files.blfour_file[0].path);
      throw StatusError.badRequest(res.__("Invalid user id"));
    }
    const userRole = req.userDetails.user_type ?? "";
    const roleId = req.userDetails.user_role_id ?? "";
    if (!userRole) {
      if (req.files && req.files.file && req.files.file[0] && req.files.file[0].path)
        customFileHelper.customFileUnlink(fs, req.files.file[0].path);
      if (
        req.files &&
        req.files.blone_file_rec &&
        req.files.blone_file_rec[0] &&
        req.files.blone_file_rec[0].path
      )
        customFileHelper.customFileUnlink(fs, req.files.blone_file_rec[0].path);
      if (
        req.files &&
        req.files.blone_file_sqa_up &&
        req.files.blone_file_sqa_up[0] &&
        req.files.blone_file_sqa_up[0].path
      )
        customFileHelper.customFileUnlink(fs, req.files.blone_file_sqa_up[0].path);
      if (
        req.files &&
        req.files.blone_file_sqa_dn &&
        req.files.blone_file_sqa_dn[0] &&
        req.files.blone_file_sqa_dn[0].path
      )
        customFileHelper.customFileUnlink(fs, req.files.blone_file_sqa_dn[0].path);
      if (
        req.files &&
        req.files.bltwo_strip_file &&
        req.files.bltwo_strip_file[0] &&
        req.files.bltwo_strip_file[0].path
      )
        customFileHelper.customFileUnlink(fs, req.files.bltwo_strip_file[0].path);
      if (
        req.files &&
        req.files.blfour_file &&
        req.files.blfour_file[0] &&
        req.files.blfour_file[0].path
      )
        customFileHelper.customFileUnlink(fs, req.files.blfour_file[0].path);
      throw StatusError.badRequest(res.__("Invalid user role"));
    }
    const reqBody = req.body;
    const pageId = reqBody.page_id ? reqBody.page_id : "";
    const pageTitle = reqBody.page_title ? reqBody.page_title : "";
    const pageMenu = reqBody.page_menu ? reqBody.page_menu : "";
    const pageStatus = reqBody.status ? reqBody.status : "";
    const pageBannerTitle = reqBody.display_text ? reqBody.display_text : "";

    let isFileDeleted = reqBody.is_fdel ? reqBody.is_fdel : "";
    isFileDeleted = isFileDeleted == "" ? "n" : isFileDeleted;

    let isFileRecDeleted = reqBody.is_fdel_rec ? reqBody.is_fdel_rec : "";
    isFileRecDeleted = isFileRecDeleted == "" ? "n" : isFileRecDeleted;

    let isFileSqaUpDeleted = reqBody.is_fdel_sqa_up ? reqBody.is_fdel_sqa_up : "";
    isFileSqaUpDeleted = isFileSqaUpDeleted == "" ? "n" : isFileSqaUpDeleted;

    let isFileSqaDnDeleted = reqBody.is_fdel_sqa_dn ? reqBody.is_fdel_sqa_dn : "";
    isFileSqaDnDeleted = isFileSqaDnDeleted == "" ? "n" : isFileSqaDnDeleted;

    let isFileStripDeleted = reqBody.is_fdel_strip ? reqBody.is_fdel_strip : "";
    isFileStripDeleted = isFileStripDeleted == "" ? "n" : isFileStripDeleted;

    let isFileFourDeleted = reqBody.is_fdel_four ? reqBody.is_fdel_four : "";
    isFileFourDeleted = isFileFourDeleted == "" ? "n" : isFileFourDeleted;

    let fileLocation = "";
    let fileName = "";
    if (req.files && req.files.file && req.files.file.length > 0) {
      const fileDetails = req.files.file[0];
      fileName = fileDetails.filename ? fileDetails.filename : "";
      fileLocation = fileDetails.destination ? fileDetails.destination + "/" + fileName : "";
    }

    let fileRecLocation = "";
    let fileRecName = "";
    if (req.files && req.files.blone_file_rec && req.files.blone_file_rec.length > 0) {
      const fileDetails = req.files.blone_file_rec[0];
      fileRecName = fileDetails.filename ? fileDetails.filename : "";
      fileRecLocation = fileDetails.destination ? fileDetails.destination + "/" + fileRecName : "";
    }

    let fileSqaUpLocation = "";
    let fileSqaUpName = "";
    if (req.files && req.files.blone_file_sqa_up && req.files.blone_file_sqa_up.length > 0) {
      const fileDetails = req.files.blone_file_sqa_up[0];
      fileSqaUpName = fileDetails.filename ? fileDetails.filename : "";
      fileSqaUpLocation = fileDetails.destination
        ? fileDetails.destination + "/" + fileSqaUpName
        : "";
    }

    let fileSqaDnLocation = "";
    let fileSqaDnName = "";
    if (req.files && req.files.blone_file_sqa_dn && req.files.blone_file_sqa_dn.length > 0) {
      const fileDetails = req.files.blone_file_sqa_dn[0];
      fileSqaDnName = fileDetails.filename ? fileDetails.filename : "";
      fileSqaDnLocation = fileDetails.destination
        ? fileDetails.destination + "/" + fileSqaDnName
        : "";
    }

    let fileStripLocation = "";
    let fileStripName = "";
    if (req.files && req.files.bltwo_strip_file && req.files.bltwo_strip_file.length > 0) {
      const fileDetails = req.files.bltwo_strip_file[0];
      fileStripName = fileDetails.filename ? fileDetails.filename : "";
      fileStripLocation = fileDetails.destination
        ? fileDetails.destination + "/" + fileStripName
        : "";
    }

    let fileFourLocation = "";
    let fileFourName = "";
    if (req.files && req.files.blfour_file && req.files.blfour_file.length > 0) {
      const fileDetails = req.files.blfour_file[0];
      fileFourName = fileDetails.filename ? fileDetails.filename : "";
      fileFourLocation = fileDetails.destination
        ? fileDetails.destination + "/" + fileFourName
        : "";
    }

    // check for page id existance in  pages table
    const isExists = await model.cmsCustomPage.findOne({
      where: {
        id: pageId,
      },
    });
    if (!isExists) {
      if (req.files && req.files.file && req.files.file[0] && req.files.file[0].path)
        customFileHelper.customFileUnlink(fs, req.files.file[0].path);
      if (
        req.files &&
        req.files.blone_file_rec &&
        req.files.blone_file_rec[0] &&
        req.files.blone_file_rec[0].path
      )
        customFileHelper.customFileUnlink(fs, req.files.blone_file_rec[0].path);
      if (
        req.files &&
        req.files.blone_file_sqa_up &&
        req.files.blone_file_sqa_up[0] &&
        req.files.blone_file_sqa_up[0].path
      )
        customFileHelper.customFileUnlink(fs, req.files.blone_file_sqa_up[0].path);
      if (
        req.files &&
        req.files.blone_file_sqa_dn &&
        req.files.blone_file_sqa_dn[0] &&
        req.files.blone_file_sqa_dn[0].path
      )
        customFileHelper.customFileUnlink(fs, req.files.blone_file_sqa_dn[0].path);
      if (
        req.files &&
        req.files.bltwo_strip_file &&
        req.files.bltwo_strip_file[0] &&
        req.files.bltwo_strip_file[0].path
      )
        customFileHelper.customFileUnlink(fs, req.files.bltwo_strip_file[0].path);
      if (
        req.files &&
        req.files.blfour_file &&
        req.files.blfour_file[0] &&
        req.files.blfour_file[0].path
      )
        customFileHelper.customFileUnlink(fs, req.files.blfour_file[0].path);
      throw StatusError.badRequest(res.__("Invalid page id or page type"));
    }
    // check duplicate page title exists
    const isExistsTitle = await model.cmsCustomPage.findOne({
      where: {
        page_menu: pageMenu,
        id: { [Op.ne]: pageId },
      },
    });
    if (isExistsTitle) {
      if (req.files && req.files.file && req.files.file[0] && req.files.file[0].path)
        customFileHelper.customFileUnlink(fs, req.files.file[0].path);
      if (
        req.files &&
        req.files.blone_file_rec &&
        req.files.blone_file_rec[0] &&
        req.files.blone_file_rec[0].path
      )
        customFileHelper.customFileUnlink(fs, req.files.blone_file_rec[0].path);
      if (
        req.files &&
        req.files.blone_file_sqa_up &&
        req.files.blone_file_sqa_up[0] &&
        req.files.blone_file_sqa_up[0].path
      )
        customFileHelper.customFileUnlink(fs, req.files.blone_file_sqa_up[0].path);
      if (
        req.files &&
        req.files.blone_file_sqa_dn &&
        req.files.blone_file_sqa_dn[0] &&
        req.files.blone_file_sqa_dn[0].path
      )
        customFileHelper.customFileUnlink(fs, req.files.blone_file_sqa_dn[0].path);
      if (
        req.files &&
        req.files.bltwo_strip_file &&
        req.files.bltwo_strip_file[0] &&
        req.files.bltwo_strip_file[0].path
      )
        customFileHelper.customFileUnlink(fs, req.files.bltwo_strip_file[0].path);
      if (
        req.files &&
        req.files.blfour_file &&
        req.files.blfour_file[0] &&
        req.files.blfour_file[0].path
      )
        customFileHelper.customFileUnlink(fs, req.files.blfour_file[0].path);
      throw StatusError.badRequest(res.__("This page title is already exist"));
    }

    const whl = true;
    let slugName = "";
    let rslug = pageTitle;
    let regenarate = false;
    if (pageTitle != rslug) {
      while (whl) {
        const generatedSlug = await generalHelper.generateSlugName(rslug, regenarate);
        // check for slug name existance in award table
        const isExists = await model.cmsCustomPage.findOne({
          where: { slug_name: generatedSlug },
          attributes: ["id", "slug_name"],
        });
        if (!isExists) {
          regenarate = false;
          slugName = generatedSlug;
          break;
        } else {
          regenarate = true;
          rslug = generatedSlug;
        }
      }
    } else {
      slugName = isExists.slug_name;
    }

    let fpath = fileLocation ? fileLocation : isExists?.file_path;
    if (isFileDeleted == "y") {
      fpath = "";
    }

    let frecpath = fileRecLocation ? fileRecLocation : isExists?.blone_file_rec;
    if (isFileRecDeleted == "y") {
      frecpath = "";
    }

    let fsquuppath = fileSqaUpLocation ? fileSqaUpLocation : isExists?.blone_file_sqa_up;
    if (isFileSqaUpDeleted == "y") {
      fsquuppath = "";
    }

    let fsqudnpath = fileSqaDnLocation ? fileSqaDnLocation : isExists?.blone_file_sqa_dn;
    if (fileSqaDnLocation == "y") {
      fsqudnpath = "";
    }

    let fstrippath = fileStripLocation ? fileStripLocation : isExists?.bltwo_strip_file;
    if (fileStripLocation == "y") {
      fstrippath = "";
    }

    let ffourpath = fileFourLocation ? fileFourLocation : isExists?.blfour_file;
    if (fileFourLocation == "y") {
      ffourpath = "";
    }

    const updateData = {
      page_menu: pageMenu,
      page_title: pageTitle,
      meta: pageTitle,
      slug_name: slugName,
      status: pageStatus,
      display_text: pageBannerTitle,
      file_path: fpath,
      blone_caption_text: !reqBody.blone_caption_text ? null : reqBody.blone_caption_text,
      blone_title: !reqBody.blone_title ? null : reqBody.blone_title,
      blone_short_quotes: !reqBody.blone_short_quotes ? null : reqBody.blone_short_quotes,
      blone_description: !reqBody.blone_description ? null : reqBody.blone_description,
      blone_feature_list: !reqBody.blone_feature_list ? null : reqBody.blone_feature_list,
      blone_file_rec: frecpath,
      blone_file_sqa_up: fsquuppath,
      blone_file_sqa_dn: fsqudnpath,
      bltwo_strip_file: fstrippath,
      blthree_caption_text: !reqBody.blthree_caption_text ? null : reqBody.blthree_caption_text,
      blthree_title: !reqBody.blthree_title ? null : reqBody.blthree_title,
      blthree_description: !reqBody.blthree_description ? null : reqBody.blthree_description,
      blthree_feature_list: !reqBody.blthree_feature_list ? null : reqBody.blthree_feature_list,
      blfour_caption_text: !reqBody.blfour_caption_text ? null : reqBody.blfour_caption_text,
      blfour_title: !reqBody.blfour_title ? null : reqBody.blfour_title,
      blfour_description: !reqBody.blfour_description ? null : reqBody.blfour_description,
      blfour_feature_list: !reqBody.blfour_feature_list ? null : reqBody.blfour_feature_list,
      blfour_file: ffourpath,
      blfive_title: !reqBody.blfive_title ? null : reqBody.blfive_title,
      blfive_description: !reqBody.blfive_description ? null : reqBody.blfive_description,
      blfive_feature_list: !reqBody.blfive_feature_list ? null : reqBody.blfive_feature_list,
      updated_by: loginUserId,
      updated_at: await customDateTimeHelper.getCurrentDateTime(),
    };
    let updt = 0;
    let sucMess = "success";
    if (userRole == "superadmin" || userRole == "administrator" || userRole == "approver") {
      const check = await userPermissionService.checkUserPermission(roleId, loginUserId, [
        "setting.site_setting.edit",
      ]);
      if (check) {
        updateData.updated_at = await customDateTimeHelper.getCurrentDateTime();
        updateData.updated_by = loginUserId;
        const [upResp] = await model.cmsCustomPage.update(updateData, {
          where: { id: pageId },
        });
        if (upResp > 0) {
          updt = 1;
        }
      }
    } else {
      const checkForPendingRequest = await contentModificationService.checkForPendingRequest({
        id: pageId,
        request_for: "pages",
        action_type: "edit",
      });
      if (checkForPendingRequest) {
        if (req.files && req.files.file && req.files.file[0] && req.files.file[0].path)
          customFileHelper.customFileUnlink(fs, req.files.file[0].path);
        if (
          req.files &&
          req.files.blone_file_rec &&
          req.files.blone_file_rec[0] &&
          req.files.blone_file_rec[0].path
        )
          customFileHelper.customFileUnlink(fs, req.files.blone_file_rec[0].path);
        if (
          req.files &&
          req.files.blone_file_sqa_up &&
          req.files.blone_file_sqa_up[0] &&
          req.files.blone_file_sqa_up[0].path
        )
          customFileHelper.customFileUnlink(fs, req.files.blone_file_sqa_up[0].path);
        if (
          req.files &&
          req.files.blone_file_sqa_dn &&
          req.files.blone_file_sqa_dn[0] &&
          req.files.blone_file_sqa_dn[0].path
        )
          customFileHelper.customFileUnlink(fs, req.files.blone_file_sqa_dn[0].path);
        if (
          req.files &&
          req.files.bltwo_strip_file &&
          req.files.bltwo_strip_file[0] &&
          req.files.bltwo_strip_file[0].path
        )
          customFileHelper.customFileUnlink(fs, req.files.bltwo_strip_file[0].path);
        if (
          req.files &&
          req.files.blfour_file &&
          req.files.blfour_file[0] &&
          req.files.blfour_file[0].path
        )
          customFileHelper.customFileUnlink(fs, req.files.blfour_file[0].path);
        throw StatusError.badRequest(
          res.__(
            "A modification request is already in progress. Please wait for the approval response and try again later.",
          ),
        );
      } else {
        updateData.custom_page_id = pageId;
        updateData.earlier_data = isExists ? JSON.stringify(isExists) : null;
        updateData.uuid = isExists.uuid;
        updateData.created_at = updateData.updated_at;
        updateData.created_by = updateData.updated_by;
        const insRes = await model.tempCmsCustomPage.create(updateData);

        if (insRes && insRes.id > 0) {
          sucMess =
            "Your modification request has been save successfully. Please wait for approval!";
          await contentModificationService.addRequest({
            temp_id: insRes.id,
            request_for: "pages",
            action_type: "edit",
            created_at: updateData.updated_at,
            created_by: updateData.updated_by,
          });
          await notificationService.generateNotificationForContentApproval(
            {
              created_by: loginUserId,
              notification_type: "content_approval",
              type: "update",
              title: `A custom page modification requested`,
              item_id: insRes.id,
              item_description: `A custom page,${insRes.page_title} modification requested by publisher`,
              item: insRes,
            },
            null,
            ["setting.site_setting.status_change"],
          );
          updt = 1;
        }
      }
    }
    if (updt > 0) {
      res.ok({
        message: res.__(sucMess),
      });
    } else {
      if (req.files && req.files.file && req.files.file[0] && req.files.file[0].path)
        customFileHelper.customFileUnlink(fs, req.files.file[0].path);
      if (
        req.files &&
        req.files.blone_file_rec &&
        req.files.blone_file_rec[0] &&
        req.files.blone_file_rec[0].path
      )
        customFileHelper.customFileUnlink(fs, req.files.blone_file_rec[0].path);
      if (
        req.files &&
        req.files.blone_file_sqa_up &&
        req.files.blone_file_sqa_up[0] &&
        req.files.blone_file_sqa_up[0].path
      )
        customFileHelper.customFileUnlink(fs, req.files.blone_file_sqa_up[0].path);
      if (
        req.files &&
        req.files.blone_file_sqa_dn &&
        req.files.blone_file_sqa_dn[0] &&
        req.files.blone_file_sqa_dn[0].path
      )
        customFileHelper.customFileUnlink(fs, req.files.blone_file_sqa_dn[0].path);
      if (
        req.files &&
        req.files.bltwo_strip_file &&
        req.files.bltwo_strip_file[0] &&
        req.files.bltwo_strip_file[0].path
      )
        customFileHelper.customFileUnlink(fs, req.files.bltwo_strip_file[0].path);
      if (
        req.files &&
        req.files.blfour_file &&
        req.files.blfour_file[0] &&
        req.files.blfour_file[0].path
      )
        customFileHelper.customFileUnlink(fs, req.files.blfour_file[0].path);
      throw StatusError.badRequest(res.__("SomeThingWentWrong"));
    }
  } catch (error) {
    console.log(error);
    if (req.files && req.files.file && req.files.file[0] && req.files.file[0].path)
      customFileHelper.customFileUnlink(fs, req.files.file[0].path);
    if (
      req.files &&
      req.files.blone_file_rec &&
      req.files.blone_file_rec[0] &&
      req.files.blone_file_rec[0].path
    )
      customFileHelper.customFileUnlink(fs, req.files.blone_file_rec[0].path);
    if (
      req.files &&
      req.files.blone_file_sqa_up &&
      req.files.blone_file_sqa_up[0] &&
      req.files.blone_file_sqa_up[0].path
    )
      customFileHelper.customFileUnlink(fs, req.files.blone_file_sqa_up[0].path);
    if (
      req.files &&
      req.files.blone_file_sqa_dn &&
      req.files.blone_file_sqa_dn[0] &&
      req.files.blone_file_sqa_dn[0].path
    )
      customFileHelper.customFileUnlink(fs, req.files.blone_file_sqa_dn[0].path);
    if (
      req.files &&
      req.files.bltwo_strip_file &&
      req.files.bltwo_strip_file[0] &&
      req.files.bltwo_strip_file[0].path
    )
      customFileHelper.customFileUnlink(fs, req.files.bltwo_strip_file[0].path);
    if (
      req.files &&
      req.files.blfour_file &&
      req.files.blfour_file[0] &&
      req.files.blfour_file[0].path
    )
      customFileHelper.customFileUnlink(fs, req.files.blfour_file[0].path);
    next(error);
  }
};
