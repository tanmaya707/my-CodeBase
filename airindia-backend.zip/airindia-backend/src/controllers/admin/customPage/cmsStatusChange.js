import model from "../../../models/index.js";
import { StatusError } from "../../../config/index.js";
import { customDateTimeHelper } from "../../../helpers/index.js";

/**
 * cmsStatusChange
 * @param req
 * @param res
 */
export const cmsStatusChange = async (req, res, next) => {
  try {
    const reqBody = req.body;
    const userId = req.userDetails.userId;
    const pageId = reqBody.page_id ? reqBody.page_id : "";
    const pageStatus = reqBody.status ? reqBody.status : "";

    // check for page id existance in custom pages table
    const getInformations = await model.cmsCustomPage.findOne({
      where: {
        id: pageId,
      },
    });
    if (!getInformations) throw StatusError.badRequest(res.__("Invalid page id or page type"));

    // Update page status
    const updateData = {
      status: pageStatus,
      updated_at: await customDateTimeHelper.getCurrentDateTime(),
      updated_by: userId,
    };
    await model.cmsCustomPage.update(updateData, {
      where: { id: pageId },
    });

    res.ok({
      message: res.__("Page status updated successfully"),
    });
  } catch (error) {
    next(error);
  }
};
