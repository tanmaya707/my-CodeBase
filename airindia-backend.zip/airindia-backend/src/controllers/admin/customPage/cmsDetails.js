import model from "../../../models/index.js";
import { StatusError } from "../../../config/index.js";
import { fn, col } from "sequelize";
/**
 * cmsDetails
 * @param req
 * @param res
 */
export const cmsDetails = async (req, res, next) => {
  try {
    const reqBody = req.query;
    const pageId = reqBody.page_id ? reqBody.page_id : "";
    // check for page id existance in custom pages table
    const getInformations = await model.cmsCustomPage.findOne({
      attributes: [
        "id",
        "uuid",
        "page_menu",
        "page_title",
        "slug_name",
        "status",
        "display_text",
        [fn("REPLACE", col("file_path"), `public/uploads/`, `public/`), "file_path"],
        "blone_caption_text",
        "blone_title",
        "blone_short_quotes",
        "blone_description",
        "blone_feature_list",
        [fn("REPLACE", col("blone_file_rec"), `public/uploads/`, `public/`), "blone_file_rec"],
        [
          fn("REPLACE", col("blone_file_sqa_up"), `public/uploads/`, `public/`),
          "blone_file_sqa_up",
        ],
        [
          fn("REPLACE", col("blone_file_sqa_dn"), `public/uploads/`, `public/`),
          "blone_file_sqa_dn",
        ],
        [fn("REPLACE", col("bltwo_strip_file"), `public/uploads/`, `public/`), "bltwo_strip_file"],
        "blthree_caption_text",
        "blthree_title",
        "blthree_description",
        "blthree_feature_list",
        "blfour_caption_text",
        "blfour_title",
        "blfour_description",
        "blfour_feature_list",
        [fn("REPLACE", col("blfour_file"), `public/uploads/`, `public/`), "blfour_file"],
        "blfive_title",
        "blfive_description",
        "blfive_feature_list",
        "created_at",
      ],
      where: {
        id: pageId,
      },
    });
    if (!getInformations) throw StatusError.badRequest(res.__("Invalid page id or page type"));

    res.ok(getInformations);
  } catch (error) {
    next(error);
  }
};
