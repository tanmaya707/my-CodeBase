import model from "../../../models/index.js";
import { paginationService } from "../../../services/index.js";
import { PAGINATION_LIMIT } from "../../../utils/constants.js";

/**
 * cmsList
 * @param req
 * @param res
 */
export const cmsList = async (req, res, next) => {
  try {
    const reqBody = req.body;
    const defautlPageNo = 1;
    const page = reqBody.page ? reqBody.page : defautlPageNo;
    const limit = reqBody.limit ? reqBody.limit : PAGINATION_LIMIT;

    const searchParams = {
      page: page,
      limit: limit,
      sortBy: "created_at",
      sortOrder: "desc",
    };
    const attributes = [
      "id",
      "uuid",
      "page_menu",
      "page_title",
      "slug_name",
      "status",
      "created_at",
    ];
    const includeQuery = [];
    const condition = {};
    const getCmsPageList = await paginationService.pagination(
      searchParams,
      model.cmsCustomPage,
      includeQuery,
      condition,
      attributes,
    );

    res.ok({
      page: page,
      limit: limit,
      total_records: getCmsPageList.count,
      total_pages: getCmsPageList.count > 0 ? Math.ceil(getCmsPageList.count / limit) : 0,
      results: getCmsPageList.rows,
    });
  } catch (error) {
    console.log(error);
    next(error);
  }
};
