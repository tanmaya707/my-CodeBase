import model from "../../../models/index.js";

/**
 * credentialCategoryList
 * @param req
 * @param res
 */
export const credentialCategoryList = async (req, res, next) => {
  try {
    const list = await model.credentialCategory.findAll({
      attributes: ["id", "uuid", ["name", "category_name"]],
      where: { status: "active" },
    });
    res.ok({
      results: list,
    });
  } catch (error) {
    next(error);
  }
};
