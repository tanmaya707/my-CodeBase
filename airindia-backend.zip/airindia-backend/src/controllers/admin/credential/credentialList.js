import model from "../../../models/index.js";
import { PAGINATION_LIMIT } from "../../../utils/constants.js";
import { paginationService } from "../../../services/index.js";
import { Sequelize, Op, col, fn } from "sequelize";

/**
 * credentialList
 * @param req
 * @param res
 */
export const credentialList = async (req, res, next) => {
  try {
    const reqBody = req.query;

    const searchType = reqBody.category_id ? reqBody.category_id : "";
    const searchName = reqBody.name ? reqBody.name.trim() : "";
    let resultData = [];
    const defautlPageNo = 1;
    const page = reqBody.page ? reqBody.page : defautlPageNo;
    const limit = reqBody.limit ? reqBody.limit : PAGINATION_LIMIT;

    const sortOrder = reqBody.sort_order ? reqBody.sort_order : "desc";
    const sortBy = reqBody.sort_by ? reqBody.sort_by : "";

    let searchDateType = !reqBody.search_date_type ? "" : reqBody.search_date_type;
    const searchStartDate = reqBody.start_date ? reqBody.start_date : "";
    const searchEndDate = reqBody.end_date ? reqBody.end_date : "";

    const loginUserId = req.userDetails.userId;
    const searchParams = {
      page: page,
      limit: limit,
    };
    let dateFilter = "credential.created_at";
    let condition = {};
    if (searchDateType == "created_date") {
      dateFilter = "credential.created_at";
    }
    let applyMoreand = false;
    // Add extra conditions for Startdate
    if (searchDateType && searchStartDate && !searchEndDate) {
      condition[Op.and] = [
        Sequelize.where(Sequelize.fn("DATE", Sequelize.col(dateFilter)), {
          [Op.gte]: searchStartDate,
        }),
      ];
      applyMoreand = true;
    }
    // Add extra conditions for Enddate
    if (searchDateType && searchEndDate && !searchStartDate) {
      condition[Op.and] = [
        Sequelize.where(Sequelize.fn("DATE", Sequelize.col(dateFilter)), {
          [Op.lte]: searchEndDate,
        }),
      ];
      applyMoreand = true;
    }
    // Add extra conditions for Startdate & EndDate
    if (searchDateType && searchStartDate && searchEndDate) {
      condition[Op.and] = [
        Sequelize.where(Sequelize.fn("DATE", Sequelize.col(dateFilter)), {
          [Op.between]: [searchStartDate, searchEndDate],
        }),
      ];
      applyMoreand = true;
    }

    const attributes = [
      "id",
      "uuid",
      "title",
      "credential_category_id",
      [col("credentialCategory.name"), "category_name"],
      [fn("REPLACE", col("file_path"), `public/uploads/`, `public/`), "file_path"],
      "status",
      "list_order",
      "created_at",
    ];
    if (sortOrder && sortBy == "category") {
      searchParams.sortOrderObj = [[Sequelize.literal("credentialCategory.name"), sortOrder]];
    } else if (sortOrder && sortBy == "name") {
      searchParams.sortOrderObj = [[Sequelize.literal("title"), sortOrder]];
    } else if (sortOrder && sortBy == "created_at") {
      searchParams.sortOrderObj = [[Sequelize.literal("created_at"), sortOrder]];
    } else {
      searchParams.sortOrderObj = [[Sequelize.literal("created_at"), sortOrder]];
    }

    const includeQuery = [
      {
        model: model.credentialCategory,
        required: true,
      },
    ];
    if (searchType) {
      if (applyMoreand) {
        condition[Op.and].push({ credential_category_id: searchType });
      } else {
        condition[Op.and] = { credential_category_id: searchType };
      }
    }
    if (searchName) {
      let orArr = [{ title: { [Op.like]: `%${searchName}%` } }];

      condition[Op.or] = orArr;
    }

    resultData = await paginationService.pagination(
      searchParams,
      model.credential,
      includeQuery,
      condition,
      attributes,
    );

    res.ok({
      page: page,
      limit: limit,
      total_records: resultData.count,
      total_pages: resultData.count > 0 ? Math.ceil(resultData.count / limit) : 0,
      results: resultData.rows,
    });
  } catch (error) {
    console.log(error);
    next(error);
  }
};
