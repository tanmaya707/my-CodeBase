import model from "../../../models/index.js";
import { Op, col, fn } from "sequelize";
import { StatusError, envs } from "../../../config/index.js";

/**
 * credentialDetails
 * @param req
 * @param res
 */
export const credentialDetails = async (req, res, next) => {
  try {
    const reqBody = req.params;
    const id = reqBody.id ? reqBody.id : "";
    if (!id) throw StatusError.badRequest(res.__("Invalid id"));

    const checkId = await model.credential.count({
      where: { id: id },
    });
    if (checkId == 0) throw StatusError.badRequest(res.__("Invalid id"));

    let resultData = {};
    const condition = { id: id };
    const attributes = [
      "id",
      "uuid",
      "title",
      "credential_category_id",
      "list_order",
      [fn("REPLACE", col("file_path"), `public/uploads/`, `public/`), "file_path"],
      "status",
      "created_at",
    ];

    const includeQuery = [
      {
        model: model.credentialCategory,
        //where: { status: "active" },
        required: true,
      },
    ];

    resultData = await model.credential.findOne({
      attributes: attributes,
      include: includeQuery,
      where: condition,
    });
    if (resultData && resultData.dataValues && resultData.dataValues.credentialCategory) {
      resultData.dataValues.category_name = resultData.dataValues.credentialCategory.name;
    }
    delete resultData.dataValues.credentialCategory;
    res.ok(resultData ? resultData : {});
  } catch (error) {
    next(error);
  }
};
