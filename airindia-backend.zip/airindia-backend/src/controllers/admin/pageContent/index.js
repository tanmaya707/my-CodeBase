import { getPageContent } from "./getPageContent.js";
import { savePageBanner } from "./savePageBanner.js";
import { saveMediaAboutText } from "./saveMediaAboutText.js";
import { saveCareerAboutText } from "./saveCareerAboutText.js";
import { saveContactUsAboutText } from "./saveContactUsAboutText.js";
import { saveContactUsContactInfo } from "./saveContactUsContactInfo.js";
import { saveFaqAboutText } from "./saveFaqAboutText.js";
import { savePageAboutText } from "./savePageAboutText.js";
import { savePageMiddleAboutText } from "./savePageMiddleAboutText.js";
import { savePageBottomAboutText } from "./savePageBottomAboutText.js";
import { saveGalleryAboutText } from "./saveGalleryAboutText.js";
import { saveClienteleAboutText } from "./saveClienteleAboutText.js";

export {
  getPageContent,
  savePageBanner,
  savePageMiddleAboutText,
  saveMediaAboutText,
  saveCareerAboutText,
  saveContactUsAboutText,
  saveContactUsContactInfo,
  saveFaqAboutText,
  savePageBottomAboutText,
  savePageAboutText,
  saveGalleryAboutText,
  saveClienteleAboutText,
};
