import model from "../../../models/index.js";
import { StatusError, envs } from "../../../config/index.js";
import { Op, fn, col } from "sequelize";

/**
 *get page content details
 * @param req
 * @param res
 * @param next
 */
export const getPageContent = async (req, res, next) => {
  try {
    const reqBody = req.query;
    const pageName = reqBody.page_name ?? "";
    if (pageName == "about_us" || pageName == "more_about_us") {
      throw StatusError.badRequest(res.__("Invalid Page"));
    }
    const keyName = `${pageName}.`;
    let getInfo = await model.sitePage.findAll({
      where: {
        page_name: pageName,
        key_name: { [Op.like]: `%${keyName}%` },
        status: "active",
      },
      attributes: ["id", "key_name", "page_value"],
    });
    let data = {};
    if (getInfo && getInfo.length > 0) {
      for (const row of getInfo) {
        let pVa = row.page_value ? JSON.parse(row.page_value) : "";

        if (row.key_name == `${pageName}.banner`) {
          if (pVa && pVa.file_path) {
            pVa.file_path = pVa.file_path.replace(`public/uploads/`, `public/`);
          }
        }
        if (row.key_name == `${pageName}.bottom_content`) {
          if (pVa && pVa.list_content && pVa.list_content.file_path) {
            pVa.list_content.file_path = pVa.list_content.file_path.replace(
              `public/uploads/`,
              `public/`,
            );
          }
          if (pVa && pVa.list_content_1 && pVa.list_content_1.file_path) {
            pVa.list_content_1.file_path = pVa.list_content_1.file_path.replace(
              `public/uploads/`,
              `public/`,
            );
          }
          if (pVa && pVa.list_content_2 && pVa.list_content_2.file_path) {
            pVa.list_content_2.file_path = pVa.list_content_2.file_path.replace(
              `public/uploads/`,
              `public/`,
            );
          }
          if (pVa && pVa.list_content_3 && pVa.list_content_3.file_path) {
            pVa.list_content_3.file_path = pVa.list_content_3.file_path.replace(
              `public/uploads/`,
              `public/`,
            );
          }
        }
        if (row.key_name == "news_event.about_text" || row.key_name == "awards.about_text") {
          if (pVa && pVa.file_path) {
            pVa.file_path = pVa.file_path.replace(`public/uploads/`, `public/`);
          }
          if (pVa && pVa.file_path_1) {
            pVa.file_path_1 = pVa.file_path_1.replace(`public/uploads/`, `public/`);
          }
        }
        if (row.key_name == "success_story.about_text" || row.key_name == "service.about_text") {
          if (pVa && pVa.file_path) {
            pVa.file_path = pVa.file_path.replace(`public/uploads/`, `public/`);
          }
        }
        data[row.key_name.replace(keyName, "")] = { id: row.id, ...pVa };
      }
    }
    if (data) {
      res.ok(data);
    } else {
      throw StatusError.notFound(res.__("data not found"));
    }
  } catch (error) {
    console.log(error);
    next(error);
  }
};
