import model from "../../../models/index.js";
import { customDateTimeHelper, customFileHelper } from "../../../helpers/index.js";
import { StatusError } from "../../../config/index.js";
import fs from "fs";
import { GLOBAL_PARAMS } from "../../../utils/constants.js";
import {
  contentModificationService,
  notificationService,
  userPermissionService,
} from "../../../services/index.js";

/**
 * savePageBottomAboutText
 * @param req
 * @param res
 */
export const savePageBottomAboutText = async (req, res, next) => {
  try {
    const reqBody = req.body;
    const loginUserId = req.userDetails.userId;
    if (!loginUserId) {
      if (req.files && req.files.file && req.files.file[0] && req.files.file[0].path)
        customFileHelper.customFileUnlink(fs, req.files.file[0].path);
      if (req.files && req.files.file_1 && req.files.file_1[0] && req.files.file_1[0].path)
        customFileHelper.customFileUnlink(fs, req.files.file_1[0].path);
      if (req.files && req.files.file_2 && req.files.file_2[0] && req.files.file_2[0].path)
        customFileHelper.customFileUnlink(fs, req.files.file_2[0].path);
      if (req.files && req.files.file_3 && req.files.file_3[0] && req.files.file_3[0].path)
        customFileHelper.customFileUnlink(fs, req.files.file_3[0].path);
      throw StatusError.badRequest(res.__("Invalid user id"));
    }
    const userRole = req.userDetails.user_type ?? "";
    const roleId = req.userDetails.user_role_id ?? "";
    if (!userRole) {
      if (req.files && req.files.file && req.files.file[0] && req.files.file[0].path)
        customFileHelper.customFileUnlink(fs, req.files.file[0].path);
      if (req.files && req.files.file_1 && req.files.file_1[0] && req.files.file_1[0].path)
        customFileHelper.customFileUnlink(fs, req.files.file_1[0].path);
      if (req.files && req.files.file_2 && req.files.file_2[0] && req.files.file_2[0].path)
        customFileHelper.customFileUnlink(fs, req.files.file_2[0].path);
      if (req.files && req.files.file_3 && req.files.file_3[0] && req.files.file_3[0].path)
        customFileHelper.customFileUnlink(fs, req.files.file_3[0].path);
      throw StatusError.badRequest(res.__("Invalid user role"));
    }
    const setId = reqBody.id ? reqBody.id : "";
    const pageName = reqBody.page_name ? reqBody.page_name : "";
    if (pageName != "service" && pageName != "success_story") {
      if (req.files && req.files.file && req.files.file[0] && req.files.file[0].path)
        customFileHelper.customFileUnlink(fs, req.files.file[0].path);
      if (req.files && req.files.file_1 && req.files.file_1[0] && req.files.file_1[0].path)
        customFileHelper.customFileUnlink(fs, req.files.file_1[0].path);
      if (req.files && req.files.file_2 && req.files.file_2[0] && req.files.file_2[0].path)
        customFileHelper.customFileUnlink(fs, req.files.file_2[0].path);
      if (req.files && req.files.file_3 && req.files.file_3[0] && req.files.file_3[0].path)
        customFileHelper.customFileUnlink(fs, req.files.file_3[0].path);
      throw StatusError.badRequest(res.__("Invalid Page"));
    }
    let isFileDeleted = reqBody.is_fdel ? reqBody.is_fdel : "";
    isFileDeleted = isFileDeleted == "" ? "n" : isFileDeleted;

    let isCerFileDeleted = reqBody.is_fdel_1 ? reqBody.is_fdel_1 : "";
    isCerFileDeleted = isCerFileDeleted == "" ? "n" : isCerFileDeleted;

    let isCerFileDeleted1 = reqBody.is_fdel_2 ? reqBody.is_fdel_2 : "";
    isCerFileDeleted1 = isCerFileDeleted1 == "" ? "n" : isCerFileDeleted1;

    let isCerFileDeleted2 = reqBody.is_fdel_3 ? reqBody.is_fdel_3 : "";
    isCerFileDeleted2 = isCerFileDeleted2 == "" ? "n" : isCerFileDeleted2;

    let fileLocation = "";
    let fileName = "";
    if (req.files && req.files.file && req.files.file.length > 0) {
      const fileDetails = req.files.file[0];
      fileName = fileDetails.filename ? fileDetails.filename : "";
      fileLocation = fileDetails.destination ? fileDetails.destination + "/" + fileName : "";
    }
    let fileLocationC = "";
    let fileNameC = "";
    if (req.files && req.files.file_1 && req.files.file_1.length > 0) {
      const fileDetailsC = req.files.file_1[0];
      fileNameC = fileDetailsC.filename ? fileDetailsC.filename : "";
      fileLocationC = fileDetailsC.destination ? fileDetailsC.destination + "/" + fileNameC : "";
    }
    let fileLocationC1 = "";
    let fileNameC1 = "";
    if (req.files && req.files.file_2 && req.files.file_2.length > 0) {
      const fileDetailsC1 = req.files.file_2[0];
      fileNameC1 = fileDetailsC1.filename ? fileDetailsC1.filename : "";
      fileLocationC1 = fileDetailsC1.destination
        ? fileDetailsC1.destination + "/" + fileNameC1
        : "";
    }
    let fileLocationC2 = "";
    let fileNameC2 = "";
    if (req.files && req.files.file_3 && req.files.file_3.length > 0) {
      const fileDetailsC2 = req.files.file_3[0];
      fileNameC2 = fileDetailsC2.filename ? fileDetailsC2.filename : "";
      fileLocationC2 = fileDetailsC2.destination
        ? fileDetailsC2.destination + "/" + fileNameC2
        : "";
    }

    let condition = {
      page_name: pageName,
      key_name: `${pageName}.bottom_content`,
    };
    if (setId) {
      condition.id = setId;
    }

    // check for settings id existance in table
    const isExists = await model.sitePage.findOne({
      where: condition,
    });

    if (!isExists && setId) {
      if (req.files && req.files.file && req.files.file[0] && req.files.file[0].path)
        customFileHelper.customFileUnlink(fs, req.files.file[0].path);
      if (req.files && req.files.file_1 && req.files.file_1[0] && req.files.file_1[0].path)
        customFileHelper.customFileUnlink(fs, req.files.file_1[0].path);
      if (req.files && req.files.file_2 && req.files.file_2[0] && req.files.file_2[0].path)
        customFileHelper.customFileUnlink(fs, req.files.file_2[0].path);
      if (req.files && req.files.file_3 && req.files.file_3[0] && req.files.file_3[0].path)
        customFileHelper.customFileUnlink(fs, req.files.file_3[0].path);
      throw StatusError.badRequest(res.__("Invalid id"));
    }
    let oldImag = "";
    let oldImagC = "";
    let oldImagC1 = "";
    let oldImagC2 = "";
    if (isExists) {
      const oldData = isExists.page_value ? JSON.parse(isExists.page_value) : [];
      if (oldData.list_content && oldData.list_content.file_path) {
        oldImag = oldData.list_content.file_path ?? "";
      }
      if (oldData.list_content_1 && oldData.list_content_1.file_path) {
        oldImagC = oldData.list_content_1.file_path ?? "";
      }
      if (oldData.list_content_2 && oldData.list_content_2.file_path) {
        oldImagC1 = oldData.list_content_2.file_path ?? "";
      }
      if (oldData.list_content_3 && oldData.list_content_3.file_path) {
        oldImagC2 = oldData.list_content_3.file_path ?? "";
      }
    }
    // add details
    let fpath = fileLocation ? fileLocation : oldImag;
    if (isFileDeleted == "y") {
      fpath = "";
    }

    let fpathc = fileLocationC ? fileLocationC : oldImagC;
    if (isCerFileDeleted == "y") {
      fpathc = "";
    }
    let fpathc1 = fileLocationC1 ? fileLocationC1 : oldImagC1;
    if (isCerFileDeleted1 == "y") {
      fpathc1 = "";
    }
    let fpathc2 = fileLocationC2 ? fileLocationC2 : oldImagC2;
    if (isCerFileDeleted2 == "y") {
      fpathc2 = "";
    }

    let reqDetails = {
      page_value: JSON.stringify({
        heading: reqBody.heading ?? "",
        sub_heading_txt: reqBody.sub_heading_txt ?? "",
        list_content: {
          title: reqBody.list_content_title ?? "",
          text_1: reqBody.list_content_text_1 ?? "",
          file_path: fpath,
        },
        list_content_1: {
          title: reqBody.list_content_1_title ?? "",
          text_1: reqBody.list_content_1_text_1 ?? "",
          file_path: fpathc,
        },
        list_content_2: {
          title: reqBody.list_content_2_title ?? "",
          text_1: reqBody.list_content_2_text_1 ?? "",
          file_path: fpathc1,
        },
        list_content_3: {
          title: reqBody.list_content_3_title ?? "",
          text_1: reqBody.list_content_3_text_1 ?? "",
          file_path: fpathc2,
        },
      }),
    };
    if (!isExists && !setId) {
      reqDetails.page_name = pageName;
      reqDetails.key_name = `${pageName}.bottom_content`;
      reqDetails.created_at = await customDateTimeHelper.getCurrentDateTime();
      reqDetails.created_by = loginUserId;
      let insRes;
      let sucMess = "success";
      if (userRole == "superadmin" || userRole == "administrator" || userRole == "approver") {
        const check = await userPermissionService.checkUserPermission(roleId, loginUserId, [
          `pages.${pageName}.add`,
        ]);
        if (check) {
          insRes = await model.sitePage.create(reqDetails);
        } else {
          insRes = null;
        }
      } else {
        let inputDetails = reqDetails;
        insRes = await model.tempSitePage.create(inputDetails);
        if (insRes && insRes.id > 0) {
          sucMess = "Your addition request has been save successfully. Please wait for approval!";
          await contentModificationService.addRequest({
            temp_id: insRes.id,
            request_for: "page_content",
            action_type: "add",
            created_at: inputDetails.created_at,
            created_by: inputDetails.created_by,
          });
          await notificationService.generateNotificationForContentApproval(
            {
              created_by: loginUserId,
              notification_type: "content_approval",
              type: "update",
              title: `A new page content addition requested`,
              item_id: insRes.id,
              item_description: `A new ${GLOBAL_PARAMS.PAGE_CONTENT_KEY[insRes.key_name]} addition requested by publisher`,
              item: inputDetails,
            },
            null,
            [`pages.${pageName}.status_change`],
          );
        }
      }
      if (insRes && insRes.id > 0) {
        res.ok({
          message: res.__(sucMess),
        });
      } else {
        if (req.files && req.files.file && req.files.file[0] && req.files.file[0].path)
          customFileHelper.customFileUnlink(fs, req.files.file[0].path);
        if (req.files && req.files.file_1 && req.files.file_1[0] && req.files.file_1[0].path)
          customFileHelper.customFileUnlink(fs, req.files.file_1[0].path);
        if (req.files && req.files.file_2 && req.files.file_2[0] && req.files.file_2[0].path)
          customFileHelper.customFileUnlink(fs, req.files.file_2[0].path);
        if (req.files && req.files.file_3 && req.files.file_3[0] && req.files.file_3[0].path)
          customFileHelper.customFileUnlink(fs, req.files.file_3[0].path);
        throw StatusError.badRequest(res.__("SomeThingWentWrong"));
      }
    } else {
      reqDetails.updated_at = await customDateTimeHelper.getCurrentDateTime();
      reqDetails.updated_by = loginUserId;

      let updt = 0;
      let sucMess = "success";
      if (userRole == "superadmin" || userRole == "administrator" || userRole == "approver") {
        const check = await userPermissionService.checkUserPermission(roleId, loginUserId, [
          `pages.${pageName}.edit`,
        ]);
        if (check) {
          const [upResp] = await model.sitePage.update(reqDetails, {
            where: condition,
          });
          if (upResp > 0) {
            updt = 1;
          }
        }
      } else {
        const checkForPendingRequest = await contentModificationService.checkForPendingRequest({
          id: setId,
          request_for: "page_content",
          action_type: "edit",
        });
        if (checkForPendingRequest) {
          throw StatusError.badRequest(
            res.__(
              "A modification request is already in progress. Please wait for the approval response and try again later.",
            ),
          );
        } else {
          let requestDetails = reqDetails;
          requestDetails.site_page_id = setId;
          requestDetails.page_name = pageName;
          requestDetails.key_name = `${pageName}.bottom_content`;
          requestDetails.earlier_data = isExists ? JSON.stringify(isExists) : null;
          requestDetails.created_at = requestDetails.updated_at;
          requestDetails.created_by = requestDetails.updated_by;
          const insRes = await model.tempSitePage.create(requestDetails);

          if (insRes && insRes.id > 0) {
            sucMess =
              "Your modification request has been save successfully. Please wait for approval!";
            await contentModificationService.addRequest({
              temp_id: insRes.id,
              request_for: "page_content",
              action_type: "edit",
              created_at: requestDetails.updated_at,
              created_by: requestDetails.updated_by,
            });
            await notificationService.generateNotificationForContentApproval(
              {
                created_by: loginUserId,
                notification_type: "content_approval",
                type: "update",
                title: `A page content modification requested`,
                item_id: insRes.id,
                item_description: `A ${GLOBAL_PARAMS.PAGE_CONTENT_KEY[insRes.key_name]} modification requested by publisher`,
                item: insRes,
              },
              null,
              [`pages.${pageName}.status_change`],
            );
            updt = 1;
          }
        }
      }
      if (updt > 0) {
        // if (
        //   ((req.files && req.files.file && req.files.file[0] && req.files.file[0].path) ||
        //     isFileDeleted == "y") &&
        //   oldImag
        // )
        //   customFileHelper.customFileUnlink(fs, oldImag);
        // if (
        //   ((req.files && req.files.file_1 && req.files.file_1[0] && req.files.file_1[0].path) ||
        //     isCerFileDeleted == "y") &&
        //   oldImagC
        // )
        //   customFileHelper.customFileUnlink(fs, oldImagC);
        // if (
        //   ((req.files && req.files.file_2 && req.files.file_2[0] && req.files.file_2[0].path) ||
        //     isCerFileDeleted1 == "y") &&
        //   oldImagC1
        // )
        //   customFileHelper.customFileUnlink(fs, oldImagC1);
        // if (
        //   ((req.files && req.files.file_3 && req.files.file_3[0] && req.files.file_3[0].path) ||
        //     isCerFileDeleted2 == "y") &&
        //   oldImagC2
        // )
        //   customFileHelper.customFileUnlink(fs, oldImagC2);
        res.ok({
          message: res.__(sucMess),
        });
      } else {
        if (req.files && req.files.file && req.files.file[0] && req.files.file[0].path)
          customFileHelper.customFileUnlink(fs, req.files.file[0].path);
        if (req.files && req.files.file_1 && req.files.file_1[0] && req.files.file_1[0].path)
          customFileHelper.customFileUnlink(fs, req.files.file_1[0].path);
        if (req.files && req.files.file_2 && req.files.file_2[0] && req.files.file_2[0].path)
          customFileHelper.customFileUnlink(fs, req.files.file_2[0].path);
        if (req.files && req.files.file_3 && req.files.file_3[0] && req.files.file_3[0].path)
          customFileHelper.customFileUnlink(fs, req.files.file_3[0].path);
        throw StatusError.badRequest(res.__("SomeThingWentWrong"));
      }
    }
  } catch (error) {
    console.log(error);
    if (req.files && req.files.file && req.files.file[0] && req.files.file[0].path)
      customFileHelper.customFileUnlink(fs, req.files.file[0].path);
    if (req.files && req.files.file_1 && req.files.file_1[0] && req.files.file_1[0].path)
      customFileHelper.customFileUnlink(fs, req.files.file_1[0].path);
    if (req.files && req.files.file_2 && req.files.file_2[0] && req.files.file_2[0].path)
      customFileHelper.customFileUnlink(fs, req.files.file_2[0].path);
    if (req.files && req.files.file_3 && req.files.file_3[0] && req.files.file_3[0].path)
      customFileHelper.customFileUnlink(fs, req.files.file_3[0].path);
    next(error);
  }
};
