import model from "../../../models/index.js";
import { customDateTimeHelper, customFileHelper } from "../../../helpers/index.js";
import { StatusError } from "../../../config/index.js";
import fs from "fs";
import { GLOBAL_PARAMS } from "../../../utils/constants.js";
import {
  contentModificationService,
  notificationService,
  userPermissionService,
} from "../../../services/index.js";

/**
 * savePageAboutText
 * @param req
 * @param res
 */
export const savePageAboutText = async (req, res, next) => {
  try {
    const reqBody = req.body;
    const loginUserId = req.userDetails.userId;
    const setId = reqBody.id ? reqBody.id : "";
    const pageName = reqBody.page_name ? reqBody.page_name : "";
    if (!loginUserId) {
      if (req.file && req.file.path) customFileHelper.customFileUnlink(fs, req.file.path);
      throw StatusError.badRequest(res.__("Invalid user id"));
    }
    const userRole = req.userDetails.user_type ?? "";
    const roleId = req.userDetails.user_role_id ?? "";
    if (!userRole) {
      if (req.file && req.file.path) customFileHelper.customFileUnlink(fs, req.file.path);
      throw StatusError.badRequest(res.__("Invalid user role"));
    }
    if (pageName != "service" && pageName != "success_story") {
      if (req.file && req.file.path) customFileHelper.customFileUnlink(fs, req.file.path);
      throw StatusError.badRequest(res.__("Invalid Page"));
    }
    let isFileDeleted = reqBody.is_fdel ? reqBody.is_fdel : "";
    isFileDeleted = isFileDeleted == "" ? "n" : isFileDeleted;
    let fileLocation = "";
    let fileName = "";
    if (req.file) {
      const fileDetails = req.file;
      fileName = fileDetails.filename ? fileDetails.filename : "";
      fileLocation = fileDetails.destination ? fileDetails.destination + "/" + fileName : "";
    }

    let condition = {
      page_name: pageName,
      key_name: `${pageName}.about_text`,
    };
    if (setId) {
      condition.id = setId;
    }

    // check for settings id existance in table
    const isExists = await model.sitePage.findOne({
      where: condition,
    });

    if (!isExists && setId) {
      if (req.file && req.file.path) customFileHelper.customFileUnlink(fs, req.file.path);
      throw StatusError.badRequest(res.__("Invalid id"));
    }

    let oldImag = "";
    if (isExists) {
      const oldData = isExists.page_value ? JSON.parse(isExists.page_value) : "";
      if (oldData.file_path) {
        oldImag = oldData.file_path ?? "";
      }
    }
    // add details
    let fpath = fileLocation ? fileLocation : oldImag;
    if (isFileDeleted == "y") {
      fpath = "";
    }
    let reqDetails = {
      page_value: JSON.stringify({
        heading_txt: reqBody.heading_txt ?? "",
        heading_txt_1: reqBody.heading_txt_1 ?? "",
        description: reqBody.description ?? "",
        file_path: fpath,
        count_data: {
          label_count: reqBody.count_data ?? "",
          label_name: reqBody.count_data_txt ?? "",
        },
        count_data_1: {
          label_count: reqBody.count_data_1_data ?? "",
          label_name: reqBody.count_data_1_txt ?? "",
        },
        count_data_2: {
          label_count: reqBody.count_data_2_data ?? "",
          label_name: reqBody.count_data_2_txt ?? "",
        },
      }),
    };
    if (!isExists && !setId) {
      reqDetails.key_name = `${pageName}.about_text`;
      reqDetails.page_name = pageName;
      reqDetails.created_at = await customDateTimeHelper.getCurrentDateTime();
      reqDetails.created_by = loginUserId;
      let insRes;
      let sucMess = "success";
      if (userRole == "superadmin" || userRole == "administrator" || userRole == "approver") {
        const check = await userPermissionService.checkUserPermission(roleId, loginUserId, [
          `pages.${pageName}.add`,
        ]);
        if (check) {
          insRes = await model.sitePage.create(reqDetails);
        } else {
          insRes = null;
        }
      } else {
        let inputDetails = reqDetails;
        insRes = await model.tempSitePage.create(inputDetails);
        if (insRes && insRes.id > 0) {
          sucMess = "Your addition request has been save successfully. Please wait for approval!";
          await contentModificationService.addRequest({
            temp_id: insRes.id,
            request_for: "page_content",
            action_type: "add",
            created_at: inputDetails.created_at,
            created_by: inputDetails.created_by,
          });
          await notificationService.generateNotificationForContentApproval(
            {
              created_by: loginUserId,
              notification_type: "content_approval",
              type: "update",
              title: `A new page content addition requested`,
              item_id: insRes.id,
              item_description: `A new ${GLOBAL_PARAMS.PAGE_CONTENT_KEY[insRes.key_name]} addition requested by publisher`,
              item: inputDetails,
            },
            null,
            [`pages.${pageName}.status_change`],
          );
        }
      }
      if (insRes && insRes.id > 0) {
        res.ok({
          message: res.__(sucMess),
        });
      } else {
        if (req.file && req.file.path) customFileHelper.customFileUnlink(fs, req.file.path);
        throw StatusError.badRequest(res.__("SomeThingWentWrong"));
      }
    } else {
      reqDetails.updated_at = await customDateTimeHelper.getCurrentDateTime();
      reqDetails.updated_by = loginUserId;
      let updt = 0;
      let sucMess = "success";
      if (userRole == "superadmin" || userRole == "administrator" || userRole == "approver") {
        const check = await userPermissionService.checkUserPermission(roleId, loginUserId, [
          `pages.${pageName}.edit`,
        ]);
        if (check) {
          const [upResp] = await model.sitePage.update(reqDetails, {
            where: condition,
          });
          if (upResp > 0) {
            updt = 1;
          }
        }
      } else {
        const checkForPendingRequest = await contentModificationService.checkForPendingRequest({
          id: setId,
          request_for: "page_content",
          action_type: "edit",
        });
        if (checkForPendingRequest) {
          throw StatusError.badRequest(
            res.__(
              "A modification request is already in progress. Please wait for the approval response and try again later.",
            ),
          );
        } else {
          let requestDetails = reqDetails;
          requestDetails.site_page_id = setId;
          requestDetails.key_name = `${pageName}.about_text`;
          requestDetails.page_name = pageName;
          requestDetails.earlier_data = isExists ? JSON.stringify(isExists) : null;
          requestDetails.created_at = requestDetails.updated_at;
          requestDetails.created_by = requestDetails.updated_by;
          const insRes = await model.tempSitePage.create(requestDetails);

          if (insRes && insRes.id > 0) {
            sucMess =
              "Your modification request has been save successfully. Please wait for approval!";
            await contentModificationService.addRequest({
              temp_id: insRes.id,
              request_for: "page_content",
              action_type: "edit",
              created_at: requestDetails.updated_at,
              created_by: requestDetails.updated_by,
            });
            await notificationService.generateNotificationForContentApproval(
              {
                created_by: loginUserId,
                notification_type: "content_approval",
                type: "update",
                title: `A page content modification requested`,
                item_id: insRes.id,
                item_description: `A ${GLOBAL_PARAMS.PAGE_CONTENT_KEY[insRes.key_name]} modification requested by publisher`,
                item: insRes,
              },
              null,
              [`pages.${pageName}.status_change`],
            );
            updt = 1;
          }
        }
      }
      if (updt > 0) {
        // if (((req.file && req.file.path) || isFileDeleted == "y") && oldImag)
        //   customFileHelper.customFileUnlink(fs, oldImag);
        res.ok({
          message: res.__(sucMess),
        });
      } else {
        if (req.file && req.file.path) customFileHelper.customFileUnlink(fs, req.file.path);
        throw StatusError.badRequest(res.__("SomeThingWentWrong"));
      }
    }
  } catch (error) {
    console.log(error);
    if (req.file && req.file.path) customFileHelper.customFileUnlink(fs, req.file.path);
    next(error);
  }
};
