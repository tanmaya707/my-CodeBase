import { generalHelper } from "../../../helpers/index.js";

/**
 * jobApplicantStatusList
 * @param req
 * @param res
 */
export const jobApplicantStatusList = async (req, res, next) => {
  try {
    let list = await generalHelper.jobApplicantStatusList();
    let retArr = [];
    if (list) {
      let i = 0;
      for (const eachRow in list) {
        retArr[i] = { key: eachRow, value: list[eachRow] };
        i++;
      }
    }
    res.ok({
      results: retArr,
    });
  } catch (error) {
    next(error);
  }
};
