import model from "../../../models/index.js";
import { customDateTimeHelper } from "../../../helpers/index.js";
import { StatusError } from "../../../config/index.js";
import { v4 as uuidv4 } from "uuid";
import {
  contentModificationService,
  notificationService,
  userPermissionService,
} from "../../../services/index.js";

/**
 * addJob
 * @param req
 * @param res
 */
export const addJob = async (req, res, next) => {
  try {
    const reqBody = req.body;
    const loginUserId = req.userDetails.userId;
    if (!loginUserId) {
      throw StatusError.badRequest(res.__("Invalid user id"));
    }
    const userRole = req.userDetails.user_type ?? "";
    const roleId = req.userDetails.user_role_id ?? "";
    if (!userRole) {
      throw StatusError.badRequest(res.__("Invalid user role"));
    }
    const totalRecord = await model.job.max("list_order");

    let listOrder = (totalRecord ?? 0) + 1;
    // add details
    const inputDetails = {
      uuid: uuidv4(),
      title: reqBody.title ?? null,
      job_no: reqBody.job_no ?? null,
      experience_level: reqBody.experience_level ?? null,
      job_location: reqBody.job_location ?? null,
      job_type: reqBody.job_type ?? null,
      year_of_experience: reqBody.year_of_experience ?? null,
      work_mode: reqBody.work_mode ?? null,
      language_known: reqBody.language_known ?? null,
      salary: reqBody.salary ?? null,
      currency_name: reqBody.currency_name ?? null,
      is_salary_not_disclosed: reqBody.is_salary_not_disclosed ?? "no",
      no_of_vacancy: reqBody.no_of_vacancy ?? null,
      responsibilities: reqBody.responsibilities ?? null,
      requirements: reqBody.requirements ?? null,
      is_urgently_needed: reqBody.is_urgently_needed ?? null,
      job_status: reqBody.job_status ?? "closed",
      list_order: listOrder,
      status: reqBody.status,
      created_at: await customDateTimeHelper.getCurrentDateTime(),
      created_by: loginUserId,
    };
    let insRes;
    let sucMess = "success";
    if (userRole == "superadmin" || userRole == "administrator" || userRole == "approver") {
      const check = await userPermissionService.checkUserPermission(roleId, loginUserId, [
        "career.add",
      ]);
      if (check) {
        insRes = await model.job.create(inputDetails);
      } else {
        insRes = null;
      }
    } else {
      insRes = await model.tempJob.create(inputDetails);
      if (insRes && insRes.id > 0) {
        sucMess = "Your addition request has been save successfully. Please wait for approval!";
        await contentModificationService.addRequest({
          temp_id: insRes.id,
          request_for: "jobs",
          action_type: "add",
          created_at: inputDetails.created_at,
          created_by: inputDetails.created_by,
        });
        await notificationService.generateNotificationForContentApproval(
          {
            created_by: loginUserId,
            notification_type: "content_approval",
            type: "update",
            title: `A new job addition requested`,
            item_id: insRes.id,
            item_description: `A new job,  ${inputDetails.title} addition requested by publisher`,
            item: inputDetails,
          },
          null,
          ["career.status_change"],
        );
      }
    }
    if (insRes && insRes.id > 0) {
      res.ok({
        message: res.__(sucMess),
      });
    } else {
      throw StatusError.badRequest(res.__("SomeThingWentWrong"));
    }
  } catch (error) {
    console.log(error);
    next(error);
  }
};
