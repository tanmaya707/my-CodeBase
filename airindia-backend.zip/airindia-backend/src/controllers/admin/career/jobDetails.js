import model from "../../../models/index.js";
import { StatusError } from "../../../config/index.js";

/**
 * jobDetails
 * @param req
 * @param res
 */
export const jobDetails = async (req, res, next) => {
  try {
    const reqBody = req.params;
    const id = reqBody.id ? reqBody.id : "";
    if (!id) throw StatusError.badRequest(res.__("Invalid id"));

    const checkId = await model.job.count({
      where: { id: id },
    });
    if (checkId == 0) throw StatusError.badRequest(res.__("Invalid id"));

    let resultData = {};
    const condition = { id: id };
    const attributes = [
      "id",
      "uuid",
      "title",
      "job_no",
      "experience_level",
      "job_location",
      "job_type",
      "year_of_experience",
      "work_mode",
      "language_known",
      "salary",
      "currency_name",
      "is_salary_not_disclosed",
      "no_of_vacancy",
      "responsibilities",
      "requirements",
      "is_urgently_needed",
      "job_status",
      "status",
      "list_order",
      "created_at",
    ];

    const includeQuery = [
      {
        model: model.jobApplicant,
        required: false,
        attributes: ["id"],
      },
    ];

    resultData = await model.job.findOne({
      attributes: attributes,
      include: includeQuery,
      where: condition,
    });
    if (resultData && resultData.dataValues && resultData.dataValues.jobApplicants) {
      resultData.dataValues.no_of_applicant = resultData.dataValues.jobApplicants.length ?? 0;
    }
    delete resultData.dataValues.jobApplicant;
    res.ok(resultData ? resultData : {});
  } catch (error) {
    next(error);
  }
};
