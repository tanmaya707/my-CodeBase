import model from "../../../models/index.js";
import { PAGINATION_LIMIT } from "../../../utils/constants.js";
import { paginationService } from "../../../services/index.js";
import { Sequelize, Op, col, fn } from "sequelize";

/**
 * jobList
 * @param req
 * @param res
 */
export const jobList = async (req, res, next) => {
  try {
    const reqBody = req.query;

    const searchName = reqBody.name ? reqBody.name.trim() : "";
    let resultData = [];
    const defautlPageNo = 1;
    const page = reqBody.page ? reqBody.page : defautlPageNo;
    const limit = reqBody.limit ? reqBody.limit : PAGINATION_LIMIT;

    const sortOrder = reqBody.sort_order ? reqBody.sort_order : "desc";
    const sortBy = reqBody.sort_by ? reqBody.sort_by : "";

    const loginUserId = req.userDetails.userId;
    const searchParams = {
      page: page,
      limit: limit,
    };

    let condition = {};

    const attributes = [
      "id",
      "uuid",
      "title",
      "job_no",
      "experience_level",
      "job_location",
      "job_type",
      "year_of_experience",
      "work_mode",
      "language_known",
      "salary",
      "currency_name",
      "is_salary_not_disclosed",
      "no_of_vacancy",
      "responsibilities",
      "requirements",
      "is_urgently_needed",
      "job_status",
      "status",
      "list_order",
      "created_at",
    ];

    if (sortOrder && sortBy == "name") {
      searchParams.sortOrderObj = [[Sequelize.literal("title"), sortOrder]];
    } else if (sortOrder && sortBy == "created_at") {
      searchParams.sortOrderObj = [[Sequelize.literal("created_at"), sortOrder]];
    } else {
      searchParams.sortOrderObj = [[Sequelize.literal("created_at"), sortOrder]];
    }

    const includeQuery = [
      {
        model: model.jobApplicant,
        required: false,
        attributes: ["id"],
      },
    ];
    if (searchName) {
      let orArr = [
        { title: { [Op.like]: `%${searchName}%` } },
        { job_no: { [Op.like]: `%${searchName}%` } },
        { experience_level: { [Op.like]: `%${searchName}%` } },
        { job_location: { [Op.like]: `%${searchName}%` } },
        { responsibilities: { [Op.like]: `%${searchName}%` } },
        { requirements: { [Op.like]: `%${searchName}%` } },
      ];

      condition[Op.or] = orArr;
    }

    resultData = await paginationService.pagination(
      searchParams,
      model.job,
      includeQuery,
      condition,
      attributes,
    );

    if (resultData.rows && resultData.rows.length > 0) {
      resultData.rows = resultData.rows.map((record) => {
        record.dataValues.no_of_applicant =
          !record.dataValues &&
          !record.dataValues.jobApplicants &&
          !record.dataValues.jobApplicants.length
            ? 0
            : record.dataValues.jobApplicants.length;
        delete record.dataValues.jobApplicants;
        return record;
      });
    }

    res.ok({
      page: page,
      limit: limit,
      total_records: resultData.count,
      total_pages: resultData.count > 0 ? Math.ceil(resultData.count / limit) : 0,
      results: resultData.rows,
    });
  } catch (error) {
    console.log(error);
    next(error);
  }
};
