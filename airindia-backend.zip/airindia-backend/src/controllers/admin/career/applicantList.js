import model from "../../../models/index.js";
import { PAGINATION_LIMIT } from "../../../utils/constants.js";
import { paginationService } from "../../../services/index.js";
import { Sequelize, Op, col, fn } from "sequelize";
import { generalHelper } from "../../../helpers/index.js";

/**
 * applicantList
 * @param req
 * @param res
 */
export const applicantList = async (req, res, next) => {
  try {
    const reqBody = req.query;

    const searchName = reqBody.name ? reqBody.name.trim() : "";
    let resultData = [];
    const defautlPageNo = 1;
    const page = reqBody.page ? reqBody.page : defautlPageNo;
    const limit = reqBody.limit ? reqBody.limit : PAGINATION_LIMIT;
    const jobId = reqBody.job_id ? reqBody.job_id : "";
    const applicantStatus = reqBody.applicant_status ? reqBody.applicant_status : "";

    const sortOrder = reqBody.sort_order ? reqBody.sort_order : "desc";
    const sortBy = reqBody.sort_by ? reqBody.sort_by : "";

    const loginUserId = req.userDetails.userId;
    const searchParams = {
      page: page,
      limit: limit,
    };

    let condition = { job_id: jobId };
    if (applicantStatus) {
      condition.applicant_status = applicantStatus;
    }
    const attributes = [
      "id",
      "job_id",
      "applicant_name",
      "applicant_email",
      "applicant_mobile",
      "applicant_address",
      "applicant_experience",
      "applicant_details",
      "file_name",
      [fn("REPLACE", col("file_path"), `public/uploads/`, `public/`), "file_path"],
      "status",
      "applicant_status",
      "remarks",
      "is_available_face_to_face",
      "is_ready_to_relocate",
      "highest_qualifiction",
      "name_of_institute",
      //"date_of_completion",
      [Sequelize.literal(`DATE_FORMAT(date_of_completion, '%d-%m-%Y')`), "date_of_completion"],
      "company_name",
      "position_holding",
      //"last_working_day",
      [Sequelize.literal(`DATE_FORMAT(last_working_day, '%d-%m-%Y')`), "last_working_day"],
      "reason_of_leaving",
      "created_at",
    ];

    if (sortOrder && sortBy == "name") {
      searchParams.sortOrderObj = [[Sequelize.literal("applicant_name"), sortOrder]];
    } else if (sortOrder && sortBy == "created_at") {
      searchParams.sortOrderObj = [[Sequelize.literal("created_at"), sortOrder]];
    } else {
      searchParams.sortOrderObj = [[Sequelize.literal("created_at"), sortOrder]];
    }

    const includeQuery = [];
    if (searchName) {
      let orArr = [
        { applicant_name: { [Op.like]: `%${searchName}%` } },
        { applicant_email: { [Op.like]: `%${searchName}%` } },
        { applicant_mobile: { [Op.like]: `%${searchName}%` } },
        { applicant_address: { [Op.like]: `%${searchName}%` } },
      ];

      condition[Op.or] = orArr;
    }

    resultData = await paginationService.pagination(
      searchParams,
      model.jobApplicant,
      includeQuery,
      condition,
      attributes,
    );

    if (resultData.rows && resultData.rows.length > 0) {
      const jobApplicantStatusList = await generalHelper.jobApplicantStatusList();
      resultData.rows = resultData.rows.map((record) => {
        record.dataValues.applicant_status_text =
          !record.dataValues && !record.dataValues.applicant_status
            ? ""
            : (jobApplicantStatusList[record.dataValues.applicant_status] ?? "");
        return record;
      });
    }

    res.ok({
      page: page,
      limit: limit,
      total_records: resultData.count,
      total_pages: resultData.count > 0 ? Math.ceil(resultData.count / limit) : 0,
      results: resultData.rows,
    });
  } catch (error) {
    console.log(error);
    next(error);
  }
};
