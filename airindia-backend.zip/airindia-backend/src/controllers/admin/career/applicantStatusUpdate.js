import model from "../../../models/index.js";
import { customDateTimeHelper } from "../../../helpers/index.js";
import { StatusError } from "../../../config/index.js";
import {
  contentModificationService,
  notificationService,
  userPermissionService,
} from "../../../services/index.js";
/**
 * applicantStatusUpdate
 * @param req
 * @param res
 */
export const applicantStatusUpdate = async (req, res, next) => {
  try {
    const reqBody = req.body;
    const loginUserId = req.userDetails.userId;
    const id = reqBody.id ? reqBody.id : "";
    const jobId = reqBody.job_id ? reqBody.job_id : "";

    const userRole = req.userDetails.user_type ?? "";
    const roleId = req.userDetails.user_role_id ?? "";
    if (!userRole) {
      throw StatusError.badRequest(res.__("Invalid user role"));
    }
    // check for id existance in table
    const isExists = await model.jobApplicant.findOne({
      //attributes: ["id"],
      where: {
        id: id,
        job_id: jobId,
      },
    });
    if (!isExists) {
      throw StatusError.badRequest(res.__("Invalid id"));
    }

    let requestDetails = {
      applicant_status: reqBody.applicant_status ?? null,
      remarks: reqBody.remarks ?? null,
      updated_at: await customDateTimeHelper.getCurrentDateTime(),
      updated_by: loginUserId,
    };
    let updt = 0;
    let sucMess = "success";
    if (userRole == "superadmin" || userRole == "administrator" || userRole == "approver") {
      const check = await userPermissionService.checkUserPermission(roleId, loginUserId, [
        "career.edit",
      ]);
      if (check) {
        requestDetails.updated_at = await customDateTimeHelper.getCurrentDateTime();
        requestDetails.updated_by = loginUserId;
        const [upResp] = await model.jobApplicant.update(requestDetails, {
          where: { id: id },
        });
        if (upResp > 0) {
          updt = 1;
        }
      }
    } else {
      const checkForPendingRequest = await contentModificationService.checkForPendingRequest({
        id: id,
        request_for: "job_applicants",
        action_type: "edit",
      });
      if (checkForPendingRequest) {
        throw StatusError.badRequest(
          res.__(
            "A modification request is already in progress. Please wait for the approval response and try again later.",
          ),
        );
      } else {
        requestDetails.job_applicant_id = id;
        requestDetails.earlier_data = isExists ? JSON.stringify(isExists) : null;
        requestDetails.uuid = isExists.uuid;
        requestDetails.job_id = isExists.job_id;
        requestDetails.applicant_name = isExists.applicant_name;
        requestDetails.applicant_email = isExists.applicant_email;
        requestDetails.applicant_mobile = isExists.applicant_mobile;
        requestDetails.applicant_address = isExists.applicant_address;
        requestDetails.applicant_experience = isExists.applicant_experience;
        requestDetails.applicant_details = isExists.applicant_details;
        requestDetails.applicant_status = isExists.applicant_status;
        requestDetails.file_name = isExists.file_name;
        requestDetails.file_path = isExists.file_path;
        requestDetails.is_available_face_to_face = isExists.is_available_face_to_face;
        requestDetails.is_ready_to_relocate = isExists.is_ready_to_relocate;
        requestDetails.highest_qualifiction = isExists.highest_qualifiction;
        requestDetails.name_of_institute = isExists.name_of_institute;
        requestDetails.date_of_completion = isExists.date_of_completion;
        requestDetails.company_name = isExists.company_name;
        requestDetails.position_holding = isExists.position_holding;
        requestDetails.last_working_day = isExists.last_working_day;
        requestDetails.reason_of_leaving = isExists.reason_of_leaving;
        requestDetails.created_at = requestDetails.updated_at;
        requestDetails.created_by = requestDetails.updated_by;
        const insRes = await model.tempJobApplicant.create(requestDetails);

        if (insRes && insRes.id > 0) {
          sucMess =
            "Your modification request has been save successfully. Please wait for approval!";
          await contentModificationService.addRequest({
            temp_id: insRes.id,
            request_for: "job_applicants",
            action_type: "edit",
            created_at: requestDetails.updated_at,
            created_by: requestDetails.updated_by,
          });
          await notificationService.generateNotificationForContentApproval(
            {
              created_by: loginUserId,
              notification_type: "content_approval",
              type: "update",
              title: `A job applicant modification requested`,
              item_id: insRes.id,
              item_description: `A job applicant, ${insRes.applicant_name} modification requested by publisher`,
              item: insRes,
            },
            null,
            ["career.status_change"],
          );
          updt = 1;
        }
      }
    }

    if (updt > 0) {
      res.ok({
        message: res.__(sucMess),
      });
    } else {
      throw StatusError.badRequest(res.__("SomeThingWentWrong"));
    }
  } catch (error) {
    next(error);
  }
};
