import model from "../../../models/index.js";
import { StatusError } from "../../../config/index.js";
import {
  contentModificationService,
  notificationService,
  userPermissionService,
} from "../../../services/index.js";

/**
 * deleteAward
 * @param req
 * @param res
 */
export const deleteAward = async (req, res, next) => {
  try {
    const reqBody = req.body;
    const awardId = reqBody.id ? reqBody.id : "";
    if (!awardId) throw StatusError.badRequest(res.__("Invalid id"));
    const loginUserId = req.userDetails.userId;
    const userRole = req.userDetails.user_type ?? "";
    const roleId = req.userDetails.user_role_id ?? "";
    if (!userRole) {
      throw StatusError.badRequest(res.__("Invalid user role"));
    }
    const checkRecordId = await model.award.count({
      where: { id: awardId },
    });
    if (checkRecordId == 0) throw StatusError.badRequest(res.__("Invalid id"));
    let desRes;
    let sucMess = "success";
    let delImg = false;
    if (userRole == "superadmin" || userRole == "administrator" || userRole == "approver") {
      const check = await userPermissionService.checkUserPermission(roleId, loginUserId, [
        "award.delete",
      ]);
      if (check) {
        desRes = await model.award.destroy({
          where: { id: awardId },
        });
        delImg = true;
      } else {
        desRes = 0;
      }
    } else {
      const checkForPendingRequest = await contentModificationService.checkForPendingRequest({
        id: awardId,
        request_for: "awards",
        action_type: "delete",
      });
      if (checkForPendingRequest) {
        throw StatusError.badRequest(
          res.__(
            "A modification request is already in progress. Please wait for the approval response and try again later.",
          ),
        );
      } else {
        const detail = await model.award.findOne({ where: { id: awardId } });
        const oldImage = await model.awardImage.findOne({
          //attributes: ["id", "created_by"],
          where: { award_id: awardId },
        });
        detail.award_id = detail.id;
        detail.award_image = oldImage ?? {};
        delete detail.id;
        const insRes = await model.tempAward.create(detail);
        if (insRes && insRes.id > 0) {
          desRes = 1;
          sucMess = "Your delete request has been save successfully. Please wait for approval!";
          await contentModificationService.addRequest({
            temp_id: insRes.id,
            request_for: "awards",
            action_type: "delete",
            created_at: detail.created_at,
            created_by: detail.created_by,
          });
          await notificationService.generateNotificationForContentApproval(
            {
              created_by: loginUserId,
              notification_type: "content_approval",
              type: "update",
              title: `A award delete requested`,
              item_id: detail.id,
              item_description: `A award "${detail.award_title}" delete requested by publisher`,
              item: detail,
            },
            null,
            ["award.status_change"],
          );
        }
      }
    }
    if (desRes > 0) {
      if (delImg) {
        await model.awardImage.destroy({
          where: { award_id: awardId },
        });
      }
      res.ok({
        message: res.__(sucMess),
      });
    } else {
      throw StatusError.badRequest(res.__("SomeThingWentWrong"));
    }
  } catch (error) {
    next(error);
  }
};
