import model from "../../../models/index.js";
import { Op } from "sequelize";
import { StatusError } from "../../../config/index.js";
import { customDateTimeHelper, customFileHelper } from "../../../helpers/index.js";
import fs from "fs";

/**
 * deleteAwardImage
 * @param req
 * @param res
 */

export const deleteAwardImage = async (req, res, next) => {
  try {
    const reqBody = req.body;
    const awardId = reqBody.award_id ? reqBody.award_id : "";
    const awardImageId = reqBody.id ? reqBody.id : "";
    const loginUserId = req.userDetails.userId;
    if (!loginUserId) throw StatusError.badRequest(res.__("Invalid user"));
    if (!awardId) throw StatusError.badRequest(res.__("Invalid award id"));
    if (!awardImageId) throw StatusError.badRequest(res.__("Invalid id"));

    const checkRecordId = await model.award.count({
      where: { id: awardId },
    });
    if (checkRecordId == 0) throw StatusError.badRequest(res.__("Invalid award id"));

    const checkImgRecordId = await model.awardImage.count({
      where: { award_id: awardId, id: awardImageId },
    });
    if (checkImgRecordId == 0) throw StatusError.badRequest(res.__("Invalid id"));
    

    const desResp = await model.awardImage.destroy({
      where: { id: checkImgRecordId, award_id:awardId },
    });
    
    if (desResp > 0) {
      res.ok({
        message: res.__("success"),
      });
    } else {
      throw StatusError.badRequest(res.__("SomeThingWentWrong"));
    }
  } catch (error) {
    next(error);
  }
};

