import model from "../../../models/index.js";
import { Sequelize, Op, col, fn } from "sequelize";
import { StatusError, envs } from "../../../config/index.js";

/**
 * awardDetails
 * @param req
 * @param res
 */
export const awardDetails = async (req, res, next) => {
  try {
    const reqBody = req.params;
    const awardId = reqBody.id ? reqBody.id : "";
    if (!awardId) throw StatusError.badRequest(res.__("Invalid id"));
    const checkRecordId = await model.award.count({
      where: { id: awardId },
    });
    if (checkRecordId == 0) throw StatusError.badRequest(res.__("Invalid id"));

    let resultData = {};
    const condition = { id: awardId };
    const attributes = ["id", "uuid", "award_title", "award_description", "website_link", "status"];

    const includeQuery = [
      {
        model: model.awardImage,
        attributes: [
          ["id", "image_id"],
          "file_name",
          [fn("REPLACE", col("awardImages.file_path"), `public/uploads/`, `public/`), "file_path"],
        ],
        //where: { status: "active" },
        required: false,
      },
    ];

    resultData = await model.award.findOne({
      attributes: attributes,
      include: includeQuery,
      where: condition,
    });

    if (resultData && resultData.dataValues && resultData.dataValues.awardImages) {
      resultData.dataValues.award_images = resultData.dataValues.awardImages;
      if (resultData.dataValues.awardImages) delete resultData.dataValues.awardImages;
    }

    res.ok(resultData ? resultData : {});
  } catch (error) {
    next(error);
  }
};
