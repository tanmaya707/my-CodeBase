import { awardDetails } from "./awardDetails.js";
import { deleteAward } from "./deleteAward.js";
import { addAward } from "./addAward.js";
import { editAward } from "./editAward.js";
import { awardList } from "./awardList.js";
import { deleteAwardImage } from "./deleteAwardImage.js";

export { awardDetails, deleteAward, addAward, editAward, awardList, deleteAwardImage };