const express = require('express');
const multer = require('multer');
const imageController = require('../controllers/imageController');

const router = express.Router();

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 50 * 1024 * 1024 },
});

router.get('/', imageController.renderHome);
router.get('/upload', (req, res) => res.redirect('/'));
router.post('/upload', upload.array('images', 5000), imageController.handleUpload);
router.get(['/gallery', '/images'], imageController.renderGallery);

router.get('/api/images', imageController.getImagesApi);
router.post('/api/rescan', imageController.rescanLibraryApi);
router.delete('/api/images/:type/:id', imageController.deleteImageApi);
router.post('/api/clear', imageController.clearImagesApi);

module.exports = router;
