// Download the helper library from https://www.twilio.com/docs/node/install
const twilio = require("twilio"); // Or, for ESM: import twilio from "twilio";

// Find your Account SID and Auth Token at twilio.com/console
// and set the environment variables. See http://twil.io/secure
// const accountSid = process.env.TWILIO_ACCOUNT_SID;
// const authToken = process.env.TWILIO_AUTH_TOKEN;
const accountSid = "ACb590e67edac153461899cbe725974ec8";
const authToken = "6f65a5fc5bab446fb273e44cb50e956e";
const client = twilio(accountSid, authToken);

async function createMessage() {
  const message = await client.messages
    .create({
      body: "This is the ship that made the Kessel Run in fourteen parsecs?",
      from: "+17244014885",
      // from: "+13474253754",
      to: "+13474253754",
      // to: "+15165401881",
    })
    .then(message => console.log(message.sid))
    .catch(error => console.error(error));

  // console.log(message.body);
}

createMessage();