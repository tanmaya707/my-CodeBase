const express = require('express');
const router = express.Router();
const policiesController = require('../controllers/policiesController')
const {
    isAuthenticated,
  } = require('../middleware/auth')


router.route('/policies-add-update').post(isAuthenticated, policiesController.policiesAddUpdate);
router.route('/get-policies').post(policiesController.getPolicies);

module.exports = router;