// const Joi = require("joi");
// const ErrorHandler = require("../utils/errorHandler");

// const validation = Joi.object({
//     name: Joi.string().required().min(3).max(30).messages({
//         'string.base': 'Username should be a string.',
//         'string.empty': 'Username cannot be empty.',
//         'string.min': 'Username should have a minimum length of {#limit}.',
//         'string.max': 'Username should have a maximum length of {#limit}.',
//         'any.required': 'Username is a required field',
//     }),
//     email: Joi.string().email().required().max(30).messages({
//         'string.base': 'Email should be a string.',
//         'string.empty': 'Email cannot be empty.',
//         'string.email': 'Email format is invalid!.',
//         'string.max': 'Email should have a maximum length of {#limit}.',
//         'any.required': 'Email is a required field',
//     }),
//     password: Joi.string().required().min(8).max(50).messages({
//         'string.base': 'Password should be a string.',
//         'string.empty': 'Password cannot be empty.',
//         'string.min': 'Password should have a minimum length of {#limit}.',
//         'string.max': 'Password should have a maximum length of {#limit}.',
//         'any.required': 'Password is a required field',
//     })
// });

// const userValidation = async (req, res, next) => {
//     const payload = {
//         name: req.body.name,
//         email: req.body.email,
//         password: req.body.password
//     };

//     const { error } = validation.validate(payload);
//     if (error) {
//         return next(new ErrorHandler(error.details[0].message, 400));
//     } else {
//         next();
//     }
// };

// module.exports = userValidation;