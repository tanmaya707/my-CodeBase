const axios = require("axios");
const BaseController = require("./BaseController.js");
const catchAsyncErrors = require("../middleware/catchAsyncErrors.js");
const ErrorHandler = require("../utils/errorHandler.js");
const RequestHandler = require("../utils/RequestHandler.js");
const fileUploaderSingle = require("../utils/fileUpload.js").fileUploaderSingle;
const bcrypt = require("bcryptjs");
const JWTAuth = require("../utils/jwtToken.js");
const jwt = require("jsonwebtoken");
const jwtConfig = require("../config/index.js").JWT;
const { Op } = require("sequelize");

const timeZone = require("../config/index.js").Timezone;
const moment = require('moment-timezone');

const {
  calculateDistance,
  calculateDistanceInsTentApi,
  calculateTimeInKilometers,
  getRateChartCategory,
} = require("../utils/utilities.js");
const {
  MSG_RECORD_STATUS_SUCCESS,
  MSG_RECORD_FETCH_SUCCESS,
} = require("../config/constants.js");
const requestHandler = new RequestHandler();

const db = require("../models/index.js");
const userModel = db.Users;
const agentModel = db.Agents;
const agentBookingMappingsModel = db.AgentBookingMappings;
const bookingRequestsModel = db.BookingRequests;
const notificationModel = db.Notifications;

class AgentBookingMappingController extends BaseController {
  constructor() {
    super();
  }

  static assignAgentToBookingRequest = catchAsyncErrors(async (req, res, next) => {
    let { agentId, bookingRequestId } = req.body;
    
    if(
			(!bookingRequestId || bookingRequestId == "" || bookingRequestId == null || bookingRequestId == undefined)
			|| (!agentId || agentId == "" || agentId == null || agentId == undefined)
		){
			return res.status(422).json({
				status: false,
				message: "All parameters are not present. Please pass all the required parameters.",
				data: {},
			});
		}

    let checkIfAgentAlreadyAssigned = await super.getByCustomOptionsSingle(req, agentBookingMappingsModel,  {
      where: {
        bookingRequestId: bookingRequestId 
      },
    });

    let mappingData = {
      agentId: agentId,
      bookingRequestId: bookingRequestId,
    };

    let assignAgentToBookingRequest = 
      (
        (checkIfAgentAlreadyAssigned) 
        && (checkIfAgentAlreadyAssigned.id != '') 
        && (checkIfAgentAlreadyAssigned.id != null)
      )
        ? await super.updateByCustomOptions(
          agentBookingMappingsModel, 
          {
            bookingRequestId: bookingRequestId,
          },
          {
            agentId: agentId,
          }
        )
        : await super.create(res, agentBookingMappingsModel, mappingData);

    if(assignAgentToBookingRequest){
      let assignmentDetails = await super.getByCustomOptionsSingle(req, agentBookingMappingsModel, {
        where: {
          bookingRequestId: bookingRequestId,
        }
      });
      let bookingDetail = await super.getByCustomOptionsSingle(req, bookingRequestsModel, {
        where: { 
          id: bookingRequestId,
        },
      });
      // ================================
      // ----- Handle Notifications -----
      // ================================
      // ----- send successful booking notification -----
      
      // ----- 1. to customer -----
      let notiDataForCustomer = {
        userId: bookingDetail?.customerId?? bookingDetail?.customerId,
        bookingRequestId: bookingRequestId,

        notiTitle: `Agent Assigned to Prepare Car as Ready`,

        notiBody: `Dear Customer, an agent has just been assigned to prepare your car. Your car will be ready in a short while. Please refer to ticket: ${(bookingDetail?.bookingTicketNo)? bookingDetail?.bookingTicketNo:"N/A"} for hassle free check-out.`
      }
      let createNotificationForCustomer = await super.create(res, notificationModel, notiDataForCustomer);
      // ----- 1. to customer -----

      // ----- 2. to super admin -----
      // let notiDataForSuperAdmin = {
      //   userId: superUser.id?? superUser.id,
      //   bookingRequestId: createdBookingRequest?.id,

      //   notiTitle: `New On Site Booking Made..!!`,

      //   notiBody: `Dear Admin, Booking confirmed. Parking slot no.: ${checkSlot?.slotName}; Slot location: [Bay-no.: ${checkSlot?.slotBayNumber}, Row-no.: ${checkSlot?.slotRowNumber}]; assigned to customer (${createCustomer?.firstName} ${createCustomer?.lastName})(Ph.: ${phone?? phone}). For more details, please refer to ticket: ${createdBookingRequest?.bookingTicketNo}.`
      // }
      // let createNotificationForSuperAdmin = await super.create(res, notificationModel, notiDataForSuperAdmin);
      // ----- 2. to super admin -----

      // ----- send successful booking notification -----
      // ================================
      // ----- Handle Notifications -----
      // ================================

      return res.status(200).json({
        status: true,
        message: "Agent assigned.",
        data: assignmentDetails,
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Something went wrong while assigning agent.",
        data: {},
      });
    }
  });
}

module.exports = AgentBookingMappingController;
