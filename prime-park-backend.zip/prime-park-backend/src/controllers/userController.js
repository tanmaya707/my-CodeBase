const axios = require("axios");
const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/errorHandler");
const RequestHandler = require("../utils/RequestHandler");
const fileUploaderSingle = require("../utils/fileUpload").fileUploaderSingle;
const bcrypt = require("bcryptjs");
const JWTAuth = require("../utils/jwtToken");
const jwt = require("jsonwebtoken");
const jwtConfig = require("../config").JWT;
const pkg = require("getmac").default;
const { Op } = require("sequelize");
const sendMail = require("../helpers/email");
const ccEmail = process.env.CC_EMAIL;
const sendPushNotification = require("../helpers/sendPushNotification");

const {
  calculateDistance,
  calculateDistanceInsTentApi,
  calculateTimeInKilometers,
  getRateChartCategory,
} = require("../utils/utilities");
const {
  MSG_RECORD_STATUS_SUCCESS,
  MSG_RECORD_FETCH_SUCCESS,
} = require("../config/constants");
const requestHandler = new RequestHandler();

const db = require("../models");
const vendorModel = db.Vendors;
const agentModel = db.Agents;
const userModel = db.Users;
const roleModel = db.Roles;
const temporaryOtpModel = db.TemporaryOtps;
const modulePermissionsModel = db.ModulePermissions;
const transactionModel = db.Transactions;
const transactionHistoryModel = db.TransactionHistory;
const bookingRequestsModel = db.BookingRequests;
const carMovementsModel = db.CarMovements;
const invoiceModel = db.Invoices;
const agentBookingMappingsModel = db.AgentBookingMappings;
const slotsModel = db.Slots;
const vehicleTypesModel = db.VehicleTypes;
const notificationModel = db.Notifications;

class UserController extends BaseController {
  constructor() {
    super();
  }

  static userAddUpdate = catchAsyncErrors(async (req, res, next) => {
    let { roleId, firstName, lastName, email, password, dialCode, phone, dob, gender, address, id, moduleAccess } = req.body;

    if (!id) {
      // user add happening ===
      if (!roleId) {
        return res.status(422).json({
          status: false,
          message: "Role Id is required.",
          data: {},
        });
      }
      if (!firstName || !lastName) {
        return res.status(422).json({
          status: false,
          message: "First name or Last name is required.",
          data: {},
        });
      }
      if (!email) {
        return res.status(422).json({
          status: false,
          message: "Email is required.",
          data: {},
        });
      }
      if (!password) {
        return res.status(422).json({
          status: false,
          message: "Password is required.",
          data: {},
        });
      }
      if (!phone) {
        return res.status(422).json({
          status: false,
          message: "Phone is required.",
          data: {},
        });
      }
			let role = await roleModel.findOne({
				where: {
					id: roleId,
					deletedAt: null,
				}
			});
			if(role.roleName != 'Employee'){
				if (!moduleAccess) {
					return res.status(422).json({
						status: false,
						message: "Please specify module access permissions.",
						data: {},
					});
				}
			}
    }

    let condition = {
      deletedAt: null,
    };
    if (id) {
      // during edit -> should not check self ===
      condition.id = {
        [Op.ne]: Number(id)
      };

      // ------------ for customerApp profile update user is not sending phone and email --------
      let user = await userModel.findOne({
        where: {
          id: id,
        }
      });
      
      if(!phone){
        phone = user?.phone;
      }
      if(!email){
        email = user?.email;
      }
      // ------------ for customerApp profile update user is not sending phone and email --------
    }

    let checkExist = await userModel.findOne({
      attributes: ["firstName", "lastName"],
      where: {
        [Op.and]: [
            condition,
            {
                [Op.or]: [{ phone: phone }, { email: email }],
            },
        ],
      },
    });

    if (checkExist) {
      return res.status(400).json({
        status: false,
        message: "User with this phone or email already exist..!!",
        data: checkExist,
      });
    }

    // =========== single file upload ================
    let fileName = "";
    if (req.files.profileImage) {
      let image = await fileUploaderSingle(
        "src/public/uploads/userImages/",
        req.files.profileImage
      );
      fileName = image.newfileName;
    }
    // =========== single file upload ================

    let updateFields = {
      roleId: roleId,
    };
    if (firstName) {
      updateFields.firstName = firstName;
    }
    if (lastName) {
      updateFields.lastName = lastName;
    }
    if (email) {
      updateFields.email = email;
    }
    if (dialCode) {
      updateFields.dialCode = dialCode;
    }
    if (phone) {
      updateFields.phone = phone;
    }
    if (password) {
      updateFields.password = await bcrypt.hash(password, 10);
    }
    if (dob) {
      updateFields.dob = dob;
    }
    if (gender) {
      updateFields.gender = gender;
    }
    if (address) {
      updateFields.address = address;
    }
    if (fileName != "") {
      updateFields.profileImage = fileName;
    }

    let updated =
      id && id != "" && id != null
        ? await super.updateById(userModel, id, updateFields)
        : await super.create(res, userModel, updateFields);
    
    if (updated) {
			let userDetails = {};
			if(id && id != "" && id != null){
				userDetails = await userModel.findOne({
					where: {
						id: id,
					}
				});
			} else {
				userDetails = await userModel.findOne({
					where: {
						id: updated.id
					}
				});
			}
			// ====== create permissions START ======
      if(moduleAccess){
        let moduleAccessArr = JSON.parse(moduleAccess);
        if(Array.isArray(moduleAccessArr)){
          // moduleAccess should always be array ========
          moduleAccessArr.forEach(async (moduleId)=>{
            let dataToBeUpdated = {
              userId: id,
              moduleId: moduleId,
            };
            let checkPermissionExists = await modulePermissionsModel.findOne({
              where: {
                userId: id,
                moduleId: moduleId,
              }
            });
            let modulePermissionUpdate = 
              checkPermissionExists && checkPermissionExists != "" && checkPermissionExists != null
                ? await super.updateByCustomOptions(
                  modulePermissionsModel, 
                  {
                    userId: id,
                    moduleId: moduleId,
                  }, 
                  dataToBeUpdated
                )
                : await modulePermissionsModel.create(dataToBeUpdated);
  
            if(modulePermissionUpdate){
              console.log("Module permissions created/updated.");
            } else{
              console.log("Module permissions not affected.");
            }
          });
        } else {
          return res.status(422).json({
            status: false,
            message: "moduleAccess variable in payload must be an array.",
            data: moduleAccess
          });
        }
      }
			// ====== create permissions END ======

      return res.status(200).json({
        status: true,
        message: "Successful.",
        data: userDetails,
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Oops..!! Something wrong happened.",
        data: {},
      });
    }
  });

  static userDetails = catchAsyncErrors(async (req, res, next) => {
    let { id } = req.body;
    
    let userDetail = await super.getByCustomOptionsSingle(req, userModel, {
      where: { 
        id: id 
      },
      attributes: {
        exclude: [
          "password",
          "webLogin",
          "appLogin",
          "fcmToken",
          "OTP",
          "macAddress",
        ],
      },
    });
    userDetail = userDetail.get({ plain: true });

    // Remove the password before sending the response
    // delete userDetail.password;

    let modulePermissions = await modulePermissionsModel.findAll({
      where:{
        userId: Number(id),
      }
    });
    // console.log("modulePermissions ===>");
    // console.log(modulePermissions);
    if(modulePermissions){
      let moduleAccess = [];
      modulePermissions.forEach((modulePermission)=>{
        moduleAccess.push(modulePermission.moduleId);
      });
      // console.log("moduleAccess ===>");
      // console.log(moduleAccess);
      userDetail["moduleAccess"] = moduleAccess;
    } else {
      userDetail["moduleAccess"] = [];
    }

    if(userDetail){
      return res.status(200).json({
        status: true,
        message: "Details found.",
        data: userDetail
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No details found.",
        data: {}
      });
    }
  });
  static userProfileDetails = catchAsyncErrors(async (req, res, next) => {
    let userDetail = await super.getByCustomOptionsSingle(req, userModel, {
      where: { 
        id: req.user.id 
      },
      attributes: {
        exclude: [
          "password",
          "webLogin",
          "appLogin",
          "fcmToken",
          "OTP",
          "macAddress",
        ],
      },
    });
    userDetail = userDetail.get({ plain: true });

    let modulePermissions = await modulePermissionsModel.findAll({
      where:{
        userId: req.user.id,
      }
    });
    // console.log("modulePermissions ===>");
    // console.log(modulePermissions);
    if(modulePermissions){
      let moduleAccess = [];
      modulePermissions.forEach((modulePermission)=>{
        moduleAccess.push(modulePermission.moduleId);
      });
      // console.log("moduleAccess ===>");
      // console.log(moduleAccess);
      userDetail["moduleAccess"] = moduleAccess;
    } else {
      userDetail["moduleAccess"] = [];
    }

    if(userDetail){
      return res.status(200).json({
        status: true,
        message: "Profile details found.",
        data: userDetail
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No profile details found.",
        data: {}
      });
    }
  });

  static userList = catchAsyncErrors(async (req, res, next) => {
    let options = {
      where: {
        '$role.roleName$': {
          [Op.notIn]: ["Super Admin", "Vendor", "Guest", "Agent"],
        },
        // isActive: true,
        // deletedAt: null,
      },
      order: [["createdAt", "DESC"]],
      attributes: {
        exclude: [
          "password",
          "webLogin",
          "appLogin",
          "fcmToken",
          "OTP",
          "macAddress",
        ],
      },
      include: [
        {
          model: roleModel, // including associated model
          attributes: ["roleName"], // Attributes to select from the included model
        },
      ],
    };
    let totalCount = await userModel.count();
    let userList = await super.getList(req, userModel, options);

    let userImageUrl = process.env.API_URL + "uploads/userImages/";

    if (userList.length > 0) {
      return res.status(200).json({
        status: true,
        message: "Data found.",
        data: {
          userList: userList,
          userImageUrl: userImageUrl,
        },
        totalCount: totalCount,
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No data found.",
        data: {},
      });
    }
  });

  static userSoftDelete = catchAsyncErrors(async (req, res, next) => {
    let { id } = req.body;
    
    if(!id){
      return res.status(400).json({
        status: false,
        message: "Id is not present in the payload.",
        data: {}
      });
    }

    let userCheckExist = await super.getById(req, userModel, id);
    let role = await super.getById(req, roleModel, userCheckExist.roleId);

    if(
      (id == 1)
      || (role.roleName == "Super Admin")
    ){
      // ---- prevent Super Admin deletion by mistake or ill-intent ----
      return res.status(403).json({
        status: false,
        message: "You can't delete superadmin.",
        data: {},
      });
    } 
    if(role.roleName == "Agent"){
      let agentDelete = await super.softDeleteByCondition(
        agentModel, 
        {
          userId: id,
        },
        req.user.id,
      );
    }
    if (role.roleName == "Vendor"){
      let vendorDelete = await super.softDeleteByCondition(
        vendorModel, 
        {
          userId: id,
        },
        req.user.id,
      );
    }

    let deleted = await super.softDeleteByCondition(
      userModel, 
      {
        id: id,
      },
      req.user.id,
    );

    if(deleted){
      return res.status(200).json({
        status: true,
        message: "Soft deletion successful.",
        data: {}
      });
    } else {
      return res.status(500).json({
        status: false,
        message: "Oops.. something went terribly wrong..!!",
        data: {}
      });
    }
  });
  static userReactivate = catchAsyncErrors(async (req, res, next) => {
    let { id } = req.body;

    if(!id){
      return res.status(400).json({
        status: false,
        message: "Id is not present in the payload.",
        data: {}
      });
    }

    let userCheckExist = await super.getById(req, userModel, id);
    let role = await super.getById(req, roleModel, userCheckExist.roleId);

    if(
      (id == 1)
      || (role.roleName == "Super Admin")
    ){
      // ---- prevent Super Admin deletion by mistake or ill-intent ----
      return res.status(403).json({
        status: false,
        message: "You can't change status of superadmin.",
        data: {},
      });
    } 

    if(!userCheckExist){
      return res.status(200).json({
        status: false,
        message: "User does not exist or wrong user id.",
        data: {}
      });
    } 

    if(role.roleName == "Vendor"){
      let vendorExistCheck = await super.getByCustomOptionsSingle(req, vendorModel, {
        userId: id,
      });

      if(vendorExistCheck){
        let reactivateVendor = await super.updateByCustomOptions(
          vendorModel,
          {
            userId: id,
          },
          {
            isActive: true,
            deletedAt: null,
            deleted_by: null,
          }
        );
      }
    } else if(role.roleName == "Agent"){
      let agentExistCheck = await super.getByCustomOptionsSingle(req, agentModel, {
        userId: id,
      });

      if(agentExistCheck){
        let reactivateAgent = await super.updateByCustomOptions(
          agentModel,
          {
            userId: id,
          },
          {
            isActive: true,
            deletedAt: null,
            deleted_by: null,
          }
        );
      }
    }
    let reactivateUser = await super.updateByCustomOptions(
      userModel, 
      {
        id: id,
      },
      {
        isActive: true,
        deletedAt: null,
        deleted_by: null,
      }
    );

    if(reactivateUser){
      return res.status(200).json({
        status: true,
        message: "Reactivated successfully",
        data: {}
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Oops.. we ran into some problem while reactivating the user.",
        data: {}
      });
    }
  });

  static userPermanentDelete = catchAsyncErrors(async (req, res, next) => {
    let { id } = req.body;

    if(!id){
      return res.status(400).json({
        status: false,
        message: "Id is not present in the payload.",
        data: {}
      });
    }

    let userCheckExist = await super.getById(req, userModel, id);
    let role = await super.getById(req, roleModel, userCheckExist.roleId);

    if(
      (id == 1)
      || (role.roleName == "Super Admin")
    ){
      // ---- prevent Super Admin deletion by mistake or ill-intent ----
      return res.status(403).json({
        status: false,
        message: "You can't delete Super Admin.",
        data: {},
      });
    } 

    if (role.roleName == "Vendor"){
      let vendorExistCheck = await super.getByCustomOptionsSingle(req, vendorModel, {
        userId: id,
      });
      if(vendorExistCheck){
        let deleteCarMovementsOfVendor = await carMovementsModel.destroy({
          where: {
            vendorId: vendorExistCheck?.id,
          }
        });

        let deleteVendor = await vendorModel.destroy({
          where: {
            id: vendorExistCheck?.id,
          }
        });
      }
      
    } else if(role.roleName == "Agent"){
      let agentExistCheck = await super.getByCustomOptionsSingle(req, agentModel, {
        userId: id,
      });
      if(agentExistCheck){
        let agentBookingMappingDelete = await agentBookingMappingsModel.destroy({
          where: {
            agentId: agentExistCheck?.id,
          }
        });

        let deleteAgent = await agentModel.destroy({
          where: {
            id: agentExistCheck?.id,
          }
        });
      }
    } else if(role.roleName == "Customer"){
      let deletedUser = await super.getByCustomOptionsSingle(req, userModel, {
        where: {
          email: "deleted@deleted.deleted",
          // dialCode: "+999",
          // phone: 1000000000,
          // OTP: "911911",
          isActive: false,
          deleted_by: 1,
          deleted_at: {
            [Op.not]: null,
          }
        }
      });
      if(!deletedUser){
        return res.status(400).json({
          status: false,
          message: "System user not configured.",
          data: {}
        });
      }
      let bookingRequestsExistCheck = await super.getByCustomOptions(req, bookingRequestsModel, {
        customerId: id,
      });
      if(bookingRequestsExistCheck.length > 0){
        let bookingRequestsIdArr = [];
        bookingRequestsExistCheck.forEach(async (bookingRequest) => {
          bookingRequestsIdArr.push(bookingRequest?.id);
        });
        
        // ======= update bookingRequests with deleted user's Id =======
        let bookingRequestUpdate = await super.updateByCustomOptions(
          bookingRequestsModel,
          {
            id: {
              [Op.in]: bookingRequestsIdArr,
            }
          },
          {
            customerId: deletedUser?.id,
          }
        );
        // ======= update bookingRequests with deleted user's Id =======
        
        // ======= update transactions with deleted user's Id =======
        let transactionsUpdate = await super.updateByCustomOptions(
          transactionModel, 
          {
            userId: id,
          },
          {
            userId: deletedUser?.id,
          }
        );
        // ======= update transactions with deleted user's Id =======

        // ======= update transactionHistories with deleted user's Id =======
        let transactionHistoriesUpdate = await super.updateByCustomOptions(
          transactionHistoryModel, 
          {
            userId: id,
          },
          {
            userId: deletedUser?.id,
          }
        );
        // ======= update transactionHistories with deleted user's Id =======
        
        // ======= update notifications with deleted user's Id =======
        let notificationsUpdate = await super.updateByCustomOptions(
          notificationModel, 
          {
            userId: id,
          },
          {
            userId: deletedUser?.id,
          }
        );
        // ======= update notifications with deleted user's Id =======
      }
    }

    let userHardDelete = await super.deleteById(userModel, id);

    if(userHardDelete){
      return res.status(200).json({
        status: true,
        message: "User permanently deleted.",
        data: {}
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Oops.. We ran into some problem.",
        data: {}
      });
    }

  });

  // ========================= CUSTOMER ===========================
  static forgotPasswordInitiate = catchAsyncErrors(async (req, res, next) => {
    let { email } = req.body;

    if(!email){
			return res.status(422).json({
				status: false,
				message: "Email is required.",
				data: {},
			});
		}

    let userExistCheck = await super.getByCustomOptionsSingle(req, userModel, {
      where: {
        email: email,
      }
    });

    if(!userExistCheck){
      return res.status(400).json({
        status: false,
        message: "No user with this email id found. Please provide a correct email id.",
        data: {}
      });
    }
    
    if(userExistCheck?.isActive == false){
      return res.status(400).json({
        status: false,
        message: "Your account has been deactivated or suspended. Please contact the customer support.",
        data: {}
      });
    }

    let OTP = Math.floor(1000 + Math.random() * 9000);

    let checkOtp = await super.getByCustomOptionsSingle(req, temporaryOtpModel, {
      where: {
        email: email,
      }
    });

    let userOtpUpdate = {};
    if(checkOtp){
      userOtpUpdate = await super.updateByCustomOptions(
        temporaryOtpModel, 
        {
          email: email,
        }, 
        {
          emailOTP: OTP,
        }
      );
    } else {
      userOtpUpdate = await super.create(res, temporaryOtpModel, {
        email: email,
        emailOTP: OTP,
      });
    }

    if(userOtpUpdate){
      let content = `
      <div>
        <h1>Hi ${userExistCheck?.firstName}, OTP to reset your account password is ${OTP}. If you have not made any such requests, please ignore this email. Do not share this OTP with anybody claiming to be an agent or anybody else. Providing this OTP to them may result in your account being sacrificed.<h1>
      <div>`;

      sendMail(email, `OTP for Forgot Password`, content);

      return res.status(200).json({
        status: true,
        message: "OTP successfully sent",
        data: {
          otp: OTP,
        }
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Oopps..we ran into some problem. Please try again later.",
        data: {}
      });
    }
  });
  static validateForgotPasswordOtp = catchAsyncErrors(async (req, res, next) => {
    let { emailOTP, email, } = req.body;

    if(!email){
			return res.status(422).json({
				status: false,
				message: "Email is required.",
				data: {},
			});
		}
    if(!emailOTP){
			return res.status(422).json({
				status: false,
				message: "OTP is required.",
				data: {},
			});
		}

    let checkOtp = await super.getByCustomOptionsSingle(req, temporaryOtpModel, {
      where: {
        email: email,
      }
    });

    if(emailOTP != checkOtp?.emailOTP){
      // OTP does not match =========
      return res.status(422).json({
        status: false,
        message: "Invalid email OTP.",
        data: {}
      });
    } else {
      let deleteTemporaryOtp = await super.deleteByCondition(temporaryOtpModel, {
        email: email,
        emailOTP: checkOtp?.emailOTP,
      });

      return res.status(200).json({
        status: true,
        message: "OTP valid.",
        data: {}
      });
    }

  });
  static resetPassword = catchAsyncErrors(async (req, res, next) => {
    let { email, password } = req.body;

    if(!email){
			return res.status(422).json({
				status: false,
				message: "Email is required.",
				data: {},
			});
		}
    if(!password){
			return res.status(422).json({
				status: false,
				message: "Password is required.",
				data: {},
			});
		}

    let userAttemptingToResetPass = await super.getByCustomOptionsSingle(req, userModel, {
      where: {
        email: email,
      }
    });

    if(!userAttemptingToResetPass){
      return res.status(400).json({
        status: false,
        message: "No user found with this email id. Please provide correct email id.",
        data: {}
      });
    }

    let updateFields = {
      password: await bcrypt.hash(password, 10),
    };

    let userUpdate = await super.updateByCustomOptions(
      userModel, 
      {
        id: userAttemptingToResetPass?.id,
      },
      updateFields
    );

    if(userUpdate){
      let content = `
      <div>
        <h1>Hi ${userAttemptingToResetPass?.firstName}, password reset successful. You can now login with the new credentials.<h1>
      <div>`;

      sendMail(email, `Password Reset Successful..!!`, content);

      return res.status(200).json({
        status: true,
        message: "Password reset successful.",
        data: {}
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Ooppss..!! Something went wrong.",
        data: {}
      });
    }
  });
  
  static customerRegister = catchAsyncErrors(async (req, res, next) => {
    let { firstName, lastName, email, password, dialCode, phone, dob, gender, address, id } = req.body;

    if (!id) {
      if (!firstName || !lastName) {
        return res.status(422).json({
          status: false,
          message: "First name or Last name is required.",
          data: {},
        });
      }
      if (!email) {
        return res.status(422).json({
          status: false,
          message: "Email is required.",
          data: {},
        });
      }
      if (!password) {
        return res.status(422).json({
          status: false,
          message: "Password is required.",
          data: {},
        });
      }
      if (!phone) {
        return res.status(422).json({
          status: false,
          message: "Phone is required.",
          data: {},
        });
      }
    }

    let customerRole = await roleModel.findOne({
      where: {
        roleName: "Customer",
        deletedAt: null,
      }
    });
    let guestRole = await roleModel.findOne({
      where: {
        roleName: "Guest",
        deletedAt: null,
      }
    });

    // =========== single file upload ================
    let fileName = "";
    if (req.files.profileImage) {
      let image = await fileUploaderSingle(
        "src/public/uploads/userImages/",
        req.files.profileImage
      );
      fileName = image.newfileName;
    }
    // =========== single file upload ================

    let updateFields = {
      roleId: customerRole.id,
    };
    if (firstName) {
      updateFields.firstName = firstName;
    }
    if (lastName) {
      updateFields.lastName = lastName;
    }
    if (email) {
      updateFields.email = email;
    }
    if (dialCode) {
      updateFields.dialCode = dialCode;
    }
    if (phone) {
      updateFields.phone = phone;
    }
    if (password) {
      updateFields.password = await bcrypt.hash(password, 10);
    }
    if (dob) {
      updateFields.dob = dob;
    }
    if (gender) {
      updateFields.gender = gender;
    }
    if (address) {
      updateFields.address = address;
    }
    if (fileName != "") {
      updateFields.profileImage = fileName;
    }

    let condition = {
      deletedAt: null,
      roleId: customerRole.id,
    };
    if (id) {
      // during edit -> should not check self ===
      condition.id = {
        [Op.ne]: id
      };
    }

    let checkCustomerExist = await userModel.findOne({
      where: {
        ...condition,
        [Op.or]: [{ phone: phone }, { email: email }],
      },
    });

    let checkGuestExist = await userModel.findOne({
      where: {
        roleId: guestRole.id,
        [Op.or]: [{ phone: phone }, { email: email }],
      },
    });
    
    if (checkCustomerExist) {
      if(checkCustomerExist.isVerified == true){
        return res.status(400).json({
          status: false,
          message: "Customer with this phone or email already registered..!!",
          data: checkCustomerExist,
        });
      } else {
        console.log("Un-verified customer.");
      }
    } else {
      console.log("Not registered as a customer yet.");
    }

    let updated = {};
    updated =
      id && id != "" && id != null
        ? await super.updateById(userModel, id, updateFields)
        : (checkGuestExist && checkGuestExist?.id != "" && checkGuestExist?.id != null)
            ? await super.updateByCustomOptions(
                userModel, 
                {
                  id: checkGuestExist?.id
                },
                updateFields
              )
            : (checkCustomerExist && checkCustomerExist?.isVerified == false && checkCustomerExist?.id != "" && checkCustomerExist?.id != null)
              ? await super.updateByCustomOptions(
                  userModel, 
                  {
                    id: checkCustomerExist?.id
                  },
                  updateFields
                )
              : await super.create(res, userModel, updateFields);

    if (updated) {
			let userDetails = {};
			if(id && id != "" && id != null){
				userDetails = await userModel.findOne({
					where: {
						id: id,
					}
				});
			} else {
        if(checkGuestExist && checkGuestExist?.id != "" && checkGuestExist?.id != null){
          userDetails = await userModel.findOne({
            where: {
              id: checkGuestExist?.id
            }
          });
        } else {
          if(checkCustomerExist && checkCustomerExist?.isVerified == false && checkCustomerExist?.id != "" && checkCustomerExist?.id != null){
            userDetails = await userModel.findOne({
              where: {
                id: checkCustomerExist?.id
              }
            });
          } else {
            userDetails = await userModel.findOne({
              where: {
                id: updated.id
              }
            });
          }
        }
			}
      
      let emailOTP = Math.floor(1000 + Math.random() * 9000);
      let phoneOTP = Math.floor(1000 + Math.random() * 9000);

      let checkOtp = await super.getByCustomOptionsSingle(req, temporaryOtpModel, {
        where: {
          email: email,
          phone: phone,
        }
      });

      let temporaryOtpUpdate = {};

      if(checkOtp){
        temporaryOtpUpdate = await super.updateByCustomOptions(
          temporaryOtpModel, 
          {
            email: email,
            phone: phone,
          },
          {
            emailOTP: emailOTP,
            phoneOTP: phoneOTP,
          }
        );
      } else {
        temporaryOtpUpdate = await super.create(res, temporaryOtpModel, {
          email: email,
          phone: phone,
          emailOTP: emailOTP,
          phoneOTP: phoneOTP,
        });
      }

      // ====== handle sendEmail here ======
      let content = `
      <div>
        <h1>OTP to validate your email: ${emailOTP}<h1>
      <div>`;
      
      sendMail(email, `Otp to Validate Email`, content);
      // ====== handle sendEmail here ======

      // ====== handle sendSms here ======
      // ====== handle sendSms here ======

      return res.status(200).json({
        status: true,
        message: "Successful.",
        data: userDetails,
        otp: {
          emailOTP: emailOTP,
          phoneOTP: phoneOTP,
        }
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Oops..!! Something wrong happened.",
        data: {},
      });
    }
  });

  static validateCustomerRegisterOtp = catchAsyncErrors(async (req, res, next) => {
    let { emailOTP, phoneOTP, email, phone, deviceType, fcmToken, deviceId, } = req.body;

    if(!email && !phone){
			return res.status(422).json({
				status: false,
				message: "Either email or phone is required.",
				data: {},
			});
		}
    if(!emailOTP && !phoneOTP){
			return res.status(422).json({
				status: false,
				message: "Either email OTP or phone OTP is required.",
				data: {},
			});
		}

    let dynamicWhereCondition = {};
    if(email){
      dynamicWhereCondition.email = email;
    }
    if(phone){
      dynamicWhereCondition.phone = phone;
    }
    let checkOtp = await super.getByCustomOptionsSingle(req, temporaryOtpModel, {
      where: dynamicWhereCondition
    });

    if(emailOTP){
      if(emailOTP != checkOtp?.emailOTP){
        // OTP does not match =========
        return res.status(422).json({
          status: false,
          message: "Invalid email OTP.",
          data: {}
        });
      }
    }
    if(phoneOTP){
      if(phoneOTP != checkOtp?.phoneOTP){
        // OTP does not match =========
        return res.status(422).json({
          status: false,
          message: "Invalid phone OTP.",
          data: {}
        });
      }
    }

    let user = await userModel.findOne({
      where: {
        email: email,
        isActive: true,
      },
    });

    // log the user in ========

    let MAC = pkg();
    // console.log(MAC);

    let token = JWTAuth.ClientSign({
      id: user.id,
      roleId: user.roleId,
      firstName: user.firstName,
      lastName: user.lastName,
      email: user.email,
      phone: user.phone,
      deviceType: user.deviceType,
      macAddress: MAC,
    });

    let time = new Date();
    time.setDate(time.getDate() + 30);
    time = new Date(time);

    let conditions = { email: email };
    let updateFields = {
      loginFlag: true,
      macAddress: MAC,
    };
    
    if (Number(deviceType) == 2) {
      updateFields.webLogin = token;
    } else {
      updateFields.appLogin = token;
      updateFields.fcmToken = fcmToken ? fcmToken : "";
      updateFields.deviceId = deviceId ? deviceId : "";
    }
    updateFields.isVerified = true;

    let userDetailsUpdate = await super.updateByCustomOptions(
      userModel,
      conditions,
      updateFields
    );

    if(userDetailsUpdate){
      // let temporaryOtpDelete = await temporaryOtpModel.destroy({
      //   where: {
      //     email: email,
      //   }
      // });

      let deleteTemporaryOtp = await super.deleteById(temporaryOtpModel, checkOtp?.id);

      return res.status(200).json({
        status: true,
        message: "OTP verified.",
        data: {
          token: token,
        }
      });
    } else {
      return req.status(400).json({
        status: false,
        message: "Something went wrong while verifiying OTP.",
        data: {}
      });
    }
  });

  static customerCurrentCheckins = catchAsyncErrors(async (req, res, next) => {
    let searchOptions = {
      where: {
        customerId: req.user.id,
        bookingStatus: "Checked In",

        isActive: true,
        deletedAt: null,
      },
      order: [["createdAt", "DESC"]],
      include: [
        {
          model: slotsModel,
        },
        {
          model: vehicleTypesModel
        },
        {
          model: userModel,
          attributes: {
            exclude: [
              "password",
              "webLogin",
              "appLogin",
              "fcmToken",
              "OTP",
              "macAddress",
            ],
          },
        },
      ],
    };
    let checkedInBookings = await super.getList(req, bookingRequestsModel, searchOptions);

    if(checkedInBookings.length > 0){
      return res.status(200).json({
        status: true,
        message: "Current bookings found",
        data: checkedInBookings,
      });
    } else {
      return res.status(200).json({
        status: true,
        message: "No current bookings found",
        data: [],
      });
    }

  });

  static customerBookingHistory = catchAsyncErrors(async (req, res, next) => {
    let searchOptions = {
      where: {
        customerId: req.user.id,
        isActive: true,
        deletedAt: null,
      },
      order: [["createdAt", "DESC"]],
      include: [
        {
          model: slotsModel,
        },
        {
          model: vehicleTypesModel
        },
        {
          model: userModel,
          attributes: {
            exclude: [
              "password",
              "webLogin",
              "appLogin",
              "fcmToken",
              "OTP",
              "macAddress",
            ],
          },
        },
      ],
    };
    let bookingHistory = await super.getList(req, bookingRequestsModel, searchOptions);

    if(bookingHistory.length > 0){
      return res.status(200).json({
        status: true,
        message: "Booking history found..!!",
        data: bookingHistory,
      });
    } else {
      return res.status(200).json({
        status: true,
        message: "No booking history found..!!",
        data: [],
      });
    }
  });

  static requestToMarkReady = catchAsyncErrors(async (req, res, next) => {
    let { bookingRequestId } = req.body;

    let roleOfSuperAdmin = await super.getByCustomOptionsSingle(req, roleModel,  {
			where: { 
				roleName: "Super Admin",
			},
		});

		let superUser = await super.getByCustomOptionsSingle(req, userModel, {
			where: {
				roleId: roleOfSuperAdmin?.id,
			},
		});

    let bookingRequest = await super.getByCustomOptionsSingle(req, bookingRequestsModel, {
      where: { 
        id: bookingRequestId,
      },
    });
    let customerData = await super.getByCustomOptionsSingle(req, userModel, {
			where: {
				id: bookingRequest?.customerId,
			}
		});
    if(!bookingRequest){
      return res.status(400).json({
        status: false,
        message: "No booking request found with this id.",
        data: {},
      });
    }

    if(
      (bookingRequest.bookingStatus == "Failed")
      || (bookingRequest.bookingStatus == "Checked Out")
      || (bookingRequest.bookingStatus == "Booked")
    ){
      return res.status(422).json({
        status: false,
        message: "Can't process further. This booking request is either has not been checked in yet or already checked out or failed.",
        data: {},
      });
    } 

    let conditions = { 
      id: bookingRequestId, 
      isCancelled: false,
    };
    let updateFields = {
      readyStatus: "Requested"
    };
    let bookingRequestUpdate = {};
    bookingRequestUpdate = await super.updateByCustomOptions(
      bookingRequestsModel, 
      conditions,
      updateFields
    );

    if(bookingRequestUpdate){
      let updatedBookingRequest = await super.getByCustomOptionsSingle(req, bookingRequestsModel, {
        where: {
          id: bookingRequestId,
        },
      });

      let checkSlot = await super.getByCustomOptionsSingle(req, slotsModel, {
        where: {
          id: updatedBookingRequest?.slotId,
        },
      });

      // ================================
      // ----- Handle Notifications -----
      // ================================
      // ----- send successful booking notification -----
      
      // ----- 1. to customer -----
      let notiDataForCustomer = {
        userId: updatedBookingRequest?.customerId?? updatedBookingRequest?.customerId,
        bookingRequestId: bookingRequestId,

        notiTitle: `Request to make car ready is received..!!`,

        notiBody: `Roger that captain..!! We got your request..!! We will assign an agent and your car will be ready in a short while. Please keep this booking ticket: ${updatedBookingRequest?.bookingTicketNo} handy to make your check-out as hassle free as possible.`
      }
      let createNotificationForCustomer = await super.create(res, notificationModel, notiDataForCustomer);
      // ----- 1. to customer -----

      // ----- 2. to super admin -----
      let notiDataForSuperAdmin = {
        userId: superUser.id?? superUser.id,
        bookingRequestId: bookingRequestId,

        notiTitle: `Ahoy..!! New Car Ready Request Arrived..!!`,

        notiBody: `Dear Admin, customer wih car plate no.: ${updatedBookingRequest?.plateNumber} has requested to mark car as ready. Parking slot no.: ${checkSlot?.slotName}; Slot location: [Bay-no.: ${checkSlot?.slotBayNumber}, Row-no.: ${checkSlot?.slotRowNumber}]. For more details, please refer to ticket: ${updatedBookingRequest?.bookingTicketNo}.`
      }
      let createNotificationForSuperAdmin = await super.create(res, notificationModel, notiDataForSuperAdmin);
      // ----- 2. to super admin -----

      // ----- send successful booking notification -----
      // ================================
      // ----- Handle Notifications -----
      // ================================

      // ============= send email =============
			let content = `
			<div>
				<h4>Dear ${customerData?.firstName}, We got your request..!! We will assign an agent and your car will be ready in a short while. Please keep this booking ticket: ${updatedBookingRequest?.bookingTicketNo} handy to make your check-out as hassle free as possible.</h4>
			<div>`;

			sendMail(customerData?.email, `Request to make car ready is received..!!`, content);
			// ============= send email =============

      //  ========== push noti ==========
			console.log("------ Sending request-ready Notification ----");
			let messages = {
				title: "Request to make car ready is received..!!",
				body: JSON.stringify({
					// "tripId": tripPassenger.tripId._id.toString(),
					"msg": `Roger that captain..!! We got your request..!! We will assign an agent and your car will be ready in a short while. Please keep this booking ticket: ${updatedBookingRequest?.bookingTicketNo} handy to make your check-out as hassle free as possible.`,
					"type": "Show"
				}),
			};
			if(customerData?.fcmToken){
				await sendPushNotification(customerData?.fcmToken, messages, "android");
			}
			//  ========== push noti ==========
      
      return res.status(200).json({
        status: true,
        message: "Requested",
        data: updatedBookingRequest,
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Oopps..!! Something went wrong while requesting to mark ready..!! You can still go to the site and collect your car. Sorry for the inconvenience.",
        data: {},
      });
    }
  });

  // ========================= CUSTOMER ===========================
  
  // ============ from admin-end ============
  static carReadyStatusChange = catchAsyncErrors(async (req, res, next) => {
    let { bookingRequestId, readyStatus } = req.body;

    let bookingRequest = await super.getByCustomOptionsSingle(req, bookingRequestsModel, {
      where: { 
        id: bookingRequestId,
        isCancelled: false,
      },
    });

    if(!bookingRequest){
      return res.status(400).json({
        status: false,
        message: "Ooppss..!! No booking request found.",
        data: {},
      });
    }
    
    if(bookingRequest.readyStatus == "Not Requested"){
      return res.status(400).json({
        status: false,
        message: "Client has not requested to mark ready yet.",
        data: {},
      });
    }

    let conditions = { 
      id: bookingRequestId,
    };
    let updateFields = {
      readyStatus: readyStatus,
    };

    let bookingRequestUpdate = await super.updateByCustomOptions(
      bookingRequestsModel,
      conditions,
      updateFields
    );

		let customerData = await super.getByCustomOptionsSingle(req, userModel, {
			where: {
				id: bookingRequest?.customerId,
			}
		});
    if(bookingRequestUpdate){
      let bookingRequestDetail = await super.getByCustomOptionsSingle(req, bookingRequestsModel, {
        where: { 
          id: bookingRequestId 
        },
      });

      // ============= send email =============
			let content = `
			<div>
				<h4>Dear ${customerData?.firstName}, an agent has marked your car as ${readyStatus}.</h4>
			<div>`;

			sendMail(customerData?.email, `Your car has been marked as ${readyStatus}`, content);
			// ============= send email =============

      //  ========== push noti ==========
			console.log("------ Sending request-ready Notification ----");
			let messages = {
				title: `Your car has been marked as ${readyStatus}`,
				body: JSON.stringify({
					// "tripId": tripPassenger.tripId._id.toString(),
					"msg": `Dear ${customerData?.firstName}, an agent has marked your car as ${readyStatus}.`,
					"type": "Show"
				}),
			};
			if(customerData?.fcmToken){
				await sendPushNotification(customerData?.fcmToken, messages, "android");
			}
			//  ========== push noti ==========

      return res.status(200).json({
        status: true,
        message: "Status updated.",
        data: bookingRequestDetail,
      });
      
    } else {
      return res.status(400).json({
        status: false,
        message: "Problem updating status.",
        data: {}
      });
    }
  });
  // ============ from admin-end ============

}

module.exports = UserController;
