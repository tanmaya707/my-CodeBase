const axios = require("axios");
const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/errorHandler");
const RequestHandler = require("../utils/RequestHandler");
const fileUploaderSingle = require("../utils/fileUpload").fileUploaderSingle;
const bcrypt = require("bcryptjs");
const JWTAuth = require("../utils/jwtToken");
const jwt = require("jsonwebtoken");
const jwtConfig = require("../config").JWT;
const { Op } = require("sequelize");

const {
  calculateDistance,
  calculateDistanceInsTentApi,
  calculateTimeInKilometers,
  getRateChartCategory,
} = require("../utils/utilities");
const {
  MSG_RECORD_STATUS_SUCCESS,
  MSG_RECORD_FETCH_SUCCESS,
} = require("../config/constants");
const requestHandler = new RequestHandler();

// ------- STRIPE INITIALIZE -------
const stripe = require('stripe')(
  (process.env.APP_ENV == 'production')
    ? process.env.STRIPE_LIVE_SECRET_KEY
    : process.env.STRIPE_LIVE_SECRET_KEY
);
// ------- STRIPE INITIALIZE -------

const db = require("../models");
const userModel = db.Users;
const transactionModel = db.Transactions;
const transactionLogModel = db.TransactionLogs;
const transactionHistoryModel = db.TransactionHistory;

class TransactionController extends BaseController {
  constructor() {
    super();
  }

  // ====================================================================================
  // ------------------------------ ONLINE PAYMENT FOR RIDE -----------------------------
  // ====================================================================================

  // ------------------------------ WITH STRIPE ---------------------------
  static createPaymentIntentWithStripe = catchAsyncErrors(async (req, res, next) => {
    const { userId, firstName, lastName, amount, currency } = req.body;

    if (!amount) {
      return res.status(422).json({
        status: false,
        message: "Amount is required",
        data: {},
      });
    }
    if (!currency) {
      return res.status(422).json({
        status: false,
        message: "Currency is required",
        data: {},
      });
    }

    let customerDetail = {};
    let fullNameOfCustomer = "";
    if(userId){
      customerDetail = await super.getByCustomOptionsSingle(req, userModel, {
        where: {
          id: userId,
        }
      });
      fullNameOfCustomer = customerDetail?.firstName + " " + customerDetail?.lastName;
    } else {
      fullNameOfCustomer = firstName + " " + lastName;
    }


    // const customer = await stripe.customers.create({
    //   name: fullNameOfCustomer,
    //   address: {
    //     line1: customerDetail?.address || "510 Townsend St",
    //     postal_code: customerDetail?.zipcode || "98140",
    //     city: customerDetail?.city || "San Francisco",
    //     state: customerDetail?.state || "CA",
    //     country: "AE",
    //   },
    // });

    const customer = await stripe.customers.create({
      name: fullNameOfCustomer,
      address: {
        line1: "510 Townsend St",
        postal_code: "98140",
        city: "San Francisco",
        state: "CA",
        country: "US",
      },
    });
    const ephemeralKey = await stripe.ephemeralKeys.create(
      { customer: customer.id },
      { apiVersion: "2024-06-20" }
    );

    let options = {
      amount: parseFloat(amount.toString()) * 100,
      currency: currency,
      customer: customer.id,
    };

    // Create Payment Intent
    const paymentIntent = await stripe.paymentIntents.create({
      amount: options.amount,
      currency: options.currency,
      customer: options.customer,
      description: "Reservation fee.",
      payment_method_types: ["card"],
      // automatic_payment_methods: {
      //   enabled: true,
      // },
    });
    // return res.status(200).json({
    //   paymentIntent: paymentIntent,
    // });


    let deletedUser = await super.getByCustomOptionsSingle(req, userModel, {
      where: {
        email: "deleted@deleted.deleted",
        // dialCode: "+999",
        // phone: 1000000000,
        // OTP: "911911",
        isActive: false,
        deleted_by: 1,
        deleted_at: {
          [Op.not]: null,
        }
      }
    });
    if(!deletedUser){
      return res.status(400).json({
        status: false,
        message: "System user not configured.",
        data: {}
      });
    }

    let transactionData = {
      userId: (userId)? (userId) : (deletedUser?.id),
      paymentGatewayOrderId: paymentIntent.id,
      paidAmount: paymentIntent.amount,
			paidCurrency: paymentIntent.currency,
      type: "tripPayment",
      remark: "Payment for trip.",
      paymentDate: new Date(),
      paymentStatus: "Pending",
    };
    let transactionCreated = await super.create(res, transactionModel, transactionData);

    // console.log("transactionCreated ===>");
    // console.log(transactionCreated);

    if (transactionCreated) {
      let transactionLogData = {
        transactionId: transactionCreated.id,
        request: JSON.stringify(req.body),
        response: JSON.stringify(paymentIntent),
      };
      let transactionLogCreated = await super.create(res, transactionLogModel, transactionLogData);
      if (transactionLogCreated) {
        return res.status(200).json({
          status: true,
          message: "Intent created successfully in Stripe Server for Reservation Fee Payment.",
          data: {
            transactionCreatedId: transactionCreated?.id,
            amount: paymentIntent.amount,
            stripeOrderId: paymentIntent.id,
            paymentIntent: paymentIntent.client_secret,
            ephemeralKey: ephemeralKey.secret,
            customer: customer.id,
            publishableKey:
              process.env.APP_ENV == "production"
                ? process.env.STRIPE_LIVE_PUBLISHABLE_KEY
                : process.env.STRIPE_LIVE_PUBLISHABLE_KEY,
          },
          errors: null,
        });
      }
    }
  });

  static verifyPaymentViaStripe = catchAsyncErrors(async (req, res, next) => {
    const {
      userId,
      stripeOrderId,
      amount,
      currency,
      // customerId,
    } = req.body;

    let deletedUser = await super.getByCustomOptionsSingle(req, userModel, {
      where: {
        email: "deleted@deleted.deleted",
        // dialCode: "+999",
        // phone: 1000000000,
        // OTP: "911911",
        isActive: false,
        deleted_by: 1,
        deleted_at: {
          [Op.not]: null,
        }
      }
    });
    if(!deletedUser){
      return res.status(400).json({
        status: false,
        message: "System user not configured.",
        data: {}
      });
    }

    if (!stripeOrderId) {
      return res.status(422).json({
        status: false,
        message: "Stripe order Id is required",
        data: {},
      });
    }

    // Retrieve the Payment Intent from Stripe
    const paymentIntent = await stripe.paymentIntents.retrieve(stripeOrderId);

    let existingTransaction = await super.getByCustomOptionsSingle(
      req,
      transactionModel,
      {
        where: {
          paymentGatewayOrderId: stripeOrderId,
        },
      },
    );
    if (paymentIntent) {
      if (paymentIntent.status === "succeeded") {
        // Payment was successful
        if (existingTransaction) {
          await super.updateById(transactionModel, existingTransaction.id, {
            paymentStatus: "Paid",
            paidVia: "Stripe",
          });

          await super.create(res, transactionLogModel, {
            transactionId: existingTransaction.id,
            request: JSON.stringify(req.body),
            response: JSON.stringify(paymentIntent),
          });

          let transactionHistoryData = {
            userId: (userId)? (userId) : (deletedUser?.id),
            // userId: customerId,
            transactionId: existingTransaction.id,
            
            paidAmount: amount,
            paidCurrency: currency,

            gatewayName: "Stripe",

            paymentType: "Reservation Fees",
            remarks: "Reservation fees payment via Stripe successful.",
            
            isSuccess: true,
          };
          let transactionHistory = await super.create(res, transactionHistoryModel, transactionHistoryData);

          return res.status(200).json({
            status: true,
            message: "Payment successful..!!",
            data: transactionHistory,
          });
        } else {
          let transactionHistoryData = {
            userId: (userId)? (userId) : (deletedUser?.id),
            // userId: customerId,
            transactionId: existingTransaction.id,

            paidAmount: amount,
            paidCurrency: currency,
    
            gatewayName: "Stripe",
    
            paymentType: "Reservation Fees",
            remarks: "Reservation fees payment via Stripe failed as transaction not found probably due to incorrect Stripe Order Id..!!",
            
            isSuccess: false,
          };
          let transactionHistory = await super.create(res, transactionHistoryModel, transactionHistoryData);

          return res.status(404).json({
            status: false,
            message: "Transaction not found",
            data: transactionHistory,
          });
        }
      } else {
        // Payment status is not 'succeeded' ====
        let transactionHistoryData = {
          userId: (userId)? (userId) : (deletedUser?.id),
          // userId: customerId,
          transactionId: existingTransaction.id,

          paidAmount: amount,
          paidCurrency: currency,

          gatewayName: "Stripe",

          paymentType: "Reservation Fees",
          remarks: "Reservation fees payment via Stripe failed or not completed yet..!!",
          
          isSuccess: false,
        };
        let transactionHistory = await super.create(res, transactionHistoryModel, transactionHistoryData);

        return res.status(400).json({
          status: false,
          message: "Payment failed or is not yet completed.",
          data: transactionHistory,
        });
      }
    } else {
      let transactionHistoryData = {
        userId: (userId)? (userId) : (deletedUser?.id),
        // userId: customerId,
        transactionId: existingTransaction.id,

        paidAmount: amount,
        paidCurrency: currency,

        gatewayName: "Stripe",

        paymentType: "Reservation Fees",
        remarks: "Reservation fees payment via Stripe failed as payment intent not found due to incorrect Stripe Order Id..!!",
        
        isSuccess: false,
      };
      let transactionHistory = await super.create(res, transactionHistoryModel, transactionHistoryData);

      return res.status(404).json({
        status: false,
        message: "Payment intent not found.",
        data: transactionHistory,
      });
    }
  });
  // ------------------------------ WITH STRIPE ---------------------------

  // ====================================================================================
  // ------------------------------ ONLINE PAYMENT FOR RIDE -----------------------------
  // ====================================================================================
}

module.exports = TransactionController;
