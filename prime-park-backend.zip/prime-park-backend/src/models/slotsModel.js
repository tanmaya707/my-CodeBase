module.exports = (sequelize, DataTypes) => {
  const slotsSchema = sequelize.define("slots", {
    parkingLotId: { type: DataTypes.INTEGER, allowNull: false },
    
    slotName: { type: DataTypes.STRING, allowNull: false },

    // -------- slot co-ordinates --------
    slotBayNumber: { type: DataTypes.INTEGER, allowNull: false },
    slotRowNumber: { type: DataTypes.INTEGER, allowNull: false },
    // -------- slot co-ordinates --------

    occupancyStatus: {
      type: DataTypes.ENUM("Vacant", "Occupied", "Booked", "Overstay"),
      allowNull: false,
      defaultValue: "Vacant",
    },

    isActive: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true, // true for Active, false for Inactive
      comment: "false-Inactive, true-Active",
    },

    deleted_by: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    deletedAt: {
      field: "deleted_at",
      type: DataTypes.DATE,
    },
  }, {
    indexes: [
      {
        // ---- 'parkingLotId', 'slotName', 'slotBayNumber', 'slotRowNumber' ---- 
        // ---- combination of these 4-fields must be unique in order to prevent duplicate entry of a same slot ----
        unique: true,
        fields: ['parkingLotId', 'slotName', 'slotBayNumber', 'slotRowNumber']
      },
    ]
  });

  return slotsSchema;
};
