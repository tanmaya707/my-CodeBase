module.exports = (sequelize, DataTypes) => {
  const temporayOtpSchema = sequelize.define("temporaryotps", {
    email: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    dialCode: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    phone: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    emailOTP: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    phoneOTP: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },

    isActive: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true, // true for Active, false for Inactive
      comment: "false-Inactive, true-Active",
    },
    
    createdAt: {
      field: "created_at",
      type: DataTypes.DATE,
    },
    updatedAt: {
      field: "updated_at",
      type: DataTypes.DATE,
    },

    deleted_by: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    deletedAt: {
      field: "deleted_at",
      type: DataTypes.DATE,
    },
  });
  return temporayOtpSchema;
};

