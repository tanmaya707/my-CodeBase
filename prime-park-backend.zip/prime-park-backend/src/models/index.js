const mysqlConfig = require("../config/index.js").Mysql;
const Sequelize = require("sequelize");
const session = require('express-session');
const SequelizeStore = require('connect-session-sequelize')(session.Store);

const sequelizeConnectionInstance = new Sequelize(mysqlConfig.dbName, mysqlConfig.user, mysqlConfig.pwd, {
  host: mysqlConfig.host,
  dialect: mysqlConfig.dialect,
  logging: mysqlConfig.debug,
  // logging: console.log,
});
 
sequelizeConnectionInstance
  .authenticate()
  .then(() => {
    console.log('Mysql connection has been established successfully.')
  })
  .catch(err => {
    console.error('Unable to connect to the Mysql database:', err)
  })
 
// storing the session
const sequelizeSessionStore = new SequelizeStore({
  db: sequelizeConnectionInstance,
})
 

const db = {};
db.sequelizeConnectionInstance = sequelizeConnectionInstance;
db.Sequelize = Sequelize;

db.sequelizeSessionStore = sequelizeSessionStore;

// =======================================================================
// ======== include the Models and group the table-relations here ========
// =======================================================================

// ---- users ----
db.Users = require("./userModel")(sequelizeConnectionInstance, Sequelize);
// ---- users ----

// ---- roles ----
db.Roles = require("./roleModel")(sequelizeConnectionInstance, Sequelize);
// ---- roles ----

db.Users.belongsTo(db.Roles, { foreignKey: 'roleId' });
db.Roles.hasMany(db.Users, { foreignKey: 'roleId' });

// ---- policies ----
db.Policies = require("./policiesModel")(sequelizeConnectionInstance, Sequelize);
// ---- policies ----

// ---- modules ----
db.Modules = require("./modulesModel")(sequelizeConnectionInstance, Sequelize);

db.Modules.belongsTo(db.Modules, { foreignKey: 'parentModuleId', }); //  as: 'parentModule'
db.Modules.hasOne(db.Modules, { foreignKey: 'parentModuleId', });
// ---- modules ----

// ---- modulePermissions ----
db.ModulePermissions = require("./modulePermissionsModel")(sequelizeConnectionInstance, Sequelize);
// ---- modulePermissions ----

db.Users.belongsToMany(db.Modules, {
  through: db.ModulePermissions, // Name of the junction table
  foreignKey: 'userId',
  otherKey: 'moduleId',
});
db.Modules.belongsToMany(db.Users, {
  through: db.ModulePermissions, // Name of the junction table
  foreignKey: 'moduleId',
  otherKey: 'userId',
});

// ---- temporaryOtps ----
db.TemporaryOtps = require("./temporaryOtpModel")(sequelizeConnectionInstance, Sequelize);
// ---- temporaryOtps ----


// ---- vehicleTypes ----
db.VehicleTypes = require("./vehicleTypesModel")(sequelizeConnectionInstance, Sequelize);
// ---- vehicleTypes ----

// ---- priceChart ----
db.PriceCharts = require("./priceChartModel")(sequelizeConnectionInstance, Sequelize);
// ---- priceChart ----

db.VehicleTypes.hasOne(db.PriceCharts, {foreignKey: 'vehicleTypeId',});
db.PriceCharts.belongsTo(db.VehicleTypes, {foreignKey: 'vehicleTypeId',});

// ---- vendors ----
db.Vendors = require("./vendorModel")(sequelizeConnectionInstance, Sequelize);
// ---- vendors ----
// ---- agents ----
db.Agents = require("./agentModel")(sequelizeConnectionInstance, Sequelize);
// ---- agents ----

db.Vendors.belongsTo(db.Users, { foreignKey: 'userId' });
db.Users.hasOne(db.Vendors, { foreignKey: 'userId' });

// ---- parking businesses ----
db.ParkingBusinesses = require("./parkingBusinessModel")(sequelizeConnectionInstance, Sequelize);
// ---- parking businesses ----

// ---- parking grounds ----
db.ParkingGrounds = require("./parkingGroundsModel")(sequelizeConnectionInstance, Sequelize);
// ---- parking grounds ----

db.Agents.belongsTo(db.Users, { foreignKey: 'userId' });
db.Users.hasOne(db.Agents, { foreignKey: 'userId' });

db.Agents.belongsTo(db.ParkingGrounds, { foreignKey: 'parkingGroundId', });
db.ParkingGrounds.hasMany(db.Agents, { foreignKey: 'userId' });

// ---- staticCharges ----
db.StaticCharges = require("./staticChargesModel")(sequelizeConnectionInstance, Sequelize);
// ---- staticCharges ----

db.StaticCharges.belongsTo(db.ParkingGrounds, { foreignKey: 'parkingGroundId' });
db.ParkingGrounds.hasOne(db.StaticCharges, { foreignKey: 'parkingGroundId' });

db.ParkingGrounds.belongsTo(db.ParkingBusinesses, {
  foreignKey: 'parkingBusinessId', 
  onDelete: 'CASCADE' // Ensure that if a parking business is deleted, related grounds are also deleted
});
db.ParkingBusinesses.hasMany(db.ParkingGrounds, { foreignKey: 'parkingBusinessId', });

// ---- parking-lots ----
db.ParkingLots = require("./parkingLotsModel")(sequelizeConnectionInstance, Sequelize);
// ---- parking-lots ----

db.ParkingLots.belongsTo(db.ParkingGrounds, { 
  foreignKey: 'parkingGroundId', 
  onDelete: 'CASCADE' // Ensure that if a parking ground is deleted, related lots are also deleted
});
db.ParkingGrounds.hasMany(db.ParkingLots, { foreignKey: 'parkingGroundId', });

// ---- slots ----
db.Slots = require("./slotsModel")(sequelizeConnectionInstance, Sequelize);
// ---- slots ----

db.Slots.belongsTo(db.ParkingLots, {
  foreignKey: 'parkingLotId', 
  onDelete: 'CASCADE' // Ensure that if a parking lot is deleted, related slots are also deleted
});
db.ParkingLots.hasMany(db.Slots, { foreignKey: 'parkingLotId', });

// ---- transactions ----
db.Transactions = require('./transactionModel')(sequelizeConnectionInstance, Sequelize);
// ---- transactions ----
// ---- transactionLogs ----
db.TransactionLogs = require('./transactionLogModel')(sequelizeConnectionInstance, Sequelize);
// ---- transactionLogs ----
// ---- transactionHistories ----
db.TransactionHistory = require('./transactionHistoryModel')(sequelizeConnectionInstance, Sequelize);
// ---- transactionHistories ----

db.Transactions.belongsTo(db.Users, { foreignKey: 'userId' });
db.Users.hasMany(db.Transactions, { foreignKey: 'userId' });

db.TransactionLogs.belongsTo(db.Transactions, { foreignKey: 'transactionId' });
db.Transactions.hasMany(db.TransactionLogs, { foreignKey: 'transactionId' });

db.TransactionHistory.belongsTo(db.Users, { foreignKey: 'userId' });
db.Users.hasMany(db.TransactionHistory, { foreignKey: 'userId' });

db.TransactionHistory.belongsTo(db.Transactions, { foreignKey: 'transactionId' });
db.Transactions.hasMany(db.TransactionHistory, { foreignKey: 'transactionId' });

// ---- bookingRequests ----
db.BookingRequests = require("./bookingRequestsModel")(sequelizeConnectionInstance, Sequelize);
// ---- bookingRequests ----
// ---- carMovements ----
db.CarMovements = require("./carMovementsModel")(sequelizeConnectionInstance, Sequelize);
// ---- carMovements ----
// ---- invoice ----
db.Invoices = require("./invoiceModel")(sequelizeConnectionInstance, Sequelize);
// ---- invoice ----

db.BookingRequests.belongsTo(db.Users, {foreignKey: 'customerId',});
db.Users.hasMany(db.BookingRequests, {foreignKey: 'customerId',});

db.BookingRequests.belongsTo(db.Slots, {foreignKey: 'slotId'});
db.Slots.hasMany(db.BookingRequests, {foreignKey: 'slotId'});

db.BookingRequests.belongsTo(db.VehicleTypes, {foreignKey: 'vehicleTypeId'});
db.VehicleTypes.hasMany(db.BookingRequests, {foreignKey: 'vehicleTypeId'});

db.BookingRequests.belongsTo(db.TransactionHistory, { foreignKey: 'transactionHistoryId' });
db.TransactionHistory.hasOne(db.BookingRequests, { foreignKey: 'transactionHistoryId' });

db.CarMovements.belongsTo(db.BookingRequests, {foreignKey: 'bookingRequestId',});
db.BookingRequests.hasOne(db.CarMovements, {foreignKey: 'bookingRequestId',});

db.CarMovements.belongsTo(db.Vendors, {foreignKey: 'vendorId'});
db.Vendors.hasMany(db.CarMovements, {foreignKey: 'vendorId'});

db.CarMovements.belongsTo(db.VehicleTypes, {foreignKey: 'actualvehicleTypeId'});
db.VehicleTypes.hasMany(db.CarMovements, {foreignKey: 'actualvehicleTypeId'});

db.Invoices.belongsTo(db.BookingRequests, {foreignKey: "bookingRequestId"});
db.BookingRequests.hasOne(db.Invoices, {foreignKey: "bookingRequestId"});

db.AgentBookingMappings = require('./agentBookingMappingsModel')(sequelizeConnectionInstance, Sequelize);

db.AgentBookingMappings.belongsTo(db.Agents, { foreignKey: 'agentId' });
db.Agents.hasMany(db.AgentBookingMappings, { foreignKey: 'agentId' });

db.AgentBookingMappings.belongsTo(db.BookingRequests, { foreignKey: 'bookingRequestId' });
db.BookingRequests.hasOne(db.AgentBookingMappings, { foreignKey: 'bookingRequestId' });

db.SocketRooms = require('./socketRoomModel')(sequelizeConnectionInstance, Sequelize);
db.SocketRooms.belongsTo(db.Users, { foreignKey: 'roomId' });
db.Users.hasOne(db.SocketRooms, { foreignKey: 'roomId' });

db.Notifications = require('./notificationModel')(sequelizeConnectionInstance, Sequelize);

db.Notifications.belongsTo(db.Users, { foreignKey: 'userId' });
db.Users.hasMany(db.Notifications, { foreignKey: 'userId' });

db.Notifications.belongsTo(db.BookingRequests, { foreignKey: 'bookingRequestId' });
db.BookingRequests.hasMany(db.Notifications, { foreignKey: 'bookingRequestId' });

// =======================================================================
// ======== include the Models and group the table-relations here ========
// =======================================================================

module.exports = db;