module.exports = (sequelize, DataTypes) => {
  const notificationsSchema = sequelize.define("notifications", {
    userId: {
      type: DataTypes.INTEGER,
      references: {
        model: "users",
        key: "id",
      },
      allowNull: true,
			defaultValue: null,
    },
		bookingRequestId: { type: DataTypes.INTEGER, allowNull: true, defaultValue: null, },

		notiTitle: { type: DataTypes.TEXT("medium"), allowNull: false,},

		notiBody: { type: DataTypes.TEXT("long"), allowNull: false,},

    isActive: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true, // true for Active, false for Inactive
      comment: "false-Inactive, true-Active",
    },

		isRead: {
			type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false, // true for Read, false for Unread
      comment: "false-Unread, true-Read",
		},

    deleted_by: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    deletedAt: {
      field: "deleted_at",
      type: DataTypes.DATE,
    },
  });

  return notificationsSchema;
};
