require('dotenv').config();
const app = require('./app');
const connectDatabase = require('./src/config/connect');

const Emitter = require('events');
const db = require('./src/models');

// Function to start the server
function startServer() {
  app.listen(process.env.PORT, () => {
    if (process.env.APP_ENV == "production") {
      console.log(`server is listening on ${process.env.APP_URL}`);
    } else {
      console.log(`server is listening on http://localhost:` + process.env.PORT + "/");
    }
  });
}

process.on("uncaughtException", (err) => {
  console.log(`Error: ${err.message}`);
  console.log(`Shutting down the server due to unhandled Uncaught Rejection`);

  server.close(() => {
    startServer();
  });
});

// ===== calls the connection variable of MongoDB from here =====
// connectDatabase.connectMongoDatabase();
// ===== calls the connection variable of MongoDB from here =====

// ===== Sequelize gets called from within the index of model folder =====
// ===== Sequelize gets called from within the index of model folder =====
  
// Event emitter
const eventEmitter = new Emitter();
app.set('eventEmitter', eventEmitter);

// process.env.TZ = 'Asia/Kolkata';
process.env.TZ = (process.env.APP_ENV == "production")? process.env.PROD_TZ : process.env.DEV_TZ;

const server = app.listen(process.env.PORT, () => {
  if (process.env.APP_ENV == "production") {
    console.log(`server is working on ${process.env.APP_URL}`);
  } else {
    console.log(`server is working on http://localhost:` + process.env.PORT + "/");
  }
});

process.on("unhandledRejection", err => {
  console.log(`Error: ${err.message}`);
  console.log(`Shutting down the server due to unhandled Promise Rejection`);

  // Close the server gracefully
  server.close(() => {
    console.log('Server closed. Restarting...');

    // Restart the server after it's closed
    startServer();
  });
});

// ============================ socket.io START ============================
const io = require('socket.io')(server, {
  cors: {
      origin: "*",
      methods: ["GET", "POST"]
  }
});

const bookingRequestsModel = db.BookingRequests;
const socketRoomModel = db.SocketRooms;

io.on('connection', async (socket) => {
  console.log(`Client connected: ${socket.id}`);

  
  // socket.on('joinRoom', async (userId) => {
  //   // ----- 'roomId' should be userId -----
  //   let checkSocketRoomExists = await socketRoomModel.findOne({
  //     where: {
  //       roomId: userId,
  //     },
  //   });

  //   if(!checkSocketRoomExists){
  //     // ---- if room for this user is not created yet ----
  //     let createSocketRoom = await socketRoomModel.create({
  //       roomId: userId,
  //     });
  //     // ---- if room for this user is not created yet ----
  //     console.log(`Room created for userId: ${userId}`);
  //   }

  //   // ----- join client to room -----
  //   socket.join(userId);
  //   // ----- join client to room -----

  //   console.log(`Client with socketId: ${socket.id}, joined room: ${userId}`);
  // });

  
  // ----- 'bookingRequestCreated' event needs to be fired every time when new booking request is created -----
  socket.on("bookingRequestCreated", async (userId) => {
    try{
      let newBookingRequests = await bookingRequestsModel.findAll({
        isEmitted: false,
      });

      if(newBookingRequests){
        console.log(`Booking request ${socket.id} created`);

        let dataToBeUpdated = {
          isEmitted: true,
        };

        newBookingRequests.forEach(async (newBookingRequest)=>{
          // const bookingRequestUpdate = await bookingRequestsModel.bookingRequestUpdate(newBookingRequest.id, dataToBeUpdated);

          const bookingRequestUpdate = await bookingRequestsModel.update(dataToBeUpdated, {
            where: {
              id: newBookingRequest.id,
            },
          });

        });

        // let options = {
        //   where: {
        //     isActive: true,
        //     deletedAt: null,
        //   },
        //   order: ["createdAt", "DESC"],
        // };    
        // let bookingRequests = await bookingRequestsModel.getList(req, bookingRequestsModel, options);

        // ----- listen to 'newBookingArrives' event and call the '/booking-request-list' API -----
        socket.emit('newBookingArrives', `New booking request arrived.`);
        // ----- listen to 'newBookingArrives' event and call the '/booking-request-list' API -----

        console.log(`Booking created with socketId: ${socket.id}`);
      } else {
        console.log(`No new booking created.`);
      }
    } catch(error){
      console.log(`error ==> from "slot booking" catch =>`);
      console.log(error);
    }
  });

  // Handle disconnection
  socket.on('disconnect', () => {
    console.log(`Client disconnected: ${socket.id}`);
  });

  // Handle error =======
  socket.on('error', (err) => {
    console.error(`Socket error: ${err.message}`);
  });
});
// ============================ socket.io END ============================